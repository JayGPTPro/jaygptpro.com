# Day 4: "Training Day"

Today you train Donna's reflexes. You stop typing paragraph-long requests every morning. instead, one command does the whole job. By the end of today you'll have run most of the 12 daily skills on your real data, customized one to fit your business, and know how to build and pull in more.

## What You'll Do Today

1. **Lesson 1**: Skills + Your First Skill (what a Skill is, where they live, the 12 daily skills, run `/morning-briefing`)
2. **Lesson 2**: Your Turn . Run Them on Your Donna (apply what you learned to your own data)
3. **Lesson 3**: Make It Yours (open a skill file, customize one, build new ones, pull more from the community)

## What You'll Need

- Claude Desktop open in the Code tab, kit loaded
- Connectors active from Day 3 (Gmail, Calendar, Drive)
- Your `brain/` filled from Day 2

---

## Lesson 1: Skills + Your First Skill

### Part 1A: What a Skill is

A skill is a one-command shortcut that turns a paragraph-long request into a single line.

**Without a skill:**
> "Hey Donna, read my emails from the last 24 hours, sort them by urgency, check my calendar for today, look at my tasks, scan for risks, and give me a summary with my top priority for today."

(You'd type this every morning.)

**With a skill:**
```
/morning-briefing
```

(Done.)

This is component #5 of Jay's AI Hire Method. **Skills**.

### Part 1B: Where Skills Live

Skills are just text files (`.md` files) inside `.claude/commands/` in your kit. The filename (without `.md`) is the command.

Examples:
- `morning-briefing.md` → `/morning-briefing`
- `draft-reply.md` → `/draft-reply [name]`

You don't need to open the file manually. Anytime you want to view or change a skill, just ask Donna. We'll do this in Lesson 3.

### Part 1C: The 12 daily skills

| Command | What it does | When to use it |
|---------|--------------|----------------|
| `/morning-briefing` | Daily briefing pulled from emails, calendar, tasks, risks | First thing every morning |
| `/evening-summary` | End-of-day wrap. done, not done, tomorrow's plan | Last thing every evening |
| `/draft-reply [name]` | Drafts a reply in your voice | Whenever an email needs a response |
| `/prep-meeting [name]` | Full briefing for a specific meeting | Day before any meeting |
| `/tasks` | Overview of incomplete tasks | When you feel scattered |
| `/accountability` | Status report on promises (yours + theirs) | Weekly, or when things feel slippery |
| `/forgotten-emails` | Threads you missed, in both directions | Once a week |
| `/block-time [task]` | Calendar block for things you keep postponing | When something keeps getting bumped |
| `/risks` | Business risks scan with action items | Once a week |
| `/weekly-report` | Weekly summary. wins, misses, patterns | Sunday morning |
| `/learn` | Improvement loop. updates her memory | ⚠️ Auto-only via Routine. Set up Day 5 |
| `/ask-jay [q]` | Help with anything Donna or kit related | Whenever you're stuck |

Plus the 2 onboarding skills you already used on Day 2 (`/learn-me`, `/business-one-pager`). 14 skills total.

> **⚠️ `/learn` is special . don't run it manually.** It runs automatically as part of your evening routine. We set this up tomorrow on Day 5. For now, just know it exists. Save it for Day 5.

### Part 1D: Two ways skills get triggered

- **Manual** . you type the slash command yourself (`/morning-briefing`). Fast and predictable.
- **Automatic** . Donna recognizes when a skill is relevant and fires it on her own. Just describe what you want, she picks the right one.

Both work. Manual is faster when you remember the skill exists. Automatic is great for when you forget.

### Part 1E: Run the headline skill

`/morning-briefing` is THE skill you'll use every day. Pulls from everything: brain/, Gmail, Calendar, Drive, optional task manager.

```
/morning-briefing
```

No need to add anything else. Just send.

**Look for these in her output:**
- Donna opening line (personality, not generic AI)
- Sections with emoji headers (🔴 URGENT, 📅 CALENDAR, ✅ TASKS, ⚠️ RISKS, 🎯 #1 PRIORITY)
- Specific numbers and names (not "a few emails" but "3 emails. one from Mike Johnson...")
- Donna closing line

If your output has those four. The skill is working.

> **Behind the scenes . the Self-Check Gatekeeper.** This is component #6. **Quality.** Every skill runs a Self-Check before showing output. Catches vague language, missing numbers, missing personality. If anything fails, Donna fixes it before showing. You never see the failure.

**Output also saves to** `brain/Daily Logs/[YYYY-MM-DD].md`. So tomorrow's `/evening-summary` and `/learn` have something to reference.

---

## Lesson 2: Your Turn . Run Them on Your Donna

Lesson 1 showed you what skills are and ran the headline one. This lesson is about **actually using them**. My goal is that by Day 5 you actually **have** Donna as your Chief of Staff . not just know how she works.

Go back to the 12 daily skills above and pick at least 5 to run on your real data. Here are 5 common starters:

### `/draft-reply [name]`

Pick one real email that needs a response. Then:
```
/draft-reply [sender's name or short email description]
```

**What to expect:** A draft that uses your greeting, sign-off, sentence length, and tone (pulled from `brain/Preferences/Style.md`). Flags any dollar amounts or commitments mentioned. Does NOT send. just drafts.

**If the tone is off:** Run `/learn-me` again and give Donna more samples. Or tell her: "read my sent emails from the last 30 days to learn my voice."

### `/forgotten-emails`

```
/forgotten-emails
```

**What to expect:** Two lists. emails YOU haven't answered (3+ days old), and emails OTHERS owe you. With suggested next actions.

> Empty list = win, not failure. Means your inbox is clean.

### `/prep-meeting [name]`

Pick someone you have a real upcoming meeting with. Check your calendar if you're not sure who's next.

```
/prep-meeting [their name or meeting title]
```

**What to expect:** A brief covering: who they are, last interaction, open items, what they probably want to discuss, your suggested agenda, watch-outs. Pulls from email history + calendar + brain/People/.

### `/risks`

```
/risks
```

**What to expect:** Risks categorized as 🔴 HIGH, 🟡 MEDIUM, 🟢 LOW. Each with a recommended action.

> "All clear" is also a valid answer. She won't manufacture risks.

### `/accountability`

```
/accountability
```

**What to expect:** Status report on every promise. yours and theirs. Plus goal progress with traffic-light status, patterns Donna noticed, and a bottom-line "where you stand" answer.

### Or pick any 5 from the full list

You don't have to run these specific five. Pick any 5 from the 12 daily skills in Lesson 1 that resonate with you right now.

**Don't skip this step.** Donna has the power of Claude Code behind her AND access to your real Gmail, Calendar, and Drive. She can bring real value today. You just need to run the skills.

---

## Lesson 3: Make It Yours

### Part 3A: Open a skill file (ask Donna to show it)

Skills are just text. Let's prove it.

Tell Donna:
```
Show me the contents of .claude/commands/morning-briefing.md
```

You'll see structured Markdown: a Meta table at top, "Steps" section with what Donna does in order, "Output Format" template, "Opening Lines" + "Closing Lines" banks for personality, "Self-Check" checklist at the end.

**This is the whole skill.** No code. No magic. Just instructions Donna follows.

### Part 3B: Add ONE business-specific rule

Pick the skill you'll use most . probably `/morning-briefing`. Then think of ONE thing about your business that you'd want her to add to it.

Just tell Donna what to add and where . she'll edit the file for you. You don't touch a thing.

**Examples of what to ask her to add:**
- "Add to the morning briefing: the top headline from [my industry source] every day."
- "Flag every email from [specific person or client name] in red."
- "When prepping for a meeting with [VIP client], also pull our last 3 conversations and the last invoice we discussed."
- "If I have more than 4 meetings tomorrow, warn me in the morning briefing with 'heavy day ahead.'"

Save the change. Run the skill again. Your custom rule should appear in the new output.

### Part 3C: Same principle for her memory

You just made a skill yours by adding one rule. Same idea applies to her brain.

Donna saves outputs of skills automatically (Daily Logs, Learning Log). But she doesn't always save free-flowing conversations. When you tell her something important about a person, decision, or preference . say so explicitly:

- *"Save this to brain/People/[name].md"*
- *"Add this decision to brain/Decisions.md"*

**Her second brain only grows from what you ask her to remember.**

### Part 3D: Want to create your own skill?

Customizing existing skills is one thing. Building new ones is even better.

**Best way:** tell Donna *"create a new skill for X"* and she'll draft the file with you, copying the structure of an existing skill.

**Remember the Power Workflow from Day 3?** The "Schedule a Meeting end-to-end" prompt that pulled from brain, calendar, Gmail, your task manager, and Drive in one go?

Today's a perfect time to turn it into a skill. Tell Donna:
```
Make the Schedule a Meeting workflow from yesterday into a skill called /schedule-meeting.
```

She'll create the file in `.claude/commands/`. Next time you need to schedule a meeting, you type `/schedule-meeting`. One command. Same workflow. Forever.

### Part 3E: Bonus . Let Donna find more skills for you

You have 14 skills. There are hundreds more out there. Community skills. Skills other people built. Skills that fit very specific industries.

Here's a trick. Tell Donna to pick the right ones for you:

```
Scan everything you know about me. my CLAUDE.md, memory, and project history. Search for new skills I don't have yet, install globally the ones that will help me most, and explain in one line why each one fits me.
```

Tailored, not generic. She picks based on what she knows about your business.

---

## What Day 4 Success Looks Like

By the end of today:
- You ran `/morning-briefing` and saw the full morning routine in one command
- You ran 5+ different skills on your real data
- You customized at least one skill with a business-specific rule
- You saw how to build new skills from scratch (and Donna did it for you)

**Tomorrow:** Day 5. Routines + Learning. Donna goes autonomous.

---

## Checklist for Day 4

Only the things that matter for moving on:

- [ ] `/morning-briefing` ran successfully with real data
- [ ] Ran at least 5 different skills
- [ ] Customized one skill with a business-specific rule

---

## Common Issues / FAQ

**Q: A skill isn't recognized when I type the command.**
Skills load when a conversation starts. Try a fresh conversation. If it still doesn't work, ask Donna to list `.claude/commands/` and confirm the file is there.

**Q: The output looks generic. no personality, no specifics.**
Self-Check Gatekeeper might not have fired. Restart the conversation (skills reload at conversation start) and run again.

**Q: `/weekly-report` and `/evening-summary` look thin. Why?**
Expected on Day 4. They depend on internal Daily Logs that get richer as Donna runs daily. Set up Routines on Day 5 and check back in a week.

**Q: I don't have a meeting / inbox is empty / no tasks. Demos don't work.**
Use the closest version: pick any past email for `/draft-reply`, or skip a skill if it has nothing to act on. The skill itself is fine. just nothing to chew on right now.

**Q: Can I delete a skill I don't want?**
Yes. Delete the `.md` file from `.claude/commands/`. The command stops working. Or move it to a `.disabled` subfolder if you want to keep it for later.

**Q: Can I create my own skills?**
Yes. Add a new `.md` file in `.claude/commands/`. The filename (without `.md`) becomes the command. Best way: tell Donna "create a new skill for X" and she'll draft it with you, copying the structure of an existing skill.

---

## Stuck?

Type `/ask-jay [your question]` in Claude. Donna checks all the guides and answers on Jay's behalf.

# Day 5: "She Works While You Sleep"

The final day. Donna becomes autonomous. She runs on her own every morning, every evening, before meetings, and weekly. By the time you wake up tomorrow, your morning briefing is already waiting.

## What You'll Do Today

1. **Lesson 1**: Routines (the shift from waiting to running + setup of all 4 routines)
2. **Lesson 2**: The Learning Loop (`/weekly-report`, `/accountability`, how `/learn` runs in the background)
3. **Lesson 3**: Graduation (Graph View, the reflection, what you built, what Donna can do starting today)

## What You'll Need

- Claude Desktop open in the Code tab, kit loaded
- All skills from Day 4 working
- Connectors from Day 3 still active

---

## Lesson 1: Routines

Until today, Donna has been waiting for you. You open Claude, you type a command, she runs it, she goes back to sleep.

**Today she stops waiting.** Routines let her run on a schedule, automatically, without you opening Claude. Morning briefing at 7am. Meeting prep at 6pm the night before. Evening summary at 9pm. Weekly report Sunday morning.

This is component #7 of Jay's AI Hire Method. **Routines.**

### Where Routines live

In Claude Desktop, in the **Code tab**, look at the left sidebar. Between **Search** and **Dispatch**, you'll see **Routines**.

If you don't see it, go to **Help → Check for Updates** and update Claude Desktop.

Click **Routines** to open the panel. Then click **+ New Routine** for each one we set up.

### Routine 1 . Morning Briefing (7:00 AM)

1. Click **+ New Routine**
2. Name: `Morning Briefing`
3. Schedule: Every day at **7:00 AM** (your local time)
4. Prompt:
```
Run /morning-briefing

After generating the briefing, save it to brain/Daily Logs/ with today's date as the filename (YYYY-MM-DD.md format).
```
5. Save

### Routine 2 . Meeting Prep (6:00 PM evening before)

1. **+ New Routine**
2. Name: `Meeting Prep`
3. Schedule: Every day at **6:00 PM**
4. Prompt:
```
Run /prep-meeting for every meeting on tomorrow's calendar. Save all briefs to brain/Daily Logs/ under a "## Meeting Prep" heading.
```
5. Save

### Routine 3 . Evening Summary (9:00 PM)

1. **+ New Routine**
2. Name: `Evening Summary`
3. Schedule: Every day at **9:00 PM**
4. Prompt:
```
Run /evening-summary

After generating the summary, append it to today's Daily Log in brain/Daily Logs/ under a "## Evening Summary" heading.
```
5. Save

> **Heads up:** This one also triggers `/learn` in the background. So every night, Donna reviews the day and updates her memory automatically.

### Routine 4 . Weekly Report (Sunday 9:00 AM)

1. **+ New Routine**
2. Name: `Weekly Report`
3. Schedule: Every **Sunday at 9:00 AM**
4. Prompt:
```
Run /weekly-report and save to brain/Daily Logs/[today's date]-weekly.md
```
5. Save

> Pick whatever times fit your real schedule. The defaults above are a starting point.

---

### 💡 Important things to know about Routines

**1. Your computer needs to be on for routines to run live, but it catches up automatically.**

You don't need to leave your laptop on overnight. When you wake it (or turn it on), Claude Desktop runs the most recent missed slot per routine . automatically, no manual trigger. So if your laptop was off all night, your morning briefing shows up when you open it. Only the latest one (no spam if you missed several).

**2. Set each routine to "Auto mode" (CRITICAL).**

By default, Claude pauses to ask permission for every action it takes. That breaks autonomous routines. Switch each routine to Auto mode:

1. Click the **pencil icon** (edit) on the routine
2. In the prompt area, look at the **bottom-left** . you'll see a dropdown that says "default"
3. Click it and switch to **"Auto mode"**
4. Save

In Auto mode, Claude approves safe operations automatically and only stops for risky ones. **Without this, your routine will stall waiting for your approval every single time.**

**3. Multiple routines at the same time? Fine.**

You can set 2 routines for 7am. They run sequentially with a small stagger (up to 10 min) to avoid hitting API limits at once.

**4. Want it to run even when your computer is off?**

Advanced option: Cloud Routines run on Anthropic's infrastructure. Requires pushing `brain/` to a GitHub repo (more setup). For most people, Local routines work fine . they catch up when you open your laptop. Explore later at [claude.ai/code/routines](https://claude.ai/code/routines) if you want.

**Pro plan limit:** 5 Routines per day. Donna uses 4. You have 1 left for whatever else. Max plan supports 15.

✅ **You now have 4 routines on autopilot.** That's the "she works while you sleep" promise. Starting tomorrow morning.

---

## Lesson 2: The Learning Loop

Donna doesn't stay the same. Every evening, she runs `/learn`. She reviews what worked, what didn't, and updates her own memory.

- After a week. drafts sound more like you
- After a month. she anticipates patterns
- After 3 months. nothing like the Donna you met on Day 1

Component #8 of Jay's AI Hire Method. **Learning.**

### Run /weekly-report manually (preview)

```
/weekly-report
```

Pulls from your real emails and calendar from the past week. Output covers: wins, misses, numbers, promise tracking, patterns, next week's plan. By next Sunday, with another week of Daily Logs, the insights get sharper.

The Routine you set up in Lesson 1 will fire this automatically every Sunday at 9am.

### Run /accountability

```
/accountability
```

Honest assessment of what you're tracking, what's stuck, where you're slipping. Run it weekly. Or whenever you feel things slipping.

### How /learn runs in the background

You don't run `/learn` directly. The Evening Summary routine you set up runs it automatically as part of its end-of-day work.

What it does: reviews the day's interactions, notices what worked (and what didn't), and updates `brain/Learning/learning-log.md` with patterns and lessons.

**After 30 days of running, that file becomes the most valuable thing in your kit.** It's Donna's accumulated wisdom about you.

---

## Lesson 3: Graduation

### Open Graph View in Obsidian (the visual wow)

Open Obsidian. Click the graph icon in the left sidebar (or press **Cmd+G** on Mac, **Ctrl+G** on Windows).

This is **Graph View**. It shows how everything connects. people, decisions, goals, daily logs. Every wiki link Donna created between files becomes a visible connection.

**On Day 5, your graph will be sparse (10-20 nodes). That's normal.** It grows over time. By Day 30 you'll see clusters of People connecting to Goals connecting to Decisions connecting to Daily Logs.

> **Pro tip:** Take a screenshot today. Take another at Day 30. The difference is dramatic.

### The Reflection

Open `output/business-one-pager.md` (the one Donna wrote on Day 2). Read it again.

Then ask Donna:
```
Compare what you knew about me on Day 2 vs what you know now. What's changed? What's sharper?
```

Save her response somewhere safe. This is your before/after snapshot.

In 30 days, ask the same question again. The growth will surprise you.

### What you built in 5 days

| What | Details |
|------|---------|
| **Identity + Memory** | Donna knows your business, your style, your priorities, and her own personality |
| **4 Connectors** | Gmail, Calendar, Drive, Task Manager (or operating without one) |
| **14 Skills** | 12 daily skills + `/learn-me` and `/business-one-pager` for onboarding |
| **4 Routines** | Morning briefing (7:00), meeting prep (18:00), evening summary (21:00), weekly report (Sunday 9:00) |
| **Memory System** | Daily Logs, People profiles, Goals, Promises, Decisions, Learning Log |
| **Self-Check Gatekeeper** | Every skill checks itself before delivering |
| **Learning Loop** | Donna gets sharper every evening via `/learn` |

### What Donna can do for you starting tomorrow

Not "someday." Tomorrow morning. Here's what she handles for you, automatically:

- 📋 **Wakes up before you** and sends a morning briefing pulled from your real Gmail and Calendar
- ✍️ **Drafts replies** to any email in your exact voice (you approve before send)
- 🤝 **Preps you for tomorrow's meetings** the night before, with full context from past interactions
- 🎯 **Tracks every promise** you made, and the ones people owe you
- 📬 **Surfaces emails you missed** in both directions (3+ days unanswered)
- 📅 **Blocks calendar time** for things that keep getting bumped
- ⚠️ **Scans for business risks** weekly . catches problems before they explode
- 📊 **Sends a weekly report** every Sunday: wins, misses, patterns, what to focus on
- 🧠 **Updates her own memory** every night . gets sharper about you every day
- 🔎 **Pulls cross-source timelines** across Gmail + Calendar + Drive on demand
- 💳 **Audits subscriptions and spending** when you ask
- 🪞 **Tells you the uncomfortable truth** when you have the courage to ask

All for $20/month. Working, on schedule, while you sleep.

**This is a working AI Chief of Staff.** She costs $20/month (Pro). She works on schedule. She remembers everything. She gets smarter every day.

**You hired your first AI employee. Congratulations.**

---

## What Day 5 Success Looks Like

- 4 Routines set up and enabled (all in Auto mode)
- `/weekly-report` ran (partial output is expected today)
- `/accountability` ran. you saw Donna's honest read on your week
- Graph View opened in Obsidian (sparse but live)
- Reflection done. before/after snapshot saved

---

## Day 6+ Operating Manual

**Tomorrow (Day 6):**
- Morning briefing arrives at 7 AM (or when you open Claude after)
- Read it in Obsidian (`brain/Daily Logs/[today's date].md`)
- Reply to Donna with feedback if anything's off. this trains `/learn`
- Use `/draft-reply` throughout the day
- Evening summary arrives at 9 PM

**First Sunday:**
- Weekly report arrives at 9 AM
- Block 30 minutes to read it
- Adjust Goals.md if priorities shifted

**First month:**
- Watch `/learn` slowly improve voice matching
- Add new People manually as Donna encounters them
- Review one custom skill rule each week
- Compare Graph View at Day 30 vs Day 5 screenshot

---

## How to Keep Improving

1. **Add more skills** as you discover repetitive tasks (ask Donna to "create a new skill for X")
2. **Update People profiles** as Donna encounters new contacts
3. **Review Weekly Reports** to spot patterns over time
4. **Update Goals and Promises** when priorities shift
5. **Add more writing samples** so Donna's drafts get closer to your voice
6. **Use `/ask-jay`** anytime you're stuck or unsure
7. **Trust the Learning Loop**. Donna gets better every day she runs `/learn`

---

## Checklist for Day 5

Only the things that matter:

- [ ] Morning Briefing routine set up (7:00 AM, daily, Auto mode)
- [ ] Meeting Prep routine set up (6:00 PM, daily, Auto mode)
- [ ] Evening Summary routine set up (9:00 PM, daily, Auto mode)
- [ ] Weekly Report routine set up (Sunday 9:00 AM, Auto mode)
- [ ] Ran `/weekly-report` and `/accountability` manually (preview)
- [ ] Opened Graph View in Obsidian (took a screenshot for the 30-day comparison)
- [ ] Saved the reflection answer somewhere

---

## Common Issues / FAQ

**Q: I don't see "Routines" in the sidebar.**
Help → Check for Updates. Update Claude Desktop. The Routines panel was added in a recent version. If still not visible after update, restart Claude.

**Q: My routine didn't fire at the scheduled time.**
Routines need Claude Desktop to be open at the scheduled time, or they queue and fire when you open it next. If your laptop was off, the most recent instance fires automatically (no spam from missed days).

**Q: My routine keeps asking for permission every time.**
You didn't set it to Auto mode. Click the pencil icon on the routine, find the dropdown at the bottom-left of the prompt area (says "default" by default), switch it to "Auto mode", save. Now it runs autonomously.

**Q: `/weekly-report` looks thin.**
Expected on Day 5. You only have 4-5 days of Donna data. By next Sunday it's full power.

**Q: Graph View is empty.**
You need wiki links between files for the graph to populate. Donna creates these automatically as she runs more skills. By Day 30, the graph will be dense.

**Q: Can I add a 5th routine?**
Yes. Pro plan supports 5 routines per day. You used 4. You have 1 left for whatever fits your work. Max plan supports 15.

**Q: Can I make my routines run even when my computer is off?**
Yes, via Cloud Routines. They run on Anthropic's infrastructure but require pushing your `brain/` to a GitHub repo. More setup. For most people, Local routines work fine because they catch up when you open your laptop. Explore at [claude.ai/code/routines](https://claude.ai/code/routines).

---

## Stuck?

Type `/ask-jay [your question]` in Claude. Donna checks all the guides and answers on Jay's behalf.

# Setting Up Routines (Day 5)

Routines let Donna run automatically at set times. She can send you a morning briefing before you wake up and an evening summary before bed.

**📢 Note:** Routines is the new name (April 2026) for what used to be called "Scheduled Tasks." Same feature, new name. Existing `/schedule` tasks were auto-migrated.

## How Routines Work

Routines run **locally on your computer**. When the scheduled time arrives:
- If Claude Desktop is open → the routine runs immediately
- If your computer is off or asleep → the routine queues. When you turn the computer back on (or wake it), Claude Desktop runs **the most recent missed slot per routine** automatically. No manual trigger needed.

So if you close your laptop at 11 PM and turn it on at 9 AM, the morning briefing runs as soon as Claude Desktop opens. Only the most recent missed slot fires (no spam from multiple missed days).

**You don't need to leave your laptop on overnight.** The catch-up behavior handles it.

### Want it to run even when your computer is off?

Advanced option: **Cloud Routines** run on Anthropic's infrastructure. Requires pushing your `brain/` to a GitHub repo (more setup). For most people, Local routines work fine because they catch up on wake. Explore at [claude.ai/code/routines](https://claude.ai/code/routines) if you want.

---

## ⚠️ Critical: Set Auto Mode on Every Routine

By default, Claude pauses to ask permission for every action a routine takes. That breaks autonomous routines.

**For every routine you create, switch it to Auto mode:**

1. Click the **pencil icon** (edit) on the routine
2. In the prompt area, look at the **bottom-left** . you'll see a dropdown that says "default"
3. Click it and switch to **"Auto mode"**
4. Save

In Auto mode, Claude approves safe operations automatically and only stops for risky ones. **Without Auto mode, your routine will stall waiting for approval every single time.**

---

## Setting Up Your Morning Briefing (7:00 AM)

### Step 1: Open Routines
1. In Claude Desktop, make sure you're in the **Code** tab (top center)
2. Look at the **left sidebar**. You'll see: New session, Search, **Routines**, Dispatch, Customize
3. Click **Routines**

### Step 2: Create New Routine
1. Click **+ New Routine**
2. Name it: "Morning Briefing"
3. Set the schedule: **Every day at 7:00 AM** (or whatever time you wake up)

### Step 3: Write the Routine Prompt
Copy and paste this prompt:

```
Run /morning-briefing

After generating the briefing, save it to brain/Daily Logs/ with today's date as the filename (YYYY-MM-DD.md format). If a file for today already exists, add the briefing under a new "## Morning Briefing" heading.
```

### Step 4: Save, Enable, Switch to Auto Mode
1. Click **Save**
2. Make sure the toggle is set to **Enabled**
3. **Switch to Auto Mode:** reopen the routine (pencil icon), find the dropdown at the bottom-left of the prompt area that says "default", switch to **"Auto mode"**, save. Without this, the routine stalls on every approval prompt.
4. The routine will run tomorrow at your set time

### Step 5: Verify
- Check brain/Daily Logs/ the next morning for a new file
- If nothing appeared, check troubleshooting below

---

## Setting Up Your Evening Summary (9:00 PM)

### Step 1: Create Another Routine
Same process as morning. Name it: "Evening Summary"

### Step 2: Set Schedule
**Every day at 9:00 PM** (or whenever you want your daily wrap-up)

### Step 3: Write the Routine Prompt
```
Run /evening-summary

After generating the summary, append it to today's Daily Log in brain/Daily Logs/[today's date].md under a "## Evening Summary" heading. If the file doesn't exist yet, create it.
```

### Step 4: Save and Enable

---

## Setting Up Meeting Prep (6:00 PM)

### Step 1: Create Routine
- **Name:** Meeting Prep
- **Schedule:** Every day at 6:00 PM
- **Prompt:**
```
Run /prep-meeting for every meeting on tomorrow's calendar that has attendees. Save all briefs to brain/Daily Logs/[today's date].md under a "## Meeting Prep" heading.
```

---

## Setting Up Weekly Report (Sunday 9:00 AM)

- **Name:** Weekly Report
- **Schedule:** Every Sunday at 9:00 AM
- **Prompt:** `Run /weekly-report and save it to brain/Daily Logs/[today's date]-weekly.md`

---

## After Setup: What to Expect

When everything is working:

**7:00 AM** - Donna automatically:
- Reads your unread emails
- Checks today's calendar
- Reviews your tasks
- Writes a morning briefing to brain/Daily Logs/

**6:00 PM** - Donna automatically:
- Preps you for tomorrow's meetings
- Adds prep notes to brain/Daily Logs/

**9:00 PM** - Donna automatically:
- Reviews what you completed today
- Checks for unfinished tasks
- Looks at tomorrow's calendar
- Writes an evening summary to the same Daily Log
- Auto-runs /learn to update her memory

**Sunday 9:00 AM** - Donna automatically:
- Generates the weekly report
- Wins, misses, patterns, next week's plan

**You wake up** and read brain/Daily Logs/[today].md to see everything.

---

## Troubleshooting

| Problem | Fix |
|---------|-----|
| Routine didn't run | Check it's enabled. Was Claude Desktop open at the scheduled time? If not, it runs when you next open Claude Desktop (most recent missed slot only). |
| Routine keeps asking for permission | You didn't set Auto mode. Edit the routine, switch the bottom-left dropdown from "default" to "Auto mode", save. |
| Routine ran but no file in brain/ | Check the prompt includes "save to brain/Daily Logs/" |
| Routine runs but output is incomplete | Check that Gmail and Calendar connectors are still connected |
| I want to change the time | Routines sidebar > Edit |
| I want to disable temporarily | Toggle the routine to Disabled (don't delete it) |
| I closed my laptop and missed it | Open Claude Desktop. The queued routine will run automatically. Only the most recent missed slot fires (no spam). |
| I want it to run even when my computer is off | Use **Cloud Routines** at [claude.ai/code/routines](https://claude.ai/code/routines). Requires pushing brain/ to GitHub. |

---

## How Many Routines Should I Set Up?

The full Donna automation needs **4 routines**:

| Routine | Time | What It Does |
|---------|------|--------------|
| Morning Briefing | 7:00 AM daily | Email triage + calendar + tasks + #1 priority |
| Meeting Prep | 6:00 PM daily | Briefs for tomorrow's meetings |
| Evening Summary | 9:00 PM daily | Day wrap + auto /learn |
| Weekly Report | Sunday 9:00 AM | Wins, misses, patterns, next week |

Set up all 4. This is what makes Donna autonomous.

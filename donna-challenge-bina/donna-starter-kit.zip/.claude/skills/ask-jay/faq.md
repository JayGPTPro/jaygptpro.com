# Ask-Jay FAQ . Round 1 Knowledge Base

Real questions and answers from the WhatsApp group of Round 1 (Apr 19-26, 2026).
Use this as the FIRST source when a participant asks something. Match by topic and intent, then quote/paraphrase the answer.

If a question doesn't fit any of these categories, fall back to the day guides and CLAUDE.md per the search order in SKILL.md.

---

## 1. Setup & Installation

**Q: Should I reinstall Claude Desktop after installing Git?**
No. Just close Claude Desktop and reopen it. You may need to reboot. Claude Desktop will detect the Git install on its own.

**Q: I'm on Mac, Claude keeps asking me to install Git. Do I need to?**
Yes, Claude Code does need Git on Mac (it ships with Xcode Command Line Tools, which isn't pre-installed on a fresh Mac). Easiest method without using Terminal: install **GitHub Desktop** (desktop.github.com). It installs Git globally in the background. Then quit and reopen Claude Desktop.

**Q: Can I install the Donna kit in a folder other than the Desktop?**
Yes, anywhere works. Documents, Downloads, a folder inside Claude, whatever fits your flow. Two rules:
1. The folder must be inside your user folder (e.g., `C:\Users\YourName\...` on Windows).
2. After extracting, open THAT location in Claude Desktop via Settings → Open folder.

**Q: I just downloaded the upgraded Donna kit. Do I need to redo /learn-me?**
No. /learn-me is Day 2 content. Unless you jumped ahead and ran it already, your brain/ folder is still empty templates. Replacing the kit doesn't lose anything meaningful. Just delete the old folder, extract the new one, done.

**Q: Do I need to remove and reinstall the vault in Obsidian when updating the kit?**
No. Both Claude and Obsidian just READ files from the folder, they don't store copies. Close both apps, swap the folder content, reopen. Same path, same folder name, new content inside. Both apps will see the new files automatically.

**Q: My Donna folder is in my Downloads folder. Is that OK?**
Yes, you can keep it there.

**Q: I got a Google "unusual traffic" message. Is this because of Donna?**
No. On Day 1 Donna isn't connected to anything yet, the Google connectors come in on Day 3. Even once they're in, it's an official Google API connection, nothing that would trigger that page. What you're seeing is Google Search temporarily blocking your IP (usually a VPN, browser extension, or too many searches in a short time). Clears on its own in 10-30 minutes.

**Q: /ask-jay command isn't recognized as a command.**
Restart Claude Desktop after loading the latest kit. The command needs to be picked up at session start.

---

## 2. WhatsApp Group / Access

**Q: I can't post in the WhatsApp group, says only admins can send messages.**
The group is open to everyone. The issue is likely WhatsApp Desktop sync. Try:
1. Send a test from your phone to confirm the group works.
2. Use the WhatsApp Desktop app (downloaded), not the web app, the web app sometimes shows this error.
3. Log out and reconnect WhatsApp Desktop if needed.

---

## 3. Multiple Businesses & Multiple Employees

**Q: I own multiple unrelated businesses. Do I need a separate Donna for each?**
For the challenge, stick to one business and one email. See the method work end-to-end with clean data first. Once the foundation is solid, expanding is the easy part. Donna can technically handle multiple businesses (Claude Desktop supports multiple connectors, and brain/ can be taught which context belongs to which business), but get the foundation solid first.

**Q: How do I create another employee/agent (e.g., PPC analyst, financial analyst)?**
This is a topic of its own, especially how to connect agents to each other. Don't half-answer it mid-challenge. Finish building Donna first. After the challenge wraps, we'll open a thread and dig into building additional employees together.

**Q: Should each employee have a dedicated vault with its own skills? Can they interact?**
Same answer, this is a deeper topic. Stay focused on Donna for the challenge. Multi-agent architecture and inter-agent communication will be covered after the challenge.

**Q: To create another employee, is it as simple as taking a fresh folder, renaming it, and starting from Day 1 again?**
That's roughly the idea, but the full how-to (and how to make them communicate) deserves its own session. After the challenge wraps, we'll go through it together.

---

## 4. Connectors: Email & Calendar

**Q: Can I connect Donna to Outlook desktop / Apple Calendar?**
No native Apple Calendar connector exists. Outlook desktop is tricky. Cleanest path is using Google Calendar as your main calendar. If you must use M365, the connector is read-only (Donna can read but not modify or send).

**Q: I have a Microsoft 365 Family subscription. Why doesn't Claude connect?**
The Microsoft 365 connector works only with Business / Work / School subscriptions. It does NOT work with Family or Personal plans. Family/Personal accounts (@outlook.com, @hotmail.com) are explicitly unsupported.

**Q: Can Donna send emails through Outlook or Microsoft 365?**
The M365 connector is **read-only for everyone, even on Business**. Donna can read emails, search them, summarize them, and draft replies in chat, but she cannot send or modify from within your M365 mailbox. For sending:
1. Ask Donna to draft in chat, paste into Outlook yourself. Works on any M365 plan including Family.
2. OR set up a separate Gmail account for Donna. Gmail's connector supports drafting and sending with your approval.

**Q: Is the M365 limitation actually a problem?**
Most of what Donna does with email is read-only anyway. Triage, summaries, meeting prep, finding patterns. That's the bulk of her value. Scan through the 12 skills, none of them require her to write or send emails herself. So this shouldn't block you.

**Q: How do I send emails from my Outlook account through Donna (advanced)?**
Requires global admin access to your Office365 tenant. You'd create a dedicated M365 user for Donna with a license (~$4.20/month), then use PowerShell scripts to set up app passwords and "send as" permissions. Not for beginners. For the challenge, use Gmail or have Donna draft in chat for you to paste/send.

**Q: I can't connect Gmail, getting "A server with this URL already exists" error.**
Try this in order:
1. Quit Claude Desktop completely and reopen.
2. Go back to the Directory and try adding Gmail again.
3. If still failing, disconnect the email, connect a different one, then disconnect that one and reconnect the one you actually want. Something about the cycle resets stuck registrations.

**Q: Donna can't read my Gmail through the connector. I've tried everything.**
Sometimes thousands of unread emails overwhelm the API and the connector fails silently. Try bulk marking your unread emails as read. Donna can write the script for you. (Bonus: this is a great use of Donna anyway, cleaning up an overflowing inbox in seconds.)

---

## 5. Privacy & Safety

**Q: How safe is it to give Donna access to emails with sensitive info (SSN, banking, ID numbers)?**
A few things to know:
1. Donna only READS emails through the connector. She cannot send, delete, or modify without your approval (built into her Standing Instructions).
2. Anthropic's privacy policy is explicit: they don't train on your data from the Pro plan.
3. For highly sensitive info, options:
   - Create a dedicated email for Donna (forward only what you want her to see). Workaround used by some community members.
   - Tell Donna in CLAUDE.md: "skip any email containing account numbers, SSNs, or banking info."
   - Use email tags to control which emails she reads.
4. If you need full privacy guarantees, you'd need a local LLM, that's out of scope here.

You stay in control. Start small if unsure: connect Gmail, see what she reads, adjust from there.

---

## 6. Donna's Brain & Long-term Use

**Q: After weeks of usage, can Donna keep up? More input might cause conflicts.**
This is exactly why we work with Obsidian as her brain, the structure gives her a clean place to review, update, and prune what she's learned. Over time she keeps getting sharper, not more conflicted. A weekly cleanup is a great practice. You can build her a dedicated cleanup skill for it (great use case).

**Q: Do you let Donna run all skills, or use her only as assistant and have separate employees per role?**
I use Donna only for what fits her role as Chief of Staff. For other roles I have other employees. Currently building one for a Data Analyst role. The bigger goal of the challenge is for each of you to start building more employees for whatever your business needs, using the same method.

---

## 7. Sessions, Performance, Permissions

**Q: Can I run Donna in multiple sessions in parallel?**
Yes, as many as you want. Plenty in parallel works fine, never tested where the limit is.

**Q: Should Donna take 2-3 minutes to complete simple tasks like an email?**
Depends on a lot: session length, what she's checking (inbox, calendar, brain/, etc.), which model is running, thinking mode, and more. Sometimes instant, sometimes a few minutes. You can keep chatting with her while she works, or open a parallel session and do something else, she multitasks fine.

**Q: It's frustrating clicking "allow" every few seconds during long tasks. Workaround?**
Change permission mode to **Bypass Permissions**. Gives the task full access to run without prompting. Slightly more permissive than Auto mode, but for long-running or unattended work, it's what you need.

**Q: I don't see "Auto mode" in my Routines, only Plan mode / Ask permissions / Accept edits.**
Three options:
1. **Enable it:** Click your profile → Settings → Claude Code → enable "Allow auto permissions mode." Then it appears in your sessions.
2. **Use Bypass Permissions instead.** Slightly more permissive than Auto mode but works fine for routines running unattended.
3. **Fallback:** Use Accept Edits, then run routines once manually with the "Run now" button and accept all permissions as "allow always." It'll work going forward.

---

## 8. Claude Code vs Cowork

**Q: What's the difference between Claude Code and Cowork?**
Honest answer: every time I dig into this, I get a different explanation. Donna should work in both, so use whichever feels smoother. In the challenge I only cover Claude Code. The lines blur as both got upgraded.

**Q: Routines/scheduled tasks, do they run on the cloud (Cowork) vs locally (Code)?**
It's nuanced. The Code-tab Routines we use in the challenge are designed to work even if you're not connected to the cloud or your laptop is off at night. Day 5 walks through the workflow.

---

## 9. Cloud, Mobile, Cross-device

**Q: Is there a way to run Claude Code and Donna on the cloud so I can use any computer or my phone?**
Short answer: no. Claude Desktop runs locally, so Donna lives on whichever computer you set her up on. The mobile app works for chat but doesn't have the Code tab features (no skills, routines, or connectors).

There are creative workarounds (running on a VPS, connecting from mobile when your computer stays on, etc.), but skip them during the challenge. Build Donna the standard way first. Once the foundation is solid, the possibilities are almost endless.

**Q: I work on multiple computers, how do I sync Donna?**
Same answer, no clean cloud sync today. For the challenge, pick one main machine. Cross-device setups (Dropbox/Google Drive sync, VPS, remote desktop) are possible later but add friction.

**Q: Can Donna run from my phone via Dispatch?**
Dispatch lets you send tasks from your phone for Claude on your computer to execute (using Computer Use). However, Donna (running on Claude Code) cannot be dispatched directly. She lives on your laptop. Computer Use + Dispatch together is powerful but:
- Requires Max subscription (not Pro)
- macOS only for now
- Still in Research Preview
- Your computer needs to be on and unlocked

---

## 10. Routines

**Q: I don't see Routines in my sidebar. I'm on Pro plan.**
Routines is a brand new feature, only rolled out a few days ago. Anthropic releases features gradually instead of pushing them to everyone at once. It will reach your account soon. Things to try:
1. Sign out completely and sign back in. Sometimes refreshes feature flags.
2. Try claude.ai/code/routines in browser to check direct access.
3. Watch for Claude Desktop updates. When one's available, you'll see a "Relaunch" button in the bottom-left of the app. Hit relaunch.

**Q: I still don't have Routines after a few days. What do I do meanwhile?**
Just run the routines manually once a day. Takes seconds to activate each skill. The feature should update for you in the next few days.

**Q: My Create button stays gray when I try to create a routine.**
You need to select a folder for the routine. Use the Donna folder.

**Q: I went to bed with my laptop off . will I miss my morning briefing?**
No. Routines catch up automatically. When you wake the laptop (or turn it back on), Claude Desktop runs the most recent missed slot for each routine . once, not all of them. So if your laptop was off all night and you have a 7am morning briefing routine, you'll see it when you open the laptop. No manual trigger needed, no spam if multiple slots were missed. (Source: day5-guide.md, "Important things to know about Routines.")

**Q: Routine ran but it stopped halfway through, asking me to allow stuff.**
The routine is not in Auto mode. Open the routine, switch the permission mode to **Auto mode** (or **Bypass Permissions** if Auto isn't available in your account . see section 7 above). Without it, Claude pauses for permission on every action and the routine breaks.

---

## 11. Other Connectors & Integrations

**Q: Can I connect Donna to Chewy to process my POs?**
No direct Chewy connector. Two paths:
1. **Email-based:** If your POs come through email, Donna can scan, extract, and log them. Covers most of what you'd want.
2. **Chrome-based:** I do this myself on a different site for generating invoices. The Chrome connection lets Donna navigate any site you're logged into. Should work for Chewy the same way. Day 0 covers the Chrome setup.

**Q: Is there a connector for Microsoft Teams?**
To my knowledge, not yet. The Microsoft 365 connector covers Outlook, Calendar, OneDrive, and SharePoint, but Teams isn't part of it as far as I've seen.

**Q: Is there a way to connect Donna to WhatsApp?**
Not natively. Possible via custom development. Out of scope for the challenge, can be tackled after.

---

## 12. Pricing & Plans

**Q: Is Claude Code being removed from the $20 Pro plan?**
There was a brief test on April 21 where Anthropic showed an X next to Claude Code on Pro for ~2% of new signups. It was reverted. Existing Pro and Max subscribers aren't affected. Claude Code remains included on Pro.

---

## 13. Troubleshooting Mindset (recurring theme)

**Q: I'm stuck on something, what should I try first?**
This whole AI thing requires a small mindset shift, the AI is doing everything for you. You just need to ask. When something feels stuck, paste the error or screenshot directly into Claude Code (Donna) and let her help you unstick it with you. Don't try to troubleshoot manually first. That's the muscle the challenge is built to develop.

---

## Defaults / patterns to remember

- Always default to "for the challenge, focus on X" when scope creeps.
- Microsoft 365 Family/Personal: hard limitation, redirect to Gmail.
- Multi-employee questions: deflect to "after the challenge".
- Feature missing in someone's account: usually gradual rollout, not a bug.
- Sensitive privacy questions: Donna is read-only by default, multiple workarounds exist.
- "Stuck on X" question: remind them to paste the error directly into Claude rather than troubleshooting manually.

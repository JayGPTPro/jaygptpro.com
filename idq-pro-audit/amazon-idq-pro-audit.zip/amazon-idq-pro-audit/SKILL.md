---
name: amazon-idq-pro-audit
description: >
  Production-grade audit of Amazon product listings against IDQ scoring, CDQ-relevant quality
  dimensions, Amazon content policy, mobile UX, indexing risk, and conversion best practices.
  Uses Bright Data MCP for live data. Accepts one or more ASINs and delivers a prioritized
  findings report with revenue-impact estimates and actionable fixes.

  Use this skill whenever someone provides ASINs and asks about listing quality, IDQ score,
  CDQ score, listing compliance, title issues, bullet problems, image requirements, A+ content,
  indexing, mobile preview, or conversion optimization. Trigger phrases include: "audit my
  listings", "check my ASINs", "what's wrong with my listing", "why isn't my product indexed",
  "review my Amazon content", "are my bullets compliant", "do my listings meet Amazon policy",
  "is my listing mobile-friendly".

  Requires: Bright Data MCP connection (web_data_amazon_product or scrape_as_markdown tools).

---

# Amazon Listing Quality Audit . Production Edition

Comprehensive audit of one or more Amazon ASINs across 7 dimensions, using only live data from
Bright Data MCP. No Keepa, no Seller Central access, no Amazon Hawk needed.

## Coverage

This skill covers:
- IDQ 5-pillar binary scoring (leaf node, A+, bullets, images, star rating)
- **Category-specific title compliance** (length limits vary by category — handled correctly)
- Bullet point quality (count, length, consistency, policy violations, feature/benefit ratio)
- **Mobile preview analysis** (first 80 chars of title + bullet 1 — what 70% of buyers see)
- **Image quality verification** (resolution check, count, variety heuristics)
- A+ content depth (basic / premium / brand story / video / module count / comparison chart)
- **Indexing risk** (do keyword expectations match content placement)
- Structured attributes completeness
- Cross-ASIN boilerplate detection
- **Revenue impact estimates** per finding

## Does NOT cover

Be explicit with the user about these:
- Backend search terms (invisible externally — check Seller Central flat file)
- Actual CDQ scores from Amazon (requires Hawk tool / SAS membership)
- Pricing, Buy Box, hijackers, PPC performance
- CVS catalog validation errors (internal Amazon tool)
- Inventory health (use other reports)

---

## Step 1 . Collect inputs

If the user hasn't provided ASINs, ask:
- ASIN(s) to audit (comma-separated list)
- Marketplace (default: amazon.com / US)
- Optional: target keywords they want to rank for (used in Step 3.6 Indexing Risk check)
- Optional: their main category if known (used for category-specific title limits)

If ASINs are in the message, proceed.

**Quick vs Deep mode.** Ask:
> "Quick audit (5 min, scoring only) or deep dive (15 min, with rewrites and revenue impact)?"

---

## Step 2 . Pull live data from Bright Data

Verify `mcp__brightdata__*` tools are available. If not:
> "This skill requires the Bright Data MCP. Run `claude mcp list` to verify it's connected. If
> not, see installation guide."

For each ASIN, call:

```
mcp__brightdata__web_data_amazon_product
url: "https://www.amazon.com/dp/{ASIN}"
```

**For 3+ ASINs, batch the calls in a single turn** (parallel). Don't sequential-wait.

**Fallback.** If `web_data_amazon_product` is not available, use `scrape_as_markdown` and parse.
Note in the report that fallback was used.

**On 404 / empty / error.** Flag the ASIN as "not accessible / possibly inactive or
region-locked". Exclude from scoring. Never fabricate data.

### Key fields and their use

| Field | Use |
|-------|-----|
| `title` | Length, mobile preview, compliance checks |
| `features` | Bullet array — quality checks |
| `images_count` | IDQ pillar 4 + competitive baseline |
| `images` (array of URLs) | **Resolution check via HEAD request** |
| `plus_content` | A+ presence |
| `product_description` | A+ modules array — depth + premium signals |
| `from_the_brand` | Brand Story presence |
| `video_count` | A+ video presence |
| `categories` | Leaf node + category-specific title limits |
| `rating` | Star rating (float). Absent on new ASINs. |
| `is_available` | Stock status |
| `product_details` | Structured attributes — count populated |
| `bs_category` | BSR context only |

### Premium A+ detection

If `product_description` is non-empty AND contains entries referencing very wide images (≥1464px)
OR video modules, that's Premium A+. Basic A+ = `plus_content: true` but no premium signals.
When ambiguous, note "A+ present — type unclear."

---

## Step 3 . Score each ASIN

### 3.1 . IDQ 5-Pillar Score (0–5)

Each pillar binary: pass = 1, fail = 0.

| Pillar | Pass | Fail Signal |
|--------|------|-------------|
| **1. Leaf Node** | `categories` has ≥3 levels AND deepest entry is specific (not "All Departments") | Shallow or missing category path |
| **2. A+ Content** | `plus_content: true` OR `product_description` non-empty | Both empty/false |
| **3. Bullet Points** | `features` has ≥5 entries | Fewer than 5 bullets |
| **4. Images** | `images_count ≥ 5` | Fewer than 5 |
| **5. Star Rating** | `rating ≥ 3.0` | Below 3.0. New ASIN with no rating: **N/A**, not fail. |

IDQ = `[pillars passed] / 5`. A 5/5 ASIN gets full inclusion in Amazon's A10 algorithm.

---

### 3.2 . Title Quality (with category-aware limits)

**FIRST: Determine the category-specific character limit.** Look at `categories` array:

| Category contains | Max title chars |
|-------------------|-----------------|
| "Clothing", "Shoes", "Jewelry" | 80 |
| "Beauty", "Health & Personal Care" | 100 |
| "Grocery", "Gourmet Food" | 100 |
| "Sports & Outdoors" | 150 |
| "Toys & Games" | 200 |
| "Books", "Music", "Movies & TV" | 200 |
| Everything else (default) | 200 |

**Note.** Amazon has been progressively tightening these. Some categories now enforce 150
strict. Always note the applied limit in the report.

**Then run these checks on the raw title string:**

1. **Character count** vs category limit. Flag if exceeds. Always show count + limit.
2. **All-caps words** ≥4 chars unless recognized acronym (IGP, DOP, USA, PDO, PGI, FBA, BPA,
   FDA, CE, OEM, GMO, NSF, etc). Use judgment for brand abbreviations.
3. **Promotional language.** Flag any of:
   - Tier 1 (definite violations): "Best Seller", "#1 in [...]", "Sale", "Free Shipping",
     "Top Rated", "Guaranteed", "Award Winning", "As Seen On TV", "Limited Time", "Exclusive"
   - Tier 2 (subjective superlatives): "amazing", "perfect", "incredible", "ultimate",
     "revolutionary", "world's best", "unbeatable"
   - Tier 3 (unverified claims): "BPA-Free" without certification, "FDA approved" for
     non-FDA categories, "Organic" without USDA cert, "Eco-friendly" without specific cert
4. **Prohibited special characters.** Flag: `!`, `$`, `?`, `~`, `{`, `}`, `^`, `¬`, `¦`, `*`,
   `™`, `®` in non-brand-name positions, **emojis** (🌟⭐ etc — Amazon policy violation).
   Allowed: `( ) , . - & ' : /`
5. **Repeat words.** Flag any content word appearing 3+ times. Exclude stop words:
   `the, a, an, of, in, for, with, and, or, to, by, on, at, from, is, are`
6. **Brand placement.** Note whether brand appears in first 30 characters (best practice).
7. **First 5 words.** These carry highest A9 algorithm weight. Note if they include the
   primary keyword (if user provided target keywords in Step 1).
8. **Title Case.** Flag if large sections are sentence case or ALL CAPS rather than Title Case.

---

### 3.3 . Mobile Preview Analysis (NEW — critical)

**70%+ of Amazon buyers are on mobile.** Mobile shows only ~80 chars of title and 80 chars of
bullet 1 in the search results card.

Extract and analyze:

**Mobile Title.** First 80 chars of title:
- Does it stand alone (i.e., communicate value without the rest)?
- Does it include brand?
- Does it include primary keyword?
- Does it have any of the policy violations above?

**Mobile Bullet 1.** First 80 chars of `features[0]`:
- Does it lead with a benefit (good) or a feature/spec (suboptimal)?
- Is it cut off mid-word?
- Does the meaningful message fit?

Output a "Mobile Preview" box showing exactly what shoppers see, with flags.

---

### 3.4 . Bullet Point Quality

Run on each entry in `features`:

1. **Count.** <3 = critical gap. 3–4 = suboptimal. ≥5 = IDQ pass. Note max: 5 standard, up to 10
   in some categories (Grocery, Industrial).
2. **Length per bullet.** 10–255 characters. Flag shorter (signals laziness) or longer (gets
   truncated).
3. **Length consistency.** Compute standard deviation of bullet lengths. If max bullet is >2x
   shortest, flag "inconsistent bullets — suggests rushed writing."
4. **ALL CAPS headers.** Flag any bullet starting with an ALL CAPS phrase followed by `:` or `-`
   (e.g., "PREMIUM QUALITY:", "MADE IN ITALY -"). **This is a documented Amazon policy
   violation that can suppress listings.** Critical severity.
5. **End punctuation.** Flag bullets ending in `.` `!` `?`. Amazon policy: no end punctuation.
6. **Comparative claims.** Flag bullets containing: "unlike other", "better than", "superior
   to", "the best", "number one", "only product", "no competitor", "leading brand".
7. **Cross-promotion.** Flag bullets containing: "visit our store", "visit the [x] store",
   "check our other listings", "see our brand page", "browse our catalog".
8. **Starts with capital.** Flag bullets not starting with a capital letter.
9. **Boilerplate / duplicate.** When auditing multiple ASINs, compare bullet text across ASINs.
   Flag any bullet appearing verbatim in 3+ ASINs as "catalog-wide boilerplate" — critical
   severity since policy violations in those bullets affect every ASIN at once.
10. **Feature vs Benefit ratio.** Heuristically classify each bullet:
    - **Feature** = describes specs (size, material, capacity, certification)
    - **Benefit** = describes outcome for buyer (keeps cold for 24 hours, fits in any cup holder)
    - Healthy ratio: ~30% feature / 70% benefit
    - All-feature bullets = low conversion. Flag if ratio is >60% feature.
11. **Subjective unverified.** Flag promotional language inside bullets (same Tier 1-3 from title).

---

### 3.5 . Image Quality (real checks, not just count)

For each image URL in `images` array:

1. **Resolution check.** Fetch headers (HEAD request) on the highest-resolution version. Most
   Amazon images come in multiple sizes — pick the largest. Look for `_SL1500_` or similar
   suffixes in the URL. If you can determine width:
   - <1000px on longest side: **Fail.** Zoom won't work. Flag.
   - 1000–1500px: Adequate but not optimal.
   - ≥1500px: Good.
   - ≥2000px: Optimal.
2. **Count.** Same as IDQ pillar 4. <5 fail / 5–7 baseline / ≥8 competitive.
3. **Image type variety (heuristic).** From URL filenames or content sampling:
   - Main image (white background) — required
   - Lifestyle / in-use shots — recommended ≥2
   - Infographic with text — recommended ≥1
   - Scale reference / dimensions — recommended ≥1
   - Detail close-ups — recommended ≥1
   Note: This is heuristic. Verify visually for high-stakes audits.
4. **Main image check.** First image in array should be white-background product-only. If
   filename contains "lifestyle" or you can detect non-white background → flag policy violation.

---

### 3.6 . Indexing Risk Check (NEW — critical)

Goal: Verify the ASIN will be returned by Amazon search for the keywords it should rank for.

**If user provided target keywords in Step 1.** For each keyword:
- Does it appear in title? In which position?
- Does it appear in bullet 1? In what context?
- Does it appear in any other bullet?
- Is it in the canonical brand-name part vs in the descriptive part?

**If user didn't provide keywords.** Derive 3 expected keywords from:
- Leaf category name
- Primary product type from title
- Top-frequency content words across bullets

Then check placement of those derived keywords.

**Output: Indexing Risk Score** (Low / Medium / High):
- **Low.** All target keywords appear in title (preferably in first 5 words) + at least 2 bullets
- **Medium.** Target keywords in title but not strategically placed; or in bullets only
- **High.** Target keywords missing from title AND bullets, or only in product description

This is the strongest predictor of organic ranking.

---

### 3.7 . A+ Content Depth (not just presence)

Beyond pillar 2 binary check:

| Check | Source |
|-------|--------|
| Basic A+ present | `plus_content` true OR `product_description` non-empty |
| Premium A+ present | `product_description` contains modules with ≥1464px images or video |
| Module count | Length of `product_description` array |
| Comparison chart | Look for entries matching "comparison" / "compare" pattern in module text |
| Brand Story present | `from_the_brand` non-empty |
| Video present | `video_count > 0` |
| Lifestyle imagery in A+ | Heuristic from module image URLs |

**Scoring:**
- Basic A+ only, <3 modules: weak A+
- Basic A+, 3-5 modules: adequate
- Premium A+ with comparison chart: strong
- Premium A+ with video: best-in-class

---

### 3.8 . Structured Attributes

From `product_details`, count distinct populated attributes (Brand, Weight, Dimensions, Flavor,
Country of Origin, Ingredients, Allergens, etc.).

- <3 attributes: sparse. CDQ Structured Attribute Quality (30% weight) likely suffering. Flag.
- 3–6: partial. Note opportunity.
- >6: reasonable. Note that Top-10 RAC list is category-specific and only visible in Amazon
  Catalog Admin Central.

**Bonus.** Check for HIGH-IMPACT category-specific attributes if you can detect category:
- Beauty: Skin Type, Hair Type, Scent
- Apparel: Size Chart, Material, Care Instructions
- Grocery: Allergens, Nutrition Facts, Diet Type
- Electronics: Compatibility, Power Source
- Pet: Pet Size, Age Range, Life Stage

---

## Step 4 . Write the report

Deliver as structured text in the conversation. Use this template:

```markdown
## Amazon Listing Quality Audit . Production Edition
Date: [today] | ASINs audited: [N] | Marketplace: amazon.com | Mode: Quick / Deep
```

**If >1 ASIN, open with Portfolio Summary:**

```markdown
## Portfolio Summary

IDQ Scores: [X] at 5/5 | [Y] at 4/5 | [Z] at <4/5
Critical violations: [count] across [N] ASINs
Systemic issues (3+ ASINs affected): [list]
Average mobile preview score: [X/10]
Average indexing risk: Low / Medium / High
Estimated revenue impact of fixing all CRITICAL findings: $[X]-$[Y]/month
```

**Then for each ASIN:**

```markdown
---
### [ASIN] — [Product Title truncated to ~60 chars]
**IDQ: X/5** | Indexing Risk: Low/Med/High | Mobile Score: X/10 | Status: In Stock / OOS

#### IDQ Pillars
✅ Leaf Node: [deepest category]
✅ A+ Content: [Basic / Premium / Brand Story present?]
⚠️ Bullet Points: 4 bullets (need ≥5)
✅ Images: 7
✅ Star Rating: 4.3★

#### Title ([N chars / max for category: M])
> [full title text]

📱 Mobile preview (first 80 chars):
> "[mobile title preview]"

Issues:
- [character limit / ALL CAPS word / prohibited term / promotional language]

First 5 words: "[first 5 words]" — primary keyword: [present/missing]

#### Bullet Points ([N bullets])
📱 Mobile bullet 1 (first 80 chars):
> "[bullet 1 mobile preview]"

Bullet length range: [min]–[max] chars (consistency: good/poor)
Feature/Benefit ratio: [X]% feature / [Y]% benefit (target: 30/70)

Issues:
- BP1: ALL CAPS header ("PREMIUM QUALITY: ...") — 🔴 critical policy violation
- BP4: Comparative claim ("unlike other producers") — 🔴 critical policy violation
- BP5: Cross-promotion ("VISIT THE BRAND STORE") — 🔴 critical policy violation
- BP2-3: Feature-heavy bullets (no buyer benefit) — 🟡 conversion impact
(or: "No issues found")

#### A+ Content
- Basic A+: ✅
- Premium A+: ❌
- Brand Story: ✅
- Video: ❌
- Module count: 4
- Comparison chart: ❌

#### Images
- Count: 7 ✅
- Main image resolution: 1500px ✅
- Type variety: 1 main + 2 lifestyle + 1 infographic + 3 detail ✅

#### Structured Attributes
- 5 populated ✅
- Missing high-impact: [Skin Type, Use Case]

#### Indexing Risk: Medium
Target keywords: "stainless water bottle", "insulated tumbler"
- "stainless water bottle" → in title (position 3) ✅
- "insulated tumbler" → in bullet 3 only — Medium risk
Recommendation: Add "insulated" to first 5 words of title.
```

**Close with Priority Fix List:**

```markdown
---
## Priority Fix List

### 🔴 Critical (do this week)
| Issue | Affected ASINs | Action | Est. Revenue Impact |
|-------|---------------|--------|----------------------|
| ALL CAPS bullet headers | All 5 | Rewrite headers in Title Case | -12-18% CTR if not fixed |
| Comparative claims in bullets | All 5 | Remove "unlike other..." language | Risk: listing suppression |
| Cross-promo in bullets | All 5 | Remove store visit calls | Risk: listing suppression |
| Main image <1000px | B0XXX | Replace with ≥1500px version | -7% conversion |

### 🟡 Important (next sprint)
| Issue | Affected ASINs | Action | Est. Revenue Impact |
|-------|---------------|--------|----------------------|
| Title >150 chars in Sports category | B0XXX, B0YYY | Shorten to 100-120 chars | Risk: title truncation |
| Missing A+ video | B0ZZZ | Add 30-60 sec video | +9% conversion |
| Feature-heavy bullets | B0AAA | Rewrite 3 bullets with benefits | +5% conversion |
| Missing high-impact attribute | B0BBB | Add Skin Type | Better category match |

### 🟢 Optimization (when bandwidth)
| Issue | Affected ASINs | Action | Est. Revenue Impact |
|-------|---------------|--------|----------------------|
| Fewer than 8 images | B0CCC | Add lifestyle / detail shots | +3-5% conversion |
| No comparison chart in A+ | B0DDD | Add 3-product comparison | +4% conversion |
| Mobile bullet 1 truncated | B0EEE | Front-load value in first 80 chars | Mobile UX |
```

**Final section:**

```markdown
---
## What This Audit Doesn't Cover
- Backend search terms: check Seller Central > Manage Inventory > Edit > Keywords tab
- Actual CDQ scores: requires Amazon Hawk tool (SAS membership)
- CVS errors / attribute validation: check Catalog Admin Central
- Image visual quality (clarity, lighting, professional polish): manual review
- Variation hygiene if parent ASIN: requires separate audit per child
```

---

## Step 5 . Offer follow-ups

After the report, offer:

1. **Rewritten copy** — "Want me to rewrite the titles or bullets for any of these ASINs?
   I can use the `amazon-listing-optimization` skill to generate compliant copy."
2. **Image plan** — "If image issues are critical, I can use the `amazon-listing-images` skill
   to generate a shot list for fixing them."
3. **A+ plan** — "Want a content plan for A+ modules? I can use `amazon-a-plus-content`."
4. **Deep dive on one ASIN** — "I can run a focused deep-dive on any single ASIN."
5. **Save as HTML report** — "Want the audit as a branded HTML file (AI Vault style) to share
   with your VA or client?"
6. **Schedule recurring** — "Want me to set up a monthly audit cron?"

---

## Edge cases

- **New ASIN, no reviews:** Star rating pillar = N/A. Note it, don't penalize.
- **OOS ASIN:** Audit content anyway. Quality issues exist regardless of stock.
- **Parent variation ASIN:** May have no own detail page. Note as parent and offer to audit children.
- **`features` empty but listing clearly has bullets:** Check `product_description` — Bright Data
  sometimes returns bullets there. Look there before scoring count = 0.
- **Scrape incomplete:** Note which fields were missing and what couldn't be assessed. Never guess.
- **Non-US marketplace:** Same framework but character limits and policy nuances vary
  (EU has stricter claims rules, JP has different character counts). Note marketplace in header.
- **Restricted categories** (Adult, Hazmat, Restricted Brand): Some checks don't apply or are
  more lenient. Note "restricted category — partial audit applied."
- **Branded vs unbranded:** If product has clear brand registry signals, apply stricter
  rules. If unbranded reseller listing, A+ Content section is N/A.

---

## Notes for the operator

This skill is built for production use. It:
- Always cites the field source for each finding (e.g., "from `features[2]`")
- Never fabricates data; flags incomplete data explicitly
- Provides revenue impact estimates based on industry benchmarks (note: estimates, not promises)
- Integrates with other AI Vault skills via follow-up offers
- Outputs are mobile-aware (the dominant Amazon shopping experience in 2026)

For the most impressive demo:
1. Use 3-5 real ASINs from a single brand (boilerplate detection shines)
2. Ask for "Deep mode"
3. Provide 2-3 target keywords for indexing risk
4. End with rewriting one critical bullet using the follow-up offer

For batch audits (10+ ASINs):
- Use Quick mode
- Skip image resolution checks (too slow)
- Focus on policy violations and IDQ scoring

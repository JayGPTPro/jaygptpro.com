# Day 6 Bonus Skills Pack

12 new skills to add to your Donna. Selected for the Day 6 live session.

## How to install

1. Unzip this folder anywhere on your Mac (e.g. inside your Donna project folder).
2. Copy the **.claude/skills/** folder into your Donna project root, alongside your existing .claude/ folder.
   - Tip: in Finder press `Cmd + Shift + .` to see hidden `.claude` folders.
3. Open Claude Code in your Donna folder. The new skills will be available immediately.

## What's included

| Command | Skill | What it does |
|---------|-------|--------------|
| `/tasks-from-emails` | create-tasks-from-emails | Turn emails automatically into tasks (Asana or your task list) |
| `/remind-me` | reminders-on-request | Set on-demand reminders. 'Remind me at 3pm to call Dan' |
| `/promises` | promise-tracking | Track promises you made. 'You said you'd get back to her by Thursday' |
| `/create-sop` | create-sop | Turn a recurring task into a ready-to-use SOP |
| `/remember` | business-memory | Long-term business memory. /remember and /recall key context anytime |
| `/subscriptions` | subscription-tracking | Find subscriptions you pay for and don't actually use. Saves real money |
| `/contracts` | contract-tracking | Track contracts and alert before expiry |
| `/patterns` | pattern-insights | Donna spots patterns. 'You always cancel meetings on Sundays' |
| `/invoices` | detect-invoices-receipts | Auto-detect invoices and receipts in your inbox and save them |
| `/stuck` | stuck-items-alert | Alert on tasks that have been stuck for too many days |
| `/cleanup-tasks` | clean-old-tasks | Cleanup old or no-longer-relevant tasks |
| `/quality-check` | gatekeeper | Quality check before sending or publishing any content |


## Test each skill before relying on it

Some skills work best after Donna has some context (people, goals, history).
Try each one once with `/help` to see what it expects.

## Questions?

Reply to the email I sent or DM me in the WhatsApp group.

. Jay

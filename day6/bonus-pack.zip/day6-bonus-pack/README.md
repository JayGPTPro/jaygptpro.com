# Day 6 Bonus Skills Pack

12 new skills to add to your Donna. Selected for the Day 6 live session.

## How to install

1. Unzip this folder anywhere on your Mac.
2. Copy the **.claude/skills/** folder into your Donna project root, alongside your existing .claude/ folder.
   - Tip: in Finder press `Cmd + Shift + .` to see hidden `.claude` folders.
3. Open Claude Code in your Donna folder. The new skills will be available immediately.

## What's inside

- **create-tasks-from-emails** . Turn emails automatically into tasks (Asana or your task list)
- **reminders-on-request** . Set on-demand reminders. 'Remind me at 3pm to call Dan'
- **promise-tracking** . Track promises you made. 'You said you'd get back to her by Thursday'
- **create-sop** . Turn a recurring task into a ready-to-use SOP
- **business-memory** . Long-term business memory. /remember and /recall key context anytime
- **subscription-tracking** . Find subscriptions you pay for and don't actually use. Saves real money
- **contract-tracking** . Track contracts and alert before expiry
- **pattern-insights** . Donna spots patterns. 'You always cancel meetings on Sundays'
- **detect-invoices-receipts** . Auto-detect invoices and receipts in your inbox and save them
- **stuck-items-alert** . Alert on tasks that have been stuck for too many days
- **clean-old-tasks** . Cleanup old or no-longer-relevant tasks
- **gatekeeper** . Quality check before sending or publishing any content


## Notes

These skills follow the same conventions as your starter kit:
- They use your `brain/` folder for storage (Decisions, Promises, Subscriptions, Contracts).
- They use the wiki link convention `[[Person]]` and reference Donna's voice from CLAUDE.md.
- They include the Self-Check + Donna Flavor rules you already use.

If a skill expects a tool you haven't connected yet (Asana, Drive, etc.), Donna will tell you and ask.

## Questions?

Reply to the email or DM in the WhatsApp group.

. Jay

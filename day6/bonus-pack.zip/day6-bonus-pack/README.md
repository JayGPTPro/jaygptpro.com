# Day 6 Bonus Skills Pack

12 new skills to add to your Donna. Selected for the Day 6 live session.

## How to install

1. Unzip this folder anywhere on your Mac.
2. Copy the **.claude/skills/** folder into your Donna project root, alongside your existing .claude/ folder.
   - Tip: in Finder press `Cmd + Shift + .` to see hidden `.claude` folders.
3. Open Claude Code in your Donna folder. The new skills will be available immediately.

## What's inside

| Command | What it does |
|---------|--------------|
| `/create-sop` | Turn any recurring task into a ready-to-use SOP |
| `/quality-check` | Quality control before you publish anything |
| `/remember` | Long-term business memory (use `/recall` to retrieve) |
| `/subscriptions` | Find subscriptions you pay for and don't use |
| `/contracts` | Track contracts and alert before expiry |
| `/patterns` | Behavioral patterns Donna spots in your data |
| `/invoices` | Auto-detect invoices and receipts in your inbox |
| `/promises` | Track promises you made to other people |
| `/remind-me` | On-demand reminders. "Remind me at 3pm to call Alex" |
| `/tasks-from-emails` | Turn an email into an actionable task |
| `/stuck` | Alert on tasks that haven't moved in 10+ days |
| `/cleanup-tasks` | Clean up old tasks (1+ month) |

## Notes

These skills follow the same conventions as your starter kit:
- They use your `brain/` folder for storage.
- They use the wiki link convention `[[Person]]` and reference Donna's voice from CLAUDE.md.
- They include the Self-Check + Donna Flavor rules you already use.

If a skill expects a tool you haven't connected yet (Asana, Drive, etc.), Donna will tell you and ask.

## Questions?

Reply to my email or DM in the WhatsApp group.

. Jay

---
name: pattern-insights
description: Donna spots patterns. 'You always cancel meetings on Sundays'
---

# Skill 46: Pattern Insights

**Command:** `/patterns` or automatic
**Category:** Personal Advisory & Insights
**Tech:** Calendar + Memory (Obsidian) + Scheduled Tasks
**Difficulty:** ⭐⭐⭐

---

## What You Do

Analyze Jay's behavior patterns over time. Surface insights he wouldn't notice himself.

### What to Look For

1. **Calendar patterns**: Which days have most meetings? When does he cancel?
2. **Task patterns**: What type of tasks get postponed most? When is he most productive?
3. **Email patterns**: Response time trends. Who gets fast replies vs. who waits?
4. **Decision patterns**: Does he make better decisions in the morning? Does he overcommit on Mondays?

### Steps

1. Analyze Calendar data (last 30 days)
2. Analyze Asana completion rates
3. Analyze Gmail response times
4. Cross-reference with Obsidian daily logs
5. Surface 2-3 actionable insights

### Output Format

```
PATTERN INSIGHTS — [Date]

Based on the last 30 days:

1. [INSIGHT]: [Description]
   Data: [What the data shows]
   Suggestion: [Actionable recommendation]

2. [INSIGHT]: [Description]
   Data: [What the data shows]
   Suggestion: [Actionable recommendation]

3. [INSIGHT]: [Description]
   Data: [What the data shows]
   Suggestion: [Actionable recommendation]
```

### Examples
- "You cancel 40% of meetings scheduled after 8pm. Consider not booking evening calls."
- "Tasks tagged 'content' get done 3x faster than tasks tagged 'admin'. Maybe delegate admin."
- "You're most responsive to emails on Tuesday mornings. That's your best inbox-clearing window."

### Safety
- Analysis only. No external actions.


## Self-Check (before delivering)

Before presenting this output, verify:
- [ ] Format matches the expected structure (headers, sections, bullet points)
- [ ] Numbers are accurate (counts, days overdue, amounts)
- [ ] No vague statements. Every claim has a specific number, name, or date.
- [ ] Output is concise and under the expected length
- [ ] [[Wiki links]] used for people, goals, decisions, promises
- [ ] At least one Donna personality line is included

If any check fails, fix it before showing the output.

## Donna Personality Reminder

This output MUST include at least one Donna-style line. Check the Donna Flavor section in CLAUDE.md. Open with personality or close with personality. Never deliver a dry report without Donna's voice.

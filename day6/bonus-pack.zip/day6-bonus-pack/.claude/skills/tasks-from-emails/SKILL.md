---
name: tasks-from-emails
description: Turn emails automatically into tasks (Asana or your task list)
---

# Skill 27: Create Tasks from Emails

**Command:** `/task-from-email [sender or subject]`
**Category:** Tasks & Execution Tracking
**Tech:** Gmail + Asana
**Difficulty:** ⭐⭐

---

## What You Do

Turn an email into an actionable task in your task manager (Asana, Todoist, Notion, etc.). Extract what needs to be done, set a deadline, assign it.

### Steps

1. Find the email (by sender, subject, or most recent)
2. Read the email and extract:
   - What action is needed
   - Who should do it (you or someone else)
   - Any deadline mentioned
3. Propose a task in your task manager

### Output Format

```
NEW TASK FROM EMAIL

Email: [Sender] — [Subject]
Action needed: [1-line summary]

Proposed task:
- Name: [Clear, actionable task name]
- Due: [Date, based on email context or default 3 days]
- Assignee: [you / other]
- Project: [Best fit project in Asana]
- Notes: [Key details from the email]

Create this task? (yes / edit / skip)
```

### Automatic Detection

During the email handling flow or `/morning-briefing`, if an email clearly requires an action that isn't tracked in Asana, suggest: "This looks like a task. Want me to create it?"

### Safety
- NEVER create tasks without your approval.
- Always show the proposed task first.

## Self-Check (before delivering)

Before presenting this output, verify:
- [ ] Format matches the expected structure (headers, sections, bullet points)
- [ ] Numbers are accurate (counts, days overdue, amounts)
- [ ] No vague statements. Every claim has a specific number, name, or date.
- [ ] Output is concise and under the expected length
- [ ] [[Wiki links]] used for people, goals, decisions, promises
- [ ] At least one Donna personality line is included

If any check fails, fix it before showing the output.

## Donna Personality Reminder

This output MUST include at least one Donna-style line. Check the Donna Flavor section in CLAUDE.md. Open with personality or close with personality. Never deliver a dry report without Donna's voice.

---
name: reminders-on-request
description: Set on-demand reminders. 'Remind me at 3pm to call Dan'
---

# Skill 17: Reminders on Request

**Command:** `/remind [what] [when]`
**Category:** Calendar, Meetings & Reminders
**Tech:** Scheduled Tasks
**Difficulty:** ⭐

---

## What You Do

Set a reminder for Jay. Simple. Reliable. No overthinking.

### Steps

1. Jay says: "Remind me to [X] at [time/date]" or "Remind me about [X] tomorrow"
2. Create a Scheduled Task that fires at the specified time
3. Confirm the reminder is set

### Examples

- "Remind me to call Kevin tomorrow at 3pm"
- "Remind me about the Stripe issue on Monday"
- "Remind me to send the email copy to Kevin by Saturday"

### Output Format

```
REMINDER SET ✓

What: [Description]
When: [Date] at [Time]

I'll ping you when it's time.
```

When the reminder fires:

```
REMINDER

[Description]

This was set on [date]. Want me to help with it now?
```

### Safety
- Reminders are internal only. No external actions.
- If the time is ambiguous ("tomorrow morning"), default to 9:00 AM and say so.

## Self-Check (before delivering)

Before presenting this output, verify:
- [ ] Format matches the expected structure (headers, sections, bullet points)
- [ ] Numbers are accurate (counts, days overdue, amounts)
- [ ] No vague statements. Every claim has a specific number, name, or date.
- [ ] Output is concise and under the expected length
- [ ] [[Wiki links]] used for people, goals, decisions, promises
- [ ] At least one Donna personality line is included

If any check fails, fix it before showing the output.

## Donna Personality Reminder

This output MUST include at least one Donna-style line. Check the Donna Flavor section in CLAUDE.md. Open with personality or close with personality. Never deliver a dry report without Donna's voice.

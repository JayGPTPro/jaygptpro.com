---
name: clean-old-tasks
description: Cleanup old or no-longer-relevant tasks
---


> **Setup note:** This skill assumes you have a knowledge folder (e.g. `brain/`) and may reference your task manager, calendar, or email. If something the skill expects is not connected yet, Donna will tell you and ask. You can adapt the storage path to wherever your CLAUDE.md says your knowledge folder lives.


# Skill 36: Clean Old Tasks (1+ Month)

**Command:** `/clean-tasks`
**Category:** Tasks & Execution Tracking
**Tech:** your task manager + Scheduled Tasks
**Difficulty:** ⭐

---

## What You Do

Find tasks that have been sitting open for over a month. Help you decide: do, delegate, or delete.

### Steps

1. Pull incomplete tasks from your task manager
2. Filter: created or last updated 30+ days ago
3. Sort by age
4. Present for triage

### Output Format

```
TASK CLEANUP — [Date]

[X] tasks older than 30 days:

1. [Task] — Created [Date] ([X] days ago)
   Project: [Project]
   Action? → Do today / Push to [date] / Delegate / Delete

2. [Task] — Created [Date] ([X] days ago)
   ...

---
Tell me what to do with each (e.g., "1: delete, 2: push to Friday, 3: delegate to [name]")
```

### Donna's Voice
"You have [X] tasks that are older than your last haircut. Let's clean house."

### Safety
- NEVER delete tasks without explicit approval.
- "Delete" means marking as complete with a note "Cancelled — cleanup [date]", NOT actual deletion.

## Self-Check (before delivering)

Before presenting this output, verify:
- [ ] Format matches the expected structure (headers, sections, bullet points)
- [ ] Numbers are specific. Counts, days, amounts are accurate.
- [ ] Every claim has a specific number, name, or date. No vague language.
- [ ] Output is concise.

If any check fails, fix it before showing the output.

## Voice

If your CLAUDE.md defines a voice or personality for Donna, use it. Open or close with one line that sounds like her, not a generic AI assistant. If you have no voice defined yet, just be warm, direct, and useful.

## Donna Personality Reminder

This output MUST include at least one Donna-style line. Check the Donna Flavor section in CLAUDE.md. Open with personality or close with personality. Never deliver a dry report without Donna's voice.

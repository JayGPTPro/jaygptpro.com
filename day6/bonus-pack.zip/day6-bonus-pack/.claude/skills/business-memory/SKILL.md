---
name: business-memory
description: Long-term business memory. /remember and /recall key context anytime
---


> **Setup note:** This skill assumes you have a knowledge folder (e.g. `brain/`) and may reference your task manager, calendar, or email. If something the skill expects is not connected yet, Donna will tell you and ask. You can adapt the storage path to wherever your CLAUDE.md says your knowledge folder lives.


# Skill 51: Business Memory

**Command:** `/remember [topic]` or `/recall [topic]`
**Category:** Personal Advisory & Insights
**Tech:** Memory (Obsidian) + CLAUDE.md
**Difficulty:** ⭐

---

## What You Do

Serve as your business memory. Store important facts, recall them when needed. "In January we decided X" answered instantly.

### How It Works

**Storing:**
- When something important happens, Donna saves it to Obsidian automatically
- you can also say: "Remember that [fact]" and it gets stored
- Categories: Decisions, People, Deals, Numbers, Strategy

**Recalling:**
- you asks: "What did we decide about [topic]?" or "When did we last talk to [person]?"
- Donna searches Obsidian and returns the answer with context

### Storage Locations

- brain/Decisions/ — Business decisions
- brain/People/ — Contact history and context
- brain/Business/ — Projects, deals, strategies
- brain/Daily Logs/ — Day-by-day history

### Output Format — Store

```
STORED ✓
Topic: [Topic]
Saved to: [Location in Obsidian]
```

### Output Format — Recall

```
RECALL: [Topic]

[Date]: [What happened / what was decided]
Context: [Why, who was involved, what led to it]
Related: [Any connected decisions or events]

Source: [Which Obsidian file this came from]
```

### Safety
- All internal (Obsidian). No external actions.
- This is one of Donna's most powerful features. It turns every conversation into permanent institutional knowledge.


## Self-Check (before delivering)

Before presenting this output, verify:
- [ ] Format matches the expected structure (headers, sections, bullet points)
- [ ] Numbers are specific. Counts, days, amounts are accurate.
- [ ] Every claim has a specific number, name, or date. No vague language.
- [ ] Output is concise.

If any check fails, fix it before showing the output.

## Voice

If your CLAUDE.md defines a voice or personality for Donna, use it. Open or close with one line that sounds like her, not a generic AI assistant. If you have no voice defined yet, just be warm, direct, and useful.

## Donna Personality Reminder

This output MUST include at least one Donna-style line. Check the Donna Flavor section in CLAUDE.md. Open with personality or close with personality. Never deliver a dry report without Donna's voice.

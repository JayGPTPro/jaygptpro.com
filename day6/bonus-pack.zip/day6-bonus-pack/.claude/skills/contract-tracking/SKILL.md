---
name: contract-tracking
description: Track contracts and alert before expiry
---


> **Setup note:** This skill assumes you have a knowledge folder (e.g. `brain/`) and may reference your task manager, calendar, or email. If something the skill expects is not connected yet, Donna will tell you and ask. You can adapt the storage path to wherever your CLAUDE.md says your knowledge folder lives.


# Skill 41: Contract Tracking (Alert Before Expiry)

**Command:** `/contracts`
**Category:** Information & Document Management
**Tech:** Memory (Obsidian) + Scheduled Tasks
**Difficulty:** ⭐

---

## What You Do

Track active contracts and their expiration dates. Alert you before anything expires or auto-renews.

### Storage

In Obsidian: brain/Business/Contracts.md

```
| Contract | With | Start | Expires | Auto-renew | Alert |
|----------|------|-------|---------|------------|-------|
| [Type] | [Party] | YYYY-MM | YYYY-MM | [Yes/No] | [X] days |
| [Type] | [Party] | YYYY-MM | YYYY-MM | [Yes/No] | [X] days |
```

### Steps

1. Check Contracts.md for upcoming expirations
2. Flag anything within its alert window
3. Include in morning briefing when relevant

### Output Format

```
CONTRACT TRACKER

⚠️ EXPIRING SOON:
- [Contract] with [Party] — expires [Date] ([X] days)
  Auto-renew: [Yes/No]
  Action needed: [Review/Renew/Cancel/Negotiate]

✅ ALL CLEAR: No contracts expiring in the next 60 days.
```

### Adding Contracts
When you mentions a contract ("signed a 6-month deal with X"), add it to Contracts.md automatically.

### Safety
- Tracking only. Never sign, cancel, or modify contracts.

## Self-Check (before delivering)

Before presenting this output, verify:
- [ ] Format matches the expected structure (headers, sections, bullet points)
- [ ] Numbers are specific. Counts, days, amounts are accurate.
- [ ] Every claim has a specific number, name, or date. No vague language.
- [ ] Output is concise.

If any check fails, fix it before showing the output.

## Voice

If your CLAUDE.md defines a voice or personality for Donna, use it. Open or close with one line that sounds like her, not a generic AI assistant. If you have no voice defined yet, just be warm, direct, and useful.

## Donna Personality Reminder

This output MUST include at least one Donna-style line. Check the Donna Flavor section in CLAUDE.md. Open with personality or close with personality. Never deliver a dry report without Donna's voice.

---
name: contracts
description: Track contracts and alert before expiry
---

# Skill 41: Contract Tracking (Alert Before Expiry)

**Command:** `/contracts`
**Category:** Information & Document Management
**Tech:** Memory (Obsidian) + Scheduled Tasks
**Difficulty:** ⭐

---

## What You Do

Track active contracts and their expiration dates. Alert you before anything expires or auto-renews.

### Storage

In Obsidian: brain/Business/Contracts.md

```
| Contract | With | Start | Expires | Auto-renew | Alert |
|----------|------|-------|---------|------------|-------|
| [Type] | [Party] | YYYY-MM | YYYY-MM | [Yes/No] | [X] days |
| [Type] | [Party] | YYYY-MM | YYYY-MM | [Yes/No] | [X] days |
```

### Steps

1. Check Contracts.md for upcoming expirations
2. Flag anything within its alert window
3. Include in morning briefing when relevant

### Output Format

```
CONTRACT TRACKER

⚠️ EXPIRING SOON:
- [Contract] with [Party] — expires [Date] ([X] days)
  Auto-renew: [Yes/No]
  Action needed: [Review/Renew/Cancel/Negotiate]

✅ ALL CLEAR: No contracts expiring in the next 60 days.
```

### Adding Contracts
When you mentions a contract ("signed a 6-month deal with X"), add it to Contracts.md automatically.

### Safety
- Tracking only. Never sign, cancel, or modify contracts.

## Self-Check (before delivering)

Before presenting this output, verify:
- [ ] Format matches the expected structure (headers, sections, bullet points)
- [ ] Numbers are accurate (counts, days overdue, amounts)
- [ ] No vague statements. Every claim has a specific number, name, or date.
- [ ] Output is concise and under the expected length
- [ ] [[Wiki links]] used for people, goals, decisions, promises
- [ ] At least one Donna personality line is included

If any check fails, fix it before showing the output.

## Donna Personality Reminder

This output MUST include at least one Donna-style line. Check the Donna Flavor section in CLAUDE.md. Open with personality or close with personality. Never deliver a dry report without Donna's voice.

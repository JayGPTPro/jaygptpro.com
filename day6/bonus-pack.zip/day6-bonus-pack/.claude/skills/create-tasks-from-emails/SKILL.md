---
name: create-tasks-from-emails
description: Turn emails automatically into tasks (your task manager (Asana / Todoist / Notion / etc.) or your task list)
---


> **Setup note:** This skill assumes you have a knowledge folder (e.g. `brain/`) and may reference your task manager, calendar, or email. If something the skill expects is not connected yet, Donna will tell you and ask. You can adapt the storage path to wherever your CLAUDE.md says your knowledge folder lives.


# Skill 27: Create Tasks from Emails

**Command:** `/task-from-email [sender or subject]`
**Category:** Tasks & Execution Tracking
**Tech:** Gmail + your task manager (Asana / Todoist / Notion / etc.)
**Difficulty:** ⭐⭐

---

## What You Do

Turn an email into an actionable your task manager (Asana / Todoist / Notion / etc.) task. Extract what needs to be done, set a deadline, assign it.

### Steps

1. Find the email (by sender, subject, or most recent)
2. Read the email and extract:
   - What action is needed
   - Who should do it (you or someone else)
   - Any deadline mentioned
3. Propose an your task manager (Asana / Todoist / Notion / etc.) task

### Output Format

```
NEW TASK FROM EMAIL

Email: [Sender] — [Subject]
Action needed: [1-line summary]

Proposed task:
- Name: [Clear, actionable task name]
- Due: [Date, based on email context or default 3 days]
- Assignee: [you / other]
- Project: [Best fit project in your task manager (Asana / Todoist / Notion / etc.)]
- Notes: [Key details from the email]

Create this task? (yes / edit / skip)
```

### Automatic Detection

During an email-handling skill if you have one or the morning briefing skill, if an email clearly requires an action that isn't tracked in your task manager (Asana / Todoist / Notion / etc.), suggest: "This looks like a task. Want me to create it?"

### Safety
- NEVER create tasks without your approval.
- Always show the proposed task first.

## Self-Check (before delivering)

Before presenting this output, verify:
- [ ] Format matches the expected structure (headers, sections, bullet points)
- [ ] Numbers are specific. Counts, days, amounts are accurate.
- [ ] Every claim has a specific number, name, or date. No vague language.
- [ ] Output is concise.

If any check fails, fix it before showing the output.

## Voice

If your CLAUDE.md defines a voice or personality for Donna, use it. Open or close with one line that sounds like her, not a generic AI assistant. If you have no voice defined yet, just be warm, direct, and useful.

## Donna Personality Reminder

This output MUST include at least one Donna-style line. Check the Donna Flavor section in CLAUDE.md. Open with personality or close with personality. Never deliver a dry report without Donna's voice.

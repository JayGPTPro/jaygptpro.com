---
name: detect-invoices-receipts
description: Auto-detect invoices and receipts in your inbox and save them
---


> **Setup note:** This skill assumes you have a knowledge folder (e.g. `brain/`) and may reference your task manager, calendar, or email. If something the skill expects is not connected yet, Donna will tell you and ask. You can adapt the storage path to wherever your CLAUDE.md says your knowledge folder lives.


# Skill 04: Detect Invoices & Receipts in Email

**Command:** `/find-invoices`
**Category:** Communication & Email
**Tech:** Gmail + Drive
**Difficulty:** ⭐⭐

---

## What You Do

Scan recent emails for invoices, receipts, and payment confirmations. List them with amounts and dates for bookkeeping.

### Steps

1. Search Gmail for keywords: invoice, receipt, payment, חשבונית, קבלה, billing, subscription
2. Also search for emails with PDF/image attachments from known payment sources (Stripe, PayPal, Mercury, etc.)
3. For each match, extract:
   - Sender / vendor name
   - Amount
   - Date
   - Invoice/receipt number if visible
   - Whether it has an attachment
4. Present organized list

### Output Format

```
INVOICES & RECEIPTS — [Date range]

Found [X] financial emails:

| # | Date | Vendor | Amount | Type | Attachment |
|---|------|--------|--------|------|------------|
| 1 | 03-24 | Anthropic | $10.00 | Receipt | No |
| 2 | 03-25 | Invoice Ninja | $14.00 | Payment | Yes (PDF) |

Total spend this period: $[X]

---
Want me to save these to Drive? (Specify folder)
```

### Safety
- Read only. Never download or move attachments without approval.
- Flag any suspicious or unexpected charges.

## Self-Check (before delivering)

Before presenting this output, verify:
- [ ] Format matches the expected structure (headers, sections, bullet points)
- [ ] Numbers are specific. Counts, days, amounts are accurate.
- [ ] Every claim has a specific number, name, or date. No vague language.
- [ ] Output is concise.

If any check fails, fix it before showing the output.

## Voice

If your CLAUDE.md defines a voice or personality for Donna, use it. Open or close with one line that sounds like her, not a generic AI assistant. If you have no voice defined yet, just be warm, direct, and useful.

## Donna Personality Reminder

This output MUST include at least one Donna-style line. Check the Donna Flavor section in CLAUDE.md. Open with personality or close with personality. Never deliver a dry report without Donna's voice.

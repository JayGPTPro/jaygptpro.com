---
name: invoices
description: Auto-detect invoices and receipts in your inbox and save them
---

# Skill 04: Detect Invoices & Receipts in Email

**Command:** `/find-invoices`
**Category:** Communication & Email
**Tech:** Gmail + Drive
**Difficulty:** ⭐⭐

---

## What You Do

Scan recent emails for invoices, receipts, and payment confirmations. List them with amounts and dates for bookkeeping.

### Steps

1. Search Gmail for keywords: invoice, receipt, payment, חשבונית, קבלה, billing, subscription
2. Also search for emails with PDF/image attachments from known payment sources (Stripe, PayPal, Mercury, etc.)
3. For each match, extract:
   - Sender / vendor name
   - Amount
   - Date
   - Invoice/receipt number if visible
   - Whether it has an attachment
4. Present organized list

### Output Format

```
INVOICES & RECEIPTS — [Date range]

Found [X] financial emails:

| # | Date | Vendor | Amount | Type | Attachment |
|---|------|--------|--------|------|------------|
| 1 | MM-DD | [Vendor A] | $X.XX | Receipt | No |
| 2 | MM-DD | [Vendor B] | $X.XX | Payment | Yes (PDF) |

Total spend this period: $[X]

---
Want me to save these to Drive? (Specify folder)
```

### Safety
- Read only. Never download or move attachments without approval.
- Flag any suspicious or unexpected charges.

## Self-Check (before delivering)

Before presenting this output, verify:
- [ ] Format matches the expected structure (headers, sections, bullet points)
- [ ] Numbers are accurate (counts, days overdue, amounts)
- [ ] No vague statements. Every claim has a specific number, name, or date.
- [ ] Output is concise and under the expected length
- [ ] [[Wiki links]] used for people, goals, decisions, promises
- [ ] At least one Donna personality line is included

If any check fails, fix it before showing the output.

## Donna Personality Reminder

This output MUST include at least one Donna-style line. Check the Donna Flavor section in CLAUDE.md. Open with personality or close with personality. Never deliver a dry report without Donna's voice.

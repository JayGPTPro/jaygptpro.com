---
name: promise-tracking
description: Track promises you made. 'You said you'd get back to her by Thursday'
---

# Skill 29: Promise Tracking

**Command:** `/promises` or automatic
**Category:** Tasks & Execution Tracking
**Tech:** Memory (Obsidian) + Scheduled Tasks
**Difficulty:** ⭐⭐

---

## What You Do

Track promises Jay makes in emails, meetings, or conversations. Hold him accountable.

### How Promises Are Captured

1. **From emails**: When Jay writes "I'll send you X by Friday" — log it
2. **From meetings**: When meeting summary includes action items for Jay
3. **From conversations**: When Jay says "remind me I promised [person] [thing]"

### Storage

In Obsidian: Donna Brain/Business/Promises.md

```
| Date | Promised to | What | Deadline | Status |
|------|-------------|------|----------|--------|
| 2026-03-27 | Kevin King | Email copy for April 1 send | 2026-03-30 | Open |
| 2026-03-25 | Mendi | Hebrew pricing details | 2026-03-31 | Open |
```

### Steps — Check

1. Read Promises.md
2. Flag any promises where the deadline is approaching or passed
3. Include in morning briefing

### Output Format

```
PROMISE TRACKER

🔴 OVERDUE:
- Promised [Person]: [What] — was due [Date] ([X] days ago)

🟡 DUE SOON (next 3 days):
- Promised [Person]: [What] — due [Date]

✅ Recently kept:
- [Person]: [What] — completed [Date]

Total open promises: [X]
```

### Donna's Voice
When a promise is overdue: "You told [person] you'd [thing] by [date]. That was [X] days ago. Want me to draft a message or extend the deadline?"

### Safety
- Tracking is internal (Obsidian). Safe.
- Sending messages about promises: requires approval.

## Self-Check (before delivering)

Before presenting this output, verify:
- [ ] Format matches the expected structure (headers, sections, bullet points)
- [ ] Numbers are accurate (counts, days overdue, amounts)
- [ ] No vague statements. Every claim has a specific number, name, or date.
- [ ] Output is concise and under the expected length
- [ ] [[Wiki links]] used for people, goals, decisions, promises
- [ ] At least one Donna personality line is included

If any check fails, fix it before showing the output.

## Donna Personality Reminder

This output MUST include at least one Donna-style line. Check the Donna Flavor section in CLAUDE.md. Open with personality or close with personality. Never deliver a dry report without Donna's voice.

---
name: create-sop
description: Turn a recurring task into a ready-to-use SOP
---

# Skill 35: Create SOPs for Tasks

**Command:** `/create-sop [task or process name]`
**Category:** Tasks & Execution Tracking
**Tech:** Skill + Drive
**Difficulty:** ⭐⭐

---

## What You Do

Create a standard operating procedure for a repeatable process. Document it so it can be delegated or automated.

### Steps

1. you describes the process (or Donna observed a pattern via the automatic behaviors in your CLAUDE.md)
2. Break it into clear, numbered steps
3. Include: tools needed, time estimate, common pitfalls
4. Present the completed SOP for you to copy/save manually to Drive (SOPs/ folder)
5. Log a short reference entry in Obsidian (brain/Business/) so Donna knows the SOP exists

### Output Format

```
SOP: [Process Name]

== OVERVIEW ==
What: [1-line description]
When: [Trigger . weekly, on request, when X happens]
Time: ~[X] minutes
Tools: [List of tools needed]

== STEPS ==
1. [Step 1 . clear, actionable]
2. [Step 2]
3. [Step 3]
...

== COMMON PITFALLS ==
- [Thing that can go wrong + how to avoid]

== NOTES ==
- [Any context or exceptions]

---
Copy this SOP and save it manually to Drive > SOPs/ folder.
```

### Safety
- Writing the SOP itself: internal, safe.
- Drive is read-only. you saves the file manually.
- Obsidian reference entry: automatic (internal memory).

## Self-Check (before delivering)

Before presenting this output, verify:
- [ ] Format matches the expected structure (headers, sections, bullet points)
- [ ] Numbers are accurate (counts, days overdue, amounts)
- [ ] No vague statements. Every claim has a specific number, name, or date.
- [ ] Output is concise and under the expected length
- [ ] [[Wiki links]] used for people, goals, decisions, promises
- [ ] At least one Donna personality line is included

If any check fails, fix it before showing the output.

## Donna Personality Reminder

This output MUST include at least one Donna-style line. Check the Donna Flavor section in CLAUDE.md. Open with personality or close with personality. Never deliver a dry report without Donna's voice.

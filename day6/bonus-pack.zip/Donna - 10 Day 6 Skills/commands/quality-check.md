---
name: quality-check
description: Quality check before sending or publishing any content
---

# Skill 55: Gatekeeper . Quality Control Before Publishing

## When to Use
Before publishing or sending any content: social posts, emails, proposals, newsletter, challenge content, landing pages.

Run manually with `/quality-check` or Donna runs it automatically before any publish action.

## How It Works

### Step 1: Gut Reaction (5 seconds)
Read the content once, fast. Answer honestly:
- Does this sound like you or like AI?
- Would you stop scrolling if you saw this?
- Is there ONE clear point?

If gut says "meh", flag it immediately. Don't proceed to checklist.

### Step 2: Voice Check
Compare against `brain/Preferences/Style.md` and `samples/`:
- [ ] Sounds like you (direct, practical, data-driven)
- [ ] No AI-isms ("I'd be happy to", "leverage", "synergy", "journey")
- [ ] No em dashes or en dashes (use periods or commas)
- [ ] Short sentences, active voice
- [ ] Leads with the point, not the setup
- [ ] Has real numbers or specifics (not vague adjectives)

### Step 3: Content Check
- [ ] One clear message (not trying to say 5 things)
- [ ] Hook in first line (for social posts)
- [ ] Clear CTA or takeaway at the end
- [ ] Right length for the platform
- [ ] No filler paragraphs
- [ ] Every sentence earns its place

### Step 4: Audience Check
- [ ] Written for the TARGET audience, not for "everyone"
- [ ] Value is obvious in 5 seconds
- [ ] Reader knows what to do next

## Verdict

Three possible outcomes:

### APPROVED
Content passes all checks. Ready to publish/send.
Say: "Good to go. [one-line summary of why it works]"

### SEND BACK
Content has specific issues. List exactly what to fix.
Say: "Almost. Fix these: [numbered list of specific changes]"
Then rewrite with the fixes applied and run the check again.

### ESCALATE
Content has fundamental problems (wrong audience, wrong message, off-brand).
Say: "Hold on. [explain the core issue]. Let's rethink this before polishing."

## The Loop
After every quality check, update `brain/Learning/learning-log.md`:
- What kind of content was it?
- What issues came up?
- Was the final version better? Why?
- Any new pattern to add to voice-dna.md?

## Standing Rules
- Never approve content just because you asked quickly. Quality over speed.
- If gut says no but checklist says yes, trust the gut. Flag it.
- Better to send back once than publish something mediocre.
- Track which types of content need the most revision. That's a signal.


## Self-Check (before delivering)

Before presenting this output, verify:
- [ ] Format matches the expected structure (headers, sections, bullet points)
- [ ] Numbers are accurate (counts, days overdue, amounts)
- [ ] No vague statements. Every claim has a specific number, name, or date.
- [ ] Output is concise and under the expected length
- [ ] [[Wiki links]] used for people, goals, decisions, promises
- [ ] At least one Donna personality line is included

If any check fails, fix it before showing the output.

## Donna Personality Reminder

This output MUST include at least one Donna-style line. Check the Donna Flavor section in CLAUDE.md. Open with personality or close with personality. Never deliver a dry report without Donna's voice.

---
name: subscriptions
description: Find subscriptions you pay for and don't actually use. Saves real money
---

# Skill 42: Subscription Tracking

**Command:** `/subscriptions`
**Category:** Information & Document Management
**Tech:** Memory (Obsidian) + Scheduled Tasks
**Difficulty:** ⭐

---

## What You Do

Track all active subscriptions and recurring payments. Know exactly where money goes each month.

### Storage

In Obsidian: brain/Business/Subscriptions.md

```
| Service | Cost | Frequency | Next Payment | Category | Notes |
|---------|------|-----------|--------------|----------|-------|
| [Service A] | $X | Monthly | YYYY-MM-DD | [Category] | [Notes] |
| [Service B] | $X | Monthly | YYYY-MM-DD | [Category] | [Notes] |
| [Service C] | $X | Monthly | YYYY-MM-DD | [Category] | [Notes] |
| [Service D] | $X | Monthly | YYYY-MM-DD | [Category] | [Notes] |
```

### Steps . View

1. Read Subscriptions.md
2. Calculate total monthly spend
3. Flag any upcoming renewals in the next 7 days

### Steps . Detect New

1. Scan Gmail for recurring payment emails
2. Compare against known subscriptions
3. Flag any new/unknown recurring charges

### Output Format

```
SUBSCRIPTION TRACKER

Active subscriptions: [X]
Monthly total: $[Sum]

UPCOMING (next 7 days):
- [Service] . $[Amount] . renews [Date]

RECENTLY CHARGED:
- [Service] . $[Amount] . charged [Date]

⚠️ NEW/UNKNOWN:
- [Charge] . $[Amount] . not in your subscription list. Want to add or investigate?

---
Total annual spend: ~$[Sum x 12]
```

### Safety
- Read and track only. Never cancel subscriptions.


## Self-Check (before delivering)

Before presenting this output, verify:
- [ ] Format matches the expected structure (headers, sections, bullet points)
- [ ] Numbers are accurate (counts, days overdue, amounts)
- [ ] No vague statements. Every claim has a specific number, name, or date.
- [ ] Output is concise and under the expected length
- [ ] [[Wiki links]] used for people, goals, decisions, promises
- [ ] At least one Donna personality line is included

If any check fails, fix it before showing the output.

## Donna Personality Reminder

This output MUST include at least one Donna-style line. Check the Donna Flavor section in CLAUDE.md. Open with personality or close with personality. Never deliver a dry report without Donna's voice.

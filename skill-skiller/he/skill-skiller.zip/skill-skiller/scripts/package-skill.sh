#!/usr/bin/env bash
# package-skill.sh - אורז סקיל שנבנה לקובץ zip לשיתוף (Mac/Linux)
# שימוש: ./package-skill.sh <skill-name>
# מניח שהסקיל כבר מותקן ב-~/.claude/skills/<skill-name>/
set -euo pipefail

SKILL_NAME="${1:-}"
if [ -z "$SKILL_NAME" ]; then
  echo "שגיאה: חסר שם סקיל. שימוש: ./package-skill.sh <skill-name>"
  exit 1
fi

SKILLS_DIR="$HOME/.claude/skills"
SRC="$SKILLS_DIR/$SKILL_NAME"
if [ ! -d "$SRC" ]; then
  echo "שגיאה: הסקיל '$SKILL_NAME' לא נמצא ב-$SRC"
  exit 1
fi

# תיקיית יעד לחבילות שיתוף, על שולחן העבודה
OUT_DIR="$HOME/Desktop/skill-skiller-packages"
mkdir -p "$OUT_DIR"
ZIP_PATH="$OUT_DIR/$SKILL_NAME.zip"

# ארוז את תיקיית הסקיל (כולל install-README ו-install-prompt שהוזרקו אליה)
rm -f "$ZIP_PATH"
( cd "$SKILLS_DIR" && zip -r -q "$ZIP_PATH" "$SKILL_NAME" -x "*.DS_Store" )

echo "✅ נוצר: $ZIP_PATH"
echo "$ZIP_PATH"

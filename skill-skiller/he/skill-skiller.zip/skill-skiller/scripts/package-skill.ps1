# package-skill.ps1 - אורז סקיל שנבנה לקובץ zip לשיתוף (Windows)
# שימוש: powershell -ExecutionPolicy Bypass -File package-skill.ps1 <skill-name>
# מניח שהסקיל כבר מותקן ב-%USERPROFILE%\.claude\skills\<skill-name>\
param(
    [Parameter(Mandatory=$true)]
    [string]$SkillName
)

$ErrorActionPreference = "Stop"

$SkillsDir = Join-Path $env:USERPROFILE ".claude\skills"
$Src = Join-Path $SkillsDir $SkillName
if (-not (Test-Path $Src)) {
    Write-Error "שגיאה: הסקיל '$SkillName' לא נמצא ב-$Src"
    exit 1
}

$OutDir = Join-Path ([Environment]::GetFolderPath("Desktop")) "skill-skiller-packages"
New-Item -ItemType Directory -Force -Path $OutDir | Out-Null
$ZipPath = Join-Path $OutDir "$SkillName.zip"

if (Test-Path $ZipPath) { Remove-Item $ZipPath -Force }
Compress-Archive -Path $Src -DestinationPath $ZipPath -Force

Write-Host "✅ נוצר: $ZipPath"
Write-Output $ZipPath

# skill-skiller - מפעל הסקילים 🔨

סקיל ל-Claude Code שבונה סקילים אחרים. ראיון חכם → בנייה אוטומטית → בדיקת eval אמיתית.
השם והקומנד באנגלית, הראיון והתוכן בעברית.

## שימוש
```
/skill-skiller                                ← ראיון מלא (3 + 2-3 שאלות)
/skill-skiller סקיל שמסכם תמלולי פגישות        ← בנייה מהירה מרעיון גולמי
/skill-skiller automate competitor analysis    ← עובד גם עם רעיון באנגלית
```

## מה הופך אותו למפלצת
- **ראיון לפי-תחום** - שאלות חכמות שונות לשיווק / פיננסים / משפטי / קוד...
- **שער מיקוד יחיד** - חוסם סקיל שמנסה לעשות 20 דברים, מצמצם למשימה אחת חדה
- **Eval דו-שכבתי** - מודד אם הסקיל *נדלק* (trigger-rate + train/test split) וגם אם הוא *עובד נכון* (הרצה אמיתית מול pass criteria)
- **זיהוי התנגשויות** - בודק שה-description החדש לא מתנגש עם הסקילים המותקנים אצלך
- **חוזה דיוק 4-חלקים** - מונע הזיות: מה יודע / לא יודע / מתי לשאול / מתי לסרב
- **Dry-run** - מראה לך הכל לפני שכותב לדיסק
- **חוצה-OS** - מזהה Mac/Windows ומתאים נתיבים לבד
- **אריזה לשיתוף** - מתקין גלובלית + יוצר zip עם הוראות התקנה לשיתוף עם אחרים

## מבנה
| קובץ | תפקיד |
|---|---|
| `SKILL.md` | אורקסטרטור ראשי (6 שלבים) |
| `reference/interview-questions.md` | בנק שאלות לפי-תחום |
| `reference/skill-blueprints.md` | 5 ארכיטקטורות + מטריצת החלטה |
| `reference/quality-manifesto.md` | 10 חוקי המפלצת + שער מיקוד |
| `reference/eval-engine.md` | מנוע ה-eval הדו-שכבתי |
| `reference/hallucination-contract.md` | חוזה מניעת הזיות |
| `scripts/package-skill.{sh,ps1}` | אריזת zip חוצה-OS |
| `templates/` | README + פרומפט התקנה לכל חבילה |
| `evals/` | 3 בדיקות איכות לסקיל עצמו |

## DNA
שילוב של: creating-skills (Mendi Koritz) · skill-creator הרשמי (Anthropic) · Custom GPT Architect (Jay).

---
נבנה ל-jaygptpro.

# תבניות ארכיטקטורה לסקילים

השתמש בקובץ הזה כשאתה מחליט על הארכיטקטורה של הסקיל שנבנה.
התאם את התבנית למקרה השימוש - אל תהנדס יתר על המידה, אל תבנה חסר.

> נתיבים בקובץ הזה כתובים בסגנון Mac (`~/.claude/...`). ב-Windows המקבילה היא
> `%USERPROFILE%\.claude\...`. הסקיל מזהה OS ומתאים לבד - ראה SKILL.md שלב 0.

---

## Blueprint 1: סקיל יחיד פשוט
**מתי**: משימה אחת ברורה, אין נתונים חיים, ידע תחומי מינימלי.
**דוגמאות**: "דרפט מייל מכירות", "סכם תמלול פגישה", "פרמט נתונים".

```
~/.claude/skills/[name]/
└── SKILL.md
```

**אותות frontmatter**: `allowed-tools` מינימלי (Read, Write לכל היותר) · `model: sonnet` · ללא reference.

**מבנה גוף**:
```markdown
# [הכרזת תפקיד]
## קלט
- $arg1: [מה זה אומר]
## שלבים
1. [שלב קונקרטי]
2. [שלב קונקרטי]
## פלט
[פורמט + דוגמה]
## כללים
- [כלל]
```

---

## Blueprint 2: סקיל + קבצי Reference
**מתי**: ידע תחומי עשיר (כללי מותג, חוקים עסקיים, ידע סכמה, חוקי ציות) שינפח את SKILL.md.
**דוגמאות**: "ניתוח מתחרים לפי המסגרות שלנו", "תוכן לפי קול המותג", "ניתוח BigQuery עם הסכמה שלנו".

```
~/.claude/skills/[name]/
├── SKILL.md              ← אורקסטרציה + התחלה מהירה
└── reference/
    ├── [domain]-knowledge.md
    └── [examples].md
```

**קישור ב-SKILL.md**:
```markdown
## ידע תחומי
קרא את `reference/[domain]-knowledge.md` לפני שאתה מתחיל.
```

**אותות frontmatter**: `allowed-tools`: Read + כלים ספציפיים · `model: sonnet`.

---

## Blueprint 3: סקיל + הזרקת קונטקסט דינמית
**מתי**: הסקיל צריך נתונים חיים בזמן ריצה - מצב git, פלט API, שאילתת DB, רשימת קבצים, מדדים נוכחיים.
**דוגמאות**: "נתח את git diff הנוכחי", "דוח בוקר מ-CRM חי", "בדוק את ה-pipeline".

```
~/.claude/skills/[name]/
├── SKILL.md
├── scripts/
│   └── fetch-data.py    ← נקרא דרך !`command`
└── reference/
    └── [knowledge].md
```

**תחביר הזרקה דינמית** (בגוף SKILL.md):
```markdown
## מצב נוכחי
- Git status: !`git status --short`
- תוצאות טסטים: !`npm test --silent 2>&1 | tail -10`
```

**אותות frontmatter**: `allowed-tools`: Bash + כלי המשימה.
> ב-Windows השתמש ב-PowerShell במקום פקודות bash (`Get-ChildItem` במקום `ls` וכו').

---

## Blueprint 4: סקיל + תת-סוכנים (Subagents)
**מתי**: למשימה יש אחריות נפרדות באמת שנהנות מ: ערכות כלים שונות, בידוד קונטקסט לכל אחריות, פוטנציאל לעבודה במקביל, מודלים שונים (Haiku זול למשימות פשוטות, Opus רק כשצריך).
**דוגמאות**: "מחקר שוק → תכנון → ביצוע → סקירה", "code review: אבטחה + ביצועים + טסטים - שלושה תת-סוכנים".

```
~/.claude/skills/[name]/
├── SKILL.md              ← אורקסטרטור (מאציל, לא מבצע)
└── reference/[knowledge].md

~/.claude/agents/
├── [name]-researcher.md
├── [name]-executor.md
└── [name]-reviewer.md
```

**תבנית קובץ תת-סוכן**:
```markdown
---
name: [name]-[role]
description: [תפקיד ספציפי - מתי הסקיל הראשי מאציל בדיוק את המשימה הזו]
tools: [רק מה שהסוכן הזה צריך]
model: [haiku לפשוט, sonnet למורכב, opus רק לחשיבה עמוקה]
---
## תפקיד
אתה [תפקיד ספציפי]. כשמופעל, אתה [אחריות ספציפית].
## קלט
אתה מקבל: [פורמט מדויק]
## פלט
החזר JSON:
{ "status": "completed|failed|needs_review", "output": "[תוצאה]", "confidence": "high|medium|low", "warnings": [] }
## גבולות
- עשה רק: [המשימה שלך]
- לעולם אל: [מה לא לעשות]
```

**כללי תקשורת רב-סוכנית**:
- עיקרון הכותב-היחיד: כל סוכן כותב רק לנתיב שלו
- לעולם לא שני סוכנים כותבים לאותו קובץ
- כל הנתונים בין-סוכנים כ-JSON מובנה
- הסוקר לעולם לא מתקן - רק מדווח

---

## Blueprint 5: Full Stack - ראיון + מחקר + יצירה
**מתי**: workflow עסקי מורכב שצריך מחקר ברשת + יצירת קבצים + חשיבה רב-שלבית. דפוס "המפלצת".
**דוגמאות**: "דוח מודיעין תחרותי מלא", "בנה תוכנית עסקית", "עצב והרץ קמפיין שיווקי".

```
~/.claude/skills/[name]/
├── SKILL.md
├── reference/ (framework.md, output-templates.md)
├── scripts/[helpers].py
└── evals/ (eval-01..03)

~/.claude/agents/ ([name]-planner.md, [name]-researcher.md, [name]-synthesizer.md)
```

**אותות frontmatter**: `allowed-tools`: WebSearch, WebFetch, Write, Read, Bash, AskUserQuestion · `model: opus`.

---

## מטריצת החלטת ארכיטקטורה

| אות | Blueprint |
|---|---|
| פשוט, אין נתונים חיים, ידע מינימלי | 1 - יחיד |
| ידע תחומי עשיר / חוקים / סכמה | 2 - Reference |
| צריך נתונים חיים בזמן ריצה | 3 - הזרקה דינמית |
| כלים / אחריות נפרדות | 4 - Subagents |
| מורכב, רשת + קבצים + רב-שלבי | 5 - Full Stack |

---

## Frontmatter - אסמכתה מהירה

```yaml
# תמיד כלול:
name: [gerund-name]
description: |            # עם ביטויי טריגר
allowed-tools: [רשימה מדויקת]
model: sonnet             # ברירת מחדל

# כלול כשצריך:
disable-model-invocation: true   # תופעות לוואי
argument-hint: [רמז]      # השלמה אוטומטית
```

> שדות לא-סטנדרטיים (למשל `effort`, `context`, `agent`) - אל תכלול אלא אם אימתת
> שהם נתמכים בגרסת Claude Code של המשתמש. עדיף frontmatter מינימלי ותקני.

## טבלת כלים מורשים

| כלי | למה |
|---|---|
| Read | קריאת כל קובץ |
| Write | יצירת קבצים חדשים |
| Edit | שינוי קבצים קיימים |
| Bash | פקודות shell, סקריפטים, git |
| Glob | מציאת קבצים לפי תבנית |
| Grep | חיפוש בתוכן קבצים |
| WebSearch | חיפוש חי ברשת |
| WebFetch | שליפת דפי אינטרנט |
| AskUserQuestion | שאלות רב-ברירה מובנות |
| Agent | הפעלת תת-סוכנים |

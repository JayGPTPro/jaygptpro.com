# הגדרות אישיות של smart-precompact

זה המקום היחיד שממנו הסקיל קורא הגדרות אישיות.
אפשר להשאיר הכל ריק: הסקיל עובד במלואו, חוץ מ-`save notes`.

## תיקיית פתקים (בשביל `save notes`)

נתיב מלא לתיקיית הפתקים שלך (Obsidian או כל תיקיית Markdown אחרת).

notes_vault:

## שמות תת-התיקיות בתוך תיקיית הפתקים

אם אצלך התיקיות נקראות אחרת, שנה כאן. תיקייה שלא קיימת בדיסק פשוט לא מקבלת כתיבה.

daily_logs: Daily Logs
decisions: Decisions
people: People
business: Business
preferences: Preferences

---
name: listing-autopilot
description: The whole production line in one run, with three stops, for an owner who has finished the bootcamp and wants the next product done fast. Registers the product, researches it, writes and sends the brief, builds and locks the reference, runs the main-image dual blast, the gallery, the A+ page, the inspection and the routine fixes, the Tasting Room, the post-tasting fixes, the variations and the upload pack, and the Improvement Log, calling the kit's own rooms in the kit's own order. The owner is asked three creative questions: the lock and the recipe, the picks, the verdict. Four other things can halt a run, all listed in the money contract: the cap, a missing ZIP, a listing title that is not the product the owner named, and a blocked fetch of the live gallery. Two stops when the owner says so. One cost cap, checked before every paid action. Use when the owner says autopilot, "run the whole line", "do the next product end to end", "I don't want to go room by room", or hands an ASIN plus photos and asks for the package. Triggers: /listing-autopilot, "do the whole thing", "make me a new listing", "autopilot B0...", "run the factory on this product", "full package on autopilot", "next product, fast".
---

# Listing Autopilot

| Meta | Value |
|------|-------|
| Skill | Listing Autopilot. Part of the bonus pack, not the kit |
| Needs | A live ASIN, the owner's ZIP of real product photos (the one input that cannot be skipped), a Genrupt MCP connection with credits, an OpenAI key, and `listing-autopilot.json` in the factory root (created once, three questions) |
| Saves to | Everything the rooms save, where they save it (`factory/Products/[product]/...`), plus `autopilot/run-state.json` and `autopilot/report.md` |
| Writes | Only through the rooms, under their own rules. This skill writes nothing into a product folder itself except `autopilot/` |
| Typical cost | The line's own costs, read live: the market analysis, the reference sheet, the smoke test, the Draft Blast, the OpenAI pool, the Theme Blast and Refine rounds, the A+ concepts, the routine fixes, the Tasting sitting. Estimated from the rooms' own figures, not yet measured on a full run: about $25 to $35 across both machines. TWO caps, never converted into each other: `cap_credits` (Genrupt) and `cap_usd` (OpenAI), both set in `listing-autopilot.json` when the file is first written and both passed to `init`, which refuses to start without them. The run stops before crossing either |
| Engine | `.claude/pack/autopilot_state.py` (the run record and the gate); the kit's rooms do the work |

## What this does

The bootcamp teaches the line one room a day, because learning needs the pauses. The second
product does not. A graduate who knows what every room decides can hand Wonka the ASIN and the
photos and come back to a tested package, having answered three questions on the way: is this my
product and is this the recipe; which of these do we race; what do we do with what the tasters
said. Everything else is Wonka's call, made by the rooms' own rules, logged with its reason, and
shown in the report.

**Three rules hold the promise together.** Every stage is a kit room, invoked as written; this
skill adds no generation of its own. Every question a room would ask the owner is either answered
by the config, by the invocation, by a stop, or by Wonka on the record. And the run record
(`autopilot_state.py`) decides what runs next, so a stop cannot be skipped and a stage cannot
run twice.

What it is not. Not a shortcut past the rooms' gates: the lock still needs a smoke test, the
tasters still vote, the routine-fix policy still caps the edits. Not a pre-launch tool in this
version: a product with no live ASIN is refused in one line and sent to the bootcamp's own
pre-launch route. And not silent about money: every paid action prints its quoted cost as it
happens.

## The config, once per factory

`listing-autopilot.json` in the factory root. On the first run it does not exist, so Wonka asks
ONE message with three questions, in the owner's language, and writes the answers:

1. **TWO caps per run, because the line runs on two machines that bill in different units**:
   `cap_credits` for Genrupt and `cap_usd` for the OpenAI key, both written into
   `listing-autopilot.json` on the first run (suggest 400 and $15 unless the owner says otherwise)
   and both passed explicitly to `autopilot_state.py init`, which has no defaults of its own and
   refuses to start without them. They are never converted into each other, because the balance tool reports no dollar rate for
   an organisation account.
2. **The main-image tactics**, the five from the brief room in plain words: a hang tag on the
   product (and its text, 28 characters and 5 words at most), a person interacting with it, the
   real retail packaging in frame, Genrupt's choice, the plain control. The kit never enables a
   tactic the owner has not answered for, so the answer lives here and every run reads it.
   Default when the owner shrugs: open brief and Genrupt's choice, the two baseline rows.
3. **The A+ machine settings**: mode (desktop, mobile, both; default both), concepts (default
   2), modules (default 7), and whether the owner adds a module of their own (default no).

Plus two the owner rarely changes: `stops` (3, or 2), `tasting_cap_usd` (10, the room's own).

When a quote comes back different from what you sent, believe the quote.

## Before you start

| Input | Missing |
|---|---|
| A live ASIN | STOP in one line: this version runs on live listings; a pre-launch product takes the bootcamp's own route (`/meet-my-product` with the anchor). Nothing is created |
| The ZIP of real photos | THE one true stop, before anything is spent: the Reference Room reads the disk, and a product locked from Amazon's pictures is a lock on a guess. Ask for the ZIP and wait. Everything else in the ZIP (reviews, notes, exports) is welcome and optional |
| Genrupt MCP + OpenAI key | Run `/machines-check` first, once. A machine that is down closes the run before it opens |
| The day gate | Never blocks this skill. If `status.md` shows a product mid-bootcamp, one line, then continue |
| An unfinished run on this product | Resume it (below). A fresh start needs the owner to say so |

## After every call, read the state back

After every call that changes state on a machine, read the state back and compare it, field by
field, with what you sent. Seven times on the first live runs a call returned success and saved
something else. The evidence is in `references/measured.md`. Four of those read-backs are rules
you apply every run:

- Before the first spend, `get_current_account_context`, and pass `--account` to `spend` so the
  record says whose credits moved.
- Before using any market-analysis id, `find_market_analyses` on THIS account. An id from a report
  may live on another organisation and looks valid until it is used.
- After the sheet is approved, `replace` it into the bucket and read the bucket back before the
  Draft Blast: the blast is priced on what the bucket holds (124 credits with seven listing photos
  attached, 31 with the sheet alone).
- On every A+ and blast call, pass `listingReferenceMode: "none"` and read back
  `listingImageReferencesAdded` = 0, or the tool imports the Amazon photos over the locked reference.

## The money contract

Every command below runs from the factory root, and `[p]` is the product FOLDER,
`factory/Products/[slug]`, never the bare slug. `autopilot_state.py` keeps its record in
`[p]/autopilot/run-state.json` and reads the brief from `[p]/brief/creative-brief.md`.

- Two caps, in two units, set once in `listing-autopilot.json` and passed on init:
  `python3 .claude/pack/autopilot_state.py init [p] --asin B0XXXXXXXX --cap-credits 400 --cap-usd 15`
- Before every paid Genrupt action, read the live balance (`get_credit_balance_and_costs`), then:
  `python3 .claude/pack/autopilot_state.py headroom [p] --worst [the most it can cost] --unit credits --balance [live balance]`
- Before every paid OpenAI action:
  `python3 .claude/pack/autopilot_state.py headroom [p] --worst [the most it can cost] --unit usd`
- A NO from headroom stops the run. Say what was about to be spent, what is left, and wait. The
  script never reads `listing-autopilot.json` itself; every value is passed on the command line.
- After every paid action, log the machine's own quote (`finalCreditsCost`, `costPreview`, the engine's
  receipt), never a balance subtraction:
  `python3 .claude/pack/autopilot_state.py spend [p] [amount] --unit credits|usd --what "[room], [action]"`
  A spend that crosses the cap is recorded and then REFUSES; nothing runs until the owner raises it
  with `unblock [p] cap --to [new cap]`.
- Three other halts, each one line and a wait: no ZIP of real photos; a fetched title that is not the
  product the owner named; a blocked fetch of the live gallery before the Tasting Room.
- The Tasting Room's own $10 sitting cap is not a halt: race the top three mains by `/inspect`'s
  ranking and never ask.
- The routine-fix limits in the kit's CLAUDE.md stand: 12 paid edits, $3, two attempts per defect, low
  quality. A crossed limit is written to the report as an open defect, never spent past.

## The three stops

Each stop is one message with everything the owner needs to answer it, delivered as FILES they
can open, never as descriptions. The run record opens the stop (`stop [name]`), Wonka says it and
waits, and the owner's reply closes it (`answer [name] --text "..."`). Nothing runs past an open
stop; `next` refuses.

**Stop 1, the lock and the recipe** (after the reference sheet is built, before the smoke test.
**Or EARLIER, the moment research raises a conflict about what the product IS.** Measured on the
first live run, 16.9.2026: the owner's own photographs disagreed with his listing about the
product's lid colour, and a sheet built on that would have locked a guess into every frame after
it. When research finds a conflict of identity, `block reference --why "[the conflict]"`, open stop
1 carrying that question with the disagreeing files attached, and build the sheet after the answer.
A gate that can only open after the work it should have prevented is not a gate.).
The owner sees: the reference sheet image(s) at full size, the one-page brief review
(`brief/owner-review.md`), and the product report's top lines. They answer two things in one
reply: `Approve all` on the sheet, or the corrections (which panel, what is wrong); and `the
brief is approved`, or their edits. A correction re-runs the sheet (the room's own correction
step), an edit is saved over the plan (the brief room's own save), and the stop re-opens with the
new files. This is the stop that cannot be automated: a wrong lock poisons every frame after it.

**Stop 2, the picks** (after the mains, the gallery and the A+ concepts exist and `/inspect`
has run on all of them). The owner sees: the numbered pick folder for the mains with Wonka's
proposed primary and alternatives and the reason for each, the gallery per slot with the
proposed frame and its alternatives, the A+ concepts with the proposed one, and the smoke-test
frames from the lock. They reply with confirmations or swaps by number. **In a two-stop run this
stop is delegated**: Wonka picks by `/inspect`'s execution ranking and the brief's selection
criteria, records it (`delegate picks --text`), and the picks are shown at stop 3 beside the
verdict, so the owner still sees them, after the tasters did.

**Stop 3, the verdict and the decision** (after both Tasting races). The owner sees: both
Tasting Cards, the proposals the tasters' notes produced (the room lists them and stops, as it
always does), the picks (in a two-stop run), and three questions folded into one message: which
of the proposals to run (or none), whether there are product variations to make images for
(ASINs, links or written changes, or `skip`), and whether to upscale the primary, with the
upscale's live quote. Their reply is the `Owner decision:` line the kit records and the variations answer. The stop-3
message asks for the word `package` on its own line; a reply that carries it invokes the Shipping
Room, and a reply without it ends the run after variations with a `Next stage:` row, never a pack.

## The run, stage by stage

Every stage is a kit room. Read the room's `.claude/skills/[room]/SKILL.md` and run it as written; the notes here say
only what this skill pre-answers, so the room never waits on a question the owner already
answered. Mark each stage `done` in the run record as it completes, with a one-line note.

1. **`research`. `/meet-my-product`, all three phases.** The invocation is the Phase A approval:
   it names the product (the ASIN), the marketplace (from the listing), the niche (Wonka's proposal,
   logged; a title that does not read as the product class the owner named is the room's own STOP
   and stays one) and the research spend (the market analysis, quoted live, `headroom` first).
   Phase B's interview runs against the ZIP: every gap is recorded as "not supplied" with what it
   costs the analysis, and no question goes to the owner. Phase C runs in full.
2. **`brief-written`, then `brief-sent`. `/creative-brief`, written AND sent.** Two stages in the
   run record: `done [p] brief-written` once the file exists, `done [p] brief-sent --evidence [projectId]`
   once Genrupt returned a project. The room sends only after the owner approves.
   Here the send comes first, for one reason stated in the report: a saved plan is a free,
   reversible draft, and the reference sheet (next) needs the project it lives in. Nothing
   generates before stop 1, where the owner approves the brief or edits it, and an edit is saved
   over the plan by the room's own step. The tactics and the tag text come from the config.
   **The brief carries the kit's `## Set structure` table** (`| Slot | Job | Message |`, one
   row per S-slot) beside the `### S1 . job` blocks, because the gallery's parity audit
   (`plan_parity.py`) walks brief to plan from that table and nothing else. `done brief-written`
   refuses a brief without it.
3. **`reference`. `/reference-sheet` up to the delivered sheet.** The sheet costs a credit or two
   before the brief is approved; the invocation pre-authorises that one spend, and it is logged like
   any other. **Before building it, read the research's conflicts.** A disagreement about the
   product's own identity (a colour, a count, a part) blocks this stage: `block reference --why`,
   and stop 1 opens early carrying it. Sources from the ZIP, the
   anatomy table, the sheets the product needs, inspected panel by panel by Wonka, corrected
   precisely, then STOP: the room's own "approve on the owner's word" is stop 1.
4. **`STOP:lock`.** Stop 1, as above.
5. **`smoke`. The smoke test**, one image per slot, read twice by Wonka (is this my product, is
   this the brief). A source problem is fixed and only the changed slot re-run, per the room.
   The pass line is Wonka's, logged; the frames are shown at stop 2. The reference is LOCKED.
6. **`main`. `/main-image`, the dual blast.** The Draft Blast (quoted, `headroom`) and the OpenAI
   pool (low). The shortlist is Wonka's: the six strongest by the brief's selection criteria,
   copied to the pick folder by number, then `/inspect` on `shortlist`. The Day 5 close (one
   primary) is proposed here and confirmed at stop 2.
7. **`gallery`. `/secondary-images`.** Parity audit and fact preflight first (free), the Theme
   Blast (quoted), the style anchor chosen by Wonka from the rows and logged, Refine rounds per
   slot to three candidates, Wonka's per-slot picks read back from the machine and brought home.
8. **`aplus`. `/aplus`.** The three intake questions from the config, the concepts generated,
   Wonka's proposed concept logged; exported at the pick after stop 2.
9. **`inspect`. `/inspect` on `secondary` and `aplus`** (the shortlist was inspected in stage 6),
   routine fixes on the report under the policy. Everything the owner will see at stop 2 has been
   through the gate first.
10. **`STOP:picks`.** Stop 2, or the delegation.
11. **`tasting`. `/tasting-room`, both races.** `incumbent/` is filled first by the run:
    `scrape_video_reference_images_from_asin` for the URLs, then
    `python3 .claude/pack/refresh_fetch.py snapshot [ASIN] --out [p]/incumbent --urls [the URLs]`
    (never the bare fetch first; a blocked retry can get the owner's IP banned), and the frames
    copied in with the kit's names (`main-live.png`, `live-01.png`, `live-02.png`, ...); a blocked
    fetch is the one preflight question here (the live images, or the anchor competitor to race
    instead). The selection is the picks. The sitting estimate is checked against the room's cap.
    The room lists the proposals and stops, as it always does.
12. **`STOP:verdict`.** Stop 3.
13. **`fixes`. `/fix` MODE B** on the changes the owner named, then `/inspect` on what changed.
    Nothing when the owner named none.
14. **`variations`. `/variations`** on the owner's answer, or the skip recorded in the kit's words.
15. **`package`. `/ready-to-upload`**, only when the owner's stop-3 reply said `package`, with the upscale if
    they said yes, the disclosure tag on their call (the room asks it; in this run the answer
    comes from whether any packaged frame carries an AI person, and is logged).
16. **`log`. `/improvement-loop`**, the natural close. Then `report`.

## Resume

Every completed stage and every paid action is in `autopilot/run-state.json` as it happens. On
invocation with that file present and not `delivered`: say in one line where the run stands
(`next` prints it) and continue there. Never re-run research, re-send a brief, rebuild a sheet or
re-blast a slot the record shows done; verify the artifact exists on disk (or in the machine) and
move on. A missing artifact is the only reason to pay again, and it gets its own spend line.

## What this skill never does

- Opens a room out of the line's order, or a room whose gate the record says is not passed.
- Answers a stop for the owner. A stop closes on the owner's words or on a recorded delegation
  in a two-stop run, and only the picks stop may be delegated.
- Spends past the cap, or reports spend from a balance delta.
- Uploads anything to Amazon. The pack is delivered; the upload is the owner's.
- Runs on a product that is mid-bootcamp without saying so, or on a pre-launch product at all.

## Output

`autopilot/report.md` (from `report`): the stages with their notes, the three stops with the
files shown and the owner's answers, every spend line with its quote, and every decision Wonka
made with its reason. The package itself is where `/ready-to-upload` puts it.

## Definition of done

- The run record's status reads `delivered` (its own word; `status.md` says `done`), every stage marked in order, every stop answered or (picks only, two-stop) delegated.
- Every paid action has a spend line with its quoted number AND its unit; both totals are inside their caps, or the run stopped and said so.
- Every room's own Definition of Done was met; this skill added no artifact of its own beyond `autopilot/`.
- The owner was shown files at every stop, never descriptions.
- `status.md` carries the row.

## Update status.md

```
| Autopilot | done | autopilot/report.md | [date] | [n] stops, [c] of [cap] credits and $[x] of $[cap], package in final/ |
```

## Wonka lines

- Opening: "You know what every room decides. So I will decide, and I will show my work. Three questions, and a package at the end."
- At stop 1: "Before a single frame is made: is this your product, and is this the recipe? Look at the files, not at me."
- At a cap stop: "The next machine wants more than the purse holds. I stop here; you decide the purse."
- Closing: "Delivered. The report says what I chose and why, and the tasters said the rest."

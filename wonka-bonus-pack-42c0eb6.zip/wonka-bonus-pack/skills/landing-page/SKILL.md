---
name: landing-page
description: Build a premium, brand-specific landing page for the product on the line, designed FROM the creative package the factory made. Inside the factory the facts come from the research, the real review quotes from reviews.md, the images from the shipped gallery and the lifestyle pack, and the design direction from the approved frames themselves, so the page and the listing are one brand. Outside the factory it reads a live Amazon listing through Chrome instead. Writes one self-contained HTML file with a gallery, real reviews, FAQ, email capture and a sticky mobile buy bar. Use when the owner says landing page, product page, a page for ads, a page for the brand, or gives an Amazon URL or ASIN. Triggers: /landing-page, "I need a website", "a page to send traffic to", "build a landing page", "product page from my images", "a page for my ads", "landing page for [product]".
argument-hint: "[product slug, or an Amazon URL / ASIN outside the factory]"
user-invocable: true
---

# landing-page

| Meta | Value |
|------|-------|
| Skill | landing-page. A PORT into the bonus pack, with a factory intake the public version does not have |
| Needs | Inside the factory: a product on the line, read by `.claude/pack/product.py`. The facts come from `status.md`, `brief/creative-brief.md`, `research/selling-points.md`, and verbatim review quotes from `research/reviews.md` or `1-inputs/reviews.txt`; the pictures from the shipped gallery and the lifestyle pack. Outside the factory: an Amazon URL or ASIN **and Chrome MCP**, which is not optional there |
| Saves to | `factory/Products/[product]/landing-page/`: `index.html`, `index-v1.html` (the pre-elevation draft) and `images/` |
| Writes | ONLY inside that folder. Never touches `images/`, `edits/`, `final/` or the listing itself |
| Typical cost | Free. This skill generates no images and calls no paid model; it arranges what the factory already paid for |
| Engine | None. One self-contained HTML file, Tailwind via CDN, no build step |


> **Part of the bonus pack, not the kit.** Two doors into this skill. Inside a Wonka factory
> with a product on the line, Phase 0 below replaces Phases 1 to 3: nothing is scraped, the
> factory already holds better material than the listing shows. Outside the factory, skip Phase
> 0 and run Phases 1 to 8 as written on the Amazon URL.

## Phase 0: Factory intake (inside the factory only)

1. `python3 .claude/pack/product.py [product]` (from the factory root) and read the JSON. The product folder is the
   source of every fact on the page:
   - **Title, brand, ASIN, URL** from `status.md`'s field table. **Price** from `1-inputs/listing-live.md`
     (the listing the research room fetched; `product.py` prints it as `price` with its source), else
     Chrome reads the live page for that one number and the rating, nothing else; with neither, the
     page shows no price and the buy button reads "See it on Amazon".
   - **The promise and the features** from `brief/creative-brief.md` (the strategy summary and
     the slot jobs) and `research/selling-points.md`. Never from the Amazon bullets: the brief
     already rewrote them into the argument the images make.
   - **Reviews**: verbatim quotes only, four to six, with their star and source lines. They come
     from `research/reviews.md` when that file holds real quotes, and from `1-inputs/reviews.txt`
     when it holds only themes. **If neither has verbatim quotes, the page ships with NO review
     section** and you say so in one line, so the missing section reads as a decision. A review
     no file holds is never on the page.
   - **The images**: the shipped main (`main`) is the hero; the shipped gallery (`gallery`)
     fills features and the filmstrip; `lifestyle/` frames, when the pack exists, give the
     full-bleed photo section and the bento tiles their scenes (they carry no text, which is
     exactly what a page background needs). Copy the files into `landing-page/images/`, never
     link into the factory folders.
   - **The FAQ** from `research/insights.md` and `reviews.md` (the objections and the questions
     shoppers actually asked), answered from the brief's approved claims only.
2. **The design comes from the creative, not from the playbook's defaults.** Before writing
   `DESIGN.md`, OPEN the shipped main and two gallery frames and pull the palette from THEM:
   the product's own colour, the scene tone the frames chose, the type feel the headlines on
   the frames use (serif or grotesque, heavy or light). The direction (Pantry, Atelier,
   Expedition...) is chosen to match the world the brief built; the signature device is built
   from the feature the brief made the hero of the gallery. Write in `DESIGN.md` which frame
   each token came from. This is what makes the page and the listing one brand.
3. The project folder is `factory/Products/[product]/landing-page/` with `images/` inside.
   Then continue at Phase 4. Phase 7's "nothing invented" check reads: every number, claim and
   review traces to a factory file, named in a comment at the top of `index.html`.
4. `status.md` gets a row: `| Landing page | done | landing-page/index.html | [date] | direction [x], [n] reviews, palette from [frames] |`


## What this does

Builds one self-contained HTML page for the product on your line, designed FROM the creative the
factory already made: the facts from the research and the brief, the real review quotes from what
you collected, the images from the shipped gallery and the lifestyle pack, and the palette pulled
from your own approved frames. The page and the listing come out as one brand. Outside the
factory it reads a live Amazon listing through Chrome instead.

What it is not. Not a template with your product dropped in, not a funnel, and not a copywriter:
every fact on the page traces to a file, and a section with no real data is left out.

## Before you start

| Input | Missing |
|---|---|
| A product on the line | Outside a factory, an Amazon URL or ASIN, and Chrome MCP, which is not optional there |
| Real review quotes | `research/reviews.md` holds themes, not quotes. Verbatim quotes come from `1-inputs/reviews.txt`. Without them the review section is left out and you say so |
| A shipped gallery, and the lifestyle pack if it exists | The page is built from the pictures the factory made; more scenes make a better page but are not required |

## The standard

You are building a premium landing page for the product named in the invocation: a product on
the line inside the factory, or an Amazon URL or ASIN outside it (a bare ASIN becomes
`https://www.amazon.com/dp/<ASIN>`).

The bar is not "a clean template with the product dropped in". The bar is a page the brand
could have commissioned from a good agency: a design direction chosen for THIS product, a
distinctive type pairing, a palette pulled from the product itself, one signature visual
device, and copy that sounds like a person. Read `.claude/skills/landing-page/references/design-playbook.md` before
you write a line of HTML. It holds the patterns that made the best pages good.

Building it in one pass is not how the good ones happen. Phase 5 gets a correct page.
**Phase 6 is where it becomes worth shipping, and it is not optional.**

**Reference build: the speaker page in the design playbook.** That is the standard.
Its first draft was clean and forgettable. The elevation pass gave it a hero that arrives
in eight staggered beats, a signature light ring built from the product's own RGB feature
and reused at three sizes, grain and mesh under the colour, a bento feature grid, a
filmstrip gallery, and a near black section for the light show. Same data, same product,
same reviews. If your finished page would not sit next to that one, you stopped at Phase 5.

## Requirements

- **Outside the factory, Chrome MCP is required** to read the listing. Test it first; if it is
  not available, stop and say so. Inside the factory it is optional (a live price refresh only).
- One HTML file with Tailwind via CDN (no build step) plus an `images/` folder.
- **Every fact traces to a source file.** Inside the factory that is the research, the brief and
  the reviews the owner collected; outside it, the real Amazon page. Never invent a review, a
  number, a badge or a spec. Inside the factory the listing's own bullets are NOT a source: the
  factory's research supersedes them.
- **Real review quotes need a real source.** The kit's `research/reviews.md` holds themes, not
  quotes. Quotes come from `1-inputs/reviews.txt` when the owner collected it. If neither has
  verbatim quotes, LEAVE THE REVIEW SECTION OUT and tell the owner why in one line, so the
  missing section reads as a decision rather than a bug.
- No em dashes and no en dashes anywhere in the copy. Periods and commas.

## Process

## Two doors

**Inside the factory:** run Phase 0, then go straight to Phase 4. Phases 1 to 3 do not run: the
folder is `factory/Products/[product]/landing-page/`, the images are already in `images/`, and
every fact came from the factory files. Phase 0 step 2 IS the `DESIGN.md` write; Phase 4 only
checks it has all six lines.

**Outside the factory:** skip Phase 0 and run Phases 1 to 8 in order.

### Phase 1: Setup (outside the factory only)

Create `amazon-landing-page-[short-product-name]/` in the current directory (lowercase, hyphens,
the product not the ASIN) with `images/` inside.

### Phase 2: Get the product data (outside the factory only)

Read the live listing through Chrome MCP and save every fact to `product-data.json` before
building. Selectors and traps are in `.claude/skills/landing-page/references/amazon-extract.md`.
Follow it; do not improvise selectors.

### Phase 3: Download images (outside the factory only)

`curl -sL "[image-url]" -o images/product-1.jpg`, named in gallery order. A file under 10 KB is a
blocked download: drop it, never retry.

### Phase 4: Design direction (write it down before building)

Open the images in `images/` with the Read tool. Look at the product, its packaging, the
lifestyle shots, and the brand's own colors. Inside the factory `DESIGN.md` already exists from
Phase 0: check it has all six lines below and do not rewrite it. Outside the factory, write a
six-line brief into
`DESIGN.md` in the project folder:

1. **Audience and mood** in one sentence. Who buys this and how the page should feel.
2. **Direction**, one of the archetypes in the playbook (Expedition, Atelier, Playground,
   Lab, Pantry, Boutique, Workshop) or a named blend. Say why it fits this product.
3. **Type pairing**: display font + body font + mono for labels. Pick from the playbook
   table for the direction. Inter on its own is never the answer.
4. **Palette**: 5 tokens with hex codes, all pulled from the product images or packaging:
   `brand` (the product's own color), `accent` (contrast for CTAs), `ink`, `paper`, and
   one `tint`. Name them after the product ("trail", "hydro") so the code reads well.
5. **Signature device**: exactly one from the playbook (topographic contours, spec marquee,
   spotlight hero, floating spec chips, outlined numerals, bento feature grid, editorial
   pull-quote, product-color section bands). One. Two is a costume party.
6. **Headline**: three words to six, the promise not the product name. Write three
   options and choose one.

This brief is the contract for Phase 5. It is what stops every page from looking like the
previous one.

### Phase 5 and 6: Build, then elevate

Two passes, both mandatory, both specified in `.claude/skills/landing-page/references/build-recipe.md`. Read it before you
write HTML.

- **Phase 5** produces a correct page: the section order, the gallery, the real reviews, the
  FAQ, the email capture, the sticky mobile buy bar. Save it as `index-v1.html` when it is done.
  That file is the proof the elevation pass actually ran.
- **Phase 6** is where it becomes worth shipping: the signature device, the motion, the depth,
  the section rhythm. A page that looks like `index-v1.html` at the end means Phase 6 did not
  happen.

### Phase 7: QA before you show it

1. Open `index.html` in the browser (Chrome MCP or `open index.html`).
2. Take a full-page screenshot and LOOK at it. Then check, in this order:
   - Every image loaded (no broken icons, no 9-byte files).
   - No text overflows its box at desktop and at 390px width.
   - The headline is the promise, not the Amazon title.
   - Nothing on the page is invented: every number, badge and review traces to a named source file (Phase 0 inside the factory, Phase 2 outside it).
   - No em or en dash anywhere. The check, with the two characters written as their
     unicode escapes so no search-and-replace can eat it:
     `python3 -c "import re,sys;print(len(re.findall(chr(8212)+chr(124)+chr(8211), open(sys.argv[1]).read())))" index.html`
     must print 0.
   - The reveal classes do not hide content when JS runs late (scroll to the bottom, all
     sections visible).
   - No infographic is cropped by a bleed or a negative margin; every callout at its edges
     is readable. Full-bleed photos show no baked-in text panel.
   - The page does not look like the last page you built. If it does, the direction in
     DESIGN.md was not followed; fix the page, not the brief.
   - Phase 6 actually happened. `index-v1.html` exists and the two files differ by more
     than colours.
3. Fix what you found. Do not report "done" with a known defect.

**Judge animation only in a visible window.** A hidden or backgrounded browser pane freezes
`requestAnimationFrame` and every CSS animation, so all your reveal and entrance elements
measure at `opacity:0` and the page looks catastrophically broken when nothing is wrong.
Before you believe that reading, check `document.visibilityState`. If it says `hidden`,
front the tab and measure again rather than "fixing" working code.

### Phase 8: Hand over

Tell the user, in four lines: the design direction you chose and why, what the page
contains (sections, number of real reviews used), the two things they must do before
publishing (put their attribution link on the buy buttons, paste the Google Form URL and
field id for email capture), and the path. Then open the page.

## Definition of done

- Every fact on the page traces to a factory file or the real Amazon page, and the trace is named
  in a comment at the top of `index.html`. Nothing was invented: not a review, a rating, a count,
  a badge or a spec.
- The design direction was written down FIRST and followed to the end. One direction per page.
- `index-v1.html` exists and differs from `index.html` by more than cosmetics. The elevation pass
  is part of the job, and that file is the proof it ran.
- The page was OPENED in a browser and read at phone width as well as desktop.
- The dash check above prints 0 (`chr(8212)` is the em dash, `chr(8211)` the en dash).
- The headline is a rewritten promise, never the Amazon title.
- The owner was told, in four lines, the direction and why, what the page contains, the two things
  they must do before publishing (their attribution link on the buy buttons, the Google Form URL
  and field id for email capture), and the path.
- `status.md` carries the row.

## Important rules

- NEVER fabricate reviews, ratings, counts, badges or specs. If a section has no real data,
  leave it out and say so.
- The headline is a rewritten promise, never the Amazon title.
- One design direction per page, written down first, followed to the end.
- No Inter-only typography, no purple-gradient-on-white, no generic dark theme by default.
- FAQ answers come from the listing, phrased plainly. Unknown is "check the listing", not
  a guess.
- The page should look like the brand made it, not like a template with a logo swapped.
- Never hand over the Phase 5 draft. The elevation pass in Phase 6 is part of the job, not
  an upsell, and `index-v1.html` is the proof it ran.

## Reference map

| File | Owns |
|---|---|
| `references/design-playbook.md` | The patterns behind the pages that came out best: directions, type pairings, palettes, signature devices |
| `references/build-recipe.md` | Phase 5 and Phase 6 in full: the section spec, the elevation recipes, the CSS |
| `references/amazon-extract.md` | Reading a live listing through Chrome (outside the factory only) |

## Update status.md

```
| Landing page | done | landing-page/index.html | [date] | direction [x], [n] reviews, palette from [frames] |
```

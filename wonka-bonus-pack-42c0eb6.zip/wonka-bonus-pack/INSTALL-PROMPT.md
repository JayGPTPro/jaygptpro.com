# The install prompt

One message the graduate pastes into their own Wonka. No download, no unzip, no terminal,
no hunting for a folder path. Wonka is already standing inside the factory, so he knows
where everything goes.

**It names no version.** `https://jaygptpro.com/wonka-bonus.txt` names whichever pack is
current, the way `kit-latest.txt` does for the kit, so a prompt sent in October still
installs what is current in March.

---

## The prompt (this is what goes in the email)

Tell them first: **start a session in Claude Code, connect their Wonka folder**, then paste
this.

```
Install my Wonka bonus pack into this factory. https://jaygptpro.com/wonka-bonus.txt names the current zip and its sha256: download it, check the digest, and run the install.sh inside it from my factory root.
```

That is the whole thing. Two sentences.

---

## Why it is shaped this way

- **Nothing executable is downloaded and run blind.** The zip is data. The only script that
  runs is `install.sh`, which arrives inside the verified zip and whose behaviour is pinned
  by 17 tests, including both Windows routes and every refusal path.
- **The digest is checked before anything is written.** A truncated download, a wrong file
  or a tampered one stops the install instead of half-installing it.
- **The manifest carries the detail, not the prompt.** `wonka-bonus.txt` opens with six
  comment lines explaining what it is and what to do with it, so an agent that fetches it
  has the context the prompt no longer has to spell out.
- **install.sh does the careful part**: it refuses a folder that is not a factory, refuses a
  same-named skill it does not own, writes its `.pack` marker before copying so a half-copy
  is still recognised, works without rsync, never deletes a file the student added, and
  prints the "start a new session" line itself.

## What this does NOT do, on purpose

- **It does not gate eligibility.** Anyone holding the prompt can install. The gate is the
  list Jay sends it to. The short URL trades a little obscurity for a link a person can
  read out loud; if the pack ever needs a real gate, a code belongs in the manifest, and
  `gate.py` in the kit is the model for checking one.
- **It does not auto-update.** A graduate who wants a newer pack pastes the same prompt
  again, which is safe: `install.sh` refreshes in place and keeps their files.

## Both manifests

| URL | For |
|---|---|
| `https://jaygptpro.com/wonka-bonus.txt` | the prompt, the email, the page. The one people see |
| `https://jaygptpro.com/wonka-bootcamp/kit-pages-e7c41b/bonus-latest.txt` | the original path, kept so anything already pointing at it keeps working |

`build-pack.sh` writes both from the same values, so they cannot drift.

## Testing it

```
cd advanced-pack && bash test_install.sh      # 17 checks on install.sh
curl -s https://jaygptpro.com/wonka-bonus.txt
```

And the whole path end to end: read the manifest, download the named zip, verify the digest,
unzip, install into a fake factory, count the skills.

# Day 10: Your Next Product Starts Here

The last day. Three lessons: the final package and what to check before uploading, saving what this
run taught Wonka, and how to keep using him from here, on the next product, the next brand, and the
work beyond Amazon.

**The sentence for the day: by the end you know where your files are, what still needs your
attention, and how to come back to Wonka with the next assignment.**

## What you will have by the end of today

- Your complete package in `final/`, with a copy in `output/`, and a handoff document that names the
  exact files to upload and everything still pending
- Every enlarged file checked against the file you approved
- Your Improvement Log written, with every lesson labelled at the strength the evidence carries
- Your working preferences saved, so you stop repeating them
- Three copyable sentences for more products and more brands, and a clear idea of what belongs in
  a separate employee

**Time needed:** 40 to 60 minutes, plus whatever your own open items need.

## What you will need at hand

- Your Day 8 decision recorded, and Day 9 done or skipped in writing
- Twenty honest minutes for the log, including the parts that went badly

---

## Lesson 1: Your final image package

### Look at the work

Take a look at what you have made. You started with a product to understand. You researched it,
built the brief, created the main image, the gallery, the A+ and the variations. Then you tested your
choices and worked through the corrections. Today brings that work together.

### Ask Wonka to prepare the delivery

When you have selected your images and finished the corrections you want, run this in your Wonka
project:

```
/ready-to-upload
```

This command opens the Shipping Room, and it runs when YOU ask for it: nothing packages off an
approval you gave on an earlier day. The Shipping Room gathers the selected versions of each asset,
checks the export sizes, and prepares the files with instructions for using them. You do not have to remember which revision is in which folder;
that is part of the handoff. Open it and you should see your main image, the gallery in order, the
A+ modules and any variation sets you created.

If something still needs a decision or a correction, it is named clearly. You can finish a session
with work still pending; the handoff makes it visible.

**What Wonka does:** resolves the source you actually chose for each class of asset, including a
revision you approved after the test; reads every file's real pixel size; runs the one owed
enlargement, on the files that ship, at a cost read live from your account and inside the budget you
agreed; assembles `final/`, copies it to `output/`, and checks the copy file by file.

**What you check:** that the main is the one you decided on, that the gallery order is the one you
want, and that every open item in the handoff is one you recognise.

### Check the actual export

Some files may need enlarging. Here is one reason to look at the output afterwards. In our run, the
enlargement changed some tiny lettering that had been correct in the source. Wonka caught it by
reading the enlarged file against the source and restored the affected region.

So when your exports are ready, look at the actual files. Pay attention to text, logos and product
details. You want a larger version of the image you approved, with those details intact. Wonka does
this read for every enlarged file and records the outcome in the handoff; your eyes are the second
check, on the files that matter most to you.

Our main, gallery and variation exports are 2,048 pixels. A+ keeps its own module dimensions. Your
delivery uses the sizes required for the placements you are preparing.

### Know what to upload

Start with the upload instructions in the handoff. They tell you which main to use, the gallery
order, and which files belong to each product, by filename. Follow that list.

The project also contains earlier images, alternatives and reports, so selecting everything would mix
the delivery with its history. The enlarged files are the upload; the smaller files beside them are
the record of what was tested.

For variations, check that the image and its claims match that particular product. And do not assume
the original product's A+ applies to every variation. It needs its own review.

A packaged folder is a packaged folder. It does not verify a product claim, and it does not make a
listing compliant. Anything the handoff lists as assumed or unreviewed is yours to resolve before
publishing.

### Amazon's AI-person disclosure

Before uploading, there is one Amazon requirement to know. Listing and A+ images with photorealistic
AI-generated people need a tag in the file's metadata. Amazon uses it for a disclosure where
applicable. The tag is a keyword in the file's XMP metadata, nothing visible on the image, and
nothing in Seller Central substitutes for it.

Have Wonka handle the applicable final files and verify the tag. Which files it applies to is your
call, against Amazon's current instructions; Wonka lists the files that show a person, points you at
the official text, tags the final files you name, verifies the tag, and refreshes the copies.

```
Check Amazon’s current AI-person disclosure instructions. Add the required metadata to the applicable final upload files and verify it. Tell me if any files still need attention.
```

Official instructions (checked 15 September 2026; read the current version before deciding which
files it covers):
https://sellercentral.amazon.com/seller-forums/discussions/t/aa0aee06-aff4-497a-a4b6-9b2ebe06f715

### The handoff

Our demonstration product belongs to another seller, so nothing was uploaded and no Amazon
experiment was started. For your own listing, review the selected files, the product claims and the
requirements for each placement before uploading. The Tasting Room helped you choose a direction;
real customer results are something to bring back afterwards.

Your task here: open your package and make sure you know which files to use and what is still
pending. You do not have to publish today.

---

## Lesson 2: What Wonka takes into the next project

### Save what should carry forward

Before you leave a project, think about what you would want Wonka to do differently next time.
Maybe you corrected a product detail. Maybe a customer test challenged your favourite image. Maybe
you found a better way to work together.

```
run /improvement-loop
```

That is the command. You do not need to write a recap of the project yourself. Wonka reviews the
record, then shows you what it proposes to carry forward.

### Two kinds of lesson

One is about your creative choices. What did people respond to? What confused them? Which idea might
be worth testing again?

The other is about the working process. What did Wonka miss, and what check would help catch it
earlier? After the lettering problem, for example, we saved the practice of checking printed text
against the source after enlargement. That is something specific the next job can use.

The evidence behind a creative lesson matters too. Our AI-panel results were labelled Lean. They gave
us ideas to explore, not proof of what customers will buy, and Wonka writes them that way: as
hypotheses to test, never as rules. If you later have real customer feedback or an experiment result,
bring it back with its context. Wonka revisits the earlier hypothesis instead of treating the first
answer as permanent.

### Read the lesson before keeping it

Read what gets saved. In our run I asked Wonka to soften a few conclusions because they were too
broad for the evidence we had. You can say the same:

- "Keep this as a hypothesis to test."
- "That was a problem in this image; don’t turn it into a rule for every product."

The goal is a useful starting point for the next project. Keep the lesson specific, keep its source,
and keep the uncertainty where it belongs.

### Teach your working preferences

You can also teach Wonka how you like to work. If you want shorter updates, say so. If you want to
see visual options before a long explanation, say that. Ask it to save the preference so you do not
have to repeat it.

```
Remember that I prefer short updates with the result and anything that needs my decision.
```

Useful lessons and preferences are written into project files that future sessions consult. You can
open them, correct them and change your mind. When something matters, ask where it was saved, and on
the next task check that it is being used.

### You can finish here

Once the lessons are saved and you know where the work stands, you can finish the session. Wonka
recognises the work, tells you what was saved and what is still open, and lets the session end. He
does not send you into another room. This was my closing message:

```
We’re done. Thanks, Wonka!
```

Come back to the Improvement Loop when there is something new to learn from. There is no need to run
it again just to produce another summary; with nothing new, Wonka says so and leaves the log as it
is.

---

## Lesson 3: Your creative employee, from here on

### Come back with the next assignment

The next time you need images for Amazon, open this Wonka project and start the conversation here.
You can say, "I have another product. Let's get started." The research, the brief, the image work
and your feedback all have a place already.

Give the next product its own folder and its own facts. Your taste and working preferences carry
over; a new product still needs its own references and research.

Think beyond Amazon images too. Wonka is the employee to come to for creative work: website images, a
campaign, a storyboard, a product video. That does not mean every capability is already installed.
It means this is where you bring the assignment and work out what is needed.

### More products and more brands

You explain the business relationship. Wonka does the filing. You never need to learn internal paths
or move project folders yourself.

**Same brand, new product:**

```
I have another product for [brand name]. Use that brand’s kit and start a separate product project. Here are its product details and references.
```

Wonka reuses that brand's kit: the visual direction, logo and tone you established. The product gets
its own research, references and brief. You are reusing the brand identity; you still check what is
true about this particular product.

**Another brand:**

```
I’m adding another brand called [name]. Help me create a separate brand kit and connect its products to it. Here are the brand materials I have.
```

Stay in Wonka and ask for a separate brand kit. Provide a website, logo, existing images or whatever
guidelines you have. Make the brand name clear when you start a product, so one brand's colours,
tone or product claims do not spill into another. If Wonka ever cannot tell which brand a product
belongs to, it asks you one question rather than guessing.

**Connected brands:**

A participant asked about a skincare brand connected to her personal brand. That is a useful
distinction to explain to Wonka: how are the two related, what should they share, and what should
stay separate?

```
My skincare brand is connected to my personal brand. Help me define what they share and what stays separate, then associate each product with the right brand kit. Ask me about any relationship that isn’t clear.
```

Wonka records your answer in both kits, in your words, and associates each product with the right
one. Each product's claims still need their own supporting facts; a founder's credentials do not
verify a product claim, and nothing about claims moves between brands because they are related.

### Make the kit yours

If you want to make product videos, ask Wonka what tools and skills that would take, then build on
the setup you already have:

```
I want to make short product videos. Help me add the tools and skills we need.
```

You can also adapt an existing skill: a different style of brief, another export format, a
particular review step before a batch runs. Explain the change, have Wonka help you make it, and try
it on a small task. You may need another connection, access to a service, or a budget for that work.

Wonka does not rewrite his own kit off a passing remark; a clear request from you is the route. A new
capability goes in its own skill, which later kit updates leave alone. A change to one of the kit's
own skills gets overwritten by the next update, so Wonka tells you that first and offers the durable
form: a new skill beside the original, or a note you re-apply.

Do not feel limited to the kit you were given. Use it, notice what your business needs, and keep
making your version more useful.

### Let the tools change

The models will change too. The tool we used for one job may not be the one to choose six months
from now. Ask Wonka to check what is available through your connected tools, including Genrupt, and
whether another option is worth trying:

```
Check which image models we can access now. Is there a useful comparison to try for this task?
```

Give it a real question. Can this model preserve the product better? Can it handle the text we need?
Is the result worth the cost? Try a relevant example, look at the output, and save what works. You
can change the tool for one step while keeping the research, the brief and the direction you have
developed.

Saved instructions and context are what give Wonka continuity. There is no retraining, no perfect
memory, and no automatic access to every new model; there are files he reads and connections you
give him.

### One employee for each role

Separate brands can belong to the same creative employee. A different job is a different employee.

Take customer service. Give that employee a separate project, its own instructions, your policies,
the right tone and the tools it needs. Define which decisions it can handle and which come back to
you. The folder gives the employee a home; what you put inside it gives the employee a way to work.

Keep Wonka focused on creative work and give the other role its own context. You can ask Claude to use
Wonka's structure, or Donna's if you have her, as a starting point and adapt it. Adapting a structure
copies the layout, not the keys: the new employee gets its own connections, its own permissions and
none of Wonka's product history.

Optional example, not a course assignment:

```
Help me build a customer service employee in a new folder, using Wonka’s structure as a starting point. Give it the instructions and skills that role needs.
```

### One useful optional command

When you're working on several products, you can ask Wonka for a status report with
`/factory-report`, to see where each product stands and what comes next.

### Finish with a useful next step

For today, make sure you can find your delivery, understand anything still pending, and see the
useful lessons saved in the log.

If you are still working through an earlier day, continue from where you are. If your product does
not have variations, you do not need to invent them to finish the course.

Once you are ready, bring Wonka the next real assignment. That is how this becomes part of your
business.

If you would like another employee alongside him, you can also join the Donna Challenge. Donna is
where the day-to-day side gets handled: inbox, calendar, meetings and routines.
[Donna registration link]

---

## MISSION 1: Package it

```
/ready-to-upload
```

Open the handoff. Check the main, the gallery order, the exact upload filenames, and every open item.
Decide which files Amazon's AI-person disclosure applies to and have Wonka tag and verify them.

## MISSION 2: Save the lessons

```
run /improvement-loop
```

Read what was saved. Soften anything broader than the evidence. Save one working preference in your
own words. Then close the session; a "We're done" is enough.

## MISSION 3: Write your next three sentences

Not to send today. Write the sentence you would use for your next product, the one for a second brand
if you have one, and the one for the first job beyond Amazon images. Keep them where you will find
them.

**Share it:** send Jay your favourite line from your own Improvement Log. Not a screenshot of the
file. One line, the one that surprised you.

---

## What good looks like

- The handoff names the exact file for every upload slot, and you can tell the delivery from the
  record
- Every enlarged file was read against its source, and any repair is named
- Every open item is written in, not left as an absence
- Every creative lesson carries its evidence and its label; a Lean reads as a hypothesis
- At least one honest mistake is recorded, and the practice it taught is kept
- Your working preferences are saved in your own words
- The session ended when the work ended

## Common mistakes

- **Uploading the whole folder.** The record files sit beside the delivery files. Follow the list.
- **Treating the package as a compliance check.** It is not one. Claims, disclosures and placement
  requirements are yours to resolve.
- **Handing the parent's A+ to a variation.** Each child needs its own review.
- **Turning one Lean result into a rule.** Keep it a hypothesis, keep its source, test it next time.
- **Running the Improvement Loop again for a fresh summary.** With nothing new, there is nothing to
  write.
- **Building the next brand as a new Wonka.** Same employee, separate kit. A new employee is for a
  new job, not a new brand.

---

## And that is the bootcamp

Thank you for spending these ten days here. You brought the product knowledge, made the choices, and
spoke up when something was not right. That work shows in the result.

Take a moment to enjoy what you have made. Then bring Wonka the next one.

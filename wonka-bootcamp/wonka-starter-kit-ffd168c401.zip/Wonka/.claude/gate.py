#!/usr/bin/env python3
"""The factory gate. Says whether a bootcamp day's room is open yet.

Usage:  python3 .claude/gate.py <day 1-10>

The schedule lives on the server, never in this file and never in Wonka's
head. The server's own clock (the HTTP Date header) is what the schedule is
compared against, so a wrong clock on this computer cannot open a door early.

Verdicts (first word of the last line, and the exit code):
  OPEN    exit 0  the room is open, continue
  CLOSED  exit 3  the room is not open yet; the line names the opening moment
  WARN    exit 0  the schedule could not be checked; continue, but say so

The schedule file format, one day per line: "N YYYY-MM-DDTHH:MMZ" (UTC).
A line consisting of the single word "all" opens every door at once.
Lines starting with # are comments.
"""
import os
import random
import sys
import urllib.request
from datetime import datetime, timezone
from email.utils import parsedate_to_datetime

GATE_URL = os.environ.get(
    "WONKA_GATE_URL", "https://jaygptpro.com/wonka-bootcamp/day-gate.txt"
)
TIMEOUT = 8  # seconds; a dead network must never hang the session


def fetch():
    """Return (schedule_text, server_now_utc). Raises on any failure."""
    url = GATE_URL + ("&" if "?" in GATE_URL else "?") + "cb=%d" % random.randrange(10**9)
    req = urllib.request.Request(url, headers={"User-Agent": "wonka-gate/1"})
    with urllib.request.urlopen(req, timeout=TIMEOUT) as resp:
        if resp.status != 200:
            raise RuntimeError("HTTP %s" % resp.status)
        text = resp.read(65536).decode("utf-8", "replace")
        now = None
        date_hdr = resp.headers.get("Date")
        if date_hdr:
            try:
                now = parsedate_to_datetime(date_hdr)
                if now.tzinfo is None:
                    now = now.replace(tzinfo=timezone.utc)
            except (TypeError, ValueError):
                now = None
    return text, now or datetime.now(timezone.utc)


def parse(text):
    """Return ('all', None) or ('schedule', {day: open_at_utc})."""
    sched = {}
    for line in text.splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        if line.lower() == "all":
            return "all", None
        parts = line.split()
        if len(parts) != 2:
            continue
        try:
            day = int(parts[0])
            when = datetime.fromisoformat(parts[1].replace("Z", "+00:00"))
        except ValueError:
            continue
        if when.tzinfo is None:
            when = when.replace(tzinfo=timezone.utc)
        sched[day] = when
    if not sched:
        raise RuntimeError("schedule file held no readable lines")
    return "schedule", sched


def main(argv):
    if len(argv) != 2 or not argv[1].isdigit():
        print("usage: python3 .claude/gate.py <day 1-10>")
        return 2
    day = int(argv[1])
    if day < 1:
        print("usage: python3 .claude/gate.py <day 1-10>")
        return 2
    if day == 1:
        print("OPEN day=1 (Day 1 is never gated)")
        return 0

    try:
        text, now = fetch()
        mode, sched = parse(text)
    except Exception as e:
        print("WARN could not check the schedule (%s)." % e)
        print("WARN continue, and tell the owner the schedule could not be verified.")
        return 0

    if mode == "all":
        print("OPEN day=%d (every door is open)" % day)
        return 0

    open_days = [d for d, when in sched.items() if when <= now]
    # day 1 is never gated, so the floor of "what is open" is always day 1
    highest = max(open_days) if open_days else 1

    if day in sched and sched[day] <= now:
        print("OPEN day=%d (open through day %d)" % (day, highest))
        return 0

    if day not in sched:
        # a day the schedule does not know is treated as not yet scheduled
        print("CLOSED day=%d opens=not-yet-scheduled open_through=day-%d" % (day, highest))
        return 3

    local = sched[day].astimezone()
    print(
        'CLOSED day=%d opens_local="%s" open_through=day-%d'
        % (day, local.strftime("%A %d %b %Y, %H:%M"), highest)
    )
    return 3


if __name__ == "__main__":
    sys.exit(main(sys.argv))

# The Product Photo Shot List

**Eleven frames. Your phone. Twenty minutes, once.** Six core shots of the product, two close-ups that pay for themselves, three of the packaging.

This is the highest paying twenty minutes in the whole bootcamp. Every main image, every
secondary, every A+ module and every variation the factory ever makes for you gets poured
out of the reference you build from these photos.

The rule behind all six: **whatever your photos do not show, the model will invent.** Not
maybe. Always. So the job is not pretty pictures, it is total coverage.

---

## Before you shoot

- **Plain background.** A white wall, a sheet, a clean table. No patterned countertop.
- **Daylight.** Next to a window, indirect. No overhead kitchen light, no flash, no lamp.
- **Clean the product.** Fingerprints and dust show up bigger than you expect.
- **Phone is fine.** Wipe the lens. Do not zoom, walk closer instead.
- **Landscape or portrait, just be consistent.**
- **Do not edit anything.** No filters, no auto enhance, no background removal. The factory
  needs the truth, not a nicer version of it.

---

## The six shots

### 1. Front
Straight on, dead centre, the way a customer sees it on a shelf. This becomes the anchor for
every image after it.

### 2. Back
**Do not skip this one.** It is the most commonly skipped shot and it causes the most damage.
If the model never sees your back, it invents one, and invented backs show up in lifestyle
images where you did not expect them.

### 3. Left side
Square to the side, not at an angle.

### 4. Right side
Both sides, even if you think they are identical. They usually are not: cables, buttons,
seams and switches live on one side only.

### 5. Top down
Straight above, looking down. This is what fixes proportions. Without it, tall products come
out squat and wide products come out narrow.

### 6. Your hand holding it
**The one everybody underrates.** Scale is the single thing AI gets most wrong about
products, and a hand in the frame pins it down in a way a dimension in inches never will.
Hold it naturally, the way a buyer would. Do not pose.

---

## Two extras that pay for themselves

**7. Label close up.** Fill the frame with your label, your logo, your printed claims. Sharp
enough to read every word. This is what stops the factory inventing text on your packaging.

**8. Texture close up.** Get close to your actual material: the grain, the weave, the brushed
metal, the matte plastic. This is what stops a glass bottle rendering as opaque plastic, and
it is a real failure that has happened on real products.

---

## And your packaging, which is a separate job

Photograph the box, pouch, sleeve or tin the same way you shot the product: **front, back, and the
label panel.**

This is not a bonus extra. Packaging travels in its own separate channel inside the machine, and it
unlocks a real hero-image strategy: a main image built around the actual retail box. That strategy
is simply unavailable to you if the box is not in the folder.

**Name these files so they read as packaging**: `box-front.jpg`, `box-back.jpg`,
`label-panel.jpg`. They get routed separately from the product shots, and clear names make that
obvious to you as well as to Wonka.

If your product genuinely has no packaging a buyer ever sees, skip it. Just skip it on purpose
rather than by forgetting.

---

## The checklist

```
THE PRODUCT
[ ] 1. Front
[ ] 2. Back
[ ] 3. Left side
[ ] 4. Right side
[ ] 5. Top down
[ ] 6. Hand holding it, for scale
[ ] 7. Label close up
[ ] 8. Texture close up

THE PACKAGING
[ ] 9.  Box / pouch / sleeve, front
[ ] 10. Box / pouch / sleeve, back
[ ] 11. Label panel, sharp enough to read

[ ] Plain background on all of them
[ ] Daylight, no flash
[ ] Nothing edited or filtered
[ ] All saved into one folder
[ ] Packaging files NAMED as packaging
```

Name the folder something you will recognise later; any name works on your phone or desktop. Their real home is inside the factory: on Day 2, when your product is registered, they land in `factory/Products/[your product]/2-reference/photos/`, and Wonka does that filing for you.

---

## If you do not have the product in your hands

It happens: the unit is at a warehouse, or a 3PL, or you are working on a listing that is not
yours yet. You have a fallback, and you should know exactly what it costs you.

**The fallback:** your own listing gallery images, plus photos customers uploaded inside
their reviews. Review photos are more useful than they sound, because they show the product
on a real table in real light, which is exactly what a brand gallery never does.

**What it costs you:** a brand gallery was shot to sell, not to measure. The angles a
reference needs most, the back and the top down, are the ones a brand rarely bothers with.
So the coverage has holes, and holes get filled by invention.

**What to do about it:** tell Wonka plainly that you have no photos of your own and where
your images came from. He records it on the reference sheet as a real limitation rather than
pretending the reference is complete, and the smoke test becomes non negotiable. Then shoot
the six properly as soon as a unit is in reach and rebuild the reference. It is worth doing
twice.

---

*The Wonka Creative Bootcamp. Day 2 and Day 4.*

---
name: variations
description: Build the variation imagery for a product sold in more than one child SKU (colors, sizes, shapes, scents, flavors, counts, bundles). Classifies the tested set frame by frame, builds a per-child truth table from each child's own listing, then propagates the family in two edit layers (shape, then printed text) off the recorded picks (the `Main pick:` and `Gallery pick:` rows) so the family reads as one brand, measures what drifted, and writes the Amazon parent/child embedding map. Takes the family three ways, any combination: ASINs or listing links, a written sentence, uploaded images. A described colour, finish, shape, size or count the listing does not sell is generated as a labelled CONCEPT, never a product claim; a shape concept takes another listing's ASIN as its shape reference. Runs on a selected source (one image or a set), estimates the cost and refuses above the cap. Use when the package is briefed, referenced and tested. Triggers: /variations, "/variations B0...", "make this in black, white and red", "make the variation images", "color swatches", "size variants", "bundle images", "multipack images", "variation set", "variation family", "parent child listing images", "variations room".
---

# The Variations Room

| Meta | Value |
|------|-------|
| Room | The Variations Room |
| Station | INVENT (variations are one of the four Invent sub-parts) |
| Day | Day 9 in the bootcamp, run after the tested set is final. Also runs any time a child is added or a single child is sent back |
| Modes | MODE 1: the PILOT, one child per kind of change (shape, colour, count), each done properly before that kind propagates. MODE 2: the rest of the family, propagated once the pilot is right. MODE 3: one child re-run, driven by an inspection flag or a new child |
| Needs | brief/creative-brief.md (its VARIATIONS section), 2-reference/reference-sheet.md (LOCKED, smoke test PASS), the family from the owner in any of three ways (ASINs or links, a sentence, uploaded images), the `Genrupt preset ID` row of status.md (optional), the tested set on disk, a live machine for the chosen path |
| Saves to | Finals: factory/Products/[product]/variations/ (main-[child].png, swatch-[child].png, per-child propagated frames [slot]-[child].png, variations-plan.md); concepts under variations/concepts/[child]/ with `-concept` in every filename and a CONCEPT.md. Machinery: factory/Products/[product]/variations-work/ (manifest.json, source/, refs/, working/, qa/) |
| Typical cost | Type A edit path: cents per edit call on the OpenAI key (an image edit is a fraction of a cent to a few cents). Type B / fallback: Genrupt credits per image. No upscale here: the Shipping Room upscales the family once, with the mains. **Estimated, then run.** `variations_run.py` prices the job list before the first call and refuses above `spend_cap_usd` (default $10 per run, set in the manifest or `--cap`); invoking the room authorises a run under the cap, and above it Wonka asks once. |

## What this room does

Until now, a product with eight variants meant eight separate photoshoots or eight separate design
jobs. **This room takes one tested set and propagates it across the whole family**, and the work
drops from days to a plan, a pilot, and a button.

The economics rest on one idea: **most of a variant family already exists.** The tested set was
briefed, referenced, inspected and tasted. A child differs from it in a bounded, nameable way: a
shape, a color, a printed count, a printed size. So the room never regenerates what did not change.
It classifies every frame, EDITS the frames that carry the difference, and REUSES the rest
untouched. A frame that carries nothing variant-specific is reused, not regenerated. That single
rule is what turns "eight children times seven frames" into a bounded number of cheap calls.

### Two kinds of variation, and the owner picks

This is the first question, and getting it wrong means redoing the family.

**TYPE A, identical except the variant.** Everything in the frame stays byte-for-byte the same
intent: the same model, the same pose, the same background, the same props, the same layout. **Only
the varying attribute changes.** A red shirt becomes a blue shirt on the same person in the same
room. Choose this when the family should read as one product in several colours, which is what most
apparel, most packaging colourways and most scent ranges want. **Type A runs as EDITS of the tested
set**, two layers per frame (shape, then text), on the OpenAI key with this room's bundled scripts.
That is what makes "identical except the variant" literally true: the pixels that did not change
are the same pixels.

**TYPE B, regenerated on the same brief.** The image is generated again from the same brief and the
same prompt, so it carries the same message and the same job, but the model may be a different
person, the styling may differ, and the composition may shift. Choose this when the owner WANTS
visual variety across the family, so the listing gallery does not feel like the same photograph
recoloured eight times. **Type B runs as GENERATION on Genrupt** off the locked reference, exactly
like the other Inventing rooms.

**Neither is correct in general.** Ask only when `status.md` has no `Type` row; otherwise reuse the
recorded answer. When asked, record the answer with its reason, and say the tradeoff out loud: Type A is coherent and can feel repetitive; Type B feels alive and can feel like a different
product. Nobody should discover this preference after the whole family is generated. The owner's standing preference for consistent compositions is Type A. When a frame cannot be edited into the new shape (three phrasings failed), Wonka says in one sentence that this frame needs a regeneration on the same brief and what that changes visually, and asks nothing else.

### The pilot rule

**Do ONE child per kind of change (shape, colour, count) properly first, and only then propagate that kind.**

A family generated in one go on an untested prompt is a family regenerated in one go. Doing a single
variant, looking at it honestly, and fixing the prompt until it is right costs one image; discovering
the same problem across eleven costs eleven.

Once the pilot is right, the rest runs on the same manifest. The pilot is for a FIRST family; a family the owner has run before skips it unless they ask for one.

### And the brief does not change

Variations are the SAME brief. Same message, same job, same claims where the claims are shared. **A
variant that needs a different brief is not a variant, it is a different product**, and it goes back
through the pipeline rather than through this room.

Two lawful nuances, both recorded rather than discovered:
- A specific variant may earn a specific extra image (a size chart that only applies to the large, a
  use case that only applies to one scent). That is an addition, not a divergence.
- **Claims MAY differ per child, and that is the truth table's job.** A smaller size fits a smaller
  basket; an eight pack prints a different count. Same story, different printed facts. Every changed
  claim is named up front in the truth table, never left for the machine to guess.

### What this room makes, and the different-brief case

This room makes the variations that can use the SAME creative brief: colours, finishes, shapes, sizes, counts, with each child's printed dimensions, labels and other variant-specific details updated from that child's own source. A real variant with different features, functionality or selling points needs a different brief: Wonka says which feature differs and routes it through `/creative-brief` before any of its images are generated. A demo or an owner assumption ("treat it as the same features, only the shape changes") is recorded verbatim as an assumption line in the plan and in `status.md`, never as a verified fact, and the truth table marks every value it drives as `assumed`. An assumption is lawful only for a concept (`status: concept`); a real child's row is always read from its own source.

## Before you start

Check these in order and report what you found out loud before spending anything.

0. **`status.md` first, and reuse every recorded decision.** Day 9 is variations: this room runs when the owner invokes it, resumes after a Day 8 close, or asks to continue, and never by itself off a Day 8 approval. Start with `python3 .claude/skills/ready-to-upload/stage_gate.py "factory/Products/[product]"`: it reads `status.md` and says whether variation information is already on record. `stage_gate.py` answering `next_stage: day8` does not close this room; it means the `Owner decision:` row for the Day 8 set is missing. Say so in one line, write it from the owner's recorded words when they are on disk, and continue. When it is (a child list, sources, Type A/B, a plan, child reference folders), use it and ask nothing. When nothing is on record, ask ONE short question and nothing else: "Do you have any product variations you'd like to create images for?" The answer may be ASINs or listing links, uploaded reference images, or written changes including new colours not yet listed, in any combination (the three methods in Process step 1). An explicit no, in the owner's words, is recorded as `Variations: skipped (owner, [date])` in `status.md`, and the Shipping Room opens on that record when the owner invokes it. A skip on record is a past answer, not a lock: a new request in this session reopens the room; rewrite the INVENT sub-status row to `Variations (/variations): in progress ([what is owed])`; the old skip line stays in the Log as history (stage_gate orders records by date then position, so a same-day reopen written as a Log line above the skip would read as done). `/variations` followed by ASINs, links, a sentence or attached files is the whole invocation. Read the Type A/B decision, the child list, the `Main pick:` and `Gallery pick:` rows and the preset id off `status.md` and the plan on disk. A question already answered on disk is never asked again. The questions Wonka may still ask, and nothing else: Type A or B when not on record; the one uploads disambiguation (method C); a shape reference for a described shape child; an unknown printed value the owner can supply; the cap question above `spend_cap_usd`; and nothing that a recorded answer, the pick rows, the brief or the fetched images already settle.
1. **Brief. HARD.** `brief/creative-brief.md` exists. Read its VARIATIONS section and say back what it currently claims. A Day 3 line such as `Variation MAIN concept: product-only` is superseded by the tested main as it stands (Process step 5), and Wonka says so once instead of repeating it. Three lawful states, all workable: a real child list, `variations: none (single SKU)`, or `variations: unconfirmed`. Missing brief entirely: station **BLOCKED**, point to `/creative-brief`, stop. What is never lawful is generating a family while the brief on disk says something else; that is resolved in Process step 3, before any credit is spent.
2. **Locked reference. HARD.** `2-reference/reference-sheet.md` exists with `Reference status: LOCKED` and `Smoke test: PASS`. An approved reference WITHOUT a passed smoke test does not count. Missing or unpassed: **BLOCKED**, point to `/reference-sheet`, stop. Also read the sheet's `source:` field: if it records `amazon_scraped`, say so plainly once ("this reference was built from listing and review images, not from photos of the unit, so product likeness is the weaker path here"), tighten the fidelity check in step 11, and carry the source into the plan.
3. **The tested set. HARD for Type A, SOFT for Type B.** Type A edits an existing set, and the source is the RECORDED selection: the `Main pick:` row (the primary name) and the `Gallery pick:` row (the folder and the ordered frame names) in `status.md`, each file at its newest `edits/vN` copy (`variations_run.py --source-from-picks` reads the rows, resolves and copies them, and prints every path with its folder). Never "the highest edits folder" as a set and never "the Tasting Room winner" as the rule: the winner and the pick coincide on most products, the pick row is the record. A file the rows name that was revised after the panel (the Day 8 `revised after test` trail in `status.md`) is used as recorded and the plan says `revised after test, no re-run` beside it. No panel run is required before Day 9. **The source is what the owner selected, not the whole set by default:** they may name ONE image (the tested main only), a SET (the main plus two frames), or the whole tested set. When nothing is named, the source is the tested main plus the frames the frame table marks as variant-carrying. Whatever is selected, the source files are the newest `edits/vN/` copies of the selected names (`variations_run.py resolve_source`, the same rule the Tasting Room uses); never a `-rejected`, `-render` or `-boxes` evidence file and never an underscore diagnostic. For Type B with no tested set, the family inherits the Reference Sheet's shot language plus the brief's main-image direction, and the plan records `inherits from: reference sheet (no tested winner yet)`. Never build a family from scratch when a tested set exists; that is the whole economic point of this room.
4. **The branding preset. OPTIONAL, and resolved from `status.md`.** Read the `Genrupt preset ID` row, not `brand-kit.md`'s existence. An id there is attached, including a **logo-only preset**; `none` there is a complete state: PROCEED, record `brand: none on file` in the plan and the status line, and score brand fit accordingly at inspection. Do not offer `/brand-kit`, and never invent a palette, a font or a brand to fill the hole. On the Type A edit path this bites less anyway: the edits inherit the tested set's brand treatment pixel for pixel.
5. **A machine for the chosen path.** Type A needs Machine 2, the OpenAI key (the same key the Fixing Room and the Tasting Room run on), plus Python with `openai` and `Pillow` installed; `/machines-check` verifies the key. Type B needs Genrupt MCP. If the Type A machine is missing, offer the fallback explicitly: the same family through Genrupt's variations flow, equal in quality and dearer per image; never switch paths silently. If NEITHER machine is available, the room is closed: mark `blocked: no generation machine` in `status.md`, point to `/machines-check` and `guides/mcp-setup-guide.md`, and stop.

## The child list, and the three honest answers

This is the spine of the room, so it happens before planning and before any estimate. **And it starts with Wonka's own hands, per the spare-the-owner ladder**: the live listing's variation picker is ON the product page, so when this session can reach the page (or `/meet-my-product` already recorded the picker), Wonka FETCHES the family Amazon shows and STATES it, "here is the family your listing sells today", and the owner's question shrinks to the one only they can answer: **which of these are actually saleable today, and what exists that the listing does not show yet**, and Wonka asks nothing when the brief already records the picker's read-back and the family it names. Only with no page access does the question start from zero. Never read a child list off a competitor's listing, off the category, or off your own assumption that a product "probably comes in other colors", and take the owner's final answer literally: the picker is evidence of what the listing SHOWS, the owner is the authority on what is REAL. The family arrives in any of three ways, combinable (Process step 1): ASINs or links, a sentence, uploaded images. The confirmed list is written down with, per child, `source: asin | described | uploaded | asin-reference` and `status: real | concept`.

**Answer 1: a list.** Write down the theme and every child, in the owner's own words, with the attribute value, the `source` and the `status` for each. That list is the batch plan; nothing outside it is generated. A real child is a saleable SKU with a source of its own; a concept child is a colour, a finish, a SHAPE, a size or a count the owner is exploring or planning that the listing does not sell, generated and labelled `concept` everywhere. A shape concept needs a shape reference (an ASIN, a link or a photo) exactly as a real shape child does; its `source` is `asin-reference`, meaning the ASIN supplies the SHAPE only: it is not a child of the owner's listing and its listing facts are never read as the concept's facts (`variations_intake.py concept_from_reference`).

**Answer 2: "none, it is a single SKU."** A complete and common answer, not a failure. Do not generate anything. **An explicit skip or no in the owner's words ("skip Day 9", "no variations for this one") is a complete Day 9 decision:** write the skip line and nothing else, no multipack offer, no concept, no run. Only when the owner answered the FACT ("it is a single SKU") without closing the day, offer one option, once, without pushing: a **multipack of the identical unit** is the only variation type that invents zero product facts, because two of the same real unit is still the same real unit, only the count changes, and it is the child a single SKU seller genuinely adds first. Say plainly that a bundle is a SKU the owner would have to really create and really stock, so it is a business decision and not an image decision. If they take it, that IS a real child list and the run continues at Answer 1, with the brief amendment in Process step 3. If the answer is still no, the finished state of this room has ONE name, `Variations: skipped (owner, [date])`, written as a Log line with the date, and the rest of the package is unaffected; the Shipping Room reads that line as complete.

**Answer 3: "I don't know."** Do NOT guess and do NOT write `none` on a guess. Record `child list: unconfirmed` and name the two places the truth lives: the live listing's own variation picker, and the parentage or variation view in Seller Central. Then park this sub-part only: `Variations (/variations): blocked: child list unconfirmed` in `status.md`, with the exact question to answer. Say clearly that nothing else is held up, because variations are the one sub-part allowed to trail the rest of the package; INSPECT and PROVE continue on the main, the gallery, and the A+.

**And measure each child against ITS OWN photos before any parent law is applied to it.** A child is not always the parent in another colour: measured 27 August 2026, two children of a brush set had no separate ferrule neck at all (a painted continuous shaft tapering straight into the ferrule) while the parent's reference sheet carried the law "warm brass neck, never chrome". Propagating that law would have rendered both children wrong, confidently. So before the truth table is written, compare each child's real photos to the parent's anatomy table and record which parent facts DO NOT apply to which child. A structural difference is not a variation layer, it is a different mold, and it may need its own reference.

Two standing rules for whatever comes back. **Real means saleable, and a concept is labelled:** a child the owner "might add later" is not a real child today; it can be a concept, filed under `variations/concepts/`, and the plan says in one line that a concept is a picture of a possible product. **Never invent a CLAIM:** a real child never asserts a capacity, a material, a finish, or a count that its own source (listing, description, the owner's answer) does not support; a concept never asserts anything about a product that exists. When a proposed real child carries an unsupported claim, stop and say so; the fix is upstream, in the brief and the reference, never in the prompt.

## Process

1. **Establish the MODE, and settle the two questions before anything generates.**

   **Question one: the child list.** Sizes, colours, shapes, scents, counts, bundles. Three ways in, any
   combination, none required on its own:
   - **A. ASINs or listing URLs.** Several at once. For each, retrieve the variant's images, starting
     with its main and adding gallery frames when the main does not show the difference. The route is
     the same fetch the Tasting Room's step 0b uses for `incumbent/`: the listing's image URLs (the A+
     preflight candidates or the page), saved to disk, one folder per child under
     `2-reference/variations/[child]/` as `live-main.jpg`, `live-02.jpg`. **Verify the image is the
     CHILD's, not the parent's shared main or another model:** if two children resolve to the same
     image URL or to byte-identical files, say so and use the next gallery frame that differs; if none
     differs, the child has no image of its own and Wonka asks for one (method C) or a description
     (method B). Reuse research already on disk (`research/competitors.md`, `1-inputs/`) and the locked
     reference; never re-run the market analysis for this. On a live family the listing's own variation
     picker is the best evidence: it names every child with its dimension values. One warning from the
     field: **the dimension labels lie.** Amazon's `color` axis has been observed carrying the SHAPE.
     Read the values, not the axis names. If retrieval fails (no browsing, no MCP), say so in one line
     and take uploaded references as the fallback. Read the differences BACK to the owner before
     accepting them: a misread attribute propagates into every child. An ASIN pasted as a SHAPE
     REFERENCE for a concept is fetched the same way into `2-reference/variations/[child]/`, and Wonka
     confirms in one line that the fetched main actually shows the shape being borrowed before it is
     used; if it does not, the next gallery frame that does, else the one question. The decision
     rule: an ASIN that is not one of the listing's own children (the picker family the brief
     records) is a SHAPE REFERENCE for a concept: `source: asin-reference`, `status: concept`, no
     question asked. `/variations B0... B0...` with two such ASINs is that case.
   - **B. Written instructions.** "Make this in black, white and red", "the 5-tier model", "a
     2-pack". No live listing required. A colour, finish, shape, size or count the listing does not sell is a CONCEPT
     child: generated and labelled `concept` everywhere (the folder, `-concept` in the filenames, the
     plan, `status.md`), no separate approval step, and never a product claim; the plan says in one
     line that a concept is a picture of a possible product. `variations_intake.py
     children_from_sentence` maps COLOURS only: every colour in the sentence becomes a child with
     `source: described` and its status, and a finish word (`matte`, `glossy`, `brushed`, `satin`)
     is merged into the colour it precedes (`matte black` is one child, never a `matte` child). A
     shape, count or size sentence ("the 5-tier model", "a 2-pack") is mapped by Wonka into
     children with `source: described`; the helper returns its one question for those, and Wonka
     answers it from the sentence, never the owner. `--known` is the list of colours the live
     picker or the reference set shows: read it from `2-reference/variations/` folder names and
     the picker read-back recorded on Day 2 (`brief/creative-brief.md` VARIATIONS section). A
     written SHAPE change still needs a shape reference (method A or C), because geometry cannot
     be described reliably; say that once and ask for the reference. A shape concept whose reference
     is another listing's ASIN or link is `source: asin-reference` (`concept_from_reference`).
   - **C. Uploaded images.** Several files. Map each to a child. **Multiple variants versus multiple
     views of ONE variant:** decide from the filenames and the owner's words (`variations_intake.py
     map_uploads` does this from colour tokens, front/back/side tokens and the sentence); when it is
     genuinely unclear, ask ONE focused question ("Are these three files three variants, or three
     views of one?") and nothing else. Two more cases the helper turns into that one question,
     never a guess: camera-numbered files with the owner naming one colour per file ("Which file
     is which colour, in order?"; position says nothing about colour), and filenames naming two
     colours while the words name one. A non-colour token in a filename stays in the child
     (`stainless-cascading.jpg` is the child `stainless-cascading`, not `stainless`). Copy the files into `2-reference/variations/[child]/`;
     the owner files nothing. **Check each asset belongs to the child it is filed under** before it
     feeds anything: piece count, colourway, size or format against the child's own listing entry. A
     neighbouring variant's photo sitting in the wrong child is how a whole family comes back subtly
     wrong, and nothing errors. Anything that disagrees moves to `_other-variant/` with a one-line
     reason, same as the Reference Room does.
   Whichever way it came, the confirmed list gets written down with, per child, `source: asin |
   described | uploaded | asin-reference` and `status: real | concept`. Never write `none` on a guess: if the owner
   does not know, that is `unconfirmed` plus the one line on how to check (the listing's variation
   picker, or Seller Central).

   **Question two: TYPE A or TYPE B** (see above). Asked only when `status.md` has no `Type` row;
   a recorded Type is reused without a word. When it is asked, record the answer and the reason,
   and say the tradeoff out loud. This decides which machine runs and how every call is built, so
   it cannot be discovered halfway.

   Then the mode:
   - **MODE 1, the PILOT.** One child per kind of change (shape, colour, count), each done properly before that kind propagates. This is the default entry
     on a first family; a family the owner has run before skips it unless they ask. A family counts
     as run before when `status.md` carries a `Variation family generated` line for this product.
   - **MODE 2, the rest of the family.** After the owner has looked at the pilot sheet and said
     "continue" (or named a fix that then landed). One batch, no confirmation per variant.
   - **MODE 3, one child re-run.** A child coming back from `/inspect`, from `/fix` as a
     REGENERATE-class defect, or a newly added variant. Name the driver in writing first.

2. **Lock the theme and the child list.** Name the dimension or dimensions the children vary on and confirm each child's attribute value. One theme is the norm; some categories allow two (Size plus Color), in which case say out loud how many children the grid actually produces, because a 3 by 4 grid is twelve children, not seven.

3. **Reconcile the brief, and amend it BEFORE any credit is spent.** Compare the confirmed child list against the brief's VARIATIONS section.
   - They match: continue, and note the match in the plan's provenance.
   - They differ, including the common case where the brief says `none (single SKU)` or `unconfirmed` and the owner has now named a real family: **amend `brief/creative-brief.md` first.** APPEND a dated `Day 9 concepts` block under the real family list in the VARIATIONS section, never replacing the picker read-back (the only record of the real children), record the reason in one line, show the amended section to the owner, and only then continue. Never generate past a document that contradicts the plan, and never edit the section silently. Six weeks later, the answer to "why are there bundle images for a single SKU product" has to be in the file.

4. **Write the FRAME TABLE and the TRUTH TABLE.** These two tables are the whole plan, and neither can be guessed.
   - **The frame table covers the SELECTED source only** (Before you start, item 3): the one image, the set, or the whole tested set the owner named, else the tested main plus the variant-carrying frames. Open every frame of that source with the Read tool, one by one, and record per frame: does it carry the varying attribute's SHAPE, does it print a variant-specific VALUE (a count, a size, a fit claim), or does it carry nothing variant-specific at all. **While looking, COUNT the products in each frame** and write the count down; a frame holding four product instances needs that number in its prompt later, and the count cannot be read off a filename. A frame that carries nothing variant-specific is marked REUSED and appears in no child's edit list. **A shape child changes product GEOMETRY under the new reference; a colour child changes finish only; the two never share a prompt.** A colour child is never a recoloured shape and a shape child is never a recolour.
   - **The truth table.** Per child, from that child's OWN source (listing, description or the owner's answer): shape, count, size label, fit range, every printed claim, and a `Parts that change / parts that keep their finish` column written from the reference sheet's parts list (for the fountain: the tiers and bowl take the colour, the stainless base, switches and jug stay). The colour prompt names both halves, and a colour child never restyles a part the row says stays. For a shape child, the dimensions, instructions and claims printed on any frame are checked per child BEFORE they carry across; under an owner assumption the row reads `assumed same as parent (owner, demo assumption, [date]); not verified for [ASIN]`. **Every printed text, dimension, quantity and accessory is CHECKED against that child's own source and written as `[value]`, or `unknown, kept from the source frame`, or `unknown, removed`; the machine never invents a spec.** When a shape change alters a dimension that is printed on a frame and the child's true value is unknown, the frame is generated with the number removed and the plan says so. **Never carry the source's claim across.** The classic silent failure: a smaller child that keeps the source's fit range, or a shape child that keeps the source's size text. A family that swaps the shape and keeps a wrong claim ships a wrong claim, beautifully.
   - Read both tables back to the owner in one screen. The frame table decides how many calls the family costs; say that arithmetic out loud ("a text-only child touches 3 frames, a shape child touches 6, so this family is [N] calls").

5. **Plan the per-child imagery.** Three file classes per child, driven by the tables.
   - **The per-child main.** The product in that child's form, inheriting the TESTED main as it is: if the tested main carries hands under the human-contact tactic (main-13 does), the child's main keeps them; the main-image rules apply to a child exactly as they applied to the parent, no stricter and no looser, and no overlay text or graphics beyond what the tested main already carries on its own label. Every child holds the same angle, lighting, background family, and framing; only the target attribute moves.
   - **The per-child propagated frames.** Every gallery frame the frame table marked as variant-carrying, edited for this child. Frames marked REUSED are shared by the whole family and copied, never re-generated.
   - **The swatch, optional.** Produced when the owner asks for it or when the theme is colour or finish AND the owner wants the picker thumbnail; never generated by default, and the scope line says whether swatches are in. The small picker thumbnail has ONE job: telling the shopper at a glance which child she is choosing. Its job differs by theme:

     | Theme | What the swatch must carry | The failure to avoid |
     |---|---|---|
     | Color or finish | the actual color, filling the frame | a full product photo where the color is a detail |
     | Size or capacity | the size, as very large legible text | tiny numerals nobody can read at picker size |
     | Count or bundle | the count, as very large legible text plus the true number of units | one unit standing in for a multipack |
     | Scent or flavor | the name plus one honest cue (the real botanical, the real fruit) | a generic near-miss ingredient |

     Swatches render tiny, so win legibility by subtraction: fewer elements means bigger elements. A swatch is not a shrunken product photo. Say one honest thing about them out loud: **whether the picker draws an image swatch or a plain text button depends on the theme and the category template.** Color, pattern, and style themes classically get image swatches; size and count themes are often text buttons. Where a swatch was asked for, produce it whichever way the picker draws, because where it does render it is the whole decision, and where it does not it still serves as a gallery or A+ frame. Never state which one a specific category will draw as if it were checked; the owner sees the truth in the listing itself. Swatches are GENERATED (Genrupt, or gpt-image on the key), not edited; they are new small compositions, not crops of the main.
   - **Counts and arrangements are structural, not scale.** A bundle child is a different ARRANGEMENT of real units, never one unit photographed larger. Every unit in frame keeps its true proportions and its true parts, and the count in the image equals the count in the child's name.
   - **Derived likeness, named as such.** This applies to a REAL child (`source: asin | uploaded`) whose fetched or uploaded image failed to show it: ask for one photo or one exact description of that child. A described colour the reference set never showed is a CONCEPT (step 1B), and a colour concept gets no question; a shape concept gets the shape-reference question once. The cheapest lawful shape reference is the child's own current live main image, used as SHAPE TRUTH ONLY (rule in step 6). If the answer is "I don't have that", that is a real answer: PROCEED, record `likeness: derived (no reference for this child)` against that child in the plan, warn once that it is the weakest thing in the family, and never present it as verified accurate.
   - **Map shared versus per child.** The frame table already made this map: which assets serve the whole family (the REUSED frames, usually most of the gallery) and which are per child (the main, always; the swatch where one was asked for; the variant-carrying frames). The A+ modules are NOT automatically shared: they are classified like frames. A module that shows the product's shape, a changed dimension or a changed instruction is per child or excluded for that child, and the plan says which; only modules with nothing variant-specific are shared. The map goes in the plan and later into the upload pack.

6. **Type A: write the manifest.** The plan becomes ONE JSON file, `variations-work/manifest.json`, and the manifest is the artifact worth reviewing: it holds every prompt, so a bad output traces to a sentence, and re-running one child after a prompt fix is one flag. Start from `example-manifest.json` in this skill's folder and rewrite it for the real family. Set up `variations-work/` first. Fill `source/` from the product folder with the run script, never by hand:
   ```bash
   python3 .claude/skills/variations/variations_run.py \
       "factory/Products/[product]/variations-work/manifest.json" --dry-run \
       --source-from "factory/Products/[product]"
   ```
   `--source-from` resolves every name in the manifest's `frames` (a stem like `main-13` is enough) to its newest `edits/vN/` copy, else `images/`, copies it into `source/` (never moves) and prints each resolved path; a `-rejected`, `-render`, `-boxes`, `-2048` or underscore name is refused before anything runs. Then one shape reference per target silhouette into `refs/`. A child's `reference` is the file copied into `refs/` from `2-reference/variations/[child]/`; the QA sheet shows it as the third tile.

   **When a child differs by COUNT (a multipack, a bundle, a different piece count), the right
   shape reference is the parts-inventory sheet**, the countable-panels additional sheet from
   `/reference-sheet` (`2-reference/parts-inventory-sheet.png`). It exists because the machines
   cannot count from a beauty shot: measured on the demo product, count edits against the beauty
   sheet landed 2, then 5, then 3, and the same edit against the parts sheet landed exactly 4,
   first try. If the family has a count child and no parts sheet exists yet, build it now via
   `/reference-sheet` (its "One product, up to five sheets" section) before writing the manifest.

   The manifest carries: the frame list, the shape references, `shape_prompts` (the normal frames), `hero_shape_prompts` (the MAIN's own wording), `frame_shape_prompts` (per-frame overrides for multi-object frames), `quality` (`low` by default), `spend_cap_usd` (10.0 by default), and per child its `source`, its `status` (`real` or `concept`) and the frames to touch with their exact text instruction from the truth table. A colour concept's prompt names the finish only and inherits the source's geometry; a shape concept's prompt is a shape prompt like any shape child's, against its reference.

   **The prompt rules.** Each one exists because the naive version shipped a wrong frame. Over all of them sits the words rule: the prompt names the CHANGE, never the product's existing look (no material, finish, colour or rim words for what stays); identity comes from the reference image in the chain, so say "keep everything else as the first image shows it".
   - **State the target geometry positively AND forbid the source geometry.** "A true circle with no corners and no straight sides, and no square or rounded-square silhouette anywhere." A soft target-only description gets read as "already close enough".
   - **The hero names its CURRENT geometry first, then orders the redraw.** "The hero product is a stack of SQUARE [things]. Redraw that product as..." The MAIN's label card dominates the frame and the model preserves the layout it sees; target-only wording leaves the MAIN unchanged while every lifestyle frame converts.
   - **Any card, badge or band on the product's label is a RIGID OBJECT, and the prompt says so.** Same shape, same size, same position, every band exactly as wide as it is now and fully inside its border. Left unsaid, the model reshapes the card to follow the new product silhouette.
   - **A frame holding several products gets its count named, and each instance located.** "This is a FOUR-PANEL grid and EVERY ONE of the four panels shows... redraw ALL FOUR." "Every [thing]" reads as satisfied after one. This is why step 4 counted.
   - **The reference is SHAPE TRUTH ONLY, and the prompt says so.** The cheapest reference (the child's live main) carries its own old label design, and without the instruction that design leaks into the output.
   - **Pin the SOURCE's camera angle by name.** Measured on a pilot child: even with "do not copy the reference's composition" in the prompt, the output drifted from the source's frontal pose toward the reference's three-quarter angle. Say it positively: "keep the SOURCE image's exact camera angle and product position; the reference supplies only the product's shape and color".
   - **Where the product sits inside a container, the container must fit it.** The basket, the drawer, the box is part of the swap.
   The script appends a preserve-everything-else block to every call on its own; do not restate it.

7. **The pilot, and the prompt loop when it does not land.** Say the scope line and the estimate first, in one line, then run. The line names the children AND the frames, the frame list is mandatory: "[N] children ([R] real, [C] concept), frames [MAIN, PT03], [M] edit calls on your OpenAI key, about $X (cap $10 per run), swatches [in / not made]". The chat report for the whole room is four lines: what will change (children, frames), the estimate, the results (one line per child with its sheet path), and what needs the owner's decision. The estimate is an ESTIMATE (calls x list price) until the billing dashboard is read, and the results line counts API calls that succeeded, never frames that passed inspection: "27 calls succeeded, 0 failed, estimated $0.54" is honest, "zero failures" alone is not, because a call that returned an image is not a frame the Inspection Room passed. Crop coordinates, hashes, measurement experiments and diagnostics go to `variations-work/run-log.md` and the `qa/` sheets, never the chat. Everything else goes to `variations-work/run-log.md`. The number comes from `variations_run.py --dry-run`, which prices the job list (calls x price per call by quality, list prices as of September 2026; a padded non-square frame counts twice because the edge-contact retry is a paid call; frames already on disk count zero unless `--force`, and the script prints how many outputs it will skip) and prints the restriction when `--frames` is set. A scoped rerun (`--only [child]`) after a prompt fix without `--force` regenerates nothing and ends on the line `Nothing regenerated: N frame(s) were already on disk`; read that line, never the exit code, and rerun with `--force`. **No "Proceed" question for a run the owner explicitly asked for, and no confirmation per variant.** The one money question is the cap: above `spend_cap_usd` the script refuses before any call, Wonka asks once ("This run estimates about $X, above the $10 cap. Run it anyway?"), and a yes re-runs it with `--cap` raised for that run only. Anything beyond the named batch (a re-run, a second attempt) gets its own estimate line the same way.

   Then run the pilot child only:
   ```bash
   python3 .claude/skills/variations/variations_run.py \
       "factory/Products/[product]/variations-work/manifest.json" --dry-run [--frames MAIN,PT02]
   python3 .claude/skills/variations/variations_run.py \
       "factory/Products/[product]/variations-work/manifest.json" --only [pilot-child] [--frames MAIN,PT02]
   ```
   Always `--dry-run` first and read the call list and the estimate out loud; that is the arithmetic check on the frame table. `--frames` restricts the run to the selected source (the same names on the dry run and the run). Pick the pilots deliberately: **one pilot per kind of change in the family (shape, colour, count)**; a successful colour edit says nothing about a structural change, so a colour pilot validates colour children only and a shape child needs its own pilot. After each pilot's "continue", that kind's batch runs under the cap and the routine-fix policy, no per-frame question.

   Open the pilot's frames beside their SOURCE frame and their VARIANT REFERENCE (`variations_qa.py --ref` puts the three on one sheet). **Three questions, in this order:** is the requested change there, is only that changed, is the product still itself. Then: is every printed value the TRUTH TABLE's value for this child, and does it match the tested composition it came from.

   **When it is wrong, the fix is the PROMPT in the manifest, not the image.** An edited pilot cannot propagate. Adjust the instruction and regenerate: **edit the manifest, then re-run with `--force`**, because without it the script keeps the old frame and reports `skip (exists)`, and a fixed prompt gets silently credited to an unfixed image. Try two or three distinct phrasings rather than nudging one repeatedly; prompt failures are structural, and three different attempts find the structure faster than five variations of one. Keep every attempt on disk with what was tried. **If three phrasings all fail the same way, the problem is upstream:** a missing shape reference, a reference that does not show the varying part, or a variant that is genuinely a different product. Say which you believe it is and ask for that input rather than trying a fourth phrasing.

   **One exception, and it is not a fourth phrasing.** When the prompt has landed the change and only a SMALL element is wrong (an icon, a label, an inset, a diagram detail, under about 200 pixels), the manifest is the wrong tool: a whole-frame edit leaves an element that size untouched (measured 14 September 2026: the PT04 FLOW icon survived two whole-frame edits on both children and landed on the first region edit). Land the frame and send it to `/fix`'s region route (step 7d: the region enlarged, edited at full resolution, composited back with 0 pixels changed outside the box), counted under the routine-fix policy's attempts limit, never resetting it and bypassing no approval. Then record the instruction correction it revealed in the manifest beside that frame's instruction (`"note": "FLOW icon: three stacked tiers, not the parent's four"`), so the batch and every re-run carry it: the fix is local, the lesson is in the manifest. **The note fixes nothing on disk.** It shapes the NEXT batch only; the other children's copies of that frame, already on disk, still carry the wrong element, and a whole-frame re-run leaves an element that size as it is. Each child's frame takes the region route once, its own box on its own file, and each is logged as its own attempt.

   Lay the pilot's frames out as a NUMBERED sheet first (`python3 .claude/skills/inspect/contact_sheet.py sheet "factory/Products/[product]/variations-work/pilot-sheet.jpg" "factory/Products/[product]/variations-work/working/[pilot child]"`, both paths from the kit root) and open the folder, so the look is given on tiles the owner can point at.
   **The owner's look at that sheet is the decision point: "continue", or a named fix.** No other gate stands before MODE 2. Then the rest of that kind's children run on the exact manifest that worked, unchanged:
   ```bash
   python3 .claude/skills/variations/variations_run.py \
       "factory/Products/[product]/variations-work/manifest.json"
   ```
   The script skips the finished pilot, resumes a rate-limited batch on re-run, chains shape into text per frame, pads non-square frames with headroom, **measures edge contact on every frame, retrying smaller when the product touches an edge**, and appends a run record to `variations-work/run-log.md` (children, frames, calls planned, frames written, calls made as paid API calls with a CLIPPED retry counted twice, failed, skipped, not attempted when a chain broke, the estimate and the price table date; OpenAI image edits report no per-call usage, so the estimate is calls x list price and the dashboard is the billed truth). The MAIN is the fragile frame: padded and asked to redraw its product, the model fills the square canvas and the crop back cuts the sides. The guard fires in practice; never ship a hero frame without its edge number.

8. **Type B, or no OpenAI key: the Genrupt path.** Use the Genrupt product-variations flow off the locked reference. Find it with `search_capabilities` and READ ITS INPUT SCHEMA before the first call: the fields below are DECISIONS, and the schema you just read decides how each one is spelled and whether that call carries it at all. Never add a field the schema does not declare; these schemas are strict and reject the whole call. All of these are mandatory as decisions:
   - **Pin the model wherever that call's schema accepts one.** An unspecified model is a model that can change under you, and a weaker engine renders text badly, which is fatal for swatches. Where a call has no model field, the engine came from the flow's own setup: say which, in the run record, rather than assuming.
   - Use the lowest resolution the tool exposes unless the owner asks otherwise.
   - Attach the approved reference asset id from `2-reference/reference-sheet.md` to every call, so every child inherits the product lock. Read the flow's references FIRST: an attached sheet shows as a `productImages` entry noted "Product Reference Sheet" (contract since September 2026). Attach only if it is missing, by id in `productReferenceSheetIds` with `mode: "merge"` and no `productImages` key, and never re-send the primary id once it is there (it re-runs the replacement). Wire the child's own slot `referenceImages` where the schema offers one without touching the plan-level ids; then read the plan back and count. There is no material-lock prose: describing the material or the shape in `customInstructions` is the words rule's failure, and the old "403, cannot attach" workaround of 21 August is dead (superseded 5 September 2026).
   - **Style and brand fit come from the branding preset (resolved from `status.md`) and the tested set's own look**, passed as structured fields where the flow accepts them. Never describe style, colors, graphics, or fonts in prompt prose, and never paste hex codes into a text field.
   - Gallery adaptations keep the approved scene: the people, props and layout of the source frame stay (Type A keeps the pixels; Type B casts the slot as the brief's People column says, same as the parent). The main follows the main rules in step 5.
   - **Vary ONLY the target attribute per call.** Composition, angle, lighting, and background are held constant across the family. If the tool exposes a seed or a base image, reuse the same one across the children.
   - Never instruct a third-party logo or an award badge render; the content checker fails the whole image.
   - Keep the whole compliance avoid-list off the swatches too: no star ratings, no review references, no invented percentages, no fake badges. A swatch is a label, not an ad.
   The pilot rule and the truth table apply on this path exactly as on Type A. Say the cost difference out loud once, with a REAL number from a live `get_credit_balance_and_costs` preview (`finalCreditsCost`, never a typed estimate): equal quality, credits instead of cents, and the Type B batch gets its own one-line pre-run report exactly like step 7's edit report. After the batch, read `get_credit_balance_and_costs` again and report the balance delta as the charge, distinct from the preview, in `run-log.md`.

9. **Run the measuring QA, then the two checks no number replaces.**
   ```bash
   python3 .claude/skills/variations/variations_qa.py \
       "factory/Products/[product]/variations-work/manifest.json" --ref
   ```
   Per frame it reports a `drift_score` over a 6x6 tile grid plus a source | generated | reference | drift-overlay contact sheet in `variations-work/qa/[child]/` (`--ref` adds the child's variant reference as the third tile where one exists). Every result is reviewed against its SOURCE frame and its VARIANT reference side by side, on the three questions: is the requested change there, is only that changed, is the product still itself. Read it correctly: **drift where the edit lives is the job; the same drift in the product, the logo, or an untouched claim is a defect.** Text edits drift low with no strong tiles; shape swaps drift high with many, and that is expected. The sheet's job is showing WHERE.

   Then, by hand, because every automated number in this room is blind to specific failures:
   - **Count the frames per child against the manifest.** One frame can die mid-batch on a one-off upstream error, and that line sits among dozens of successes. `working/[child]/` must hold exactly the planned frame list. A missing frame re-runs with `--only [child]`; the finished ones skip.
   - **OPEN every hero frame at full size and look at it.** This is the blocking gate, and it exists because it was skipped once: hero frames have shipped with the label card reshaped into an egg and its bands bleeding past the border while drift and edge contact both read fine. Check the label card (rigid, bands inside the border), the product (target silhouette, correct stack or count), and the words (every value is this child's truth-table value, nothing else reworded). A hero frame that fails any of these regenerates; it never ships with a note.
   - **The family overview.** Build the mains side by side, source first, one tile per child, labelled, and open the folder:
     ```bash
     python3 .claude/skills/inspect/contact_sheet.py sheet "factory/Products/[product]/variations-work/family-sheet.jpg" \
         "factory/Products/[product]/variations-work/source/[main]" "factory/Products/[product]/variations-work/working/[child-1]/MAIN.png" "factory/Products/[product]/variations-work/working/[child-2]/MAIN.png"
     open "factory/Products/[product]/variations-work"   # macOS; explorer on Windows
     ```
   Then the four-line report (step 7): what changed, the estimate, one line per child with its sheet path, what needs the owner's decision. The rest is in `run-log.md`.

10. **Land the finals with `variations_land.py`, and write nothing else there.** The naming is code, not memory:
    ```bash
    python3 .claude/skills/variations/variations_land.py "factory/Products/[product]" [child] real MAIN=[working/child/MAIN.png] PT03=[...]
    python3 .claude/skills/variations/variations_land.py "factory/Products/[product]" [child] concept MAIN=[...] SWATCH=[...]
    python3 .claude/skills/variations/variations_land.py "factory/Products/[product]" --plan
    ```
    A real child lands in `variations/` as `main-[child].png`, `[slot]-[child].png` (`pt03-round-10in.png`) and `swatch-[child].png`, the owner's own child names slugified. A concept child lands in `variations/concepts/[child]/` with `-concept` in every filename (`main-onyx-concept.png`) and a `CONCEPT.md` one-liner in the folder. `--plan` prints every landed path with its status for the plan's Outputs section. `variations/concepts/` is never inventoried as a child, never scored as one, and is excluded from upload packages unless subsequently confirmed for sale; a concept becomes a real child only by getting its own listing and a re-run as `status: real`. This room writes ONLY those names and `variations-plan.md` into `variations/`; the machinery stays in `variations-work/`. Never overwrite, never delete, never move: the helper lands a second attempt as `-v2` beside the untouched first, and surgical edits from `/fix` live in `edits/vN/variations/` snapshots, never inside `variations/`. Originals in `images/` and `edits/vN/` are never touched. **At the end, tell the owner where the files are, by path, one line per child.**

11. **Verify with evidence, not with confidence.** Open EVERY file you just landed with the Read tool and write ONE literal line per image (what is actually in frame). An image you did not open was not checked. For swatches, also make a picker-size copy and read THAT, because a swatch judged at full size is a swatch never judged at all:
    ```bash
    mkdir -p "factory/Products/[product]/scorecards/picker"
    sips --resampleWidth 60 "factory/Products/[product]/variations/swatch-[child].png" --out "factory/Products/[product]/scorecards/picker/swatch-[child]-60.png"   # macOS
    # Windows/ImageMagick: magick convert "factory/Products/[product]/variations/swatch-[child].png" -resize 60x "factory/Products/[product]/scorecards/picker/swatch-[child]-60.png"
    ```
    The copies live OUTSIDE `variations/` on purpose: that folder is inventoried by `/inspect` and its gate-passed files travel into `final/`, and downscaled proofs are neither deliverables nor candidates.

    You are looking for five catastrophic misses only:
    1. **Wrong or drifted product** against the Reference Sheet spec, part by part. Every part the spec lists must be present and countable.
    2. **Wrong count, wrong attribute, or wrong printed claim for that child** against the truth table. A two pack showing one unit, a size child at the wrong size, a shape child keeping the source's fit range.
    3. **A failed or empty generation, or a missing frame.**
    4. **The family does not read as siblings.** Put the mains side by side: a child at a different angle, height, light, or background is a family break.
    5. **A swatch that does not do its job at 60px.** If you cannot tell which child it is from the downscaled copy, it failed, whatever it looked like at full size.

    Do NOT score, do NOT rank, do NOT run the full 160px squint pass: that is the Inspection Room's job and duplicating it here just does it worse. Route what you find: wrong claims and family breaks are REGENERATE class (a manifest fix plus `--only [child] --force`), and enlarging swatch text is regenerate class too; product drift or a wrong count on ONE child goes to `/fix` first as a focused edit on that child's region under the routine-fix policy in `CLAUDE.md` (a small element such as an icon, a label or an inset takes `/fix` step 7d's region route, and the instruction correction is recorded in the manifest), and drift across several children is a manifest fix. Removing a stray element or swapping a word is a surgical edit. Offer any re-run with a fresh cost line.

12. **Write `variations/variations-plan.md`** in the Output format below: provenance, the confirmed child list with `source` and `status` per child, the selected source, the frame table and the truth table, the shared-versus-per-child map, the Amazon embedding map, every output path with its status (from `variations_land.py --plan`), and the generation record. On a MODE 2 run, APPEND a generation row; never rewrite the file and never touch an earlier row.

13. **Verify the artifacts exist before you claim anything.** List `variations/` and confirm one main, a swatch where one was asked for, and every planned propagated frame per confirmed child, with earlier files still present, plus `variations-plan.md`. Re-read the plan from disk to confirm it wrote. If a child is missing an image, the family is NOT complete: retry that image once (with its own cost line), and if it fails again, record the failure with its error in the plan, name the missing child to the owner, and leave the sub-status at `in progress`. Never fill a hole with another child's image, never rename to hide a gap, and never call the family done because most of it landed.

14. **Hand off to the Inspection Room, then record.** Tell the owner: "The family is out of the machines. Next stop is the Inspection Room: run /inspect before you fall in love with it." Ask for the variation checks by name (per child fidelity against the reference, truth-table values on every frame, family consistency, swatch legibility at picker size where a swatch exists). Nothing here is final and nothing is a candidate yet. **A clean scorecard is the Inspection Room's verdict, not the owner's acceptance.** After `/inspect`, show the results for review (the family sheet and the landed paths, one line per child) and take the owner's words per child; those words are the record. Then record in `status.md` under INVENT sub-status: `Children:` with the status and the owner's pick per child (kept / rejected / owed), and `Variations: [done | in progress ([what is owed])]`. On an approve-and-finish ("both sets approved, save everything and finish Day 9"): write in this ORDER, because `stage_gate.py` reads the LAST entry of `status.md` and a record written after `Next stage:` hides it: first the `Owner decision:` line in their words, the `Children:` record, the `Variations: family of [N], upscale: owed` line (step 15) and every other record; then, as the LAST line, `Next stage: Day 10, Shipping Room (session ended at the owner's word, [date])` carrying the outstanding Day 10 work (the owed upscale, every `assumed` claim still open, the A+ classification for the children). Suggest Day 10 as the next session in words, and stop: `/ready-to-upload` is never invoked from here, and "Ready for the Shipping Room?" is not asked on a stop. Day 10 packaging belongs to the next session; say so once.

15. **Only AFTER the family is gate-passed: record the owed upscale and hand off.** This step never runs on uninspected images, and this room never upscales.
    - **The family ships at the Shipping Room's resolution, not this room's.** The edit path outputs 1024px on the long edge (a padded hero crops back smaller still), a review artifact, not a shipping asset, and the REUSED frames copied from the live listing sit at 1024 to 1500 too. Record `upscale: owed` for the whole family (every propagated frame, every reused frame, once per shared frame) in `variations-plan.md` and on the Variations line of `status.md`: `Variations: family of [N], upscale: owed`. Note there that the owner's original masters are preferable for reused frames if they exist. Never present 1024px files as upload-ready.
    - **Hand off:** the Shipping Room upscales the family once, with the mains, on the files that ship. Say that sentence to the owner as-is, then, only when no stop stands and variations are done, ask once, like every room: "Ready for the Shipping Room?" A yes opens `/ready-to-upload`; a stop is a stop.
    - If the Shipping Room has already run (`final/` exists), copy the gate-passed family into `final/variations/` beside the rest of the approved package so its re-run finds the class in place. `variations/concepts/` is never inventoried as a child, never scored as one, and never copied into `final/`; a concept becomes a real child only by getting its own listing and a re-run as `status: real`. Otherwise leave the family in `variations/`; the Shipping Room resolves it from there.
    - This room never writes `tests/upload-pack.md`. The Shipping Room is its only writer: its re-run replaces the `Variations: pending (Day 9)` line with the real family, the embedding map and the finished upscale. Say so in the plan.
    - Say once more, plainly: this room produces the files and the map. The owner uploads them and wires the parentage in Seller Central. Wonka never touches the live listing, and the plan records what was produced, never a predicted result.

## Output format

`factory/Products/[product]/` after a run:

```
variations/
  main-round-10in.png
  swatch-round-10in.png
  pt01-round-10in.png
  pt03-round-10in.png
  main-square-10in-8set.png
  swatch-square-10in-8set.png
  main-round-10in-v2.png    (a regenerated child, beside its untouched first attempt)
  concepts/onyx/            (a concept child: a described finish the reference never showed)
    main-onyx-concept.png
    swatch-onyx-concept.png
    CONCEPT.md              (one line: a picture of a possible product, never a claim)
  variations-plan.md
variations-work/
  manifest.json             (the whole plan: frames, refs, every prompt, per-child deltas)
  source/                   (the tested set the family was built from)
  refs/                     (one shape reference per target silhouette)
  working/[child]/          (1024px drafts + [FRAME]_shape.png intermediates)
  qa/[child]/               ([FRAME]_qa.png contact sheets)
  qa-report.json
```

`variations/variations-plan.md`:

```markdown
# Variations Plan . [Product Name]

Built from: brief/creative-brief.md ([date], VARIATIONS section [matched / amended [date]: [reason]]),
2-reference/reference-sheet.md (LOCKED, smoke test PASS, source: [manual / amazon_scraped]),
factory/Brand/brand-kit.md ([on file / not available (owner)]),
edits source: [edits/v2/ / images/],
selected source: [the tested main only / MAIN + PT02 + PT03 / the whole tested set], from the recorded picks (Main pick: [main-13]; Gallery pick: [edits/v9, frames ...]), newest edits/vN copies[, sec-03-v3 revised after test, no re-run],
inherits composition from: [the Main pick: row, file main-13.png / reference sheet (no tested winner yet)].
Assumptions: [none / "[the owner's words, verbatim]" (owner, [date]); every truth-table value it drives is marked assumed].

Variation theme: [Color / Size / Shape / Scent / Flavor / Count or bundle]. Confirmed real by the owner [date].
Type: [A (edit path, OpenAI key) / B (regenerated, Genrupt)] . reason: [owner's reason, date].

## Frame table (from the tested set)
| Frame | Carries | Product count in frame | Per child? |
|---|---|---|---|
| MAIN | shape + count text + size text | 1 stack | yes, edit (shape + text) |
| PT01 | shape + count badge | 1 | yes, edit (shape + text) |
| PT02 | shape only | 1 | yes, edit (shape) |
| PT03 | shape only | 4 (four-panel grid) | yes, edit (shape, counted prompt) |
| PT05 | nothing variant-specific | 2 | REUSED, shared by the family |

## Truth table (per child, checked against that child's own source)
| Child | Shape | Count | Size label | Fit / claims | Parts that change / parts that keep their finish | Likeness |
|---|---|---|---|---|---|---|
| round-10in | round | set of 4 | 10" | [claims] | the plate body / the rim print | ref: live child main (shape truth only) |
| square-10in-8set | square (source) | set of 8 | unknown, kept from the source frame | [claims] | none / all | from source set |
| onyx (concept) | square (source) | set of 4 | 10" | none printed | the glaze / the foot ring | described: "in onyx"; a picture of a possible product |
| cascading (concept) | assumed same as parent (owner, demo assumption, [date]); not verified for B011RBDCJQ | assumed | assumed | assumed | the tier profile / everything else | asin-reference B011RBDCJQ (shape truth only) |

## Children
| Child | Source | Status | Attribute value | Main | Swatch | Propagated frames |
|---|---|---|---|---|---|---|
| round-10in | asin | real | shape: round | main-round-10in.png | swatch-round-10in.png | pt01, pt02, pt03, pt04 |
| square-10in-8set | asin | real | count: 8 | main-square-10in-8set.png | swatch-square-10in-8set.png | pt01 |
| onyx | described | concept | finish: onyx | concepts/onyx/main-onyx-concept.png | concepts/onyx/swatch-onyx-concept.png | none |
| cascading | asin-reference | concept | shape: cascading tiers | concepts/cascading/main-cascading-concept.png | not asked for | pt03 |

## Outputs (every path, with its status; concepts are excluded from upload packages unless subsequently confirmed for sale)
- `variations/main-round-10in.png`: real
- `variations/pt03-round-10in.png`: real
- `variations/concepts/onyx/main-onyx-concept.png`: concept

## Shared versus per child
- Per child (must exist for every child): the main image, the swatch where one was asked for, every frame the frame table marks variant-carrying.
- Shared across the family: the REUSED frames, and only the A+ modules with nothing variant-specific. Shared frames are listed once here, upscaled once by the Shipping Room, and copied into each child's upload set.
- A+ modules, classified like frames: [module: shared / per child / excluded for [child], with the reason: shows the shape, a changed dimension, a changed instruction].

## Amazon embedding
- Theme: [the one dimension, or two if the category allows]. Children: [N].
- Structure: a non-buyable parent holds the child SKUs; the shopper lands on the parent and picks a child.
- Per-child images: each child SKU carries its own main and its own gallery (mapped above), so the gallery updates when the shopper switches. A buyer who picks the two pack and sees one unit was told something untrue before she paid.
- Swatches: one picker thumbnail per child where one was asked for, mapped to its SKU. Whether this category draws an image swatch or a text button is visible in the live listing; the file is produced where one was asked for.
- Wiring: the exact theme names and the parentage screens live in the category's own template in Seller Central. This map says WHAT to produce; the owner wires it there.

## Generation
| Date | Mode | Path | Model | Calls/Images | Est. cost | Approved | Notes |
|---|---|---|---|---|---|---|---|
| [date] | pilot | edit (OpenAI key) | gpt-image | 6 calls | cents | brief ([date]) | pilot: round-10in; 2 prompt rounds on the MAIN, winning phrasing in manifest |
| [date] | full family | edit (OpenAI key) | gpt-image | 14 calls | cents | brief ([date]) | [failures, retries, derived likeness, edge-contact retries] |
| [date] | upscale | owed to the Shipping Room | - | [N] frames | 0 here | - | `upscale: owed`, reused frames included; runs once in /ready-to-upload with the mains |
```

## Golden Standards check

Before handing off, verify:
- [ ] Brief, locked reference (with a PASSED smoke test), and the tested-set source folder were confirmed BEFORE generating; any hard miss was reported as BLOCKED, not worked around. A missing brand kit was recorded as an explicit gap, never invented.
- [ ] The child list was confirmed by the owner in this run with `source` and `status` per child, nothing outside it was generated, and every concept is labelled `concept` in its folder, its filenames, the plan and `status.md`. "None" and "I don't know" were handled as first-class answers, not papered over.
- [ ] Where the confirmed list differed from the brief, the brief was AMENDED first, dated and reasoned, before a single cent was spent.
- [ ] The frame table was written by OPENING every source frame (with its product count), and the truth table from each child's OWN listing; no claim was carried across from the source. Frames carrying nothing variant-specific were REUSED, not regenerated.
- [ ] The scope line and the estimate were said before the run, the run stayed under `spend_cap_usd` or the owner answered the one cap question, and no per-variant confirmation was asked. Re-runs got their own estimate line.
- [ ] On a first family the pilots ran FIRST, one per kind of change (shape, colour, count), each checked against its source and its reference, and the owner's look at each sheet ("continue" or a named fix) was the only gate before that kind's batch. Prompt fixes were made in the manifest and re-run with `--force`, never by editing the pilot image; a small element fixed by `/fix`'s region route after landing had its instruction correction recorded in the manifest.
- [ ] Every child has a main that inherits the tested main as it is (its tactic included), a swatch where one was asked for, and every planned propagated frame. Only the target attribute varies across the family, A+ modules were classified per child or shared with a reason, and a bundle is a true arrangement of real units.
- [ ] No real child asserts a capacity, material, finish, count, or fit its own source does not support; unknown printed values were kept from the source frame or removed, never invented. The compliance avoid-list holds on swatches too.
- [ ] Type A path: dry-run read before the batch, edge contact measured on every frame, drift QA run and read as located drift, frames counted per child against the manifest, and EVERY hero frame opened at full size (card rigid, silhouette right, words right). Genrupt path: every call made against a schema that was READ first, model pinned, reference asset attached, one attribute varied per call.
- [ ] Every landed file was opened with Read and has a literal one-line description; every swatch was read at 60px; the mains were compared side by side for family consistency.
- [ ] Only `main-*`, `swatch-*`, `[slot]-*`, `concepts/[child]/*-concept.png` with their `CONCEPT.md`, and `variations-plan.md` were written into `variations/`, through `variations_land.py`; the machinery stayed in `variations-work/`. No original overwritten, deleted, or moved; picker proofs live outside the folder; the owner was told every path, one line per child.
- [ ] `variations/` was listed and matches the confirmed child list and the frame table, or the missing images are named to the owner and recorded with their errors; `variations-plan.md` was re-read from disk.
- [ ] The owner was pointed to the Inspection Room with the variation checks named, and no child was called final. A clean scorecard was shown for review, not treated as acceptance; on an approve-and-finish the records and the `Next stage:` line were written and nothing was invoked; an explicit skip triggered no offer and no run. The results line counted API calls, not frames passed inspection, and the estimate was called an estimate. Upscaling (including the reused frames, to 1600px+) ran only AFTER the gate passed, and `output/` and the upload pack were extended only after that.

## Wonka lines

Openers:
- "The Variations Room. One brief, many flavors, and every one must taste like the same factory made it."
- "Give me the family any way you have it: the ASINs, a sentence, the photos. A colour you only described gets made and labelled a concept, and a concept is not a claim."
- "Nine days bought you one tested winner. This is the room where that stops being expensive."

Refusals (say them plainly, without drama):
- "A colorway you only described is a concept, and it says so on the file. The moment it is a real SKU with its own listing, it becomes a real child."
- "If the plan changed, the plan gets rewritten. Dated, with the reason. Then, and only then, the machines run."
- "I will not guess what the eight pack claims. Its own listing knows. We read, then we print."

Closers:
- "Same light, same angle, same composition that won. One family, one visual language, and not a stranger among them."
- "Every frame that did not need to change did not change. That is not laziness, that is the whole trick."
- "Mains and the frames that carry the difference, one set per child, mapped to their SKUs. Where a swatch was asked for, look at it at the size it actually renders; that is the only size that matters."
- "Consistent to the last chip. Nothing ships until the Inspection Room signs it. Onward to /inspect."

## Definition of Done

One of two honest end states, never a third.

**Generated:**
- Every confirmed child has a per-child main, a swatch where one was asked for, and every frame the frame table marked variant-carrying, in `variations/`, verified by listing the folder; any image that failed twice is named to the owner and recorded with its error, and the family is NOT called complete.
- `variations/variations-plan.md` exists and was re-read from disk, carrying provenance (brief state, reference source, brand kit state, edits source, the selected source, inherited composition, TYPE with its reason), the frame table, the truth table with checked values, the confirmed child list with `source`, `status` and likeness notes, the shared-versus-per-child map, the Amazon embedding map, every output path with its status, and the generation record.
- Where the plan changed, `brief/creative-brief.md` carries the dated, reasoned amendment.
- On the edit path: the manifest is on disk in `variations-work/` with every prompt that ran, the QA report and contact sheets exist, frames were counted per child, and every hero frame was opened at full size.
- Every landed file was opened and described, every swatch was read at picker size, and the five catastrophic-miss checks ran with anything found routed correctly.
- Every original is untouched on disk, and the owner was explicitly handed to `/inspect` with nothing presented as final. `upscale: owed` was recorded only after the gate passed; nothing was upscaled here and `tests/upload-pack.md` was not touched.
- `status.md` carries the `Children:` record (status and the owner's pick per child: kept / rejected / owed) and `Variations: [done | in progress ([what is owed])]`; A+ modules are mapped shared or per child in the plan. On the owner's stop, the `Next stage:` line was written and nothing was invoked after it; "Ready for the Shipping Room?" was asked only when no stop stood and variations were done.

**Not applicable or blocked:**
- `n/a`: the owner confirmed the product is a single SKU and asked for no concept. Recorded in `status.md` with the date, no folder faked, no claim invented, the rest of the package unaffected.
- `blocked`: the child list is unconfirmed. Recorded with the exact question and the two places to answer it, and the owner told plainly that nothing else is held up.

## Update status.md

In the INVENT sub-status block, set `Variations (/variations): done` (or `in progress` if the family is partial or a child is still owed, or `n/a (product has no variations)` with the owner's confirmation date, or `blocked: [precondition or "child list unconfirmed"]`). Artifact `variations/` + `variations/variations-plan.md`. An explicit skip is ALSO written as a Log line, `Variations: skipped (owner, [date])`, in the owner's words; that line is what `stage_gate.py` reads as complete, and `pending` never is. When the child list was answered in chat, write it under INVENT sub-status too (`Type: A|B ...` and `Children: ...` with `source` and `status` per child), so a resumed session reuses it and asks nothing.

Then check the whole INVENT sub-status block: when all four sub-parts (Main image, Secondary images, A+, Variations) are `done` or `n/a` with a reason, set the INVENT station row to `done`; otherwise leave it `in progress`. If an earlier run left the lawful trailing marker `Variations: pending (Day 9)`, this run replaces it.

Log lines, one of:
- `[date] Variation family generated: [N] children ([R] real, [C] concept), type [A/B] on [edit path / genrupt], [M] calls, estimated [est] under cap [cap], source [selected source, from the pick rows], inherits [Main pick file], reference source [manual/amazon_scraped][, brand kit not available]. Awaiting inspection.`
- `[date] Child [name] regenerated ([driver]) via manifest fix + --force, cost reported [est]. Awaiting re-inspection of the family.`
- `[date] Variation family gate-passed: [N] frames, upscale: owed (reused frames included). The Shipping Room upscales it with the mains and extends the pack.`
- `[date] Variations: skipped (owner, [date]). [The owner's words: single SKU / not for this product.] INVENT sub-part consciously skipped; on this line Wonka asks once "Ready for the Shipping Room?" and a yes opens it, ONLY when the skip came without a stop. A skip that carries a stop ("single SKU, we'll do Day 10 in a new session") is a stop: nothing is asked, the session ends at the owner's word.`
- `[date] Variations: blocked, child list unconfirmed. Owner to check the listing's variation picker or Seller Central parentage. Rest of the package proceeds.`

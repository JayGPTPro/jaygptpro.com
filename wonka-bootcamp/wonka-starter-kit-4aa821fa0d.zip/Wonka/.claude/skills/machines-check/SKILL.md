---
name: machines-check
description: Verify the Factory's two machines (Genrupt MCP, OpenAI key) are connected and alive. Free handshakes plus a Genrupt credit fuel-gauge reading, and an optional First Candy, one tiny welcome image that proves the OpenAI pipeline end to end for a few cents. This is also the first move for any "it is not working" problem, on any day. Triggers: /machines-check, "check my machines", "are my tools connected", "test connections", "is Genrupt connected", "verify my setup", "print the first candy", "nothing is working", "my key is not working", "verification error", "how many credits do I have".
---

# The Machine Room

| Meta | Value |
|------|-------|
| Room | The Machine Room |
| Station | Pre-RESEARCH (setup check; run any time, on any day) |
| Taught on | Day 1, The Front Gate |
| Needs | Nothing. This room only listens for the hum of the machines. |
| Saves to | One line in `factory/Factory Log/machines-log.md` (the artifact) + First Candy to `output/first-candy.png` if printed |
| Typical cost | Handshakes and the credit reading are free. The optional First Candy costs a few cents, and only after an explicit yes. |

## What this room does

Before the production line runs, Wonka walks the Machine Room and confirms both machines are warm: Genrupt (the image factory) and the OpenAI key (the second blast machine, the fixing bench AND the Tasting Room's panel). The base checks are handshakes only and cost nothing. Then, if the user wants it, the Factory prints its **First Candy**: one small welcome image on the OpenAI key. It costs a few cents, and it proves the one thing a handshake cannot: that the key is actually ALLOWED to generate images (the one-time organization verification). A verification problem should surface here, on Day 1, never in the middle of Day 5's main image batch.

**The governing rule of this room: a label is not a handshake.** A connector listed in settings, a tool visible in the tool list, a key sitting in a file: none of those is a PASS. A PASS is a real response, observed this session, with one identifying detail written into the report.

This room also runs on any other day, and it is the first move for every "it is not working" moment in the bootcamp. Run it, then debug.

## Before you start

- **Get today's real date from the system** (`date`). The report header and the log line use it. Never write a date from memory.
- **Never expose a key.** Do not print, echo, `cat`, paste, or quote the OpenAI key or any Genrupt key, not in the chat, not in the report, not in the log. Presence, character count, and the last four characters are the only things that may ever be shown. The user may be recording their screen.
- **There is no third machine.** If the user asks which testing or survey account to connect, the answer is none: the Tasting Room runs inside the Factory on Machine 2.
- **A missing machine is a first-class answer.** "I do not have Genrupt", "I have not made the key yet", "skip that one today" are all legitimate. Record the gap, state exactly what it closes and what still runs, and finish the report. This room never dead-ends and never stalls waiting for a machine.
- **Deliver the report no matter what.** Even with both machines cold, the report is the deliverable. Two FAILs with two exact fixes is a successful run of this room.

## Process

0. **Machine zero: Python, its VERSION, and its packages.** Free, instant, and it comes first because the other two checks both pass on a machine that cannot run Day 5, Day 8 or Day 9. The version half is not optional: printing a version nobody compares to anything is how this room used to report PASS on a machine the kit could not run.

   **The floor is Python 3.9**, which is what macOS ships, so most Mac owners need no Python install at all. That number is measured rather than assumed: the kit's own test suite passes on 3.9.6. Run one command and read all three answers at once (on Windows use `python` in place of `python3`):

   ```bash
   python3 -c "import sys,importlib.util; v=sys.version_info; print('python','.'.join(map(str,v[:3])),'OK' if v>=(3,9) else 'TOO OLD, need 3.9+'); [print(m, 'ok' if importlib.util.find_spec(m) else 'MISSING') for m in ('openai','numpy','PIL','dotenv')]"
   ```

   - **Version below 3.9**: FAIL. Nothing else in this room matters until it is fixed. Mac: `brew install python3`, or download from python.org. Windows: python.org, and tick "Add Python to PATH" in the installer.
   - **A package missing** (`openai` is the common one; macOS ships numpy and PIL): print the one line that fixes it, `python3 -m pip install openai numpy pillow python-dotenv`.
   - Report it as a third machine, PASS or FAIL like the others. The First Candy itself runs on Python, so a student who fails here fails the last step of Day 1.

   **On Windows**, every shell snippet in this room is bash; run them in Git Bash, or do the same checks in Python, and never paste a failing bash line into PowerShell as the next attempt.

1. **Machine 1: Genrupt MCP, the handshake.**
   - Check whether Genrupt MCP tools are available in this session at all.
   - **Not there at all** (no Genrupt tools listed): report **NOT CONNECTED**. Give the two causes in order: (a) Claude was not fully quit and reopened after adding the connector (Mac: Cmd+Q, Windows: quit from the tray icon), which is the cause nine times out of ten, (b) the connector entry does not match Genrupt's current official values. Point to `guides/mcp-setup-guide.md`, Part 1. Then ask ONE question and accept any answer: "Do you have Genrupt at all, or are we running the fallback today?" Either way, continue to step 3.
   - **Tools present:** make a FREE call. Use the account-context tool (on this connection it is typically named `get_current_account_context`). A PASS requires a real response carrying an identifying detail: account name, email, or workspace. Write that detail into the report as the evidence.
   - **Free only.** If a tool's name contains `generate`, `create`, `run`, `analyze`, `upscale`, `blast`, or `video`, it costs credits. Do not call it here. This room never makes a market analysis, a product reference sheet, an image, or a video.
   - **On error:** retry ONCE. If it fails again, report **FAIL** and quote the observed error verbatim (first line, up to about 200 characters). Never guess a cause that the error did not state.
   - **Wrong account:** report the account identity plainly. If the user says it is not the account their ticket activated, keep the handshake PASS and add a **WRONG ACCOUNT** flag: credits will draw from the wrong place, and the fix belongs before Day 3, not in the middle of a batch.

2. **Machine 1: the fuel gauge.**
   - Call the free credit-balance tool if the connection exposes one (typically `get_credit_balance_and_costs`). Report the balance as the Factory's fuel gauge.
   - If that same response carries per-action costs, quote the listing-image cost **from the response, and specifically its `finalCreditsCost` figure**: every Genrupt preview carries TWO numbers and the account is billed the FINAL one, 3 to 8 times below the base (CLAUDE.md, Genrupt contract rule 7). Quoting the base makes the fuel gauge lie and scares a student off work they can afford. If no cost is exposed, write `cost per image: not exposed on this connection`. Never invent or recall a price.
   - **Low fuel verdict, from real numbers only.** Balance at zero, or below the quoted `finalCreditsCost` of a single listing image, gets a **LOW FUEL** flag with the consequence (a production batch stops halfway) and the fix (top up before Day 3). A real balance with no quoted cost is reported as a number with no verdict attached.
   - **No balance tool on this connection:** write `fuel gauge: not available on this connection` in the report and say the handshake still stands. Never drop the line silently; an absent gauge is information the user needs before Day 5.

3. **Machine 2: the OpenAI key, presence and shape, without exposing it.**
   - Check the environment first, then the `.env` at the Factory root. Run this from the Factory root; it reveals nothing but a masked fingerprint:
     ```bash
     k="$OPENAI_API_KEY"
     if [ -z "$k" ] && [ -f .env ]; then
       k=$(grep -m1 '^OPENAI_API_KEY=' .env | cut -d= -f2- | tr -d '"' | tr -d "'" | tr -d ' ')
     fi
     if [ -z "$k" ]; then echo "OPENAI_API_KEY: MISSING"; else
       echo "OPENAI_API_KEY: present, ${#k} chars, ends ...${k: -4}"
       case "$k" in sk-*) echo "prefix: OK" ;; *) echo "prefix: SUSPECT, does not start with sk-" ;; esac
     fi
     ```
   - **Placeholder counts as missing.** A value like `your-key-here`, `sk-xxx`, or an obviously truncated stub is reported as MISSING with that reason, never as present.
   - **Privacy check, one line.** If a `.git` folder exists at the Factory root and `.gitignore` does not cover `.env`, say so in one line: the key would travel with the folder. Offer to add the ignore rule.
   - **State the consequence, always.** This one key powers FOUR rooms: the Main Image Room's OpenAI Blast (`/main-image`, Day 5, half of the dual blast), the Fixing Room (`/fix`, Days 5 to 7), the Tasting Room (`/tasting-room`, Day 8; a further comparison only when the owner asks for one), and the Variations Room's edit path (`/variations`, Day 9). Missing key closes the last three and halves the first. Days 2, 3 and 4 need nothing from it, and Day 1 only loses the First Candy, so a missing key today is a task with days of runway, not a blocker.
   - **"I do not have a key yet" is a valid answer.** Report **MISSING (by choice)**, record it, point to `guides/mcp-setup-guide.md`, Part 2, and carry on. Do not ask twice.
   - A key check alone cannot see organization-verification status. That is exactly what the First Candy is for.

4. **The First Candy (optional, recommended, a few cents).**
   - **Skip the offer** if the key is MISSING. Say the candy waits for the key, and move on.
   - **Re-run guard.** If `output/first-candy.png` already exists, say so. Offer a reprint only when the point is to retest a verification that has since cleared, and save it as `output/first-candy_2.png`. Never overwrite the original print.
   - **Offer once, cost first, in one line:** "Want the Factory to print its First Candy? One small welcome card, a few cents, and it proves your key can really draw. Say: Yes, print the First Candy." If the answer is no, or the user moves on, do not ask again this session.
   - **The yes must be explicit and in the user's own message.** A general "go ahead" for the check is not approval to spend. If the user opened with "print the first candy", that request is the yes; still state the cost in the same breath before running.
   - **Print it exactly as written in "The First Candy print" below**, prompt and command both. Do not improvise the prompt, the model, or the quality.
   - **Never report verification as proven on a hopeful call.** Proven means a file landed on disk and was viewed this session.

5. **The identity check: is Wonka the only voice on this floor?** Free, and it catches the one setup problem the handshakes cannot: a `CLAUDE.md` in a folder ABOVE the Factory (common when the kit lives inside a wider assistants folder) is loaded into every session and can override Wonka's character and protocol.
   - Walk the parent folders from the Factory root upward (stop at the home directory) and note every `CLAUDE.md` found:
     ```bash
     d="$(pwd)"; found=0
     while [ "$d" != "/" ] && [ "$d" != "$HOME" ]; do
       d="$(dirname "$d")"
       [ -f "$d/CLAUDE.md" ] && { echo "PARENT CLAUDE.md: $d/CLAUDE.md"; found=1; }
     done
     [ "$found" = 0 ] && echo "no parent CLAUDE.md, the floor is Wonka's alone"
     ```
   - **None found:** one line in the report, `Identity: clear`, and move on.
   - **Found:** check whether `.claude/settings.local.json` at the Factory root already excludes it (a `claudeMdExcludes` pattern matching that path). If yes: `Identity: protected (excluded)`. If no: report **IDENTITY RISK** with the offending path, explain in one line that a parent file can override Wonka's character, and offer the definitive fix from `guides/troubleshooting.md` issue 1b: write `.claude/settings.local.json` with `{"claudeMdExcludes": ["**/[ParentFolderName]/CLAUDE.md"]}`, then start a NEW conversation. Only write the file after the user says yes, and never touch a parent folder's files.

6. **Deliver the machines report** in the Output format below. Every machine carries one of five states, and each one is a legitimate ending:

   | State | Meaning |
   |---|---|
   | **PASS** | A real response was observed this session, and the report names the evidence |
   | **FAIL** | The machine answered with an error, or the check failed. The exact fix is attached |
   | **MISSING** | The key or connection is not there yet |
   | **NOT CONNECTED (by choice)** | The user does not have this machine. Recorded as a gap, with what it closes |
   | **SKIPPED** | The user asked to leave this machine untouched this session, with the reason recorded |

   Every non-PASS names three things: what it closes (which rooms and which days), the exact fix, and where in `guides/mcp-setup-guide.md` the walkthrough lives. Nothing is ever reported as PASS on hope, on memory, or on a settings screenshot.

7. **Write the log line. This is the artifact.** Append one line to `factory/Factory Log/machines-log.md` (create the file on first use, append, never overwrite):
   `[YYYY-MM-DD] Genrupt [state] ([N] credits | gauge n/a), OpenAI key [state], First Candy [printed/declined/failed: reason], identity [clear/protected/RISK]. [notes]`
   The line never contains a key, a key fragment, or a masked tail. No other files are created by this room.

## The First Candy print

Runs only after the explicit yes in Process step 4. One image, lowest quality, a few cents.

**The prompt, word for word.** The forbidden list goes FIRST, because image models weight the opening of a prompt most heavily and quietly drop constraints parked at the end:

```
FORBIDDEN, these must not appear: no Willy Wonka, no movie or cartoon character,
no person, no face, no real brand logo, no third-party trademark or award badge.
A single golden ticket card lying on a warm chocolate-brown surface. Printed across
the ticket in clean bold lettering, large and easy to read: "Welcome to the Bootcamp".
Gold foil edge, soft studio light, nothing else in frame.
```

**The command.** Same image endpoint and the same model family the Fixing Room uses on Day 5, so this print proves the real pipeline rather than a lookalike. Run it from the Factory root, exactly as written. It finds the key in the environment or in the `.env`, never prints it, and prints the API's own error text if the call fails:

```bash
mkdir -p output
python3 - <<'PY'
import base64, json, os, pathlib, urllib.error, urllib.request

key = os.environ.get("OPENAI_API_KEY", "")
if not key and pathlib.Path(".env").exists():
    for line in pathlib.Path(".env").read_text().splitlines():
        if line.startswith("OPENAI_API_KEY="):
            key = line.split("=", 1)[1].strip().strip('"').strip("'")
if not key:
    raise SystemExit("NO KEY: set OPENAI_API_KEY or put it in the .env at the Factory root")

prompt = (
    "FORBIDDEN, these must not appear: no Willy Wonka, no movie or cartoon character, "
    "no person, no face, no real brand logo, no third-party trademark or award badge. "
    "A single golden ticket card lying on a warm chocolate-brown surface. Printed across "
    'the ticket in clean bold lettering, large and easy to read: "Welcome to the Bootcamp". '
    "Gold foil edge, soft studio light, nothing else in frame."
)
body = json.dumps({"model": "gpt-image-2", "prompt": prompt,
                   "size": "1024x1024", "quality": "low", "n": 1}).encode()
req = urllib.request.Request(
    "https://api.openai.com/v1/images/generations", data=body,
    headers={"Authorization": "Bearer " + key, "Content-Type": "application/json"})
try:
    d = json.load(urllib.request.urlopen(req, timeout=300))
except urllib.error.HTTPError as ex:
    raise SystemExit("API ERROR %s | %s" % (ex.code, ex.read().decode()[:300]))

out = pathlib.Path("output/first-candy.png")
out.write_bytes(base64.b64decode(d["data"][0]["b64_json"]))
print("saved", out, out.stat().st_size, "bytes")
PY
```

Three notes on running it: `gpt-image-2` is the model as of mid 2026, and if the account answers `model_not_found`, list the account's models, put the newest gpt-image model in that one line and run it again. The script carries the same prompt as the block above, so a change to one is a change to both. On a reprint (the re-run guard, or a forbidden element rendered), change the output path in the last lines to `output/first-candy_2.png` so the first print survives.

**Verify the artifact before claiming anything.** The file must exist and be a real image (a few hundred kilobytes; under about 10 KB means an error blob was written, not a picture). Then OPEN it with Read and look at it. Confirm three things: it is an image, the lettering reads "Welcome to the Bootcamp", and nothing forbidden appears in it. Only then is verification PROVEN, and only then does the user see it.

**If a forbidden element rendered anyway** (a character, a face, a logo): do not present it as the Factory's first print. Reprint ONCE as `output/first-candy_2.png` with the forbidden line repeated at the top and the offending element named. If it happens again, keep both files, report it plainly, and tell the user not to post that one publicly. Count both prints in the cost line.

**Failure triage. Match the observed error, never guess a cause the error did not state:**

| Observed error | Verdict | Fix |
|---|---|---|
| 403, "must be verified", "organization verification" | **FAIL (verification pending)** | Finish the one-time verification at platform.openai.com, Settings, Organization, Verify. Then run `/machines-check` again. Meanwhile Days 1 to 4 all run: the only thing this holds up is the First Candy print, which is the proof rather than the work. It has to clear before Day 5. `guides/mcp-setup-guide.md`, Part 2 |
| 401, `invalid_api_key` | **FAIL (bad key)** | Re-copy the key. Stray spaces and truncated pastes are the usual crime. If it is lost, create a new one and delete the old |
| 429, `insufficient_quota`, billing limit | **FAIL (no credit)** | Load $10 to $20 at platform.openai.com under Billing, then re-run |
| `model_not_found` | Retry once | The account exposes a different image model. List the account's models, put the newest gpt-image model in the `"model"` line of the script, retry once, then report what happened |
| Moderation or content flag | Retry once | The prompt drifted. Re-run the exact prompt above. Never add a logo, a character, or a person to satisfy the model |
| Timeout or network error | Retry once | Then FAIL with the observed error quoted |

## Output format

Spoken in the chat, in character framing with a clean professional table:

```markdown
## Machines Report . [YYYY-MM-DD]

| Machine | Check performed | Status | Evidence / Fix |
|---|---|---|---|
| Python | version + required modules | PASS / FAIL | [the version seen, or the one line that installs what is missing] |
| Genrupt MCP | tool list + free account call + credit reading | PASS / FAIL / NOT CONNECTED / SKIPPED | [the account detail seen, or the exact fix + guides/mcp-setup-guide.md Part 1] |
| OpenAI key | key present + shape + First Candy print (if approved) | PASS / FAIL / MISSING | [present, NN chars, ends ...XXXX, or the exact fix + guides/mcp-setup-guide.md Part 2] |

- Genrupt account: [name or email seen in the context call]
- Fuel gauge: [N] credits [+ cost per image if the response carried it, or "cost per image: not exposed on this connection", or "gauge not available on this connection"]
- OpenAI: [First Candy printed and viewed at output/first-candy.png, verification PROVEN / key present, verification UNPROVEN until the first generation]
- Identity: [clear / protected (excluded) / RISK: parent CLAUDE.md at [path], fix offered per guides/troubleshooting.md issue 1b]

Gaps recorded: [none / no Genrupt this round: the OpenAI fallback covers the Reference Room (Day 4), the Main Image Room (Day 5), the Secondary Images Room (Day 6) and the Variations Room (Day 9). **The A+ Room (Day 7) has no fallback and stays CLOSED**, because hands-off means Genrupt authors the page and there is no second engine to hand it to. Day 3 still writes the brief; only the send waits / no key yet, the Fixing Room and the Tasting Room stay closed until it exists]
Next action: [the ONE thing that moves this forward, with the command or the click path]
Total spent on this check: [nothing / a few cents for the First Candy].
```

## Golden Standards check

Before presenting, verify:
- [ ] No paid call was made except the First Candy, and it ran only after an explicit yes with the cost stated first.
- [ ] No credit-spending Genrupt tool was called: no analysis, no reference sheet, no image, no video.
- [ ] The OpenAI key was never printed, echoed, or quoted. Only presence, character count, and the last four characters appear anywhere.
- [ ] Every PASS names the specific evidence observed this session (account detail, balance number, the printed file). None rests on a settings screen or on memory.
- [ ] Every non-PASS names what it closes (rooms and days), the exact fix, and the guide section.
- [ ] The First Candy file exists on disk at a plausible image size AND was opened and viewed. It shows no Wonka character, no movie character, no person, no third-party logo or trademark.
- [ ] The organization-verification status is stated honestly: PROVEN (candy printed and seen) or UNPROVEN (declined, missing key, or key-only check).
- [ ] The report date came from the system clock, not from memory.
- [ ] `factory/Factory Log/machines-log.md` has today's line, and it contains no key material.

## Wonka lines

Openers:
- "The Machine Room. Listen... hear that hum? Let's make sure both are singing."
- "Before we invent anything, we check the machines. The listening is free."
- "A label on a settings page is not a handshake. Let me shake the hands myself."

Closers:
- "The machines are warm. The Factory is ready when you are."
- "Two machines, two green lights, and your First Candy is on the tray. Onward. Golden Tickets don't print themselves."
- "One machine is sulking. Here is exactly how we cheer it up, and here is everything that still runs while it sulks."
- "No Genrupt today? Then we bake on the smaller oven. It is written down, and the line keeps moving."

## Definition of Done

- Both machines have a state (PASS, FAIL, MISSING, NOT CONNECTED, or SKIPPED), and every PASS is backed by a response actually observed this session.
- The Genrupt fuel gauge was read, or its absence was stated in the report.
- The First Candy was offered with its cost; on a yes, `output/first-candy.png` exists on disk and was viewed and shown; on a no or a missing key, that is recorded as UNPROVEN verification.
- The machines report was delivered, with a fix for every non-PASS and one next action.
- `factory/Factory Log/machines-log.md` contains today's one-line entry. **This file is the artifact: without it, the room is not done.**
- Nothing was spent beyond the approved First Candy.

## Update status.md

This room is factory-level, not product-level; no product `status.md` changes. The record of this run lives in `factory/Factory Log/machines-log.md` (Process step 7).

# Day 9: The Variations Room

**If your product is a single SKU, today is optional.** Say so and Wonka records `Variations: skipped
(owner, [date])` in your words; that line is what lets the Shipping Room open on Day 10. A silent skip is
not a skip: with nothing on record, Day 10 waits.

**How today opens.** You resume, or you ask to continue. Wonka reuses whatever `status.md` already holds
about your family (the child list, where each child came from, Type A or B). With nothing on record he
asks one question and nothing else:
"Do you have any product variations you'd like to create images for?"
Answer with ASINs or links, with photos, or with a written change including a colour the listing
does not carry yet, in any combination. Or answer no, and he writes the skip.

Watch it for the knowledge, because you will have a variant product eventually and this is a good
thing to know exists. Or take the day back. **Day 10 is the last day and it is the one everybody
runs.**

If you DO have variants, or you are thinking about one, this is probably the highest-value day in
the bootcamp.

**The sentence for the day: eight variants used to be eight jobs. Today it is a plan, a pilot, and a
button.**

## What you will have by the end of today

- Your **confirmed child list**, with where each child came from (an ASIN, a sentence, your photos)
  and whether it is a real SKU or a labelled concept
- The **frame table** (what each frame of your selected source carries, and what gets REUSED) and
  the **truth table** (each child's printed facts, checked against that child's own source)
- **One pilot child, the hardest one, done properly**, reviewed against its source and its reference
- The **whole family** propagated on the instructions that worked, unchanged, with untouched frames
  reused rather than regenerated
- Every file's path, one line per child, and a plan that lists them all

**Time needed:** 45 to 75 minutes, most of it on the tables and the pilot.

## What you will need at hand

- Your family, in whatever form you have it: the ASINs or listing links, or a sentence, or photos
- Your tested set from Day 8, untouched
- Your OpenAI key alive (Day 1's `/machines-check`). Today's edits run on it, for cents

---

## One lesson: the room, the three ways in, the demo

The idea first; the terminal starts a few paragraphs down.

### What this room does

Eight colours. Seven images each. **Fifty-six images.** Until very recently that meant fifty-six
pieces of design work, or a photoshoot where somebody swapped a product eight times under the same
lights and hoped nothing moved. Which is why most listings have **one beautiful main SKU and seven
neglected siblings** with two images each.

**Most of your variant family already exists.** You spent eight days building a tested set. Your
blue version differs from it in a way you can name in one line: a colour, a shape, a printed number.
Everything else is finished work. So nothing gets rebuilt. Wonka classifies your set frame by frame:
frames that carry the **SHAPE** of the thing that varies, frames that print a **VALUE** (a count, a
size, a fit claim), and frames that carry **nothing variant-specific**, which are **REUSED**, copied
into every child's set untouched.

The frames that do change get edited in **two separate layers, never one prompt**: the shape is one
edit against a reference image, the printed text is another. A shape child changes the product's
geometry under its new reference; a colour child changes the finish only. The two never share a
prompt. Each edit costs cents on your OpenAI key.

**Type A or Type B, in two lines.** Type A is identical except the variant: same photograph, same
pose, same light, only the thing that varies, varies. Runs as cheap edits on your key. Type B is
regenerated on the same brief on Genrupt: same message, fresh composition, the gallery feels alive
and can start to feel like different products wearing one brand. Apparel and colourways usually want
A. Decide once, with a reason; Wonka writes it down and never asks again.

**The pilot, in two lines.** On a first family Wonka does one child first, the hardest one, and
shows it to you as a sheet. Your look at that sheet is the decision: "continue", or a named fix. A
family you have run before skips the pilot unless you ask for one.

**Same brief, but not same claims.** A variant that needs a different brief is a different product.
But the printed facts may differ per child, and they usually do: the small size fits a smaller
basket, the eight pack prints a different count. Those facts are checked against each child's own
source, never carried across. A number nobody can confirm is removed from the frame, and the plan
says so. The machine never invents a spec.

### Three ways to tell Wonka what the family is

You can use one, or any mix of the three. Nothing has to be demonstrated; pick whatever you have.

**ASINs or links.** Paste the variant ASINs or listing URLs, several at once. Wonka fetches each
child's images himself, starting with its main and adding gallery frames when the main does not show
the difference, and files them under the child. He checks the image is really that child's and not
the parent's shared main; when two children resolve to the same picture he says so and takes the
next frame that differs. One warning from the field: **the picker labels lie.** Amazon's colour axis
has been seen carrying the SHAPE. He reads the values, not the labels, and reads the differences
back to you before accepting them. The one question he may ask: when a child has no picture of its
own on the listing, he asks you for one or for a description.

**A sentence.** "Make this in black, white and red." "The 5-tier model." "A 2-pack." No listing
required. A colour or finish your reference photos never showed becomes a **concept** child:
generated, labelled `concept` on the folder, the filenames and the plan, no approval step, and never
a product claim. A concept is a picture of a possible product, and the plan says so in one line. The
one question he may ask: a shape described in words still needs a shape reference, because geometry
cannot be described reliably, so he asks for the ASIN or a photo once.

**Uploaded images.** Attach the files. Wonka maps each to a child and files them; you file nothing.
The one question he may ask, only when the filenames and your words leave it genuinely open: "Are
these three files three colours, or three angles of one colour?"

However it came in, the confirmed list is written down with, per child, where it came from and
whether it is real or a concept. Every recorded decision (the type, the list, your Day 8 picks) is
reused from `status.md`; a question answered on disk is never asked again.

### The demo, narrated

The demo product sells as a family: Aqua, Black, Stainless Cascading and the Stainless tested on
Days 2 to 8. The Stainless Cascading has a **different shape**, and that is the interesting one.

**The shape variant, from its ASIN.** Jay pastes the Cascading's ASIN after `/variations`. Wonka
reads the type off `status.md`, fetches the Cascading's images, sees that its main shows the
different tier profile and keeps it as the shape reference. He names the source: the tested main
plus the frames the frame table marks as variant-carrying, from the newest edit round. The frame
table and the truth table come back on one screen: which frames carry the shape, which print a
capacity, and which capacity value the Cascading's own listing prints. One value it does not print
gets `unknown, removed`. Then the scope line: "1 child, 4 edit calls on your OpenAI key, about $0.08
(cap $10 per run)". No question. The pilot runs.

**The pilot, checked against source and reference.** The sheet shows each frame three ways: the
source frame, the result, the Cascading's own picture. Three questions: is the requested change
there, is only that changed, is the product still itself. The hero comes back with the tier profile
right and the label card intact. Jay says "continue". The rest of the frames run on the same
manifest, unchanged.

When a pilot is wrong, the fix is the instruction, never the image. The failures have shapes that
repeat: the hero that refuses to change (name what it IS before what it becomes), the group frame
where only one of them changed (count them: "ALL FOUR"), the label card that melted (declare it a
RIGID OBJECT). Two or three genuinely different phrasings, not five nudges. Three failing the same
way means the problem is upstream: a missing reference, or a variant that is really a different
product.

**A short colour concept run.** Jay adds a sentence: "and show me this in black, white and red as
concepts for a possible launch". Black is a real child on the listing; white and red are colours the
reference set never showed, so they come back labelled concepts. No approval step. The scope line
says "3 children (1 real, 2 concept), 3 edit calls, about $0.06", and they run. The colour children
change finish only; the geometry stays the Stainless's.

**The review, and where the files are.** Every result is reviewed beside its source and its
reference. Wonka counts each child's folder against the plan, opens every hero at full size, and
then says where everything is, one line per child: the Cascading's files in `variations/`, the
concepts in `variations/concepts/[child]/` with `-concept` in every filename and a one-line
`CONCEPT.md` beside them. `variations/variations-plan.md` lists every path with its status. Nothing
in `images/` or `edits/` was touched.

### And before anything goes near Amazon

The edit drafts are review size. **Nothing is upscaled in this room.** Wonka records `upscale: owed`
against the family, and the Shipping Room on Day 10 upscales it once, with the mains, on the files
that ship. Then the gate, like everything else:

```
/inspect scoped to the variations
```

He opens every child, checks each frame against that child's own truth-table row, and checks the
family reads as one product rather than five photoshoots. The Shipping Room extends your upload pack
only with gate-passed variation files.

---

## MISSION 1: Define the family, one of the three ways

```
/variations B0XXXXXXXX B0YYYYYYYY
```

or

```
/variations make this in black, white and red
```

or attach your photos to `/variations`, or answer his one question in the same three ways. Then
**listen to the read-back** of what differs, and correct it if it is wrong. No variations for this
product? Say so:

```
No variations for this one, skip Day 9.
```

He records `Variations: skipped (owner, [date])`, and Day 10 opens on that line when you ask for it.

## MISSION 2: Run and review the pilot

Read the scope line. Look at the pilot sheet: the change is there, only that changed, the product
is still itself. Then:

```
Continue.
```

or name the fix in nouns:

```
[The defect.] Change the instruction and try again.
```

## MISSION 3: Find the outputs and read the plan

Open the paths he gave you, one line per child. Open `variations/variations-plan.md` and read the
Outputs section: every file, real or concept. Then:

```
/inspect scoped to the variations
```

**Share it:** send Jay your family as one grid, one review sheet, and the phrasing that cracked your
hero frame, because everybody's will be different and the shapes are genuinely interesting.

## Common mistakes

- **Generating the whole family first.** An untested instruction across eleven children is eleven
  children regenerated.
- **Regenerating frames that carry nothing variant-specific.** They are reused. That is the whole
  economics of the day.
- **Editing the pilot into shape.** An edited pilot cannot propagate.
- **Describing a new shape in words.** Geometry needs a reference. Give the ASIN or a photo.
- **Selling a concept.** A concept is a picture of a possible product. It is labelled, and it is
  never a claim.
- **Describing only the target shape to the hero.** Name its CURRENT shape first, then order the
  redraw.
- **"Every plate" in a group frame.** Count them. ALL FOUR.
- **Letting the label card follow the new shape.** The card is a RIGID OBJECT and the instruction
  says so.
- **Carrying the source's claims into a child.** Each child's printed facts are checked against its
  own source. Unknown means removed, never guessed.
- **Trusting the drift numbers alone.** They are blind to a melted label. Open every hero.
- **Judging swatches at full size.** They all look lovely there. Nobody sees them there.
- **Re-running the family to fix one child.** Re-run the child on its fixed prompt.
- **Uploading draft-resolution files.** The upscale is owed, not done here. The Shipping Room runs
  it once on Day 10, reused frames included.

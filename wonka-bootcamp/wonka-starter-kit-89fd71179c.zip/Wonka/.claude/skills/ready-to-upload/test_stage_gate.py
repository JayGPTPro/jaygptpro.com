#!/usr/bin/env python3
"""The stage gate, against fixture status.md files.

Written from the 14 September 2026 failure: the owner approved the Day 8 images,
said "We're stopping here" and "Next is Day 9", and Wonka packaged. Every case
here is one of the four rules, and each one was watched failing with the module
absent before it passed.

Run: python3 test_stage_gate.py
"""
import sys
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

FAILURES = []


def check(name, cond, detail=""):
    print(("  PASS  " if cond else "  FAIL  ") + name + ("  " + str(detail) if not cond and detail else ""))
    if not cond:
        FAILURES.append(name)


HEAD = """# Fondue . Station Tracker

| Station | Status | Artifact | Date | Notes |
|---|---|---|---|---|
| PROVE | in progress | tests/ | 2026-09-12 | Tasting Round 1 RUN, both races, Lean and Lean |

INVENT sub-status:
- Main pick: main-13 (primary); alternatives: main-03, main-06; backup: vanilla-control.png
- Gallery pick: edits/v9 (frames sec-01-v2 .. sec-08-v3, in that order)
"""

TEMPLATE_ROWS = """- Owner decision: [none yet] (written on Day 8 or Day 10 only when the owner ships a set)
- Variations (/variations): pending | in progress | done | n/a (product has no variations)
- Variations: [pending (Day 9) | none (single SKU) | family of N, upscale: owed]

INVENT is `done` only when all four sub-parts are done (e.g. "Variations: n/a (product has no
variations)"). "Variations: pending (Day 9)" is a lawful trailing marker.
"""

APPROVED_AND_STOPPED = HEAD + """- Owner decision: approve the Day 8 image set, edits/v9 (main-13 + 8 frames), after Lean on
  round 1, 2026-09-14. Approval of the images only; no ship decision.
- Variations (/variations): pending

## Log
- 2026-09-12 Tasting Round 1 main: main-13 preferred by 68 of 100, Lean.
- 2026-09-14 Owner decision: approve the Day 8 image set (edits/v9), after Lean on round 1.
  Day 8 complete on the owner's word.
- 2026-09-14 Next stage: Day 9, variations (session ended at the owner's word, 2026-09-14).
"""

WITHDRAWN = HEAD + """- Variations (/variations): pending

## Log
- 2026-09-14 Owner decision: ship edits/v9, after a Lean on round 1, reason: "I approve the current set".
  Next room: /ready-to-upload.
- 2026-09-14 CORRECTION, owner's clarification: "My approval was for the Day 8 images only."
  The `Owner decision: ship edits/v9` line above was Wonka's misreading. It is WITHDRAWN.
  No ship decision has been made.
"""

RESUMED_WITH_CHILDREN = HEAD + """- Owner decision: approve the Day 8 image set (edits/v9), after Lean on round 1, 2026-09-14
- Variations (/variations): in progress
- Type: A (edit path, OpenAI key), reason: one product in four finishes, 2026-09-15
- Children: stainless (asin B0STAINLES, real), aqua (asin B0AQUA0000, real), black (described, concept)

## Log
- 2026-09-14 Next stage: Day 9, variations (session ended at the owner's word, 2026-09-14).
- 2026-09-15 Session resumed. Day 9 opened from the recorded child list.
"""

SKIPPED = HEAD + """- Owner decision: approve the Day 8 image set (edits/v9), after Lean on round 1, 2026-09-14
- Variations (/variations): n/a (product has no variations)

## Log
- 2026-09-14 Next stage: Day 9, variations (session ended at the owner's word, 2026-09-14).
- 2026-09-15 Variations: skipped (owner, 2026-09-15). "No variations for this one."
"""

SKIPPED_LOG_ONLY = HEAD + """- Owner decision: approve the Day 8 image set (edits/v9), after Lean on round 1, 2026-09-14
- Variations (/variations): pending

## Log
- 2026-09-15 Variations: skipped (owner, 2026-09-15).
"""

FAMILY_DONE = HEAD + """- Owner decision: ship edits/v9, after Lean on round 1, reason: the owner's words "ship it"
- Variations (/variations): done
- Variations: family of 3, upscale: owed
"""

# Adversarial review of kit v41 (14 September 2026): file position is not chronology.
# The sub-status row sits above the Log; /variations rewrote it to `in progress` on
# 09-16 while the Log's last line still read `skipped (owner, 2026-09-15)`.
PILOT_AFTER_SKIP = HEAD + """- Owner decision: approve the Day 8 image set (edits/v9), 2026-09-15
- Variations (/variations): pending | in progress | done | n/a (product has no variations)
- Variations: in progress (pilot running, 2026-09-16) (the `upscale: owed` state is written by /variations at the gate pass)

## Log
- 2026-09-15 **Owner decision: approve the Day 8 image set (edits/v9), 2026-09-15.**
- 2026-09-15 Variations: skipped (owner, 2026-09-15)
"""

# The word "withdrawn" inside a real re-approval's trailing remark is not a withdrawal.
# Shaped like the fondue file: ship, CORRECTION withdrawing it, then a real approval.
REAPPROVED_AFTER_WITHDRAWAL = HEAD + """- Owner decision: [none yet] (written on Day 8 or Day 10 only when the owner ships a set)
- Variations (/variations): pending

## Log
- 2026-09-14 **Owner decision: ship edits/v9, the current set, after a Lean on round 1 in BOTH races,
  reason: the owner's words, verbatim, "I approve the current set".** Next room: /ready-to-upload.
- 2026-09-14 **CORRECTION, owner's clarification, verbatim: "My approval was for the Day 8 images only."**
  The `Owner decision: ship edits/v9` line above was Wonka's misreading. It is WITHDRAWN. What stands:
  the Day 8 image set is APPROVED as images. No ship decision has been made.
- 2026-09-15 **Owner decision: approve the Day 8 image set (edits/v9), after Lean, 2026-09-15.** (The earlier ship line stays withdrawn.)
"""

# The guides' form of the stop line, without the "session ended" remark.
STOPPED_PLAIN = HEAD + """- Owner decision: approve the Day 8 image set (edits/v9), after Lean on round 1, 2026-09-14
- Variations (/variations): pending

## Log
- 2026-09-14 Owner decision: approve the Day 8 image set (edits/v9), after Lean on round 1.
- 2026-09-14 Next stage: Day 9, variations
"""


def product(status_text, **files):
    d = Path(tempfile.mkdtemp())
    (d / "status.md").write_text(status_text, encoding="utf-8")
    for rel, body in files.items():
        f = d / rel
        f.parent.mkdir(parents=True, exist_ok=True)
        f.write_text(body, encoding="utf-8")
    return d


def run():
    import stage_gate as sg

    print("rule 1: an explicit stop is respected")
    p = product(APPROVED_AND_STOPPED)
    e = sg.read(p)
    check("approval plus stop: Day 8 is decided", sg.day8_decided(e))
    check("approval plus stop: the record ends on a stop", sg.stop_requested(e))
    check("approval plus stop: next stage is variations", sg.next_stage(e) == "variations", sg.next_stage(e))
    ok, why = sg.ship_gate(p, invoked=False, ents=e)
    check("approval plus stop: nothing is packaged", not ok, why)
    check("and the refusal names the missing record (variations)", "Variations" in why, why)
    ok2, why2 = sg.ship_gate(p, invoked=True, ents=e)
    check("even when invoked, variations pending keeps the room shut", not ok2, why2)

    print()
    print("rule 2: image approval is not a ship decision, and a withdrawn one is none")
    e = sg.read(product(WITHDRAWN))
    check("a withdrawn decision does not count", not sg.day8_decided(e))
    check("so the next stage is still Day 8", sg.next_stage(e) == "day8", sg.next_stage(e))
    e = sg.read(product(HEAD + TEMPLATE_ROWS))
    check("template placeholders decide nothing", not sg.day8_decided(e))
    check("template placeholders skip nothing", not sg.variations_done_or_skipped(e))
    check("template example text is not a variations record", not sg.variations_on_record(product(HEAD + TEMPLATE_ROWS), e))

    print()
    print("rule 3: Day 9 uses what is recorded, else asks ONE question")
    p = product(RESUMED_WITH_CHILDREN)
    e = sg.read(p)
    check("a recorded child list: no question", sg.variations_question(p, e) is None, sg.variations_question(p, e))
    check("a resumed session is no longer a stop", not sg.stop_requested(e))
    check("next stage is still variations (in progress is not done)", sg.next_stage(e) == "variations")
    p = product(APPROVED_AND_STOPPED)
    e = sg.read(p)
    check("no variation info: the one question is asked",
          sg.variations_question(p, e) == "Do you have any product variations you'd like to create images for?",
          sg.variations_question(p, e))
    p = product(APPROVED_AND_STOPPED, **{"2-reference/variations/aqua/live-main.jpg": "x"})
    check("child reference folders on disk count as recorded", sg.variations_question(p, sg.read(p)) is None)
    p = product(APPROVED_AND_STOPPED, **{"variations/variations-plan.md": "# plan"})
    check("a variations plan on disk counts as recorded", sg.variations_question(p, sg.read(p)) is None)

    print()
    print("rule 4: Day 10 follows completed or explicitly skipped variations, on the owner's ask")
    p = product(SKIPPED)
    e = sg.read(p)
    check("explicit skip: variations done or skipped", sg.variations_done_or_skipped(e))
    check("explicit skip: next stage is ready-to-upload", sg.next_stage(e) == "ready-to-upload", sg.next_stage(e))
    ok, why = sg.ship_gate(p, invoked=True, ents=e)
    check("explicit skip plus the owner's ask opens the Shipping Room", ok, why)
    ok, why = sg.ship_gate(p, invoked=False, ents=e)
    check("a passed gate and a skip alone do NOT open it: the owner must ask", not ok, why)
    check("and that refusal says to ask the next-room question", "Ready for the Shipping Room" in why, why)
    p = product(SKIPPED_LOG_ONLY)
    e = sg.read(p)
    check("a skip recorded only as a log line still counts (latest record wins)",
          sg.variations_done_or_skipped(e))
    p = product(FAMILY_DONE)
    e = sg.read(p)
    check("a finished family opens the way to Day 10", sg.next_stage(e) == "ready-to-upload")
    check("a family on record asks no question", sg.variations_question(p, e) is None)

    print()
    print("review of v41: chronology, the decision value, the plain stop line")
    p = product(PILOT_AFTER_SKIP)
    e = sg.read(p)
    check("F1: a later `in progress` sub-status row beats an earlier skipped Log line",
          not sg.variations_done_or_skipped(e))
    ok, why = sg.ship_gate(p, invoked=True, ents=e)
    check("F1: --ship --invoked refuses while the pilot runs", not ok, why)
    e = sg.read(product(REAPPROVED_AFTER_WITHDRAWAL))
    check("F2: a re-approval that mentions the earlier withdrawal is a decision", sg.day8_decided(e))
    check("F2: and the next stage is variations", sg.next_stage(e) == "variations", sg.next_stage(e))
    e = sg.read(product(WITHDRAWN))
    check("F2: a ship line followed by a plain CORRECTION/WITHDRAWN entry still decides nothing",
          not sg.day8_decided(e))
    e = sg.read(product(STOPPED_PLAIN))
    check("F3: `Next stage: Day 9, variations` as the last line is a stop", sg.stop_requested(e))
    ok, why = sg.ship_gate(product(STOPPED_PLAIN), invoked=False, ents=e)
    check("F3: and nothing is packaged", not ok, why)

    print()
    print("the CLI")
    import subprocess
    p = product(APPROVED_AND_STOPPED)
    r = subprocess.run([sys.executable, str(HERE / "stage_gate.py"), str(p), "--ship", "--invoked"],
                       capture_output=True, text=True)
    check("--ship exits 1 while variations are pending", r.returncode == 1, r.stdout)
    check("and prints the one-line refusal", "REFUSED" in r.stdout, r.stdout)
    p = product(SKIPPED)
    r = subprocess.run([sys.executable, str(HERE / "stage_gate.py"), str(p), "--ship", "--invoked"],
                       capture_output=True, text=True)
    check("--ship --invoked exits 0 on an explicit skip", r.returncode == 0, r.stdout)
    r = subprocess.run([sys.executable, str(HERE / "stage_gate.py"), str(p), "--ship"],
                       capture_output=True, text=True)
    check("--ship without --invoked exits 1 even on a skip", r.returncode == 1, r.stdout)

    if FAILURES:
        print(f"\nFAILED ({len(FAILURES)}): " + ", ".join(FAILURES))
        return 1
    print("\nSTAGE GATE: all green")
    return 0


if __name__ == "__main__":
    sys.exit(run())

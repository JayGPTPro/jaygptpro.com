---
name: fix
description: Surgical image edits in the Fixing Room, in two modes. MODE A (pre-tasting, QA-driven) fixes the defects the Inspection Room flagged. MODE B (post-tasting, note-driven) reads the Tasting Card notes and refines the winning main image and the weakest gallery frame. Fixes the chosen image first (a focused edit with the references, the changed region composited back so the rest of the frame stays byte-identical), regenerates from that base only for broad changes or after two failed edits, never swaps a chosen image for another, runs routine fixes on a report under CLAUDE.md's routine-fix policy, refuses fixes that break a house rule or fight the research, writes every edit round as a COMPLETE set snapshot to edits/v1, v2 and so on (originals stay write-once in images/), verifies side by side, re-inspects, and logs every edit and every routing decision. Triggers: /fix, "fix this image", "remove the badge", "shorten that text", "change the word", "edit the image", "refine the winner", "act on the tasting notes", or fix items coming from /inspect or /tasting-room.
---

# The Fixing Room

| Meta | Value |
|------|-------|
| Room | The Fixing Room |
| Station | INSPECT (fix leg, MODE A) and PROVE (post-tasting refinement, MODE B) |
| Taught | Day 5, MODE A, as the second half of the quality loop. MODE B on Day 8, off the Tasting Cards, the same day the panel runs. Runs again whenever a scorecard or a Tasting Card names a defect |
| Needs | The image file and the exact defect (MODE A: the scorecard. MODE B: the Tasting Card notes), `OPENAI_API_KEY`, plus `2-reference/reference-sheet.md` and `brief/creative-brief.md` whenever a fix changes on-image text |
| Saves to | `factory/Products/[product]/edits/v[N]/`, one folder per edit ROUND, each holding the COMPLETE current set (new renders for fixed files, unchanged copies of everything else). Originals stay write-once in `images/` (and `aplus/`, `variations/`). The round log is `edits/fixes-log.md` |
| Typical cost | Cents per edit at low quality, roughly $0.02 to $0.10. A face repair runs at `high` instead (slower and dearer, see step 7). Every edit is counted and logged; routine fixes run on a report inside the routine-fix policy's limits (CLAUDE.md), and a round that crosses a limit stops once for one approval. |

## What this room does

Most defects on a chosen image cost cents to fix ON that image. This room fixes the chosen image first: one precise change at a time on the direct OpenAI image edit API with the references attached, the changed REGION composited back onto the base so every other pixel stays the base's own, the original always preserved, every result verified against it and re-inspected before it counts. A broad change (recast, new scene, new layout) or a defect that failed two edits goes back to its generation room (`/main-image`, `/secondary-images`, `/aplus`, `/variations`) as a regeneration FROM THIS FILE AS THE BASE with a tighter brief. What this room never does is hunt for a different image to avoid a fix: the owner chose this one. The route, the spend and the stops are CLAUDE.md's routine-fix policy, the one source. The room services mains, secondaries, and variation imagery. **A+ module images are the one exception (house decision, Jay 27 July 2026): ALL A+ edits, surgical included, run inside Genrupt through the A+ edit flow in `/aplus` (the `edit_aplus_concept` MCP capability, verified working 22 August 2026, or the Genrupt app for anyone who prefers clicking), never through the OpenAI edit API here.** Genrupt's editor is built for A+ and its export comes out final; paying the direct API to patch an A+ module produces a worse round trip. When an A+ item lands on this room's list, route it to `/aplus` with the defect named, and log the routing.

Every fixing session is a ROUND, and every round writes a complete set snapshot to its own folder: `edits/v1/` for the first round, then `v2/`, `v3/`, and so on. Fixed files go in as new renders; every untouched file is COPIED in unchanged, same filename. The version lives in the folder name, never in the filename. The law this buys: **the highest `vN` folder always holds the ENTIRE current set**, so no room ever assembles a set from two folders, and `final/` and `/ready-to-upload` read exactly one place. `images/` is the raw generation output and it is write-once: this room reads from it and never writes into it.

The Fixing Room runs in TWO modes, and this is a core promise of the bootcamp: creative does not stop at "generated", it improves with evidence.

- **MODE A . pre-tasting, QA-driven (Day 5).** Fix the specific defects the Inspection Room flagged, so only gate-passing candidates ever reach the Tasting Room. MODE A removes flaws.
- **MODE B . post-tasting, note-driven (Day 8, straight after the panel).** After a Tasting Round, read the Tasting Cards and refine TWO targets: the winning MAIN image, from the main race Card's friction themes, and the WEAKEST GALLERY FRAME, from the gallery race Card's frame-by-frame layer. Optionally hand `/main-image` one challenger brief that answers the single biggest objection, for Tasting Round 2. MODE B chases conversion.

Both modes use the same routing table, the same refusal gate, the same edit API, the same keep-the-original discipline, and the same verification. The only difference is where the fix list comes from: the scorecard, or the Tasting Card notes.

## What this room never does

- **Never regenerates.** A regenerate-class defect leaves this room as a written brief instruction naming the current file as the base, not an edit.
- **Never swaps.** A defect on the image the owner chose is fixed on that image. Wonka never proposes a free alternative, another candidate or the pool instead of the fix; an alternative is offered only when the owner asks for one, approves one, or two edits and the regeneration route have both failed.
- **Never "fixes" a preference.** "I like the other one more" and "make it pop" are not defects; they get one sentence of Wonka's reading and a question. A plain-language DEFECT ("the column is not centred", "the logo is missing on the left one") is a fix order and runs without a `/fix`, a prompt, or a "go".
- **Never removes a prop, an ingredient or an accessory nobody asked to lose.** Props are lawful on every image, the main included; a prop leaves only on the owner's word, and Wonka never lectures Amazon policy to justify a removal.
- **Never edits the incumbent.** The live Amazon image is the benchmark to beat and it belongs to another seller. It is never an edit base and never a generation reference.
- **Never writes into `images/`** (or `aplus/`, `variations/`). Those folders are write-once generation output. Every render this room produces lands in the round folder `edits/vN/`, nowhere else.
- **Never overwrites, renames, or deletes an original**, and never touches a previous round folder after the next round opens. The owner prunes their own files.
- **Never leaves a round folder incomplete.** A `vN` missing files is a broken snapshot: every file the round did not fix gets copied in unchanged before the round closes.
- **Never puts a word on an image that is not traceable** to the Reference Sheet, the brief, or the live listing. A fix is the easiest place in the whole factory to invent a product fact. It does not happen here.
- **Never spends outside the routine-fix policy.** Inside its limits (calls per round, estimated cost per round, attempts per defect, `low` quality outside a face repair) a routine fix runs on a REPORT with its estimate; crossing a limit, a paid regeneration route, or an owner preference on file that says ask first, stops the round once for one approval. Never a silent cent, never a ping per item, never a round split to stay under a limit.
- **Never edits an image it has not opened with Read**, and never logs a fix as SUCCESS it has not opened again afterwards.
- **Never presents a failed, unverified, or un-re-inspected fix as a candidate.**

## Before you start

- **State the mode out loud.** MODE A if the list comes from an Inspection Room scorecard. MODE B if it comes from a completed Tasting Round. It changes only where the list comes from, never how edits run.
- **MODE B: read the Cards first.** Open the latest `tests/tasting-r[N]-[date]-main/tasting-card.md` (and the `...-gallery` Card if both races ran), and confirm from the verdict band which file WON the main race (the table's File column names it, and the winner line repeats it) and which frame the frame-by-frame layer named weakest. Refinement targets the winner and the weakest frame. It never targets losing candidates.
- **Find the current set.** The current version of every file is in the HIGHEST existing `edits/vN` folder; if no round has ever run, it is in `images/` (A+ in `aplus/`, variations in `variations/`). Confirm the exact target files exist there and open each one with Read so you can see the defect yourself. Echo the list back in one line before doing anything.
- **Confirm the key.** If `$OPENAI_API_KEY` is not set, load it from the Factory root `.env` first, with the same parser `/machines-check` uses:
  ```bash
  export OPENAI_API_KEY=$(grep -m1 '^OPENAI_API_KEY=' .env | cut -d= -f2- | tr -d '"' | tr -d "'" | tr -d ' ')
  ```
  The `-f2-` and the quote stripping both matter. A key written as `OPENAI_API_KEY="sk-..."` is normal, and a parser that cuts at the first `=` and keeps the quotes hands the API a truncated key wrapped in quote marks. It fails as a 401, which reads like a bad key rather than a bad parse, and it fails HERE on Day 5 even though Day 1's check passed with the same file..
- **Get one sentence for the defect and one for the desired result.** "Make it better" is not a fix order; ask for the specific change. "The column is not centred on the left one" IS one: the desired result is what the reference shows, and Wonka writes both sentences himself from the references, verifies the defect on the magnified crop, and runs.
- **The spend is the routine-fix policy in `CLAUDE.md`, nothing else.** Build the WHOLE list first with ONE estimate line, check it against the policy's limits, and RUN on a report when it is inside them. A list that crosses a limit (calls, estimated cost, a third attempt on one defect) or that contains a paid regeneration stops ONCE for ONE approval, with the number that crossed. An owner preference on file ("ask before every spend"; "just check, do not fix yet") wins in either direction.

### "I don't have it" is a real answer

Missing convenience never stops this room. Missing EVIDENCE stops only the item it belongs to. Record every gap in the log and proceed.

| The owner says | What happens |
|---|---|
| "No scorecard, but this badge has to go" | Proceed on the stated defect. Log `list source: owner, no scorecard on file`. |
| "No Tasting Card, but they said the text was busy" (MODE B) | Proceed on the stated notes. Log `notes source: owner recollection, no Card on file`, and say plainly that without mention counts the theme rule cannot be applied, so the change is a lean and not an instruction. |
| "No reference sheet / no brief" and a fix changes on-image text | Do not invent. Read the new wording back and get the owner to confirm it is literally true of the product. Log `wording verified by owner, no reference sheet on file`. |
| "I deleted the original" (the `images/` file is gone) | The edit can still run off the latest `edits/vN` copy, but say plainly that the side-by-side check against the true original is degraded. Verify against the previous round's file and the scorecard's literal description instead and log `no original on file, verification degraded`. |
| "No OpenAI key" | Paid edits are closed, the ROOM IS NOT. Run the whole list through the refusal gate and the routing table, log every decision, hand the regenerate items to their rooms, and park the edit items as `blocked: no key` with a pointer to `guides/mcp-setup-guide.md`. |
| No answer on a stop the policy required (a limit crossed, a paid regeneration) | Nothing beyond the limit runs. Park the station `in progress`, say exactly what is waiting, and stop. Fixes inside the limits already ran. |
| "Just fix all of them, do not ask" | That is the default already. The routing and the refusal gate still run; the list is announced with its estimate and runs at once, and only a policy limit stops it. |
| "I only want the left machine fixed, leave the rest" | Scope the round to what was named. The composite step keeps the rest of the frame byte-identical anyway; say so once. |

## The refusal gate. Two fixes Wonka will not run

Apply this to every item BEFORE routing. A refusal is a result, not a failure: it gets logged with its reason and its reroute, and the owner may override in writing.

1. **A fix that breaks a house rule.** The commonest one by far: an objection about the MAIN image that can only be answered with text or a graphic. A main carries no overlay text, no callouts, no badges, no arrows, **and no added graphic logo**, ever. (A logo printed on the real product is product truth and stays.) Refused everywhere too: drawing, redrawing, re-spelling or approximating a logo. A logo defect is fixed by re-running the wiring in `/reference-sheet` against the real supplied asset, or by removing the rendered graphic, never by having the model draw it better. Also refused everywhere: adding a star rating or review reference, a drawn award or Best Seller badge, a third-party logo, a flag graphic, an invented percentage, or a medical claim. **Reroute, do not build:** the message goes to a secondary frame where it is allowed to live, and the gallery often already has that frame. Example: tasters say they cannot tell how big the fountain is. No "8 x 8 x 18 IN" callout may be added to the main. It goes to the gallery scale frame.
2. **A fix that fights the research.** The panel is cheap and fast, which is exactly why it never quietly overrules expensive real evidence like reviews, returns, and the selling-points checklist. Example: tasters ask for a bigger, fuller chocolate cascade, but the reviews report that a fill at the listed capacity gives a thin flow. Answering that objection sells a promise the product cannot keep as sold, which is the complaint that drives its one-star reviews. Record it in the test file, do not execute it. The owner can override; the reason goes in the log.

## Process

1. **Write the instruction list before any surgery.** Orders first, scalpel second. One line per item: what changes, which asset it belongs to, and the evidence that justifies it.
   - **MODE A:** each item cites the scorecard flag (the dimension and the element).
   - **MODE B:** each item cites the exact tasting note and the number of tasters who raised it. **A theme needs repetition: one taster is noise, three or more is an instruction.** Below three mentions, record it as noise and do not act. **If no theme reaches three, MODE B runs no edits at all**: say so, log `no qualifying theme, no refinement`, and let Round 2 run as a confirmation against the challenger or the next best gate-passed candidate. Changing a winner without a reason is how winners get broken.
   - A good instruction: "Remove the two smallest callouts. Justified by: five tasters said the text was busy." A bad one: "Make it pop more." Strike anything that reads like taste smuggled in as data.

2. **Run the refusal gate** (above) on every item. Refused items get their reason and their reroute written down now, and they never reach the routing table.

3. **ROUTE EVERY SURVIVING ITEM. This decision is the room.**

   | Defect | Route |
   |---|---|
   | Shorten or remove text | EDIT |
   | Remove an element (badge, card, stray object) | EDIT |
   | Swap a word or a claim for a shorter, truer one | EDIT |
   | Recolor an accent | EDIT |
   | A part of the product in the wrong place: off its axis, misaligned with another part, a tier not centred, a joint that does not meet | EDIT, focused on that instance's region, the reference sheet attached, composited back by region |
   | Restore the product's own markings (a logo, control labels) or reshape an object ("make the marshmallow a short cylinder") | EDIT, focused, references attached, composited back; after two failed edits a regeneration from this file as the base |
   | Fix the product itself (wrong part count, wrong material, wrong label) on ONE instance or one region | EDIT first, references attached; two failures route it to regeneration from this base |
   | Move or resize ONE element inside its own region; a small layout change that stays local | EDIT first, composited back; two failures route it to regeneration |
   | Enlarge text so it reads at 160px | REGENERATE from this base (an enlargement re-flows the layout around it) |
   | Change the whole layout or composition, a new scene, most of the frame wrong | REGENERATE from this base, tighter brief |
   | Make AI-looking people look real (the three signatures: doll face / waxy skin / filter glow) | EDIT, via the people-rescue pass below, `high` |
   | RECAST a person (different age, different person) or change their pose | REGENERATE from this base |
   | "Keep main-07 as the base and take X from main-03" | REGENERATE, `/main-image` step 8b (develop), new number |
   | The same defect after TWO failed edits | REGENERATE from this base; the third edit is never run |

   The reason the composite exists is mechanical: the edit endpoint re-renders the WHOLE frame, so even a correct local fix comes back with the rest of the picture drifted (measured 7 September 2026 on a two-machine frame: the tower re-centred as asked, and both machines came back smaller with the jug reshaped). Pasting only the fixed region back onto the base (step 7b) keeps everything outside it byte-identical, which is what makes spatial fixes an edit. **For every REGENERATE item: do not edit it.** Send it to its generation room with THIS file named as the base and the exact sentence the tighter brief must contain, for example "The machine has FOUR tiers. All four must be visible and countable." Record the routing decision in the log even when no edit runs. An image needing three or more edits is a regeneration wearing a disguise: say so and recommend the ovens, from this base.

4. **Announce the plan with its estimate, check the policy's limits, and run.** The routine-fix policy in `CLAUDE.md` pre-authorises the round inside its limits; the plan is REPORTED, never gated, and runs in the same breath. It stops for ONE approval only when a limit is crossed (calls per round, estimated cost per round, a third attempt on one defect), when an item is a paid regeneration, or when an owner preference on file says ask first.

   ```
   Fix plan . [product] . MODE [A/B]
   1. [file]  EDIT       [change, region x,y,w,h]   [evidence]   ~$0.0X
   2. [file]  EDIT       [change, region x,y,w,h]   [evidence]   ~$0.0X
   3. [file]  REGENERATE [change] from this base    [evidence]   Genrupt, waits for a yes
   4. [file]  REFUSED    [change]            [rule broken / research it contradicts] -> [reroute]
   [n] edits, about $0.XX (estimate; the balance delta is the charge), inside the routine-fix limits. Running now.
   ```

5. **Write the surgical prompt.** It names ONE change and freezes everything else. One change per API call.
   - "Remove the red BEST SELLER ribbon from the top left corner. Change nothing else in the image."
   - A structure fix names the instance, the part and what the reference shows, never how the product looks in general (the words rule; the sheet carries the product): "On the LEFT fountain only, move the central column so it rises from the centre of the bowl and the base on one vertical axis, with all three tiers centred on it, exactly as in the reference sheet. Keep the right fountain, the text, the props and the background exactly as they are." The locked reference sheet goes in as the first image, the base second.
   - "Change the text 'HOLDS 4 LBS' to 'HOLDS 32 OZ'. Keep the exact same font, size, color, and position. Change nothing else."
   - **Any text a fix introduces must be true and sourced.** Check the new wording against the Reference Sheet, the brief, or the live listing, and write that source into the log. A shorter lie is still a lie.

   **The people-rescue pass runs on the Face Clinic's engine, never on a hand-rolled prompt.** When `/inspect` flags a people image with realism signatures (A doll face, B waxy skin, C filter glow), the fix is `/fix-faces` on that file: head boxes drawn and proven, the full frame sent to gpt-image at `high` (a face is always `high`, Jay, 6 September 2026), each face REPLACED by a new real one of the same casting, pose and position, and only the head boxes composited back through a feathered mask, so everything outside them is the original by construction. It runs conditionally: no signature flagged, no pass. Asking the model to "keep the same people and make them realistic" keeps the doll geometry and paints texture on it, which reads as a skin disease; that is why the Clinic replaces. Inside a round, run it with `--out edits/v[N]/[name].png` so the fixed file takes its canonical name in the snapshot this round opened (the engine opens its own round only when run standalone). A different pose or a different casting is a regeneration, not a face fix.

6. **Open the round folder BEFORE any render.** Find the highest existing `edits/vN`; this round is `edits/v[N+1]` (`edits/v1` if no round exists yet). Create it, then copy the ENTIRE current set into it unchanged, same filenames: from the previous `vN` if one exists, otherwise from `images/`. The renders in the next step will replace only the files this round fixes; everything else already sits in the folder as-is. That is what makes the highest `vN` the whole current set on its own.
   - The EDIT BASE for every item is the file in the previous round folder (`edits/v[N-1]/[name].png`), or `images/[name].png` on round 1. Never edit off `images/` when a later version exists: that would silently discard earlier fixes.
   - A+ module images and variation imagery follow the same law. Their originals live write-once in `aplus/` and `variations/`; a round that fixes them copies that class's full current set into `edits/vN/aplus/` or `edits/vN/variations/` and replaces only the fixed files. The current set of a class is the highest `vN` that contains it, else its originals folder.

7. **Run the edit on the OpenAI images.edit endpoint directly**, using the newest gpt-image model on the account (as of mid 2026, `gpt-image-2`). **Quality depends on WHAT is being repaired, not on which room you are in:**
   - **A person's face is the thing being fixed: `high`.** Same rule and same reason as the Face Clinic, and if the repair is a face-realism pass, use `/fix-faces` and its engine rather than hand-rolling one here. Cheap pools, expensive repairs: this is one asset, already paid for, already known to be wrong, and faces are what a customer looks at hardest.
   - **Everything else: `low`.** Shortening text, removing an element, swapping a word or a colour. Low is the cheapest option and it preserves burned-in text well. Whether medium would preserve text BETTER has never been measured here; if someone measures it, record the numbers rather than assuming. Run from the kit root with full paths. The output path is the canonical filename INSIDE the new round folder, replacing the copy placed there in step 6:

   `quality` is `low` here; pass `high` whenever the edit touches a face.

   ```bash
   curl -s https://api.openai.com/v1/images/edits \
     -H "Authorization: Bearer $OPENAI_API_KEY" \
     -F model="gpt-image-2" \
     -F image="@factory/Products/[product]/edits/v[N-1]/[name].png" \
     -F prompt="[the surgical prompt]" \
     -F size="1024x1024" \
     -F quality="low" \
   | python3 -c '
   import sys, json, base64, pathlib
   r = json.load(sys.stdin)
   if "error" in r:
       sys.exit("EDIT FAILED, nothing written: " + str(r["error"].get("message", r["error"])))
   out = pathlib.Path(sys.argv[1])
   out.write_bytes(base64.b64decode(r["data"][0]["b64_json"]))
   print("wrote", out, out.stat().st_size, "bytes")
   ' "factory/Products/[product]/edits/v[N]/[name].png"
   ```

   **`size` is passed on purpose, and it costs resolution. Say so.** The edit endpoint returns a fixed working size, not the source's size, so an edited file usually comes back SMALLER than the Genrupt original it was built from. Set `size` to match the source's aspect ratio (`1024x1024` for a square listing image, the portrait or landscape option for a frame that is not square); leaving it out lets the API choose, and a portrait frame can return square with the composition cropped. The consequence travels: because a round copies the whole set forward, the edited files become the low-resolution members of an otherwise full-resolution set, and the MAIN image is the most exposed of all since MODE B refines the winner by design. That is not a reason to avoid editing, it is a reason to check. The Shipping Room reads every packaged file's real pixel size, reports it, and offers the Genrupt upscale before anything is uploaded.

   **A structure fix passes the reference sheet as well**: `-F image[]=@[reference sheet].png -F image[]=@[base].png`, sheet first, so the product's identity comes from the sheet and the base carries the scene. Read the endpoint's current schema for the multi-image form before typing it.

7b. **Composite the changed region back onto the base. Every render that was a LOCAL fix goes through this before verification.** The endpoint re-rendered the whole frame; only the region you asked to change is wanted from it. Measure the box on the base (source pixels, generous enough to hold the whole part and its shadow, never cutting through the object or through text), then:

   ```bash
   python3 .claude/skills/fix/composite_region.py "[base].png" "[render].png" "[out in edits/vN]/[name].png" x,y,w,h [x2,y2,w2,h2] --feather 24
   ```

   The tool resizes the render to the base's size, pastes the boxes back with a feathered edge, and prints two numbers: pixels changed inside the region and pixels changed OUTSIDE it, which must be 0. A non-zero outside count means the boxes or the feather are wrong; fix the boxes, never accept the drift. The whole-frame render is kept beside it as `[name]-render.png` for the log. A people-rescue pass and a recolour that legitimately touch the whole frame skip this step and say so in the log.

   On round 1 the `-F image=` input is `images/[name].png`. The guard matters: the API error is checked BEFORE the output file is opened, so a refused or failed call leaves the copied-in parent file in place instead of an empty render pretending to be a fix. **If the "wrote ... bytes" line did not print, no new image exists** and the round folder still holds the unchanged copy. Never log that item as anything but FAILED.

8. **Rejected renders never take the canonical name.** If a render FAILS verification (next step), rename it to `[name]-rejected.png` (`-rejected-2` for a second failure) inside the round folder, then copy the parent version back in as `[name].png` so the snapshot stays whole. No later room can mistake a rejected file for a candidate, and the round folder is never missing a file. Two failed attempts on the same defect is a regeneration from this base (the policy's attempts limit), not a third try, and the regeneration is a paid route that waits for one yes.

9. **Verify: first the hash, then the eyes.**

   **The hash check runs BEFORE any looking.** Compare a checksum of the edit base against the new render:

   ```bash
   md5 -q "[edit base].png" "[new render].png"                                                        # macOS
   python3 -c "import hashlib,sys; print(*[hashlib.md5(open(p,'rb').read()).hexdigest() for p in sys.argv[1:]], sep='\n')" "[edit base].png" "[new render].png"   # anywhere
   ```

   **Identical hashes mean the edit silently FAILED**: the API returned the input unchanged, or the output path never actually replaced the step-6 copy, and the render "success" line was telling the truth about bytes while lying about work. Eyes are the wrong tool for catching this, because a person shown two identical images politely finds the difference they were told to expect. Identical = treat exactly like a failed render: rename per step 8, retry once with a tighter prompt or route to regeneration. Record both short hashes in the log entry either way.

   **Then verify side by side, against the true original.** Open the new render in `edits/vN` AND the `images/` original with Read and compare deliberately. For a file that was already fixed in an earlier round (a chained edit), ALSO open the immediate parent in `edits/v[N-1]`, because each re-render drifts a little and the drift compounds where a single-step check cannot see it. Check four things:
   - (a) the requested change actually happened,
   - (b) every other piece of text still reads exactly as before, transcribed word for word, not glanced at,
   - (c) the product is untouched: label, material, colors, and part count (a four tier machine still shows four tiers),
   - (d) nothing new appeared anywhere in the frame,
   - (e) for a composited fix: the seam is clean at 3x (`python3 .claude/skills/inspect/magnify.py [out] [dir] x,y,w,h` on the box, and the same box on the base beside it), and the defect is gone on the magnified crop, not only at full size; the other instance of the product, if any, is compared on the same strip.
   Anything else changed means the edit FAILED. Rename it rejected per step 8, restore the parent copy, log it, and either retry ONCE with a tighter prompt or route it to regeneration.

10. **Re-inspect mechanically. Nothing is fixed because it feels fixed.** Write a real 160px copy of the fixed file to `scorecards/squint/`, named with the round so no squint copy shadows another, and READ that copy, then re-run the compliance gate and the six scores per the Inspection Room. A fix to a gallery frame also re-runs the listing set-level checks, because a change to one frame can duplicate another frame's message.

   ```bash
   mkdir -p "factory/Products/[product]/scorecards/squint"
   sips --resampleWidth 160 "factory/Products/[product]/edits/v[N]/[name].png" --out "factory/Products/[product]/scorecards/squint/[name]-v[N]-160.png"   # macOS
   magick "[in].png" -resize 160x "[out]-160.png"                                                                                                        # Windows / ImageMagick
   python3 -c "from PIL import Image; im=Image.open('[in].png'); im.resize((160, round(im.height*160/im.width))).save('[out]-160.png')"                  # anywhere with Pillow
   ```

   A fix that passes replaces its parent in the slot ranking. Update the current scorecard. A fix that fails the gate is not a fix.

11. **Log the round** in `edits/fixes-log.md` (create `edits/` and the log on the first round). Append, never overwrite. Every round gets a header stating the round folder, the base it was copied from, and which files were fixed versus copied. Every item gets its own entry: edits, regenerate routings, refusals, and blocked items alike.

12. **Hand off.**
    - **MODE A:** back to `/inspect` for the updated scorecard, then the human picks from gate-passed candidates only.
    - **MODE B:** the refined winner and the refined frame go back to `/inspect`, and the set is then FINAL. A second synthetic sitting is optional and rarely worth it; the real second opinion is Amazon's own A/B. **The refined winner keeps its Round 1 candidate id in the Round 2 config**, even though the file now lives in `edits/v[N]`. Change the id and the round-over-round delta, which is the only number that says whether the fix worked, cannot line up.

## Output format

`edits/fixes-log.md`, one round header plus one entry per item, appended:

```markdown
# Round v[N] . [YYYY-MM-DD HH:MM] . MODE [A/B]
- Copied from: [edits/v[N-1] / images/ (first round)]
- Fixed this round: [file, file]
- Copied unchanged: [count] files
- Round cost: ~$[X.XX] estimated across [n] edits, [charge from the balance delta when read]. Policy limits: [n]/12 calls, ~$[X.XX]/$3.00, no defect past 2 attempts [or: STOPPED at [limit], approved by the owner at [time]]. Running product total: ~$[X.XX]

## [name].png
- Target: [the flagged image / the main race WINNER / the weakest gallery frame]
- Defect or request: [what was wrong or wanted]
- Evidence: [MODE A: scorecard flag, dimension and element / MODE B: the exact note, verbatim, and the taster count]
- Route: [EDIT / REGENERATE, sent to /[room] with the exact brief sentence / REFUSED: which rule or which research finding, and where it was rerouted / BLOCKED: what is missing]
- Edit base: [edits/v[N-1]/[name].png / images/[name].png]
- Prompt: "[the exact surgical prompt]"
- New wording source: [Reference Sheet / brief / live listing / owner-confirmed. n-a if no text changed]
- Region: [x,y,w,h on the base / whole frame (people pass or recolour)] . composite: [inside [n] px, outside 0 / n-a]
- Result: [SUCCESS, [n] bytes written / FAILED: what else broke -> renamed [name]-rejected.png, parent copy restored]
- Attempt: [1 of 2 / 2 of 2 -> next route is regeneration from this base]
- Hash check: [base [first 8 chars] vs new [first 8 chars], differ / IDENTICAL -> silent failure, treated as FAILED]
- Side-by-side check: [change OK vs the images/ original (and vs the v[N-1] parent for a chained edit), other text transcribed and intact, product and part count intact, nothing new]
- Re-inspection: squint [PASS/FAIL] at 160px, compliance [PASS/FAIL], scores [summary]
- Cost: ~$[0.0X]
```

## Golden Standards check

Before presenting, verify:
- [ ] The mode is stated. MODE B targeted the winning main and the weakest gallery frame, never a loser, and each edit names the note and the taster count that drove it.
- [ ] The three-mention rule was applied in MODE B, and a run with no qualifying theme made NO edits and said so.
- [ ] The refusal gate ran on every item. Every refusal names the rule it would break or the research it contradicts, plus where the message was rerouted.
- [ ] The routing table was applied BEFORE any edit: the chosen image was fixed first, no defect got a third edit, every regenerate item left with THIS file named as its base and the exact sentence its tighter brief must contain, and no owner-reported defect was answered with an offer of a different image.
- [ ] Every edit prompt names one change and ends with an explicit "change nothing else".
- [ ] Every word a fix put on an image is true and its source is named in the log.
- [ ] The full list was announced with ONE estimate line and checked against the routine-fix policy's limits; inside them it ran on the report, and a crossed limit or a paid regeneration stopped once for one approval, never per item.
- [ ] Every local fix went through `composite_region.py` with 0 pixels changed outside its boxes, the seam was read at 3x, and the whole-frame render was kept beside it.
- [ ] `images/` (and `aplus/`, `variations/`) are untouched: nothing there was written, renamed, or deleted.
- [ ] The round folder `edits/vN` holds the COMPLETE current set: new renders for the fixed files, unchanged copies of every other file, same filenames throughout. Nothing downstream needs a second folder.
- [ ] Every edit ran off the previous round's file (or the `images/` original on round 1), never off a stale version.
- [ ] Failed renders are renamed `[name]-rejected.png` inside the round folder and the parent copy was restored as `[name].png`, so no later room can pick a reject and no file is missing.
- [ ] The hash check ran on every render BEFORE the visual compare, both short hashes are in the log, and an identical pair was treated as a failed edit, never as a subtle success.
- [ ] The `images/` original and the fix were both opened (plus the `v[N-1]` parent for chained edits), other on-image text was transcribed and confirmed, and the product part count was counted, not assumed.
- [ ] Every fixed image has a round-named 160px squint copy on disk and passed the compliance gate. No full-size legibility judgments.
- [ ] Every item is in `edits/fixes-log.md` under its round header: edits, routings, refusals, and blocked items.
- [ ] All output is English with zero em or en dashes.

## Troubleshooting

- **"wrote ... bytes" never printed:** no file was written. Read the error the guard printed. Nothing is logged as SUCCESS.
- **A verification or organization error from the API:** the OpenAI organization needs its one-time verification at platform.openai.com. See `guides/mcp-setup-guide.md`. The room parks as blocked, the routing still runs.
- **The API refuses the prompt on content policy:** almost always a face, a person, or a third-party logo in the instruction. Rewrite the prompt to name only the region and the change, or route it to regeneration.
- **The fix landed but something across the frame broke:** that defect was regenerate territory. Rename the output rejected, restore the parent copy so the round folder stays whole, and send it to the ovens with a tighter brief.
- **The hashes came back identical:** the API returned the input unchanged (it happens, quietly). Nothing was fixed no matter how the render looks. Retry once with a more explicit prompt naming the exact region; a second identical pair routes to regeneration.
- **`sips` not found (Windows):** use the ImageMagick or Pillow line in step 10. Missing Pillow: `python3 -m pip install pillow`.
- **The same defect failed twice:** stop editing. Two failures is the policy's attempts limit: the next route is a regeneration from this file as the base, which waits for one yes. Not a different image.
- **`composite_region.py` reports pixels changed outside the boxes:** the render came back at a different size or the box is off. The tool already resized; re-measure the box on the base, and never widen the feather to hide drift.
- **The owner says "just find another one":** that is the owner asking for an alternative, which is lawful. Say in one line what the fix would have cost and offer both; do not decide for them.

## Wonka lines

Openers:
- "To the Fixing Room. Small tools, steady hands, and absolutely no improvising."
- "One flaw, one scalpel. We do not repaint the whole candy to fix a smudge."
- "Bring the patient in. And bring the original. We never operate without it."

Closers:
- "Fixed, verified, and the original sleeps safely in images/, untouched as always. Back to the Inspection belt."
- "One new round folder, the whole set inside it, nothing scattered. That is how a factory keeps its shelves."
- "Two cents of surgery and the candy is whole. I do enjoy a bargain."
- "That one needs the ovens, not the scalpel. Off to the generation rooms with a stricter brief, and your pick goes in as the base."
- "Two tries is my limit on one wound. The ovens get it next, built from this very frame. I do not go shopping for a different candy."
- "No. Not on a main image, not for anyone. The message is welcome. It moves to the gallery, where it is legal."
- "A hundred tasters asked for a lie, and a hundred reviewers already paid for it. Noted, and refused."
- "The tasters told us what to sharpen, and we sharpened exactly that. Now let them taste it again."

## Definition of Done

A run is done in one of two lawful shapes, and both end with the log on disk.

**Shape one, edits ran:**
- A new round folder `edits/vN` exists and holds the ENTIRE current set: the fixed files as new renders, every other file copied in unchanged, same filenames. Every failed attempt inside it is renamed `[name]-rejected.png` with its parent copy restored.
- `images/` (and `aplus/`, `variations/`) are exactly as they were before the round. Write-once means write-once.
- Every fix was verified side by side against the `images/` original (and the `v[N-1]` parent for chained edits) and re-inspected, with its round-named 160px squint copy on disk.
- `edits/fixes-log.md` holds the round header plus a complete entry per item, including the running cost total.

**Shape two, no edit ran** (everything routed, refused, or blocked):
- NO new round folder is opened. A `vN` exists only when a render landed in it.
- `edits/fixes-log.md` still holds an entry per item with its route or refusal reason. A routing-only run is a real result and it is never dressed up as an edit.

In both shapes:
- Every REGENERATE item left with the current file named as its base and the exact sentence its tighter brief must contain, addressed to a named room.
- The report to the owner says, per file, found / fixed / open, with before and after attached. A round never closes as "nothing flagged" with a factual defect still open on a file in scope.
- MODE B: each change is tied to a note and its taster count, the refined winner keeps its original candidate id, and any challenger is queued with `/main-image` for Round 2.

## Update status.md

Add a Log line: `[date] Fixing Room (MODE [A/B]): round v[N], [n] edits on [files], [n] routed to regeneration, [n] refused, ~$[X.XX] spent. Current set: edits/v[N]. See edits/fixes-log.md.`

MODE A: INSPECT stays `in progress` until the re-inspection passes, then it follows the Inspection Room's status. MODE B: PROVE stays `in progress`, and the refined winner plus the refined frame go on to `/ready-to-upload` (labelled `refined after test`), or back to `/tasting-room` for an optional Round 2 when the change was big enough to be a different image.

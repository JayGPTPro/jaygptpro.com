# Day 5: The Main Image Room

Today the factory makes its most valuable single asset, and then teaches you the loop that
everything else in this bootcamp passes through.

**The sentence for the day: the main image is the one thing you fully control, so it is the one
thing always worth improving.**

## What you will have by the end of today

- **Around two hundred hero candidates from TWO machines**: Genrupt's Draft Blast plus the OpenAI
  Blast, each spread across several strategies, because the best five of two hundred beat the best
  five of ten
- **Between one and five mains chosen** and on your disk, one of them safely compliant as a swap-in
- A scorecard: described literally, scored, squint tested at thumbnail size, gated for compliance
- At least one repair done, with the original still on disk
- **The quality loop, learned once and yours from here on.** Days 6, 7 and 9 use it without
  re-teaching it

**Time needed:** 75 to 100 minutes, including generation waiting time.

## What you will need at hand

- Your approved `brief/creative-brief.md`, with its MAIN section fresh in your head
- Your locked reference with a **passed** smoke test, and your brand kit with its preset attached
  (both from Day 4)
- Your current live main image, so you have something to beat
- Genrupt open in a browser tab. **Two of today's four lessons happen there rather than in the
  terminal**, and that is on purpose

---

## Lesson 1: Why the main image

Slides. No terminal, no Wonka. This is the doctrine, and it is the most opinionated part of the
bootcamp.

### Everything that moves the needle, and who controls it

Rating. Review count. A Best Seller badge. Price. Rank. Ad spend. Images.

Now cross off everything you cannot change this afternoon. You cannot raise your rating today. You
cannot conjure four hundred reviews. You cannot award yourself a badge. Price you can move, and it
costs you money on every unit.

What is left is the images. And one of them does something none of the others do: **the main image
is the only asset that competes in search.** The other six sell to somebody who has already clicked.
The main earns the click in the first place.

One image. Fully in your control. Changeable in an afternoon. Most sellers treat it as something
they did once at launch.

### The snowball

Improve conversion by nought point one percent. That sounds like nothing, and it is not, because of
what it feeds:

More conversion, so more sales. More sales, so better rank. Better rank, so more sessions. More
sessions and more sales, so more reviews. More reviews, so more conversion.

It is a loop, and you just pushed it. A small push on a loop is not a small result, it is a permanent
change in the direction the whole thing rolls.

**Which is why the honest recommendation is that you should have an A/B test running on your main
image at all times.** Not when you get round to it. Always. There is always a next thing to try, and
even a slightly different angle can move it. That is also why this bootcamp puts several mains in
your hands rather than one: you cannot run a test with a single image.

### The four ways to build a hero

You choose which of these are in play. **Enable several. Not one.**

| Tactic | What it is | When it earns its place |
|---|---|---|
| **Hang tag** | A physical tag on the product with your words, 28 characters | How a claim gets onto a main image legally. It is a real object, not an overlay |
| **Avatar interaction** | A person's hands or presence | Scale and warmth. Forbidden in some categories, so know yours |
| **Packaging** | The real retail box in frame | Strong when your box is good, and it answers "what actually arrives" |
| **Genrupt's choice** | The planner decides | Worth including. It has seen more listings in your category than you have |

A hundred drafts spread across four strategies is a real experiment. A hundred drafts of one strategy
is a hundred versions of a single opinion.

### And a fifth thing, which is not a tactic

**The vanilla control: a plain product shot, no tactic at all.**

It is worth understanding why this one works differently, because it is the safety net for everything
in the next section.

Vanilla is not a strategy you add to the list. **It is the list, empty.** You get it by running a
second, tiny job with every tactic switched off, and it takes about a minute.

So it does not arrive free inside your blast. It is a deliberate extra step, and **it is not
optional.**

**And turn OFF what does not apply.** If your product ships in a poly bag nobody sees, packaging is
not a strategy, it is twenty-five wasted drafts. Say so and it comes out.

### The risk conversation. This is Jay's doctrine, not a rule of the course

Amazon's terms want a main image on pure white, product only. That is the written rule. In practice,
across most categories, enforcement is not black and white and there is more room than most sellers
use.

In ten years Jay has not heard of an account closed over a bolder main image. What happens is the
image comes down and you swap it back. **That is the actual downside.**

So the working method: **find the image that converts best, even if it sits furthest from the letter
of the terms, then walk back from there** until you are somewhere you can live with. Starting from
safe and creeping outward means you never find out what was possible.

There are levels. A hang tag. Something in the background. Ingredients beside the product. Those are
not the same as a screaming graphic, and treating them as equally risky is how people talk themselves
out of every improvement.

**Two things make this advice safe rather than reckless, and they are not footnotes.**

**Categories are not equal.** Some are policed hard: supplements, anything medical, anything
regulated. If that is you, this whole conversation is smaller, and you should play with the room you
actually have. Know your category before taking this advice.

**The safe version must EXIST before the bold one goes live.** Not planned. Not intended. Generated,
saved, sitting in your folder ready to swap. That is exactly what the vanilla control is for, and it
is why the extra minute it costs is the best minute you will spend today.

With the safe one ready, the worst case is an afternoon of mild annoyance. Without it, the worst case
is your listing sitting there with no main image while you scramble. Same risk, completely different
consequence, and the difference is ten minutes of preparation.

**If you will not take any risk here, you will not grow. If you take it without the safety net, you
have earned the afternoon you are about to have.**

### Why a hundred

Take the best five out of ten. Now take the best five out of a hundred. The second set is better, not
because the machine improved but because you had more to choose from.

This is the cheapest quality upgrade available to you and it costs a few minutes of waiting.

---

## Lesson 2: Generate

Everything that decides how these hundred images come out was decided on Day 3, in your brief.
Today confirms it.

Wonka reads the controls back, one line each: which tactics are in, which are out and why, mix and
match on, the hang-tag text with its character count, packaging on or off with the bucket count.

**Two checks worth understanding:**

- **The hang-tag words are YOUR words.** If your brief chose a phrase, it lands in the field. Leave
  it empty and the machine writes one from the buyer signal, which is lawful but silent.
- **A packaging tactic needs real packaging photos.** Enabled tactic plus empty bucket equals an
  invented box, and an invented box on a hero image is a returns problem wearing a design problem's
  clothes.

Then he stops and asks. About a hundred drafts for a hundred credits, on one slot. **The Draft
Blast is the one generation that gets its own go-ahead**, and it is worth understanding why, because
it is the exception to how the rest of the week works.

Approving your brief pre-approved the planned flow: the reference sheet, the smoke test, the batches
the brief specified. Those get reported as they run, never gated, because a gate on work you just
specified is only a delay. A hundred credits on a single frame is a different size of decision, so
it joins the short list that always stops first: the Draft Blast, any re-spend on a slot that
already produced candidates, a Tasting Round, a paid edit batch, and a balance that will not cover
the run.

He will name the cost against your live balance and wait. Say yes.

### And then the small one

When the blast lands, Wonka runs the **vanilla control** as its own tiny job: every tactic off, a
plain product shot, a minute of work.

It is a separate run because vanilla is not a tactic that mixes with the others. **Do not let him
skip it and do not skip it yourself**, however good the hundred look. This is the image that makes
this morning's risk advice safe rather than reckless, and the whole point is that it exists before
you need it.

### The spread check, which almost nobody does

With four tactics enabled and mix and match on, those hundred should arrive spread across all four.
Roughly twenty-five each.

**Ask for the count before you start picking.** If they all came back as one strategy, the run failed
and you are about to spend an hour choosing from a broken batch. **A lopsided run is a failed run
wearing a successful one's clothes**, and it is only obvious if somebody counts.

### The second blast: the OpenAI machine bakes its own tray

While the Genrupt drafts land, Wonka runs the SAME assignment through the second machine: the
**OpenAI Blast**, dozens of prompts he authors himself on your OpenAI key, at low quality, for a
couple of dollars total. Same owner answers, zero new questions: the tactics you enabled become his
prompt tiers, from the ultra-safe plain shot, through tags (including die-cut shapes carrying one
real claim), through the product's own contents in motion and hands in honest use, up to one
art-directed creative frame. Before he writes a single prompt he reads your competitors' mains from
the Day 2 research and writes down the moves he is beating.

Why run both? It is nearly free, it is a real backup (either machine down, today still happens),
and the two machines have different taste, which is exactly what you want in a pool you pick from.
His pool lands on your disk with a contact sheet, so you judge it in a grid just like Genrupt's.

### Then you leave the terminal

Two hundred images are not something to look at in a chat window. Genrupt has a grid built for
exactly this, and the OpenAI pool has its contact sheet, so that is where you go. **The agent does the work, you do the judging, and each of you gets
the interface you are good at.**

Scroll the whole pool once WITHOUT judging. You are calibrating your eye to the range before choosing
inside it. People who pick the first good one they see at image four regret it at image sixty.

---

## Lesson 3: Choose

### Read the criteria BEFORE you look

Your brief wrote selection criteria on Day 3, when you had no images in front of you and could
not fall in love with one.

**Read them before the grid and it is judgment. Read them after and it is a rationalisation of
whatever you already liked.** That is the entire reason they were written three days early.

### Two passes

**First pass, fast, and be brutal.** You are not choosing, you are eliminating. Wrong product, wrong
count, invented junk, unreadable small. Gone. Ninety seconds should cut a hundred to about twenty.

**Second pass, slow, against the criteria.** Does this answer the question your buyers actually ask?
Does it beat what is live right now, and by what mechanism?

**And look at it small.** Shrink it, step back, or squint. Your buyer sees this at postage-stamp size
in a row of rivals. An image that only works at full size does not work.

### Compare, for when you are stuck

You will get stuck between two. Everyone does, and staring harder does not resolve it. Genrupt's
Compare view puts them side by side, and the difference you could not name suddenly has a name. Once
it has a name you can check it against the criteria instead of against your mood.

### Select between one and five

**Not one.** One is a favourite. Several is a test, and on Day 8 you race them against each other
and against what is live today.

If you choose four, make them genuinely different from each other. Four versions of the same idea
teach you nothing.

**And keep one that is safely compliant.** That is your vanilla control, and this is the moment it
earns its place: it is your swap-in if a bolder one ever comes down. Selecting it costs you nothing
today and saves you an afternoon later.

### Bring them home

```
Selected. Bring them in.
```

You do not type out which images you picked. **Wonka reads the selection**, so nothing gets copied
between you and nothing gets mistyped. He reads back what he found selected before downloading, which
catches a stray click or a leftover selection from an earlier round.

They land in `images/`, and that matters: everything from here reads that folder. Leave them living
only in Genrupt and Day 6 opens on an empty directory.

---

## Lesson 4: Inspect, and fix

**This is the most reused lesson in the bootcamp.** Days 6, 7 and 9 point back at it instead of
re-teaching it.

### Two commands, two different jobs

`/inspect` **judges.** It does not touch anything.

`/fix` **changes.** It does not judge.

Keeping them apart is what stops you quietly editing an image until you like it and calling that
quality control.

### What inspection actually does

It **describes** each image literally before scoring it. That sounds like a wasted step and it is the
most important one: a model that starts by judging tends to judge what it expected to see rather than
what is there.

Then the squint test, done **mechanically**: the image is shrunk to thumbnail size and read at that
size, not eyeballed at full size and imagined. Every time somebody eyeballs this instead of measuring
it, small text ships.

Then compliance, which is not taste: an invented badge, a fake rating, a claim with nothing behind
it. Those are flagged rather than scored.

### Edit or regenerate. The routing that saves you the most money

**Edit** when the change is subtraction or substitution: remove a stray element, shorten a label, swap
a word. The image is right and one thing on it is wrong.

**Regenerate** when the change is structural: make the text bigger, move it, change the layout, change
who is in it.

Why the line is there: an edit re-renders part of the picture, and asking a model to enlarge text
usually gets you enlarged, garbled text plus a subtly different product. **You will spend money to
make it worse.** Regenerating with a tighter brief costs about the same and actually works.

**The rule:** if you can describe the fix as "take that away" or "change that word", edit. If it
starts with "make it" or "move it", regenerate.

### Where edits run, and the one exception

Genrupt can edit images and it works fine. But every Genrupt image costs credits, and an edit is a
small change to one you already paid for. So edits route to **the OpenAI API directly**, which you
wired up on Day 1, and it costs cents instead of credits.

**And they run at low quality on purpose.** For an edit, low is almost always enough: you are changing
a word or removing an object, not re-rendering the world. Full quality on a small edit is paying more
for a difference you cannot see.

**One exception, and write it down now because it saves you a mess on Day 7: A+ edits go through
Genrupt, not the API.** An A+ is an assembled multi-module layout, and editing it inside Genrupt keeps
it assembled so the export comes out final. Mains and secondaries: direct API. A+: Genrupt.

### You can drive it yourself

You do not have to route everything through `/fix`. Point at the image, say the change in plain words,
get the edited version back.

**The original is never touched.** The fixed version saves beside it, because you will change your
mind and because a fix that made things worse needs somewhere to go back to.

---

## MISSION 1: Confirm, then generate

```
/main-image
```

Read the controls back with him. Then:

```
Confirmed. Run it.
```

And before you look at a single image:

```
What is the spread across the tactics?
```

Then the one that is easy to forget:

```
Now run the vanilla control as its own job.
```

## MISSION 2: Choose

Read your selection criteria out loud first. Then work BOTH grids: the Genrupt app and the OpenAI
contact sheet. Fast elimination, slow pass against the criteria, Compare when stuck. One shortlist
across both pools.

Select between one and five, genuinely different, one of them safely compliant. Then:

```
Selected. Bring them in.
```

## MISSION 3: The loop

```
/inspect
```

Read the literal description, not just the scores. Then fix one thing, and practise the routing out
loud before you run it: is this a "take away" or a "make it"?

```
/fix
```

**Share it:** post your top two mains in the group. Watching people argue about main images is the
best free education in here.

---

## Optional, for the impatient: this weekend

If one of your new mains is genuinely better than what is live right now, **you can put it up and
start an A/B test today.** You do not have to wait.

Two conditions:

- **Save your current main first**, so you can revert in one move
- Know that on Day 8 we test these against each other with a panel of AI tasters matched to your
  buyer, so nothing is lost by waiting either

This is for people who cannot sit still, and impatience here is not a flaw.

---

## What good looks like

- The spread was checked and reported before you started picking
- **The vanilla control was run as its own job**, and it is on your disk
- You read your selection criteria BEFORE opening the grid
- Between one and five mains on disk, genuinely different, one safely compliant, picked from the
  union of BOTH machines' pools
- The selection was read back to you by count before anything downloaded
- A scorecard exists with a literal description per candidate, not just numbers
- One fix done, correctly routed, with the original untouched beside it

## Common mistakes

- **Picking one.** One is a favourite. You cannot test a favourite against itself.
- **Picking five versions of the same idea.** Different bets, or it is not a test.
- **Reading the criteria after choosing.** That is not judgment, it is justification.
- **Not checking the spread.** An hour spent picking from a single-tactic batch is an hour gone.
- **Skipping the vanilla control because the hundred look great.** It is not there to win. It is
  there for the afternoon something comes down.
- **Editing when you should regenerate.** "Make the text bigger" is a regenerate. Every time.
- **Judging at full size.** Your buyer never will.
- **Leaving your picks in Genrupt.** Day 6 opens on the local folder.

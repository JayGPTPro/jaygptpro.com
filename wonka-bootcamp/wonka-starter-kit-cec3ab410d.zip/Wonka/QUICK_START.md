# Quick Start . 5 Minutes to a Working Factory

Four steps. Then you have an AI Creative Director on your machine.

## 1. Unzip and place the folder

- Download `wonka-starter-kit.zip` from the portal.
- Mac: double-click the zip. Windows: right-click, "Extract All".
- Drag the `Wonka` folder to your **Desktop** so you always know where it lives.

## 2. Open the folder in Claude

**Claude Desktop (recommended):**
1. Open Claude Desktop.
2. Click the **Code** tab (top center).
3. Click the folder picker at the bottom of the chat input.
4. Choose **"Open folder..."** and select `Wonka` on your Desktop.

**Claude Code (terminal), if that is your thing:**
1. Open Terminal.
2. Type: `cd ~/Desktop/Wonka` and press Enter.
3. Type: `claude` and press Enter.

## 3. Say hello to Wonka

Type these three sentences, one at a time. They verify he is alive, in character, and knows his own Factory:

```
Who are you, and what is this factory?
```
He should introduce himself as Willy Wonka, your AI Creative Director, with some theater. If the answer sounds like a generic chatbot, the folder did not load. Re-open it.

```
Walk me through the 5 stations of the Production Line in one line each.
```
He should name RESEARCH, BRIEF, INVENT, INSPECT, PROVE, in order.

```
What would you do if I asked you to skip research and just make me images?
```
He should refuse, charmingly. "No brief, no candy." If he agrees to skip, the character file is not loading: see `guides/troubleshooting.md`.

## 4. Put your first product on the line

```
/meet-my-product
```

Wonka will ask for your ASIN, listing URL, marketplace, brand, and niche, build the product's folder, and hand you a short shopping list of inputs to gather. (Run `/machines-check` first if you want Wonka to verify all his machines and connections are alive.) That is Day 2 in motion. Day 1 is the day before it: keys, machines, and packing the basket your product walks in with.

## What next

- Full setup (a Genrupt account and your OpenAI key): the Day 1 guide, The Front Gate, at `guides/episode1-guide.md`. Genrupt access is included with your ticket.
- The day-by-day journey, 10 days: `guides/episode1-guide.md` (Day 1) through `guides/episode10-guide.md` (Day 10). One guide per day, one room per day.
- What the finish line looks like: `guides/graduation-checklist.md`
- Something broken: `guides/troubleshooting.md`

What you are here to build: a full creative package for your product, generated on your locked real product and raced against your live listing before a dollar of ad spend. "Tested" means the Tasting Room sitting on Day 8, both races, with the fixes it ordered applied. No sales lift is promised. Results vary by product and niche.

"Come in, come in. We're inventing today."

# Day 1: The Front Gate

Today you meet your Creative Director, tour the factory he runs, install him on your computer,
connect his two machines, and print the first thing that comes off the line.

**Watch the first three lessons before you install anything.** They ask nothing of you. You meet
Wonka, you understand how an AI employee actually works, you see all ten rooms, and then the setup
in Lessons 4 and 5 has a point. Nothing here is hard. One thing is easy to skip and can bite later,
the OpenAI organization verification, so it is flagged where it matters.

By the time you close the laptop tonight, the factory is live and standing empty, waiting for the
product that walks in tomorrow.

**The sentence for the day: stop using AI, start hiring it.**

## What you will have by the end of today

- A clear picture of who Wonka is, where he lives, and what he does without asking you
- Claude installed, with the kit folder open, and Wonka answering in character
- A Genrupt account with the Wonka plan activated (first month covered by your ticket)
- An OpenAI API key created, funded, and stored in a private file the chat never sees
- Both machines verified by Wonka himself, with your credit fuel gauge read out loud
- Your factory's First Candy printed: a welcome card that cost a few cents and proved your whole
  image pipeline works end to end

**Time needed:** about an hour, and a good part of it is account signups and waiting.
The video is about 32 minutes across five lessons.

**A word on cost before you start.** Your ticket covers your first month of Genrupt: 1,000
credits. It is a monthly plan, so you enter a card and month one is free; cancel any time during
that month and it will not renew, or keep it at $49 against $99 on open sale. You bring your own
Claude Pro or Max subscription, which is separate, and your own OpenAI credit for the image edits
and the Tasting Room: cents per edit, a few dollars per race, and the bootcamp runs two races (one
Tasting Round on Day 8: the main race and the gallery race). Ten to twenty dollars covers it. That
is the entire bill. There is no survey tool to buy and no research extension to install, because
the Tasting Room runs inside the factory and the research runs on your own listing, reviews, and
competitors.

---

## Lesson 1: Meet Wonka, and how he actually works

*Watch only. Nothing to do yet.*

The single most useful idea in the whole bootcamp, and the one that confuses everybody at first:

> **Your employee is a folder.**

Not a metaphor. It is a folder on your computer. Inside it there is a character file that says who
he is, a set of skills that are things he knows how to do, and a factory of folders where his work
lives. **The folder you open in Claude Code is the employee you are talking to.** Open the Wonka
folder, you are talking to Wonka. That is the whole trick.

No app to log into. No dashboard, no website, no seat to buy. Copy the folder and you copy your
Creative Director.

The second idea: **Wonka translates.** Behind every AI image there are models, tools, APIs and
technical systems. You do not learn to speak the language of any of them. You tell Wonka in plain
language what you want, he translates it into a process the machines understand, and he gets to
work. When you talk to your graphic designer you do not tell them how to use Photoshop; same here.

The third idea is the working relationship, because it decides how this feels all week:

| He does this on his own | He stops and waits for you |
|---|---|
| Research, analysis, and the small routine spends | Any meaningful expense, with the cost shown first |
| Generating from an approved brief | Approving or changing the brief itself |
| Quality checks on everything he makes | Choosing which candidates move forward |
| Fixing small defects and recording what was learned | Picking the final winner |

You talk to him the way you talk to your photographer and your graphic designer. **He does the
work. You approve it.**

---

## Lesson 2: The Factory Tour

*Watch only, and short. Orientation.*

Ten rooms, one per day. Underneath them, five stations that are the actual method: **Research,
Brief, Invent, Inspect, Prove.**

| Day | Room | What comes out |
|---|---|---|
| 1 | The Front Gate | A live factory, both machines warm |
| 2 | Wonka, Meet My Product | A research report on your buyers, complaints, and listing gaps |
| 3 | The Creative Brief | The strategy for the complete image package |
| 4 | The Reference and Brand Rooms | The machines know YOUR product, proved by a test, plus your brand direction |
| 5 | The Main Image Room | A tray of candidates, your pick, and the quality loop |
| 6 | The Secondary Images Room | The gallery, built as a team |
| 7 | The A+ Room | The second page under your bullets, exported in Amazon-ready pieces |
| 8 | The Tasting Room | About a hundred AI shoppers vote, your images against your live listing |
| 9 | The Variations Room | One winner becomes a shelf (optional if your product has no variations) |
| 10 | The Improvement Loop | A final package ready to upload, plus lessons for the next product |

Two loops run through the whole building. **The quality loop**, learned properly on Day 5 and then
running every day after. And **the learning loop**, which is why the Wonka you use for your next
product already knows more than the one you started with today.

---

## Lesson 3: The Wonka Kit

*Your first hands-on lesson. Download, place, open.*

There is no software to install inside the kit and no new account to log into. The whole folder is
about half a megabyte, smaller than a photo on your phone: instructions, guides, his sixteen
skills, and a few small helper files. Claude reads those files, and that is how he knows who he is,
how to work, and where to keep everything he creates.

### Download and unzip

The download button sits in today's room, with Lesson 3. On Mac, double-click the zip. On Windows,
right-click it and choose **Extract All**.

**One quick check before you continue.** Open the `Wonka` folder. You should see `CLAUDE.md`,
`README.md` and `factory/` directly inside it. If instead you see another folder called `Wonka`,
some unzips nest it; use the INNER folder, the one that directly holds `CLAUDE.md`. That is the
employee.

### Give him a permanent home

Move the `Wonka` folder to your **Desktop**, or into the folder where your AI employees live.
**Do not leave it in Downloads.** Downloads gets cleaned out, and this folder will soon hold his
memory and all his work. One place, forever.

Two more placement rules from the lesson:

- If you already have another AI employee, Donna for example, do not put Wonka inside that
  employee's folder. His own folder, his own place to work, beside the others.
- **Keep the name `Wonka` during the bootcamp.** Every skill and process is built for that name.
  After the bootcamp, ask Wonka to change his own name and he will tell you how.

### Open him in Claude Code

1. Open the Claude Desktop app
2. Top of the screen: the **Code** tab, not Cowork
3. Bottom of the chat box: the folder picker. **Open folder**, choose `Wonka`
4. When it asks, choose **Trust workspace**

**The folder you open is the employee you are talking to.** From now on, a new session with this
folder open is a conversation with Wonka, never an empty chat. Do not start product work yet; your
first setup message comes in Lesson 4, when Wonka prepares the private file for your OpenAI key.

### What is inside, so he is never a black box

You do not need to read these files. The lesson walks the folder so you can see the employee is
real and on your drive: `CLAUDE.md` is his operating manual, `guides/` holds all ten days plus
troubleshooting (ask Wonka before you ask Jay, he has read them), `downloads/` holds short
references, `output/` is where finished images leave the factory, `.claude/` holds his character
and his sixteen skills, and `factory/` holds your products, your brand, and the improvement log,
his long-term memory. `.claude/` starts with a dot, so it is hidden: Cmd+Shift+. in Finder on Mac,
View then Hidden items on Windows.

One rule for the folder, and it is the only one: **do not reorganize it.** No renaming files, no
moving folders around. The structure is how Wonka finds his work and remembers what is already
done. Add files only where he points you.

And a habit worth knowing from day one: **back up the `Wonka` folder and you back up the entire
employee.** Skills, memory, products, everything he has learned. One folder.

---

## Lesson 4: Connecting the Machines

*The setup lesson. Two machines, two kinds of plug.*

Wonka can already understand research, plan images, write briefs and inspect results. To generate
and edit images he needs image machines, and we connect two, because they are good at different
things:

| | Genrupt (MCP connector) | OpenAI (API key) |
|---|---|---|
| What it is | A production platform built around Amazon product images | Direct access to GPT Image 2 |
| What Wonka uses it for | The structured Amazon image workflow. It holds your REAL product, so images are your item, not a lookalike | Lower-cost generations and edits, and the Tasting Room |
| Where it lives | The Connectors screen in Claude | A `.env` file inside the kit |

If MCP sounds like jargon, think of a restaurant: Wonka is the diner, Genrupt is the kitchen, and
the MCP is the waiter carrying his order in and the results back. You never walk into the kitchen
and cook.

An API key is the other kind of plug: a door for SOFTWARE. It has its own balance, separate from
any ChatGPT subscription (paying for ChatGPT gives the key nothing). It is a password, so anyone
holding it can spend your balance. And it is made once and shown once.

Better image models will appear one day. When they do, you replace the machine, never the
employee. **Wonka does not get old.**

### Create your Genrupt account

Two steps, in this order:

1. **No Genrupt account yet?** Create one first at **genrupt.com/l/aivault** and click **Apply for
   Beta Access**. Already have a Genrupt account? Skip straight to step 2.
2. Open the Wonka signup page from today's room (genrupt.com/wonka) and enter code **WONKA49** at
   checkout. The link and the code together are what attach your included first month and the
   1,000 credits; a general signup from their website does not.

You do enter a card. Cancel any time inside the free month, even today, and it will not renew.
Keep it and you stay at $49 a month against $99 on open sale.

**Already paying for Genrupt?** Do not open a second plan. Message Jay or Michael and the 1,000
credits go onto the account you already have. Any Genrupt account, billing or credit question goes
to Michael; it is his machine, and his details are under the video.

### Connect the Genrupt MCP

In Claude: **Connectors**, then **Manage connectors** (or the **+** button in the chat box, then
Connectors). Click **Add custom connector**. Name it exactly `Genrupt`, and paste this as the
server URL:

```
https://genrupt.com/api/agent/mcp
```

Click **Add**, then **Connect**, and complete the Genrupt sign-in in the browser window that
opens. The settings screen you land on is your control panel: what he may always do, what waits
for your approval.

> **Then quit Claude completely and reopen it.** Not just the window. Cmd+Q on Mac, quit from the
> system tray on Windows. Claude only loads a connector on a full restart.

### Create your OpenAI key

One key, four rooms: the OpenAI Blast beside Genrupt's on Day 5, the edit paths where fixes cost
cents, the Variations Room on Day 9, and the Tasting Room on Day 8.

1. Go to **platform.openai.com** and sign in or create an account. This is **separate from
   ChatGPT**: a ChatGPT subscription includes zero API credit, even on the same email
2. If OpenAI asks you to complete one-time **organization verification**, start it now. Approval
   can take a few minutes or a day or two, so it is the one step worth doing early rather than
   discovering later with a batch waiting
3. **Billing**: add a payment method and load **$10 to $20** of credit. That covers the
   bootcamp's OpenAI work
4. **API keys**, then **Create new secret key**. Name it `Wonka` if you like, and create it

> **The key is shown once.** Copy it now, and never paste it into a chat, a screenshot, or a
> screen recording. Whoever holds this key can spend the balance in your account. It is a credit
> card number; treat it like one.

Click by click, plus an error table: `downloads/openai-key-and-verification-walkthrough.md`.

### Store the key in the .env file, without the chat ever seeing it

The key lives in one private file named `.env` inside the Wonka folder, and Wonka opens that file
for you. Tell him:

```
Prepare the .env file for my OpenAI key and open it for me. I will paste the
key into the file myself.
```

He creates the file with a placeholder and opens it in your text editor. You paste the key THERE,
replacing the placeholder, save, close, and tell him:

```
done
```

He verifies it without ever printing it back: he reports only that it is present, its length, and
its last four characters.

**If you already pasted the key into the chat**, no drama, one fix: go to platform.openai.com, API
keys, revoke that key and make a new one, and wire the new one through the file. Thirty seconds,
and the transcript now holds a dead key.

---

## Lesson 5: The Machines Check

*The proof lesson. Short, and it closes the day.*

The settings say connected. A label is not proof. This factory has a rule you will hear all week:
**we do not trust labels, we verify.**

### Say hello (this is also your kit test)

Open the `Wonka` folder in Claude's Code tab, start a **new** conversation, and type:

```
Hello! Who are you and what is this place?
```

He should answer in character and tell you the factory is empty. **If he answers like normal
Claude, the folder is not really loaded.** Reopen the `Wonka` folder in the Code tab and start a
new conversation. This is the single most common Day 1 issue.

### Run the check

One command, sent as its own message:

```
/machines-check
```

He runs three checks himself:

1. **Python.** Not a third image machine: a free local process some of his scripts run on. No
   account to create, nothing to pay for, and most Macs already have it. If anything is missing,
   Wonka gives you the one line that installs it.
2. **Genrupt.** A real handshake, plus your credit balance read as a fuel gauge.
3. **The OpenAI key.** Present, valid, and where he looks.

What good looks like: **PASS, PASS, PASS**, and the credit balance on the report. Each FAIL
carries its own exact fix; follow it and run `/machines-check` again.

**Every "it is not working" problem this bootcamp will ever hand you starts here.**
`/machines-check` first, then debug.

### The First Candy

A green key check still cannot prove OpenAI will let your key generate an image. Only a real image
can. So Wonka offers the print, one small generation for a few cents, and waits for your yes:

```
Yes, print the First Candy.
```

A welcome card lands in `output/` and inside the session. A few cents just proved the key, the
billing, the verification, the model access and the generation path, end to end.

**If it fails here, that is the good outcome.** One tiny test found what a full production batch
would have found on Day 5. Follow the exact error Wonka reports, fix it, and run `/machines-check`
again. **Day 1 is complete when all three checks pass and the First Candy is printed.**

That is the day. Python ready, Genrupt connected, OpenAI connected, one print on the tray, and a
factory standing empty. Nothing is registered today, and nothing needs to be: your product walks
through the gate tomorrow, and the first thing Wonka does is tell you exactly what to collect
for it.

---

## Common mistakes, and what they look like

| Symptom | Cause | Fix |
|---|---|---|
| Wonka sounds like a generic chatbot | The kit folder is not really loaded | Code tab, folder picker shows `Wonka`, re open it, start a NEW conversation |
| A slash command does nothing | It was described instead of typed | Type it as its own message, starting with the slash, exactly as named: `/machines-check` |
| The Genrupt machine does not appear at all | Claude was not fully quit | Cmd+Q on Mac, system tray quit on Windows, reopen, run `/machines-check` again |
| Genrupt connects but calls fail | A stale session | Sign in to genrupt.com in your browser once, retry. If it persists, contact Michael |
| First Candy fails with a verification error | Organization verification has not cleared | platform.openai.com, Settings, Organization, Verify. Then `/machines-check` again |
| "No API key" | The key is not where Wonka looks | Redo the `.env` steps from Lesson 4, then `/machines-check` |
| You cannot see the `.claude` folder | Dot folders are hidden | Mac: Cmd+Shift+. in Finder. Windows: File Explorer, View tab, Hidden items. Or just ask Wonka to show you what is in it |

The full list lives in `guides/troubleshooting.md`. And if something is genuinely stuck, post the
exact error in the group. Setup friction is the one thing worth interrupting anybody for.

---

## What good looks like

- [ ] Watched Lessons 1, 2 and 3 before installing anything
- [ ] Claude Desktop or Claude Code installed, Pro plan or higher active
- [ ] `Wonka` moved out of Downloads, in its permanent home, open in Claude's Code tab
- [ ] Wonka answered "who are you" in character
- [ ] Genrupt account created (beta access first if you were new), Wonka plan activated with WONKA49
- [ ] Genrupt MCP connected, Claude fully quit and reopened
- [ ] OpenAI key created, $10 to $20 loaded, verification started if OpenAI asked for it
- [ ] The key stored in `.env` through Wonka's setup prompt, never pasted in the chat
- [ ] `/machines-check` run, with Python, Genrupt and OpenAI all reporting PASS and the credit
      fuel gauge read
- [ ] First Candy printed at `output/first-candy.png`

**One habit worth forming today: tell Wonka where you are in the lessons.** He will ask once which
day you have watched up to, and from then on he paces the factory with you: finish a day's work and
he points you to the next lesson before the next room, because each lesson teaches the decision
that room will ask you to make. Watched several days ahead? Say so, and he will happily run several
days of work in one sitting, as far as the factory gate allows: during the bootcamp round, each
day's room opens on the schedule, and Wonka checks the gate before opening a door.

**Do not open Day 2 until `/machines-check` passes.** Not because anyone is strict, because
tomorrow spends real credits and a cold machine wastes them.

Every day has a list like this one, and together they are the graduation checklist. Walk all ten
and you finish with a full, tested creative package ready to upload. No sales lift is promised.
Results vary by product and niche.

---

## What this bootcamp will cost

Your ticket covers your first month of Genrupt: 1,000 credits, claimed with the link and the code
at signup. You bring your own Claude subscription and your own OpenAI credit.

| Item | When | Typical cost |
|---|---|---|
| Claude Pro or Max | ongoing | $20 per month and up. Your own subscription, separate from the bootcamp |
| Genrupt | first month covered by your ticket | 1,000 credits, then $49 a month if you keep it ($99 on open sale), and nothing if you cancel inside the free month. On average 1,000 credits is enough for 2 to 3 products; top up at Genrupt if you burn through it |
| OpenAI credit | the fixing and tasting days | $10 to $20 loaded. Cents per edit, a few dollars per race, two races across the bootcamp |

For scale: one professionally designed listing image runs $50 to $200, and a full untested set runs
$500 to $1500. You are building the factory, not paying per candy.

A standing rule you will hear all bootcamp: Wonka never spends your money silently, and he also
never stalls the line asking you the same question twice. There is ONE pre-authorisation point,
your approval of the creative brief on Day 3. It covers the planned flow that follows it: the
reference sheet, the smoke test, and the planned generation batches. Those are REPORTED as they
run, with the cost line, not gated.

A short named list still waits for a fresh yes every single time: a 100-credit Draft Blast, any
re-spend on a slot that already produced candidates, a Tasting Round, a paid edit batch, and
anything at all when your balance will not cover it. Silence is never a yes.

---

## Common questions

**"Where does Wonka actually live? Is he installed somewhere?"**
He is the folder. Personality, skills, and memory are all files inside `Wonka`. Copy the
folder and you copy your Creative Director. Nothing else is installed.

**"Why do I watch three lessons before doing anything?"**
Because setup is boring and meaningless until you know what it is for. Meet the employee, see the
building, understand the kit, then connect the machines. It makes the rest of the day make sense.

**"Can I use Claude Code in the terminal instead of Claude Desktop?"**
Yes, fully. Open a terminal, `cd` into the kit folder, run `claude`. Every prompt in every guide
works identically. The guides describe Claude Desktop click paths because most participants use it.

**"I sell in a non US marketplace. Does this work?"**
Yes. The method is marketplace agnostic. Your reviews and competitors come from your marketplace, so
the research reflects your shelf, and the Tasting Room's panel is conditioned on your real buyer
whatever marketplace they shop in.

**"What if I have several products?"**
Pick ONE for the bootcamp when Day 2 asks. The factory happily runs a portfolio afterwards, and
Day 9 shows you how to multiply. Learning the line is a one product job.

**"Do I need Brand Registry?"**
No. It unlocks the demographics export and the optional Amazon A/B at the end. Without it, personas
are estimated and clearly labelled as estimated, and every room runs identically.

**"Why is there no survey tool to sign up for?"**
Because the Tasting Room runs inside the factory, on the same OpenAI key you already created. A few
dollars a round, results in minutes. To be straight with you about what it is: the tasters are
synthetic AI personas conditioned on your real buyer, so the verdict is directional and the real
value is the objections they hand you in their own words. It is not a panel of real shoppers, and
nowhere in this bootcamp will it be sold to you as one.

**"Can I change Wonka's name or move his folder later?"**
After the bootcamp, yes to both. During it, keep the name `Wonka` and keep the folder where you
put it today. Every skill, guide and process is built for that name and that structure.

---

## What Day 2 opens with

Exactly what you leave here holding: two warm machines and an empty floor.

Day 2 is Wonka, Meet My Product, in three lessons. First you photograph your product and its
packaging, five to ten phone photos that each add information, so Wonka never has to guess.
Then one command registers the product: you hand him your Amazon link and one ZIP with the
photos and anything private you have, he reads the listing himself, proposes the niche, shows
you one card to confirm, files your ZIP with a receipt, and asks only the things no page can
hold. He closes the interview himself and goes to work. The third lesson opens his Product
Report: the table stakes, the pains in buyers' own words, your real buyer, the whitespace
nobody in your niche is showing, and a diagnosis of where your listing is actually losing
sales.

As the man says: "Every great candy starts with knowing exactly who it is for."

---
name: secondary-images
description: Generate the SECONDARY image set (5 to 7 slots) from the creative brief, using Genrupt (primary) or gpt-image (fallback), with set-level variety and legibility rules, and cost reported rather than gated. Also re-runs a single slot when /inspect or /fix sends one back for regeneration. Use when the brief, the locked reference, and the brand kit are done and the user wants the gallery produced, or when one gallery frame must be rebuilt. Triggers: /secondary-images, "generate the secondaries", "make the gallery", "secondary set", "lifestyle images", "infographic images", "secondary images room", "regenerate slot", "rebuild that frame".
---

# The Secondary Images Room

| Meta | Value |
|------|-------|
| Room | The Secondary Images Room |
| Station | INVENT (secondaries are one of the four Invent sub-parts) |
| Day | Day 6 in the bootcamp (the gallery). Also runs any time a single slot is sent back for regeneration |
| Modes | MODE 1: the Theme Blast, ten style directions across the whole gallery. MODE 2: Restyle and Refine, the chosen style applied and more frames generated inside it. MODE 3: a Draft Blast on ONE slot Refine did not serve. MODE 4: one slot re-run, driven by a scorecard flag or a tasting note |
| Needs | brief/creative-brief.md (the secondary slot plan), 2-reference/reference-sheet.md (LOCKED, smoke test PASS), factory/Brand/brand-kit.md (soft), a live generation machine |
| Saves to | factory/Products/[product]/images/ (sec-01.png .. sec-07.png, re-runs as sec-NN-v2.png) |
| Typical cost | Theme Blast: 1 credit per image, so ten rows across seven slots is about 70. Draft Blast: 100 credits flat, for ONE slot. **Reported, not gated.** The owner's brief approval authorises the production run; say what it will cost, run it, then say what it actually cost. The one thing named out loud FIRST is a Draft Blast, because 100 credits on a single frame is a decision rather than execution. |

## What this room does

The Secondary Images Room turns the brief's slot plan into the gallery: the images that do the selling after the main earns the click. It runs in three gears, in order, and using them out of order is the expensive mistake.

**Gear one, the Theme Blast.** Ten complete visual directions, each applied across every supporting slot, at one credit per image. Not ten variations of one frame: **ten different-looking versions of your whole gallery**. This is where fonts, colors and composition finally get judged, after the Day 4 smoke test deliberately deferred them.

**Gear two, Restyle and Refine.** The owner picks the style and the composition they want, sends that to **Refine**, and from then on every new generation carries the chosen look. More rounds can run inside Refine, gathering the best of the best. **This is the normal path to a finished gallery**, not an optional extra: the first blast finds the direction, Refine finds the frames.

**Gear three, a Draft Blast on one slot.** About a hundred drafts for ONE frame, a hundred credits flat. The deep dive, and the last resort, for a slot that Refine still has not served. Reaching for it on every slot is how somebody burns a thousand credits improving frames that were already finished.

**The house default: `mobileFriendly` stays ON.** It is Genrupt's product-aware enhancer for typography, color, backgrounds and mobile readability, and it is what produces big text and restraint instead of walls of copy. That default encodes a real position: on a phone, one message read is worth more than four messages present. **An owner who genuinely wants denser, more copy-heavy frames can turn it off**, and that is a legitimate choice for some categories. Say the cost when they choose it: turning it off routes the prompt down an older path that can drop the constraint sentences we put in `customInstructions`, so the "never show hands" and "the scoop must be visible" kind of instruction may simply not arrive. Nothing errors. The images just come back non-compliant with no explanation. If the owner turns it off, every constraint gets re-verified by eye at `/inspect` rather than assumed. It is a decision to make out loud, once, not a switch to flip silently.

Scope of THIS room is the secondary set only. The main image, A+ modules, and variation imagery are generated in their own rooms (`/main-image`, `/aplus`, `/variations`) off the same brief and the same locked reference. Nothing that comes out of this room is final: everything goes to the Inspection Room next, and the gate-passed set later faces the Tasting Room's gallery race against the live Amazon gallery.

## Before you start

Check the preconditions in this order. Report what you found out loud before spending anything.

1. **Brief. HARD.** `brief/creative-brief.md` exists with the secondary slot plan and is marked done in `status.md`. Missing: station **BLOCKED**, point to `/creative-brief`, stop. Sub-check: if the brief contains "pending brand kit", resolve those fields from `factory/Brand/brand-kit.md` before generating.
2. **Locked reference. HARD.** `2-reference/reference-sheet.md` exists with `Reference status: LOCKED` and `Smoke test: PASS`. An approved reference WITHOUT a passed smoke test does not count; the smoke test is the only proof the lock actually holds. Missing or unpassed: **BLOCKED**, point to `/reference-sheet`, stop. Also read the sheet's `source:` field: if it records `amazon_scraped`, say so plainly once ("this reference was built from listing and review images, not from photos of the unit, so product likeness is the weaker path here"), tighten the fidelity check in step 8, and carry the source into the batch log.
3. **Brand kit. SOFT.** `factory/Brand/brand-kit.md` exists, with its branding preset ATTACHED to this product's saved plan (a preset that exists but was never attached dresses nothing, and it fails silently). Missing: offer `/brand-kit` first, it is a short room, and it does NOT need the owner to have brand files: with none, it proposes a full kit from the product, the category and the buyer. If the owner declines the room entirely, that is a real answer: PROCEED, record `brand kit: declined (owner)` in the batch log and in the status line, generate on the reference plus the engine's neutral defaults, and warn once that brand fit will score "no kit on file" at inspection. This room never invents a palette or a font itself; proposing one is `/brand-kit`'s job and it is done with the owner watching.
4. **A generation machine.** Confirm which path applies: Genrupt MCP connected (primary) or gpt-image fallback on the OpenAI key. If Genrupt is expected but not responding, say so and offer the fallback explicitly; never switch paths silently. If NEITHER machine is available, the room is closed: mark `blocked: no generation machine` in `status.md`, point to `/machines-check` and `guides/mcp-setup-guide.md`, and stop.

Two standing rules for everything below. **The brief owns the slot count**: never invent an extra frame and then look for a job to give it, and never quietly drop one; a set that should grow or shrink is changed in the brief first. **The brief and the Reference Sheet own the facts**: if a slot asks an image to assert a capacity, a certification, a material, or a number that the Reference Sheet and the research files do not support, stop and fix the brief. An invented fact on a listing image is an account risk, not a style choice.

## Process

1. **Establish the MODE, then load the plan.**
   - **MODE 1, the Theme Blast.** The opening move for a gallery that has not been styled yet. Read every slot brief, the coverage map and the restated avoid list FIRST; ten style directions across a gallery that is briefed wrong is ten wrong galleries.
   - **MODE 2, Restyle and Refine.** The normal continuation, and where a gallery is actually finished. The owner picks the style AND the composition they want, that gets sent to Refine, and every generation from then on carries it. More rounds may run inside Refine; each one is cheap and each one raises the ceiling.
   - **MODE 3, a Draft Blast on one slot.** Only after Refine has run, and only for a slot Refine still did not serve. State THREE things in writing first: which slot, what is wrong with the refined version, and what a hundred drafts fixes that another Refine round would not. **"It could be better" is not a reason to spend a hundred credits.** If the answer is really about the brief rather than the picture, fix the brief instead.
   - **MODE 4, one slot re-run.** A frame coming back from `/inspect`, from `/fix` MODE A (a REGENERATE-class defect), or from `/fix` MODE B (a tasting note). State WHICH slot, WHAT the defect or note is, and the EXACT sentence the tighter brief now carries. A re-run with no named driver is a reroll: refuse it and ask what changed.

2. **Read the plan back, then enforce the SET-level rules against it.** Say each slot out loud in one line (slot, job, message, person yes or no). This is the last cheap moment to catch a slot that drifted. Verify these before generating, and fix any failure through the brief, never by improvising here:
   - **One job, one message per slot.** Each slot exists to do exactly one thing, with one dominant headline.
   - **No two slots share a message or headline.** A repeated message is a wasted slot; the gallery is too expensive for reruns.
   - **At least one emotional frame.** One slot sells the feeling or the outcome, not a spec.
   - **Avatars own casting; slot text owns nothing about people except whether one appears.** On the Genrupt path, casting is a STRUCTURED FIELD (intake guide, section 2.1): the persona in The Product Report is translated into 1 to 2 custom avatars with an EXPLICIT age and gender (the displayed age follows the brief's aspirational casting, a vital version of the real buyer). Per-image variety is AUTOMATIC and always on: within those constraints Genrupt varies appearance across the set so the same face does not repeat. Never request variety in prose, and never describe or specify a person inside a slot's text; casting sentences in a brief are ordinary creative input and can be re-scoped or dropped. Whether a slot shows a person at all is the brief's job. Inspection still checks that no face repeats (variety is automatic, not an identity guarantee).
   - **Legibility.** One headline per slot, at most about 3 supporting labels or icons, big mobile-legible text, no icon soup and no wall of words. Win legibility by subtraction: fewer elements means bigger text.
   - **Casting gap handling.** If the brief gives no persona to build the avatars from, derive them from the persona section of `research/product-report.md` (The Product Report) with the aspirational skew, state the derived age and gender out loud, and record them in the batch log as derived. If there is no persona there either, ask the owner for one line (roughly what age, which gender). If that too comes back "I don't have it", that is a real answer: generate the people-bearing slots WITHOUT people and say so, because an avatar with blank age and gender pins nothing (that blank default is exactly what caused the old casting drift) and it is never worth the credits.

3. **Report the cost, then run.** One line before: "[gear], [N] images on [path], about [credits/dollars]." One line after: what it actually cost. **Do not stop for permission** on a Theme Blast. The owner approved the brief and this room executes it; a gate there only delays work they already said yes to.
   **Two things DO stop and get named first, because they are decisions rather than execution:** a Draft Blast (a hundred credits on one frame, see step 4b), and a re-run of a slot that already generated (say what changed and why the first attempt is being spent over).

3b. **MODE 1: run the Theme Blast, and let the owner read it as ROWS.**
   - Run it once the plan is verified. About one credit per image, so ten rows across the set is roughly ten credits per slot. The main image is excluded by design; the hero is `/main-image`'s work and it is already decided. `mobileFriendly` stays at its default unless the owner has explicitly chosen otherwise (see the house default above).
   - Read the result back (`get_listing_builder_blast_images`) and report what came: how many rows, how many slots each, and the row anchors. **Say the total out loud**, because volume is the point: seventy frames or more means the best of them is genuinely good rather than merely available.
   - **Then hand it to the owner in the Genrupt grid and tell them what to judge**, because this is the moment style finally gets judged. Day 4 told them explicitly NOT to look at fonts, colors and composition. Say plainly that the wait is over and this is the payoff.
   - **They read ROWS, not columns.** Each row is one coherent look across the whole gallery. Say this out loud, because the instinct is to cherry-pick the prettiest frame in each column, and a gallery assembled from four rows reads as though four different people made it.

3c. **MODE 2: Restyle, send to Refine, and generate inside the chosen look.**
   - The owner chooses the **style** and the **composition** they want to carry forward, then sends that through **Restyle and Send to Refine**. Confirm what was chosen by reading it back rather than assuming the action took.
   - **From this point every new generation inherits that look.** Say that explicitly and show it: the first Refine output beside a frame from a rejected row makes the lock visible in a way no sentence does.
   - **Run more rounds inside Refine.** This is expected, not indulgent: each round is cheap and the whole doctrine of this room is that the best of many beats the best of few. Stop when a round stops producing anything better than what you already have, not at a fixed number.
   - The owner picks the final frame per slot from everything Refine has produced. Same method as the hero: fast elimination, then a slow pass against each slot's job in the brief, Compare when stuck. **One frame per slot**, because unlike the hero there is nothing to A/B test in a gallery slot.
   - **Read the selection back before downloading**, by name and count. Never assume a selection took.
   - **Feed the GENERALIZABLE reasons forward**, exactly as `/main-image` does with its shortlist: a rejection or pick reason that names a look, an element, or a rule ("no flat-lay grids", "always show the product plugged in and running") is appended as a dated bullet under **Owner creative preferences** in `factory/Improvement Log.md`, in the owner's words, and the recording is said out loud. A reason that only compares frames stays in the batch log. This is what lets the NEXT brief's rejection pre-flight actually know what this owner already said no to.

4. **Generate. Path A: Genrupt (primary). The rules below apply to EVERY gear: the Theme Blast, a Draft Blast, and a single-slot re-run.** Genrupt owns prompting and generation; this room owns DISTILLATION (the law: `guides/genrupt-intake-guide.md`). Never write image prompts. **The plan already exists: `/creative-brief` saved it when the owner approved the brief** (its `## Send log` records the date, the slot count, and the cast). Open THAT plan. Do not plan from the ASIN again, and do not re-plan: re-running the planner wipes every slot's approved text and reverts casting. Only if the send log shows no saved plan (the brief was approved while Genrupt was down) does this room run the send itself, following `/creative-brief` step 17 exactly, and record it back into the brief's send log. **The intake principle: DISTILL, DON'T FORWARD.** Dumping the whole brief into every slot's text produces WORSE images, because your prose competes with the plan the model needs to land. Operating rules, all mandatory:
   - **Verify the saved plan still carries the owner's text BEFORE spending anything.** Read it back with `get_listing_builder_plan_review` and compare each secondary slot's `buyerQuestion`, `contentBrief` and `headerPhrases` against the brief's Funnel B blocks, plus `selectedAvatars` against the cast. A mismatch means something re-planned since the send: stop, say which slots drifted, restore them from the brief, and only then generate. This is a free check standing in front of a paid batch.
   - **Read the full plan, modify it, send back EVERYTHING.** Every edit starts from `get_listing_builder_plan_review`: it returns the full editable snapshot plus an `editableFields` map naming exactly what the save accepts back. On `save_listing_builder_plan_review`, always send the full `slotAssignments` array, even to change one slot; partial arrays are rejected, deliberately, so a sloppy call cannot erase other slots. Field semantics, exact: omit a field to preserve it, send `[]` to clear a list, send `text: null` to clear an instruction. Never "helpfully" resend empty arrays for fields you did not mean to touch.
   - **Slot 1 (the main image) is protected: round-trip it unchanged.** It is edited only through the main-image controls the setup flow exposes (tactic, hang-tag text, packaging preference), never through briefs, headers, custom instructions, or slot references. Those three controls are `/main-image`'s conversation with the user, not this room's.
   - **Route the brief into the fields.** Per slot: `contentBrief` = a 2 to 5 sentence visual direction lifted from the brief's slot section (the scene, the objects and their arrangement, whether a person is in frame), never a research summary. The finished headline goes in `headerPhrases` as FINISHED on-image copy (mobile-legible, no placeholder text, no keyword stuffing); header phrases become the mandatory on-image headline text. A second credible angle worth keeping goes to `alternateCreativeBriefs` (max 2, pick the best, do not hoard).
   - **Route constraints before you write them** (guide, section 5). Sort every "must / must never" by what enforces it: casting goes to the avatar fields; physical product accuracy goes to the product reference images, with a clean product description as backstop; brand color, font, and logo go to the branding preset and styleImage built by `/brand-kit`; on-image wording goes to `headerPhrases`. Only what is left ("never show hands", "must include the scoop") belongs in `customInstructions` with `mode: "ADDITIVE"`, a couple of short sentences at most. A constraint sitting in the wrong field is weaker than the same constraint in its own field, and it crowds the brief. Default to ADDITIVE; use OVERRIDE only when the user explicitly wants to replace Genrupt's planned direction, and preserve whichever mode the user approved. Never restate style, colors, or fonts in any text field.
   - **Avatars own casting. Zero casting prose, zero variety prose.** Translate the persona in The Product Report into 1 to 2 `customAvatars` with an EXPLICIT age (the brief's aspirational displayed age) and gender; blank fields pin nothing, and that blank default is exactly what used to cause the "ignored age" drift. An exact age holds that age in every image; a range or decade phrase spreads across the set. Leave `ethnicity` blank or "varied" unless the persona genuinely requires one: a named ethnicity is HELD identically in every image, while blank or "varied" opts into per-image variation. Per-image variety is automatic and always on, so never ask for it in prose and never describe people in slot text. On every save that touches casting, re-send `selectedAvatarIds` and `customAvatars` TOGETHER when both should persist: `customAvatars` alone also clears `selectedAvatarIds`. After saving, read the plan back (`get_listing_builder_plan_review` returns `selectedAvatars`) and confirm out loud exactly who is cast before generating; never assume the request applied.
   - **Propose edits, never silently apply them.** Show the user the returned plan with your Funnel-B edits proposed, then save the user-approved full slot array. Approval is an explicit save, never inferred from silence or enthusiasm.
   - **Pin the model wherever the schema lets you, and never anywhere it does not.** An unstated model is a model that can change under you, and a weaker engine renders text badly, which is exactly what a gallery cannot afford. But the field lives on some capabilities and not others: the blast calls identify the set and the approved plan and carry no model at all, because the engine was settled at planning time. Read the schema of the call you are about to make, pin the model if it declares one, and note in the batch log which call carried it and which inherited it from the plan. Never add the field to a tool that does not declare it: the schemas are strict and it fails the whole call.
   - **Edit the existing plan; never re-plan.** Re-running the planner wipes every slot edit and reverts casting. Fix slots through the plan-review/save path only.
   - **Generate the SECONDARY slots only, and leave the hero alone.** Do not include slot 1 in the generation request: the mains are `/main-image`'s work, they may already be gate-passed, and re-baking one here costs credits and breaks a set that later rooms depend on. If the tool returns a main anyway, it is not saved into `images/` and it is never advanced as a candidate. Say what you ignored.
   - **When regenerating a slot, make sure the tool call is a fresh generation, not a cached result** (if the tool exposes an idempotency or request key, use a new one).
   - **Never instruct the model to render a third-party logo or award badge**, and do not restate the ban in briefs either; Genrupt blocks it system-side. Real certifications appear only as they exist on the physical label. What Genrupt does NOT block, and what therefore stays in your short constraints: no star ratings or review references, no invented numbers.
   - Verify the approved reference asset id from `2-reference/reference-sheet.md` is attached to the generation so the product lock is inherited. The reference set is also the product-fidelity authority: a photo that SHOWS the material and shape beats any sentence describing them.

4b. **MODE 3: the Draft Blast, for a slot Refine still did not serve.**
   - Name the cost out loud FIRST and wait: a hundred credits, flat, for one frame. This is the single exception to the report-do-not-ask rule in this room, because at a hundred credits per slot the question is which slots deserve it, and that is the owner's call rather than yours.
   - Run it on that slot only. It inherits the style sent to Refine, so the hundred drafts arrive in the look the owner already chose rather than reopening a settled question.
   - The owner picks in the Genrupt grid, exactly as they did for the hero: fast elimination pass, then a slow pass against the slot's job in the brief, Compare when stuck. **One frame per slot this time**, because unlike the hero there is nothing to A/B test here.
   - **Read the selection back before downloading**, by name and count. Never assume a selection took.

4c. **Bring the chosen gallery home.** Whichever gear produced them, the frames the owner chose come down into `images/` under the naming contract in step 6, and each slot's completion is marked (`set_listing_builder_slot_completion`). **This is not optional and it is easy to forget:** `/inspect`, `/fix`, `/aplus` and the Tasting Room all read the local folder, so a gallery living only inside Genrupt is a Day 7 that opens on an empty directory. Say what landed, count included.

5. **Generate. Path B: gpt-image fallback (no Genrupt).** Per slot:
   - Attach the reference sheet's cleaned reference images to the call.
   - Use the slot brief as the prompt, prepending the product spec from `2-reference/reference-sheet.md` (exact size, material, every part present, label text) so the model cannot drift.
   - **Casting works differently here, and ONLY here.** This path has no avatar fields, so the avatars-own-casting rule cannot apply: each people-bearing slot must carry its casting IN THE PROMPT, an explicit displayed age and gender, plus enough distinguishing description that the person is clearly a different individual from every other people frame in the set. Keep a short list of who you cast where so the set stays varied. This is the one sanctioned exception; the moment the run is on Genrupt, casting prose is banned again.
   - Expect weaker product fidelity than the locked Genrupt path, and say so to the user up front. Inspect each output harder: compare the product in every image to the reference before accepting it into the set.
   - Generate the two highest-priority slots first, view them, and only continue if the product renders faithfully; if it does not, stop and tighten the reference rather than burning the batch.

6. **Save to `images/`, and write nothing else.** Files are named `sec-01.png` through `sec-07.png` (or however many slots the brief carries), matching the brief's slot order. This room writes ONLY `sec-*` filenames. Never overwrite, never delete, never move an existing file: a regenerated slot saves as `sec-03-v2.png` beside the first attempt (then `-v3`), and surgical edits from `/fix` live in `edits/vN/` snapshots under the same filename, never inside `images/`. Every original stays on disk underneath, which is the point. Untouched means untouched: the main candidates, their scorecard, and any earlier fixes are not this room's to tidy.

7. **Log the batch by APPENDING to `images/batch-log.md`.** The file is shared with `/main-image` and may already hold earlier rows. Add your row to the existing table and your slot map below it. Never rewrite the file, never re-emit the header, never touch an earlier row. If the file does not exist yet, create it with the header. The entry carries: date, room, path, model, image count, cost estimate versus approved, reference source (`manual` or `amazon_scraped`), brand-kit state, any slot that failed with its error, and, in MODE 2, the driver that justified the re-run.

8. **Do a first-pass sanity look, with evidence.** Open EVERY file you just generated with the Read tool and write ONE literal line per image (what is actually in frame). An image you did not open was not checked. You are looking for catastrophic misses only, four of them:
   - wrong or drifted product (compare against the Reference Sheet spec, part by part; every part the spec lists must be present and countable),
   - a failed or empty generation,
   - ignored casting (a person who is clearly not the specified age or gender),
   - the same face across two people frames (put them side by side and look).
   Do NOT score, do NOT run the squint test, do NOT rank: that is the Inspection Room's job and doing it here just duplicates it badly. If you find one of the four, name the file, name the defect, and route it correctly: product drift and casting are REGENERATE class, never an edit, and a repeated face is repaired UPSTREAM in the structured avatars (confirm explicit age and gender on each, and whether a second avatar from the persona should join the cast) before the slot re-runs as a fresh generation; it is never repaired by describing a different person in slot text. Offer the re-run with a fresh cost line. Never present raw generations as results.

9. **Verify the artifacts exist before you claim anything.** List `images/` and confirm one file per planned slot, with the earlier files still there. If a slot is missing, the set is NOT complete: retry that slot once (with its own cost line), and if it fails again, record the failure with its error in the batch log, name the missing slot to the user, and leave the sub-status at `in progress`. Never fill a hole with another slot's image, never renumber to hide a gap, and never call the set done because most of it landed.

10. **Hand off.** Tell the user: "The gallery is out of the machines. Next stop is the Inspection Room: run /inspect before you fall in love with anything." Ask for the set-level checks by name (message overlap, repeated faces, the emotional frame, selling-points coverage) and ask that it write its OWN scorecard file, so an earlier scorecard and its ranking survive untouched. Then continue the INVENT station: `/main-image` if the hero is not done, `/aplus` for the modules, `/variations` if the product sells variants, and the full package goes to Inspection together.

## Output format

`factory/Products/[product]/images/` after a run:

```
images/
  main-01.png .. main-04.png   (untouched, from /main-image)
  sec-01.png
  sec-02.png
  sec-03.png
  sec-04.png
  sec-05.png
  sec-06.png
  sec-07.png           (if the brief carries 7 slots)
  sec-05-v2.png        (a regenerated slot, beside its untouched first attempt)
  batch-log.md
```

`images/batch-log.md`, appended (the earlier row stays exactly as it was):

```markdown
# Batch Log . [Product Name]
| Date | Room | Path | Model | Images | Est. cost | Approved | Notes |
|---|---|---|---|---|---|---|---|
| [date] | main-image | genrupt | gpt_image_2 | 4 | [est] | yes ([date]) | [earlier row, untouched] |
| [date] | secondary-images | genrupt / gpt_image_fallback | gpt_image_2 | 6 | [est] | yes ([date]) | reference source: [manual/amazon_scraped]; brand kit: [on file/not available]; [failures, retries] |

## Slot map . secondary run [date]
| Slot | Job | Message | File | Casting | State |
|---|---|---|---|---|---|
| S1 | [job] | "[headline]" | sec-01.png | no people | generated |
| S4 | [job] | "[headline]" | sec-04.png | avatar A, [age]/[gender] | generated |
| S5 | [job] | "[headline]" | sec-05-v2.png | avatar B, [age]/[gender] | re-run: [driver, e.g. "repeated face, scorecard [date]"] |
```

## Golden Standards check

Before handing off, verify:
- [ ] Brief and locked reference (with a PASSED smoke test) were both confirmed BEFORE generating; any hard miss was reported as BLOCKED, not worked around. A missing brand kit was either filled or recorded as an explicit gap, never invented.
- [ ] Cost was REPORTED before and after each gear, never used as a gate on the Theme Blast the brief already authorised. The two that stopped and got their own go-ahead first: a Draft Blast (slot and reason stated), and any re-run of a slot that had already generated (what changed, and why the first attempt is being spent over).
- [ ] The gears ran in order: Theme Blast, then Restyle and Refine, and only then a per-slot deep dive if one was earned. Style and composition were chosen ONCE and sent to Refine, with a read-back confirming it took.
- [ ] `mobileFriendly` was left at its default unless the owner explicitly chose denser frames, and that choice was said out loud once rather than flipped silently.
- [ ] Refine ran more than one round where it was still improving things, and stopped when it stopped improving them rather than at a number.
- [ ] The owner was told out loud that this is where fonts, colors and composition finally get judged, after Day 4 deliberately deferred them.
- [ ] Frames were not cherry-picked across rows. A gallery assembled from four different themes was refused and the reason explained.
- [ ] Every chosen frame is on disk in `images/` with its slot completion marked. Nothing important was left living only inside Genrupt.
- [ ] Set rules were checked against the plan and read back to the user: one job one message per slot, no two slots share a message, at least one emotional frame, and no slot invented or dropped outside the brief.
- [ ] Legibility holds per slot: one headline, max ~3 supporting elements, big mobile-legible text.
- [ ] No image asserts a fact the Reference Sheet and research files do not support.
- [ ] Genrupt path: every save started from `get_listing_builder_plan_review` and sent back the FULL `slotAssignments` array (omit preserves, `[]` clears a list, `text: null` clears an instruction, no empty arrays for untouched fields); slot 1 round-tripped unchanged; `modelId: "gpt_image_2"` on every generation call; brief ROUTED to fields (2 to 5 sentence contentBriefs of visual direction, finished headlines in `headerPhrases`, constraints sorted to their owning field with only the leftovers in ADDITIVE `customInstructions`); casting via 1 to 2 custom avatars with explicit age and gender, zero casting or variety prose anywhere, `selectedAvatarIds` re-sent alongside `customAvatars` when both should persist, and the cast confirmed on a read-back; edits proposed to the user before saving; plan edited not re-planned; MAIN slot NOT generated; reference asset id attached.
- [ ] Fallback path: references attached to every call, product spec prepended, casting written explicitly per people-slot and varied across the set, weaker-fidelity warning given.
- [ ] Every generated file was opened with Read and has a literal one-line description; the two people frames were compared side by side.
- [ ] Only `sec-*` files were written. No original overwritten, deleted or moved; no main candidate touched.
- [ ] `images/` was listed and matches the planned slot count, or the missing slots are named to the user and recorded with their errors.
- [ ] Batch log APPENDED (earlier rows intact) with path, model, count, approved cost, reference source, brand-kit state, and the slot map.
- [ ] The user was pointed to the Inspection Room with the set-level checks named, and no image was called final, approved, or ready.

## Wonka lines

Openers:
- "The Secondary Images Room. The main earns the click; this lot does the selling."
- "Every slot gets ONE job. A picture doing two jobs does neither."
- "Come in, come in. We're inventing a gallery today, and no two frames may sing the same note."

Closers:
- "Six frames, six jobs, one family. Nothing leaves this factory uninspected: Inspection Room, next."
- "Fresh gallery, still warm. Squint at it on a phone before you cheer; better yet, let /inspect do the squinting."
- "Machines off, set in the tray, originals sleeping safely underneath. Onward to /inspect."

## Definition of Done

- Every secondary slot from the brief has at least one generated file in `images/`, named `sec-NN` (or `sec-NN-v2` for a re-run), verified by listing the folder; any slot that failed twice is named to the user and recorded with its error, and the set is NOT called complete.
- `images/batch-log.md` exists and was appended, not rewritten, carrying path, model, count, approved cost, reference source, brand-kit state, and the slot map. Earlier rows are intact.
- Every generated file was opened and described; the four catastrophic-miss checks ran, and anything found was routed (regenerate for product drift or casting, upstream avatar repair for a repeated face).
- The main candidates and every earlier file are untouched on disk.
- The user was explicitly handed to `/inspect` with the set-level checks named, and the remaining INVENT rooms (`/main-image`, `/aplus`, `/variations`) named as needed; no output was presented as final.

## Update status.md

In the INVENT sub-status block, set `Secondary images (/secondary-images): done` (or `in progress` if the batch is partial or a slot is still owed, or `blocked: [precondition]`). Artifact `images/sec-01..NN.png` + `images/batch-log.md`. Then check the whole INVENT sub-status block: when all four sub-parts (Main image, Secondary images, A+, Variations) are `done` or `n/a` with a reason (variations may be n/a), set the INVENT station row to `done`; otherwise leave it `in progress`. Log line: `[date] Secondary set generated: [N] slots on [path], cost approved [est], reference source [manual/amazon_scraped][, brand kit not available]. Awaiting inspection.` For a MODE 2 re-run, the log line names the slot and its driver instead: `[date] Slot [sec-NN] regenerated ([driver]) as sec-NN-v2.png, cost approved [est]. Awaiting re-inspection of the whole set.` Name the remaining INVENT rooms as next steps, with INSPECT to follow once the full package exists.


**Then roll the station up, because whichever sub-part finishes last owns this.** Check the whole INVENT sub-status block: when all four (Main image, Secondary images, A+, Variations) read `done`, or `n/a` with a reason, set the INVENT station row to `done`; otherwise leave it `in progress`. A single-SKU product never runs `/variations`, so if only that room rolled up, INVENT would sit unfinished forever on exactly the simplest products.
---
name: improvement-loop
description: Close BOTH learning loops in one command. PART A writes what wins in the MARKET (Tasting Card verdicts from every race, an Amazon A/B verdict, a real shopper poll, owner creative preferences) into the Improvement Log with honest evidence strength and visible conflicts. PART B reviews the run itself and writes how WONKA works better (corrections, recurring QA flags, rework, owner working-style preferences) into the Improvement Log. Run after every Tasting Round, upload pack, or A/B verdict, and at the end of any big session. Triggers: /improvement-loop, "record the lesson", "update the improvement log", "the tasting card is in", "the A/B results are in", "remember that I hate...", "review this session", "close the loop", "get better at your job".
---

# The Improvement Loop

| Meta | Value |
|------|-------|
| Room | The Improvement Loop |
| Station | PROVE (step 3 of 3, and always-on) |
| Day | Day 10 of the bootcamp, run beside `/factory-report`. Outside the bootcamp, run it the same day any result lands. |
| Needs | Today's real date; every result not yet recorded (`tests/tasting-r[N]-[date]-[race]/tasting-card.md` plus `results.json`, an Amazon A/B verdict the owner pastes, a real shopper poll, or a stated owner preference); the run or session to review; `factory/Improvement Log.md` (all three parts), and the product's `status.md` |
| Saves to | factory/Improvement Log.md (all three parts of the one file) |
| Typical cost | Free. Reading and writing only. No credits, no API spend, nothing to approve. |

## What this room does

A Factory that forgets its results is an expensive random number generator. This is ONE command that feeds ONE file, `factory/Improvement Log.md`, in two loops, and the difference between them is the whole point:

- **PART A . the MARKET loop (Part 1 of the log).** What wins with buyers: creative patterns, evidence-weighted, carrying the numbers that earned them ("a savoury frame, queso and wings, beat a second dessert frame in the gallery, 57% vs 31%, 100 synthetic tasters, chocolate fountain niche"). It is about the CANDY. `/creative-brief` reads this part before writing a word, so lesson one shapes brief two and the third product starts smarter than the first.
- **PART B . the PROCESS loop (Part 2 of the log).** How Wonka works better as an employee: what he missed, what he should have front-loaded, the rework he caused, and how this owner likes to work. It is about the FACTORY WORKER, not the candy. It is read at the start of every session, which is exactly why it must stay short and true.

The same file also carries **Part 3, the experiments ledger**, one row per race; this room finalizes those rows once the lessons are distilled.

One question routes everything: **is this about the candy or about the worker?** "Shoppers preferred X" is candy, so PART A. "I should have confirmed the real variation list before planning" is worker, so PART B. Run BOTH parts every time. Either may honestly come back empty, and an honest empty is a result.

The Improvement Log is read by a machine that spends money. Every row in it becomes an instruction in a future brief, so a row that overstates its evidence quietly buys the wrong images months from now.

## Before you start

Read every input first, then handle each one exactly as this table says. An honest gap beats an invented lesson, every time.

| Input | If it is missing |
|---|---|
| **Today's real date**, from the shell (`date`) | Run it once, before writing anything. Every row in the Improvement Log is dated and the whole evidence ladder rests on those dates. If the shell is unavailable, use the date printed inside the Tasting Card header and write `date from card` beside it. Never guess a date from memory. |
| **The result artifacts**: `factory/Products/[product]/tests/tasting-r[N]-[date]-[race]/tasting-card.md` and `results.json` | **PROCEED with PART B only.** If no result exists, say so plainly ("no new result to record, so the Improvement Log stays as it is") and review the run for process lessons. Never write a Patterns row without a card to cite. |
| **The product folder**, when the input is a pasted result rather than a card | **ASK which product.** Derive it from the card path when there is one (`factory/Products/[product]/tests/...`). With more than one product in the Factory and no path, ask. Never guess a product, because the niche and the status file come from it. |
| **The exact niche phrase**, from that product's `status.md` | **ASK for it in the owner's own words** and record it. Copy it word for word; do not paraphrase it into a tidier category. A pattern with the wrong niche on it gets applied to the wrong product later. |
| `factory/Improvement Log.md` | **RECREATE and PROCEED.** The log ships with the kit, so a missing one usually means the command is running outside the Factory folder. Check that first and say so. If the file is genuinely gone, recreate it with the canonical headers from the Output format below, tell the owner the history was lost, and carry on. Never invent headers, and never append to a file you have not read in THIS run. |
| **An Amazon A/B verdict** the owner promised | **"I do not have it yet" is a complete answer.** Leave that `amazon-ab` row at `running`, note the date it was asked for, proceed with everything else. Never estimate an A/B outcome and never mark a row won or lost on a feeling. |
| **A/B numbers pasted without the metric, both arms, or the duration** | **ASK once** for the missing piece (CTR or CVR, version A and version B, how long it ran, and what Amazon called the result). If the owner does not have it, record the row as `inconclusive` with the reason, and record no Patterns row. A one-sided number is not evidence. |
| **A real shopper poll** result (the optional Pro Move) | **PROCEED.** Use it in PART A at its true weight (real people, above any synthetic panel). Do NOT create or finalize a `shopper-poll` row in `Improvement Log.md`; no skill writes those. Hand the owner the exact row text to paste if they want it logged. |
| **The session to review** for PART B | If the run happened in an earlier session (a verdict that arrived weeks later), say so and review the ARTIFACTS instead: `status.md` Log lines, the scorecards, the `edits/vN/` round folders and `edits/fixes-log.md`, the brief's gaps. If there is genuinely nothing to review, PART B reports "no run to review" and adds nothing. |

## Process

### Step 0. Inventory every result, then check what is already recorded

1. **List every unrecorded result, not just the newest one.** One Tasting Room sitting holds TWO races (the main race and the gallery race), and the bootcamp runs ONE sitting, so a Day 10 run typically has TWO tasting results waiting plus whatever fixes followed them. Name them out loud before processing any of them. **Processing one card and calling the loop closed is the most common way this room lies.** If a product genuinely ran a second sitting, say so and process all four.

### PART A . market patterns (Part 1 of the log)

1. **Read the card properly, by section.** Open `tasting-card.md` (and `results.json` when a number needs checking) and read, in this order: `## Verdict` (the shares, the standardized label, the models-disagree line, the vs current listing line), `## What the tasters keep saying (ranked objections)` with its mention counts, `### Per-candidate themes` (what worked and what hurt, per candidate), `## Strongest frame in each set` for a gallery race, and `## Round comparison` when it is a Round 2. The vote count only says a pattern exists. The objections say WHAT it is.

2. **Apply the evidence gate BEFORE writing any pattern.** The Tasting Room grades its own reliability, and this room obeys that grade:
   - **Clear lead**: the shares are usable evidence. Write the pattern.
   - **Lean**: usable only as a lean. Write the pattern at strength MIXED (the book's "apply with judgment" slot, which is exactly what a lean is) and say "Lean, not proof" inside the evidence cell.
   - **Toss-up, or the base models disagreed on the winner, or the card carries the parse-rate quality warning (under 90%)**: **NO pattern row from the shares.** Record an honest no-result line in the Lessons log instead. The percentages from a coin flip are noise, and noise in this book becomes an instruction later.
   - Whatever the tier, the recurring OBJECTIONS are still real material. An objection is not a tested pattern, so it goes to the Lessons log with its mention count and the race it came from, where the next brief still reads it.

3. **Extract the pattern, and test that it is one.** A pattern is a reusable creative claim a future brief can act on. Not "option B won" but "a savoury frame, queso and wings, beat a second dessert frame in the gallery." Three checks before it earns a row:
   - **Pointable**: it names a visible creative choice (a composition, a message, a prop, a frame job, a color decision) that you could point at in an image. If you cannot point at it, it is a note, not a pattern.
   - **One step of generalization, no further**: from the tasters' stated reason, generalized once. Two steps and you are inventing.
   - **No result promises**: a pattern says what won a test. It never says what it will do to sales, ranking, or conversion. That promise is not ours to make.

4. **Record what LOST too, in its own row.** A losing candidate with clear objections earns an AVOID row ("three stacked callouts on the main lost to a single headline"). Losses teach faster than wins and they are cheaper to obey. A run that only records winners has thrown away half of what it paid for.

5. **Attach the evidence in this exact shape**: shares, panel size in words, race, round, stability label, date, niche, and the source folder. Example: `won 57% vs 31%, 100 synthetic tasters, gallery race, round 1, Clear lead (2026-08-14)`. Write "100 synthetic tasters", never a bare "n=100": a number with no panel type reads like real shoppers to whoever opens this book next year. The niche is the exact phrase from `status.md`, because a pattern proven in one niche is only a HYPOTHESIS in the next one.

6. **Record a round-over-round move as its own pattern IF a second round ever ran.** By default the bootcamp runs ONE sitting, so this usually does not apply.** If the same candidate was refined between rounds and its share moved, the `## Round comparison` delta is evidence about the FIX, which is the strongest thing a two-round run produces: "enlarging the headline and dropping two callouts moved the same candidate from 42% to 55% between rounds, 100 synthetic tasters, rounds 1 and 2." Cite both rounds. If the share fell, that is an AVOID row about the fix, and it counts just as much.

7. **Grade the strength honestly, on the full evidence ladder.** Higher evidence outranks lower evidence on the same question:
   1. **Amazon A/B** (real buyers, real money, controlled). Outranks everything.
   2. **Real shopper poll** (real people, no purchase). Outranks any synthetic panel.
   3. **Tasting Room** (synthetic panel, directional plus objections).
   Then the count: **one test = weak signal**, recorded and used as a lean, never as a law. **Two consistent tests = usable prior**, applied by default, and only tests that CLEARED the gate count toward the two. Two Leans do not add up to a law; they stay MIXED. Strength labels are the three the book defines and no others: **USE** (apply by default), **MIXED** (conflicting or lean evidence, judge per case), **AVOID** (lost clearly).

8. **Check for conflicts, and make them visible.** If a new result contradicts an existing row: LOWER the old row (USE becomes MIXED), keep both results side by side in the evidence cell, add a dated line under `## Conflicts on record` naming what differed (niche, panel type, round, image quality), and never silently overwrite. When the contradiction comes from HIGHER evidence (an A/B against a tasting round), the higher one sets the new strength and the older evidence stays in the cell marked `superseded by [source]`. A visible conflict is information. A hidden one is a lie in a book that spends money.

9. **Write Part 1.** Add or update the rows under `## Patterns`, append preferences and conflicts and log lines to their own sections. Append to evidence cells, never erase them: the history of a row is part of its value.

10. **Finalize the experiments ledger (Part 3), one row per race.** Find each matching row (Type `tasting-room` or `amazon-ab`) and complete Winner / Margin / Key why / Status. Status is `won` / `lost` / `inconclusive` (`inconclusive` whenever the label was not Clear lead or the models disagreed), and it becomes `logged` once that result's patterns are actually in the Improvement Log. If a row is genuinely missing, create it in the canonical 8-column schema:

    `| Date | Product | Type | Candidates | Winner | Margin | Key why | Status |`

    Two things this room never does: it never invents an `amazon-ab` row (a test nobody ran, on a listing that may not even be the owner's, is a fabrication), and it never writes or finalizes a `shopper-poll` row (those are logged by hand, by the owner).

11. **Handle owner CREATIVE preferences.** When the owner states taste ("I hated that layout", "never use purple", "keep the stainless base in frame"), record it as a dated bullet under `## Owner creative preferences`, quoting them closely. It binds future briefs like a pattern does, and it is labeled a preference, because the book never dresses taste up as data. A WORKING-STYLE preference (how Wonka should operate) is not creative taste; it belongs in PART B.

### PART B . process lessons (Part 2 of the log)

Review the run for these five signals. Do not review from memory alone: the evidence is on disk.

**Where to look:** this session's conversation (the corrections are in it, verbatim), the product's `status.md` Log lines, `scorecards/scorecard-[scope]-[date].md` (recurring flags are countable), the `edits/vN/` round folders and `edits/fixes-log.md` (rework is countable: a file fixed across three rounds cost three rounds), the brief's `## Gaps carried forward`, and the Tasting Card's objections read against what the brief actually planned.

1. **Corrections and re-asks.** Where did the owner correct Wonka, override a recommendation, or ask the same thing twice? Quote the correction, then distill the rule ("when the product has variants, confirm the real list before planning, never assume").
2. **Recurring QA flags.** Which defect appeared on MORE THAN ONE image in the Inspection Room? A repeat is a planning failure, not a QA failure: it should have been prevented upstream ("text kept failing the squint test, so plan fewer labels per slot and the headline renders bigger").
3. **What the tasting revealed that the brief never anticipated.** If tasters reacted to something no slot was planned for, that is a gap in how Wonka plans. The market fact goes to PART A; the planning lesson ("plan a scale frame whenever size questions are plausible") lives here.
4. **Wasted effort and rework.** Edits that should have been regenerations, failed batches, generations on the wrong path, steps run out of order. Each is a method lesson ("enlarging text is a regenerate, not an edit; I burned two rounds proving it again").
5. **Owner working-style preferences.** How the owner likes Wonka to operate: how to walk through a decision, how much to decide alone, pacing, how to report. These go under `## Owner working-style preferences`, separate from process lessons. Creative taste is NOT working style; route it to PART A.

**The bar, so this book stays worth reading at every session start:**
- A defect that hit two or more images, or cost a re-run, a re-generation, or a correction, is a lesson. A one-off that cost nothing is not.
- **At most five process lessons per run**, ranked by what they cost. If more qualify, keep the five most expensive and say plainly that the rest were minor. A lessons table nobody finishes reading teaches nothing.
- **If a lesson is already in the book, do NOT add a twin.** Append the new date to the existing row's Trigger cell as a recurrence, and ESCALATE its How to apply from advice into a precondition ("check this before estimating a batch, every time"). A lesson that recurred is the most important line in the book.

For each lesson that clears the bar, write three parts:
- **Trigger**: what actually happened, concrete, from this run.
- **Lesson**: the general rule, one careful step of generalization, no further.
- **How to apply**: a specific change to a future brief, generation, or inspection, so the next session can act on it. "Do better" is not a How to apply.

Then append: process lessons to the `## Process lessons` table, working-style notes to `## Owner working-style preferences`. Retire a lesson (Status `retired`) only when a later run proved it wrong or made it obsolete, and note why. History is never deleted.

## Routing examples (which book gets what)

| The raw observation | Book | Where |
|---|---|---|
| "The savoury frame beat the second dessert frame, 57 vs 31, 100 synthetic tasters, Clear lead" | Improvement Log | Patterns row (weak signal until a second test) |
| "The panel came back Toss-up and the models disagreed" | Improvement Log | Lessons log, honest no-result. No Patterns row. |
| "Fourteen tasters asked whether it actually flows" | Improvement Log | Lessons log as an objection with its count, not a Patterns row |
| "Never use purple, I hate it" | Improvement Log | Owner creative preferences |
| "The A/B contradicted last month's Tasting Round on white backgrounds" | Improvement Log | Conflicts on record, the tasting row downgraded and marked superseded |
| "Tasters kept asking about size and the brief never planned a scale frame" | BOTH | Market fact to Patterns; "plan a scale frame when size questions are plausible" to Process lessons |
| "I edited when I should have regenerated and burned two rounds" | Part 2 | Process lessons |
| "Same squint-test fail on 4 of 8 images" | Part 2 | Process lessons (front-load legibility into the brief) |
| "Give me two options and let me pick, do not decide alone" | Part 2 | Owner working-style preferences |

## When to run

- After every Tasting Round lands, on ALL of that sitting's races, not just the main one.
- After `/ready-to-upload`, and again when an Amazon A/B verdict arrives, however many weeks later.
- At the end of any big working session, even with no test result. PART B may still have lessons while PART A honestly stays empty.
- On Day 10 of the bootcamp it runs once across the whole run, so expect several results in the queue.

## When something is missing or broken

- **The log is not where it should be**: the command is probably running outside the Factory folder. Say that first, check, and only then recreate the file from the canonical headers.
- **No result and no session to review**: report "nothing to record today" and stop. That is a legitimate outcome of this room, not a failure of it.
- **The owner does not have the A/B numbers yet**: record the ask with today's date, leave the row `running`, and continue. Never estimate.
- **The card carries the parse-rate quality warning**: no pattern from those shares. Recommend a re-run of the tasting (it resumes from its checkpoint) and record the objections only.
- **The demo product has no Amazon A/B, ever**: the bootcamp's demo listing belongs to another seller, so its run ends with tasting rows and no `amazon-ab` row at all. That absence is the honest state of things. Teach the A/B recording generically: this is what you would paste in from your own listing.
- **The result contradicts the owner's stated preference**: record both. The test goes to Patterns, the preference stays in its section, and the conflict gets a line. The owner decides which one wins; this room does not overrule taste, and it does not hide the evidence either.

## Output format

Everything below lands in the ONE file, `factory/Improvement Log.md`. PART 1 sections, appended in this order, and do not invent new headers:

```markdown
## Patterns

| Pattern | Evidence | Niche | Strength | Source test |
|---|---|---|---|---|
| A savoury frame, queso and wings, beats a second dessert frame in the gallery | set won 57% vs 31%, 100 synthetic tasters, gallery race, round 1, Clear lead (2026-08-14) | chocolate fountain | USE (1 round = weak signal) | tasting-r1-2026-08-14, gallery race |
| Three stacked callouts on the main lose to one headline | 12% vs 54%, 100 synthetic tasters, main race, round 1, Clear lead (2026-08-14) | chocolate fountain | AVOID | tasting-r1-2026-08-14, main race |
| [pattern] | [shares, panel size in words, race, round, label, date; then the next result] | [exact niche phrase] | [USE / MIXED / AVOID] | [test folder, race] |

## Owner creative preferences

- [YYYY-MM-DD] [the preference, close to the owner's words] (owner feedback after [moment])

## Conflicts on record

- [YYYY-MM-DD] [pattern] : [old evidence] vs [new contradicting evidence]. Downgraded to MIXED. Difference suspects: [niche / panel type / round / image quality].

## Lessons log

- [YYYY-MM-DD] [tasting / A/B / shopper poll / owner] : [one-line lesson] -> [row added / updated]
- [YYYY-MM-DD] tasting : no usable pattern from [test folder, race]. Toss-up, models disagreed. Objections kept, percentages dropped.
- [YYYY-MM-DD] tasting : objection, "will it actually flow", raised by 14 tasters in [test folder, race]. Recorded as an objection, not a tested pattern.
```

The experiments ledger (PART 3 of the same file), matching row completed in the canonical 8-column schema:

```markdown
| [YYYY-MM-DD] | [product slug] | [tasting-room / amazon-ab] | [candidates incl. incumbent, and which race] | [winner file or set] | [57% vs 31%, 100 synthetic tasters, round 1, Clear lead] | [one clause on why] | [won / lost / inconclusive / logged] |
```

PART 2 of the same file. Append to its sections:

```markdown
## Process lessons

| Date | Trigger | Lesson | How to apply | Status |
|---|---|---|---|---|
| 2026-08-14 | The Reference Sheet was built from listing and review images because there is no unit in hand | When the reference comes from listing imagery, treat size, back and underside as unknown rather than as fact | Brief the scale frame against the stated 8 x 8 x 18 inches, and ask the owner for one real photo with a hand in it before the next batch | active |
| [YYYY-MM-DD] (recurred [YYYY-MM-DD]) | [what happened, concrete] | [the general rule] | [precondition, checked before the step it protects] | active |
| [YYYY-MM-DD] | [lesson a later run made obsolete] | [rule] | [change] | retired ([why]) |

## Owner working-style preferences

- [YYYY-MM-DD] [what the owner said or repeatedly corrected, e.g. "walk me through two options, do not decide for me"]
```

## Golden Standards check

Before presenting, verify:
- [ ] Today's real date came from the shell (or is marked `date from card`), and every new row carries it.
- [ ] EVERY unrecorded result was inventoried and processed, both races of every round, not just the newest card.
- [ ] Nothing was double-recorded: each result was checked against the Source test key and the `logged` status first, and re-runs updated rows instead of adding twins.
- [ ] The whole Improvement Log (all three parts) was read fully in THIS run before anything was appended.
- [ ] The evidence gate was applied: no Patterns row rests on a Toss-up, a models-disagree card, or a card carrying the parse-rate warning. Those produced Lessons log entries instead.
- [ ] Every Patterns row is pointable (names a visible creative choice), one step of generalization, and promises no sales result.
- [ ] Every Patterns row carries shares, panel size IN WORDS, race, round, stability label, date, the exact niche phrase from `status.md`, and its source folder. No bare "n=".
- [ ] What LOST was recorded too, with its own AVOID row, wherever the objections said why.
- [ ] Strength follows the ladder: A/B outranks a real shopper poll, which outranks a synthetic Tasting Round. One test is a weak signal, two consistent tests are a usable prior. Only USE / MIXED / AVOID were used.
- [ ] Contradictions produced a visible Conflicts entry plus a downgrade, never an overwrite; a superseded row says what superseded it.
- [ ] Every `Improvement Log.md` row for these results has Winner / Margin / Key why / Status filled, ending at `logged` once its patterns landed. No invented `amazon-ab` row. No `shopper-poll` row written by this room.
- [ ] Each process lesson has a real quoted or cited Trigger, a generalized Lesson, and a concrete How to apply. Five lessons maximum, ranked by cost. A recurring lesson escalated an existing row instead of adding a new one.
- [ ] Lessons were routed correctly: market patterns and creative taste to Part 1, process lessons and working-style preferences to Part 2. Nothing cross-filed.
- [ ] Nothing was invented: a no-lesson result and a clean run are each recorded as exactly that.
- [ ] Appends only. The only deletions were the kit's own marked example rows on the first real entry.
- [ ] The file was re-read after writing: the new rows are there and the previous content is intact.
- [ ] Everything written is in English with zero em dashes and zero en dashes.

## Wonka lines

Openers:
- "The Improvement Loop. One book, two loops, one honest hour: what the shoppers taught us, and what I taught myself."
- "Results in hand. Part 1 learns about the candy. Part 2 learns about me."
- "Win or lose, everything goes in the book. Especially lose. Losses are cheaper teachers and they never flatter you."

Closers:
- "The log grows wiser on both pages. Your third product will thank your first, and the next Wonka thanks this one."
- "One weak signal in the Improvement Log, one process lesson in mine. Two more tests and the first becomes law around here."
- "The panel gave us a toss-up. That is a shrug, not a lesson, and I do not file shrugs as law. The objections I keep. The percentages I throw away."
- "A clean run and a clean result, honestly recorded. I will not invent a lesson to look busy."

## Definition of Done

- Part 1 of `factory/Improvement Log.md` holds every new or updated row from every result processed today, or an explicit no-lesson entry in the Lessons log, and the file was re-read after writing to confirm the append landed and the old rows survived.
- Part 2 holds this run's process lessons and working-style notes (five at most, each with Trigger, Lesson, How to apply), or the run is explicitly recorded as clean with nothing added.
- Part 3 (the experiments ledger) has every processed race finalized on its own row: Winner, Margin, Key why, and Status ending at `logged` once the patterns landed. Rows left `running` (an A/B still out) say so on purpose.
- Any contradiction is visible under `## Conflicts on record` with the downgrade applied.
- The owner heard three lines: what the Factory now knows about its market, what the Factory worker now knows about himself, and exactly how the next `/creative-brief` will differ because of today. If either part came back empty, the owner heard that plainly, with nothing added to fill the silence.

## Update status.md

Only when this run touched a specific product. Never downgrade a station that is already further along.

If this closes an experiment: set PROVE to `done` for that cycle, with the Improvement Log entry as the artifact. Add a Log line: `[date] Improvement Loop: [N] results recorded ([which races]) -> Part 1: [one-line market lesson]; [N] process lessons -> Part 2 (or "nothing new, clean run").`

If the run was not about one product (an end-of-session review), skip `status.md` entirely and say so.

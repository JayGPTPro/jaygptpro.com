#!/usr/bin/env python3
"""brief-lint. Check a creative brief BEFORE it costs you credits.

Wonka checks his own work, and that is usually fine. This is the part that does
not get tired: one command, mechanical rules, no opinions. It catches the
failure modes that are cheap to fix in a text file and expensive to fix in a
batch of generated images.

Reads `brief/creative-brief.md` (the markdown Wonka writes) and checks it
against the Genrupt intake contract plus the house rules.

Usage:
    python3 brief_lint.py factory/Products/[product]/brief/creative-brief.md

Exit code 0 when clean, 1 when there are errors. Warnings never fail the run:
a missing section is a WARNING (briefs differ per product), a broken rule
inside a section that IS present is an ERROR.

Stdlib only. Nothing to install.
"""
import re
import sys
from pathlib import Path

# ---------------------------------------------------------------- patterns

# A person actually in frame. "customer" and "shopper" are abstractions a brief
# may reason about without showing anyone, so they are not in this list.
PEOPLE = re.compile(
    r"\b(woman|women|man|men|model|models|person|people|mother|father|family|"
    r"girl|boy|guy|lady|couple|child|children|kid|kids|baby|host|hostess)\b"
    r"|\bhands?\b(?!-)",  # "a hand holding it" is a person. "hand-poured" is not
    re.I,
)

# CASTING is describing WHO the person is. Person-anchored on purpose, so that
# ordinary product language ("for all ages", "a mature finish") never trips it.
_PERSON = (r"(?:woman|women|man|men|model|person|people|mother|father|lady|guy|"
           r"girl|boy|couple|child|kid|baby|host|hostess|she|he|they)")
_DECADE = r"(?:twenties|thirties|forties|fifties|sixties|seventies|eighties)"
_ETHNIC = (r"(?:black|white|caucasian|asian|hispanic|latina|latino|"
           r"african[- ]american|middle[- ]eastern|south[- ]asian|east[- ]asian)")
CASTING = re.compile(
    r"\bcasting\b"
    r"|\bcast(?:s|ing)?\s+(?:a|an|the|one|two|her|him|them)\b"
    r"|\b\d{1,3}[-\s]year[-\s]old\b"
    rf"|\b(?:in\s+(?:her|his|their)\s+(?:early\s+|late\s+|mid[-\s]?)?{_DECADE})\b"
    rf"|\b(?:a|an|one)\s+(?:{_ETHNIC})\s+{_PERSON}\b"
    rf"|\b{_PERSON}\s+(?:aged|around|about)\s+\d{{2}}\b"
    r"|\b(?:silver|grey|gray)[-\s]haired\b"
    rf"|\bdifferent\s+{_PERSON}\b"
    rf"|\bsame\s+{_PERSON}\s+(?:again|in every|across)\b",
    re.I,
)

# Design direction. The look belongs to the branding preset, never to brief text.
DESIGN = re.compile(
    r"#[0-9a-fA-F]{6}\b"                                    # hex codes
    r"|\b(?:serif|sans[- ]serif|typeface|font family|bold sans|editorial serif)\b"
    r"|\b(?:cream|ivory|beige|forest green|navy|charcoal|gold|copper|plum)\s+"
    r"(?:background|backdrop|headline|type|text|accent|palette)\b",
    re.I,
)

BANNED_CLAIMS = re.compile(
    r"\b(?:\d(?:\.\d)?\s*(?:out of|/)\s*5|star rating|five[- ]star|5[- ]star|"
    r"verified buyer|best ?seller badge|as seen on|clinically proven|"
    r"FDA[- ]approved|doctor recommended)\b",
    re.I,
)

PLACEHOLDERS = re.compile(r"\b(?:TBD|TODO|XXX|lorem ipsum|FILL IN|\[insert)\b", re.I)

# Placeholders this skill declares on purpose, so they are lawful.
LAWFUL = re.compile(
    r"pending brand kit|variations: unconfirmed|incumbent: none \(pre-launch\)|"
    r"Owner review: PENDING|upload first|none given|source: estimated",
    re.I,
)

HEADER_MAX = 120        # Genrupt cap on a header phrase
BRIEF_MAX_SENTENCES = 6  # "2 to 5 sentences" with one sentence of slack


# ---------------------------------------------------------------- helpers

def split_sections(md: str) -> dict:
    """Map '## Heading' -> body text."""
    out, current, buf = {}, None, []
    for line in md.splitlines():
        m = re.match(r"^##\s+(.+?)\s*$", line)
        if m:
            if current:
                out[current.lower()] = "\n".join(buf)
            current, buf = m.group(1), []
        elif current:
            buf.append(line)
    if current:
        out[current.lower()] = "\n".join(buf)
    return out


def find_section(sections: dict, *needles) -> str | None:
    for key, body in sections.items():
        if any(n in key for n in needles):
            return body
    return None


def slot_blocks(body: str) -> list:
    """Split a secondary-slots section into (label, chunk) pairs.

    The label is what the brief itself calls the slot, so an error message
    points at 'Slot 5' and not at 'the third block I happened to parse'.
    """
    parts = re.split(r"^###\s+|^\*\*Slot\s", body, flags=re.M)
    out = []
    for part in parts:
        if not part.strip():
            continue
        m = re.match(r"\s*(?:Slot\s*)?([0-9]+|[A-Za-z][\w \-]{0,30})", part)
        label = f"slot {m.group(1).strip()}" if m else f"slot {len(out) + 1}"
        out.append((label, part))
    return out


def sentences(text: str) -> int:
    text = re.sub(r"\s+", " ", text).strip()
    return len([s for s in re.split(r"[.!?]+(?:\s|$)", text) if s.strip()])


def line_no(md: str, fragment: str) -> int:
    idx = md.find(fragment[:60])
    return md[:idx].count("\n") + 1 if idx >= 0 else 0


# ---------------------------------------------------------------- checks

def main() -> int:
    if len(sys.argv) < 2:
        print("usage: python3 brief_lint.py <brief/creative-brief.md>")
        return 1
    path = Path(sys.argv[1])
    if not path.exists():
        print(f"ERROR  brief not found: {path}")
        return 1

    md = path.read_text(encoding="utf-8")
    sections = split_sections(md)
    errors, warnings = [], []

    def err(msg, frag=""):
        n = line_no(md, frag) if frag else 0
        errors.append(f"line {n}: {msg}" if n else msg)

    def warn(msg):
        warnings.append(msg)

    # 1) MAIN IMAGE IS CHOSEN, NOT BRIEFED --------------------------------
    main_sec = find_section(sections, "main image")
    if main_sec is None:
        warn("no 'Main image' section found; skipped the main-image checks")
    else:
        if PEOPLE.search(main_sec):
            hit = PEOPLE.search(main_sec).group(0)
            err(f"main image mentions a person ('{hit}'). The main is product "
                f"only, always [no-people-in-main]", main_sec)
        for banned in ("contentbrief", "content brief", "headerphrase",
                       "header phrase", "custominstruction"):
            if banned in main_sec.lower():
                err(f"main image section carries '{banned}'. Slot 1 is protected: "
                    f"it is decided by tactic, hang-tag text and packaging "
                    f"preference only [slot-1-protected]", main_sec)

    # 2) A+ IS HANDS-OFF --------------------------------------------------
    aplus = find_section(sections, "a+ content", "a+ ")
    if aplus is not None:
        body = aplus.lower()
        for banned in ("module 1", "module 2", "headline:", "copy points",
                       "module plan"):
            if banned in body:
                err(f"A+ section carries '{banned}'. A+ is hands-off: Genrupt "
                    f"plans it alone and inspection is the gate [aplus-hands-off]",
                    aplus)

    # 3) SECONDARY SLOTS ---------------------------------------------------
    sec = find_section(sections, "secondary slot")
    messages = []
    if sec is None:
        warn("no 'Secondary slots' section found; skipped the slot checks")
    else:
        for label, block in slot_blocks(sec):
            if CASTING.search(block):
                hit = CASTING.search(block).group(0)
                err(f"{label}: casting text in the brief ('{hit}'). Casting is a "
                    f"structured field: it belongs in customAvatars, never in "
                    f"slot text [casting-is-structured]", block)
            if DESIGN.search(block):
                hit = DESIGN.search(block).group(0)
                err(f"{label}: design direction in the brief ('{hit}'). The look "
                    f"comes from the branding preset; briefs stay design-silent "
                    f"[briefs-are-design-silent]", block)
            comp = re.search(r"(?:composition|content brief)\s*[:\-]\s*(.+?)(?=\n\s*[-*]|\n\n|$)",
                             block, re.S | re.I)
            if comp and sentences(comp.group(1)) > BRIEF_MAX_SENTENCES:
                err(f"{label}: content brief runs {sentences(comp.group(1))} "
                    f"sentences. It is 2 to 5 sentences of visual direction, not a "
                    f"research summary [distill-dont-forward]", block)
            msg = re.search(r"(?:message|headline)\s*[:\-]\s*(.+)", block, re.I)
            if msg:
                text = msg.group(1).strip().strip('"')
                if len(text) > HEADER_MAX:
                    err(f"{label}: headline is {len(text)} chars, the cap is "
                        f"{HEADER_MAX} [header-phrase-cap]", block)
                messages.append((label, re.sub(r"[^a-z0-9 ]", "", text.lower()).strip()))

        # set-level: no two slots may carry the same message
        seen = {}
        for idx, m in messages:
            if not m:
                continue
            if m in seen:
                err(f"{seen[m]} and {idx} share the same message "
                    f"('{m[:40]}'). Every frame does a distinct job "
                    f"[set-level-variety]")
            seen[m] = idx

    # 4) REJECTED POINTS MAY NOT RESURFACE ---------------------------------
    cov = find_section(sections, "coverage map")
    if cov is None:
        warn("no coverage map found; skipped the skipped-points check")
    elif sec is not None:
        skipped = []
        for line in cov.splitlines():
            if re.search(r"\bskipped\b|\bnot mapped\b", line, re.I):
                cells = [c.strip() for c in line.split("|") if c.strip()]
                # drop the reason cell and any short id cell; the point is the
                # longest thing left on the row
                cand = [c for c in cells
                        if not re.search(r"\bskipped\b|\bnot mapped\b", c, re.I)]
                cand = [c for c in cand if len(c) > 4]
                if cand:
                    skipped.append(max(cand, key=len))
        for point in skipped:
            tokens = [t for t in re.findall(r"[a-z]{5,}", point.lower())
                      if t not in ("skipped", "because", "reason")]
            if not tokens:
                continue
            for label, block in slot_blocks(sec):
                low = block.lower()
                hits = sum(1 for t in tokens if t in low)
                if hits >= 2:
                    err(f"{label} asserts '{point[:45]}', which the coverage map "
                        f"lists as SKIPPED. A point rejected in research may never "
                        f"be claimed by a slot [skipped-is-a-negative-constraint]")
                    break

    # 5) BANNED CLAIMS + PLACEHOLDERS --------------------------------------
    for m in BANNED_CLAIMS.finditer(md):
        err(f"banned claim in the brief: '{m.group(0)}' [compliance-avoid]", m.group(0))
    for m in PLACEHOLDERS.finditer(md):
        line_start = md.rfind("\n", 0, m.start()) + 1
        line_end = md.find("\n", m.start())
        line = md[line_start:line_end if line_end > 0 else len(md)]
        if not LAWFUL.search(line):
            err(f"unresolved placeholder: '{m.group(0)}'. An input is missing, "
                f"say which one [no-placeholders]", line)

    # 6) THE GENRUPT HANDOFF MUST EXIST ------------------------------------
    if find_section(sections, "genrupt handoff") is None:
        warn("no 'Genrupt handoff' section. The generation rooms read that "
             "section; without it they have nothing structured to send")

    # ---------------------------------------------------------------- out
    print(f"\nbrief-lint: {path.name}")
    print("=" * 52)
    for w in warnings:
        print(f"  WARN    {w}")
    for e in errors:
        print(f"  ERROR   {e}")
    if not errors and not warnings:
        print("  clean. Nothing to fix.")
    print("=" * 52)
    print(f"{len(errors)} error(s), {len(warnings)} warning(s)\n")
    if errors:
        print("Fix the BRIEF, never the linter. Every rule here exists because")
        print("skipping it once cost somebody a batch of images.\n")
    return 1 if errors else 0


if __name__ == "__main__":
    sys.exit(main())

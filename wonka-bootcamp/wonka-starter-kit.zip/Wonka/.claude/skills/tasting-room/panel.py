#!/usr/bin/env python3
"""The Tasting Room engine: a synthetic consumer panel for listing images.

Implements the semantic-similarity-rating (SSR) approach from arXiv:2510.08338:
demographic-conditioned LLM "tasters" react to each candidate image in FREE
TEXT; each reaction is mapped to a 1-5 purchase-intent score by embedding
similarity against Likert anchor statements (never by asking the model for a
number directly; direct rating elicitation collapses to "3" and loses signal).
Adds a forced-choice pass (all candidates side by side, pick one) for
head-to-head discrimination, and a within-set vote for per-image ranking.

Tasters MUST be built from the real buyer demographics (the persona from the
Research Room). The paper shows correlation attainment drops from ~90% to ~50%
without demographic conditioning. Use the buyer's REAL age, never the
aspirational display age used for casting models in images.

Usage: python3 panel.py config.json [lite]
Better: use run.py (cross-platform wrapper, keeps the machine awake on macOS
and renders the Tasting Card at the end).

Keys: OPENAI_API_KEY, loaded from the nearest .env (this folder upward to the
Factory root). Optional: GEMINI_API_KEY / ANTHROPIC_API_KEY for model mixing.
Outputs in config.out_dir: results.json, tasting-card.md (English).
"""

import base64
import io
import json
import mimetypes
import os
import random
import sys
import time
from collections import Counter, defaultdict
from concurrent.futures import ThreadPoolExecutor, as_completed
from functools import lru_cache
from pathlib import Path

import numpy as np
from dotenv import load_dotenv
from openai import OpenAI


def _load_env():
    """Load .env from the current folder upward (so the Factory root .env is
    found no matter which subfolder the run starts in), and then from this
    file's own tree (so a run launched from OUTSIDE the Factory still finds the
    key sitting at the Factory root). Exported environment variables always
    win, and the first file found wins over the second."""
    for start in (Path.cwd(), Path(__file__).resolve().parent):
        for d in [start, *start.parents]:
            f = d / ".env"
            if f.exists():
                load_dotenv(dotenv_path=f, override=False)
                break


_load_env()

# ---------------------------------------------------------------------------
# Clients. Built lazily so a missing optional key only fails if actually used.
# The per-request timeout is LOAD-BEARING: without it one hung connection
# blocks a worker thread forever, and once all workers hang the whole run
# stalls silently. 90s timeout + our own retries.
_clients = {}


def _openai_client():
    if "openai" not in _clients:
        key = os.environ.get("OPENAI_API_KEY")
        if not key:
            raise RuntimeError(
                "OPENAI_API_KEY is missing. Put it in the .env file at your Factory root "
                "(the same key you set up on Day 1). The Tasting Room cannot open without it."
            )
        _clients["openai"] = OpenAI(api_key=key, timeout=90.0, max_retries=0)
    return _clients["openai"]


def client_for(model: str):
    """MODEL MIXING: tasters can be split across different base models (and
    even different PROVIDERS) to soften the shared-base-model taste. All
    tasters on ONE model share one latent aesthetic preference that persona
    profiles alone cannot remove. Gemini rides the same OpenAI SDK via
    Google's OpenAI-compatible endpoint; Claude needs ANTHROPIC_API_KEY.
    Embeddings (the SSR scoring) always stay OpenAI, because changing the
    embedder changes the anchor geometry."""
    if model.startswith("gemini"):
        if "gemini" not in _clients:
            key = os.environ.get("GEMINI_API_KEY")
            if not key:
                raise RuntimeError(
                    "gemini-* taster models need GEMINI_API_KEY in your Factory root .env. "
                    "Either add the key or remove the gemini entry from \"models\" in the config."
                )
            _clients["gemini"] = OpenAI(
                api_key=key,
                base_url="https://generativelanguage.googleapis.com/v1beta/openai/",
                timeout=90.0,
                max_retries=0,
            )
        return _clients["gemini"]
    if model.startswith("claude"):
        if "anthropic" not in _clients:
            key = os.environ.get("ANTHROPIC_API_KEY")
            if not key:
                raise RuntimeError(
                    "claude-* taster models need ANTHROPIC_API_KEY in your Factory root .env "
                    "(from console.anthropic.com). Either add the key or remove the claude "
                    "entry from \"models\" in the config."
                )
            _clients["anthropic"] = OpenAI(
                api_key=key, base_url="https://api.anthropic.com/v1/", timeout=90.0, max_retries=0
            )
        return _clients["anthropic"]
    return _openai_client()


# ---------------------------------------------------------------------------
# Fallback demographics: a general US Amazon shopper. Used ONLY when the
# config carries no demographics (e.g. no persona.md yet). A real persona from
# the Research Room always beats this default.
DEFAULT_DEMOGRAPHICS = {
    "age_dist": {"18-24": 0.10, "25-34": 0.25, "35-44": 0.25, "45-54": 0.20, "55-64": 0.12, "65+": 0.08},
    "gender": {"female": 0.5, "male": 0.5},
    "income": {"lower-middle income": 0.3, "middle income": 0.5, "upper-middle income": 0.2},
    "notes": "DEFAULT general US Amazon shopper (no buyer persona supplied)",
}

# SSR anchors: 5 Likert points x 3 paraphrases (averaged per point, as in the
# paper's multi-set design, to stabilize the mapping).
ANCHORS = {
    1: [
        "I would definitely not buy this product.",
        "There is no way I would purchase this.",
        "I'm not interested in buying this at all.",
    ],
    2: [
        "I probably wouldn't buy this.",
        "It's rather unlikely that I'd purchase this.",
        "I don't think this product is for me.",
    ],
    3: [
        "I might or might not buy this.",
        "I'm on the fence about buying it.",
        "Not sure - I could go either way on this.",
    ],
    4: [
        "I would probably buy this.",
        "I'm fairly likely to purchase this.",
        "This looks good - I'd likely give it a try.",
    ],
    5: [
        "I would definitely buy this product.",
        "I'm certain I would purchase this.",
        "I'd buy this right away.",
    ],
}

TRAITS = {
    "shopping_style": [("bargain hunter", 0.3), ("value-for-money shopper", 0.45), ("premium buyer", 0.25)],
    "skepticism": [("takes claims at face value", 0.3), ("moderately skeptical of marketing", 0.5), ("highly skeptical of marketing claims", 0.2)],
    "attention": [("skims images quickly on a phone", 0.55), ("reads product images carefully", 0.45)],
    "familiarity": [("uses this kind of product regularly", 0.35), ("tried it before but lapsed", 0.25), ("curious first-time buyer", 0.4)],
}


def wpick(rng: random.Random, dist):
    """Weighted pick from [(value, weight)] or {value: weight}."""
    items = list(dist.items()) if isinstance(dist, dict) else dist
    total = sum(w for _, w in items)
    r = rng.random() * total
    for v, w in items:
        r -= w
        if r <= 0:
            return v
    return items[-1][0]


def age_from_band(rng: random.Random, band: str) -> int:
    band = band.strip().replace(" ", "")
    if band.endswith("+"):
        lo = int(band[:-1])
        return rng.randint(lo, lo + 12)
    lo, hi = (int(x) for x in band.split("-"))
    return rng.randint(lo, hi)


DEFAULT_MODEL_MIX = {"gpt-5.4-mini": 0.6, "gpt-5.4": 0.4}


def model_mix(cfg: dict) -> dict:
    """The taster model mix, {"model-name": weight}.
    An explicit "models" block wins; a single "model" runs deliberately
    single-model. The DEFAULT is a mix of two OpenAI models on the one key
    every Factory already has: one model = one shared taste, and a
    single-model panel has called a 75/25 that a mixed panel read as 45/55."""
    if cfg.get("models"):
        return cfg["models"]
    if cfg.get("model"):
        return {cfg["model"]: 1.0}
    return dict(DEFAULT_MODEL_MIX)


def build_tasters(cfg: dict, rng: random.Random):
    demo = cfg.get("demographics") or DEFAULT_DEMOGRAPHICS
    # A partial persona block is a normal authoring outcome, so every key falls
    # back on its own. age_dist used to be the one required key, and a persona
    # written without it crashed the run with a bare KeyError.
    age_dist = demo.get("age_dist") or DEFAULT_DEMOGRAPHICS["age_dist"]
    mix = model_mix(cfg)
    tasters = []
    for i in range(cfg.get("n_personas", 100)):
        band = wpick(rng, age_dist)
        p = {
            "id": i + 1,
            "age": age_from_band(rng, band),
            "age_band": band,
            "gender": wpick(rng, demo.get("gender", {"female": 0.5, "male": 0.5})),
            "income": wpick(rng, demo.get("income", {"middle income": 1.0})),
            "model": wpick(rng, mix),
            **{k: wpick(rng, v) for k, v in TRAITS.items()},
        }
        tasters.append(p)
    return tasters


def taster_model(p: dict, cfg: dict) -> str:
    return p.get("model") or cfg.get("model", "gpt-5.4-mini")


def taster_system(p: dict, cfg: dict) -> str:
    # "niche" is optional in the config; fall back to the product context so a
    # minimal config still produces grounded tasters.
    niche = cfg.get("niche") or cfg.get("product_context") or "this kind of"
    return (
        f"You are a {p['age']}-year-old {p['gender']} shopper in the US, {p['income']}. "
        f"You are a {p['shopping_style']}, you {p['skepticism']}, and you {p['attention']}. "
        f"You are a {p['familiarity']} of {niche} products. "
        "You are browsing Amazon. Speak in first person, plainly, like a real shopper - "
        "not a marketer, not an assistant. Be honest, including negative reactions."
    )


@lru_cache(maxsize=512)
def _encode_image(path: str, max_edge: int) -> tuple:
    """Downscale + JPEG-encode ONCE per (path, size), cached.

    LOAD-BEARING for reliability, not just cost: the NETWORK payload (not only
    the token `detail`) must be small. A full-res 2000px PNG is ~1.5MB; a
    7-image gallery sent per taster is then a ~13MB request, and on a home
    uplink with many concurrent workers every call blows past the 90s timeout,
    retries, and the run grinds for an hour producing __ERROR__ reactions.
    At `detail:"low"` the model only ever sees a ~512px thumbnail, so shipping
    the original is pure waste. Caching also collapses 100-tasters x N-images
    re-encodes of the SAME file down to one."""
    try:
        from PIL import Image
        im = Image.open(path)
        if im.mode not in ("RGB", "L"):
            im = im.convert("RGB")
        w, h = im.size
        if max(w, h) > max_edge:
            s = max_edge / max(w, h)
            im = im.resize((max(1, round(w * s)), max(1, round(h * s))), Image.LANCZOS)
        buf = io.BytesIO()
        im.save(buf, format="JPEG", quality=82)
        return "image/jpeg", base64.b64encode(buf.getvalue()).decode()
    except Exception:
        # Pillow missing or a decode failure: fall back to the raw bytes so a
        # run still works (just heavier) rather than crashing.
        mime = mimetypes.guess_type(path)[0] or "image/png"
        return mime, base64.b64encode(Path(path).read_bytes()).decode()


def img_part(path: str, detail: str = "auto") -> dict:
    # detail "low" -> the model downsamples to ~512px, so 768 longest-edge is
    # ample; give full-detail single images a bigger cap.
    max_edge = 768 if detail == "low" else 1024
    mime, b64 = _encode_image(path, max_edge)
    return {"type": "image_url", "image_url": {"url": f"data:{mime};base64,{b64}", "detail": detail}}


def paths_of(image: dict) -> list:
    """A candidate is a single image ({path}) or a STACK ({paths: [...]}),
    e.g. a whole secondary gallery tested against the live Amazon gallery."""
    return image.get("paths") or [image["path"]]


def _clean(text: str) -> str:
    """House style: no em or en dashes in any output, ever."""
    return text.replace(" \u2014 ", ", ").replace("\u2014", ", ").replace("\u2013", "-")


def chat(messages, model, max_tokens=220, retries=3, json_mode=False):
    c = client_for(model)
    # OpenAI's newer models want max_completion_tokens; the compat endpoints
    # (Gemini/Anthropic) speak classic max_tokens.
    is_compat = model.startswith(("gemini", "claude"))
    tok_key = "max_tokens" if is_compat else "max_completion_tokens"
    use_rf = json_mode
    use_re = model.startswith("gemini")  # disable Gemini "thinking"
    if model.startswith("gemini"):
        # Gemini spends "thinking" tokens INSIDE the budget; a small budget
        # gets eaten before the answer arrives, so raise the floor.
        max_tokens = max(max_tokens, 512)
    for attempt in range(retries):
        try:
            kwargs = {"model": model, "messages": messages, tok_key: max_tokens}
            if use_rf:
                kwargs["response_format"] = {"type": "json_object"}
            if use_re:
                kwargs["reasoning_effort"] = "none"
            r = c.chat.completions.create(**kwargs)
            return _clean((r.choices[0].message.content or "").strip())
        except Exception as e:  # noqa: BLE001 - retry then surface
            # a provider that rejects an optional param gets a retry without it
            # (callers all have lenient parsers)
            msg = str(e)
            if use_rf and "response_format" in msg:
                use_rf = False
                continue
            if use_re and "reasoning" in msg:
                use_re = False
                continue
            if attempt == retries - 1:
                return f"__ERROR__ {e}"
            time.sleep(2 * (attempt + 1))
    return "__ERROR__"


def react(p, image, cfg):
    """One taster reacts to one candidate (single image OR a whole stack)."""
    ps = paths_of(image)
    stack = len(ps) > 1
    ask = (
        f"These are the product photos on an Amazon listing for: {cfg['product_context']}. "
        "React honestly in 2-4 sentences: after flipping through them, what do you think and feel about the "
        "product? What works for you, what puts you off? Finish with how likely you'd be to buy."
        if stack
        else f"This is one of the photos on an Amazon listing for: {cfg['product_context']}. "
        "React honestly in 2-4 sentences: what does this photo make you think or feel about the "
        "product? What works for you, what puts you off? Finish with how likely you'd be to buy "
        "after seeing it."
    )
    content = [img_part(pp, "low" if stack else "auto") for pp in ps]
    content.append({"type": "text", "text": ask})
    msg = [{"role": "system", "content": taster_system(p, cfg)}, {"role": "user", "content": content}]
    return chat(msg, taster_model(p, cfg))


def react_image(p, set_img, cfg):
    """Per-image structured tasting note: one taster, ONE image out of a set,
    strict-JSON verdict. Powers the per-image cards on the Tasting Card."""
    msg = [
        {"role": "system", "content": taster_system(p, cfg)},
        {
            "role": "user",
            "content": [
                img_part(set_img["path"]),
                {
                    "type": "text",
                    "text": (
                        f"This is ONE image from an Amazon listing for: {cfg['product_context']}. "
                        "Judge THIS image's effect on whether YOU would buy - be decisive, most images are not neutral. "
                        "Respond in strict JSON only: "
                        '{"reaction": "2-3 honest first-person sentences about what this image makes you think/feel", '
                        '"works": "the single strongest thing this image does for you (empty string if nothing)", '
                        '"doesnt": "the single biggest problem with this image for you (empty string if nothing)", '
                        '"impact": "boosts" (this image makes me MORE likely to buy) | "neutral" (no real effect) '
                        '| "hurts" (this image makes me LESS likely to buy / I would distrust or skip it)}'
                    ),
                },
            ],
        },
    ]
    out = chat(msg, taster_model(p, cfg), max_tokens=260, json_mode=True)
    try:
        d = json.loads(out)
        v = str(d.get("impact", d.get("verdict", ""))).lower()
        return {
            "reaction": str(d.get("reaction", ""))[:600],
            "works": str(d.get("works", ""))[:300],
            "doesnt": str(d.get("doesnt", ""))[:300],
            "impact": v if v in ("boosts", "neutral", "hurts") else "neutral",
        }
    except Exception:  # noqa: BLE001
        return {"reaction": out[:600], "works": "", "doesnt": "", "impact": "neutral", "_raw": True}


def synthesize_image_takeaways(cfg, set_id, per_image_rows, model):
    """One call per SET: per-image top works/doesn't + a one-line takeaway."""
    blocks = []
    for row in per_image_rows:
        works = [f["works"] for f in row["feedback"] if f.get("works")][:15]
        doesnt = [f["doesnt"] for f in row["feedback"] if f.get("doesnt")][:15]
        blocks.append(
            f"### image_{row['idx']}\nWORKS:\n" + "\n".join(f"- {w}" for w in works)
            + "\nDOESN'T:\n" + "\n".join(f"- {x}" for x in doesnt)
        )
    prompt = (
        f"Synthetic shoppers reviewed each image of an Amazon listing set for: {cfg['product_context']}.\n\n"
        + "\n\n".join(blocks)
        + '\n\nReturn STRICT JSON: {"images": {"image_<idx>": {"top_works": [{"text": "short theme", "count": <int>}] (max 3), '
        '"top_doesnt": [{"text": "short theme", "count": <int>}] (max 3), '
        '"takeaway": "one imperative sentence: keep as-is / fix X / drop because Y"}}}. '
        "COUNT RULE: count = how many DISTINCT lines above raise that theme (honest tally, never a guess). "
        "Only recurring themes. JSON only."
    )
    out = chat([{"role": "user", "content": prompt}], model, max_tokens=2400, json_mode=True)
    try:
        return json.loads(out).get("images", {})
    except Exception:  # noqa: BLE001
        return {}


LETTERS = "ABCDEFGHIJKL"  # supports up to 12 candidates / images per set


def choose(p, images, cfg, rng: random.Random):
    """Forced choice: all candidates side by side (shuffled per taster).
    THE decision metric. Parsed via strict JSON (a free-text reply like
    "Sure, B..." used to risk grabbing a wrong letter from an unrelated word)."""
    order = list(range(len(images)))
    rng.shuffle(order)
    stacks = any(len(paths_of(i)) > 1 for i in images)
    unit = "Set" if stacks else "Photo"
    content = []
    for pos, idx in enumerate(order):
        content.append({"type": "text", "text": f"{unit} {LETTERS[pos]}:"})
        for pp in paths_of(images[idx]):
            content.append(img_part(pp, "low" if stacks else "auto"))
    content.append(
        {
            "type": "text",
            "text": (
                f"These are alternative image {unit.lower()}s for the SAME Amazon listing: {cfg['product_context']}. "
                f"Which ONE {unit.lower()} makes you most likely to buy? "
                'Reply as strict JSON only: {"choice":"<letter>","why":"one short sentence"}.'
            ),
        }
    )
    msg = [{"role": "system", "content": taster_system(p, cfg)}, {"role": "user", "content": content}]
    out = chat(msg, taster_model(p, cfg), max_tokens=120, json_mode=True)
    valid = LETTERS[: len(images)]
    if out.startswith("__ERROR__"):  # an API failure is NOT a vote. The lenient
        return None, out             # letter-scan would find one in "ERROR"/"RATE"
    letter = None
    try:
        letter = str(json.loads(out).get("choice", "")).strip().upper()[:1]
    except Exception:  # noqa: BLE001
        pass
    if not letter or letter not in valid:  # lenient fallback: first valid letter in the raw text
        letter = next((c for c in out.strip().upper() if c in valid), None)
    chosen = images[order[LETTERS.index(letter)]]["id"] if letter else None
    return chosen, out


def rank_within_set(p, set_img, cfg, rng: random.Random):
    """WITHIN-SET vote (the "strongest image" metric): one taster sees ALL
    images of ONE set (shuffled) and picks the MOST convincing and the
    WEAKEST. Comparative judgment discriminates far better than absolute 1-5
    scoring. Returns (best_idx, worst_idx) as 1-based image numbers in the
    set, or (None, None)."""
    ps = paths_of(set_img)
    if len(ps) < 2:
        return (1, None)
    if len(ps) > len(LETTERS):
        raise ValueError(f"set {set_img.get('id')} has {len(ps)} images; max {len(LETTERS)} supported")
    order = list(range(len(ps)))
    rng.shuffle(order)
    letters = LETTERS
    content = []
    for pos, idx in enumerate(order):
        content.append({"type": "text", "text": f"Image {letters[pos]}:"})
        content.append(img_part(ps[idx], "low"))
    content.append(
        {
            "type": "text",
            "text": (
                f"These are the images on ONE Amazon listing for: {cfg['product_context']}. "
                "As a shopper flipping through them, which ONE image is the MOST convincing "
                "(makes you most likely to buy) and which ONE is the WEAKEST? "
                'Reply as strict JSON only: {"best":"<letter>","worst":"<letter>"}.'
            ),
        }
    )
    msg = [{"role": "system", "content": taster_system(p, cfg)}, {"role": "user", "content": content}]
    out = chat(msg, taster_model(p, cfg), max_tokens=60, json_mode=True)
    valid = letters[: len(ps)]
    if out.startswith("__ERROR__"):  # an API failure must not become a phantom vote
        return (None, None)

    def to_idx(letter):
        return order[letters.index(letter)] + 1 if letter and letter in valid else None

    # primary: strict JSON
    try:
        d = json.loads(out)
        bl = str(d.get("best", "")).strip().upper()[:1]
        wl = str(d.get("worst", "")).strip().upper()[:1]
        if bl in valid:
            return (to_idx(bl), to_idx(wl))
    except Exception:  # noqa: BLE001
        pass
    # lenient fallback: pull the first two valid letters near "best"/"worst"
    up = out.upper()
    bl = next((c for c in up[up.find("BEST"):] if c in valid), None) if "BEST" in up else None
    wl = next((c for c in up[up.find("WORST"):] if c in valid), None) if "WORST" in up else None
    if not bl:
        bl = next((c for c in up if c in valid), None)
    return (to_idx(bl), to_idx(wl))


def embed_all(texts, batch=256):
    vecs = []
    for i in range(0, len(texts), batch):
        r = _openai_client().embeddings.create(model="text-embedding-3-small", input=texts[i : i + batch])
        vecs.extend(d.embedding for d in r.data)
    a = np.array(vecs, dtype=np.float64)
    return a / np.linalg.norm(a, axis=1, keepdims=True)


def ssr_scores(reaction_vecs, anchor_vecs_by_point, temp):
    """Map each reaction embedding to a pmf over 1..5 (softmax of mean cosine
    similarity per Likert point / temp), return expected scores + pmfs."""
    sims = np.stack(
        [np.mean(reaction_vecs @ np.stack(anchor_vecs_by_point[pt]).T, axis=1) for pt in range(1, 6)],
        axis=1,
    )  # (n, 5)
    logits = sims / temp
    logits -= logits.max(axis=1, keepdims=True)
    pmf = np.exp(logits)
    pmf /= pmf.sum(axis=1, keepdims=True)
    scores = pmf @ np.arange(1, 6)
    return scores, pmf


def synthesize_themes(cfg, images, reactions):
    """One aggregation call: per-candidate strengths/objections (WITH COUNTS),
    a cross-candidate ranked objection list, and suggested fixes.
    BLIND / ANTI-LEAK: candidates are referred to by NEUTRAL aliases (set_1,
    set_2...), never by their human labels. A label like "our new design" or
    "live on Amazon" would tell the judge the answer. Aliases are mapped back
    to ids after the call, so nothing about incumbency reaches the model."""
    alias = {img["id"]: f"set_{i + 1}" for i, img in enumerate(images)}
    back = {v: k for k, v in alias.items()}
    blocks = []
    for img in images:
        sample, seen = [], set()
        for r in reactions:
            if r["image_id"] != img["id"] or r["text"].startswith("__ERROR__"):
                continue
            t = r["text"].strip()
            if t in seen:  # dedupe identical reactions so a repeat can't inflate a theme
                continue
            seen.add(t)
            sample.append(t)
        joined = "\n".join(f"- {t}" for t in sample[:40])
        blocks.append(f"### {alias[img['id']]} ({min(len(sample), 40)} reactions)\n{joined}")
    prompt = (
        f"Below are reactions from a synthetic consumer panel to {len(images)} alternative Amazon listing images "
        f"for: {cfg['product_context']}.\n\n" + "\n\n".join(blocks) + "\n\n"
        "Return ONE strict JSON object with EXACTLY these four top-level keys, ALL REQUIRED: "
        '"images", "objections_ranked", "suggested_edits", "cross_takeaways". Never omit a key; use [] when empty.\n'
        '- "images": {"<set_alias>": {"strengths": [{"text": "short theme", "count": <int>}] (max 3), '
        '"objections": [{"text": "short theme", "count": <int>}] (max 3)}}\n'
        '- "objections_ranked": [{"text": "short theme", "count": <int>, "applies_to": ["<set_alias>", ...]}] '
        "(max 6, across ALL candidates, sorted by count descending)\n"
        '- "suggested_edits": [max 6 strings, each one concrete, surgical image edit that addresses a '
        "recurring objection - phrased as an instruction]\n"
        '- "cross_takeaways": [3-5 short strings - what this panel teaches about what converts for THIS '
        "audience, phrased as reusable creative rules]\n"
        "COUNT RULE: count = how many DISTINCT reactions above raise that theme (an honest tally, "
        "never a guess above the listed reactions). Only include themes that recur in 2 or more "
        "reactions. No markdown, JSON only."
    )
    def _parse(raw):
        try:
            return json.loads(raw[raw.index("{") : raw.rindex("}") + 1])
        except Exception:  # noqa: BLE001
            return None

    model = cfg.get("model", "gpt-5.4-mini")
    cross_keys = ("objections_ranked", "suggested_edits", "cross_takeaways")
    parsed, out = None, ""
    for _ in range(2):  # one retry: the model sometimes drops required keys anyway
        out = chat([{"role": "user", "content": prompt}], model, max_tokens=3000, json_mode=True)
        parsed = _parse(out)
        if parsed and parsed.get("images") and all(parsed.get(k) for k in cross_keys):
            break
    if not parsed:
        return {"images": {}, "objections_ranked": [], "suggested_edits": [], "cross_takeaways": [], "_raw": out}
    parsed.setdefault("images", {})
    # The model regularly returns ONLY "images" and drops the cross-candidate
    # keys. A short focused follow-up (tiny output, still in ALIAS space, no
    # image re-send) fills exactly what is missing far more reliably than
    # another full retry.
    missing = [k for k in cross_keys if not parsed.get(k)]
    if missing and parsed["images"]:
        f_prompt = (
            "Per-image recurring themes from a synthetic shopper panel (JSON):\n"
            + json.dumps(parsed["images"]) + "\n\n"
            "Return STRICT JSON with exactly these three keys: "
            '{"objections_ranked": [{"text": "short theme", "count": <int>, "applies_to": ["<set_alias>", ...]}] '
            "(max 6, across ALL candidates, sorted by count descending), "
            '"suggested_edits": [max 6 concrete, surgical image-edit instructions addressing recurring objections], '
            '"cross_takeaways": [3-5 short reusable creative rules for this audience]}. JSON only.'
        )
        extra = _parse(chat([{"role": "user", "content": f_prompt}], model, max_tokens=1200, json_mode=True)) or {}
        for k in missing:
            if extra.get(k):
                parsed[k] = extra[k]
    # map neutral aliases back to real image ids, and NORMALIZE shapes at the
    # source so no downstream renderer ever meets a bare list / bare string
    # (the model occasionally emits both; results.json must carry clean dicts)
    parsed["images"] = {
        back.get(k, k): (v if isinstance(v, dict)
                         else {"strengths": [], "objections": v if isinstance(v, list) else []})
        for k, v in parsed.get("images", {}).items()
    }
    parsed["objections_ranked"] = [
        (o if isinstance(o, dict) else {"text": str(o), "count": None, "applies_to": []})
        for o in (parsed.get("objections_ranked") or [])
    ]
    for o in parsed["objections_ranked"]:
        o["applies_to"] = [back.get(a, a) for a in (o.get("applies_to") or [])]
    parsed.setdefault("suggested_edits", [])
    parsed.setdefault("cross_takeaways", [])
    if not parsed.get("objections_ranked"):
        # deterministic fallback: aggregate the per-image objections by count so
        # the ranked list can never silently vanish from the report
        merged = {}
        for iid, tt in parsed["images"].items():
            # lenient: a malformed entry may be a bare list instead of the dict
            objs = tt.get("objections") if isinstance(tt, dict) else (tt if isinstance(tt, list) else None)
            for txt, cnt in theme_items(objs):
                m = merged.setdefault(txt.lower(), {"text": txt, "count": 0, "applies_to": []})
                m["count"] += cnt or 1
                m["applies_to"].append(iid)
        parsed["objections_ranked"] = sorted(merged.values(), key=lambda o: -o["count"])[:6]
    return parsed


def theme_items(lst):
    """Normalize a strengths/objections/top_works list to [(text, count)].
    Accepts both the new {"text","count"} dicts and legacy plain strings, so
    older results.json files still render."""
    out = []
    for t in lst or []:
        if isinstance(t, dict):
            txt = str(t.get("text", "")).strip()
            cnt = t.get("count")
            if txt:
                out.append((txt, int(cnt) if isinstance(cnt, (int, float)) and cnt else None))
        elif str(t).strip():
            out.append((str(t).strip(), None))
    return out


TIER_LABEL = {"clear": "Clear lead", "lean": "Lean", "tossup": "Toss-up"}
TIER_MEANING = {
    "clear": "safe to act on this alone",
    "lean": "directionally useful; confirm with another round before shipping",
    "tossup": "treat as a tie; use the objections, ignore the shares",
}


def bootstrap_stability(vote_counts, seed=42, resamples=1000):
    """vote_counts: [(id, votes)]. Bootstrap resample the recorded forced-choice
    votes and report the share of resamples where the winner stays strictly
    first, plus the minimum number of flipped votes that would erase rank 1.
    This is THE decision label, the same math the Tasting Card renders:
    clear (>= 95% of resamples), lean (80-95%), tossup (< 80%)."""
    pool = []
    for k, v in vote_counts:
        pool += [k] * v
    n = len(pool)
    ordered = sorted(vote_counts, key=lambda kv: -kv[1])
    winner = ordered[0][0]
    if n == 0 or len(ordered) < 2:
        return {"tier": "tossup", "holds": 0, "of": resamples, "flip_votes": 0, "winner": winner}
    rng = random.Random(seed)
    holds = 0
    for _ in range(resamples):
        c = Counter(pool[rng.randrange(n)] for _ in range(n))
        top = c.most_common(2)
        if top[0][0] == winner and (len(top) == 1 or top[0][1] > top[1][1]):
            holds += 1
    gap = ordered[0][1] - ordered[1][1]
    flip = gap // 2 + 1
    share = holds / resamples
    tier = "clear" if share >= 0.95 else ("lean" if share >= 0.80 else "tossup")
    return {"tier": tier, "holds": holds, "of": resamples, "flip_votes": flip, "winner": winner}


def model_agreement(tasters, choices):
    """Per-base-model forced-choice winners, computed from the recorded votes.
    With a model mix, a DISAGREEMENT between the base models means the "winner"
    is a model-taste artifact, not shopper signal - the caller downgrades the
    verdict to tossup (the card does the same)."""
    vote_of = {c["persona_id"]: c.get("chosen") for c in choices}
    model_names = sorted({p.get("model") for p in tasters if p.get("model")})
    if len(model_names) < 2:
        return None, {}
    winners = {}
    for m in model_names:
        cnt = Counter(vote_of.get(p["id"]) for p in tasters if p.get("model") == m and vote_of.get(p["id"]))
        if cnt:
            winners[m] = cnt.most_common(1)[0][0]
    return (len(set(winners.values())) <= 1 if winners else None), winners


def load_comparison(cfg, agg):
    """Optional round-over-round comparison. When the config has
    "compare_to": "/abs/path/to/previous/results.json", load that prior run
    and compute choice-share deltas for candidates sharing ids. Powers the
    Round Comparison section (Round 2 vs Round 1). Never required; a missing
    or unreadable file just skips the section with a console note."""
    prev_path = cfg.get("compare_to")
    if not prev_path:
        return None
    try:
        prev = json.loads(Path(prev_path).read_text())
        prev_agg = prev["aggregate"]
    except Exception as e:  # noqa: BLE001
        print(f"  note: compare_to could not be read ({e}); skipping the round comparison")
        return None
    prev_round = prev.get("config", {}).get("round")
    rows = []
    for iid, a in agg.items():
        row = {"id": iid, "label": a["label"], "share": a["choice_share"], "votes": a["choice_votes"]}
        pa = prev_agg.get(iid)
        if pa:
            row["prev_share"] = pa.get("choice_share")
            row["prev_votes"] = pa.get("choice_votes")
            row["delta_pts"] = round((a["choice_share"] - pa.get("choice_share", 0)) * 100)
        rows.append(row)
    return {
        "prev_path": str(prev_path),
        "prev_round": prev_round,
        "rows": rows,
        "new_ids": [i for i in agg if i not in prev_agg],
        "dropped_ids": [i for i in prev_agg if i not in agg],
    }


def cfg_sig(cfg):
    """Fingerprint of the inputs that determine the LLM calls. A checkpoint
    only resumes when these are unchanged."""
    key = {
        "images": [(i["id"], paths_of(i)) for i in cfg["images"]],
        "n": cfg.get("n_personas", 100),
        "model": cfg.get("model", "gpt-5.4-mini"),
        # The EFFECTIVE mix, not the raw config keys: a change to the built-in
        # default mix must also reset checkpoints, or a resume would mislabel
        # reactions already recorded under the old models.
        "models": model_mix(cfg),
        "seed": cfg.get("seed", 42),
        "pis": cfg.get("per_image_sample", 40),
        "ctx": cfg.get("product_context", ""),
    }
    import hashlib

    return hashlib.sha256(json.dumps(key, sort_keys=True).encode()).hexdigest()[:16]


def preflight_keys(cfg):
    """Every provider in the model mix must have its key BEFORE any spend.
    A missing key stops the run loudly and immediately; silently dropping a
    provider would quietly turn a mixed panel back into a single-model panel
    with one shared taste, and failing mid-run wastes the calls already made."""
    mix = model_mix(cfg)
    need = {"OPENAI_API_KEY"}  # tasters by default + embeddings/SSR are always OpenAI
    for m in mix:
        if m.startswith("gemini"):
            need.add("GEMINI_API_KEY")
        elif m.startswith("claude"):
            need.add("ANTHROPIC_API_KEY")
    missing = sorted(k for k in need if not os.environ.get(k))
    if missing:
        sys.exit(
            f"MISSING API KEY(S): {', '.join(missing)}. Add them to the .env file at your "
            f"Factory root. Refusing to start: the config's model mix {list(mix)} needs every "
            "provider's key, and dropping one would bias the tasting toward a single model's taste. "
            "Either add the key(s) or remove those entries from \"models\" in the config."
        )


def preflight_config(cfg):
    """Validate the config BEFORE any spend. Every failure listed here used to
    cost real money and surface late: a typo'd path crashed a worker thread
    mid-run (after the other reactions were already paid for), an
    `incumbent_id` matching no candidate silently dropped the vs-incumbent
    verdict from the card, two candidates sharing an id silently merged their
    votes, and a 13th candidate or a 13th frame in a set ran off the end of the
    letter alphabet the forced choice uses. All of it is knowable at zero cost,
    so it fails here, loudly, before the first call."""
    problems = []
    images = cfg.get("images")
    for key in ("images", "out_dir", "product_context"):
        if not cfg.get(key):
            problems.append(f'missing required config key "{key}"')
    if images is not None and not isinstance(images, list):
        problems.append('"images" must be a LIST of candidates')
        images = None
    if isinstance(images, list):
        if len(images) < 2:
            problems.append(
                f"only {len(images)} candidate in the config. The forced choice needs at least two, "
                "and a main-image race always carries the live incumbent as one of them."
            )
        if len(images) > len(LETTERS):
            problems.append(
                f"{len(images)} candidates; the forced choice supports at most {len(LETTERS)}"
            )
        seen = set()
        for i, img in enumerate(images, 1):
            if not isinstance(img, dict):
                problems.append(f"candidate #{i} is not an object")
                continue
            iid = img.get("id")
            if not iid:
                problems.append(f'candidate #{i} has no "id"')
                continue
            if iid in seen:
                problems.append(f'duplicate candidate id "{iid}"; ids must be unique or their votes merge')
            seen.add(iid)
            paths = img.get("paths") or ([img["path"]] if img.get("path") else [])
            if not paths:
                problems.append(f'candidate "{iid}" has neither "path" nor "paths"')
                continue
            if len(paths) > len(LETTERS):
                problems.append(
                    f'set "{iid}" has {len(paths)} frames; at most {len(LETTERS)} are supported'
                )
            for pth in paths:
                if not Path(pth).is_file():
                    problems.append(f'candidate "{iid}": file not found: {pth}')
        inc = cfg.get("incumbent_id")
        if inc and inc not in seen:
            problems.append(
                f'incumbent_id "{inc}" matches no candidate id ({", ".join(sorted(seen)) or "none"}). '
                "The incumbent must BE one of the candidates, or the vs-incumbent verdict "
                "silently vanishes from the card."
            )
    if problems:
        sys.exit(
            "CONFIG PROBLEM(S). Nothing ran and nothing was spent:\n  - "
            + "\n  - ".join(problems)
            + "\nFix the config and run the same command again."
        )


def apply_mode(cfg):
    """LITE mode = the same process at reduced volume: a quick taste (about 20
    tasters at the defaults), for eyeballing a set or testing the machine.
    Set `"mode": "lite"` in the config OR pass `lite` as the 2nd CLI arg.
    Runs at about a fifth of the configured tasters (minimum 8).
    Use the FULL tasting for anything that feeds a real decision."""
    mode = (cfg.get("mode") or "").lower()
    if len(sys.argv) > 2 and sys.argv[2].lower() == "lite":
        mode = "lite"
    if mode == "lite":
        cfg.setdefault("n_personas", 100)
        cfg.setdefault("per_image_sample", 40)
        cfg["n_personas"] = max(8, round(cfg["n_personas"] / 5))
        cfg["per_image_sample"] = max(6, round(cfg["per_image_sample"] / 4))
        cfg["_mode"] = "lite"
    return cfg


def main():
    raw_cfg_text = Path(sys.argv[1]).read_text()
    cfg = apply_mode(json.loads(raw_cfg_text))
    preflight_keys(cfg)
    preflight_config(cfg)
    out_dir = Path(cfg["out_dir"])
    out_dir.mkdir(parents=True, exist_ok=True)
    # Reproducibility artifact, written here so it can never be forgotten: the
    # exact config that ran, beside its own results. NEVER overwritten, so a
    # config that already lives in the round folder stays byte-for-byte as the
    # owner wrote it (and a lite re-run can never re-divide its own counts).
    saved_cfg = out_dir / "config.json"
    if not saved_cfg.exists():
        saved_cfg.write_text(raw_cfg_text)
    rng = random.Random(cfg.get("seed", 42))
    images = cfg["images"]
    for img in images:
        img.setdefault("label", img["id"])
    if not cfg.get("demographics"):
        cfg["demographics"] = DEFAULT_DEMOGRAPHICS
        print("note: no demographics in the config, using the DEFAULT general US Amazon shopper. "
              "A real buyer persona (Research Room, Day 2) makes the tasting sharper.")
    elif not cfg["demographics"].get("age_dist"):
        print("note: the demographics block carries no age_dist, so the default age spread is used. "
              "Copy the age bands from research/persona.md to sharpen the panel.")
    tasters = build_tasters(cfg, rng)
    workers = cfg.get("workers", 32)
    tag = " [LITE]" if cfg.get("_mode") == "lite" else ""
    mix = model_mix(cfg)
    print(f"tasting{tag}: {len(tasters)} tasters x {len(images)} candidates, models {', '.join(mix)}")

    # Live progress: writes out_dir/live.html (auto-opens, self-refreshing,
    # with a stall detector) so a minutes-long run is never a silent terminal.
    from progress import Progress
    product_name = cfg.get("product") or cfg.get("asin") or cfg.get("niche", "")
    prog = Progress(out_dir, title=f"Tasting Room{tag} - {product_name}",
                    subtitle=f"{len(tasters)} tasters x {len(images)} candidates")
    prog.update("tasters built", len(tasters), len(tasters))

    # Checkpoint: the expensive LLM phases are saved as they finish, so a run
    # killed by sleep / a closed laptop / a dropped connection RESUMES instead
    # of restarting from zero. Just run the same command again.
    ckpt_path = out_dir / ".panel_ckpt.json"
    sig = cfg_sig(cfg)
    ckpt = {}
    if ckpt_path.exists():
        try:
            loaded = json.loads(ckpt_path.read_text())
            if loaded.get("sig") == sig:
                ckpt = loaded
                print(f"  resuming from checkpoint: {[k for k in ('reactions', 'choices', 'image_feedback') if k in ckpt]}")
        except Exception:  # noqa: BLE001
            ckpt = {}

    def save_ckpt(**kv):
        ckpt.update(kv)
        ckpt["sig"] = sig
        ckpt_path.write_text(json.dumps(ckpt))

    # 1) reactions (tasters x candidates, parallel). Incremental checkpoint
    # every 40 so a death DURING this first phase (the common failure) still
    # resumes the completed (taster, candidate) pairs.
    partial = {(r["persona_id"], r["image_id"]): r for r in ckpt.get("reactions_partial", [])}
    if "reactions" in ckpt:
        reactions = ckpt["reactions"]
        print(f"  reactions (cached): {len(reactions)}")
    else:
        reactions = list(partial.values())
        jobs = [(p, img) for p in tasters for img in images if (p["id"], img["id"]) not in partial]
        if partial:
            print(f"  reactions resume: {len(partial)} done, {len(jobs)} left")
        with ThreadPoolExecutor(max_workers=workers) as ex:
            futs = {ex.submit(react, p, img, cfg): (p, img) for p, img in jobs}
            for n, fut in enumerate(as_completed(futs), 1):
                p, img = futs[fut]
                reactions.append({"persona_id": p["id"], "image_id": img["id"], "text": fut.result()})
                prog.update("taster reactions", len(reactions), len(tasters) * len(images))
                if n % 40 == 0:
                    print(f"  reactions {len(reactions)}/{len(tasters) * len(images)}")
                    save_ckpt(reactions_partial=reactions)
        ckpt.pop("reactions_partial", None)
        save_ckpt(reactions=reactions)
    ok = [r for r in reactions if not r["text"].startswith("__ERROR__")]
    print(f"  reactions done: {len(ok)}/{len(reactions)} ok")

    # 2) forced choice (one per taster, shuffled order)
    if "choices" in ckpt:
        choices = ckpt["choices"]
        print(f"  choices (cached): {len(choices)}")
    else:
        choices = []
        with ThreadPoolExecutor(max_workers=workers) as ex:
            futs = {ex.submit(choose, p, images, cfg, random.Random(cfg.get("seed", 42) * 1000 + p["id"])): p for p in tasters}
            for fut in as_completed(futs):
                p = futs[fut]
                chosen, raw = fut.result()
                choices.append({"persona_id": p["id"], "chosen": chosen, "raw": raw})
                prog.update("forced choice", len(choices), len(tasters))
        save_ckpt(choices=choices)
    choice_parse_rate = sum(1 for c in choices if c["chosen"]) / max(1, len(choices))
    print(f"  choices done: {sum(1 for c in choices if c['chosen'])}/{len(choices)} parsed")
    if choice_parse_rate < 0.9:
        print(f"  WARNING: only {round(choice_parse_rate * 100)}% of forced choices parsed. "
              "The win% is on a reduced sample; check API health and consider re-running.")

    # 2b) per-image structured tasting notes. Runs when any candidate is a
    # stack; for single-image candidates the set-level pass already IS
    # per-image. Sampled tasters per image to control cost.
    image_agg = {}
    stacks_mode = any(len(paths_of(i)) > 1 for i in images)
    if "image_feedback" in ckpt:
        image_feedback = ckpt["image_feedback"]
        print(f"  per-image (cached): {len(image_feedback)}")
    elif stacks_mode and cfg.get("per_image", True):
        image_feedback = []
        sample_n = int(cfg.get("per_image_sample", 40))
        rng_pi = random.Random(cfg.get("seed", 42) + 999)
        sample = tasters if len(tasters) <= sample_n else rng_pi.sample(tasters, sample_n)
        pi_jobs = []
        for img in images:
            for idx, path in enumerate(paths_of(img), 1):
                for p in sample:
                    pi_jobs.append((p, {"set_id": img["id"], "idx": idx, "path": path}))
        print(f"  per-image pass: {len(pi_jobs)} structured tasting notes")
        with ThreadPoolExecutor(max_workers=workers) as ex:
            futs = {ex.submit(react_image, p, si, cfg): (p, si) for p, si in pi_jobs}
            for n, fut in enumerate(as_completed(futs), 1):
                p, si = futs[fut]
                d = fut.result()
                image_feedback.append({"persona_id": p["id"], **si, **d})
                prog.update("per-image tasting notes", n, len(pi_jobs))
                if n % 100 == 0:
                    print(f"    per-image {n}/{len(pi_jobs)}")
        save_ckpt(image_feedback=image_feedback)
    else:
        image_feedback = []

    # 2c) WITHIN-SET vote (the "strongest image" metric): every taster picks
    # the most convincing + weakest image inside each stack. This comparative
    # vote is the PRIMARY per-image ranking; the isolation intent / net-impact
    # above stay as diagnostics. All tasters vote (better stats).
    if "within_votes" in ckpt:
        within_votes = ckpt["within_votes"]
        print(f"  within-set votes (cached): {len(within_votes)}")
    elif stacks_mode:
        within_votes = []
        wv_jobs = [(p, img) for img in images if len(paths_of(img)) > 1 for p in tasters]
        print(f"  within-set vote pass: {len(wv_jobs)} votes")
        with ThreadPoolExecutor(max_workers=workers) as ex:
            futs = {
                ex.submit(rank_within_set, p, img, cfg, random.Random(cfg.get("seed", 42) * 7 + p["id"])): (p, img)
                for p, img in wv_jobs
            }
            for n, fut in enumerate(as_completed(futs), 1):
                p, img = futs[fut]
                try:
                    best, worst = fut.result()
                except Exception as e:  # noqa: BLE001 - one bad vote must not kill the pass
                    print(f"    within-vote error (skipped): {str(e)[:80]}")
                    best, worst = None, None
                within_votes.append({"persona_id": p["id"], "set_id": img["id"], "best": best, "worst": worst})
                prog.update("within-set votes", n, len(wv_jobs))
                if n % 60 == 0:
                    print(f"    within-vote {n}/{len(wv_jobs)}")
        save_ckpt(within_votes=within_votes)
    else:
        within_votes = []
    if within_votes:
        wv_rate = sum(1 for v in within_votes if v.get("best")) / len(within_votes)
        if wv_rate < 0.9:
            print(f"  WARNING: only {round(wv_rate * 100)}% of within-set votes parsed. "
                  "Per-image ranking is on a reduced sample.")

    # 3) SSR scoring
    prog.update("SSR scoring + theme synthesis")
    if not ok:
        sys.exit("Every reaction failed (__ERROR__). The provider is down or the key is "
                 "rate-limited. Nothing was scored; fix the connection and run the same "
                 "command again (the checkpoint resumes).")
    anchor_texts = [t for pt in range(1, 6) for t in ANCHORS[pt]]
    anchor_vecs = embed_all(anchor_texts)
    anchor_by_point = {pt: [anchor_vecs[(pt - 1) * 3 + j] for j in range(3)] for pt in range(1, 6)}
    reaction_vecs = embed_all([r["text"] for r in ok])
    scores, pmfs = ssr_scores(reaction_vecs, anchor_by_point, cfg.get("temp", 0.075))
    for r, s, pmf in zip(ok, scores, pmfs):
        r["ssr"] = round(float(s), 3)
        r["pmf"] = [round(float(x), 3) for x in pmf]

    # per-image SSR + aggregation (needs the anchors from above)
    if stacks_mode and cfg.get("per_image", True):
        pi_ok = [f for f in image_feedback if f["reaction"] and not f["reaction"].startswith("__ERROR__")]
        if pi_ok:
            pi_vecs = embed_all([f["reaction"] for f in pi_ok])
            pi_scores, _ = ssr_scores(pi_vecs, anchor_by_point, cfg.get("temp", 0.075))
            for f, s in zip(pi_ok, pi_scores):
                f["ssr"] = round(float(s), 3)
        for img in images:
            votes = [v for v in within_votes if v["set_id"] == img["id"]]
            vote_total = sum(1 for v in votes if v.get("best"))
            rows = []
            for idx, path in enumerate(paths_of(img), 1):
                fb = [f for f in image_feedback if f["set_id"] == img["id"] and f["idx"] == idx]
                good = [f for f in fb if f.get("ssr") is not None]
                boosts = sum(1 for f in fb if f["impact"] == "boosts")
                hurts = sum(1 for f in fb if f["impact"] == "hurts")
                strongest = sum(1 for v in votes if v.get("best") == idx)
                weakest = sum(1 for v in votes if v.get("worst") == idx)
                rows.append(
                    {
                        "idx": idx,
                        "path": path,
                        "n": len(fb),
                        "ssr_mean": round(float(np.mean([f["ssr"] for f in good])), 3) if good else None,
                        "boosts": boosts,
                        "neutral": sum(1 for f in fb if f["impact"] == "neutral"),
                        "hurts": hurts,
                        "net_impact": boosts - hurts,  # >0 helps the listing, <0 drags it
                        # PRIMARY per-image ranking metric (comparative vote):
                        "strongest_votes": strongest,
                        "weakest_votes": weakest,
                        "strongest_pct": round(strongest / vote_total * 100) if vote_total else None,
                        "vote_total": vote_total,
                        "feedback": fb,
                    }
                )
            takeaways = synthesize_image_takeaways(cfg, img["id"], rows, cfg.get("model", "gpt-5.4-mini"))
            for row in rows:
                t = takeaways.get(f"image_{row['idx']}", {})
                row["top_works"] = t.get("top_works", [])
                row["top_doesnt"] = t.get("top_doesnt", [])
                row["takeaway"] = t.get("takeaway", "")
                row["feedback"] = [{k: v for k, v in f.items() if k not in ("set_id", "idx", "path")} for f in row["feedback"]]
            image_agg[img["id"]] = rows

    # 4) aggregate
    by_img = defaultdict(list)
    taster_by_id = {p["id"]: p for p in tasters}
    for r in ok:
        by_img[r["image_id"]].append(r)
    agg = {}
    total_choices = max(1, sum(1 for c in choices if c["chosen"]))
    for img in images:
        rs = by_img[img["id"]]
        vals = np.array([r["ssr"] for r in rs])
        seg = defaultdict(list)
        for r in rs:
            p = taster_by_id[r["persona_id"]]
            seg[p["age_band"]].append(r["ssr"])
            seg[p["gender"]].append(r["ssr"])
            # per-model segment: shows when the base models DISAGREE (the whole
            # point of mixing). A candidate that wins on one model and loses on
            # another is a model-taste artifact, not a real audience signal.
            if p.get("model"):
                seg[p["model"]].append(r["ssr"])
        agg[img["id"]] = {
            "label": img["label"],
            "n": len(rs),
            "ssr_mean": round(float(vals.mean()), 3) if len(rs) else None,
            "ssr_std": round(float(vals.std()), 3) if len(rs) else None,
            "choice_votes": sum(1 for c in choices if c["chosen"] == img["id"]),
            "choice_share": round(sum(1 for c in choices if c["chosen"] == img["id"]) / total_choices, 3),
            "segments": {k: round(float(np.mean(v)), 3) for k, v in sorted(seg.items())},
        }
    # Verdict: BOOTSTRAP STABILITY of the forced choice is the decision label
    # (Clear lead / Lean / Toss-up) - the exact same math the Tasting Card
    # renders, so the markdown twin and the card can never disagree. The
    # z-approx stays in results for continuity. A per-model disagreement
    # forces Toss-up: the "winner" is model taste, not shopper signal.
    ranked_ids = sorted(agg, key=lambda i: -agg[i]["choice_votes"])
    c1, c2 = agg[ranked_ids[0]]["choice_votes"], agg[ranked_ids[1]]["choice_votes"] if len(ranked_ids) > 1 else 0
    z = (c1 - c2) / max(1e-9, (c1 + c2) ** 0.5)
    stab = bootstrap_stability(
        [(i["id"], agg[i["id"]]["choice_votes"]) for i in images], seed=cfg.get("seed", 42)
    )
    models_agree, model_winners = model_agreement(tasters, choices)
    if models_agree is False:
        stab["tier"] = "tossup"
    verdict = {
        "winner_id": ranked_ids[0],
        "winner_vs_runner_up_z": round(float(z), 2),
        "significant": bool(z >= 1.96),
        "stability": stab,
        "label": TIER_LABEL[stab["tier"]],
        "models_agree": models_agree,
        "model_winners": model_winners,
    }
    incumbent_id = cfg.get("incumbent_id")
    if incumbent_id and incumbent_id in agg:
        inc = agg[incumbent_id]
        verdict["incumbent_id"] = incumbent_id
        verdict["winner_beats_incumbent"] = ranked_ids[0] != incumbent_id
        verdict["winner_vs_incumbent_pts"] = round(
            (agg[ranked_ids[0]]["choice_share"] - inc["choice_share"]) * 100
        )
    themes = synthesize_themes(cfg, images, ok)
    comparison = load_comparison(cfg, agg)

    # 5) write results + Tasting Card (markdown)
    results = {
        "run_date": time.strftime("%Y-%m-%d"),
        "config": {k: v for k, v in cfg.items() if k != "images"},
        "images": [{"id": i["id"], "label": i["label"], "paths": paths_of(i)} for i in images],
        "personas": tasters,
        "aggregate": agg,
        "verdict": verdict,
        "quality": {
            "reactions_ok": len(ok),
            "reactions_total": len(reactions),
            "choice_parse_rate": round(choice_parse_rate, 3),
            "within_vote_parse_rate": round(
                sum(1 for v in within_votes if v.get("best")) / len(within_votes), 3
            ) if within_votes else None,
        },
        "themes": themes,
        "comparison": comparison,
        "image_agg": image_agg,
        "within_votes": within_votes,
        "reactions": reactions,
        "choices": choices,
    }
    (out_dir / "results.json").write_text(json.dumps(results, indent=1))

    # Ranking doctrine: the forced CHOICE decides, SSR intent is diagnostic.
    ranked = sorted(images, key=lambda i: -agg[i["id"]]["choice_votes"])
    product = cfg.get("product") or cfg.get("asin") or cfg.get("niche", "product")
    round_no = cfg.get("round", 1)
    def fmt_theme(lst):
        return "; ".join(f"{t}{f' (x{c})' if c else ''}" for t, c in theme_items(lst)) or "-"

    lines = [
        f"# Tasting Room Results - {product} (Round {round_no})",
        "",
        f"**Product:** {cfg['product_context']}",
        f"**Panel:** {len(tasters)} synthetic tasters matched to the buyer "
        f"({cfg['demographics'].get('notes', '')}), models: {', '.join(mix)}, "
        f"{'lite' if cfg.get('_mode') == 'lite' else 'full'} mode, {time.strftime('%Y-%m-%d')}. "
        "Free-text reactions scored via SSR (arXiv 2510.08338).",
        "",
    ]
    if choice_parse_rate < 0.9:
        lines += [
            f"**QUALITY WARNING: only {round(choice_parse_rate * 100)}% of forced-choice votes parsed.** "
            "The shares below sit on a reduced sample; re-run (it resumes) before trusting the verdict.",
            "",
        ]
    lines += [
        "## Verdict",
        "",
        "| # | Candidate | Choice share | Votes | Purchase intent 1-5 (diagnostic) | n |",
        "|---|-----------|--------------|-------|----------------------------------|---|",
    ]
    for rank, img in enumerate(ranked, 1):
        a = agg[img["id"]]
        tag2 = " [WINNER]" if img["id"] == verdict["winner_id"] else ""
        tag2 += " [CURRENT LISTING]" if img["id"] == cfg.get("incumbent_id") else ""
        lines.append(
            f"| {rank} | {img['id']} ({img['label']}){tag2} | {round(a['choice_share'] * 100)}% "
            f"| {a['choice_votes']}/{total_choices} | {a['ssr_mean']} +/- {a['ssr_std']} | {a['n']} |"
        )
    lines.append("")
    lines.append(
        f"**{verdict['label']}.** Winner: {verdict['winner_id']} - holds first place in "
        f"{stab['holds']:,} of {stab['of']:,} bootstrap resamples of the recorded votes; "
        f"the lead flips if {stab['flip_votes']} votes change sides. "
        f"({TIER_MEANING[stab['tier']]}. Tiers: Clear lead >= 95% of resamples, Lean 80-95%, Toss-up under 80%.)"
    )
    if models_agree is False:
        lines.append(
            "**THE BASE MODELS DISAGREE on the winner** ("
            + "; ".join(f"{m}: {w}" for m, w in model_winners.items())
            + ") - that is model taste, not shopper signal. NO reliable verdict: keep the objections, drop the percentages."
        )
    if "incumbent_id" in verdict:
        rel = (
            f"BEATS the live Amazon image by {verdict['winner_vs_incumbent_pts']} pts of choice share"
            if verdict["winner_beats_incumbent"]
            else "does NOT beat the live Amazon image. The incumbent held."
        )
        lines.append(f"**Vs current listing ({verdict['incumbent_id']}):** the top candidate {rel}.")
    # Per-image within-set vote ranking (the strongest / weakest frame story).
    if image_agg:
        lines += ["", "## Strongest frame in each set (within-set vote)", ""]
        for img in ranked:
            rows = image_agg.get(img["id"]) or []
            if not rows:
                continue
            rr = sorted(rows, key=lambda r: (-(r.get("strongest_votes") or 0), (r.get("weakest_votes") or 0)))
            lines.append(f"### {img['id']} ({img['label']})")
            for i, r in enumerate(rr):
                tag2 = "STRONGEST" if i == 0 else ("WEAKEST" if i == len(rr) - 1 else f"#{i + 1}")
                lines.append(
                    f"- [{tag2}] frame {r['idx']}: {r.get('strongest_pct', 0) or 0}% picked most convincing "
                    f"({r.get('strongest_votes', 0)}/{r.get('vote_total', 0)}), {r.get('weakest_votes', 0)} called it weakest"
                    + (f". {r['takeaway']}" if r.get("takeaway") else "")
                )
            lines.append("")

    lines += ["", "## Segments (mean purchase intent)", ""]
    for img in ranked:
        a = agg[img["id"]]
        segs = " | ".join(f"{k}: {v}" for k, v in a["segments"].items())
        lines.append(f"- **{img['id']}**: {segs}")
    lines += ["", "## What the tasters keep saying (ranked objections)", ""]
    for o in themes.get("objections_ranked", []):
        cnt = o.get("count")
        applies = ", ".join(o.get("applies_to") or [])
        lines.append(
            f"- {'(x' + str(cnt) + ') ' if cnt else ''}{o.get('text', '')}"
            + (f" [applies to: {applies}]" if applies else "")
        )
    lines += ["", "### Per-candidate themes", ""]
    for img in ranked:
        t = themes.get("images", {}).get(img["id"], {})
        lines.append(f"**{img['id']}** ({img['label']})")
        lines.append(f"- What worked: {fmt_theme(t.get('strengths'))}")
        lines.append(f"- What hurt: {fmt_theme(t.get('objections'))}")
        lines.append("")
    lines += [
        "## Suggested fixes (apply only if consistent with your research)",
        "",
        "Apply a fix ONLY if it agrees with your research (the selling points and the Improvement Log).",
        "A synthetic objection that contradicts real evidence gets recorded, not acted on. When a fix",
        "is applied, keep the pre-fix original too, so a later test can prove the fix actually helped.",
        "",
    ]
    lines += [f"{i}. {e}" for i, e in enumerate(themes.get("suggested_edits", []), 1)]
    if comparison:
        lines += [
            "",
            f"## Round comparison (vs Round {comparison.get('prev_round') or 'previous'})",
            "",
            "| Candidate | Previous share | This round | Delta |",
            "|-----------|----------------|------------|-------|",
        ]
        for row in comparison["rows"]:
            if "delta_pts" in row:
                d = row["delta_pts"]
                arrow = "up" if d > 0 else ("down" if d < 0 else "flat")
                lines.append(
                    f"| {row['id']} | {round((row.get('prev_share') or 0) * 100)}% | "
                    f"{round(row['share'] * 100)}% | {'+' if d > 0 else ''}{d} pts ({arrow}) |"
                )
            else:
                lines.append(f"| {row['id']} | new this round | {round(row['share'] * 100)}% | - |")
        if comparison.get("dropped_ids"):
            lines += ["", f"Not in this round: {', '.join(comparison['dropped_ids'])}."]
    lines += [
        "",
        "## How to read this card (house rules)",
        "",
        "- These tasters are language models playing shoppers, not real shoppers. Never quote these",
        "  numbers as customer results.",
        "- The verdict label is standardized by bootstrap resampling the recorded votes: Clear lead",
        "  (holds in >= 95% of resamples), Lean (80-95%), Toss-up (under 80%, or the base models",
        "  disagree). Anything under Clear lead is a lean, not proof.",
        "- A single-model panel carries one shared model taste that can bias the win%; the model mix",
        "  softens this. If the per-model rows disagree on the winner, treat it as NO reliable verdict.",
        "- The most reliable value here is the relative per-image ranking plus the recurring",
        "  objections. Those travel well; the exact percentages do not.",
        "- For a real-money decision, a real shopper poll (the optional Pro Move bonus) is the gold",
        "  standard.",
        "",
        "Method: free-text reactions mapped to 1-5 purchase intent via embedding similarity to Likert",
        "anchor statements (SSR, arXiv:2510.08338); forced choice shown per taster in shuffled order;",
        "tasters conditioned on the real buyer demographics.",
    ]
    (out_dir / "tasting-card.md").write_text("\n".join(lines))
    # success -> drop the checkpoint so the next run starts clean (only now:
    # a crash while writing the card must stay resumable)
    try:
        ckpt_path.unlink()
    except FileNotFoundError:
        pass
    print(f"wrote {out_dir}/tasting-card.md and results.json")
    prog.done("tasting-card.md + results.json written")
    print(json.dumps({i: {k: agg[i][k] for k in ('ssr_mean', 'choice_share')} for i in agg}, indent=1))


if __name__ == "__main__":
    main()

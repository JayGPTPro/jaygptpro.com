#!/usr/bin/env python3
"""End to end, offline: a whole sitting of TWO races, with no API calls.

`chat` and `embed_all` are stubbed, so this exercises everything our side owns
(persona build, forced choice, SSR scoring, verdict, both report builders, the
progress states, scope derivation, coverage union and the gate) and nothing
OpenAI owns. Deterministic, free, and runnable as many times as you like,
which is exactly what a real paid run is not.

The stub is deliberately shaped like the case the reporting used to get wrong:
a near-unanimous forced choice sitting on a hair of purchase intent.

Run: python3 test_e2e.py
"""
import json
import random
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

FAILURES = []


def check(name, cond, detail=""):
    print(("  PASS  " if cond else "  FAIL  ") + name + ("  " + str(detail) if not cond and detail else ""))
    if not cond:
        FAILURES.append(name)


def png(path, w=48, h=48, shade=200):
    """A real, decodable PNG so the image encoder is genuinely exercised."""
    import zlib
    import struct
    raw = b"".join(b"\x00" + bytes([shade, shade, shade] * w) for _ in range(h))
    def chunk(t, d):
        c = t + d
        return struct.pack(">I", len(d)) + c + struct.pack(">I", zlib.crc32(c) & 0xFFFFFFFF)
    path.write_bytes(
        b"\x89PNG\r\n\x1a\n"
        + chunk(b"IHDR", struct.pack(">IIBBBBB", w, h, 8, 2, 0, 0, 0))
        + chunk(b"IDAT", zlib.compress(raw))
        + chunk(b"IEND", b"")
    )


# ---------------------------------------------------------------- the stub
_rng = random.Random(7)


def fake_chat(messages, model, max_tokens=220, retries=3, json_mode=False):
    txt = json.dumps(messages)[-4000:]
    if "persona" in txt.lower() and json_mode:
        return json.dumps({"personas": [
            {"id": f"p{i}", "age": 30 + i % 30, "gender": "F" if i % 2 else "M",
             "income": "mid", "shopping": "price aware", "note": "n"} for i in range(40)]})
    if json_mode:
        return json.dumps({"themes": ["cannot tell the size", "looks like plastic"]})
    # forced choice: overwhelmingly B, which is the shape that used to be
    # reported as a landslide on a difference of nothing
    if "Photo A" in txt or "Set A" in txt:
        return "B" if _rng.random() < 0.95 else "A"
    return _rng.choice([
        "Looks clean but I cannot tell how big it is.",
        "Feels premium. I would probably buy it.",
        "Not sure about the material, might be plastic.",
    ])


def fake_embed_all(texts, batch=256):
    out = []
    for t in texts:
        h = sum(ord(c) for c in t)
        out.append([((h >> k) % 100) / 100.0 for k in range(8)])
    return out


def drive(panel, cfg_path):
    """panel.main() is argv driven, so drive it the way run.py does."""
    old = sys.argv
    sys.argv = ["panel.py", str(cfg_path), "lite"]
    try:
        panel.main()
    finally:
        sys.argv = old


def run():
    import os
    os.environ.setdefault("OPENAI_API_KEY", "sk-test-offline-stub")
    os.environ["PANEL_OPEN_LIVE"] = "0"          # no browser windows in a test
    import panel
    panel.chat = fake_chat
    panel.embed_all = fake_embed_all
    import scope

    tmp = Path(tempfile.mkdtemp())
    try:
        prod = tmp / "factory" / "Products" / "fondue"
        (prod / "images").mkdir(parents=True)
        (prod / "incumbent").mkdir(parents=True)
        (prod / "tests").mkdir(parents=True)
        (prod / "research").mkdir(parents=True)
        for i, n in enumerate(["main-01.png", "main-02.png", "sec-01.png", "sec-02.png"]):
            png(prod / "images" / n, shade=120 + i * 30)
        png(prod / "incumbent" / "main-live.png", shade=90)
        png(prod / "incumbent" / "gal-live-01.png", shade=95)
        png(prod / "incumbent" / "gal-live-02.png", shade=100)

        print("\n1. Scope is derived from disk, before any config is written")
        s = scope.derive(prod)
        check("main race scope", s["main"] == ["main-01.png", "main-02.png"], s["main"])
        check("gallery scope", s["gallery"] == ["sec-01.png", "sec-02.png"], s["gallery"])
        check("benchmark found", s["incumbent_main"] == ["main-live.png"], s["incumbent_main"])
        scope.cmd_plan(str(prod))

        common = {
            "product": "fondue fountain", "asin": "B09BDGFKXB",
            "product_context": "A 4 tier electric chocolate fondue fountain",
            "niche": "chocolate fondue fountain",
            "demographics": {"notes": "US home entertainers 30-60"},
            "seed": 42,
        }

        print("\n2. Race 1 of 2: the MAIN race")
        d1 = prod / "tests" / "tasting-r1-main"
        d1.mkdir()
        cfg1 = dict(common, round=1, race="main", incumbent_id="current_listing",
                    out_dir=str(d1), images=[
                        {"id": "main_01", "label": "hero on white", "path": str(prod / "images" / "main-01.png")},
                        {"id": "main_02", "label": "hero with tag", "path": str(prod / "images" / "main-02.png")},
                        {"id": "current_listing", "label": "current listing",
                         "path": str(prod / "incumbent" / "main-live.png")}])
        (d1 / "config.json").write_text(json.dumps(cfg1))
        drive(panel, d1 / "config.json")
        res1 = json.loads((d1 / "results.json").read_text())
        check("results.json written", bool(res1.get("verdict")))
        v = res1["verdict"]
        print(f"     tier={v['label']}  intent_gap={v.get('intent_gap')}  "
              f"downgraded={v.get('tier_downgraded_for_magnitude')}")
        check("verdict carries the intent gap", "intent_gap" in v)
        check("a near-unanimous vote on a hair is NOT a Clear lead",
              v["label"] != "Clear lead" or v.get("intent_gap_decisive"),
              f"label={v['label']} gap={v.get('intent_gap')}")

        md = (d1 / "tasting-card.md").read_text()
        check("markdown headline is a count", "of " in md and "Chosen by" in md)
        check("no % on the choice metric in markdown",
              "Choice share" not in md and "pts of choice share" not in md)

        print("\n3. The progress page does not claim FINISHED yet")
        pj = json.loads((d1 / "progress.json").read_text()) if (d1 / "progress.json").exists() else {}
        check("engine handed off, did not finish", pj.get("finished") is False, pj.get("finished"))
        check("awaiting is set", pj.get("awaiting") is True)

        print("\n4. The card process renders and then closes the run")
        subprocess.check_call([sys.executable, str(HERE / "tasting_card.py"), str(d1 / "results.json")],
                              stdout=subprocess.DEVNULL)
        html = (d1 / "tasting-card.html").read_text()
        check("card rendered", len(html) > 20000, len(html))
        pj = json.loads((d1 / "progress.json").read_text())
        check("now FINISHED, closed by the other process", pj.get("finished") is True)
        import re
        leaks = [m.group(0) for m in re.finditer(r'>\s*\d{1,3}%\s*<', html)]
        check("no bare percentage rendered as a headline number", not leaks, leaks[:5])

        scope.cmd_record(str(prod), str(d1))
        print("\n5. The gate BLOCKS on a half-finished sitting")
        check("blocked with only the main race in", scope.cmd_check(str(prod)) == 1)

        print("\n6. Race 2 of 2: the GALLERY race")
        d2 = prod / "tests" / "tasting-r1-gallery"
        d2.mkdir()
        cfg2 = dict(common, round=1, race="gallery", incumbent_id="live_set",
                    out_dir=str(d2), images=[
                        {"id": "our_set", "label": "our gallery",
                         "paths": [str(prod / "images" / "sec-01.png"), str(prod / "images" / "sec-02.png")]},
                        {"id": "live_set", "label": "live gallery",
                         "paths": [str(prod / "incumbent" / "gal-live-01.png"),
                                   str(prod / "incumbent" / "gal-live-02.png")]}])
        (d2 / "config.json").write_text(json.dumps(cfg2))
        drive(panel, d2 / "config.json")
        check("gallery results written", (d2 / "results.json").exists())
        subprocess.check_call([sys.executable, str(HERE / "tasting_card.py"), str(d2 / "results.json")],
                              stdout=subprocess.DEVNULL)
        html2 = (d2 / "tasting-card.html").read_text()
        check("gallery card rendered (report builder B)", len(html2) > 20000, len(html2))
        leaks2 = [m.group(0) for m in re.finditer(r'>\s*\d{1,3}%\s*<', html2)]
        check("report B has no bare percentage headline either", not leaks2, leaks2[:5])

        scope.cmd_record(str(prod), str(d2))
        cov = json.loads((prod / "tests" / "coverage.json").read_text())
        check("coverage holds BOTH races", set(cov["races"]) == {"r1-main", "r1-gallery"}, set(cov["races"]))

        print("\n7. The gate PASSES, and each card names its twin")
        check("gate passes", scope.cmd_check(str(prod)) == 0)
        subprocess.check_call([sys.executable, str(HERE / "tasting_card.py"), str(d1 / "results.json")],
                              stdout=subprocess.DEVNULL)
        html = (d1 / "tasting-card.html").read_text()
        check("the main card names the gallery race", "GALLERY race" in html or "gallery race" in html.lower(),
              "sibling note missing")
        check("and links to it", "tasting-r1-gallery" in html)
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


if __name__ == "__main__":
    run()
    print()
    if FAILURES:
        print(f"{len(FAILURES)} FAILED: {', '.join(FAILURES)}")
        sys.exit(1)
    print("END TO END: all green")

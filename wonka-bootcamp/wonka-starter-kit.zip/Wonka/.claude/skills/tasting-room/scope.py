#!/usr/bin/env python3
"""What this sitting OWES, what it actually tested, and a gate on the gap.

The failure this exists to prevent: eight frames approved, the panel run on
one, seven never tested including one already flagged as a quality failure,
and no surface mentioning it. The scope lived in prose ("the approved
candidates"), bound to no field and checked by nothing. Two records that must
agree, with no code comparing them, drift; and the drift is invisible.

So scope is derived from disk rather than asserted:

  images/main-*   the main-race candidates the owner picked
  images/sec-*    the gallery frames
  incumbent/      the live image and gallery to beat

Three commands:

  plan   <product_dir>              what each race owes, before you author a config
  record <product_dir> <race_dir>   fold one finished race into the coverage
  check  <product_dir>              the gate: refuse to close on a silent gap

Coverage ACCUMULATES across the races of a sitting. A sitting is two races
(main and gallery) that finish minutes apart, and each one writing its own
record would erase the other's; then no pair of races could ever satisfy the
gate. Keyed on (round, race) so a second round registers its own row instead
of overwriting the first.

Stdlib only, cross-platform. No network.
"""
import json
import sys
import time
from pathlib import Path

IMG_EXT = {".png", ".jpg", ".jpeg", ".webp"}
COVERAGE = "coverage.json"


def _imgs(d):
    if not d.is_dir():
        return []
    return sorted(p for p in d.iterdir() if p.suffix.lower() in IMG_EXT and not p.name.startswith("."))


def derive(product_dir):
    """The approved scope, read off the disk that holds it."""
    p = Path(product_dir).resolve()
    images = _imgs(p / "images")
    main = [f for f in images if f.name.lower().startswith("main")]
    gallery = [f for f in images if not f.name.lower().startswith("main")]
    inc = _imgs(p / "incumbent")
    inc_main = [f for f in inc if "main" in f.name.lower()]
    inc_gallery = [f for f in inc if f not in inc_main]
    return {
        "product_dir": str(p),
        "main": [f.name for f in main],
        "gallery": [f.name for f in gallery],
        "incumbent_main": [f.name for f in inc_main],
        "incumbent_gallery": [f.name for f in inc_gallery],
        "quality_notes": scorecard_notes(p),
    }


def scorecard_notes(p):
    """Any FAIL a scorecard already recorded, attached to the filename it is about.

    Printed at the moment the scope is READ, which is the moment it is cheap.
    A frame that has already failed inspection should not reach the panel and
    find out afterwards that a round was spent on it.
    """
    notes = {}
    sc = p / "scorecards"
    if not sc.is_dir():
        return notes
    for f in sorted(sc.glob("*.md")):
        try:
            text = f.read_text(errors="ignore")
        except Exception:
            continue
        for line in text.splitlines():
            low = line.lower()
            if "fail" not in low:
                continue
            for name in [x.name for x in _imgs(p / "images")]:
                if name.lower() in low or Path(name).stem.lower() in low:
                    notes.setdefault(name, line.strip()[:160])
    return notes


def cmd_plan(product_dir):
    s = derive(product_dir)
    n = s["quality_notes"]

    def block(title, items, extra=""):
        print(f"\n{title}  ({len(items)})")
        if not items:
            print("   nothing on disk")
            return
        for i in items:
            flag = f"   <-- {n[i]}" if i in n else ""
            print(f"   {i}{flag}")
        if extra:
            print(f"   {extra}")

    print(f"SCOPE for {Path(s['product_dir']).name}")
    block("MAIN RACE owes", s["main"])
    block("  benchmark", s["incumbent_main"],
          "MISSING: a main race without the live image proves nothing" if not s["incumbent_main"] else "")
    block("GALLERY RACE owes", s["gallery"])
    block("  benchmark", s["incumbent_gallery"])
    if n:
        print("\nQUALITY FLAGS already on record. Do not spend a race on a known failure:")
        for k, v in n.items():
            print(f"   {k}: {v}")
    print("\nRaces this sitting owes: "
          + ", ".join(x for x in (["main"] if s["main"] else []) + (["gallery"] if s["gallery"] else []))
          + ".  A race you skip on purpose is fine; record it with `waive`.")


def _cov_path(product_dir):
    return Path(product_dir).resolve() / "tests" / COVERAGE


def _load_cov(product_dir):
    f = _cov_path(product_dir)
    if f.exists():
        try:
            return json.loads(f.read_text())
        except Exception:
            pass
    return {"races": {}, "waived": {}}


def _save_cov(product_dir, cov):
    f = _cov_path(product_dir)
    f.parent.mkdir(parents=True, exist_ok=True)
    f.write_text(json.dumps(cov, indent=1))
    return f


def cmd_record(product_dir, race_dir):
    """Fold ONE finished race into the coverage. Never replaces the other race."""
    rd = Path(race_dir).resolve()
    cfg_f, res_f = rd / "config.json", rd / "results.json"
    if not cfg_f.exists():
        print(f"no config.json in {rd}")
        return 1
    cfg = json.loads(cfg_f.read_text())
    tested = []
    for img in cfg.get("images", []):
        for path in (img.get("paths") or ([img["path"]] if img.get("path") else [])):
            tested.append(Path(path).name)

    rnd = cfg.get("round", 1)
    race = cfg.get("race") or ("gallery" if any(len(i.get("paths") or []) > 1 for i in cfg.get("images", []))
                               else "main")
    key = f"r{rnd}-{race}"                      # (round, race), never round alone

    cov = _load_cov(product_dir)                # LOAD then merge: accumulate, never reset
    cov["races"][key] = {
        "round": rnd, "race": race, "tested": sorted(set(tested)),
        "out_dir": str(rd), "completed": res_f.exists(),
        "at": time.strftime("%Y-%m-%d %H:%M"),
    }
    f = _save_cov(product_dir, cov)
    print(f"recorded {key}: {len(set(tested))} images. coverage now holds {', '.join(sorted(cov['races']))} -> {f}")
    return 0


def cmd_waive(product_dir, name, reason):
    if not reason.strip():
        print("a waiver needs a reason. That is the whole point of it.")
        return 1
    cov = _load_cov(product_dir)
    cov["waived"][name] = reason.strip()
    _save_cov(product_dir, cov)
    print(f"waived {name}: {reason.strip()}")
    return 0


def cmd_check(product_dir):
    """The gate. A deliberate skip stays possible; a silent one does not."""
    s = derive(product_dir)
    cov = _load_cov(product_dir)
    tested = set()
    for r in cov["races"].values():
        tested |= set(r.get("tested", []))       # UNION across every race
    owed = set(s["main"]) | set(s["gallery"])
    waived = set(cov["waived"])
    gap = sorted(owed - tested - waived)

    print(f"races recorded: {', '.join(sorted(cov['races'])) or 'none'}")
    print(f"approved on disk: {len(owed)} | tested: {len(owed & tested)} | waived: {len(owed & waived)}")
    for name in sorted(owed & waived):
        print(f"   waived  {name}: {cov['waived'][name]}")
    if gap:
        print("\nGATE: BLOCKED. Approved but neither tested nor waived:")
        for name in gap:
            note = s["quality_notes"].get(name)
            print(f"   {name}" + (f"   <-- {note}" if note else ""))
        print("\nTest them, or waive each with a reason:")
        print(f'   python3 scope.py waive "{product_dir}" {gap[0]} "why it is not being tested"')
        print("\nDeciding on a partial round is the wrong question to put to the owner.")
        return 1
    print("\nGATE: PASS. Everything approved was tested or waived with a reason.")
    return 0


def main():
    if len(sys.argv) < 3:
        print(__doc__)
        return 1
    cmd, pdir = sys.argv[1], sys.argv[2]
    if cmd == "plan":
        cmd_plan(pdir); return 0
    if cmd == "record":
        return cmd_record(pdir, sys.argv[3])
    if cmd == "waive":
        return cmd_waive(pdir, sys.argv[3], " ".join(sys.argv[4:]))
    if cmd == "check":
        return cmd_check(pdir)
    print(f"unknown command: {cmd}")
    return 1


if __name__ == "__main__":
    sys.exit(main())

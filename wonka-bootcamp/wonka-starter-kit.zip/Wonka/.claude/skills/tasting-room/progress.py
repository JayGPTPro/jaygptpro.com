"""Live progress view for long tasting runs.

Writes <out_dir>/progress.json plus a self-refreshing <out_dir>/live.html that
opens once in the browser: a phase list with checkmarks, a live bar, and a
"last heartbeat Ns ago" stall detector. Zero server, zero dependencies
(stdlib only), works on macOS, Windows, and Linux.

Why it exists: a full tasting runs for minutes with nothing but sparse console
lines. The live page answers "is it still going?" at a glance, and the stall
detector says plainly when a run died (sleep, dropped connection) so you know
to run the SAME command again and resume from the checkpoint.

Opt out with the environment variable PANEL_OPEN_LIVE=0 (the files are still
written; only the auto-open is skipped).
"""

import json
import os
import time
import webbrowser

_HTML = """<!doctype html>
<html><head><meta charset="utf-8"><meta http-equiv="refresh" content="2">
<title>{title} - live</title>
<style>
 body {{ font-family: -apple-system, 'Segoe UI', sans-serif; background:#0f1115; color:#e5e7eb;
        max-width:640px; margin:40px auto; padding:0 20px; }}
 h2 {{ font-size:18px; margin-bottom:2px; }} .sub {{ color:#94a3b8; font-size:13px; }}
 .bar {{ background:#1f2430; border-radius:8px; height:22px; margin:18px 0 6px; overflow:hidden; }}
 .fill {{ background:#22c55e; height:100%; width:{pct}%; transition:width .4s;
         display:flex; align-items:center; justify-content:flex-end;
         color:#052e12; font-size:12px; font-weight:700; padding-right:8px; }}
 ul {{ list-style:none; padding:0; margin:16px 0; }}
 li {{ padding:5px 0; font-size:14px; border-bottom:1px solid #1f2430; }}
 .done {{ color:#22c55e; }} .now {{ color:#e5e7eb; font-weight:600; }} .todo {{ color:#64748b; }}
 #hb {{ font-size:13px; color:#94a3b8; margin-top:14px; }}
 #stall {{ display:none; background:#7f1d1d; color:#fecaca; padding:10px 14px;
          border-radius:8px; margin-top:14px; font-size:14px; }}
</style></head><body>
 <h2>{title}</h2><div class="sub">{subtitle}</div>
 <div class="bar"><div class="fill">{pct}%</div></div>
 <div class="sub">{phase_line}</div>
 <ul>{phase_list}</ul>
 <div id="hb"></div><div id="stall">No heartbeat for over 2 minutes - the run looks STALLED.
 Check the terminal / rerun the same command (it resumes from the checkpoint).</div>
 <script>
  const ts = {ts};
  const age = Math.round(Date.now()/1000 - ts);
  const awaiting = {awaiting};
  const pending = {pending_js};
  let msg = 'last heartbeat ' + age + 's ago';
  if ({finished}) msg += ' - FINISHED';
  else if (awaiting) msg = 'engine complete ' + age + 's ago - ' + pending;
  document.getElementById('hb').textContent = msg;
  // A healthy render takes longer than the running-state threshold, so the
  // awaiting state gets its own window. Reusing 2 minutes would cry wolf on
  // every successful run.
  const limit = awaiting ? 600 : 120;
  if (!{finished} && age > limit) {{
    document.getElementById('stall').textContent = awaiting
      ? 'The final step has not reported for over 10 minutes. Re-run: python3 run.py <your config.json>'
      : 'No heartbeat for over 2 minutes - the run looks STALLED. Re-run the same command; it resumes from the checkpoint.';
    document.getElementById('stall').style.display = 'block';
  }}
 </script>
</body></html>"""


class Progress:
    def __init__(self, out_dir, title="tasting run", subtitle="", open_browser=None):
        self.dir = str(out_dir)
        self.title = title
        self.subtitle = subtitle
        self.phases = []          # [{name, done, total}]
        # THREE states, not two. "awaiting" is the gap between the engine
        # finishing and the last artifact existing; it is the state the page
        # used to render as FINISHED.
        self.finished = False
        self.awaiting = False
        self.pending = ""
        self._last_write = 0.0
        if open_browser is None:
            open_browser = os.environ.get("PANEL_OPEN_LIVE", "1") != "0"
        self._open_pending = open_browser

    # -- public API ------------------------------------------------
    def update(self, phase, done=None, total=None):
        """Upsert the named phase; a NEW phase marks all earlier ones complete."""
        for ph in self.phases:
            if ph["name"] == phase:
                ph["done"], ph["total"] = done, total
                break
        else:
            for ph in self.phases:                    # entering a new phase
                if ph["total"] and (ph["done"] or 0) < ph["total"]:
                    ph["done"] = ph["total"]
            self.phases.append({"name": phase, "done": done, "total": total})
        self._emit()

    def handoff(self, note, pending):
        """The engine is done but the RUN is not. Never claims completion.

        panel.py writes results.json and exits, and a second process then
        renders tasting-card.html, which is the file the owner is told to open.
        Calling done() at the end of the engine put FINISHED on the page while
        that file did not exist yet. So the engine hands off instead, and the
        process that produces the last artifact is the one that closes the run
        (see mark_finished below). Never leave the closing step to somebody
        remembering to call it.
        """
        self.awaiting = True
        self.pending = pending
        for ph in self.phases:
            if ph["total"]:
                ph["done"] = ph["total"]
        self.phases.append({"name": note, "done": None, "total": None})
        self._emit(force=True)

    def done(self, note="results ready"):
        self.finished = True
        self.awaiting = False
        for ph in self.phases:
            if ph["total"]:
                ph["done"] = ph["total"]
        self.phases.append({"name": note, "done": None, "total": None})
        self._emit(force=True)

    # -- internals -------------------------------------------------
    def _pct(self):
        if self.finished:
            return 100
        if self.awaiting:
            return 95          # never 100 until the last artifact exists
        counted = [p for p in self.phases if p["total"]]
        if not counted:
            return 0
        # every counted phase weighs equally; the phase list grows as the run
        # discovers work, so this is an honest "of what we know so far"
        per = 100 / max(len(counted), 1)
        return min(99, round(sum(per * min(1, (p["done"] or 0) / p["total"]) for p in counted)))

    def _emit(self, force=False):
        now = time.time()
        if not force and now - self._last_write < 1.5:   # throttle disk writes
            return
        self._last_write = now
        payload = {"title": self.title, "phases": self.phases, "pct": self._pct(),
                   "finished": self.finished, "awaiting": self.awaiting,
                   "pending": self.pending, "subtitle": self.subtitle,
                   "title_": self.title, "ts": int(now)}
        try:
            with open(os.path.join(self.dir, "progress.json"), "w") as f:
                json.dump(payload, f)
            self._write_html(payload)
        except Exception:
            pass                                          # progress must never kill the run
        if self._open_pending:
            self._open_pending = False
            try:
                webbrowser.open("file://" + os.path.abspath(os.path.join(self.dir, "live.html")))
            except Exception:
                pass

    def _write_html(self, p):
        items, current = [], None
        for i, ph in enumerate(p["phases"]):
            full = ph["total"] and (ph["done"] or 0) >= ph["total"]
            is_last = i == len(p["phases"]) - 1
            if ph["total"] and not full and not p["finished"]:
                cls, mark = "now", "*"
                current = f'{ph["name"]}: {ph["done"] or 0} / {ph["total"]}'
            elif full or p["finished"] or not is_last:
                cls, mark = "done", "OK"
            else:
                cls, mark = "now", "*"
                current = ph["name"]
            count = f' ... {ph["done"]}/{ph["total"]}' if ph["total"] else ""
            items.append(f'<li class="{cls}">[{mark}] {ph["name"]}{count}</li>')
        html = _HTML.format(title=self.title, subtitle=self.subtitle, pct=p["pct"],
                            phase_line=current or ("finished" if p["finished"] else "starting..."),
                            phase_list="".join(items), ts=p["ts"],
                            finished="true" if p["finished"] else "false",
                            awaiting="true" if p.get("awaiting") else "false",
                            pending_js=json.dumps(p.get("pending") or ""))
        with open(os.path.join(self.dir, "live.html"), "w") as f:
            f.write(html)


class NullProgress:
    """Drop-in no-op (tests / callers that opt out)."""
    def update(self, *a, **k): pass
    def done(self, *a, **k): pass


def mark_finished(out_dir, note="tasting card rendered"):
    """Close a run from ANOTHER process.

    The rule this exists to enforce: the process that produces the last
    artifact is the process that marks the run finished. tasting_card.py is a
    separate process from panel.py, so it calls this. Module level and
    importable precisely so the closing step is code, not a thing somebody has
    to remember.

    Idempotent: safe to call on a retry, and safe to call when no progress
    files exist (a run started before this existed, or with the live view off).
    """
    import os as _os
    pj = _os.path.join(str(out_dir), "progress.json")
    try:
        with open(pj) as f:
            p = json.load(f)
    except Exception:
        return False
    if p.get("finished"):
        return True                       # already closed; a retry changes nothing
    p["finished"] = True
    p["awaiting"] = False
    p["pending"] = ""
    p["pct"] = 100
    p["ts"] = int(time.time())
    p.setdefault("phases", []).append({"name": note, "done": None, "total": None})
    try:
        with open(pj, "w") as f:
            json.dump(p, f)
        pr = Progress(out_dir, title=p.get("title", "tasting run"),
                      subtitle=p.get("subtitle", ""), open_browser=False)
        pr.phases = p["phases"]
        pr.finished = True
        pr._write_html(p)
    except Exception:
        return False
    return True

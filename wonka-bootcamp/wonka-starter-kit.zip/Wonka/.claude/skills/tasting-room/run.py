#!/usr/bin/env python3
"""Runner for the Tasting Room. Works on macOS, Windows, and Linux.

Usage: python3 run.py <config.json> [lite]
  lite = a quick taste at roughly 1/5 the tasters (1/4 the per-image sample). Faster and coarser; good for
         eyeballing a set or testing the machine. Use the full tasting for
         anything that feeds a real decision.

What it does:
  1. Runs the panel engine (panel.py). On macOS it wraps the run in
     `caffeinate -i` so the laptop cannot fall asleep and kill it mid-way.
  2. Renders the Tasting Card (tasting-card.html) from results.json.

RESUMABLE: the expensive phases checkpoint to <out_dir>/.panel_ckpt.json as
they finish. If the run stops for any reason, run the SAME command again and
it continues from the last checkpoint instead of restarting.
"""

import json
import shutil
import subprocess
import sys
from pathlib import Path


def main():
    if len(sys.argv) < 2:
        print("usage: python3 run.py <config.json> [lite]")
        sys.exit(1)
    cfg_path = Path(sys.argv[1]).resolve()
    mode = sys.argv[2].lower() if len(sys.argv) > 2 else ""
    cfg = json.loads(cfg_path.read_text())
    out_dir = Path(cfg["out_dir"])
    here = Path(__file__).resolve().parent

    cmd = [sys.executable, "-u", str(here / "panel.py"), str(cfg_path)]
    if mode == "lite":
        cmd.append("lite")
    if sys.platform == "darwin" and shutil.which("caffeinate"):
        cmd = ["caffeinate", "-i"] + cmd  # keep the Mac awake for the whole run

    print(f"tasting: {cfg_path.name}{' [lite]' if mode == 'lite' else ''} (resumable; if it stops, run the same command again)", flush=True)
    rc = subprocess.call(cmd)
    if rc != 0:
        print("the tasting stopped before finishing. Run the SAME command again; it resumes from the checkpoint.")
        sys.exit(rc)

    subprocess.check_call([sys.executable, str(here / "tasting_card.py"), str(out_dir / "results.json")])
    print(f"done: {out_dir}/tasting-card.html (open it in a browser), tasting-card.md, results.json")


if __name__ == "__main__":
    main()

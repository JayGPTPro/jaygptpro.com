"""Regression tests for the two reporting rules the panel gets wrong by default.

Both assert on RENDERED output, not on source text, so a behaviour-preserving
refactor keeps passing and a behaviour-changing one fails. Every test here was
watched to fail against the pre-fix code before it was kept.

Run: python3 test_verdict.py
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from panel import MIN_INTENT_GAP, bootstrap_stability, intent_magnitude  # noqa: E402

FAILURES = []


def check(name, cond, detail=""):
    if cond:
        print(f"  PASS  {name}")
    else:
        print(f"  FAIL  {name}  {detail}")
        FAILURES.append(name)


def agg_of(win_votes, lose_votes, win_intent, lose_intent):
    return {
        "new": {"choice_votes": win_votes, "ssr_mean": win_intent, "label": "new"},
        "live": {"choice_votes": lose_votes, "ssr_mean": lose_intent, "label": "live"},
    }


print("\n1. A near-unanimous vote on a hair of intent is NOT a clear lead")
# The real shape of the problem: 76-4 on the vote, +0.06 of 5 on intent.
agg = agg_of(76, 4, 3.430, 3.367)
stab = bootstrap_stability([("new", 76), ("live", 4)])
gap, decisive, _, _ = intent_magnitude(agg, ["new", "live"])
check("bootstrap alone says clear", stab["tier"] == "clear", f'got {stab["tier"]}')
check("intent gap is tiny", gap == 0.063, f"got {gap}")
check("magnitude gate refuses it", not decisive, f"gap {gap} vs bar {MIN_INTENT_GAP}")

print("\n2. The same vote WITH a real intent gap stays top tier")
agg = agg_of(76, 4, 4.10, 3.36)
gap, decisive, _, _ = intent_magnitude(agg, ["new", "live"])
check("large gap is decisive", decisive, f"gap {gap}")

print("\n3. An unstable vote is never rescued by a big intent gap")
stab = bootstrap_stability([("new", 42), ("live", 38)])
agg = agg_of(42, 38, 4.50, 3.20)
gap, decisive, _, _ = intent_magnitude(agg, ["new", "live"])
check("bootstrap says not clear", stab["tier"] != "clear", f'got {stab["tier"]}')
check("gap is decisive on its own", decisive)
check(
    "direction is checked FIRST, so it cannot be promoted",
    stab["tier"] != "clear",
    "the downgrade must only ever lower a tier the bootstrap already earned",
)

print("\n4. Missing intent data does not silently downgrade")
agg = {"new": {"choice_votes": 76, "ssr_mean": None, "label": "n"},
       "live": {"choice_votes": 4, "ssr_mean": None, "label": "l"}}
gap, decisive, _, _ = intent_magnitude(agg, ["new", "live"])
check("gap is None, not 0", gap is None, f"got {gap}")

print("\n5. No percentage survives on the choice metric, in any rendered surface")
src_panel = Path(__file__).with_name("panel.py").read_text()
src_card = Path(__file__).with_name("tasting_card.py").read_text()
banned = [
    ("Choice share", "the markdown verdict table header"),
    ("delta_pts", "the round-over-round comparison"),
    ("winner_vs_incumbent_pts", "the vs-incumbent line"),
    ("racepct\">{o['share']}%", "the big number on the HTML race bar"),
]
for needle, where in banned:
    check(f"gone: {where}", needle not in src_panel and needle not in src_card, f'found "{needle}"')

print("\n6. The threshold is documented as provisional, with a refit trigger")
check("PROVISIONAL is written next to the constant", "PROVISIONAL" in src_panel)
check("the refit trigger is named", "Improvement Log" in src_panel)
check("standardising is explicitly ruled out", "Cohen" in src_panel)


# ---------------------------------------------------------------- item 4
print("\n7. The live page does not say FINISHED until the last artifact exists")
import json as _json, subprocess as _sp, tempfile as _tf  # noqa: E402
from progress import Progress, mark_finished  # noqa: E402

with _tf.TemporaryDirectory() as d:
    pr = Progress(d, title="t", open_browser=False)
    pr.update("reactions", 10, 10)
    pr.handoff("results written", "rendering the Tasting Card...")

    html = Path(d, "live.html").read_text()
    state = _json.loads(Path(d, "progress.json").read_text())
    check("handoff does not claim finished", state["finished"] is False)
    check("handoff sets awaiting", state["awaiting"] is True)
    check("bar is not 100", state["pct"] == 95, f'got {state["pct"]}')
    check("page renders the pending step", "rendering the Tasting Card" in html)
    check("awaiting gets its own stall window", "awaiting ? 600 : 120" in html)
    check("page does NOT say FINISHED yet", "const awaiting = true" in html and "{finished}" not in html)

    # closed by a DIFFERENT process, which is the whole point
    rc = _sp.run([sys.executable, "-c",
                  "import sys; sys.path.insert(0,%r);"
                  "from progress import mark_finished; print(mark_finished(%r))"
                  % (str(Path(__file__).resolve().parent), d)],
                 capture_output=True, text=True)
    check("a separate process can close the run", rc.stdout.strip() == "True", rc.stderr[-200:])
    state = _json.loads(Path(d, "progress.json").read_text())
    check("now finished", state["finished"] is True)
    check("now 100", state["pct"] == 100)

    check("idempotent on retry", mark_finished(d) is True)
    n_close = sum(1 for ph in _json.loads(Path(d, "progress.json").read_text())["phases"]
                  if ph["name"] == "tasting card rendered")
    check("a retry does not duplicate the closing phase", n_close == 1, f"got {n_close}")

with _tf.TemporaryDirectory() as d2:
    check("safe when no progress files exist", mark_finished(d2) is False)

# The checks above prove the Progress class behaves. They do NOT prove panel.py
# USES it correctly, and reverting panel.py to done() left them all green. So
# this one asserts the wiring. It is a source-level check and therefore weaker:
# it would false-fail on a rename. Kept anyway, because the alternative is no
# coverage of the actual regression, which is panel.py claiming completion.
print("\n8. panel.py hands off; it does not close the run itself")
src_panel_p = Path(__file__).with_name("panel.py").read_text()
check("panel.py calls handoff", "prog.handoff(" in src_panel_p)
check("panel.py never calls done", "prog.done(" not in src_panel_p)
src_card_p = Path(__file__).with_name("tasting_card.py").read_text()
check("the card process closes the run", "mark_finished(" in src_card_p)

print()
if FAILURES:
    print(f"{len(FAILURES)} FAILED: {', '.join(FAILURES)}")
    sys.exit(1)
print("all green")

---
name: reference-sheet
description: Build the Product Reference Sheet, the collage Genrupt generates from the owner's photos that locks front, side, back, detail, scale and material identity, revise it until the owner approves it, then prove the lock with a smoke test that generates ONE image per slot and reads it for two different failures: is this my product, and is this the brief I actually wanted. Use before any image batch, or when the user is ready to prepare their product photos for generation. Triggers: /reference-sheet, "lock the product", "reference photos", "product reference", "build the reference sheet", "smoke test", "the mold".
---

# The Reference Room

| Meta | Value |
|------|-------|
| Room | The Reference Room |
| Station | INVENT gate. No blast runs until the reference sheet is APPROVED and the smoke test has PASSED |
| Taught on | Day 4, lessons 1 and 3. Runs again whenever a new product enters the Factory |
| Needs | The product folder with `status.md`; the owner's own product photos in `2-reference/photos/` (all angles + one hand-for-scale + label close-ups), or an explicitly approved fallback; ONE working generation machine (Genrupt MCP, or the OpenAI key on the fallback path). For the smoke test specifically: the approved plan `/creative-brief` saved, because the smoke test renders the brief |
| Saves to | factory/Products/[product]/2-reference/ (reference-sheet.md, sheet-v[N].png, smoke-test-v[N]/; the owner's source photos stay in 2-reference/photos/, brand files in 2-reference/brand/) |
| Typical cost | Each reference-sheet version, plus one image per slot per smoke-test attempt. Cheap on purpose: the smoke test runs at `requestedCount: 1`, the lowest setting Genrupt exposes. **Report the cost, do not ask permission.** The owner approved the brief; that approval carries through to the reference and the smoke test. Say what each step cost, in one line, after it runs. |

## What this room does

A reference made from guesses produces images shaped like guesses. This room does two jobs, and the second one is the one everybody skips.

1. **Lock.** The owner's photos become a **Product Reference Sheet**: a single collage Genrupt generates, locking front, side, back, detail, scale and material identity in one image. It is not a document, it is a picture, and every image the factory makes afterwards is poured from it. It is generated, reviewed against real criteria, REVISED until it is right, and only then approved. The spec written in step 2 is what the sheet gets judged against and the raw material for the clean `product.description`. Reference sheet plus a clean description ARE the accuracy mechanism (intake guide, section 3). A "glass, not plastic" sentence in a brief is a backstop, never the lock.
2. **Prove.** The smoke test generates **ONE image per slot** off the approved plan, at the cheapest setting, and the owner reads the result for TWO different failures:
   - **Is this my product?** Wrong parts, wrong materials, wrong scale, invented decoration. A fidelity failure is a REFERENCE problem: the fix is a new sheet version, never a nicer prompt.
   - **Is this the brief I actually wanted?** Plenty of people cannot judge a brief until they see it rendered. "I do not want that frame at all" is a legitimate and valuable thing to discover here. A brief failure is a BRIEF problem: the fix is an edit to the plan, never a re-roll of the image.
   **What is NOT being judged here: fonts, colors, composition, polish.** Not because they do not matter, but because they are chosen later, from far more options, and judging them now makes people reject a good frame for a bad reason. Say this out loud before showing the images.

A reference can sit there marked approved and still produce the wrong product. **Approved is a status. Eyes on generated images are the evidence.**

A beautiful image of the wrong product is worth less than no image at all, and it is a returns problem and a compliance problem at the same time. This room is the only insurance against it, and every room downstream inherits whatever quality it gets here.

## Before you start

Check these in order. Any miss = station **BLOCKED**, named out loud, with a pointer.

1. **The product.** `factory/Products/[product]/` exists with its `status.md`. Missing: point to `/meet-my-product` and stop. If more than one product folder exists, ASK which product this run is for. Never guess from the newest folder, and never build a reference against a folder the user did not name. **The approved creative brief IS a precondition for the smoke test** (step 6), because the smoke test renders the plan rather than a generic prompt. Building and approving the reference sheet (steps 1 to 4c) does NOT need the brief and may run first.
2. **A machine for the smoke test.** Genrupt MCP connected (Path A, primary) or the OpenAI key present (Path B, fallback). If Genrupt was expected but is not answering, say so and offer the fallback explicitly; never switch paths silently. If NEITHER machine is available, the inventory and the spec can still be written, but the room ends PARKED (see "If the smoke test cannot run"). Never write LOCKED without a passed smoke test.
3. **The photos, asked for FIRST, every time.** The required set:

| Shot | Why it exists |
|---|---|
| Front | the face of the product, the angle every image starts from |
| Back | skip it and the model invents your back label, every time |
| Both sides (2 shots) | shape and depth, so the product is not rendered flat |
| Top down | lids, openings, tier counts, anything only visible from above |
| One hand-for-scale (a hand holding or beside the product) | scale is the single thing image models get most wrong. A dimension in inches does not fix it. A hand in the frame does |
| Label and texture close-ups | so label text and finish get copied instead of approximated |

Saved into `2-reference/photos/` inside the product folder (create the folder if it is missing). Phone photos in decent light are fine, **completeness beats beauty**: a blurry back shot that shows the real label outranks a pretty front shot that shows nothing new, because these photos go to Genrupt as `references.productImages`, where they preserve product identity. Box, pouch, and label-panel photos are collected too; they route to `references.packagingImages`. If `/meet-my-product` already collected photos into `2-reference/photos/`, inventory what is there instead of asking for them again.

**Two sources are never allowed in a reference:**
- **A competitor's photo.** It locks THEIR product, their angle, their lighting. Competitors belong in the teardown as the benchmark to match and beat, never in the reference.
- **Any AI-generated image, including one this Factory made.** A reference built from a generation locks that generation's mistakes and compounds them.

**"I don't have that" is a first class answer.** Every version of it has a defined path, and none of them is a dead end:

| The user says | What happens |
|---|---|
| "I have no photos of my own and cannot take any" | The fallback: the product's OWN listing gallery plus CUSTOMER REVIEW images. Only on explicit approval in plain words, after you name what gets weaker. A generic "continue" is not approval. Ask it straight: "shall I build the reference from the listing gallery and the review photos only, accepting weaker size and back-of-product accuracy?" On a yes, record `source: amazon_scraped` with the approval date, and say plainly that the smoke test now matters double |
| "I have some shots but not all of them" | Named gap waiver. Record each accepted gap and what the model is now free to invent because of it. Proceed |
| "I don't have Genrupt" | Path B, recorded as `gpt_image_fallback`. The lock is genuinely weaker and the written spec carries the weight. Say so rather than implying the lock is as strong |
| "I have neither machine right now" | Inventory and spec still get written. The room ends PARKED with the smoke test owed, and INVENT stays closed |
| "I have no product and no listing images at all" | There is nothing to lock, and pretending otherwise would be a fake artifact. Say so plainly and close the room. `/brand-kit` and `/creative-brief` can run meanwhile |

**On the fallback path, mine the customer review images.** A brand gallery is lit to sell and skips exactly the angles a reference needs most. A review photo is the product on a real counter, at its real size, from angles no brand ever shoots. On that path they are the best input in the folder. This is also how the bootcamp's on-camera demo runs, because that listing belongs to another seller and there is no unit in the room. Say that plainly whenever it comes up, and hold the owner to real photos of their own product.

## Process

1. **Inventory the sources.** List what is actually in `2-reference/photos/` against the required set, as a table, and name what each gap COSTS in the model's behavior, not just that it is missing ("no back shot, so the model will invent your back label"). Ask the user to fill the gaps or waive them by name. Then make provenance visible in the folder itself: rename source files so anyone can see where they came from (`own-front.jpg`, `gallery-01.jpg`, `review-photo-02.jpg`). Provenance that lives only inside a markdown file is provenance nobody checks. While inventorying, write the one-line NOTE each image will carry into Genrupt: what this image establishes ("back label, exact text", "hand for scale, true size", "matte finish close-up"). The note field is the one place a sentence of context belongs.

   **Packaging is on the required list, not the optional one, and it is asked for BY NAME** (`box-front`, `box-back`, `label-panel`). It is a separate bucket from the product photos and it unlocks a real hero strategy on Day 5. If the answer is "my product has no packaging a buyer ever sees", record that as a deliberate skip rather than a silent gap.

2. **Write the product spec.** This is what the smoke test gets judged against, so write it like a manufacturer, not like an art director:
   - Overall size and dimensions, and weight if known
   - **Every countable thing, counted** (tiers, lids, compartments, cables, pieces in the box)
   - Material and finish PER PART (a stainless steel base with plastic tiers is two materials, and saying so is the difference between premium and cheap on screen)
   - Every included part and accessory
   - Label text exactly as printed, and the brand name spelled as it is spelled
   - Colors, product and label
   - Power, voltage, plug type, where it applies

   **Every line carries its source**: seen in photo [file], stated by the owner, or read off the listing. **Never invent a spec value.** If something cannot be seen or confirmed, write `unknown` and say out loud that the model is now free to invent it. `unknown` is a legitimate spec value; a confident guess is a defect that ships.

   The spec does double duty: it is what the smoke test gets judged against, and it is the raw material for the clean `product.description` that goes to Genrupt in step 4. `unknown` values never enter the description; only confirmed facts do.

3. **Report the cost, do not ask for permission.** The owner approved the brief; that approval carries through this room. Say what is about to run and what it will cost in one line ("building the reference sheet, then one image per slot at the lowest setting, about [N] credits"), then run it, then say what it actually cost. **Never park the room waiting for a go-ahead on a cost the brief approval already covered.** The one exception is a THIRD failed smoke-test round: at that point stop, diagnose, and let the owner decide whether to keep spending (step 6).

4. **Build the reference sheet. Path A: Genrupt (primary).** This is the highest-leverage step in the whole factory. Never rush it and never accept the first draft out of politeness.
   - Upload every source photo through Genrupt's upload path (find the upload capability with `search_capabilities` and READ ITS INPUT SCHEMA before calling; the CLI bridge is the alternative, per `guides/mcp-setup-guide.md`). Wait for COMPLETED asset URLs. Local file paths are rejected; HTTPS asset URLs are the only currency here.
   - **Generate the sheet with `create_product_reference_sheet`.** It is a background operation: it returns an `operationId`, so poll with `wait_for_operation` or `get_operation_status` until the draft sheet is ready. Pass:
     - `sourceImageUrls` (or `sourceAssetIds` from a completed upload), up to 12. Completeness beats beauty: front, back, both sides, top, the hand-for-scale shot, label and texture close-ups.
     - `asin` and `productTitle` so the sheet ties to the product profile.
     - `scaleReferenceMode`. Default `auto`. **This is the structured version of "put a hand in it", so use it rather than hoping.** `handheld` or `hand_or_forearm` for anything held; `tabletop` or `sink_or_counter` for anything that sits somewhere; `none` only when the owner explicitly does not want a scale cue. Scale is the single thing image models get most wrong, and a dimension in inches does not fix it.
     - `packagingMode`. Default `exclude`, and it should almost always stay there. Use `include_separate_panel` ONLY when the owner explicitly wants packaging in the mold itself, and say the tradeoff out loud: anything in the sheet bleeds into everything poured from it. **Leaving it excluded does NOT throw the packaging away**, and say that out loud too, because it worries people. The packaging photos live in their own bucket and that is what drives the packaging main-image tactic on Day 5.
     - `notes` for product-specific corrections the photos do not settle (exact size, material per part, a detail that reads wrong).
   - **The sheet carries NO text.** No labels, captions, arrows, callouts or infographic graphics; it locks visual identity, nothing else. If a draft comes back with added text, that is a defect, not a feature.
   - Save every version to `2-reference/sheet-v[N].png`, N counting up. **Never overwrite a version.** Rejected sheets are evidence of what the notes fixed.

4a. **Judge the sheet against real criteria, out loud, before the owner sees it.** "Looks good" is how a bad mold gets approved. Run these five, name each pass or fail:

   | Check | Passes when | Fails when |
   |---|---|---|
   | Every angle present | front, back, both sides and top are all readable panels | an angle is missing. Whatever is not shown, the model will invent |
   | Scale cue | a hand, forearm or context object makes the true size obvious | no scale cue, or one so ambiguous it could be any size |
   | Every panel clear AND attractive | each panel is sharp, well lit, and the product looks like something worth buying | a blurred, dark or ugly panel. It does not just fail to help, it poisons every image poured from this mold |
   | Materials honest | each part reads as its real material: steel as metal, plastic as plastic, glass as translucent with reflections | premium reads cheap, cheap reads premium, or one material swallows the rest |
   | Nothing added, nothing invented | no text, no captions, no arrows, no badge or award graphic; the label reads correctly | the sheet has been decorated, or a part is missing or invented |

4b. **Revise until it is right. This loop is normal, not a failure.** A first draft that needs two rounds is the expected case.
   - Take the owner's notes in their own words and turn them into `editInstructions`, naming the defect in NOUNS ("the back panel is missing", "the tower reads as chrome, it is brushed steel") rather than in feelings ("it looks off").
   - Call `create_product_reference_sheet` again with `baseReferenceSheetId` set to the draft being fixed, the `editInstructions`, and any newly uploaded photos. **This edits the sheet. Do not start a fresh sheet from scratch to fix one panel.**
   - Save as the next `sheet-v[N].png`, re-run the five checks, and show old beside new so the owner sees what actually changed.
   - **If the same defect survives two revisions, the problem is upstream, not in the instructions.** Almost always a missing source angle. Ask for that photo instead of rewording the notes a third time.

4c. **Approve, and only on the owner's word.** `approve_product_reference_sheet` with the draft's `referenceAssetId`. This marks the sheet APPROVED and saves it as the latest approved reference on the product profile, which is what later generations inherit.
   - **The owner approves, not Wonka.** Silence, "ok" or "next" is not approval; ask again, naming the five checks. If the owner says any detail is wrong, do NOT approve: revise (4b) or ask for the missing photo.
   - Record the returned reference asset id in `reference-sheet.md` exactly as returned, with the version number of the sheet that was approved and the date. Never write an id a tool did not return.
   - Also route the individual source photos into the plan's `references.productImages` and `references.packagingImages` with the `note` from step 1, and write the clean `product.description` from the spec in step 2. **Then CONFIRM out loud that the packaging images actually landed in `packagingImages`** by reading the plan back, and if the product has real packaging, set `alwaysIncludePackaging` (the app's "Use actual packaging" toggle) to true. A packaging main-image tactic running against an empty packaging bucket produces an INVENTED box, and an invented box on a hero image is a returns problem wearing a design problem's clothes. The approved sheet is the identity lock; the source photos and the clean description are what carry the specifics.

5. **Build the reference. Path B: gpt-image fallback (no Genrupt).**
   - For each key angle, use gpt-image to clean the photo to a plain white background, square crop, even lighting, with NO change to the product itself: same label, same proportions, same cap, same materials. The prompt must say so explicitly.
   - Save as `2-reference/ref-front.png`, `2-reference/ref-back.png`, and so on. **The originals in `2-reference/photos/` are never edited, moved, or overwritten.**
   - On this path there is no true lock, so the written spec from step 2 carries the weight: the generation rooms prepend it to every call. Say plainly that fidelity is weaker here and that the Inspection Room will have to bite harder.

6. **SMOKE TEST. Mandatory, both paths, no exceptions. ONE image per slot, and it is read TWICE.**

   This is the first time the owner sees their brief as pictures. It is deliberately cheap and deliberately rough.

   - **Precondition: the approved plan from `/creative-brief` exists** (its `## Send log` records the save). The smoke test renders THAT plan; a smoke test made from a generic prompt tests nothing anyone is going to ship. If no plan is saved, say so and point at `/creative-brief`.
   - **Generate the whole set at the cheapest setting.** Genrupt path: the `generate_listing_builder_full_set_from_asin` capability (discover it with `search_capabilities`, call it through `execute_capability`) with:
     - `requestedCount: 1`. **One variant per slot. This is the cost lever and it is not optional here.** Genrupt exposes no "effort" or "quality" dial on listing images; the number of variants IS the dial.
     - `modelId: "gpt_image_2"`, explicitly, every call. The default is already OpenAI GPT Image 2, but an unstated model is a model that can change under you.
     - `planApproved: true`, which is lawful only because `save_listing_builder_plan_review` already saved the owner's approval on Day 3.
     - `aspectRatio: "1:1"`. Square is the default and the right one for listing images. A non-square run also requires `aspectRatioConfirmedByUser: true`, so never drift into one by accident.
     - `mobileFriendly` left at its default `true`. That is Genrupt's Visual Brand Language enhancer for typography, color and mobile readability, and it is on our side.
   - Save the whole round into `2-reference/smoke-test-v[N]/`, one folder per attempt, filenames matching the slot numbers. **Never overwrite an attempt.** Failed rounds are evidence.
   - **OPEN every file and look at it.** A returned URL, a success status, a filename or an `approved` flag is not a look. If the files cannot be opened and actually seen, the smoke test has NOT run and nothing may be written about it.

   **Then say this, before showing anything:** we are looking at two things only, whether it is the real product and whether this is the brief you wanted. **We are NOT looking at fonts, colors, composition or polish.** Those get chosen later from far more options, and judging them now makes people throw away a good frame for a bad reason.

   **READ ONE: is this my product?** Run the four-point check on EVERY frame, not just the best one.

   | Check | Passes when | Fails when |
   |---|---|---|
   | Parts and count | every part present, every countable thing counted right (a four tier fountain shows four tiers, a two lid pot shows two lids) | a part is missing, a part is invented, or the count is off by even one |
   | Materials | each part reads as its real material: steel as metal, plastic as plastic, glass as translucent glass with reflections | premium reads cheap or cheap reads premium; one material swallows the others |
   | Scale and proportions | reads as the size it really is, checked against the hand-for-scale shot (or against review photos on the fallback path) | a counter-top machine renders as catering equipment, or a large product renders as a travel size |
   | Nothing invented | no badge, seal, ribbon or award graphic that is not physically on the real product; the label is readable and spelled correctly | the model has decorated the product with things that would be a compliance problem on a live listing |

   **A fidelity failure is a REFERENCE problem.** Go back to 4b, revise the sheet, re-approve, and re-run the round. Never fix it by rewording a slot brief, and never accept "it is only in one frame": if the mold is loose it is loose everywhere, and the other frames were lucky.

   **READ TWO: is this the brief I actually wanted?** Walk the frames beside the brief's slot list, one line each: this slot's job, and whether the picture does that job. Ask the owner directly, in these words or close to them: *"now that you can see it, is there a frame here you do not actually want?"* Legitimate answers that are WINS, not problems:
   - "I do not want that frame at all" → drop the slot, and re-map its selling points in the coverage map.
   - "That is not the job I meant" → the buyer question or the content brief was ambiguous, so sharpen it.
   - "Two of these are saying the same thing" → the review questions missed an overlap. Merge them.

   **A brief failure is a BRIEF problem.** Route it to `/creative-brief`'s revision protocol: change only what was named, re-run the affected checks, re-save the plan, and record the reason in the owner's words. **Never fix a brief problem by re-rolling the image.** The next round of that slot would be a better picture of the wrong idea.

   - **PASS is the HUMAN'S word, never Wonka's**, and it means both reads passed. Ask for the call in plain words. Silence, "ok", "continue" or "looks good, next" is not a verdict; ask again, naming both reads.
   - Log every round with its number, which read failed, and what was changed as a result. The log is what proves a fix was a fix.
   - **After three failed rounds, STOP generating and diagnose out loud.** Repeated failures are one of three things: a missing source angle, a spec too vague to judge against, or the wrong path for this product. Name which one you believe it is, ask for the specific missing input, and let the owner decide whether to keep spending. One round is cheap. Six are not.
   - **NEVER proceed to a blast on a failed, parked or skipped smoke test.** One round is cheap. A hundred-image Draft Blast of the wrong product is not.
   - **Fallback path (no Genrupt):** generate one image per slot with gpt-image, prepending the spec from step 2 to every call, because there the spec IS the lock. Both reads still apply, and say plainly that fidelity is weaker so read one bites harder.

7. **Write `2-reference/reference-sheet.md` with full provenance, then update `status.md`.** Both files, every run, including runs that end parked or blocked.

## If the smoke test cannot run

Machines go down. This is the defined behavior, and it is neither a dead end nor a shortcut:

- Write everything that does not need a machine: the photo inventory, the waivers, the full product spec, and the source line.
- Write `Reference status: not locked (smoke test parked: [exact reason])` in `reference-sheet.md`. **Never LOCKED, never PASS, never a placeholder verdict.**
- Put the exact blocker in `status.md` under `Blocked on`, and leave INVENT closed. The generation rooms check for `LOCKED` plus `Smoke test: PASS` and will correctly refuse to run.
- Point the user at the work that costs nothing and needs no machine: the photo inventory, the spec, and the brand kit interview all run fine with the machine down.
- Say exactly what will resume the room: "when Genrupt answers again, say `run the smoke test` and we finish the round."

## When to re-lock

The reference is not permanent. Send the product back through this room when:

- The packaging, label, or physical form changes, including a new variant that is genuinely a different shape.
- `/inspect` fails product fidelity on more than one image in a batch. That is a reference problem wearing an image problem's clothes, and no amount of editing fixes it.
- A new product enters the Factory. **Every product gets its own Reference Sheet.** References are never shared between products, not even between siblings in the same brand.

## Output format

`factory/Products/[product]/2-reference/reference-sheet.md`:

```markdown
# Reference Sheet . [Product Name]
Built: [YYYY-MM-DD]
Built from: [N] source images in 2-reference/photos/, owner input on [date]
source: manual_photos | amazon_scraped (listing gallery + customer review images, explicitly approved by [name] on [date])

## Photo inventory
| Required shot | Present | File | What this image establishes (its Genrupt note) | If missing, what the model is free to invent |
|---|---|---|---|---|
| Front | yes | photos/own-front.jpg | front face, label text exact | . |
| Back | MISSING (gap waived by owner [date]) | | | the entire back panel and its label |
| Left side | yes | photos/gallery-03.jpg | left profile, spout shape | . |
| Right side | yes | photos/gallery-04.jpg | right profile | . |
| Top down | yes | photos/review-photo-02.jpg | lid opening, tier count from above | . |
| Hand-for-scale | MISSING (no unit in hand) | | | true size; judged against review photos instead |
| Label / texture close-up | yes | photos/own-label.jpg | matte finish, label typography | . |

## Product spec
| Field | Value | Source |
|---|---|---|
| Size / dimensions | [exact, or unknown] | [photo file / owner / listing] |
| Weight | [value or unknown] | [source] |
| Countable parts | [e.g. 4 tiers, 1 auger, 1 base] | [source] |
| Materials and finish, per part | [part: material, finish] | [source] |
| Included parts and accessories | [everything in the box that can appear in an image] | [source] |
| Label text | [exactly as printed] | [source] |
| Colors | [product + label] | [source] |
| Power / voltage | [value, or n/a] | [source] |

Anything marked `unknown` is something the model is free to invent. That is the risk this line records.

## Genrupt intake routing (Path A)
| File | Bucket | Asset URL (exactly as returned) | Note sent with it |
|---|---|---|---|
| photos/own-front.jpg | productImages | https://... | front face, label text exact |
| photos/review-photo-02.jpg | productImages | https://... | top down, lid opening |
| photos/box-front.jpg | packagingImages | https://... | retail box, front panel |

Clean product.description sent in projectSetup (confirmed facts only, no `unknown` values, no constraint prose):
> [the spec rewritten as one clean factual description]

## Reference lock
- Path: genrupt | gpt_image_fallback
- Lock mechanism: references.productImages + packagingImages + clean product.description per the routing above (Path A), or cleaned refs: [file list] + spec prepended to every call (Path B)
- Routing recorded: [YYYY-MM-DD]. A recorded payload is a status, not proof. The smoke test below is the proof.

## Reference sheet versions
| Version | File | Approved | What the notes fixed |
|---|---|---|---|
| v1 | sheet-v1.png | no | back panel missing, tower read as chrome |
| v2 | sheet-v2.png | YES [YYYY-MM-DD] | back added from new photo, brushed steel corrected |

- scaleReferenceMode used: [auto / handheld / hand_or_forearm / tabletop / none] . why: [one line]
- packagingMode used: [exclude / include_separate_panel] . why: [one line]
- Approved reference asset id: [exactly as `approve_product_reference_sheet` returned]
- Five-point check on the approved sheet: every angle [ok], scale cue [ok], every panel clear and attractive [ok], materials honest [ok], nothing added [ok]

## Smoke test (mandatory, one image per slot)
Rendered from the plan `/creative-brief` saved on [date]. Settings: requestedCount 1, gpt_image_2, 1:1, mobileFriendly default.

| Round | Folder | Slots rendered | Cost | Read 1 (my product?) | Read 2 (my brief?) | What changed as a result |
|---|---|---|---|---|---|---|
| 1 | smoke-test-v1/ | 7 | [actual] | FAIL: three tiers, tower read as chrome | not judged, read 1 failed first | new sheet version v2 |
| 2 | smoke-test-v2/ | 7 | [actual] | PASS | FAIL: slot 5 is not a frame I want | slot 5 dropped, SP re-mapped in the brief |
| 3 | smoke-test-v3/ | 6 | [actual] | PASS | PASS | . |

- Read by: [user name], with Wonka reading first
- NOT judged at this stage, on purpose: fonts, colors, composition, polish
- Smoke test: PASS
- Reference status: LOCKED [YYYY-MM-DD]

## Notes
[waived gaps, fallback warnings, what the generation rooms should watch hardest, anything that would explain a future fidelity miss]
```

Three lines are read mechanically by other rooms and must be written literally, exactly as spelled here: `source:`, `Smoke test: PASS` (or `FAIL: [reason]`), and `Reference status: LOCKED [date]`. Until a PASS, the status line reads `not locked` with the reason in brackets. Do not reword them, do not decorate them, do not write them early.

## Golden Standards check

Before presenting, verify:
- [ ] The user's own photos were requested FIRST, before any fallback was mentioned. The fallback ran only on explicit, named approval, recorded as `source: amazon_scraped` with a date.
- [ ] No competitor image and no AI-generated image is in the reference set.
- [ ] The spec is complete and SOURCED, with `unknown` written where a value could not be confirmed. Nothing was invented to fill a field.
- [ ] Cost was REPORTED, not asked permission for, and the actual cost was said out loud after each round. The room never parked waiting on a go-ahead the brief approval already covered.
- [ ] The reference exists on the chosen path: every photo uploaded and routed to its bucket (`productImages` / `packagingImages`) with its note, asset URLs recorded exactly as returned, plus the clean `product.description` (Path A), or cleaned reference files plus the spec (Path B). No URL was written from memory.
- [ ] Accuracy is enforced by the reference images and the clean description, not by constraint prose planned for briefs or custom instructions.
- [ ] The reference sheet was judged against the five-point check BEFORE the owner saw it, revised via `baseReferenceSheetId` + `editInstructions` rather than rebuilt from scratch, and approved only on the owner's word. Every version is on disk as `sheet-v[N].png`; nothing was overwritten.
- [ ] `scaleReferenceMode` was CHOSEN and its reason recorded, never left to luck. `packagingMode` stayed `exclude` unless the owner asked otherwise and heard the bleed-through tradeoff.
- [ ] The smoke test rendered the SAVED PLAN, one image per slot, at `requestedCount: 1` with `modelId: "gpt_image_2"`, `aspectRatio: "1:1"` and `planApproved: true`.
- [ ] EVERY frame was opened and looked at, and BOTH reads were run: read one (my product?) on all four points, read two (my brief?) slot by slot.
- [ ] The owner was told out loud, before seeing the images, that fonts, colors, composition and polish are NOT being judged at this stage.
- [ ] A fidelity failure routed to a new sheet version. A brief failure routed to `/creative-brief`. Neither was ever fixed by re-rolling an image.
- [ ] The PASS came from the human in words and covers BOTH reads. Wonka never wrote PASS on his own judgment.
- [ ] Every round is on disk in `2-reference/smoke-test-v[N]/` and logged with which read failed and what changed. Nothing was overwritten. Originals in `photos/` untouched.
- [ ] `2-reference/reference-sheet.md` and `status.md` were both written, including on a parked or blocked run.
- [ ] No blast ran here. Draft Blast and Theme Blast belong to the generation rooms, after this room passes.

## Wonka lines

Openers:
- "The Reference Room. Get this wrong and every candy downstream comes out the wrong shape."
- "Real photos, please. Molds made from guesses produce candy shaped like guesses."
- "Ah, the product itself. Let us introduce it to the machines properly, before they introduce themselves to it."

During:
- "The back, please. Whatever you do not show me, the machines will happily invent."
- "A hand in the frame. Inches are an argument, a hand is a fact."
- "Empty, please. No chocolate, no pour, no garnish. We are testing the machine, not the promise."

Closers:
- "One of each, cheap and rough, before we spend properly. I have burned enough sugar to know."
- "Two questions and two only: is that your product, and is that the picture you asked for. Fonts and colours can wait; you will have a hundred of those."
- "The reference is locked and the smoke test passed. The machines can no longer hallucinate your product."
- "Your product, faithfully cast. Batch production is now a safe activity."
- "It came back wrong, which is exactly what it is for. Name the defect and we run one more."

## Definition of Done

Done means all of these are true on disk, and it is checkable in ten seconds:

- `2-reference/reference-sheet.md` exists with a sourced photo inventory, a sourced product spec, the Genrupt intake routing, and a `source:` line.
- The reference is locked on a named path: asset URLs routed into `productImages` / `packagingImages` with notes plus a clean `product.description` (Path A), or cleaned reference files (Path B).
- An APPROVED product reference sheet exists: its version file on disk, its returned reference asset id recorded, and the owner's approval dated.
- At least one smoke-test round exists as a folder of per-slot images in `2-reference/`, and every frame in the passing round was opened and viewed.
- `reference-sheet.md` carries `Smoke test: PASS` and `Reference status: LOCKED [date]`, the PASS came from the human, and it covers both reads.
- `status.md` records it.

**Not done, and honestly recorded as such:**
- Reference built, smoke test not yet run or parked: `Reference status: not locked ([reason])`. The artifact exists, INVENT stays closed, and the user knows exactly what resumes it.
- Smoke test failed: attempts logged with defects, status `not locked`.

A Reference Sheet without a passed smoke test is NOT done, however good the sheet looks and however confident the tool sounds.

## Update status.md

- Set the INVENT station row to `in progress` if it is still `pending` (the reference is INVENT's preparation, not a station of its own), with artifact `2-reference/reference-sheet.md`.
- On a PASS, add the Log line: `[date] Reference locked (source: [manual_photos/amazon_scraped], path: [genrupt/gpt_image_fallback]), smoke test PASS on attempt [N].`
- Not passed, add instead: `[date] Reference built, smoke test [pending/parked: reason/failed on attempt N]. INVENT blocked on the smoke test.` and put the exact blocker in the `Blocked on` list.
- Record every waiver (gaps accepted, fallback source approved, no-Genrupt path) in the Notes of `reference-sheet.md` and in `status.md`, so a future session knows what this reference was built on without re-reading every file.

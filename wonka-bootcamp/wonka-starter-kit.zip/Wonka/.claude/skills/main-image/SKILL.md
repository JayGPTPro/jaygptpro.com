---
name: main-image
description: Run the MAIN image generation for the hero slot. The main image is briefed in the creative brief but CHOSEN here. The three main-image controls (tactic, hang-tag text, packaging preference) are decided in the brief and confirmed with the owner, Genrupt generates many main candidates, and this room collects every candidate into images/ and supports the human pick against the brief's selection criteria. Slot 1 is protected and round-trips unchanged in every plan save. A gpt-image fallback, used only when Genrupt is down, may still author mains from the brief. Product only, no people, no overlay text, cost reported rather than gated. Also produces the Round 2 challenger and any regeneration a scorecard or a tasting note orders. Use when the brief, the locked reference, and the brand kit are done and the user wants the hero image. Triggers: /main-image, "make the main image", "hero image", "generate the mains", "main image room", "round 2 challenger", "regenerate main-02".
---

# The Main Image Room

| Meta | Value |
|------|-------|
| Room | The Main Image Room |
| Station | INVENT (the main image is one of the four Invent sub-parts) |
| Taught | Day 5. Reused on Day 8 for any regeneration the tasting notes order |
| Needs | brief/creative-brief.md (the MAIN section with the three main-image decisions answered and the selection criteria), 2-reference/reference-sheet.md (LOCKED, smoke test PASS), factory/Brand/brand-kit.md (branding preset + styleImage, built by /brand-kit), one working generation machine |
| Saves to | factory/Products/[product]/images/ (main-01.png .. main-NN.png) + images/batch-log.md |
| Typical cost | Genrupt: a few credits per candidate, read off the live balance. Fallback: gpt-image API per call. **Reported, not gated:** the brief approval authorises the run. A 100-credit Draft Blast is the one exception that gets named before it runs. |

## The contract this room lives under

**The main image is briefed in the brief, but chosen here.** `/creative-brief` writes a real main-image brief: what the shot must show and prove. That brief is the standard the human picks against in step 8 and the prompt source for the fallback path, and it is never sent to Genrupt. On the Genrupt path our side owns a small set of structured controls, and nothing else touches slot 1:

1. **Which tactics are enabled.** `enabledMainImageTactics` is an ARRAY, not a single choice, and there are FOUR values: `hang_tag` (a physical tag attached to the product), `human_contact` (avatar interaction, a person's hands or presence), `packaging_expansion` (the real retail box in frame), and `genrupt_choice` (the planner decides). **Enabling several is the normal case**, because a hundred drafts spread across four strategies is worth far more than a hundred drafts of one. A fresh plan arrives with all four enabled.
2. **The vanilla control is NOT a fifth value in that array** (confirmed by Genrupt, 27 July 2026). Vanilla means every tactic off, requested as `enabledMainImageTactics: []`, so it cannot ride along inside a run that has any tactic enabled. **It is a SECOND, separate job**, small and cheap, run right after the blast. Never report the main image as done without it: it is the compliant swap-in the whole risk doctrine depends on, and a plan that promises it "inside the same run" is wrong.
3. **Mix and match.** Whether one image may COMBINE two tactics. Turning it off does **not** collapse the run onto one tactic: images still distribute across every enabled tactic either way. It only stops two tactics appearing in a single image.
4. **Hang-tag text.** The exact words on the tag, **28 characters maximum**. Leave it empty and Genrupt writes one from the buyer signal, which is a legitimate choice but a silent one. **If the brief decided a hang-tag phrase, that phrase goes in this field**; a brief that specified the words and a run that auto-generated them is a quiet, expensive disconnect.
5. **Use actual packaging.** `alwaysIncludePackaging`. **Turn it ON whenever the product has real packaging photos in the bucket.** With it off, a packaging tactic has to invent a box, and an invented box on a hero image is a returns problem wearing a design problem's clothes.

These are decided in the creative brief and CONFIRMED with the owner before generation. **Never enable a tactic the owner has not answered for, and never silently drop one they wanted.** An unanswered control is a stop, not a default.

**Removing a tactic is a first-class answer.** "My product has nothing to do with packaging" or "no people anywhere near my hero" are common and correct, and the fix is to drop that value from the array rather than to generate images nobody wants. Say which tactics are in and which are out, and why, before anything runs.

**Slot 1 is protected.** In every `save_listing_builder_plan_review`, slot 1 round-trips byte-for-byte unchanged: no contentBrief, no headerPhrases, no customInstructions, no slot referenceImages, ever. The hero is shaped only by the three controls, the locked reference, and the branding preset. Rules pasted as prose into the slot stop behaving like rules and start competing with Genrupt's own direction, and the big prohibitions are enforced system-side anyway.

Genrupt generates MANY main candidates from those controls. This room's job is to run that generation, collect ALL the candidates into `images/`, and then support the HUMAN choice against the selection criteria the brief wrote down. The human picks. This room never does.

## What this room does

The Main Image Room produces the single most important asset on the listing: the hero shot the shopper sees in search results, at the size of a postage stamp, in a row of competitors, for well under a second. It confirms the three main-image decisions from the brief with the owner, runs Genrupt's main-candidate generation, collects every candidate that comes off the machine, and lays them out beside the brief's selection criteria so the human can choose with clear eyes. Scope of THIS room is the MAIN image only. Secondary images, A+ modules, and variation imagery are generated in their own rooms (`/secondary-images`, `/aplus`, `/variations`). Nothing that comes out of this room is a winner; the shortlist the human picks goes to the Inspection Room next.

## What this room never does

- Never writes a brief, header phrase, custom instruction, or slot reference onto slot 1. The main is edited only through tactic, hang-tag text, and packaging preference.
- Never picks a tactic, hang-tag text, or packaging preference the owner has not answered for. Silence is not a default.
- Never picks the winner, scores, or ranks. The human picks; `/inspect` gates.
- Never edits an existing image. Removals, word swaps, and shortenings are `/fix`.
- Never invents a product fact. Every attribute comes from the Reference Sheet and the brief.
- Reports every spend in one line before and after, and never uses cost as a gate on work the approved brief already authorised. The exception: a Draft Blast is 100 credits flat for ONE slot, so that one gets named out loud first.
- Never presents output as final, approved, ready, or "the best one".
- Never drops a candidate silently. Every candidate Genrupt produces is collected, logged, and shown.

## Before you start

Check ALL FOUR preconditions. Open the files; do not take `status.md`'s word for them. Any miss = station **BLOCKED**, with the exact ask and a pointer.

1. `brief/creative-brief.md` exists and its MAIN section carries the three main-image decisions (tactic, hang-tag text, packaging preference) and the selection criteria the human choice will be judged against. Missing section: point to `/creative-brief`. Section present but a decision unanswered: the room does not guess, see the table below.
2. `2-reference/reference-sheet.md` exists and reads `Reference status: LOCKED` and `Smoke test: PASS`. An approved reference WITHOUT a passed smoke test does not count; the smoke test is the only proof the lock actually holds. Missing or unpassed: point to `/reference-sheet`.
3. `factory/Brand/brand-kit.md` exists, with the branding preset id and the styleImage that `/brand-kit` built. Style comes ONLY from there; this room never describes style, colors, or fonts in prose. Missing: point to `/brand-kit`.
4. A generation machine is alive: Genrupt MCP connected (Path A, primary) or an OpenAI key for the fallback (Path B). Never switch paths silently, and never assume a machine is alive because it was alive on the last run.

**"I don't have it" is a real answer, and most of the time the run proceeds.** What blocks is missing EVIDENCE and missing DECISIONS, never missing convenience.

| The owner says | What happens |
|---|---|
| "No Genrupt" | Path B fallback, with the weaker-fidelity warning said out loud, one concept generated and viewed before the rest. The run proceeds. |
| "No Genrupt and no OpenAI key" | Both machines down: the room is CLOSED. Say exactly what is missing, point to `guides/mcp-setup-guide.md`, record `blocked: no generation machine` in `status.md`, and stop. Never fake, never "describe" images instead. |
| The brief has no answered tactics | STOP. Present the five in the owner's language: a hang tag on the product, a person interacting with it, the real retail box in frame, let the planner decide, or a plain control shot. Ask which are IN and which are OUT, and why. Never pick, never default, never infer from enthusiasm. Record the answer back into the brief. |
| "No hang tag" / "no packaging" / "no people near my hero" | All fine, and all common. Drop that value from the enabled tactics array, record WHY in one line, and proceed. A dropped tactic is a decision; a forgotten one is a defect. |
| "Just pick one image for me" | Refused, gently. Ask for one to five. The Tasting Room needs candidates to race, and the A/B doctrine wants challengers queued rather than a single favourite that never gets tested. |
| "I can't afford the full batch" | Run the smallest batch the tactic supports and name the trim in the batch log as a conscious cut. A named cut is fine; a silent one is not. |
| "Skip the smoke test, just go" | Refused. The lock and its smoke test are evidence, not paperwork, and skipping them is what turns one wrong reference into a whole wrong batch. Back to `/reference-sheet`. |
| No answer on the cost line | Nothing runs. Park the station as `in progress`, say what is waiting, and stop. |

## Process

1. **Read the MAIN section and confirm every control, out loud, one line each.** From the brief: which tactics are enabled and which were deliberately dropped, mix and match on or off, the hang-tag text (or "auto"), and whether actual packaging is in play. If any is missing or marked open, stop and ask (see the table). Two checks that cost seconds and save a run:
   - **The hang-tag text actually reaches the field.** If the brief decided a phrase, it goes in `hangTagText`, within 28 characters. If it does not fit, shorten it WITH the owner rather than truncating it silently. If the brief said "none", leave the field empty and say out loud that Genrupt will write one from the buyer signal, so nobody is surprised by words they did not choose.
   - **Packaging is real before a packaging tactic runs.** If `packaging_expansion` is enabled, confirm the packaging bucket actually has images in it and that `alwaysIncludePackaging` is on. Enabled tactic plus empty bucket equals an invented box.

   The brief also carries the SELECTION CRITERIA: what a winning main must do for THIS product, the mechanism that beats the incumbent. Read those back too; they are the instrument for the pick, and reading them BEFORE the images exist is what stops the pick becoming a beauty contest.

2. **The main-image laws. Non-negotiable, every product, every candidate.** These laws now serve two jobs: they are the FILTER every collected candidate is checked against before the human sees it (step 10), and they are the AUTHORING rules on the fallback path (step 6). On the Genrupt path they are never pasted into the slot as prose; the big prohibitions are enforced system-side, and a violation that comes off the machine anyway is a bug to report and a candidate to pull, not something to argue with in a brief.
   - **PRODUCT ONLY.** No people, no faces, no hands, no product-in-use. The hero shot is the product. Full stop.
   - **NO overlay text or graphics.** No headlines, callouts, arrows, or floating seals. The ONLY marks allowed are what physically exists on the product, its label or box, and the hang-tag the owner approved. Best Seller flags, star ratings, review counts, and award graphics are never allowed: Amazon draws its own on the search tile, and a drawn one is a fake badge.
   - **The product is the real product.** Real material, true proportions, and every part present and countable (a four tier machine shows all four tiers, steel reads as metal and not plastic), matching the locked reference exactly.
   - **Never promise what the product cannot deliver as sold.** This is the most expensive mistake in this room: an over-promising hero wins the click and buys the one-star review. If the research names a gap between what the category's pictures suggest and what buyers report actually happens, the winning candidate must show the buyer's reality, not the fantasy.
   - **No new product facts.** If an attribute is not in the Reference Sheet or the brief, it does not exist and must not be depicted.

3. **Report the cost against the live balance, then run.** Read the balance first (a free read, the same fuel gauge `/machines-check` uses) so the number is real; if the connection does not expose a gauge, say "balance not available on this connection" rather than guessing. One line before: "Main candidates on [path], tactic [name], about [credits/dollars], balance [X]." One line after: what it actually cost. **This is a report, not a gate.** The owner approved the brief and this room executes it; stopping for permission on every batch only delays work they already said yes to.
   Three things still stop and get named FIRST, because they are decisions and not execution: a **Draft Blast** (100 credits flat for a single slot), a **retry or Round 2 that re-spends on a slot which already produced candidates**, and a **balance that will not cover the run** (say the exact shortfall, then stop, because a half-spent batch is worse than an unspent one).

4. **Generate. Path A: Genrupt (primary).** **The plan already exists.** `/creative-brief` saved it when the owner approved the brief, with the main-image controls answered at setup time (its `## Send log` records the date and the cast). Open that plan, confirm the controls read back as the owner answered them, and generate. Never plan from the ASIN again and never re-plan: that wipes the whole approved gallery to make one hero.
   - **The hero runs as a Draft Blast: about 100 drafts for this one slot, 100 credits flat.** That is the point rather than an extravagance. **The best five of a hundred beat the best five of ten**, and the main image is the one asset where that difference compounds into rank, reviews and everything downstream.
   - **Confirm the spread before it runs.** With several tactics enabled, those hundred drafts should cover all of them, **whether mix and match is on or off**: the setting only governs whether two tactics may share one image, never whether the run distributes. Say what you expect ("four tactics, so roughly twenty-five each") and check it against what actually comes back in step 5. A hundred near-identical drafts of one tactic is a failed run wearing a successful one's clothes, and it is worth catching immediately.
   - `modelId: "gpt_image_2"` explicitly on every call. `aspectRatio: "1:1"` unless the owner explicitly confirmed otherwise. `planApproved: true`, lawful only because the owner's approval was already saved.
   - **Edit the existing plan; never re-plan.** Fix through the plan-review and save path only.

5. **Do NOT drag a hundred drafts onto the disk. Verify the spread, then hand the picking to the app.** A Draft Blast produces about a hundred images and they live in Genrupt, where there is a proper grid and a Compare view. Dumping all hundred into `images/` helps nobody and buries the ones that matter.
   - Read the blast back (`get_listing_builder_blast_images`) and report the SPREAD in one line: how many drafts per enabled tactic. This is the check promised in step 4. If the spread is lopsided or single-tactic, say so plainly and stop before the owner wastes an hour picking from a failed run. Mix and match being off is **not** an explanation for a lopsided spread.
   - **Then run the vanilla control, as its own job, before the owner starts picking.** A second small generation with `enabledMainImageTactics: []` and `requestedCount: 1`, same locked reference, same preset. It cannot be part of the blast (see control 2 above). Report it in the same line as the spread so the owner sees it landed. **Do not offer to skip it because the hundred look good**: it is the compliant swap-in that makes the ToS advice in Day 5 lesson 1 safe, and its whole value is existing before it is needed.
   - Then point the owner at the app and say what to do there: work through the grid, use **Compare** when torn between two, and **select between one and five**. Not one. The Tasting Room needs candidates to race, and the A/B doctrine wants a queue of tested challengers ready rather than a single favourite.
   - **The owner selects in the app. Nothing needs to be copied back to you.** The selection state is readable, so when they say they are done, that is the whole handoff.

6. **Generate. Path B: gpt-image fallback. FALLBACK-ONLY BEHAVIOR.** This path exists for one situation: Genrupt is down or absent and the owner said proceed. On this path, and ONLY on this path, the room still AUTHORS mains from the brief, because there is no Genrupt planner to choose for us. This is the old way kept alive as a spare tire, and it is announced as such. Per concept:
   - Confirm the key: if `$OPENAI_API_KEY` is not set, load it from the `.env` in the Factory root before the first call. No key at all means the room is closed (see the table above).
   - Author one concept per distinct strategy in the brief's MAIN section, in the brief's order (concept 1 becomes the next free `main-NN`).
   - Attach the Reference Sheet's cleaned reference images from `2-reference/photos/` to the call.
   - Use the concept direction as the prompt, prepending the product spec from `2-reference/reference-sheet.md` (exact size, material, parts and their count, label text) so the model cannot drift. All the laws of step 2 are authoring rules here.
   - Say the honest warning up front: product fidelity holds less tightly here than on the locked path, so drift is likelier and inspection matters double.
   - Generate ONE concept first, VIEW it, and only continue if the product renders faithfully. If it does not, stop and tighten the reference rather than burning the batch.

7. **Save to `images/` under one flat naming contract.** Never overwrite, never delete, never renumber.
   - New candidates: `main-01.png` .. `main-NN.png`, numbered in the order they come off the machine (Genrupt path) or in the brief's strategy order (fallback path). Every later room and every later day refers to these images by filename, so the numbering is a promise: never renumber after the fact.
   - A REGENERATION of an existing candidate keeps its number and gains a suffix: `main-02-v2.png`, saved beside an untouched `main-02.png`. Keeping the number keeps candidate ids stable, which is what lets a round-over-round tasting comparison line up.
   - A NEW candidate that is not a re-bake of an existing one (a challenger built from a tasting objection) takes the NEXT FREE number in the same sequence: `main-09.png`. There is no separate series.
   - Surgical edits are `/fix`'s work and land as complete set snapshots in `edits/vN/` (same filenames, the round in the folder name), never in `images/` and never by this room.

8. **Support the human choice, then read the selection back and bring it home.** This is the second half of the room's job and it is service, not judgment.
   - **Before they pick**, give them the instrument: the brief's SELECTION CRITERIA restated as a short list, the incumbent read (what the current live main does and fails to do), and the reminder that a shopper sees these at postage-stamp size in a row of rivals. Offer to show any candidate downscaled to thumbnail size on request. A criteria list read before the grid is judgment; the same list read after is a rationalisation.
   - **While they pick**, stay out of the way. The app's grid and Compare view are better at this than anything said in a chat window, and the human is better at "which would I click" than any scorer.
   - **When they say they are done, read the selection state back BEFORE downloading anything.** Name what you found selected, count included: "four selected, here they are." That two-second read-back catches a stray click, a selection left over from an earlier round, and the case where nothing actually saved. Never assume a selection took, exactly as with a plan save.
   - **Then bring them home.** Download the selected candidates into `images/` under the naming contract in step 7, mark the slot completion, and update `status.md`. This step is not optional and it is easy to forget: `/inspect`, `/fix` and the Tasting Room all read the local folder, so a selection that stays in Genrupt is a Day 6 that opens on an empty directory.
   - **Never pick, score, or rank on the owner's behalf**, and never quietly drop a selected candidate because you disagree with it.

9. **Handle failures out loud, and reconcile the count.** Every planned candidate ends in exactly one of three states: **generated**, **failed** (record the exact error), or **skipped** (record the reason, e.g. the owner's approved trim from the cost table). State the arithmetic before handing off: planned N = generated M + failed K + skipped S. If the numbers do not add up, the batch is not done. On a mid-batch tool error, retry once; generation resumes from saved slots, so what already landed is not paid for twice. If the machine is down for good, keep what landed, record the failure, and offer the fallback for the rest with its own cost line. A quietly shorter batch is the one thing that must never happen.

10. **Run the fidelity and law check on every collected candidate, then stop judging.** Open every file and look. This room checks four catastrophic classes only, each with a fixed action:
    - **(a) Not the product** (wrong part count, wrong material, wrong shape). ONE candidate drifted: pull it from the choice set, log it, and regenerate if the owner wants the slot refilled. ALL of them drifted: STOP, spend nothing more, and go back to `/reference-sheet` to re-lock with a fresh smoke test. On the Genrupt path a wholesale drift with the reference confirmed attached is also a bug to report, not a prompt to write.
    - **(b) A person, a face, or a hand.** Never enters the choice set. Pull and log it.
    - **(c) Overlay text, a drawn badge, a star rating** (anything beyond the product, its label, and the approved hang-tag). Never enters the choice set. Pull and log it.
    - **(d) A failed or blank render.** Log it with its error and retry or record per step 9.
    A pulled candidate stays on disk and in the log (never delete), it just does not get shown as a choice. Then STOP. Scores, the squint test, the compliance verdicts, and the deep ranking belong to `/inspect`, and duplicating them here just gives the owner two opinions to referee.

11. **Post-tasting: the challenger and the ordered regenerations (Day 8).** Two different jobs arrive here after the Tasting Room, and both must be traceable:
    - **The challenger.** ONE only, and optional. Build it only when the tasting notes handed you a thesis that Round 1 never tested. On the Genrupt path a challenger is a NEW generation under a DIFFERENT control setting, usually a different tactic, confirmed with the owner like any tactic; it is never a prose brief on slot 1. On the fallback path it may be authored from the thesis directly. It must be a different STRATEGY, not different decoration: two shades of the same idea split votes and teach nothing. It carries the honesty law from step 2 even harder, because a challenger born from a praise theme is exactly where over-promising creeps in. Write its provenance into the batch log: the theme it came from, how many tasters said it, and which control changed. Then hand it straight to `/inspect`; no image enters the Tasting Room ungated, not even one born from data. If no theme reached enough mentions to build on, SAY SO and skip it. An uncited challenger is a reroll wearing a costume.
    - **Regenerations ordered by `/fix` MODE B.** When a taster objection routes to REGENERATE (framing, size in frame, layout, anything spatial), it comes back here. On the Genrupt path that means a fresh generation under the same or an owner-adjusted control setting, with the objection recorded; on the fallback path the tighter sentence is carried in the prompt. Save it as `[winner]-v2.png` and record which note drove it. Same rule for scorecard-driven regenerations in MODE A.
    - **Otherwise the mains stay frozen.** Do not re-run this room just because a later room is open. After the batch passes the gate, a main changes only when a scorecard flag or a tasting note orders it.

12. **Log the batch** in `images/batch-log.md` (append, never overwrite) using the format below: the candidate map with the controls that produced it, the batch row, the reconciliation, the human shortlist with reasons, and any Round 2 provenance.

    **Then feed the GENERALIZABLE reasons forward.** Read the shortlist reasons back once more. A reason that names a look, an element, or a rule ("nothing on a marble countertop", "the steel base must stay in frame", "that angle hides the tiers") is a creative preference that outlives this batch: append it as a dated bullet under **Owner creative preferences** in `factory/Improvement Log.md`, in the owner's words, and say out loud that it was recorded so the next brief starts already knowing it. A reason that only compares candidates ("this one is better", "cleaner") stays in the batch log and goes no further. Without this step the reasons die in the batch log, and the owner ends up re-rejecting the same idea in three products, each time from scratch.

13. **Hand off.** Tell the owner: "The mains are out of the machines and your shortlist is named. Nothing here is approved yet. Next stop is the Inspection Room: run `/inspect` before you fall in love with anything." Then name the rest of the INVENT station: `/secondary-images` for the gallery, `/aplus` for the modules, `/variations` if the product sells variants. The full package goes to Inspection together.

## Output format

`factory/Products/[product]/images/` after a run:

```
images/
  main-01.png
  main-02.png
  ...
  main-08.png
  main-02-v2.png       (a regeneration, beside its untouched original)
  main-09.png          (post-tasting challenger, next free number)
  batch-log.md
```

`images/batch-log.md`:

```markdown
# Batch Log . [Product Name]

## Controls confirmed (before spend)
Tactic: [name, as the setup flow names it] (owner confirmed [date])
Hang-tag text: [text, or "none"]
Packaging preference: [choice, or "none"]

## Candidate map
| File | Path | Produced by | Law check | Result |
|---|---|---|---|---|
| main-01.png | genrupt | tactic [name] | pass | generated |
| main-02.png | genrupt | tactic [name] | pass | generated |
| main-03.png | genrupt | tactic [name] | PULLED: [law class + one line] | generated |
| main-04.png | genrupt | tactic [name] | . | failed: [exact error] |
| main-05.png | fallback | brief strategy "[variant name]" | pass | generated |

## Batches
| Date | Room | Path | Model | Candidates | Est. cost | Approved | Notes |
|---|---|---|---|---|---|---|---|
| [date] | main-image | genrupt / gpt_image_fallback | gpt_image_2 | 8 | [est] | yes ([date]) | planned 8 = generated 7 + failed 1 + skipped 0 |

## Human shortlist
- Picked: main-02, main-05. Owner's reasons: main-02 "[one line, owner's words]", main-05 "[one line]".
- Criteria they were judged against: [the brief's selection criteria, one line].

## Post-tasting provenance (only when a challenger or an ordered regeneration ran)
- main-09.png . challenger. Theme: "[the taster theme, quoted]" ([N] tasters, Tasting Round 1 card). Control changed: [tactic X to tactic Y, owner confirmed]. Different strategy from the winner because: [one line].
- main-02-v2.png . regeneration ordered by /fix MODE B. Note that drove it: "[quoted note]" ([N] tasters). What changed: [control adjustment or fallback sentence].
```

## Golden Standards check

Before handing off, verify:
- [ ] All four preconditions were checked by opening the files, and any block was reported with its exact ask, not worked around.
- [ ] All three main-image decisions (tactic, hang-tag text, packaging preference) came from the brief and were confirmed with the owner BEFORE spending. No control was defaulted, guessed, or inferred.
- [ ] Slot 1 round-tripped unchanged in every plan save: zero brief text, zero headers, zero custom instructions, zero slot references on the main.
- [ ] Cost was read against the live balance and REPORTED in one line before and after, never used as a gate. A re-spend on a slot that already produced candidates, and an insufficient balance, were each named and stopped on before running.
- [ ] Every enabled tactic was confirmed with the owner, every dropped one carries a written reason, and the hang-tag text either came from the brief inside 28 characters or was left empty with that consequence said out loud.
- [ ] If a packaging tactic ran, the packaging bucket was confirmed non-empty and `alwaysIncludePackaging` was on. No box was ever invented.
- [ ] The blast SPREAD was reported per tactic before the owner started picking, and a lopsided or single-tactic spread was called out rather than passed along.
- [ ] The VANILLA CONTROL was generated as its own job with `enabledMainImageTactics: []`, and it is on disk. Never tick this from an intention.
- [ ] The owner picked between one and five, in the app, holding the selection criteria. The selection was READ BACK by name and count before anything downloaded.
- [ ] The selected candidates are on disk in `images/` and the slot completion is marked. Nothing important was left living only inside Genrupt.
- [ ] EVERY candidate Genrupt produced was collected, saved, and logged. None dropped silently, including the ones pulled by the law check.
- [ ] Every candidate shown to the owner is PRODUCT ONLY: no people, faces, or hands.
- [ ] No overlay text or graphics on any shown candidate, and no drawn badge, star rating, or review reference. Only the product, its label, and the approved hang-tag.
- [ ] Nothing shown over-promises what the product delivers as sold, and no product fact appears that is not in the Reference Sheet or the brief.
- [ ] Genrupt path: `modelId: "gpt_image_2"` on every call, plan edited not re-planned, reference asset id confirmed attached, style only via the branding preset and styleImage.
- [ ] Fallback path: announced as fallback, key confirmed, references from `2-reference/photos/` attached, product spec prepended, weaker-fidelity warning given, first concept viewed before the rest.
- [ ] Naming contract held: machine order (or brief order on fallback), `-v2` beside an untouched original for regenerations, next free number for the challenger, no overwrites, no renumbering.
- [ ] The reconciliation adds up (planned = generated + failed + skipped) and every failure carries its exact error, every skip its named reason.
- [ ] The human choice was supported, never made: criteria restated, candidates laid out, thumbnail view offered, no ranking or recommendation given, the owner's picks and reasons recorded.
- [ ] Post-tasting only: the challenger cites its theme and mention count, changed a control rather than adding prose, and went to `/inspect` before any tasting.
- [ ] Batch log written with the confirmed controls, the candidate map, the batch row, the reconciliation, and the shortlist.
- [ ] Generalizable shortlist reasons were appended to the Improvement Log's Owner creative preferences (dated, in the owner's words), and the recording was said out loud; compare-only reasons stayed in the batch log.
- [ ] The owner was pointed to the Inspection Room, and no image was called final, approved, ready, or best.

## Wonka lines

Openers:
- "The Main Image Room. One square inch of shelf, and the machines will offer you many ways to win it."
- "The hero shot is the product. Full stop. We set three dials, the machines do the rest, and YOU do the choosing."
- "Come in, come in. Today the factory bakes a whole tray of heroes, and you pick the one the shop window gets."
- "Money first, because this factory never spends silently. Here is the number. Say the word."

Closers:
- "A tray of contenders, out of the machines, every last one collected. Your shortlist is noted. Inspection Room, next."
- "Fresh mains, still warm. Whether your pick is THE main is a question for the shoppers, not for either of us."
- "I laid them out and held the yardstick. The choosing was yours, as it always is in this room."
- "A challenger born from what a hundred tasters told us, with its parentage written on it. Now let them judge their own child."

## Definition of Done

- The three main-image decisions are confirmed with the owner and recorded in the batch log before any spend.
- Every candidate the run produced is accounted for on disk: a collected file in `images/` named per the contract, or a recorded failure with its exact error, or a named conscious skip. Planned = generated + failed + skipped, stated.
- `images/batch-log.md` exists with the confirmed controls, the candidate map, path, model, count, approved cost, the reconciliation, and the human shortlist with the owner's reasons. Round 2 runs also carry their provenance lines.
- The fidelity and law check ran on every file, and no image with a person, overlay text, or a wrong product was shown as a choice.
- The human named the shortlist; this room recorded it without ranking or recommending.
- `status.md` updated per below.
- The owner was explicitly handed to `/inspect`, with `/secondary-images`, `/aplus`, and `/variations` named as the rest of the INVENT station, and no output was presented as final.

## Update status.md

In the INVENT sub-status block, set `Main image (/main-image): done` (or `in progress` if the batch is partial, waiting on a named decisionhead, or waiting on the owner's shortlist, or `blocked: [precondition or unanswered control]`). Artifact `images/main-01..NN.png` + `images/batch-log.md`. Then check the whole INVENT sub-status block: when all four sub-parts (Main image, Secondary images, A+, Variations) are `done` or `n/a` with a reason (variations may be n/a or a lawful trailing marker), set the INVENT station row to `done`; otherwise leave it `in progress`. Log line: `[date] Main candidates generated: [M] of [N] planned on [path], tactic [name], cost approved [est], [K] failed, [S] skipped, [P] pulled by the law check. Owner shortlisted [files]. Awaiting inspection.` For a Round 2 run: `[date] Round 2 challenger main-[NN] generated from the "[theme]" tasting note ([N] tasters), control change [X to Y]. Inspected before tasting.` Name the remaining INVENT rooms as next steps, with INSPECT to follow once the full package exists.

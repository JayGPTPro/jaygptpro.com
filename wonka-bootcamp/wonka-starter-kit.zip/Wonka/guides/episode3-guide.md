# Day 3: The Creative Brief

This is the bootcamp's first big WOW, and it is not an image. It is a document.

Today Wonka takes everything the Research Room learned and writes one creative brief for your whole
product page: the main image, the full secondary set, your cast, your variation plan. Then he hands
it to you, because it is a draft until you say otherwise. You review it, you argue with it, you
approve it. Only then does it go into the machine.

**The sentence for the day: we write the brief, Genrupt executes it.**

## What you will have by the end of today

- **A full brief (`brief/creative-brief.md`)**: every secondary slot with one job and one message, a
  written main-image brief, your cast, your variations, and the honest list of what you left out
- A **coverage map**: every selling point mapped to an asset, or consciously skipped in writing with
  a real reason
- The **three main-image controls** (tactic, hang-tag text, packaging preference) decided by YOU,
  plus **selection criteria**, so the Day 5 pick has a yardstick that is not your mood that afternoon
- A **cast of 1 to 2 custom avatars** built from your real buyer, with an explicit age and gender
- **The brief saved inside Genrupt**, your text sitting in every secondary slot
- **Three questions you will use to review every creative brief for the rest of your life**

**Time needed:** 45 to 75 minutes, and most of it is reading and arguing. Writing costs nothing.
Only the send at the end touches credits. This is the most valuable hour of the bootcamp. Spend it
awake.

## What you will need at hand

- Your `research/` folder from Day 2, including `product-report.md`
- Your product photos already sitting in `2-reference/photos/`. They go into the send as product
  images. Locking the reference properly is tomorrow's job, not today's
- Your real SKU list, if your product sells in colors, sizes, counts or bundles
- Your own opinions. You are the editor of this document, not a spectator

**You do not need your brand kit today.** Colors and fonts get built tomorrow and applied to the
plan. Style is never written into a brief as text, so its absence changes nothing about today.

---

## Lesson 1: Wonka writes the brief

### The one rule that runs the whole day

**Distill, do not forward.**

The obvious move, once you have a twenty page report, is to hand the whole thing to the image
machine. It feels thorough. It produces WORSE images, reliably, because a model drowning in prose
latches onto the wrong sentence and your actual direction gets buried.

So twenty pages become a handful of small, sharp fields: about seven buyer questions, one clean
product description, a short list of finished headlines, a cast, and two or three constraints. If a
field reads like research notes, it is not done.

### The four rules baked into the document

Learn these and you will read any creative brief, from Wonka or from a human, with sharper eyes.

**One asset, one job, one message.** An image that says three things says nothing. Each frame gets
one thing to prove.

**The main image is briefed here, but chosen on Day 5, and it is product only.** No people, no
faces, no hands, in any candidate, ever. The hero fights for the click at thumbnail size and clutter
loses the click. Your brief writes what the winner must show and prove, but only three controls
travel to the machine: tactic, hang-tag text, packaging preference. Genrupt generates many
candidates and YOU pick, holding the written criteria.

**Plan the set, not the slots.** No two assets share a message. At least one frame is emotional
rather than another spec sheet. And every selling point is mapped to an asset, or skipped in writing
with a reason. That mapping is the coverage map, and it is the difference between a set that covers
your market and a set that covers whatever the model found interesting.

**The funnel diagnosis sets the weighting.** From Day 2: weak click share means the weight goes on
the main-image criteria and the first Tasting Round. Clicks fine but conversion weak means the
weight goes on the secondaries and the A+. No data means Wonka marks it estimated and hedges.

### Where research stops being homework

In the demo product, the number one complaint is a promise the images made: the pictures showed a
full cascade, buyers filled the machine to the number on the box, and got a trickle. Nobody lied in
words. The images over-promised, and the reviews punished it for years.

Ask that question of your own product before you read a single slot: **is there a complaint in my
reviews that my current images caused?** If there is, the first job of this brief is to stop
repeating it.

### The promise check

Before he hands anything over, Wonka runs every headline and the hang-tag text through three
questions. Is it sourced. Do the reviews SPLIT on it. Would a buyer who believed this line and then
opened the box feel misled. When the last answer is yes, the fix is always the same shape: **keep the
job, drop the promise, show the mechanism.** The image teaches how the thing works and leaves the
outcome unpromised.

A theme buyers argue about is not a promise. It is a coin flip, and promising it betrays a chunk of
your buyers by design.

### Two things routed away from the brief on purpose

- **Casting is a field, not a sentence.** Your buyer becomes 1 to 2 custom avatars with an explicit
  age and gender, with the aspirational skew applied (from age 50 the displayed model looks about 5
  years younger, scaling to about 10 by 70). Per-image variety is automatic: within your cast the
  machine varies appearance so a different person appears in every people-bearing image. Never ask
  for variety in prose, and never describe a person inside a slot.
- **A+ is hands-off.** No module plan, no A+ copy. Genrupt plans the A+ alone on Day 7 and the
  inspection is the gate. The brief records only which selling points are expected to land there.

### The one input that teaches by being absent

Before writing, Wonka checks the **Improvement Log**, the factory's memory of what YOUR market has
actually voted for. Today he will tell you it is empty, because this is your first product. Remember
that line. After your first Tasting Round the book starts filling, and the next time this command
runs he opens it and briefs from what already won for you. Today is the only day it is ever empty.

### The check that is not him

At the end, Wonka runs a linter over his own brief. Four seconds, no opinions, never tired. Casting
text sitting in a slot, a headline over the character cap, two slots carrying the same message, a
point you dropped yesterday creeping back into a frame. **Zero errors before it reaches you**, so
your review is about judgement instead of proofreading.

---

## Lesson 2: Your review, your approval

Most people freeze here, because they think reviewing creative means having opinions about design.
It does not. The machine already caught the mechanical faults. What is left is the part only you can
do, and it is three questions.

**Learn these three. They work on every brief, from any source, forever.**

### Question 1: does every image have a different job?

Ask for the buyer questions alone, in order, nothing else. Listen for two that are secretly the same
question. Amazon gives you six or seven gallery slots, not twenty, so one job wearing two hats costs
you a whole frame.

### Question 2: why is this in, and that out?

Open the skipped column and make him defend every drop. When you disagree, you win: he read a
thousand reviews, but you have used the product and talked to the people who bought it.

The best version of this move is not reversing his reason, it is finding the honest version he
missed. "You dropped cleanup because the reviews split on it, and you were right that I cannot
promise easy. Bring it back as the mechanism, show the machine coming apart, promise nothing."

### Question 3: can we prove it?

Ask for every headline beside its source: a listing spec, the label, a real review, or something you
told him. **Anything sourced to nothing comes out.** Not because Amazon is scary, though it is,
but because an unprovable headline is a one star review with a two week delay.

### Then you approve, and it gets sent

Approval is a word you say, not a feeling. When you say it, Wonka sends: your product facts and your
cast go over, Genrupt plans, and then **your text is saved over its text** in every secondary slot.
Slot 1, the hero, is round-tripped untouched, because it is decided by those three controls and
nothing else.

Two things worth knowing about that send:

- **We do not throw Genrupt's plan away unseen.** Its planner has read far more listings in your
  category than your research ever will. Wonka reads what it planned, tells you anything it caught
  that your brief missed, and you decide whether you want it. That is what a second opinion is for.
- **Nothing generates today.** Today saves a plan. Images start on Day 5, after your product is
  locked in tomorrow.

---

## MISSION 1: Write the brief

```
/creative-brief
```

Let it finish. Do not interrupt the coverage map. Wonka saves `brief/creative-brief.md` and fills in
the "Mapped to" and "Skipped because" columns in `research/selling-points.md` so the two agree.

Read it slowly, top to bottom, before you react to anything.

## MISSION 2: Answer the main-image controls yourself

He will ask. Answer with your own words, never "whatever you think":

```
Main image: [tactic], [hang tag text or "no hang tag"], [packaging preference].
```

**Never let a default pick your tactic.** An unanswered control is a stop, not a shrug. Then read the
selection criteria he wrote, because that list is what you will be holding on Day 5 while you stare
at a dozen candidates that all look fine.

## MISSION 3: The three questions

Question one:

```
Read me just the buyer questions, in order, nothing else.
```

If two are doing the same job:

```
Slots [N] and [M] are answering the same worry. Merge them and give the freed
slot to [the thing nobody has answered yet].
```

Question two:

```
Show me the skipped column. Why did each one get dropped?
```

And when you disagree, overrule him with a reason. He writes the reason down, and in six months
that reason is the only thing that explains the file:

```
Bring [point] back. Not as a promise, as the mechanism: show [what happens],
claim nothing about [the thing the reviews split on].
```

Question three:

```
List every headline with what it's sourced to.
```

```
Cut [headline]. Replace it with something the listing actually supports.
```

## MISSION 4: Confirm the two structural things

Two quick checks that make the generation days go smoothly:

```
List every slot that will contain a person, then read me the cast: the custom
avatars with their explicit age and gender. Confirm no slot text describes a
person.
```

```
Confirm the variations plan matches my real SKUs. I sell in these variations:
[list them, or say "no variations"].
```

If you have no variations the brief should say `variations: none (single SKU)` in writing, rather
than inventing three. Fixing casting and variation logic here is a free edit to a document. Fixing
it after generation costs credits.

## MISSION 5: Approve, and send

```
Approved. Send it to Genrupt.
```

He states the planning cost, waits for your go, sends, and then reads the plan back to you slot by
slot. Check three things in what comes back:

1. Your text is in the secondary slots, not his
2. Slot 1 is untouched
3. The cast that read back is the cast you asked for

Then ask the free question:

```
What did Genrupt's planner have that our brief missed?
```

**Share the WOW:** post a screenshot of your favorite part of the brief to the group, the coverage
map or a single slot. Reading dozens of briefs for dozens of different products is a masterclass in
listing strategy, and it is free.

---

## What good looks like

- Every secondary slot has ONE job, ONE buyer question, ONE headline of six words or fewer
- No two slots carry the same message, judged on meaning rather than wording
- The coverage map accounts for 100 percent of your selling points, with zero blank cells
- At least one skipped point says plainly that creative cannot fix it, and names who owns it instead
- The main-image section has your answers in it, not defaults
- Every headline can be traced to something real
- `Owner review: approved` with your reasons recorded in your own words
- A `## Send log` showing the plan saved, your text in the slots, and the hero untouched

## Common mistakes

- **Approving without reading.** The brief is the cheapest place in the entire factory to fix a
  mistake. Every day after this one is more expensive.
- **Treating Wonka's draft as final.** He is a very good first draft. You are the owner.
- **Answering "whatever you think" to a main-image control.** That is the one image that decides
  whether anyone sees the other six.
- **Trying to write style, colors or people into a slot.** Those are fields and presets, not
  sentences. Text in the wrong place is weaker than the same instruction in its own field, and it
  crowds out your actual direction.
- **Expecting images today.** Today is a plan. Tomorrow is the mold. Day 5 is the first candy.

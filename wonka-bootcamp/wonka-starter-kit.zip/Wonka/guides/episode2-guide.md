# Day 2: Wonka, Meet My Product

Today your product walks through the Front Gate, and your new employee earns his salary before touching a single pixel. One command does all of it: he registers the product, interviews you for the intel only you have, hands you a shopping list, waits until it is full, then digests your listing, your reviews and your competitors and derives the picture of your niche himself. No research subscription, no export, no browser extension. Everything he needs, you already own.

No images today. This is the foundation everything else stands on, and it is the day a lot of sellers discover that a complaint sitting in their reviews was caused by their own images.

**The sentence for the day: you are not showing him a product, you are teaching him one.**

## What you will have by the end of today

- A product folder on disk with all its rooms inside it and a station tracker
- `research/insights.md`: the derived niche picture. Table stakes, customer language, the pricing landscape, demographics, and your funnel diagnosis
- `research/reviews.md`: pain points ranked, objections, delight moments, and the exact customer phrases worth putting on an image
- `research/persona.md`: the real buyer, not the imagined one
- `research/competitors.md`: what every rival shows, which of their frames is genuinely strong, and the whitespace nobody is covering
- `research/selling-points.md`: the checklist that follows you for the rest of the bootcamp

**Time needed:** about 60 to 75 minutes. 18 minutes of video, about 15 minutes filling the basket, and the rest reading what comes back, which is the enjoyable part.

## What you will need at hand

- Your basket of inputs from Day 1: your reviews file, your competitor gallery screenshots with their listing URLs, and your product photos. Today Wonka creates your product's folder and opens the drop zones for them (`1-inputs/` for the files, `2-reference/photos/` for the photos)
- Your ASIN, your full Amazon listing URL, your brand name, and your exact niche phrase in your own words
- Your owner intel, roughly thought through. He interviews you for it at the Gate today
- Optional, and only if you have Brand Registry: your ASIN level demographics export, and your Search Query Performance export

If your basket of inputs is not ready, gather it before you start. It is copy and paste from things you already own, and the quality of everything downstream is set by what goes into those folders.

---

---

## Lesson 1: Teach Wonka

*The interview. He keeps asking until he has what he needs.*

### Research is ammunition, not homework

The most expensive image you will ever pay for is a beautiful one that answers a question nobody asked. It looks superb in your folder and it moves nothing, because it was never connected to what buyers in your niche actually care about.

Wonka needs four answers before he touches a pixel:

1. What does this niche treat as mandatory?
2. What do buyers complain about, and what actually triggers the purchase?
3. What is every competitor showing, and what is nobody showing?
4. Who is the real buyer?

He derives all four from two sources, cross referenced. **Competitors** give you the visual landscape. **Reviews** give you the emotional truth. A critical review is a buyer writing your image brief for free.

---

## Lesson 2: The analysis, and The Product Report

*He goes away and works, then hands back one readable report.*

### Table stakes and whitespace

Two words you will use for the rest of your selling career.

**Table stakes**: what most competitors show AND reviews demand. That double confirmation is what makes a feature non negotiable. You get no points for showing one, you get eliminated for missing one. A feature only competitors show, or only reviews mention, is single source, and Wonka labels it that way so you can weigh it instead of guessing.

**Whitespace**: what nobody in your niche shows, even though the reviews prove buyers care. That is where a new image set wins, because it is the only place you are not competing on execution.

The competitor teardown exists to sort every visual idea into one of those two piles, and to name their single best frame so you can match it and then beat it.

### The reviews trap, and why it decides your whole day

Your product page shows you a handful of reviews, usually about eight, and they skew positive, because a product page is a sales page. Copy those and you have collected marketing, not research.

Log in on amazon.com. Sort by Most recent. Then filter to Critical and copy those too. For your own product, Seller Central gives you the lot.

The demo product this bootcamp runs on shows exactly why. It is the number one best seller in its category, sitting at 3.9 stars, and the split is 58% five star and **18% one star**. Nearly one in five buyers is angry. Take the eight reviews the page offers and you meet none of them.

### The expectation gap (the most important idea in this bootcamp)

Here is what those critical reviews turned out to say on the demo product, a four tier electric chocolate fondue fountain.

The number one complaint, by a distance, is that the chocolate does not flow. Buyers describe following the instructions precisely, adding oil, adding more oil, and still getting a thick trickle instead of a cascade. Then one buyer explains the whole thing in a single line: the box says it holds 32 oz, two pounds, and it does hold that amount, but for the flow you see in the pictures you need about four pounds.

Read that again. The listing sells 32 ounces. The buyer fills it to 32 ounces, because that is the number on the box. She gets a trickle instead of the waterfall she saw in the photograph, at her daughter's baby shower, in front of the guests.

**The number one complaint about that product is a promise the images made.**

Not the motor. Not the shipping. The images. Somebody chose a hero shot with a perfect cascade, and every buyer who trusted the number next to it felt lied to, and left one star, months later.

Now the reverse, which is why you are here. If images can open that gap, images can close it. Look at the rest of that competitive set: 3.5, 3.5, 3.7, 3.7, and one premium machine at 4.1 that costs more than three times as much. Every gallery on the page shows the same fantasy cascade, and nobody answers the question every buyer is actually asking, which is: will it flow for ME, and what does it take. The first seller who answers that inside the gallery owns the category.

Two things to carry into your own product:

1. Go and look for your version. Somewhere in your critical reviews is a complaint your own creative caused. Almost every product has one. Finding it is worth more than any lighting decision you will make in this bootcamp.
2. A finding from reviews is a **review finding**. It is what buyers report. It never goes onto an image as if it were a claim on your box. We close expectation gaps, we do not open new ones. Truth is the entire advantage here.

### The real buyer, not the imagined one

Most listings are art directed for a customer who does not exist, often 25 years younger than the person actually clicking Buy. Wonka builds the persona from the evidence: the voice in your reviews, your listing, and your competitors'.

If you have Brand Registry and export your ASIN level demographics, he builds it from your ACTUAL buyers and records `source: brand_registry_export`. If you do not, he builds an honest estimate, labels every line `estimated`, and upgrades it the moment real data arrives.

This persona decides real things later: who appears in your lifestyle images, which fear the images answer first, what language goes into headlines, and how the panel of tasters in the Tasting Room is screened. A wrong persona here is inherited by every room that follows.

### Click problem or close problem

There are only two ways an Amazon listing loses money, and they need opposite fixes.

- **Low click share.** Shoppers see you in search and scroll past. That is a click problem, and the lever is the MAIN image.
- **Healthy click share, weak purchase share.** Shoppers click, land on your page, and leave. That is a close problem, and the lever is the secondary gallery and the A plus content.

Fix the wrong one and a beautiful new set changes nothing. That is how most sellers waste a redesign.

If you have Brand Registry, Search Query Performance answers this for you. If you do not, say so, and Wonka reasons from public signals and marks the diagnosis `estimated`. Either way, the answer steers how much weight your brief puts on the main image versus the gallery.

### One rule that runs through the whole factory

Every selling point gets mapped to an asset, or gets skipped in writing, with a reason. Nothing important disappears silently. That rule starts today, in `selling-points.md`, and it is enforced in every room after this one.

---

---

## MISSION 1: Walk through the Front Gate

The whole day runs on one command:

```
/meet-my-product
```

Give him the identity in the first message: ASIN, full Amazon URL, product name, brand, and your **exact niche phrase** in your own words. Confirm that phrase carefully. It defines which competitors count as the same niche, and every table stake in your analysis depends on it being right.

Three things happen before anything is created, and all three are deliberate.

1. **He proposes a folder slug and asks you to confirm it.** That name follows this product for the rest of the bootcamp.
2. **He reads the listing title back to you.** Confirm it is genuinely your product. A single transposed character in an ASIN passes every format check on earth and quietly registers a stranger's product into your factory. A human reading a title is the only thing that catches it.
3. **He interviews you for owner intel.** Three questions, in one message: what do you already know works, what MUST appear, what must we avoid.

Answer question three properly. This is the one input no research on earth can replace, it is recorded word for word, and it travels with your product through every room. Plain sentences are perfect:

```
Known winners: the lifestyle shot with the product in use outperformed the
white background shot the last time we swapped them.
Must include: the certification that is really printed on our label, and
the one feature buyers never notice until support explains it to them.
Avoid: any medical or health claim, our lawyer killed those, and no
comparison to [competitor] by name.
```

Write yours the way you would say it to a new employee, with the real words off your real label. Only claim what is genuinely printed on your product or documented in your account. An invented certification here becomes an invented badge in an image later, and that is a suppression risk, not a stylistic one.

If an item genuinely does not exist for you, say so plainly. "None, this is a new product and I have no past results" is a real answer and he records it as given. He will never invent intel to fill a gap.

Then the product folder is created from the TEMPLATE and `status.md` is written with RESEARCH set to in progress.

## MISSION 2: Fill the shopping list properly

He hands you the entire list in one message and then he parks. He will not research, guess, or move on until the basket is full. That is the integrity rule, and it is the reason you can trust anything downstream.

The list:

- **Listing URL.** Or a product description if you are pre launch, and he records `live: no`.
- **Reviews.** About 10 positive and about 10 critical, saved as a file into `1-inputs/`. Take the critical ones properly, see above. This is the file that decides how good today is.
- **Competitors.** 3 to 5 ASINs or URLs, or full gallery screenshots dropped into `1-inputs/competitors/`. The ones stealing your sales, not the ones flattering to compare against.
- **Real product photos.** All angles, one hand for scale shot, and label close ups, into `2-reference/photos/`. They are used in the next room, so collect them now while the camera is out. If you genuinely cannot hold the product, the fallback is the listing gallery plus customer review images, recorded as exactly that. It is what the demo run uses, because that listing is not ours and there is no unit on the desk, and you will hear it said plainly on camera. It is the fallback, not the standard. Yours is in your house, so shoot it.
- **Optional: Brand Registry demographics export.**
- **Optional: any search term or keyword data you already have.**

The two optional items never block. If you do not have them, say so and he records them as not provided.

Then say it explicitly:

```
Everything is in.
```

A generic "continue" is not the trigger, on purpose.

**Picking competitors, when you are unsure.** Search your exact niche phrase and expect most of page one to be noise: accessories, different formats, adjacent products. The test is simple. Would a shopper typing my niche phrase see this listing and consider it instead of mine? A fondue pot is not a chocolate fountain even though both say fondue, and its table stakes are not yours. One off niche competitor tilts every conclusion after it. Wonka runs this check himself before analysing and will drop one and ask for a replacement. Fewer than three genuinely relevant competitors and the station stays blocked, which is correct.

Then verify the artifact exists. Start this habit now, because you will use it in every room:

```
Show me the status.md you just created, and list the folders inside my
product's folder.
```

You should see the station tracker with five stations, your owner intel recorded, and the full set of subfolders: 1-inputs, 2-reference, research, brief, images, edits, final, aplus, variations, scorecards, tests.

## MISSION 3: Read the analysis, and push back

The analysis lands as a summary on screen and five files on disk. Read all five. This is the enjoyable part and it is also where you earn your money, because you know things the data cannot see.

Read in this order:

1. `reviews.md`, for the pain points and the exact customer language
2. `competitors.md`, for the whitespace and their best frame
3. `insights.md`, for the table stakes and the funnel diagnosis
4. `persona.md`, for who you are actually talking to
5. `selling-points.md`, last, because it summarises all four

React out loud. This is a conversation, not a report you file:

```
Correction: [what he got wrong, or what the data cannot see. For example:
"our buyers are mostly repeat gift buyers in their fifties, the persona
skews far too young"]
```

He revises the file, records the correction and its source, and tells you what it changes downstream.

Read the whitespace section twice. That is where your set finds its unfair advantage. And do not only collect their weaknesses. Note their STRONGEST frame too, because a rival's best image is a benchmark you brief your set to match and then beat, rather than something you discover halfway through the bootcamp when somebody pastes it into the group.

**Share the whitespace:** post yours to the bootcamp group. Watching a room full of sellers each find the gap nobody in their niche is filling is half the education here.

## MISSION 4: Interrogate the selling points checklist

This is the most important artifact of the day. Every table stake, every real differentiator, every quality signal, every pain point your product genuinely solves, every whitespace opening. Each with an ID, each with a source, and two empty columns at the end, Mapped to and Skipped because, that the brief fills on Day 4.

```
Show me the selling-points checklist. For each point, tell me where it came
from: competitors, reviews, the listing, or my owner intel. Flag anything
you inferred rather than sourced.
```

Then check three things yourself:

1. **Is anything missing that YOU know matters?** Especially from your owner intel. Make sure it survived into the checklist.
2. **Is anything on it that is not actually true of your product?** Kill it now, loudly. A false selling point becomes a false image, then a return, then a one star review.
3. **Is anything vague?** "High quality" is not a selling point. "The front legs adjust so it sits level and the chocolate does not pool to one side" is.

And look for the quiet gold: a spec your product already has that answers a complaint buyers are making, and that nobody has ever put in an image. Those exist on most listings and they are free.

## MISSION 5: Get your funnel diagnosis

```
Give me the funnel diagnosis in one line: is my problem the click (main
image) or the close (gallery and A plus), and what is the evidence?
```

If you have Brand Registry, hand over the real thing first:

```
Here is my Search Query Performance export and my return reasons.
[attach the exports]
Diagnose the funnel from this, and turn the return reasons into creative
fixes.
```

If you do not, say so plainly and let him reason from public signals with the result marked `estimated`. That is what the demo run does, and it is what most sellers will do.

One trap inside return reasons: not every complaint is a creative job. "Arrived cracked" is packaging, and no image will save it. "Not as described" and "smaller than I expected" are yours entirely, and each maps to a specific frame. Sort them, and fix the ones that are actually yours.

---

## What a good Product Report looks like

- **Table stakes name their confirmation type.** Double confirmed items say so, single source items say so. If everything is presented with equal confidence, push back.
- **Every claim traces to a source.** Reviews, the listing, a competitor gallery he actually looked at, or your owner intel. Nothing else.
- **The customer language section quotes real phrases**, verbatim, in buyers' words. Those phrases are future image copy. Marketing language in that section means the reviews input was thin.
- **The whitespace list is specific and mapped.** "Nobody shows how to get a full cascade, and the top complaint is that it does not flow" is whitespace. "Better branding" is not.
- **One best frame is named**, with a concrete move to beat it.
- **The persona has a fear and a dream outcome**, both traceable to review lines.
- **The diagnosis states its evidence and its confidence.** If it is estimated, the file says estimated.
- **The checklist has IDs, sources, and two unfilled columns: Mapped to and Skipped because.**

## What a weak run looks like, and what caused it

| What you see | What actually went wrong |
|---|---|
| The digest reads like a generic category article | Thin reviews input. Paste 10 more critical reviews and say `Re-run the analysis with these reviews.` |
| Table stakes feel wrong or oddly broad | An off niche competitor got in. Ask `List the competitors you analysed. Are they all genuinely [my niche phrase]?` and swap the impostor |
| No real pain points, everything is positive | You copied the reviews from the product page. Log in, sort by Critical, take those |
| The persona could be anyone | No demographics and thin reviews. Push back with what you know, or export ASIN level demographics if you have Brand Registry |
| The whitespace list is vague | He did not actually see the galleries. Drop the gallery screenshots into `1-inputs/competitors/` and ask him to redo the teardown from the images |
| A confident claim you cannot place | Ask `Where did that come from?` Anything untraceable gets deleted, not softened |

## Common mistakes

**He is stuck waiting and will not move.** Working as designed. Name the missing item in plain words: "I have no critical reviews, proceed without them." That is a waiver, he records it and continues. A generic "just go" is not a waiver.

**He cannot open your competitor listings.** Browsing is not always available. Screenshot their full image galleries into `research/` and tell him they are there. He reads images with vision. He must never analyse a competitor from memory, and if he offers to, stop him.

**Your product is new and has almost no reviews.** Mine your competitors' reviews instead. Copy their top and critical reviews into the file and tell him plainly: my listing is new, these are competitor reviews, use them for pain point mining. Buyer pain in the niche is buyer pain in the niche.

**Your product is not live yet.** Give a product description instead of an ASIN. He records `live: no` and everything else runs the same way.

**You have no Brand Registry.** That is a first class answer, not a failure. The persona and the demographics get labelled `estimated`, the diagnosis is made from public signals, and both upgrade the day real data exists.

Anything else: `guides/troubleshooting.md`.

---

## Before the next room, 10 to 15 minutes

The Reference Room is next, where your REAL product gets locked into a reference the AI cannot drift away from, and your brand's look gets locked into a file. It goes faster if you do three things now.

1. **Confirm your photos are in `2-reference/photos/`.** All angles, the hand for scale shot, and label close ups. Ask him:
   ```
   Check my 2-reference/photos folder. Do you have everything you need to
   build the reference sheet in the next room?
   ```
   If a shot is missing, take it now. It is twenty minutes of your life and it sets the quality of every image after it.
2. **Gather your brand assets.** Logo file, transparent background if you have one. Your brand colours, hex codes if you know them, though "the green on our label" also works. Any real certifications or press mentions, with proof.
3. **Re read your whitespace section and your checklist.** Come to the next rooms with an opinion. You will be a far better editor for having slept on the research.

## What good looks like, on disk

- [ ] `/meet-my-product` ran to completion and your product folder exists with all its subfolders (1-inputs through tests)
- [ ] `status.md` exists with the station tracker, your owner intel recorded verbatim (or explicitly marked none given), and an empty Blocked on list
- [ ] All five research files exist on disk with real content: `insights.md`, `reviews.md`, `persona.md`, `competitors.md`, `selling-points.md`
- [ ] Every competitor was confirmed as genuinely your niche, and the check is stated in `competitors.md`
- [ ] You sent at least one correction and he recorded it
- [ ] You read the selling points checklist and checked it for missing, untrue, and vague
- [ ] You have a funnel diagnosis, honestly labelled, and you agree with it
- [ ] You know your whitespace, and you have named their best frame and your move to beat it
- [ ] RESEARCH shows `done` in `status.md`
- [ ] Homework: product photos confirmed complete in `2-reference/photos/`, brand assets gathered

Next: the Reference Room. You lock a reference of your REAL product so the machines cannot invent a different one, run the one cheap test that protects every generation credit after it, and dress the factory in your brand. Measure twice, invent once.

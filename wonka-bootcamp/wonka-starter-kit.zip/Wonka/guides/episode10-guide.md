# Day 10: The Improvement Loop, and the Close

The last day, and the one everybody runs.

**The sentence for the day: the Wonka you have in two months will be considerably better trained than
the one you have today, and this is why.**

## What you will have by the end of today

- **Your Improvement Log, written.** It has been empty, and named as empty, in nearly every room this
  week, on purpose
- Every market pattern citing the test that produced it, and at least one honest mistake recorded
- Your complete package in `output/`, with a document explaining every choice
- A ten minute weekly rhythm you can actually keep
- **Three specific next actions**, rather than a motivational sentence

**Time needed:** 40 to 60 minutes. Twenty of those are the log, and they are the highest-value writing
you will do all bootcamp.

## What you will need at hand

- Both races from Day 8, sitting in `tests/`
- Twenty honest minutes, including for the parts that went badly

---

## Lesson 1: Wonka gets smarter

### It has been empty all week, on purpose

Every room opened by telling you this file was empty. Day 2, Day 3, Day 5. It got repetitive.

**It was not filler. This is the only week it will ever be empty.**

Sitting in `tests/` there are two races' worth of results, a pile of objections in a hundred people's
own words, a set of images that changed because of them, and about a dozen things that went wrong this
week and got fixed. None of it has been turned into anything yet.

### What the market taught you

Wonka reads the results and both Cards and writes the market patterns.

**Check that every line CITES its evidence.** Not "warm lighting wins" but "warm lighting won the main
race, clear lead, this many tasters".

The citation is not bureaucracy. **It is what lets you disagree with yourself later** when better
evidence turns up, and you will want to.

A pattern without a citation is an opinion with better formatting.

**Here is what actually changes because of this section.** Every future `/creative-brief` opens by
reading it. Remember Wednesday, when he said the log was empty so the brief would run on your research
and best practice alone? **Next time he opens this first and briefs from what already won for you.**

Your second product does not start from zero. It starts from here.

### What the factory taught itself

Different animal. These are not about buyers, they are about how the work goes.

Enlarging text is a regenerate, not an edit, and you proved that by wasting a round on it. The
reference sheet needed the back panel photo. That objection group was too vague to act on until it was
counted.

Where the first section is read at the start of every **brief**, this one is read at the start of every
**session**.

**And there is a real reason they stay separate in your head even though they live in one file.** A
fact about your buyers should outlive your tools. A fact about the process is only true until the tool
changes. Mix them and one day you will brief a product using a lesson that was actually about a button
that no longer exists.

### Write down what went wrong. Especially that

Everybody writes the wins. Almost nobody writes the other thing.

**The entries that will help you most are the ones recording a mistake.**

"I approved the brief too fast and paid for it on Thursday." "I did not take the back photo and it cost
me a day." "I edited when I should have regenerated and burned the round."

Those are worth more than five confident pattern lines, because **you will do them again unless they
are written somewhere you will actually see them.** And you will see these, because he reads this file
at the start of every session.

### Which is why he gets better

The Wonka you started this week with knew how to do the job.

**The Wonka you have now knows how to do the job AND knows what happened when you did it.**

Next product, he opens the book before he writes the brief. He knows your buyers cannot judge size
without a reference object, because a hundred of them said so. He knows not to suggest an edit when
the fix is structural, because that already cost you a round.

**None of that comes from a model update. It comes from a file you wrote.**

That is the difference between using a tool and building an employee.

---

## Lesson 2: What you actually have, and what to do with it

### Walk your own folders

Ten days ago this was an ASIN and an empty folder.

| Folder | What is in it |
|---|---|
| `research/` | Your product report. Every complaint your buyers have, counted, with sources |
| `brief/` | The document that said what to shoot, argued with and approved, with your reasons |
| `2-reference/` | Your product, locked, and the smoke test that PROVED the lock rather than claiming it |
| `factory/Brand/` | Your brand in a file, and a preset attached to your plan |
| `images/` | Your mains and your gallery. Tested against what was live, then sharpened |
| `aplus/` | Cut to Amazon's dimensions, ready to upload |
| `variations/` | Your family, or a written none |
| `tests/` | Two races, a hundred tasters, every objection they raised |
| `factory/Improvement Log.md` | No longer empty |

**That is not a set of images. That is a documented production run**, and the difference is that you
can repeat it.

### Pack it

`/ready-to-upload` assembles everything into `output/` and writes the upload pack: what each asset is,
why it was chosen, what it beat, and **what was consciously not fixed.**

That last file is the part that survives. In four months you will look at this listing and wonder why
the main image is that one. This answers it. If somebody else ever runs your listings, this is the
handover. **And it stops you re-testing something you already settled**, which is the most common way
people lose a second month on a listing.

### Three things to actually do

**One: upload it. This week.** Not when it feels finished, because it will never feel finished.

**Two: start an A/B test on your main image, today, and never stop having one running.** Amazon runs it
free, on real traffic, with real buyers voting with real money. **It is the only genuine test in this
entire process and you already own it.** You have a shortlist rather than one image precisely so that a
challenger is always ready.

**Three: consider a paid survey with real people**, and be honest about whether your stakes justify it.
A hero SKU, a rebrand, a packaging run: probably yes. A seventh variant of something that already
sells: probably not. The Tasting Room did a lot for a few dollars, and it is still not people.

### And the next product

`/factory-report` is your Monday. Ten minutes, one command, every product and what is blocked **and on
whom.** A status that does not name an owner is a status nobody acts on.

When you start product two, here is what happens differently:

**You do not rebuild your brand kit.** You do not rewire your machines. You do not invent a folder
structure. You do not re-learn how to review a brief or read a Card. **And he opens the Improvement Log
before he writes anything.**

The research is real work every time, because it is about that product. The brief is real work. The
reference is real work. Everything else is already yours.

Realistically, **product two is a day and a half.** Not because you got faster at clicking. Because
most of the decisions were already made and written down.

---

## MISSION 1: Write the log

```
/improvement-loop
```

Then read all three parts out loud and check three things:

- Does every market pattern **cite the test** that produced it?
- Is there at least one honest **mistake** recorded?
- Is every gap written IN as a gap rather than left as an absence?

## MISSION 2: Pack it

```
/ready-to-upload
```

Read the upload pack. **If it does not explain your choices to a stranger, it is not finished.**

## MISSION 3: The rhythm

```
/factory-report
```

Check every blocked item names an owner. If one does not, the report is failing at its one job.

## MISSION 4: The three actions

Upload it this week. Start an A/B on your main and keep one running forever. Decide honestly whether
your stakes justify a paid survey.

**Share it:** post your favourite line from your own Improvement Log. Not a screenshot of the file. One
line, the one that surprised you.

---

## MISSION 5 (optional): The speed run

Not part of the guarantee. It is the mission that proves the whole thing, because a factory that
only ever ran once is a factory you have to take on faith.

Put your second product on the line and watch how much of it is already done:

```
/meet-my-product
```

He opens the Improvement Log before he opens anything else, so the patterns your own tasters just
taught you shape the research from the first question. The brand kit is built. The machines are
warm. Every gate still runs, because the gates are the method, but the reading is faster and the
brief is sharper.

Take it as far as you want today. The graduation checklist asks only that product two has its
research approved, or its next station on the calendar. Then it is a factory rather than a project.

---

## What good looks like

- Every market pattern cites its test
- At least one honest mistake is written down
- Every gap in the ledger is named as a gap
- The upload pack explains every choice to somebody who was not here
- `/factory-report` names an owner for every blocked item
- You know your three next actions and when you are doing them

## Common mistakes

- **Writing patterns without citations.** That is an opinion with better formatting.
- **Only recording wins.** The mistakes are the entries that change your behaviour.
- **Skipping the log because the week is over.** It is the only asset here that improves while you
  sleep.
- **Waiting until it feels finished to upload.** It will not.
- **Uploading without starting an A/B.** You built a shortlist specifically so you would have a
  challenger ready.

---

## And that is the bootcamp

Ten days ago you had an ASIN and a folder. Now you have a documented production run, a tested package
ready to upload, a challenger queued for your first A/B, and a file that makes your next product
cheaper than this one.

What this was actually for was never the images.

**It is that in three months you run a product through this in a day and a half, barely think about it,
and wonder what the fuss was.**

That is what a factory is. You built one this week. Go and use it.

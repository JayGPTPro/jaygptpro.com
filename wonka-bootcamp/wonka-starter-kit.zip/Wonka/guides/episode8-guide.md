# Day 8: The Tasting Room

Seven days of making things. Today the making stops and the finding-out starts.

**The sentence for the day: this replaces asking an AI to score your images, and it is several
levels above that.**

## What you will have by the end of today

- **Two Tasting Cards**: your shortlist against the image that is live now, and your whole gallery
  against the whole live gallery
- A result in one of three tiers, and the knowledge of what each tier licenses you to do
- **A list of objections in the tasters' own words**, sorted into what creative can fix, what the
  listing can fix, and what nobody can fix
- **A FINAL SET, ready to upload.** The fixes the panel asks for get applied the same day
- Two rows in your Improvement Log

**Time needed:** 90 minutes to two hours, and a chunk of that is waiting rather than working. Start
the races and go and do something else.

## What you will need at hand

- Your gate-passed candidates, and **your CURRENT live main image and gallery** downloaded into
  `incumbent/`. Without those, today does not work
- Your `OPENAI_API_KEY` in the factory root `.env`. **This spends your own money**, a few dollars per
  race, so Wonka will ask before each run rather than just reporting

---

## Lesson 1: What this actually is

Slides. No terminal, no Wonka.

### What everybody else does

You have five candidates. The obvious move is to paste them into a chat and ask which is best.

You will get an answer, confidently, with a number on it.

Now think about what produced that answer. **One model, with no age, no income, no shopping history,
and no reason to prefer anything, having a single opinion.** That is not analysis. It is a confident
guess with a decimal point attached.

It is better than nothing. It is not much better than nothing.

### What this does instead

It builds a **panel**.

**About a hundred distinct shopper personas**, each one conditioned on YOUR buyer: the age, gender,
income and shopping habits that came out of your research on Day 2. Not generic people. Yours.

**Each is shown the candidates the way a shopper meets them**, in random order, without knowing which
is the incumbent and which is new.

**And none of them is asked to score anything.** They react, in their own words. Because people, and
models playing people, are genuinely bad at scoring and genuinely good at reacting. Ask for a number
and you get a number. **Ask for a reaction and you get the truth, plus a number.**

Then a separate pass reads a hundred free-text reactions for purchase intent, runs a blind forced
choice, and produces a result with a **stability tier** attached, so you know whether the gap is real
or whether it is noise.

That is several layers of work, and each one exists because the layer under it was not good enough.

### What it is NOT

**This does not replace a paid survey with real people.**

Real humans, recruited and paid, remain the gold standard, and there is an optional lesson after this
week on running one cheaply. Not in your ticket, not required. **When a decision carries real money,
a hero SKU, a rebrand, a packaging run, that is what you should reach for**, and you should decide
that for yourself rather than take anyone's word.

These tasters are language models playing a role. They can be wrong, and they can be collectively
wrong in the same direction, which is worse.

**What it absolutely does replace is "Claude, tell me which of these is best."** That is the
comparison that matters, because that is the thing you were actually going to do.

### And what it is FOR

**One more round of sharpening, before this goes anywhere expensive.**

Not a verdict. A refinement step, sitting between your own eyes (compromised, because you have looked
at these for a week) and the two places where being wrong actually costs: Amazon, and a paid survey.

By the end of today your images will have changed because of a hundred reactions rather than because
of your taste or mine. That is the whole point of the room.

### Two races, and no listing yet

**The mains:** what is live on your listing now, against the new ones you made.

**The gallery:** your set against the live set, in order.

**And if nothing is live yet**, because you are launching, the benchmark is **the strongest
competitor's** main and gallery from your research. Say which competitor and why, because "beats the
category leader" and "beats my old image" are different claims and your Card should not blur them.

### How to read a result like an adult

| Tier | What it means | What it licenses |
|---|---|---|
| **Clear lead** | One candidate is genuinely ahead | Act on it |
| **Lean** | Ahead, but not by enough to be sure | A hint. Hold it loosely |
| **Toss-up** | Nothing separated them | **A real answer.** That decision does not matter. Spend the attention elsewhere |

**A hundred synthetic tasters leaning three points is not a fact about the world.** It is a nudge.

### The part worth more than the score

Every taster says WHY, in their own words, unprompted.

A result tells you candidate three won. **The objections tell you that eleven tasters could not tell
how big it is, four thought it was plastic, and two assumed it needed assembly.**

Those are not opinions about your images. They are the questions your listing is failing to answer,
handed to you in a list, before you have spent a cent on advertising.

**The score decides what to ship this week. The objections decide what to build next.**

---

## Lesson 2: Running both races

### It runs on your FINAL images

The check that matters most is the boring one. Wonka reads the filenames out loud before anything
starts, and **you should actually listen to that part.**

Not an earlier version sitting in an edits folder. Not something you fixed after you last looked. The
set that is in `images/` right now, which is the set you would upload.

**Racing an old version and then acting on the result wastes the whole run**, and it is an easy
mistake to make.

### The incumbent is not optional

Without your current live image in the race, you find out which of YOUR images the panel prefers,
which is interesting and useless. The decision is not "which of mine". **It is "is any of mine better
than what I already have".**

Nothing live yet? Use the strongest competitor's set, and know that you are making a different claim.

### The gallery goes in as a stack, in order

Not frame against frame. A shopper does not compare your image three to your image five, **they swipe
a sequence and form an impression**, so the sequence is the unit.

Order is part of what is being tested. Your strongest frame leading is a different gallery from your
strongest frame at position five, using the same images.

### It takes a while, and that is fine

This is not instant. It is a hundred personas reacting, twice.

**A live page opens by itself and refreshes on its own**, showing which phase it is in and how far
through, and telling you honestly if it has stalled. If the page does not open, `progress.json` in
the round folder has the same information.

**Then go and do something else.** Genuinely. Watching the bar is not participation and it will not
make it faster. Make a coffee, answer an email, come back when it is done.

---

## Lesson 3: The report

Nothing is generated or changed in this lesson. It is a read, and it is worth doing properly.

### Start at the tier

See the table above. And the sentence to carry out of the room: **a hundred synthetic tasters leaning
three points is not a fact about the world.**

**A toss-up is a result**, not a failed test. It told you where NOT to spend attention.

### Then per candidate, in their words

Not a score. **What a hundred people thought was going on in the picture**, which is a completely
different kind of information from "7.2 out of 10".

### Then the objections. This is the part that pays

Read all of them. Verbatim. Sort as you go into three piles:

**Creative can fix it.** They could not tell the size. They thought it was plastic. Images that
failed to communicate, and you fix them today.

**The listing can fix it, but not with an image.** A question about what is in the box, a spec nobody
could find. That belongs in your bullets or your A+.

**Nobody can fix it.** "Too expensive." "I would not use it often enough." Real, and no photograph
solves them. **Writing them down as unfixable is what stops you trying to photograph your way out of
a pricing problem.**

### And a warning about taste

**Do not treat this panel's taste as authoritative.** It will sometimes prefer something you can see
is worse. It is a hundred models, not a hundred people.

**Do take its advice seriously when it sounds right to you.** "They could not tell the size" is
information regardless of who said it, because it is about comprehension rather than preference.

**Comprehension objections are the gold. Preference verdicts are the nudge.** Weigh them differently.

### The cross-read

Look for **the same objection appearing in BOTH races.** That is not about one image. It is a gap in
your listing that your creative has not closed anywhere.

---

## Lesson 4: The final set

Now you do something about it, which is the part almost nobody does.

### He proposes, you approve

Wonka reads both Cards, groups the objections by theme **with counts**, and comes back with a list.
Every line says which objection it answers and how many tasters raised it.

**One taster is a person. Eleven is a pattern.** Spend your credits on the patterns.

### Changes, not wishes

"Make it clearer that it is big" **is not a change, it is a wish**, and nothing can act on it.

"Add a hand holding it at the same scale as the size callout" **is a change.**

Every group has to become something physical before anything runs.

### And the ones you refuse

**You do not act on every objection.**

Some contradict each other. Some come from a taster who is not your buyer. Some ask you to promise
something your product does not always do, which is exactly what your brief spent Wednesday
preventing.

**Refuse at least one, out loud, with your reason recorded.** A refusal with a reason is a decision.
A refusal you never mention is just something you ignored, and in three months you will not remember
which it was.

### Then it runs, and everything gets re-checked

Same routing as Friday: take something away or swap a word is an edit for cents through the direct
API, make it or move it is a regenerate.

**And everything touched gets re-inspected before you call it finished.** A fix introduces problems:
you enlarge the size callout and crowd the headline, you remove an element and unbalance the frame.
Catching that with a scorecard is free.

### You now have a set

Tested against what is actually live. Sharpened by a hundred reactions rather than by anyone's taste.
Re-checked afterwards.

**These are ready to upload.** Put them up, and **start an A/B test on the main image** while you are
in there. Amazon runs it free, on real traffic, and everything today was to give that test something
worth running.

---

## MISSION 1: Set up honestly

Get your current live main image and gallery into `incumbent/` first. If nothing is live, pick the
strongest competitor from your research and say why.

```
/tasting-room
```

Check two things before you say go: **is my current image (or my chosen competitor) in the race**,
and **did he read back the right filenames?**

## MISSION 2: Both races, then walk away

```
Go. Main race first.
```

Then the gallery race, both stacks in ORDER.

Open `live.html` when it appears, glance at it once, **and then go and do something else.**

## MISSION 3: Read both Cards properly

Tier first. Then every objection, verbatim, sorted into the three piles.

Then the cross-read:

```
Which objections appear in BOTH races?
```

## MISSION 4: The final set

```
/fix
```
```
Work from both Tasting Cards. Tell me what you want to change and why.
```

Check every proposed change is **physical** rather than a wish. Then refuse one:

```
I am not acting on [objection], because [reason]. Record that.
```

```
Approved. Do those.
```

Confirm everything changed got re-inspected before you call the set final.

**Share it:** post your most surprising objection in the group. Not your result. Your objection.

---

## What good looks like

- It raced your FINAL images, and you heard the filenames read back
- Your current live image, or a named competitor, was in both races
- Both stacks went into the gallery race in ORDER
- You read the tier before the percentage, and treated a toss-up as an answer
- Every objection read verbatim and sorted into three piles
- Any objection appearing in both races is written down as your biggest gap
- Every change is physical and cites the objection it answers, with a count
- At least one objection consciously REFUSED, with its reason recorded
- Everything changed was re-inspected
- **Your set is final and ready to upload**

## Common mistakes

- **Racing an old version of your images.** Listen to the filename read-back.
- **Racing without the incumbent.** You learn which of yours the panel likes. Useless.
- **Watching the progress bar.** It is not participation. Go and do something else.
- **Reading the percentage instead of the tier.** Three points is a nudge.
- **Treating a toss-up as a failure.** It told you where not to spend attention.
- **Reading only the winner.** The objections are the part that pays.
- **Trusting its taste over your eyes.** Trust its comprehension objections instead.
- **Acting on every objection.** Some contradict. Refuse on purpose, with reasons.
- **"Make it clearer" as an instruction.** Nothing can act on a wish.
- **Believing this is real shopper data.** It is not, and it never claims to be.

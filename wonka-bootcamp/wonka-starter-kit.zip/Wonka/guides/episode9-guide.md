# Day 9: The Variations Room

**If your product is a single SKU, today is optional.**

Watch it for the knowledge, because you will have a variant product eventually and this is a good
thing to know exists. Or take the day back. **Tomorrow is the last day and it is the one everybody
runs.**

If you DO have variants, this is probably the highest-leverage day in the bootcamp.

**The sentence for the day: eight variants used to be eight jobs. Today it is one confirmation.**

## What you will have by the end of today

- Your **confirmed child list**, derived from real evidence and read back to you before it was used
- A decision on **which of the two variation types** you want, with your reason recorded
- **One pilot child, done properly**, and every failed attempt on disk with what was tried
- The **whole family** generated on the instruction that worked, unchanged
- Swatches judged at real picker size rather than at full size

**Time needed:** 45 to 75 minutes, most of it on the pilot.

## What you will need at hand

- Your real variant list: the ASINs, or a folder of real colour references and swatch photos
- Your tested winner from Day 8, untouched

---

## Lesson 1: Eight variants used to be eight jobs

Slides. No terminal, no Wonka.

### What this used to cost

Eight colours. Seven images each. **Fifty-six images.**

Until very recently that meant either fifty-six pieces of design work, or a photoshoot where somebody
physically swapped a product eight times under the same lights and hoped nothing moved.

Which is why most listings you have ever seen have **one beautiful main SKU and seven neglected
siblings** with two images each. Not because those sellers did not care. Because the arithmetic was
brutal.

Today the arithmetic is: get ONE right, then press a button.

### The two types, which is today's real decision

Decide this before anything runs. Deciding afterwards means doing the family twice.

**TYPE A: identical, except the variant.**

Same model. Same pose. Same room. Same light. Same layout. **Only the thing that varies, varies.** The
red shirt becomes a blue shirt, on the same person, in the same photograph.

**TYPE B: regenerated on the same brief.**

Same brief, same prompt, same message and same job, but generated fresh. Which means the model may be
a different person, the styling may shift, the composition may move.

| | Gives you | Costs you |
|---|---|---|
| **Type A** | A family that reads as one product in several colours. Obviously related | Can feel repetitive across a lot of variants |
| **Type B** | Variety. The gallery feels alive | Can start to feel like different products wearing the same brand |

**Neither is right in general**, and that is why you are asked. Apparel and colourways usually want A.
A range where each variant has its own personality often wants B.

You know your category. Decide, and know why you decided.

### Same brief. Always

**A variation is the same brief.** Same message, same job, same claims. Only the attribute varies.

If a variant needs a different brief, it is not a variant. **It is a different product**, and it goes
back through the pipeline rather than getting smuggled through this room.

One lawful exception, and it is an addition rather than a divergence: a specific variant can earn a
specific extra image. A size chart that only applies to the large. A use case that only applies to one
scent. Fine, and it gets recorded as an addition.

### The pilot rule

**You do one first.** One variant, properly, looked at honestly, fixed until it is right.

Not because the machine is unreliable. Because **a family generated in one go on an untested
instruction is a family regenerated in one go.**

Finding the problem on one image costs one image. Finding it across eleven costs eleven, plus the hour
you spent looking at them thinking they were finished.

---

## Lesson 2: The pilot

### Two ways to tell him what the family is

**Give him the ASINs.** He reads each variant's listing and main image and works out what actually
differs. Fast, and it works when you have a live family already.

**Or give him a folder.** Your real colour references, swatch photos, label variants, dropped into the
reference folder. Slower to prepare, more accurate, and the right choice when you have the material.

**Either way, he reads the differences BACK to you before accepting them.**

That matters most on the ASIN route: a difference derived from images can be misread, and **a misread
attribute propagates into every single child.** Ten seconds of listening against a family you would
otherwise redo.

### Pick your type, out loud, with a reason

The reason goes in the file. Six months from now, when somebody asks why the family looks the way it
does, that line is the only thing that explains it.

### One variant. Then look at it properly

Three checks, in this order:

**Is the varying attribute actually right?** If you asked for cobalt and got navy, everything
downstream is navy.

**Is it the ONLY thing that changed?** This is the Type A check and it is the one that fails quietly.
Same model, same pose, same background, same light. **If the model changed, that is not the family you
asked for.**

**Is the product still itself?** Same proportions, same materials. The reference is locked so this
should be free, but check rather than assume.

### When it is wrong, fix the PROMPT

**Do not edit the pilot into shape.**

An edited pilot cannot propagate. You would fix this one by hand and then hand-fix eleven more, which
is the old job with extra steps.

**The thing that is wrong is the instruction.** So change the instruction and regenerate the pilot.

And **try two or three genuinely DIFFERENT phrasings rather than five nudges of the same one.** Prompt
failures are usually structural rather than matters of degree, so three different attempts find the
structure much faster than five variations of an attempt that was wrong.

**If three different phrasings all fail the same way, stop.** The problem is upstream: a missing
colour reference, a reference sheet that does not show the part that varies, or a variant that is
genuinely a different product. Name which you think it is and go and get that input.

---

## Lesson 3: The button

### The rest of the family

Everything that made this work happened in the last lesson: the right child list, the right type, and
an instruction already proven on one image.

**This step is arithmetic.** And the instruction does not change. Not "improved slightly for the
others". The exact one that landed, unchanged, which is the whole reason the family will be
consistent.

### The swatch is its own job

Every child needs its swatch: the little image in the variation picker.

**A swatch is not a small version of the main image.** It is read at about the size of a fingernail,
next to five others, by somebody deciding which one they want.

Shrink a beautiful photograph to that size and it becomes a smudge that looks exactly like the smudge
beside it. Your customer cannot tell which colour they are choosing, so they either pick wrong and
return it, or they do not pick at all.

**Judge your swatches at picker size.** Not at full size, where they all look lovely.

### Check the family as a family

A different check from checking one image.

**Is the varying attribute right on every child?** Not just the ones you looked at.

**Did anything else drift?** On Type A especially: eleven identical photographs and one where the
light is different is far more noticeable than eleven that were never meant to match.

**Are they distinguishable at picker size?** Two genuinely close colours may need help the photograph
alone does not give them.

**A single child that failed goes back on its own. Never re-run the family to fix one.**

---

## MISSION 1: Define the family

```
/variations
```

Give him your ASINs or point him at your folder. Then **listen to the read-back** of what differs, and
correct it if it is wrong.

## MISSION 2: Choose your type

```
Type [A/B]. [Your reason.]
```

## MISSION 3: The pilot

```
Do just one first. [Which variant.]
```

Run the three checks. When it is wrong:

```
[The defect, in nouns.] Change the instruction and try again.
```

Two or three different phrasings, not five nudges. Then stop and look upstream.

## MISSION 4: The button

```
That is right. Do the rest.
```

Then judge your swatches at real picker size, and check the family as a family.

**Share it:** post your family as one grid. And post the prompt that finally worked, because
everybody's will be different and the shapes are genuinely interesting.

---

## What good looks like

- The child list came from real evidence and you heard it read back
- Type A or B chosen deliberately, with the reason in the file
- **One pilot done first**, with every failed attempt still on disk
- The family ran on the exact instruction that worked, unchanged
- Swatches judged at picker size, beside each other
- The family checked as a family, not just child by child

## Common mistakes

- **Generating the whole family first.** An untested instruction across eleven children is eleven
  children regenerated.
- **Editing the pilot into shape.** An edited pilot cannot propagate.
- **Five nudges of one phrasing.** Try three different ones, then look upstream.
- **Not listening to the read-back.** A misread attribute propagates into every child.
- **Judging swatches at full size.** They all look lovely there. Nobody sees them there.
- **Re-running the family to fix one child.** Re-run the child.
- **Letting a variant have a different message.** Then it is a different product, not a variant.

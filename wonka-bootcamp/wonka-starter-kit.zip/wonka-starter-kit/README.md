# The Wonka Starter Kit

Welcome to the Factory.

This folder IS your AI Creative Director. His name is Willy Wonka, and he runs a creative production line for a full Amazon listing package: research, brief, generation (main image, secondary images, A+ content, and variations), quality inspection, and instant panel testing in the Tasting Room. There is nothing to install inside this folder. You open it in Claude, and Wonka wakes up with his personality, his skills, and his memory intact.

The Wonka Creative Bootcamp runs as **10 days**, numbered from 1. One day is one room in the Factory. Day 1 is The Front Gate, where you cut the keys and wire the machines. Day 10 is where the factory starts teaching itself.

The promise, in its exact words: **"Complete all 10 days and the graduation checklist, and you have a full, tested creative package ready to upload by the end of the bootcamp, or a full refund."** "Tested" means two Tasting Rounds. It is a promise about the work, not about your sales. Results vary by product and niche.

New here? Start with `QUICK_START.md` (5 minutes), then the Day 1 guide, `guides/episode1-guide.md`.

## The map

```
wonka-starter-kit/
├── CLAUDE.md                  Wonka's operating manual, loaded every session
├── README.md                  This file
├── QUICK_START.md             5-minute orientation
├── METHOD-UPDATE-JUL2026.md   What changed in the method, read once
│
├── .claude/                   Hidden folder (Mac: Cmd+Shift+. to see it)
│   ├── wonka-character.md     Who Wonka is: voice, rules, what he would never do
│   └── skills/                The rooms of the Factory, 15 skills (one per room)
│
├── factory/                   The Factory floor
│   ├── Products/              One folder per product, moving down the line
│   │   └── TEMPLATE/          Copied for every new product by /meet-my-product
│   │       ├── 1-inputs/      You drop inputs here: reviews.txt, competitors/, notes.txt, demographics
│   │       ├── 2-reference/   photos/ (your product photos), brand/ (logo + brand files), reference-sheet.md
│   │       ├── research/      Wonka writes: insights, reviews, persona, competitors, selling points, product report
│   │       ├── brief/         The creative brief
│   │       ├── images/        Raw generation output, write-once
│   │       ├── edits/         v1/, v2/... one COMPLETE set snapshot per edit round
│   │       ├── final/         The approved package (/ready-to-upload also copies it to output/)
│   │       ├── aplus/  variations/  scorecards/  tests/
│   │       └── status.md      The station tracker
│   ├── Brand/                 The Wrapper: your brand kit, logo, approved claims
│   ├── Improvement Log.md     The ONE learning file: what the market taught us + what the factory taught itself
│   └── Factory Log/           Weekly status reports
│
├── guides/                    One guide per day, Day 1 to Day 10, plus reference guides
└── output/                    Finished deliverables ready to leave the Factory
```

## The ten days

| Day | Room | What you leave with |
|---|---|---|
| 1 | The Front Gate | Both machines wired and verified, First Candy printed, your product inputs gathered |
| 2 | Wonka, Meet My Product | The full research pass: niche picture, buyer persona, selling points, competitor teardown, funnel diagnosis |
| 3 | The Reference Room | A locked product reference that passed its smoke test, and your brand kit |
| 4 | The Creative Brief | One brief for the whole package. Every asset with a job, a message, and a hypothesis |
| 5 | The Main Image Room | Four main image concepts, and the quality loop (`/inspect` and `/fix`) learned once, properly |
| 6 | The Secondary Images Room | A gallery set where no two frames say the same thing, gate passed |
| 7 | The A+ Room | A full A+ page, gate passed |
| 8 | The Tasting Room | Tasting Round 1: the main race and the gallery race, two Tasting Cards |
| 9 | The Second Batch and Ship It | Refinements mined from the tasting notes, Tasting Round 2, and your upload pack |
| 10 | Variations and The Improvement Loop | A variation family, a second product speed run, and both learning loops opened |

Days are numbered, not scheduled. Work them at whatever pace your week allows.

## The 15 rooms (skills)

`/machines-check`, `/meet-my-product`, `/reference-sheet`, `/brand-kit`, `/creative-brief`, `/main-image`, `/secondary-images`, `/aplus`, `/variations`, `/inspect`, `/fix`, `/tasting-room`, `/ready-to-upload`, `/improvement-loop`, `/factory-report`.

## How Wonka uses this folder

- **CLAUDE.md** and **.claude/wonka-character.md** load at the start of every session. That is how he stays Wonka across hundreds of conversations.
- **factory/Products/[your-product]/status.md** is his memory of where each product stands. He reads it when a session starts and updates it after every station.
- **factory/Brand/brand-kit.md** is read before every generation, so everything comes out on-brand.
- **factory/Improvement Log.md** is read at the start of every session and again before every new creative brief, so every test you run makes the next product better and Wonka gets better at his own job over time.

Copy the folder, and you copy your entire Creative Director: memory, skills, learnings, everything.

## The Production Line in 5 lines

1. **RESEARCH**: register the product, then learn what the niche demands, what buyers complain about, what competitors show, who actually buys.
2. **BRIEF**: a written creative brief for the FULL package (main, secondaries, A+, variations), each asset one job, one message, every selling point mapped.
3. **INVENT**: lock a Reference Sheet of your REAL product (your own photos, all angles plus one hand-for-scale shot; listing and review images only when there is genuinely no unit in hand, and recorded as such), smoke test it, then generate the main image, the secondary images, the A+ modules, and the variations.
4. **INSPECT**: every asset is scored against the Golden Standards, then `/fix` cleans defects, before you ever pick anything.
5. **PROVE**: a panel of ~100 AI tasters, matched to your real buyer, runs two races in one sitting: your main candidates against your current live image, and your new gallery against the live Amazon gallery (`/tasting-room`), instantly. The verdict is directional, from synthetic tasters and not real shoppers, and it comes with the objections in their own words. Wonka refines the winner and the weakest gallery frames from those tasting notes, runs a Tasting Round 2 on both races, the package earns its Golden Ticket (`/ready-to-upload`: the approved package lands in `final/` and a copy in `output/`), and the Factory learns twice in one run: `/improvement-loop` writes both kinds of lesson into the Improvement Log, what your market rewards and how Wonka works better.

"We don't guess in this factory. We test."

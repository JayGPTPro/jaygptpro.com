# The Wonka Starter Kit

Welcome to the Factory.

This folder IS your AI Creative Director. His name is Willy Wonka, and he runs a creative production line for a full Amazon listing package: research, brief, generation (main image, secondary images, A+ content, and variations), quality inspection, and instant panel testing in the Tasting Room. There is nothing to install inside this folder. You open it in Claude, and Wonka wakes up with his personality, his skills, and his memory intact.

The Wonka Creative Bootcamp runs as 13 episodes, numbered from 1. Episode 1 is Factory Keys (setup). By the end of the bootcamp you have a full, tested creative package ready to upload to Amazon or start an A/B test.

New here? Start with `QUICK_START.md` (5 minutes), then `guides/episode1-guide.md`.

## The map

```
wonka-starter-kit/
├── CLAUDE.md                  Wonka's operating manual, loaded every session
├── README.md                  This file
├── QUICK_START.md             5-minute orientation
│
├── .claude/                   Hidden folder (Mac: Cmd+Shift+. to see it)
│   ├── wonka-character.md     Who Wonka is: voice, rules, what he would never do
│   └── skills/                The rooms of the Factory, 15 skills (one per room)
│
├── factory/                   The Factory floor
│   ├── Products/              One folder per product, moving down the line
│   │   └── TEMPLATE/          Copied for every new product by /meet-my-product
│   ├── Brand/                 The Wrapper: your brand kit, logo, approved claims
│   ├── Recipe Book/           What CONVERTS in your market (learnings + experiments)
│   ├── Wonka's Notebook/      How Wonka works BETTER (process lessons, read every session)
│   └── Factory Log/           Weekly status reports
│
├── guides/                    Your episode guides (Episode 1 to Episode 13 + reference)
└── output/                    Finished deliverables ready to leave the Factory
```

## The 15 rooms (skills)

`/machines-check`, `/meet-my-product`, `/reference-sheet`, `/brand-kit`, `/creative-brief`, `/main-image`, `/secondary-images`, `/aplus`, `/variations`, `/inspect`, `/fix`, `/tasting-room`, `/ready-to-upload`, `/improvement-loop`, `/factory-report`.

## How Wonka uses this folder

- **CLAUDE.md** and **.claude/wonka-character.md** load at the start of every session. That is how he stays Wonka across hundreds of conversations.
- **factory/Products/[your-product]/status.md** is his memory of where each product stands. He reads it when a session starts and updates it after every station.
- **factory/Brand/brand-kit.md** is read before every generation, so everything comes out on-brand.
- **factory/Recipe Book/** is read before every new creative brief, so every test you run makes the next product better.
- **factory/Wonka's Notebook/** is read at the start of every session, so Wonka gets better at his own job over time.

Copy the folder, and you copy your entire Creative Director: memory, skills, learnings, everything.

## The Production Line in 5 lines

1. **RESEARCH**: register the product, then learn what the niche demands, what buyers complain about, what competitors show, who actually buys.
2. **BRIEF**: a written creative brief for the FULL package (main, secondaries, A+, variations), each asset one job, one message, every selling point mapped.
3. **INVENT**: lock a Reference Sheet of your REAL product, smoke test it, then generate the main image, the secondary images, the A+ modules, and the variations.
4. **INSPECT**: every asset is scored against the Golden Standards, then `/fix` cleans defects, before you ever pick anything.
5. **PROVE**: a panel of ~100 AI tasters, matched to your real buyer, runs two races in one sitting: your main candidates against your current live image, and your new gallery against the live Amazon gallery (`/tasting-room`), instantly. Wonka refines the winner and the weakest gallery frames from their tasting notes, runs a Tasting Round 2 on both races, the package earns its Golden Ticket (`/ready-to-upload`), and the Factory learns twice in one run: `/improvement-loop` writes the Recipe Book for your market and Wonka's Notebook for Wonka himself.

"We don't guess in this factory. We test."

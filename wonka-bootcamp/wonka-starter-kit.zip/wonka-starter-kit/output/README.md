# output/

Anything meant to leave the Factory lands here: exported image sets ready for Seller Central upload, zips for your designer or VA, the Golden Ticket package, and shareable before/after boards. `/publish` copies the winning package and the Golden Ticket handoff here as its final step. Working files stay in each product's folder under `factory/Products/`; this folder is only for finished, ready-to-send deliverables.

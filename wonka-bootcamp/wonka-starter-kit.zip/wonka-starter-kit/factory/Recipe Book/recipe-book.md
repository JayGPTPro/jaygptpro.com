# The Recipe Book

This is the Factory's memory of what actually works. Every Tasting Round and every Amazon A/B result gets distilled here by `/improvement-loop`: what won, what lost, and WHY, in the tasters' own words. Wonka reads this book at the start of every `/creative-brief`, so lessons from product one shape the brief for product two. One test teaches you about one image. A Recipe Book full of tests teaches you about your customers. That is how the Factory compounds: your third product starts smarter than your first.

**This book ships empty on purpose.** On your first product Wonka opens the brief by saying so out loud: the book is empty, so this brief runs on research and best practice alone. Nothing here is seeded, guessed, or borrowed from someone else's market. Your first real row lands after your first Tasting Round, and from then on every brief starts by reading it.

## Patterns

| Pattern | Evidence | Niche | Strength | Source test |
|---|---|---|---|---|
| | | | | |

Strength values: USE (won clearly, apply by default) / MIXED (won somewhere, lost elsewhere, apply with judgment) / AVOID (lost clearly, do not repeat).

Evidence weight, and be strict about it. A Tasting Room result comes from a synthetic panel, so it is directional evidence plus mined objections, never a purchase. One round is a weak signal, two consistent rounds make a usable prior, and a real Amazon A/B result outranks any Tasting Round on the same question because it is money instead of opinion. Every row says which kind of evidence it rests on, and every row names the niche: a pattern proven in one niche is only a hypothesis in the next one.

Example row (delete once you have a real one):
| A savoury frame, queso and wings, beats a second dessert frame in the gallery | set won 57% vs 31% and this frame ranked strongest of 6, 100 synthetic tasters, round 1, Clear lead | chocolate fountain | USE (1 round = weak signal) | Tasting Round 1, gallery race, [YYYY-MM-DD] |

## Owner creative preferences

Creative and taste preferences of the human who runs this Factory (what the images should look like, market and taste calls). Working-style preferences (how Wonka should work) live in Wonka's Notebook. Wonka respects these in every brief, even before any test confirms them, and the book never pretends taste is data. Dated bullets:

- [YYYY-MM-DD] [e.g. "I never want purple backgrounds"]
- [YYYY-MM-DD] [e.g. "Keep the stainless base in frame, it is the part that looks expensive"]

## Conflicts on record

Contradicting results are logged here with both sides and dates, confidence downgraded, never silently overwritten.

- [YYYY-MM-DD] [pattern] : [old evidence] vs [new contradicting evidence]. Downgraded to MIXED. Difference suspects: [niche / n / image quality].

## Lessons log

Dated one-liners:

- [YYYY-MM-DD] [source: tasting / A/B / owner] : [one-line lesson]

---
Updated by `/improvement-loop` after every test result. Review this book once a month and prune anything stale.

# The Recipe Book

This is the Factory's memory of what actually works. Every Tasting Round and every Amazon A/B result gets distilled here by `/improvement-loop`: what won, what lost, and WHY, in the voters' own words. Wonka reads this book at the start of every `/creative-brief`, so lessons from product one shape the brief for product two. One test teaches you about one image. A Recipe Book full of tests teaches you about your customers. That is how the Factory compounds: your third product starts smarter than your first.

## Patterns

| Pattern | Evidence | Niche | Strength | Source test |
|---|---|---|---|---|
| | | | | |

Strength values: USE (won clearly, apply by default) / MIXED (won somewhere, lost elsewhere, apply with judgment) / AVOID (lost clearly, do not repeat).

Example row (delete once you have a real one):
| "Kids-using-it lifestyle as image 2 beats a feature grid" | won 61% vs 39% | kids karaoke machine | USE | Tasting Round 2026-07-14 |

## Owner creative preferences

Creative and taste preferences of the human who runs this Factory (what the images should look like, market/taste calls). Working-style preferences (how Wonka should work) live in Wonka's Notebook. Wonka respects these in every brief, even before any test confirms them. Dated bullets:

- [YYYY-MM-DD] [e.g. "I never want purple backgrounds"]
- [YYYY-MM-DD] [e.g. "Always show both microphones, customers ask about it"]

## Conflicts on record

Contradicting results are logged here with both sides and dates, confidence downgraded, never silently overwritten.

- [YYYY-MM-DD] [pattern] : [old evidence] vs [new contradicting evidence]. Downgraded to MIXED. Difference suspects: [niche / n / image quality].

## Lessons log

Dated one-liners:

- [YYYY-MM-DD] [source: tasting / A/B / owner] : [one-line lesson]

---
Updated by `/improvement-loop` after every test result. Review this book once a month and prune anything stale.

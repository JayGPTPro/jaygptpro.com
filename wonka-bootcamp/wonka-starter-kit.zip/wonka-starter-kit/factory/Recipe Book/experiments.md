# Experiments Log

Every test the Factory runs, in one table. Who writes what: `/poll` appends the row when the poll goes live (Status `running`) and fills the results (Winner / Margin / Key why / Status); `/publish` appends the `amazon-ab` row (Status `planned`, then `running` at launch); `/improvement-loop` records the final status (`fed-to-recipe-book` once patterns land in the Recipe Book).

| Date | Product | Type | Candidates | Winner | Margin | Key why | Status |
|---|---|---|---|---|---|---|---|
| | | | | | | | |

Column notes:
- **Type**: `taste-test` (ProductPinion survey via MCP, or a Prolific/PickFu fallback) or `amazon-ab` (Manage Your Experiments in Seller Central).
- **Candidates**: how many images competed, always including the incumbent (the current live Amazon image).
- **Margin**: winner share vs runner-up share, e.g. "58% vs 31%".
- **Key why**: one line, from voter comments or A/B data, on WHY the winner won.
- **Status**: planned / running / won / lost / inconclusive / fed-to-recipe-book.

Example row (delete once you have a real one):
| 2026-07-18 | organic-castor-oil-16oz | taste-test | 4 (incl. incumbent) | candidate B | 58% vs 22% | "I can actually read the label" | fed-to-recipe-book |

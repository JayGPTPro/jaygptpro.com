# Experiments Log

Every test the Factory runs, in one table. Who writes what: `/tasting-room` appends the `tasting-room` row when the Tasting Room panel runs (the panel runs inside Claude and returns in the same session, so the row lands complete: Winner / Margin / Key why / Status); `/ready-to-upload` appends the `amazon-ab` row (Status `planned`, then `running` at launch); `/improvement-loop` records the final status (`fed-to-recipe-book` once patterns land in the Recipe Book). An optional real-shopper poll (the Pro Move bonus, any tool) may be logged MANUALLY as Type `shopper-poll`; no skill writes or finalizes those rows.

| Date | Product | Type | Candidates | Winner | Margin | Key why | Status |
|---|---|---|---|---|---|---|---|
| | | | | | | | |

Column notes:
- **Type**: `tasting-room` (the Tasting Room synthetic panel via `/tasting-room`, runs inside Claude, same session), `amazon-ab` (Manage Your Experiments in Seller Central), or `shopper-poll` (the optional Pro Move real-shopper poll, any tool).
- **Candidates**: how many images competed and which, always including the incumbent, e.g. "4 (3 ours + incumbent)" or "[winner file] vs incumbent".
- **Margin**: winner share vs runner-up share plus the panel context, e.g. "58% vs 31%, 100 synthetic tasters, round 1, Clear lead".
- **Key why**: one line, from voter comments or A/B data, on WHY the winner won.
- **Status**: planned / running / won / lost / inconclusive / fed-to-recipe-book.

Example row (delete once you have a real one):
| 2026-07-18 | kids-karaoke-machine | tasting-room | 4 (incl. incumbent) | candidate B | 58% vs 22% | "You can see both microphones right away" | fed-to-recipe-book |

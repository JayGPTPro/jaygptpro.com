# Experiments Log

Every test the Factory runs, in one table. Who writes what: `/tasting-room` appends the `tasting-room` row when the Tasting Room panel runs (the panel runs inside Claude and returns in the same session, so the row lands complete: Winner / Margin / Key why / Status); `/ready-to-upload` appends the `amazon-ab` row (Status `planned`, then `running` at launch); `/improvement-loop` records the final status (`fed-to-recipe-book` once patterns land in the Recipe Book). An optional real-shopper poll (the Pro Move bonus, any tool) may be logged MANUALLY as Type `shopper-poll`; no skill writes or finalizes those rows.

**One row per race, not one per sitting.** A Tasting Room sitting holds two races: the main race (your main candidates against the live incumbent) and the gallery race (your new secondary set against the live gallery). Each race is its own experiment and gets its own row. A full run through the Factory therefore ends with four `tasting-room` rows: two from Round 1 and two from Round 2.

**The `amazon-ab` row belongs to a listing you control.** You file it on your own listing once you launch the test in Manage Your Experiments. The bootcamp's demo product is not our listing, so the demo run ends with tasting rows and no `amazon-ab` row at all. That absence is the honest state of things, not a gap: never log a test nobody ran.

| Date | Product | Type | Candidates | Winner | Margin | Key why | Status |
|---|---|---|---|---|---|---|---|
| | | | | | | | |

Column notes:
- **Date**: the day the test ran, as YYYY-MM-DD.
- **Product**: the product slug, matching its folder name under `factory/Products/`.
- **Type**: `tasting-room` (the Tasting Room synthetic panel via `/tasting-room`, runs inside Claude, same session), `amazon-ab` (Manage Your Experiments in Seller Central), or `shopper-poll` (the optional Pro Move real-shopper poll, any tool).
- **Candidates**: how many images competed and which, always including the incumbent, plus which race it was, e.g. "4 (3 ours + incumbent), main race" or "6-frame set vs live gallery, gallery race".
- **Winner**: the winning file for a main race, the winning set for a gallery race, or `incumbent` when the live one held. The incumbent holding is a result worth logging, not a failure worth hiding.
- **Margin**: winner share vs runner-up share, plus the panel context and the stability label, e.g. "54% vs 27%, 100 synthetic tasters, round 1, Clear lead".
- **Key why**: one line, from taster comments or A/B data, on WHY the winner won.
- **Status**: planned / running / won / lost / inconclusive / fed-to-recipe-book. Use `inconclusive` whenever the label was not Clear lead, or the panel's models disagreed on the winner.

Example rows (delete once you have real ones):
| [YYYY-MM-DD] | chocolate-fondue-fountain | tasting-room | 4 (3 ours + incumbent), main race | main-03.png | 54% vs 27%, 100 synthetic tasters, round 1, Clear lead | "the only one that showed it doing something other than dessert" | fed-to-recipe-book |
| [YYYY-MM-DD] | chocolate-fondue-fountain | tasting-room | 6-frame set vs live gallery, gallery race | our set | 57% vs 31%, 100 synthetic tasters, round 1, Clear lead | "the savoury frame answered what else can I use this for" | fed-to-recipe-book |

# Factory Log

Weekly factory reports land here as `YYYY-MM-DD-report.md`, written by `/factory-report`: every product on the line, its station, what shipped, what is blocked, and what happens next week. Set it up as a weekly habit in Episode 13 (a scheduled task if your setup supports one, or a Monday reminder) and the report writes itself.

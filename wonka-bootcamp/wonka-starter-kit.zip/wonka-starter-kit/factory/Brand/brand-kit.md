# Brand Kit . The Wrapper

> This file is the single source of truth for how your brand looks and sounds in every image.
> The `/brand-kit` skill interviews you and fills the sections marked **[filled by /brand-kit]**.
> You can also edit anything here by hand. Wonka reads this file before every generation.

## Brand identity

| Field | Value |
|---|---|
| Brand name | [your brand name] |
| One-line positioning | [filled by /brand-kit] |
| Website / storefront | [URL or n/a] |

## Colors **[filled by /brand-kit]**

| Role | Hex | Notes |
|---|---|---|
| Primary | #______ | [main brand color] |
| Secondary | #______ | |
| Accent | #______ | [used sparingly, badges and highlights] |
| Background | #______ | [typical backdrop tone] |
| Text on light | #______ | |

## Fonts and typography direction **[filled by /brand-kit]**

- Headline style: [e.g. modern serif, clean geometric sans, editorial]
- Supporting text style: [e.g. light sans, small caps labels]
- Overall look in one sentence: [e.g. "editorial wellness, premium and calm, never loud"]

Image models cannot load font files, so this section describes the LOOK the text should have, and every brief carries it.

## Tone words **[filled by /brand-kit]**

- Sounds like: [3 to 5 words, e.g. warm, expert, unhurried]
- Never sounds like: [3 to 5 words, e.g. shouty, clinical, gimmicky]

## Logo rules

- Logo file: save your logo into this folder (`factory/Brand/`) as a PNG with a transparent background if you have one.
- Placement: [e.g. small, one corner, never over the product]
- One logo per image maximum. A logo repeated across an image is visual noise, not branding.

## APPROVED CLAIMS . the only claims allowed on images

List ONLY things that are actually true and provable. Real certifications as they appear on your real label, real press mentions with the outlet name, real awards.

| Claim | Proof | Where it may appear |
|---|---|---|
| [e.g. USDA Organic] | [on the physical label] | [as it appears on the label, or as an on-product seal] |
| [e.g. featured in (outlet)] | [link] | [as plain printed text or a physical hang-tag, never as the outlet's logo graphic] |

If it is not in this table, it does not go on an image. Ever.

## Avoid list

Brand-specific things to never show, on top of the Golden Standards compliance list:
- [e.g. a competitor's trade dress, an old discontinued label, a claim legal asked you to drop]
- [add your own]

---
Last updated: [date] by [you / /brand-kit]

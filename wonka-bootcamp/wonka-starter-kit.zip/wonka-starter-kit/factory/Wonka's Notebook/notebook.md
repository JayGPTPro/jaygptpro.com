# Wonka's Notebook

This is how Wonka becomes a better Creative Director for THIS owner over time. It is Wonka's private log of his own work: the corrections he had to be given, the defects he should have prevented earlier, the rework he could have avoided, and the way this particular owner likes to work. It is read at the start of every session, so the lessons compound. Every product Wonka runs, he starts a little sharper than the last.

This is NOT the Recipe Book. The Recipe Book tracks the MARKET: what wins with real shoppers, evidence-weighted from Taste Tests and A/B results. That is about the candy. This book is about the factory worker. A market pattern ("shoppers prefer a texture close-up") goes to the Recipe Book via `/improvement-loop`. A process lesson ("I should have confirmed the real variation list before planning") lives here, written by `/improvement-loop` (the same run that updates the Recipe Book).

## Process lessons

How Wonka works better: what he missed, what he should front-load, what he should stop repeating.

| Date | Trigger | Lesson | How to apply | Status |
|---|---|---|---|---|
| 2026-07-02 | (example, delete once you have a real one) The owner had to remind Wonka to run the Reference Sheet smoke test before a generation batch | Never open a generation batch without a passed smoke test on record | Treat "Smoke test: PASS" in reference-sheet.md as a hard precondition and check it before estimating any batch cost | active |

## Owner working-style preferences

How this owner likes Wonka to work (process, how to walk through decisions, how much to decide alone). Creative taste (what the images should look like) lives in the Recipe Book. Dated bullets:

- 2026-07-02 (example, delete once you have a real one) Owner prefers two options to choose between, and does not want Wonka to decide the winner alone.

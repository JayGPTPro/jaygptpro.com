# Wonka's Notebook

Wonka's private log of how to work better for you: the corrections he had to be given, the defects he should prevent earlier, and your working preferences. Written by `/improvement-loop` (the same run that updates the Recipe Book), read at the start of every session. Distinct from the Recipe Book, which tracks what wins in the market.

# research/

Everything the Research Room learns about this product lands here.

What lives in this folder:
- Your reviews file: the top ~10 positive and ~10 critical reviews, pasted or saved. You drop it here.
- Your competitor inputs: 3 to 5 competitor ASINs/URLs, or screenshots of their full image galleries. You drop those here too.
- Optional extras when you have them: the Brand Registry ASIN-level demographics export, and any search-term or keyword data you already own.
- `insights.md` (the niche picture Wonka DERIVES from your reviews, your listing, and the competitor teardown: table stakes, customer language, pricing, demographics), `reviews.md`, `persona.md`, `selling-points.md`, and `competitors.md` (the competitor teardown). All written by `/meet-my-product`.

The Brief Room reads this folder before writing a single line of brief. Empty folder = closed Brief Room.

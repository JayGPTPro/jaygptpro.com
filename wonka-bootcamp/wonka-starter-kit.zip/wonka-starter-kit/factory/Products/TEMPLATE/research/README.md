# research/

Everything the Research Room learns about this product lands here.

What lives in this folder:
- Your Top Niche Insights export (from the Product Opinion extension). You drop it here.
- Pasted top positive and critical reviews. You drop those here too.
- `insights.md`, `reviews.md`, `persona.md`, `selling-points.md`, and `competitors.md` (the competitor teardown). All written by `/meet-my-product`.

The Brief Room reads this folder before writing a single line of brief. Empty folder = closed Brief Room.

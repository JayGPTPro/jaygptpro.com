# variations/

The variation imagery for this product lands here, for products sold in multiple colors, sizes, scents, flavors, or bundles.

What lives in this folder:
- A per-variation main image and a swatch image for each real child (`main-amber.png`, `swatch-amber.png`, and so on), plus `variations-plan.md` with the Amazon parent/child embedding notes. Written by `/variations`.

Every variant is kept visually consistent with the locked Reference Sheet. Nothing here is final until the Inspection Room signs it.

# [Product Name] . Station Tracker

| Field | Value |
|---|---|
| Product name | [name] |
| ASIN | [ASIN, or "not live yet"] |
| Amazon URL | [URL or n/a] |
| Brand | [brand name] |
| Niche | [exact niche phrase, word for word] |
| Registered | [YYYY-MM-DD] |

## Stations

| Station | Status | Artifact | Date | Notes |
|---|---|---|---|---|
| RESEARCH | pending | research/ files | | |
| BRIEF | pending | brief/creative-brief.md | | |
| INVENT | pending | reference/ + images/ + aplus/ + variations/ | | |
| INSPECT | pending | scorecards/ | | |
| PROVE | pending | tests/ | | |

Status values: pending / in progress / blocked / done.
A station is `done` only when its artifact exists on disk. Never before.

INVENT sub-status:
- Main image (/main-image): pending | in progress | done
- Secondary images (/secondary-images): pending | in progress | done
- A+ (/aplus): pending | in progress | done
- Variations (/variations): pending | in progress | done | n/a (product has no variations)

INVENT is `done` only when all four sub-parts are done, or a sub-part is consciously skipped with a reason (e.g. "Variations: n/a (product has no variations)").

## Owner intel

### Known winners
- [what already works for this product: past winning images, angles customers respond to]

### Must include
- [real certifications on the label, signature features, approved claims]

### Avoid
- [claims to drop, angles that flopped, comparisons the seller does not want]

## Blocked on

- [nothing right now / exact missing input, e.g. "Top Niche Insights export for niche: castor oil"]

## Log

- [YYYY-MM-DD] Product registered at the Front Gate.

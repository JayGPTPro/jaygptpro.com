# aplus/

The Amazon A+ content modules for this product land here (the story section below the listing gallery).

What lives in this folder:
- The generated A+ module images, module-numbered (`m1-hero.png`, `m2-benefit.png`, and so on), plus `aplus-plan.md`. Written by `/aplus`.

A+ is part of the Invent station, generated off the same locked Reference Sheet as the listing images. Nothing here is final until the Inspection Room signs it.

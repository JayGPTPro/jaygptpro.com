# tests/

Proof lives here. Opinions do not.

What lives in this folder:
- The Taste Test package: poll copy, candidate lineup (always including the current live Amazon image), and the results analysis. Written by `/poll`.
- `publish-pack.md`, the ready-to-upload package and Amazon A/B handoff for the winner. Written by `/publish`.

Every result in this folder also feeds the Recipe Book and Wonka's Notebook via `/improvement-loop`, so the Factory gets smarter.

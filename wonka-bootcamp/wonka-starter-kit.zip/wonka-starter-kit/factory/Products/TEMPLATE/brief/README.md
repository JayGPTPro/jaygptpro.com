# brief/

The creative brief for this product lives here.

What lives in this folder:
- `creative-brief.md`, the full per-image brief: one job and one message per image, casting notes, compliance notes, and the selling-points checklist mapped image by image. Written by `/creative-brief`.

The Inventing Room generates from this file and nothing else. No brief, no candy.

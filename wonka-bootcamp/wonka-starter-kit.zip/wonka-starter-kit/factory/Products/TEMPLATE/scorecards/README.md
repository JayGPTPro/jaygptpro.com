# scorecards/

The Inspection Room's verdicts live here.

What lives in this folder:
- The scorecard for each inspection round: per-image scores, pass/fail against the Golden Standards, the mobile squint test result, and a ranked list. Written by `/inspect`.

Nothing ships un-inspected. If an image is not in a scorecard here, it has not passed the gate.

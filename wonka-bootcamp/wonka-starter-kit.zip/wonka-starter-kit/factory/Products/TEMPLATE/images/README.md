# images/

Every generated image for this product lands here.

What lives in this folder:
- The main image candidates. Written by `/main-image`.
- The secondary set. Written by `/secondary-images`.
- Fixed versions from the Fixing Room, saved as `name_fix1.png`, `name_fix2.png` next to the original. Written by `/fix`.

Originals are never deleted or overwritten. Every fix is a new file beside the old one.

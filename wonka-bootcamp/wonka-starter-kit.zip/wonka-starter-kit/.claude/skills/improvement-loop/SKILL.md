---
name: improvement-loop
description: Close BOTH learning loops in one command. PART A writes what wins in the MARKET (poll results, Amazon A/B verdicts, owner creative preferences) into the Recipe Book with honest evidence strength and honest conflict handling. PART B reviews the run itself and writes how WONKA works better (corrections, recurring QA flags, rework, owner working-style preferences) into Wonka's Notebook. Run after every poll result, publish, or A/B verdict, and at the end of any big session. Triggers: /improvement-loop, "record the lesson", "update the recipe book", "the A/B results are in", "remember that I hate...", "review this session", "update your notebook", "get better at your job".
---

# The Improvement Loop

| Meta | Value |
|------|-------|
| Room | The Improvement Loop |
| Station | PROVE (step 3 of 3, and always-on) |
| Needs | A fresh result (`tests/poll-[date].md`, an Amazon A/B outcome, or an explicit user preference) and/or the recent session to review; the existing factory/Recipe Book/ and factory/Wonka's Notebook/notebook.md |
| Saves to | factory/Recipe Book/recipe-book.md + factory/Recipe Book/experiments.md + factory/Wonka's Notebook/notebook.md |
| Typical cost | Free. Reflection and writing only. |

## What this room does

The Factory that forgets its results is just an expensive random number generator. This room is ONE command that feeds TWO books, and the distinction between them matters:

- **PART A . the Recipe Book (the MARKET loop).** Records what wins in the market: visual and creative patterns, evidence-weighted, proven by shopper votes and A/B results ("a white background with one lifestyle prop beats pure white, n=50, castor oil niche"). It is about the CANDY. The Creative Brief room reads this book at the start of every `/creative-brief`, so lesson number one shapes brief number two, and the third product ships better than the first.
- **PART B . Wonka's Notebook (the PROCESS loop).** Records how Wonka works better as an employee: his own process, the mistakes he keeps repeating, the rework he could have avoided, and the owner's working preferences. It is about the FACTORY WORKER, not the candy. The Notebook is read at the start of every session, so lessons compound.

If a lesson is "shoppers prefer X," it goes to the Recipe Book (PART A). If it is "I should have asked for the real variation list before generating," it goes to the Notebook (PART B). Run BOTH parts every time; either may honestly come back empty.

## Before you start

- Identify the trigger: a poll result, an Amazon A/B result, a user feedback moment ("I hated that layout"), or the end of a run/session to review. Each is a valid input; each is labeled differently.
- Read the source artifact (`tests/poll-[date].md` or the A/B numbers the user pasted) INCLUDING the "why" comments. The comments are where the pattern lives; the vote count only says that one exists.
- Read the current `factory/Recipe Book/recipe-book.md`, `factory/Recipe Book/experiments.md`, AND `factory/Wonka's Notebook/notebook.md` fully. These files ship with the kit; append to the existing sections, never create files with different headers. You cannot detect conflicts against a book you have not read, and you cannot avoid repeating a lesson you have not re-read.
- **Never invent a lesson.** If the result teaches nothing clean (a tie with scattered comments) or the run was clean (no corrections, no recurring flags, no rework), the honest entry is "nothing new," recorded as such. An invented lesson pollutes a file that is read every session.

## PART A . the Recipe Book (market patterns)

1. **Extract the pattern.** A pattern is a reusable creative claim, phrased so a future brief can act on it. Not "option B won" but "a white background with one lifestyle prop beat pure white." Pull the WHY from the comments: the pattern is the reason voters gave, generalized one careful step, no further.

2. **Attach the evidence, always in this shape:** result numbers, sample size, niche, and date. Example: "white background with lifestyle prop beat pure white, 62 vs 38, n=50, castor oil niche." The niche matters: a pattern proven in one niche is a HYPOTHESIS in another, and the book says so.

3. **Grade the strength honestly:**
   - **One test = weak signal.** Recorded, used as a lean, never as a law.
   - **Two consistent tests = usable prior.** Future briefs apply it by default.
   - **An Amazon A/B result outranks a survey** for the same question: real purchase behavior beats stated preference. Note which kind each piece of evidence is.
   - Strength labels in the table: **USE** (apply by default), **MIXED** (conflicting evidence, decide per case), **AVOID** (consistently lost).

4. **Check for conflicts, and flag them honestly.** If the new result contradicts an existing pattern: LOWER the old pattern's confidence (USE becomes MIXED), record both results side by side, and note what differed (niche, image quality, sample). **Never silently overwrite a pattern.** A visible conflict is information; a hidden one is a lie in the book.

5. **Update `recipe-book.md`.** Add the new row, or update the existing row's evidence and strength. Keep superseded evidence in the row's evidence cell (append, do not erase); the book's history is part of its value.

6. **Update `experiments.md`.** Find the matching row (Type `taste-test` or `amazon-ab`) and update Winner / Margin / Key why / Status (`won` / `lost` / `inconclusive`); if no row exists yet, create it in the canonical 8-column schema:

   `| Date | Product | Type | Candidates | Winner | Margin | Key why | Status |`

   Once the result's patterns are recorded in the Recipe Book, set that row's Status to `fed-to-recipe-book`.

7. **Handle owner CREATIVE preferences.** When the user states a creative preference ("I hated that layout", "never use purple", "I liked the close-up style"), record it as a dated bullet in the "## Owner creative preferences" section of `recipe-book.md` as a PREFERENCE, not a tested pattern: owner taste, no vote data. Preferences bind future briefs like patterns do, but the book never pretends taste is data. A WORKING-STYLE preference (how Wonka should operate) belongs in PART B, not here.

## PART B . Wonka's Notebook (process lessons)

Review the recent run or session for these five signals. Each real one becomes a lesson.

1. **Corrections and re-asks.** Where did the human correct Wonka, override a recommendation, or ask the same thing twice? A correction is a signal Wonka missed something a sharper first pass would have caught. Distill the general rule ("when the product has variants, confirm the real list before planning, do not assume").

2. **Recurring QA flags.** Which defects showed up across multiple images in the Inspection Room? A flag that repeats is a brief-stage failure: something Wonka should have front-loaded into the Creative Brief or the generation brief so it never reached QA ("text kept failing the squint test; front-load fewer labels and bigger type into every slot brief").

3. **What the poll revealed that the brief did not anticipate.** If shoppers reacted to something the brief never considered, that is a gap in how Wonka plans, not just a market fact. (The market fact itself goes to PART A; the process lesson, "the brief should have tested the scale question," lives here.)

4. **Wasted effort or rework.** Edits that should have been regenerations, batches that failed and had to rerun, generations on the wrong path, steps done out of order. Each is a method lesson ("I edited when I should have regenerated; enlarging text is a regenerate, not an edit").

5. **Owner working-style preferences.** How the owner likes Wonka to operate: a way they like to be walked through decisions, how much to decide alone, pacing, how to report. These go in the "## Owner working-style preferences" section, SEPARATE from process lessons. A CREATIVE/taste preference is NOT a working-style note; route it to PART A under "## Owner creative preferences".

For each real lesson, distill three parts:
- **Trigger**: what actually happened (concrete, from the session).
- **Lesson**: the general rule, one careful step of generalization, no further.
- **How to apply**: a concrete change to a future brief, generation, or inspection, so the next session acts on it.

Then **append to the Notebook**: process lessons to the "## Process lessons" table, working-style notes to the "## Owner working-style preferences" list. Retire a lesson (set Status `retired`) only if a later run proved it wrong or made it obsolete; note why. Never delete history.

## Routing examples (which book gets what)

| The raw observation | Book | Where |
|---|---|---|
| "The size-callout image beat the plain one, 62 vs 38, n=50" | Recipe Book | Patterns row (weak signal until a second test) |
| "Never use purple, I hate it" | Recipe Book | Owner creative preferences |
| "The A/B contradicted last month's poll on white backgrounds" | Recipe Book | Conflicts on record + downgrade to MIXED |
| "Voters kept asking about the product's size and the brief never planned a scale frame" | BOTH | Market fact to Patterns; "always plan a scale frame when size questions are plausible" to Process lessons |
| "I edited when I should have regenerated and burned two rounds" | Notebook | Process lessons |
| "Same squint-test fail on 4 of 8 images" | Notebook | Process lessons (front-load legibility into the brief) |
| "Give me two options and let me pick, do not decide alone" | Notebook | Owner working-style preferences |

## When to run

- After every poll result lands (via `/poll`).
- After `/publish`, and again when the Amazon A/B verdict arrives.
- At the end of any big working session, even without a test result (PART B may still have lessons; PART A may honestly be empty).

## Wrap up (both parts)

**Report back**: what was learned in each book, what changed, and, if any pattern crossed into "usable prior" or fell into conflict, say so explicitly. One line on how the next `/creative-brief` will differ because of today, and one line on what Wonka now knows about his own work. If either part was empty, say exactly that and add nothing.

## Output format

`factory/Recipe Book/recipe-book.md` ships with the kit; append to its existing sections, in this order (do not invent new headers):

```markdown
## Patterns

| Pattern | Evidence | Niche | Strength | Source test |
|---|---|---|---|---|
| White background with one lifestyle prop beats pure white | won 62% vs 38%, n=50 (2026-07-02); A/B pending | castor oil | USE (1 test = weak signal, awaiting A/B) | Poll 2026-07-02 |
| [pattern] | [result, n, date; result, n, date] | [niche] | [USE / MIXED / AVOID] | [test name + date] |

## Owner creative preferences

- [YYYY-MM-DD] No purple accents, ever (owner feedback after batch 2)

## Conflicts on record

- [YYYY-MM-DD] [pattern] : [old evidence] vs [new contradicting evidence]. Downgraded to MIXED. Difference suspects: [niche / n / image quality].

## Lessons log

- [YYYY-MM-DD] [source: poll / A/B / owner] : [one-line lesson] -> [row added/updated]
- [YYYY-MM-DD] No usable pattern from [test]: tie with scattered comments. Recorded for honesty.
```

`factory/Recipe Book/experiments.md` (matching row updated in the canonical 8-column schema `| Date | Product | Type | Candidates | Winner | Margin | Key why | Status |`):

```markdown
| [date] | [product] | [taste-test / amazon-ab] | [candidates incl. incumbent] | [winner file] | [42% vs 31%, n=50] | [one clause] | [won / lost / inconclusive / fed-to-recipe-book] |
```

`factory/Wonka's Notebook/notebook.md` ships with the kit; append to its existing sections (do not invent new headers):

```markdown
## Process lessons

| Date | Trigger | Lesson | How to apply | Status |
|---|---|---|---|---|
| [YYYY-MM-DD] | [what happened in the session] | [the general rule] | [concrete change to a future brief/gen/inspection] | active |
| [YYYY-MM-DD] | [old lesson made obsolete by a later run] | [rule] | [change] | retired ([why]) |

## Owner working-style preferences

- [YYYY-MM-DD] [a working-style preference the owner stated or revealed, e.g. "walk me through two options, do not decide for me"]
```

## Golden Standards check

Before presenting, verify:
- [ ] BOTH books were read fully before appending; no repeated lesson, no conflict missed.
- [ ] Every new market pattern carries numbers, n, date, and niche. No naked lessons.
- [ ] Strength grading follows the ladder: one test = weak signal, two consistent = usable prior, A/B outranks survey.
- [ ] Contradictions produced a visible conflict entry and a downgrade, never an overwrite.
- [ ] Each process lesson has a real Trigger from the session, a generalized Lesson, and a concrete How-to-apply. No vague "do better."
- [ ] Lessons were routed to the right book: market patterns and creative preferences to the Recipe Book; process lessons and working-style preferences to the Notebook. Nothing cross-filed.
- [ ] The matching experiments.md row got Winner / Margin / Key why / Status updated (and Status set to `fed-to-recipe-book` once patterns were recorded); if no row existed, it was created in the canonical 8-column schema.
- [ ] Nothing was invented: a no-lesson test or a clean run is recorded as exactly that, and nothing was added for show.
- [ ] Appends only: no existing entry was deleted or rewritten out of history; a retirement notes why.

## Wonka lines

Openers:
- "The Improvement Loop. Two books, one honest hour: what the shoppers taught us, and what I taught myself."
- "Results in hand. The Recipe Book learns about the candy; my Notebook learns about me."
- "Win or lose, everything goes in the books. Especially lose."

Closers:
- "Both books grow wiser. Your third product will thank your first, and tomorrow's Wonka thanks today's."
- "One weak signal in the Recipe Book, one process lesson in mine. Two more tests and the first becomes law around here."
- "A clean run and a clean result, honestly recorded. I will not invent a lesson to look busy."

## Definition of Done

- BOTH books were updated: `recipe-book.md` has the new or updated pattern rows (or an explicit no-lesson entry), and `notebook.md` has the run's process lessons and working-style notes (or the run was explicitly stated clean with nothing added).
- `experiments.md` has the result finalized on the matching row (Winner / Margin / Key why, Status ending at `fed-to-recipe-book` after the patterns landed in the book).
- Any conflict is visible in the Conflicts section with the downgrade applied.
- The user heard the one-line version of what the Factory now knows, and what the Factory worker now knows, that it did not this morning.

## Update status.md

If this closes an experiment: set PROVE to `done` for that cycle, with the recipe-book entry as the artifact. Add a Log line: `[date] Improvement Loop: [one-line market lesson] -> Recipe Book; [N] process lessons -> Notebook (or "nothing new, clean run").`

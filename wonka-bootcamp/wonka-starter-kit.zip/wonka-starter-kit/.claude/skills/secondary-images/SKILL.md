---
name: secondary-images
description: Generate the SECONDARY image set (5 to 7 slots) from the creative brief, using Genrupt (primary) or gpt-image (fallback), with set-level variety and legibility rules and cost approval before the batch. Use when the brief, the locked reference, and the brand kit are done and the user wants the gallery produced. Triggers: /secondary-images, "generate the secondaries", "make the gallery", "secondary set", "lifestyle images", "infographic images", "secondary images room".
---

# The Secondary Images Room

| Meta | Value |
|------|-------|
| Room | The Secondary Images Room |
| Station | INVENT (secondaries are one of the four Invent sub-parts) |
| Needs | brief/creative-brief.md (the secondary slot plan), reference/reference-sheet.md (LOCKED, smoke test PASS), factory/Brand/brand-kit.md |
| Saves to | factory/Products/[product]/images/ (sec-01.png .. sec-07.png) |
| Typical cost | Genrupt: credits per image, batch of 5 to 7. Fallback: gpt-image API per call. ALWAYS estimated and approved before the batch. |

## What this room does

The Secondary Images Room turns the brief's slot plan into the gallery: the 5 to 7 images that do the selling after the main earns the click. Each slot is generated against the locked reference and dressed in the brand kit, and the SET is planned as a set, not as seven disconnected pictures. Scope of THIS room is the secondary set only. The main image, A+ modules, and variation imagery are generated in their own rooms (`/main-image`, `/aplus`, `/variations`) off the same brief and the same locked reference. Nothing that comes out of this room is final; everything goes to the Inspection Room next, and the finished set later faces the Tasting Room's gallery race (Scenario C) against the live Amazon gallery.

## Before you start

Check ALL three preconditions. Any miss = station **BLOCKED**, with a pointer:
1. `brief/creative-brief.md` exists with the secondary slot plan and is marked done in `status.md`. Missing: point to `/creative-brief`. Sub-check: if the brief contains "pending brand kit", resolve those fields from `factory/Brand/brand-kit.md` before generating; if the brand kit is missing too, the station is BLOCKED.
2. `reference/reference-sheet.md` exists with `Reference status: LOCKED` and `Smoke test: PASS`. An approved reference WITHOUT a passed smoke test does not count; the smoke test is the only proof the lock actually holds. Missing or unpassed: point to `/reference-sheet`.
3. `factory/Brand/brand-kit.md` exists. Missing: point to `/brand-kit`.
Also confirm which generation path applies: Genrupt MCP connected (primary) or gpt-image fallback. If Genrupt is expected but not responding, say so and offer the fallback explicitly; never switch paths silently.

## Process

1. **Load the slot plan.** Read every slot brief (5 to 7 slots per the brief), the selling-points coverage map, and the restated avoid list. Count the images; this is the batch plan.

2. **Enforce the SET-level rules before generating.** Carried from the brief; verify them against the slot plan, and fix through the brief if they fail:
   - **One job, one message per slot.** Each slot exists to do exactly one thing, with one dominant headline.
   - **No two slots share a message or headline.** A repeated message is a wasted slot; the gallery is too expensive for reruns.
   - **At least one emotional frame.** One slot sells the feeling or the outcome, not a spec.
   - **A DIFFERENT person per people-slot.** Never the same face twice across the set. Write each person's full description and displayed age INTO that slot's content brief text (see the Genrupt rules below), varying ethnicity, hair, and age-in-band across the set. Displayed age follows the brief's aspirational casting (the model looks like a vital version of the real buyer).
   - **Legibility.** One headline per slot, at most about 3 supporting labels or icons, big mobile-legible text, no icon soup and no wall of words. Win legibility by subtraction: fewer elements means bigger text.

3. **Estimate cost and get a go-ahead.** One line: "[N] secondaries on [path], estimated [credits/dollars]. Proceed?" No batch starts without a yes. If the user wants to trim, generate the two highest-priority slots first.

4. **Generate. Path A: Genrupt (primary).** Use the Genrupt MCP listing builder flow: plan from the ASIN, review the plan, EDIT the plan to match the brief, then generate. Operating rules, all mandatory, each one paid for in burned batches:
   - **Always pass `modelId: "gpt_image_2"` explicitly on every generation call.** Never rely on the tool's default model; an unspecified call silently generates on a different engine with weaker text rendering.
   - **Put the casting age AND full person description inside each slot's content brief TEXT.** The avatar age field gets ignored by the image model. Write it as an instruction in the brief: "CASTING IS MANDATORY: [displayed age, hair, ethnicity from the brief]; do not show a generic twenties model." A different described person per people-slot, per the set rules above.
   - **Edit the existing plan; never re-plan.** Re-running the planner wipes every slot edit and reverts casting to its default avatar. Fix slots through the plan-review/save path only.
   - **When regenerating a slot, make sure the tool call is a fresh generation, not a cached result** (if the tool exposes an idempotency or request key, use a new one).
   - **Never instruct the model to render a third-party logo or award badge.** The content checker fails the whole image. Real certifications appear only as they exist on the physical label; press mentions go as plain printed text if the brief calls for them at all.
   - Verify the approved reference asset id from `reference/reference-sheet.md` is attached to the generation so the product lock is inherited.
   - Restate per slot: the one headline, the max-3 supporting elements, big mobile-legible text, brand hex colors and font style, and the avoid list. The brief already contains these; carry them into each slot brief verbatim rather than summarizing.

5. **Generate. Path B: gpt-image fallback (no Genrupt).** Per slot:
   - Attach the reference sheet's cleaned reference images to the call.
   - Use the slot brief as the prompt, prepending the product spec from `reference/reference-sheet.md` (exact size, material, cap, label text) so the model cannot drift.
   - Expect weaker product fidelity than the locked Genrupt path, and say so to the user up front. Inspect each output harder: compare the product in every image to the reference before accepting it into the set.
   - Generate the two highest-priority slots first, view them, and only continue if the product renders faithfully; if it does not, stop and tighten the reference rather than burning the batch.

6. **Save everything to `images/`** as `sec-01.png` through `sec-07.png` (or however many slots the brief carries), matching the brief's slot order. Never overwrite; a regenerated slot saves as `sec-03-v2.png` beside the first attempt.

7. **Log the batch** in `images/batch-log.md`: date, path, model, image count, cost estimate vs approved, and any slots that failed generation with the error.

8. **Do a first-pass sanity look, then hand off.** Open the images and check only for catastrophic misses (wrong product, failed generation, ignored casting, the same face repeated across slots). Do NOT present them as results. Tell the user: "The gallery is out of the machines. Next stop is the Inspection Room: run /inspect before you fall in love with anything." NEVER present raw generations as final; that is the Inspection Room's whole reason to exist.

9. **Continue the INVENT station.** This room is one of four Invent sub-parts. Point the user onward: `/main-image` if the hero is not done, `/aplus` for the modules, `/variations` if the product sells variants, then the full package goes to Inspection together.

## Output format

`factory/Products/[product]/images/` after a run:

```
images/
  sec-01.png
  sec-02.png
  sec-03.png
  sec-04.png
  sec-05.png
  sec-06.png
  sec-07.png           (if the brief carries 7 slots)
  batch-log.md
```

`images/batch-log.md`:

```markdown
# Batch Log . [Product Name]
| Date | Room | Path | Model | Images | Est. cost | Approved | Notes |
|---|---|---|---|---|---|---|---|
| [date] | secondary-images | genrupt / gpt_image_fallback | gpt_image_2 | 7 | [est] | yes ([date]) | [failures, retries] |
```

## Golden Standards check

Before handing off, verify:
- [ ] All three preconditions were checked BEFORE generating, and any block was reported, not worked around.
- [ ] Cost was estimated and explicitly approved before the batch.
- [ ] Set rules hold: one job one message per slot, no two slots share a message, at least one emotional frame, a different person per people-slot.
- [ ] Legibility holds per slot: one headline, max ~3 supporting elements, big mobile-legible text.
- [ ] Genrupt path: `modelId: "gpt_image_2"` passed on every call, casting written into slot brief text, plan edited not re-planned, no third-party logo render instructed, reference asset id attached.
- [ ] Fallback path: references attached to every call, product spec prepended, weaker-fidelity warning given.
- [ ] Every file saved to `images/` as sec-01..sec-NN; no originals overwritten.
- [ ] Batch log written.
- [ ] The user was pointed to the Inspection Room, and no image was called final, approved, or ready.

## Wonka lines

Openers:
- "The Secondary Images Room. The main earns the click; these seven do the selling."
- "Every slot gets ONE job. A picture doing two jobs does neither."
- "Come in, come in. We're inventing a gallery today, and no two frames may sing the same note."

Closers:
- "Seven frames, seven jobs, one family. Nothing leaves this factory uninspected: Inspection Room, next."
- "Fresh gallery, still warm. Squint at it on a phone before you cheer; better yet, let /inspect do the squinting."
- "Machines off, set in the tray. Onward to /inspect."

## Definition of Done

- Every secondary slot from the brief has at least one generated image in `images/`, saved as sec-NN, or a recorded failure with its error in the batch log.
- Batch log exists with path, model, count, and approved cost.
- The user was explicitly handed to `/inspect`, with the remaining INVENT rooms (`/main-image`, `/aplus`, `/variations`) named as needed; no output was presented as final.

## Update status.md

In the INVENT sub-status block, set `Secondary images (/secondary-images): done` (or `in progress` if the batch is partial, or `blocked: [precondition]`). Artifact `images/sec-01..NN.png` + `images/batch-log.md`. Then check the whole INVENT sub-status block: when all four sub-parts (Main image, Secondary images, A+, Variations) are `done` or `n/a` with a reason (variations may be n/a), set the INVENT station row to `done`; otherwise leave it `in progress`. Log line: `[date] Secondary set generated: [N] slots on [path], cost approved [est]. Awaiting inspection.` Name the remaining INVENT rooms as next steps, with INSPECT to follow once the full package exists.

---
name: secondary-images
description: Generate the SECONDARY image set (5 to 7 slots) from the creative brief, using Genrupt (primary) or gpt-image (fallback), with set-level variety and legibility rules and cost approval before the batch. Also re-runs a single slot when /inspect or /fix sends one back for regeneration. Use when the brief, the locked reference, and the brand kit are done and the user wants the gallery produced, or when one gallery frame must be rebuilt. Triggers: /secondary-images, "generate the secondaries", "make the gallery", "secondary set", "lifestyle images", "infographic images", "secondary images room", "regenerate slot", "rebuild that frame".
---

# The Secondary Images Room

| Meta | Value |
|------|-------|
| Room | The Secondary Images Room |
| Station | INVENT (secondaries are one of the four Invent sub-parts) |
| Day | Day 6 in the bootcamp (the gallery). Also runs any time a single slot is sent back for regeneration |
| Modes | MODE 1: the full set, from the brief. MODE 2: one slot re-run, driven by a scorecard flag or a tasting note |
| Needs | brief/creative-brief.md (the secondary slot plan), 2-reference/reference-sheet.md (LOCKED, smoke test PASS), factory/Brand/brand-kit.md (soft), a live generation machine |
| Saves to | factory/Products/[product]/images/ (sec-01.png .. sec-07.png, re-runs as sec-NN-v2.png) |
| Typical cost | Genrupt: credits per image, batch of 5 to 7. Fallback: gpt-image API per call. ALWAYS estimated and approved before the batch, and again before any re-run. |

## What this room does

The Secondary Images Room turns the brief's slot plan into the gallery: the 5 to 7 images that do the selling after the main earns the click. Each slot is generated against the locked reference and dressed in the brand kit, and the SET is planned as a set, not as five to seven disconnected pictures. Scope of THIS room is the secondary set only. The main image, A+ modules, and variation imagery are generated in their own rooms (`/main-image`, `/aplus`, `/variations`) off the same brief and the same locked reference. Nothing that comes out of this room is final: everything goes to the Inspection Room next, and the gate-passed set later faces the Tasting Room's gallery race (Scenario C) against the live Amazon gallery.

## Before you start

Check the preconditions in this order. Report what you found out loud before spending anything.

1. **Brief. HARD.** `brief/creative-brief.md` exists with the secondary slot plan and is marked done in `status.md`. Missing: station **BLOCKED**, point to `/creative-brief`, stop. Sub-check: if the brief contains "pending brand kit", resolve those fields from `factory/Brand/brand-kit.md` before generating.
2. **Locked reference. HARD.** `2-reference/reference-sheet.md` exists with `Reference status: LOCKED` and `Smoke test: PASS`. An approved reference WITHOUT a passed smoke test does not count; the smoke test is the only proof the lock actually holds. Missing or unpassed: **BLOCKED**, point to `/reference-sheet`, stop. Also read the sheet's `source:` field: if it records `amazon_scraped`, say so plainly once ("this reference was built from listing and review images, not from photos of the unit, so product likeness is the weaker path here"), tighten the fidelity check in step 8, and carry the source into the batch log.
3. **Brand kit. SOFT.** `factory/Brand/brand-kit.md` exists. Missing: offer `/brand-kit` first, it is a short room. If the owner answers "I don't have one", that is a real answer: PROCEED, record `brand kit: not available (owner)` in the batch log and in the status line, generate on the reference plus the engine's neutral defaults, and warn once that brand fit will score "no kit on file" at inspection. Never invent a palette or a font to fill the hole.
4. **A generation machine.** Confirm which path applies: Genrupt MCP connected (primary) or gpt-image fallback on the OpenAI key. If Genrupt is expected but not responding, say so and offer the fallback explicitly; never switch paths silently. If NEITHER machine is available, the room is closed: mark `blocked: no generation machine` in `status.md`, point to `/machines-check` and `guides/mcp-setup-guide.md`, and stop.

Two standing rules for everything below. **The brief owns the slot count**: never invent an extra frame and then look for a job to give it, and never quietly drop one; a set that should grow or shrink is changed in the brief first. **The brief and the Reference Sheet own the facts**: if a slot asks an image to assert a capacity, a certification, a material, or a number that the Reference Sheet and the research files do not support, stop and fix the brief. An invented fact on a listing image is an account risk, not a style choice.

## Process

1. **Establish the MODE, then load the plan.**
   - **MODE 1, the full set.** Read every slot brief (5 to 7 slots per the brief), the selling-points coverage map, and the restated avoid list. Count the images; this is the batch plan.
   - **MODE 2, one slot re-run.** A frame is coming back from `/inspect`, from `/fix` MODE A (a REGENERATE-class defect), or from `/fix` MODE B (a tasting note). Before anything runs, state three things in writing: WHICH slot, WHAT the defect or note is, and the EXACT sentence the tighter brief now carries. A re-run with no named driver is a reroll: refuse it and ask what changed. Repair upstream first, in the brief or the casting, then re-run the one slot; never re-run the whole set to fix one frame.

2. **Read the plan back, then enforce the SET-level rules against it.** Say each slot out loud in one line (slot, job, message, person yes or no). This is the last cheap moment to catch a slot that drifted. Verify these before generating, and fix any failure through the brief, never by improvising here:
   - **One job, one message per slot.** Each slot exists to do exactly one thing, with one dominant headline.
   - **No two slots share a message or headline.** A repeated message is a wasted slot; the gallery is too expensive for reruns.
   - **At least one emotional frame.** One slot sells the feeling or the outcome, not a spec.
   - **Avatars own casting; slot text owns nothing about people except whether one appears.** On the Genrupt path, casting is a STRUCTURED FIELD (intake guide, section 2.1): the persona in The Product Report is translated into 1 to 2 custom avatars with an EXPLICIT age and gender (the displayed age follows the brief's aspirational casting, a vital version of the real buyer). Per-image variety is AUTOMATIC and always on: within those constraints Genrupt varies appearance across the set so the same face does not repeat. Never request variety in prose, and never describe or specify a person inside a slot's text; casting sentences in a brief are ordinary creative input and can be re-scoped or dropped. Whether a slot shows a person at all is the brief's job. Inspection still checks that no face repeats (variety is automatic, not an identity guarantee).
   - **Legibility.** One headline per slot, at most about 3 supporting labels or icons, big mobile-legible text, no icon soup and no wall of words. Win legibility by subtraction: fewer elements means bigger text.
   - **Casting gap handling.** If the brief gives no persona to build the avatars from, derive them from the persona section of `research/product-report.md` (The Product Report) with the aspirational skew, state the derived age and gender out loud, and record them in the batch log as derived. If there is no persona there either, ask the owner for one line (roughly what age, which gender). If that too comes back "I don't have it", that is a real answer: generate the people-bearing slots WITHOUT people and say so, because an avatar with blank age and gender pins nothing (that blank default is exactly what caused the old casting drift) and it is never worth the credits.

3. **Estimate cost and get a go-ahead.** One line: "[N] secondaries on [path], estimated [credits/dollars]. Proceed?" No batch starts without a yes. If the user wants to trim, generate the two highest-priority slots first. Anything beyond that approved batch, a re-run, a second attempt, a MODE 2 slot, is NEW spend and gets its own one-line estimate and its own go-ahead. Never fold a re-run silently into an approval the user already gave.

4. **Generate. Path A: Genrupt (primary).** Genrupt owns planning, prompting, and generation; this room owns DISTILLATION (the law: `guides/genrupt-intake-guide.md`). Never write image prompts. Reuse the product's existing listing-builder flow if one exists (from `/main-image` or an earlier run); otherwise plan from the ASIN per the guide's call sequence, with product facts and casting set at planning time. **The intake principle: DISTILL, DON'T FORWARD.** Dumping the whole brief into every slot's text produces WORSE images, because your prose competes with the plan the model needs to land. Operating rules, all mandatory:
   - **Read the full plan, modify it, send back EVERYTHING.** Every edit starts from `get_listing_builder_plan_review`: it returns the full editable snapshot plus an `editableFields` map naming exactly what the save accepts back. On `save_listing_builder_plan_review`, always send the full `slotAssignments` array, even to change one slot; partial arrays are rejected, deliberately, so a sloppy call cannot erase other slots. Field semantics, exact: omit a field to preserve it, send `[]` to clear a list, send `text: null` to clear an instruction. Never "helpfully" resend empty arrays for fields you did not mean to touch.
   - **Slot 1 (the main image) is protected: round-trip it unchanged.** It is edited only through the main-image controls the setup flow exposes (tactic, hang-tag text, packaging preference), never through briefs, headers, custom instructions, or slot references. Those three controls are `/main-image`'s conversation with the user, not this room's.
   - **Route the brief into the fields.** Per slot: `contentBrief` = a 2 to 5 sentence visual direction lifted from the brief's slot section (the scene, the objects and their arrangement, whether a person is in frame), never a research summary. The finished headline goes in `headerPhrases` as FINISHED on-image copy (mobile-legible, no placeholder text, no keyword stuffing); header phrases become the mandatory on-image headline text. A second credible angle worth keeping goes to `alternateCreativeBriefs` (max 2, pick the best, do not hoard).
   - **Route constraints before you write them** (guide, section 5). Sort every "must / must never" by what enforces it: casting goes to the avatar fields; physical product accuracy goes to the product reference images, with a clean product description as backstop; brand color, font, and logo go to the branding preset and styleImage built by `/brand-kit`; on-image wording goes to `headerPhrases`. Only what is left ("never show hands", "must include the scoop") belongs in `customInstructions` with `mode: "ADDITIVE"`, a couple of short sentences at most. A constraint sitting in the wrong field is weaker than the same constraint in its own field, and it crowds the brief. Default to ADDITIVE; use OVERRIDE only when the user explicitly wants to replace Genrupt's planned direction, and preserve whichever mode the user approved. Never restate style, colors, or fonts in any text field.
   - **Avatars own casting. Zero casting prose, zero variety prose.** Translate the persona in The Product Report into 1 to 2 `customAvatars` with an EXPLICIT age (the brief's aspirational displayed age) and gender; blank fields pin nothing, and that blank default is exactly what used to cause the "ignored age" drift. An exact age holds that age in every image; a range or decade phrase spreads across the set. Leave `ethnicity` blank or "varied" unless the persona genuinely requires one: a named ethnicity is HELD identically in every image, while blank or "varied" opts into per-image variation. Per-image variety is automatic and always on, so never ask for it in prose and never describe people in slot text. On every save that touches casting, re-send `selectedAvatarIds` and `customAvatars` TOGETHER when both should persist: `customAvatars` alone also clears `selectedAvatarIds`. After saving, read the plan back (`get_listing_builder_plan_review` returns `selectedAvatars`) and confirm out loud exactly who is cast before generating; never assume the request applied.
   - **Propose edits, never silently apply them.** Show the user the returned plan with your Funnel-B edits proposed, then save the user-approved full slot array. Approval is an explicit save, never inferred from silence or enthusiasm.
   - **Always pass `modelId: "gpt_image_2"` explicitly on every generation call.** Never rely on the tool's default model; an unspecified call silently generates on a different engine with weaker text rendering.
   - **Edit the existing plan; never re-plan.** Re-running the planner wipes every slot edit and reverts casting. Fix slots through the plan-review/save path only.
   - **Generate the SECONDARY slots only, and leave the hero alone.** Do not include slot 1 in the generation request: the mains are `/main-image`'s work, they may already be gate-passed, and re-baking one here costs credits and breaks a set that later rooms depend on. If the tool returns a main anyway, it is not saved into `images/` and it is never advanced as a candidate. Say what you ignored.
   - **When regenerating a slot, make sure the tool call is a fresh generation, not a cached result** (if the tool exposes an idempotency or request key, use a new one).
   - **Never instruct the model to render a third-party logo or award badge**, and do not restate the ban in briefs either; Genrupt blocks it system-side. Real certifications appear only as they exist on the physical label. What Genrupt does NOT block, and what therefore stays in your short constraints: no star ratings or review references, no invented numbers.
   - Verify the approved reference asset id from `2-reference/reference-sheet.md` is attached to the generation so the product lock is inherited. The reference set is also the product-fidelity authority: a photo that SHOWS the material and shape beats any sentence describing them.

5. **Generate. Path B: gpt-image fallback (no Genrupt).** Per slot:
   - Attach the reference sheet's cleaned reference images to the call.
   - Use the slot brief as the prompt, prepending the product spec from `2-reference/reference-sheet.md` (exact size, material, every part present, label text) so the model cannot drift.
   - **Casting works differently here, and ONLY here.** This path has no avatar fields, so the avatars-own-casting rule cannot apply: each people-bearing slot must carry its casting IN THE PROMPT, an explicit displayed age and gender, plus enough distinguishing description that the person is clearly a different individual from every other people frame in the set. Keep a short list of who you cast where so the set stays varied. This is the one sanctioned exception; the moment the run is on Genrupt, casting prose is banned again.
   - Expect weaker product fidelity than the locked Genrupt path, and say so to the user up front. Inspect each output harder: compare the product in every image to the reference before accepting it into the set.
   - Generate the two highest-priority slots first, view them, and only continue if the product renders faithfully; if it does not, stop and tighten the reference rather than burning the batch.

6. **Save to `images/`, and write nothing else.** Files are named `sec-01.png` through `sec-07.png` (or however many slots the brief carries), matching the brief's slot order. This room writes ONLY `sec-*` filenames. Never overwrite, never delete, never move an existing file: a regenerated slot saves as `sec-03-v2.png` beside the first attempt (then `-v3`), and surgical edits from `/fix` live in `edits/vN/` snapshots under the same filename, never inside `images/`. Every original stays on disk underneath, which is the point. Untouched means untouched: the main candidates, their scorecard, and any earlier fixes are not this room's to tidy.

7. **Log the batch by APPENDING to `images/batch-log.md`.** The file is shared with `/main-image` and may already hold earlier rows. Add your row to the existing table and your slot map below it. Never rewrite the file, never re-emit the header, never touch an earlier row. If the file does not exist yet, create it with the header. The entry carries: date, room, path, model, image count, cost estimate versus approved, reference source (`manual` or `amazon_scraped`), brand-kit state, any slot that failed with its error, and, in MODE 2, the driver that justified the re-run.

8. **Do a first-pass sanity look, with evidence.** Open EVERY file you just generated with the Read tool and write ONE literal line per image (what is actually in frame). An image you did not open was not checked. You are looking for catastrophic misses only, four of them:
   - wrong or drifted product (compare against the Reference Sheet spec, part by part; every part the spec lists must be present and countable),
   - a failed or empty generation,
   - ignored casting (a person who is clearly not the specified age or gender),
   - the same face across two people frames (put them side by side and look).
   Do NOT score, do NOT run the squint test, do NOT rank: that is the Inspection Room's job and doing it here just duplicates it badly. If you find one of the four, name the file, name the defect, and route it correctly: product drift and casting are REGENERATE class, never an edit, and a repeated face is repaired UPSTREAM in the structured avatars (confirm explicit age and gender on each, and whether a second avatar from the persona should join the cast) before the slot re-runs as a fresh generation; it is never repaired by describing a different person in slot text. Offer the re-run with a fresh cost line. Never present raw generations as results.

9. **Verify the artifacts exist before you claim anything.** List `images/` and confirm one file per planned slot, with the earlier files still there. If a slot is missing, the set is NOT complete: retry that slot once (with its own cost line), and if it fails again, record the failure with its error in the batch log, name the missing slot to the user, and leave the sub-status at `in progress`. Never fill a hole with another slot's image, never renumber to hide a gap, and never call the set done because most of it landed.

10. **Hand off.** Tell the user: "The gallery is out of the machines. Next stop is the Inspection Room: run /inspect before you fall in love with anything." Ask for the set-level checks by name (message overlap, repeated faces, the emotional frame, selling-points coverage) and ask that it write its OWN scorecard file, so an earlier scorecard and its ranking survive untouched. Then continue the INVENT station: `/main-image` if the hero is not done, `/aplus` for the modules, `/variations` if the product sells variants, and the full package goes to Inspection together.

## Output format

`factory/Products/[product]/images/` after a run:

```
images/
  main-01.png .. main-04.png   (untouched, from /main-image)
  sec-01.png
  sec-02.png
  sec-03.png
  sec-04.png
  sec-05.png
  sec-06.png
  sec-07.png           (if the brief carries 7 slots)
  sec-05-v2.png        (a regenerated slot, beside its untouched first attempt)
  batch-log.md
```

`images/batch-log.md`, appended (the earlier row stays exactly as it was):

```markdown
# Batch Log . [Product Name]
| Date | Room | Path | Model | Images | Est. cost | Approved | Notes |
|---|---|---|---|---|---|---|---|
| [date] | main-image | genrupt | gpt_image_2 | 4 | [est] | yes ([date]) | [earlier row, untouched] |
| [date] | secondary-images | genrupt / gpt_image_fallback | gpt_image_2 | 6 | [est] | yes ([date]) | reference source: [manual/amazon_scraped]; brand kit: [on file/not available]; [failures, retries] |

## Slot map . secondary run [date]
| Slot | Job | Message | File | Casting | State |
|---|---|---|---|---|---|
| S1 | [job] | "[headline]" | sec-01.png | no people | generated |
| S4 | [job] | "[headline]" | sec-04.png | avatar A, [age]/[gender] | generated |
| S5 | [job] | "[headline]" | sec-05-v2.png | avatar B, [age]/[gender] | re-run: [driver, e.g. "repeated face, scorecard [date]"] |
```

## Golden Standards check

Before handing off, verify:
- [ ] Brief and locked reference (with a PASSED smoke test) were both confirmed BEFORE generating; any hard miss was reported as BLOCKED, not worked around. A missing brand kit was either filled or recorded as an explicit gap, never invented.
- [ ] Cost was estimated and explicitly approved before the batch, and every re-run got its own estimate and its own go-ahead.
- [ ] Set rules were checked against the plan and read back to the user: one job one message per slot, no two slots share a message, at least one emotional frame, and no slot invented or dropped outside the brief.
- [ ] Legibility holds per slot: one headline, max ~3 supporting elements, big mobile-legible text.
- [ ] No image asserts a fact the Reference Sheet and research files do not support.
- [ ] Genrupt path: every save started from `get_listing_builder_plan_review` and sent back the FULL `slotAssignments` array (omit preserves, `[]` clears a list, `text: null` clears an instruction, no empty arrays for untouched fields); slot 1 round-tripped unchanged; `modelId: "gpt_image_2"` on every generation call; brief ROUTED to fields (2 to 5 sentence contentBriefs of visual direction, finished headlines in `headerPhrases`, constraints sorted to their owning field with only the leftovers in ADDITIVE `customInstructions`); casting via 1 to 2 custom avatars with explicit age and gender, zero casting or variety prose anywhere, `selectedAvatarIds` re-sent alongside `customAvatars` when both should persist, and the cast confirmed on a read-back; edits proposed to the user before saving; plan edited not re-planned; MAIN slot NOT generated; reference asset id attached.
- [ ] Fallback path: references attached to every call, product spec prepended, casting written explicitly per people-slot and varied across the set, weaker-fidelity warning given.
- [ ] Every generated file was opened with Read and has a literal one-line description; the two people frames were compared side by side.
- [ ] Only `sec-*` files were written. No original overwritten, deleted or moved; no main candidate touched.
- [ ] `images/` was listed and matches the planned slot count, or the missing slots are named to the user and recorded with their errors.
- [ ] Batch log APPENDED (earlier rows intact) with path, model, count, approved cost, reference source, brand-kit state, and the slot map.
- [ ] The user was pointed to the Inspection Room with the set-level checks named, and no image was called final, approved, or ready.

## Wonka lines

Openers:
- "The Secondary Images Room. The main earns the click; this lot does the selling."
- "Every slot gets ONE job. A picture doing two jobs does neither."
- "Come in, come in. We're inventing a gallery today, and no two frames may sing the same note."

Closers:
- "Six frames, six jobs, one family. Nothing leaves this factory uninspected: Inspection Room, next."
- "Fresh gallery, still warm. Squint at it on a phone before you cheer; better yet, let /inspect do the squinting."
- "Machines off, set in the tray, originals sleeping safely underneath. Onward to /inspect."

## Definition of Done

- Every secondary slot from the brief has at least one generated file in `images/`, named `sec-NN` (or `sec-NN-v2` for a re-run), verified by listing the folder; any slot that failed twice is named to the user and recorded with its error, and the set is NOT called complete.
- `images/batch-log.md` exists and was appended, not rewritten, carrying path, model, count, approved cost, reference source, brand-kit state, and the slot map. Earlier rows are intact.
- Every generated file was opened and described; the four catastrophic-miss checks ran, and anything found was routed (regenerate for product drift or casting, upstream avatar repair for a repeated face).
- The main candidates and every earlier file are untouched on disk.
- The user was explicitly handed to `/inspect` with the set-level checks named, and the remaining INVENT rooms (`/main-image`, `/aplus`, `/variations`) named as needed; no output was presented as final.

## Update status.md

In the INVENT sub-status block, set `Secondary images (/secondary-images): done` (or `in progress` if the batch is partial or a slot is still owed, or `blocked: [precondition]`). Artifact `images/sec-01..NN.png` + `images/batch-log.md`. Then check the whole INVENT sub-status block: when all four sub-parts (Main image, Secondary images, A+, Variations) are `done` or `n/a` with a reason (variations may be n/a), set the INVENT station row to `done`; otherwise leave it `in progress`. Log line: `[date] Secondary set generated: [N] slots on [path], cost approved [est], reference source [manual/amazon_scraped][, brand kit not available]. Awaiting inspection.` For a MODE 2 re-run, the log line names the slot and its driver instead: `[date] Slot [sec-NN] regenerated ([driver]) as sec-NN-v2.png, cost approved [est]. Awaiting re-inspection of the whole set.` Name the remaining INVENT rooms as next steps, with INSPECT to follow once the full package exists.

---
name: variations
description: Create the variation imagery for a product that sells in multiple colors, sizes, scents, flavors, or bundles, keeping every variant visually consistent with the locked Reference Sheet, and explain how the variations embed on Amazon (parent/child, per-child main image, swatches). Use when the brief and Reference Sheet are done and the product actually has variations. Triggers: /variations, "make the variation images", "color swatches", "size variants", "variation set", "parent child listing images", "variations room".
---

# The Variations Room

| Meta | Value |
|------|-------|
| Room | The Variations Room |
| Station | INVENT (variations live under Invent, alongside listing images and A+) |
| Needs | brief/creative-brief.md (the variations plan), reference/reference-sheet.md (LOCKED, smoke test PASS), factory/Brand/brand-kit.md, the real variation list from the user |
| Saves to | factory/Products/[product]/variations/ |
| Typical cost | Genrupt: credits per variant image, one set. Fallback: gpt-image API per call. ALWAYS estimated and approved before the batch. |

## What this room does

The Variations Room builds the imagery for a product sold in more than one form: a per-variation main image and a swatch or thumbnail for each child, so the Amazon variation picker shows the shopper exactly what each option looks like. Every variant is kept visually consistent with the locked Reference Sheet: same product, same shot language, only the varying attribute changes. This room also explains how the set embeds on Amazon so the user can wire it up correctly.

## Before you start

Check inputs, in this order. Any hard miss = station **BLOCKED**, with a pointer:
- `brief/creative-brief.md`: must exist and carry the variations plan or at least the product strategy this set extends. If missing, the station is BLOCKED. Point to `/creative-brief` and stop.
- `reference/reference-sheet.md`: must exist with `Reference status: LOCKED` and `Smoke test: PASS`. Missing or unpassed: point to `/reference-sheet` and stop. The Reference Sheet is what keeps every variant the same real product.
- `factory/Brand/brand-kit.md`: colors, fonts, tone. If missing, offer `/brand-kit`; brand-style fields are marked `pending brand kit` until filled.
- **Ask the user which variations the product ACTUALLY sells.** Confirm the variation theme and the exact child list: colors, sizes, scents or flavors, bundle counts. NEVER invent a variation the product does not sell. If the theme is unclear, ask before generating; a made-up "lavender scent" is a real listing error, not a harmless mock.
- Confirm the generation path: Genrupt MCP connected (primary) or gpt-image fallback. Never switch paths silently.

## Process

1. **Lock the variation theme and child list.** Write down the theme (color / size / scent / flavor / bundle) and every real child SKU the user named. This list is the batch plan; nothing outside it gets generated.

2. **Plan the per-child imagery.** For each child, plan:
   - A **per-variation main image**: the product in that variant, product-only (no people in a main, ever), matching the Reference Sheet's shot language so the gallery reads as one family.
   - A **swatch or thumbnail image**: the small square the variation picker shows (a color chip, a size callout, a scent icon). Keep swatches instantly readable at tiny size, since Amazon renders them small.
   Keep everything visually consistent: same angle, same lighting, same background family as the Reference Sheet and the main gallery. Only the varying attribute changes between children.

3. **Estimate cost and get one go-ahead.** One line: "[N] variants x [main + swatch] = [M] images on [path], estimated [credits/dollars]. Proceed?" No batch starts without a yes.

4. **Generate. Path A: Genrupt (primary).** Use the Genrupt product-variations flow off the locked reference. Rules, all mandatory:
   - **Always pass `modelId: "gpt_image_2"` explicitly on every call.** Never rely on the tool default.
   - Use the lowest resolution the tool exposes unless the user asks otherwise.
   - Attach the approved reference asset id from `reference/reference-sheet.md` so every variant stays the real product.
   - Vary ONLY the target attribute per call; hold composition, angle, and background constant across the set.
   - Never instruct a third-party logo or award badge render; the content checker fails the image.

5. **Generate. Path B: gpt-image fallback (no Genrupt).** Attach the Reference Sheet's cleaned reference images and prepend the product spec from `reference/reference-sheet.md` to every call, then change only the varying attribute in the prompt. Expect weaker fidelity and consistency across children; say so, generate one child first, view it, and only continue if the product and the shot language hold across variants.

6. **Save everything to `variations/`** with variant-tagged filenames: `main-[variant].png` and `swatch-[variant].png`, for example `main-amber.png`, `swatch-amber.png`, `main-16oz.png`. Never overwrite; a regenerated variant saves beside the first attempt.

7. **Write the Amazon embedding notes** into `variations/variations-plan.md` so the user can wire it up:
   - **Variation theme**: the single dimension the children vary on (Amazon expects one clear theme, e.g. Color or Size; some categories allow two like Size + Color).
   - **Parent / child structure**: a non-buyable parent listing holds the child SKUs; shoppers land on the parent and pick a child. Each child is its own buyable SKU.
   - **Per-child main image**: each child SKU gets its own main image showing that variant, so the gallery updates when the shopper switches.
   - **Swatch images**: the small variation-picker thumbnails, one per child, mapped to each SKU.

8. **Run the Golden Standards check below, then hand off.** First-pass sanity look for catastrophic misses only. Do NOT present as final. Point the user to the Inspection Room: "The variation set is out of the machines. Next stop is /inspect."

## Output format

`factory/Products/[product]/variations/` after a run:

```
variations/
  main-amber.png
  swatch-amber.png
  main-clear.png
  swatch-clear.png
  main-16oz.png
  swatch-16oz.png
  variations-plan.md
```

`variations/variations-plan.md`:

```markdown
# Variations Plan . [Product Name]
Built from: brief/creative-brief.md ([date]), reference/reference-sheet.md (LOCKED), factory/Brand/brand-kit.md.
Variation theme: [Color / Size / Scent / Flavor / Bundle]. Confirmed real by owner [date].

## Children (real SKUs only)
| Child | Attribute | Main image | Swatch |
|---|---|---|---|
| Amber 16oz | color: amber | main-amber.png | swatch-amber.png |

## Amazon embedding
- Theme: [one dimension, or two if the category allows].
- Structure: non-buyable parent holds the child SKUs; shopper picks a child.
- Per-child main: each child SKU carries its own main image (mapped above).
- Swatches: one picker thumbnail per child (mapped above).

## Generation
| Date | Path | Model | Images | Est. cost | Approved |
|---|---|---|---|---|---|
| [date] | genrupt / gpt_image_fallback | gpt_image_2 | 6 | [est] | yes ([date]) |
```

## Golden Standards check

Before handing off, verify:
- [ ] Brief and Reference Sheet lock were both present; a miss was reported as BLOCKED, not worked around.
- [ ] The variation list is REAL: confirmed with the user, nothing invented that the product does not sell.
- [ ] Every child has a product-only main (no people in a main) and a readable swatch.
- [ ] All variants are visually consistent with the Reference Sheet: same angle, lighting, and background family; only the target attribute changes.
- [ ] Genrupt path: `modelId: "gpt_image_2"` on every call, Reference Sheet reference id attached, one attribute varied per call, no third-party logo render.
- [ ] Fallback path: references attached, product spec prepended, weaker-consistency warning given.
- [ ] Amazon embedding notes written (theme, parent/child, per-child main, swatches).
- [ ] Cost estimated and approved before generating; files saved variant-tagged, no overwrites.
- [ ] User was pointed to the Inspection Room; no variant called final.

## Wonka lines

Openers:
- "The Variations Room. One brief, many flavors, and every one must taste like the same factory made it."
- "Colors, sizes, scents. Tell me which ones truly exist. I invent candy, not flavors you do not sell."
- "Same product, new coats. The trick is that they all look like family."

Closers:
- "Every variant matches the Reference Sheet, so the shelf reads as one brand and not a bag of strangers. Off to /inspect."
- "Mains and swatches, one per child, mapped to their SKUs. The picker will thank you."
- "Consistent to the last chip. Nothing ships until the Inspection Room signs it. Onward."

## Definition of Done

- Every real child has a per-variation main image and a swatch image in `variations/`, or a recorded failure with its error.
- `variations/variations-plan.md` exists with the confirmed real child list, the Amazon embedding notes, and the generation record.
- The user was explicitly handed to the Inspection Room; no variant was presented as final.

## Update status.md

Variations are part of the INVENT station. In the INVENT sub-status block, set `Variations (/variations): done` (or `n/a (product has no variations)` with the reason if the product genuinely sells no variations, or mark `blocked: [precondition]`). Artifact `variations/` + `variations/variations-plan.md`. Then check the whole INVENT sub-status block: when all four sub-parts (Main image, Secondary images, A+, Variations) are `done` or `n/a` with a reason, set the INVENT station row to `done`; otherwise leave it `in progress`. Add a Log line: `[date] Variations generated: [N] children on [path], cost approved [est]. Awaiting inspection.` (If n/a, log: `[date] Variations: n/a, product has no variations. INVENT sub-part consciously skipped.`)

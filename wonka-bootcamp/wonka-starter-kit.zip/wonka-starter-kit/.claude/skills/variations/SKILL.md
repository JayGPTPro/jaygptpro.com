---
name: variations
description: Build the variation imagery for a product sold in more than one child SKU (colors, sizes, scents, flavors, counts, bundles), inheriting the tested winner's composition and the locked Reference Sheet so the family reads as one brand, then write the Amazon parent/child embedding map. Refuses to invent a child the product does not sell. Use when the package is briefed and referenced and the owner can name the real children. Triggers: /variations, "make the variation images", "color swatches", "size variants", "bundle images", "multipack images", "variation set", "variation family", "parent child listing images", "variations room".
---

# The Variations Room

| Meta | Value |
|------|-------|
| Room | The Variations Room |
| Station | INVENT (variations are one of the four Invent sub-parts) |
| Day | Day 10 in the bootcamp, the finale, run after the package is tested and packed. Also runs any time a child is added or a single child is sent back |
| Modes | MODE 1: the full family, from the confirmed child list. MODE 2: one child re-run, driven by a named inspection flag or a new child |
| Needs | brief/creative-brief.md (its VARIATIONS section), 2-reference/reference-sheet.md (LOCKED, smoke test PASS), the REAL child list from the owner, factory/Brand/brand-kit.md (soft), a live generation machine, the tested winner if one exists |
| Saves to | factory/Products/[product]/variations/ (main-[child].png, swatch-[child].png, variations-plan.md) |
| Typical cost | Genrupt: credits per image, 2 images per child. Fallback: gpt-image API per call. ALWAYS estimated and approved before the batch, and again before any re-run. |

## What this room does

The Variations Room takes one tested composition and propagates it across a real variation family: a per-child main image and a per-child swatch, so the Amazon variation picker shows the shopper exactly what each option is. Every child comes off the same locked Reference Sheet and the same winning shot language, which is why the family reads as one brand instead of three photographers on three afternoons. The room then writes the embedding map so the owner can wire the family up correctly.

Two things this room does NOT do. It does not invent a child the product does not sell: a made-up colorway is a real listing error that ends in returns, not a harmless mock. And it does not call anything final. The family goes to the Inspection Room like every other asset, and only a gate-passed family extends the upload pack.

Scope is variation imagery only. The main image, the gallery, and the A+ modules are generated in their own rooms off the same brief and the same locked reference.

## Before you start

Check these in order and report what you found out loud before spending anything.

1. **Brief. HARD.** `brief/creative-brief.md` exists. Read its VARIATIONS section and say back what it currently claims. Three lawful states, all workable: a real child list, `variations: none (single SKU)`, or `variations: unconfirmed`. Missing brief entirely: station **BLOCKED**, point to `/creative-brief`, stop. What is never lawful is generating a family while the brief on disk says something else; that is resolved in Process step 3, before any credit is spent.
2. **Locked reference. HARD.** `2-reference/reference-sheet.md` exists with `Reference status: LOCKED` and `Smoke test: PASS`. An approved reference WITHOUT a passed smoke test does not count. Missing or unpassed: **BLOCKED**, point to `/reference-sheet`, stop. Also read the sheet's `source:` field: if it records `amazon_scraped`, say so plainly once ("this reference was built from listing and review images, not from photos of the unit, so product likeness is the weaker path here"), tighten the fidelity check in step 10, and carry the source into the plan.
3. **The tested winner. SOFT, but strongly preferred.** If `tests/` holds a Tasting Card with a winning main, the family inherits THAT composition: angle, lighting, background, framing. Name the exact file it inherits from. If no test has run yet, the family inherits the Reference Sheet's shot language plus the brief's main-image direction instead, and the plan records `inherits from: reference sheet (no tested winner yet)`. Never build a family from scratch when a tested composition exists; that is the whole economic point of this room.
4. **Brand kit. SOFT.** `factory/Brand/brand-kit.md` exists. Missing: offer `/brand-kit` first, it is a short room. If the owner answers "I don't have one", that is a real answer: PROCEED, record `brand kit: not available (owner)` in the plan and the status line, generate on the reference plus neutral defaults, and warn once that brand fit will score "no kit on file" at inspection. Never invent a palette or a font to fill the hole.
5. **A generation machine.** Confirm which path applies: Genrupt MCP connected (primary) or gpt-image fallback on the OpenAI key. If Genrupt is expected but not responding, say so and offer the fallback explicitly; never switch paths silently. If NEITHER machine is available, the room is closed: mark `blocked: no generation machine` in `status.md`, point to `/machines-check` and `guides/mcp-setup-guide.md`, and stop.

## The child list, and the three honest answers

This is the spine of the room, so it happens before planning and before any estimate. **Ask the owner what this product ACTUALLY sells**, and take the answer literally. Never read a child list off a competitor's listing, off the category, or off your own assumption that a product "probably comes in other colors".

**Answer 1: a real list.** Write down the theme and every real child, in the owner's own words, with the attribute value for each. That list is the batch plan; nothing outside it is generated, ever.

**Answer 2: "none, it is a single SKU."** A complete and common answer, not a failure. Do not generate anything. Then offer one option, once, without pushing: a **multipack of the identical unit** is the only variation type that invents zero product facts, because two of the same real unit is still the same real unit, only the count changes, and it is the child a single SKU seller genuinely adds first. Say plainly that a bundle is a SKU the owner would have to really create and really stock, so it is a business decision and not an image decision. If they take it, that IS a real child list and the run continues at Answer 1, with the brief amendment in Process step 3. If the answer is still no, `n/a` is the finished state of this room, recorded with the date, and the rest of the package is unaffected.

**Answer 3: "I don't know."** Do NOT guess and do NOT write `none` on a guess. Record `child list: unconfirmed` and name the two places the truth lives: the live listing's own variation picker, and the parentage or variation view in Seller Central. Then park this sub-part only: `Variations (/variations): blocked: child list unconfirmed` in `status.md`, with the exact question to answer. Say clearly that nothing else is held up, because variations are the one sub-part allowed to trail the rest of the package; INSPECT and PROVE continue on the main, the gallery, and the A+.

Two standing rules for whatever comes back. **Real means saleable:** a child the owner "might add later" is not a child today. **A variation must not create a product claim:** if a proposed child asserts a capacity, a material, a finish, or a count that the Reference Sheet and the research files do not support, stop and say so; the fix is upstream, in the brief and the reference, never in the prompt.

## Process

1. **Establish the MODE.**
   - **MODE 1, the full family.** The confirmed child list, generated as one batch.
   - **MODE 2, one child.** A child is coming back from `/inspect`, from `/fix` as a REGENERATE-class defect, or the owner added a new child. Before anything runs, state three things in writing: WHICH child, WHAT the flag or reason is, and the EXACT sentence the tighter brief now carries. A re-run with no named driver is a reroll: refuse it and ask what changed. Never re-run the whole family to repair one child.

2. **Lock the theme and the child list.** Name the single dimension the children vary on and confirm each child's attribute value. One theme is the norm; some categories allow two (Size plus Color), in which case say out loud how many children the grid actually produces, because a 3 by 4 grid is twelve children and twenty four images, not seven.

3. **Reconcile the brief, and amend it BEFORE any credit is spent.** Compare the confirmed child list against the brief's VARIATIONS section.
   - They match: continue, and note the match in the plan's provenance.
   - They differ, including the common case where the brief says `none (single SKU)` or `unconfirmed` and the owner has now named a real family: **amend `brief/creative-brief.md` first.** Replace the VARIATIONS section with the confirmed plan, stamp it with today's date, record the reason in one line, show the amended section to the owner, and only then continue. Never generate past a document that contradicts the plan, and never edit the section silently. Six weeks later, the answer to "why are there bundle images for a single SKU product" has to be in the file.

4. **Plan the per-child imagery.** For each child, plan exactly two images.
   - **The per-child main.** The product in that child's form, **product-only, no people, no overlay text or graphics**, matching the inherited composition named in the preconditions (the tested winner, or the Reference Sheet's shot language if no test has run yet). Every child holds the same angle, lighting, background family, and framing; only the target attribute moves.
   - **The swatch.** The small picker thumbnail, and it has ONE job: telling the shopper at a glance which child she is choosing. Its job differs by theme:

     | Theme | What the swatch must carry | The failure to avoid |
     |---|---|---|
     | Color or finish | the actual color, filling the frame | a full product photo where the color is a detail |
     | Size or capacity | the size, as very large legible text | tiny numerals nobody can read at picker size |
     | Count or bundle | the count, as very large legible text plus the true number of units | one unit standing in for a multipack |
     | Scent or flavor | the name plus one honest cue (the real botanical, the real fruit) | a generic near-miss ingredient |

     Swatches render tiny, so win legibility by subtraction: fewer elements means bigger elements. A swatch is not a shrunken product photo. Say one honest thing about them out loud: **whether the picker draws an image swatch or a plain text button depends on the theme and the category template.** Color, pattern, and style themes classically get image swatches; size and count themes are often text buttons. Produce the swatch either way, because where it does render it is the whole decision, and where it does not it still serves as a gallery or A+ frame. Never state which one a specific category will draw as if it were checked; the owner sees the truth in the listing itself.
   - **Counts and arrangements are structural, not scale.** A bundle child is a different ARRANGEMENT of real units, never one unit photographed larger. Every unit in frame keeps its true proportions and its true parts, and the count in the image equals the count in the child's name.
   - **Derived likeness, named as such.** If a child's real-world appearance appears NOWHERE in the reference set (the classic case: a color the reference photos never showed), ask for one photo or one exact description of that child. If the answer is "I don't have that", that is a real answer: PROCEED, record `likeness: derived (no reference for this child)` against that child in the plan, warn once that it is the weakest thing in the family, and never present it as verified accurate.
   - **Map shared versus per child.** Note which existing assets serve the whole family (usually the gallery and the A+) and which must be per child (the main, always, and the swatch). This map goes in the plan and later into the upload pack.

5. **Estimate cost and get one go-ahead.** One line: "[N] children x main + swatch = [M] images on [path], estimated [credits/dollars]. Proceed?" No batch starts without a yes. Anything beyond that approved batch, a re-run, a second attempt, a MODE 2 child, is NEW spend and gets its own one-line estimate and its own go-ahead. Never fold a re-run silently into an approval the owner already gave.

6. **Generate. Path A: Genrupt (primary).** Use the Genrupt product-variations flow off the locked reference. All mandatory:
   - **Always pass `modelId: "gpt_image_2"` explicitly on every call.** Never rely on the tool default; an unspecified call silently generates on a different engine with weaker text rendering, which is fatal for swatches.
   - Use the lowest resolution the tool exposes unless the owner asks otherwise.
   - Attach the approved reference asset id from `2-reference/reference-sheet.md` to every call, so every child inherits the product lock.
   - **Style and brand fit come from the branding preset plus the one styleImage built by `/brand-kit`**, passed as structured fields where the flow accepts them. Never describe style, colors, graphics, or fonts in prompt prose, and never paste hex codes into a text field. If no kit exists, that is the recorded gap from the preconditions; do not compensate with style prose.
   - Variation imagery is product-only, so no casting applies here. If a request ever tries to put a person into a variation image, the answer is no, and casting direction would in any case live in the avatar fields (`customAvatars` / `selectedAvatarIds`), never in brief prose.
   - **Vary ONLY the target attribute per call.** Composition, angle, lighting, and background are held constant across the family. If the tool exposes a seed or a base image, reuse the same one across the children.
   - Never instruct a third-party logo or an award badge render; the content checker fails the whole image.
   - Keep the whole compliance avoid-list off the swatches too: no star ratings, no review references, no invented percentages, no fake badges. A swatch is a label, not an ad.

7. **Generate. Path B: gpt-image fallback (no Genrupt).** Attach the Reference Sheet's cleaned reference images to every call and prepend the product spec (exact size, material, every part present, label text) so the model cannot drift, then change only the varying attribute in the prompt. Expect weaker fidelity and weaker family consistency, and say so up front. **Generate ONE child first, both its images, open them, and hold.** Continue only if the product renders faithfully and the shot language holds; if it does not, stop and tighten the reference rather than burning the batch.

8. **Save to `variations/`, and write nothing else.** Filenames are child-tagged: `main-[child].png` and `swatch-[child].png`, using the owner's own child names slugified (`main-2pack.png`, `swatch-2pack.png`). This room writes ONLY `main-*`, `swatch-*`, and `variations-plan.md`. Never overwrite, never delete, never move: a regenerated child saves as `main-2pack-v2.png` beside its untouched first attempt, and surgical edits from `/fix` live in `edits/vN/variations/` snapshots under the same filename, never inside `variations/`. Every original stays on disk, which is the point.

9. **Write `variations/variations-plan.md`** in the Output format below: provenance, the confirmed real child list, the shared-versus-per-child map, the Amazon embedding map, and the generation record. On a MODE 2 run, APPEND a generation row; never rewrite the file and never touch an earlier row.

10. **Verify with evidence, not with confidence.** Open EVERY file you just generated with the Read tool and write ONE literal line per image (what is actually in frame). An image you did not open was not checked. For swatches, also make a picker-size copy and read THAT, because a swatch judged at full size is a swatch never judged at all:
    ```bash
    mkdir -p "factory/Products/[product]/scorecards/picker"
    sips --resampleWidth 60 "factory/Products/[product]/variations/swatch-[child].png" --out "factory/Products/[product]/scorecards/picker/swatch-[child]-60.png"   # macOS
    # Windows/ImageMagick: magick convert "factory/Products/[product]/variations/swatch-[child].png" -resize 60x "factory/Products/[product]/scorecards/picker/swatch-[child]-60.png"
    ```
    The copies live OUTSIDE `variations/` on purpose: that folder is inventoried by `/inspect` and its gate-passed files travel into `final/` (and from there to `output/` via `/ready-to-upload`), and downscaled proofs are neither deliverables nor candidates.

    You are looking for five catastrophic misses only:
    1. **Wrong or drifted product** against the Reference Sheet spec, part by part. Every part the spec lists must be present and countable.
    2. **Wrong count or wrong attribute for that child.** A two pack showing one unit, a size child rendered at the wrong size, a color child in the wrong color.
    3. **A failed or empty generation.**
    4. **The family does not read as siblings.** Put the mains side by side: a child at a different angle, height, light, or background is a family break.
    5. **A swatch that does not do its job at 60px.** If you cannot tell which child it is from the downscaled copy, it failed, whatever it looked like at full size.

    Do NOT score, do NOT rank, do NOT run the full 160px squint pass: that is the Inspection Room's job and duplicating it here just does it worse. Route what you find: product drift, wrong counts, and family breaks are REGENERATE class, never an edit; enlarging swatch text is also regenerate class. Only removing a stray element or swapping a word is a surgical edit. Offer any re-run with a fresh cost line.

11. **Verify the artifacts exist before you claim anything.** List `variations/` and confirm one main and one swatch per confirmed child, with earlier files still present, plus `variations-plan.md`. Re-read the plan from disk to confirm it wrote. If a child is missing an image, the family is NOT complete: retry that image once (with its own cost line), and if it fails again, record the failure with its error in the plan, name the missing child to the owner, and leave the sub-status at `in progress`. Never fill a hole with another child's image, never rename to hide a gap, and never call the family done because most of it landed.

12. **Hand off to the Inspection Room.** Tell the owner: "The family is out of the machines. Next stop is the Inspection Room: run /inspect before you fall in love with it." Ask for the variation checks by name (per child fidelity against the reference, true counts, family consistency, swatch legibility at picker size). Nothing here is final and nothing is a candidate yet.

13. **Only AFTER the family is gate-passed, extend the pack.** This step never runs on uninspected images.
    - Copy the gate-passed family into `final/` beside the rest of the approved package (`/ready-to-upload` copies `final/` to `output/`).
    - In `tests/upload-pack.md`, replace the pending Variations line with the real family and the embedding map. The lawful pending marker is `Variations: pending (Day 10)`.
    - If `tests/upload-pack.md` does not exist yet (this room ran before the Shipping Room), do not create it: note in the plan that the pack will pick the family up, and say so.
    - Say once more, plainly: this room produces the files and the map. The owner uploads them and wires the parentage in Seller Central. Wonka never touches the live listing, and the plan records what was produced, never a predicted result.

## Output format

`factory/Products/[product]/variations/` after a run:

```
variations/
  main-2pack.png
  swatch-2pack.png
  main-3pack.png
  swatch-3pack.png
  main-3pack-v2.png     (a regenerated child, beside its untouched first attempt)
  variations-plan.md
```

`variations/variations-plan.md`:

```markdown
# Variations Plan . [Product Name]

Built from: brief/creative-brief.md ([date], VARIATIONS section [matched / amended [date]: [reason]]),
2-reference/reference-sheet.md (LOCKED, smoke test PASS, source: [manual / amazon_scraped]),
factory/Brand/brand-kit.md ([on file / not available (owner)]),
inherits composition from: [tests/tasting-r2-[date]-main/ winner, file main-01-v2.png / reference sheet (no tested winner yet)].

Variation theme: [Color / Size / Scent / Flavor / Count or bundle]. Confirmed real by the owner [date].

## Children (real SKUs only)
| Child | Attribute value | Main image | Swatch | Likeness |
|---|---|---|---|---|
| Two pack | count: 2 units | main-2pack.png | swatch-2pack.png | from reference |
| Party three pack | count: 3 units | main-3pack-v2.png | swatch-3pack.png | from reference |

## Shared versus per child
- Per child (must exist for every child): the main image, the swatch.
- Shared across the family: the secondary gallery, the A+ modules.

## Amazon embedding
- Theme: [the one dimension, or two if the category allows]. Children: [N].
- Structure: a non-buyable parent holds the child SKUs; the shopper lands on the parent and picks a child.
- Per-child main: each child SKU carries its own main image (mapped above), so the gallery updates when the shopper switches. A buyer who picks the two pack and sees one unit was told something untrue before she paid.
- Swatches: one picker thumbnail per child, mapped to its SKU (mapped above). Whether this category draws an image swatch or a text button is visible in the live listing; the file is produced either way.
- Wiring: the exact theme names and the parentage screens live in the category's own template in Seller Central. This map says WHAT to produce; the owner wires it there.

## Generation
| Date | Mode | Path | Model | Images | Est. cost | Approved | Notes |
|---|---|---|---|---|---|---|---|
| [date] | full family | genrupt / gpt_image_fallback | gpt_image_2 | 4 | [est] | yes ([date]) | [failures, retries, derived likeness, brand kit state] |
| [date] | child re-run | genrupt | gpt_image_2 | 1 | [est] | yes ([date]) | [child]: [driver, e.g. "tier count wrong, scorecard [date]"] -> main-3pack-v2.png |
```

## Golden Standards check

Before handing off, verify:
- [ ] Brief and locked reference (with a PASSED smoke test) were confirmed BEFORE generating; any hard miss was reported as BLOCKED, not worked around. A missing brand kit was recorded as an explicit gap, never invented.
- [ ] The child list is REAL, confirmed by the owner in this run, and nothing outside it was generated. "None" and "I don't know" were handled as first-class answers, not papered over.
- [ ] Where the confirmed list differed from the brief, the brief was AMENDED first, dated and reasoned, before a single credit was spent.
- [ ] Cost was estimated and explicitly approved before the batch, and every re-run got its own estimate and its own go-ahead.
- [ ] The family inherits the tested winner's composition where one exists, and the inheritance source is named in the plan.
- [ ] Every child has a product-only main (no people, no overlay text or graphics) and a swatch that does its one job.
- [ ] Only the target attribute varies: angle, lighting, background family, and framing are constant across the family, and a bundle is a true arrangement of real units, never one unit scaled up.
- [ ] No image asserts a capacity, material, finish, or count the Reference Sheet and research files do not support. The compliance avoid-list holds on swatches too.
- [ ] Genrupt path: `modelId: "gpt_image_2"` on every call, reference asset id attached, one attribute varied per call, no third-party logo render. Fallback path: references attached, product spec prepended, one child generated and viewed first, weaker-fidelity warning given.
- [ ] Every generated file was opened with Read and has a literal one-line description; every swatch was read at 60px; the mains were compared side by side for family consistency.
- [ ] Only `main-*`, `swatch-*`, and `variations-plan.md` were written into `variations/`. No original overwritten, deleted, or moved; picker proofs live outside the folder.
- [ ] `variations/` was listed and matches the confirmed child list, or the missing images are named to the owner and recorded with their errors; `variations-plan.md` was re-read from disk.
- [ ] The owner was pointed to the Inspection Room with the variation checks named, and no child was called final. `output/` and the upload pack were extended only AFTER the gate passed.

## Wonka lines

Openers:
- "The Variations Room. One brief, many flavors, and every one must taste like the same factory made it."
- "Before anything else: tell me which children truly exist. I invent candy, not flavors you do not sell."
- "Nine days bought you one tested winner. This is the room where that stops being expensive."

Refusals (say them plainly, without drama):
- "Your brief says single SKU, in writing, on [date]. I will not contradict my own document to please a prompt."
- "A colorway that does not exist is a return, a bad review, and a listing problem. Give me the real list and I will give you a real family."
- "If the plan changed, the plan gets rewritten. Dated, with the reason. Then, and only then, the machines run."

Closers:
- "Same light, same angle, same composition that won. One family, one visual language, and not a stranger among them."
- "Mains and swatches, one per child, mapped to their SKUs. Look at the swatch at the size it actually renders; that is the only size that matters."
- "Consistent to the last chip. Nothing ships until the Inspection Room signs it. Onward to /inspect."

## Definition of Done

One of two honest end states, never a third.

**Generated:**
- Every confirmed child has a per-child main and a swatch in `variations/`, verified by listing the folder; any image that failed twice is named to the owner and recorded with its error, and the family is NOT called complete.
- `variations/variations-plan.md` exists and was re-read from disk, carrying provenance (brief state, reference source, brand kit state, inherited composition), the confirmed real child list with likeness notes, the shared-versus-per-child map, the Amazon embedding map, and the generation record.
- Where the plan changed, `brief/creative-brief.md` carries the dated, reasoned amendment.
- Every generated file was opened and described, every swatch was read at picker size, and the five catastrophic-miss checks ran with anything found routed correctly.
- Every original is untouched on disk, and the owner was explicitly handed to `/inspect` with nothing presented as final. `output/` and `tests/upload-pack.md` were extended only after the gate passed.

**Not applicable or blocked:**
- `n/a`: the owner confirmed the product is a single SKU. Recorded in `status.md` with the date, no folder faked, no child invented, the rest of the package unaffected.
- `blocked`: the child list is unconfirmed. Recorded with the exact question and the two places to answer it, and the owner told plainly that nothing else is held up.

## Update status.md

In the INVENT sub-status block, set `Variations (/variations): done` (or `in progress` if the family is partial or a child is still owed, or `n/a (product has no variations)` with the owner's confirmation date, or `blocked: [precondition or "child list unconfirmed"]`). Artifact `variations/` + `variations/variations-plan.md`.

Then check the whole INVENT sub-status block: when all four sub-parts (Main image, Secondary images, A+, Variations) are `done` or `n/a` with a reason, set the INVENT station row to `done`; otherwise leave it `in progress`. If an earlier run left the lawful trailing marker `Variations: pending (Day 10)`, this run replaces it.

Log lines, one of:
- `[date] Variation family generated: [N] children on [path], [M] images, cost approved [est], inherits [winner file], reference source [manual/amazon_scraped][, brand kit not available]. Awaiting inspection.`
- `[date] Child [name] regenerated ([driver]) as main-[child]-v2.png, cost approved [est]. Awaiting re-inspection of the family.`
- `[date] Variations: n/a, owner confirmed single SKU. INVENT sub-part consciously skipped.`
- `[date] Variations: blocked, child list unconfirmed. Owner to check the listing's variation picker or Seller Central parentage. Rest of the package proceeds.`

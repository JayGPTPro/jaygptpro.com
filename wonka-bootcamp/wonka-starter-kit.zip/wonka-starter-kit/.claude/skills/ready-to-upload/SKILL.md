---
name: ready-to-upload
description: Package the proven winner and the full tested creative set into an upload pack: the complete creative package (main + secondary + A+ + variations) ready to upload to Amazon, the evidence, and OPTIONAL Amazon A/B launch instructions for those who want to A/B the main image. The bootcamp finishes here. Use after a Tasting Round winner and the user wants the package packaged and ready. Triggers: /ready-to-upload, "package the winner", "ready to upload", "put it on Amazon", "ship the package", "launch the A/B".
---

# The Shipping Room

| Meta | Value |
|------|-------|
| Room | The Shipping Room |
| Station | PROVE (step 2 of 3) |
| Needs | A Tasting Round winner that beat the incumbent (`tests/tasting-r[N]-[date]/tasting-card.md`), the full tested creative set (main + secondary + A+ + variations), the current live image, Brand Registry status (only if the user opts into A/B) |
| Saves to | factory/Products/[product]/tests/upload-pack.md + the complete package copied to output/ + a row appended to factory/Recipe Book/experiments.md (only if the user opts into an A/B) |
| Typical cost | Free. Packaging costs nothing; Amazon's Manage Your Experiments (the optional A/B) is also free and the user performs it in Seller Central. |

## What this room does

An upload pack is a tested creative package with papers: the complete winning set, ready to upload to Amazon. This is where the bootcamp finishes. The Shipping Room lists every file in the package (the winning main image, the secondary gallery, the A+ modules, and the product variations), the evidence behind the winning main, and hands the user a package they can upload to their listing directly. For those who want to prove the main-image lift with a controlled test, an Amazon A/B (Manage Your Experiments) is the OPTIONAL next step, not the required finish. The bootcamp's promise is a full, tested creative package ready to upload or to A/B, and this room delivers exactly that.

## Before you start

- Read the tasting card in the latest `tests/tasting-r[N]-[date]/` folder (`tasting-card.md`). The gate is the MAIN race card's own standardized verdict: the WINNER must be one of OUR candidates (not the incumbent) AND the card's label must be **"Clear lead"**. The GALLERY race card (Scenario C), when one ran, is evidence to report, not a gate. Any other label ("Lean", "Toss-up"), a split panel, or an incumbent win closes the Shipping Room: say exactly why and route back to refine and re-taste, or suggest the optional real-shopper poll (the Pro Move) on the finalists. No shipping for a coin flip.
- Confirm the winning file exists in `images/` and open it with Read to confirm it is the exact tested version (including `_fixN` suffix). The pack must name the precise file that won, not a sibling.
- Confirm the rest of the package exists: the secondary gallery, the A+ modules (`factory/Products/[product]/aplus/`), and the variation imagery (`factory/Products/[product]/variations/`). The upload pack lists the WHOLE tested set, not just the main image.
- Variations are the one allowed gap. In the bootcamp order this room (Episode 11) runs before the Variations Room (Episode 12), so if `variations/` is empty, do NOT block: record "Variations: pending (Episode 12)" in the pack and note that `/variations` extends this pack when it completes. Everything else (main + secondary + A+) must be present.
- **Ask whether the user wants the optional Amazon A/B** of the main image. If yes, ask whether the seller has **Brand Registry** (Manage Your Experiments requires it, plus Amazon's eligibility thresholds for the ASIN) and check `factory/Recipe Book/experiments.md` for a running experiment on this ASIN. **Queue rule: one experiment per ASIN at a time;** if one is running, the new pack waits in the queue. If the user does not want an A/B, skip all A/B steps and the experiments.md row; the package is still complete and ready to upload.

## Process

1. **Assemble the evidence block.** Winner filename and what the image is (one line), the control (the current live image), the tasting numbers (shares, number of tasters, date, both rounds), and the top recurring notes and objections from the Tasting Cards. When a GALLERY race (Scenario C) ran, report its set-level verdict too: proposed gallery vs live gallery, shares, and the label. It ships as evidence even though the gate is the main race. Label the evidence honestly: a directional verdict from the AI taster panel, not real-shopper data.

2. **Write the hypothesis.** One sentence, causal and falsifiable: "The new main image lifts CTR because [the specific thing the tasters said: the size callout reads at thumbnail size / both microphones are visible at a glance / ...]." The hypothesis comes from the tasting notes, never from taste.

3. **Set the metric.**
   - MAIN image test: **CTR** (click-through rate). The main image's job is winning the click on the search page.
   - Gallery or A+ test: **CVR** (conversion rate). Those assets work after the click.
   State which one this experiment watches and why.

4. **Assemble the full package list.** List every file in the tested creative set, grouped: the winning MAIN image, the SECONDARY gallery, the A+ modules, and the VARIATION imagery. Each entry is the exact filename and a one-line description. This list is the deliverable the user uploads to Amazon.

--- The remaining A/B steps (5 through 8) run ONLY if the user opted into the optional Amazon A/B in "Before you start." If not, skip to step 9 (write the pack). ---

5. **Write the launch walkthrough (Brand Registry path, Manage Your Experiments):**
   1. Seller Central > Brands > Manage Your Experiments.
   2. Create a new experiment > experiment type: Main Image (or A+ Content / Title as relevant).
   3. Select the ASIN. Amazon checks eligibility (the ASIN needs sufficient traffic; if it fails, Amazon says so on this screen).
   4. Upload the winner as Version B; the current live image stays as Version A. Do not change anything else about the listing during the test.
   5. Name the experiment (use the pack name), set the duration, and set the hypothesis field from step 2.
   6. **Duration: let it run to significance, typically 8 to 10 weeks.** Pick 10 weeks with "end early if a winner is found" if offered. **Do not peek and stop early**: early leads flip, and a stopped test proves nothing.
   7. Launch, then paste the experiment start date back so the pack and the Recipe Book are updated.

6. **No Brand Registry: the honest fallback.** A straight swap of the main image, with before/after monitoring:
   1. Record 4 weeks of baseline CTR from Business Reports (Detail Page Sales and Traffic: sessions vs impressions data as available).
   2. Swap the main image to the winner.
   3. Monitor the same report for 4 weeks after.
   Say plainly: this is WEAKER evidence than a true A/B. Seasonality, price changes, ads, and competitors all move CTR too, and there is no control group. It answers "did things get better" and not "did the image cause it." Record `method: swap_with_monitoring` on the pack.

7. **Append the experiment row** to `factory/Recipe Book/experiments.md` (create the file with the canonical header row if missing). Append a NEW row in the canonical 8-column schema:

   `| Date | Product | Type | Candidates | Winner | Margin | Key why | Status |`

   Type = `amazon-ab`, Status = `planned`. Status becomes `running` once the user confirms the experiment started in Seller Central. Do not use any other column set. This is what `/improvement-loop` and `/factory-report` track.

8. **Set the follow-up.** Tell the user when to come back with results (test end date) and that `/improvement-loop` runs on the outcome either way, win or lose.

--- End of optional A/B steps. ---

9. **Write the pack** to `tests/upload-pack.md` per the Output format (include the full package list, the evidence, and the A/B plan only if the user opted in).

10. **Package to the ready-to-ship folder and finish.** Copy the ENTIRE tested creative package (the winning main image, the secondary gallery, the A+ module files, the variation imagery) and `upload-pack.md` into `output/` (the kit's ready-to-ship folder), so the complete package sits in one place, ready to upload to Amazon. Tell the user plainly: the bootcamp finishes here. They have a full, tested creative package ready to upload, and the optional A/B is theirs to run whenever they want. Make no promises about sales; the guarantee is a tested package ready to go, never a result. When results land (tasting re-tests or the A/B verdict), run `/improvement-loop`.

## Output format

`tests/upload-pack.md`:

```markdown
# Upload Pack . [Product Name] . [YYYY-MM-DD]

Built from: tests/tasting-r[N]-[date]/tasting-card.md (both rounds), scorecard-[date].md, the live listing

## The winning main image
- File: images/[exact filename]
- What it is: [one line: e.g. main image, machine with both mics forward on white background]

## The full tested package (ready to upload)
- Main image: images/[winning filename]
- Secondary gallery: images/[s1 ...], [s2 ...], ...
- A+ modules: aplus/[module files]
- Variations: variations/[per-variation files]

## The control
- The current live Amazon main image (the incumbent the main beat in both Tasting Rounds)

## Evidence
- Tasting Round 1 [date], main race: winner [x]% vs incumbent [y]%, n=[tasters]
- Tasting Round 2 [date], main race: winner [x]% vs challenger [y]% vs incumbent [z]%, n=[tasters]
- Gallery race (Scenario C, when run): proposed gallery [x]% vs live gallery [y]%, [label], round [N]
- Taster reasons: [top 2 recurring notes, one line each]
- Nature of evidence: directional verdict from the AI taster panel (SSR method). An optional real-shopper poll (PickFu / ProductPinion / any panel) is the gold-standard upgrade for big-money decisions; not run unless the user chose to.

## Optional A/B (only if the user opted in)
- Hypothesis: the new main image lifts CTR because [specific taster-backed reason].
- Metric: [CTR (main image test) / CVR (gallery or A+ test)] . measured by [Manage Your Experiments report / Business Reports before-after]
- Method: [Manage Your Experiments / swap_with_monitoring (no Brand Registry: weaker evidence, no control group)]
- Steps: [the numbered walkthrough from the process, with the ASIN filled in]
- Duration: [8 to 10 weeks, run to significance, no early stopping]
- Queue check: [no other experiment running on this ASIN / QUEUED behind experiment X]

## Status
- Package: ready to upload (copied to output/ on [date])
- A/B (if opted in): [not requested / pending launch / launched YYYY-MM-DD, results expected ~YYYY-MM-DD]
```

Row appended to `factory/Recipe Book/experiments.md` ONLY if the user opted into the A/B (canonical 8-column schema: `| Date | Product | Type | Candidates | Winner | Margin | Key why | Status |`):

```markdown
| [YYYY-MM-DD] | [product] | amazon-ab | 2 ([winner file] vs incumbent) | | | | planned |
```

Status flips to `running` once the user confirms the experiment started in Seller Central. If the user did not opt into an A/B, no experiments.md row is written from this room.

## Golden Standards check

Before presenting, verify:
- [ ] The winner beat the INCUMBENT (not just our other candidates) by a meaningful margin, per the main race test file.
- [ ] If a gallery race (Scenario C) ran, its set-level verdict is reported in the evidence block.
- [ ] The pack names the exact winning filename, verified on disk with Read.
- [ ] The full package is listed (main + secondary + A+ + variations, or variations marked pending/n-a), each an exact filename.
- [ ] The A/B section is clearly OPTIONAL, and the finish (a tested package ready to upload) does not depend on it.
- [ ] No promise of sales or results anywhere; the guarantee is a tested package ready to upload or A/B.
- [ ] If the user opted into the A/B: the hypothesis cites a taster-backed reason; the metric matches the asset type (CTR for main, CVR for gallery/A+); duration says 8 to 10 weeks, run to significance, no peek-and-stop; the one-experiment-per-ASIN queue rule was checked; the no-Brand-Registry fallback (if used) is labeled weaker evidence; and the experiments.md row was written (canonical 8-column schema, Type `amazon-ab`).
- [ ] The COMPLETE package (main + secondary + A+ + variations) and upload-pack.md were copied into output/.

## Wonka lines

Openers:
- "The Shipping Room. Very few candies make it this far; let's stamp this one properly."
- "A winner with a hundred witnesses. Now we send it to face the only judge left: Amazon itself."
- "Papers, evidence, hypothesis. A shipped package is a promise with paperwork."

Closers:
- "Stamped in gold. The whole package sits in output/, ready to upload. That is the finish line, and you crossed it."
- "Tested, packaged, and ready. Upload it as it stands, or run the optional A/B if you want the controlled proof. Your call."
- "Onward. Golden Tickets don't print themselves, but this one just did. If you A/B it, no peeking for ten weeks."

## Definition of Done

- `tests/upload-pack.md` exists with the winning main, the full package list (main + secondary + A+ + variations), control, evidence, and (only if opted in) the optional A/B plan and status.
- The COMPLETE tested package and upload-pack.md are copied into `output/`, ready to upload to Amazon.
- If the user opted into an A/B: the experiment row exists in `factory/Recipe Book/experiments.md` in the canonical 8-column schema with Type `amazon-ab` and Status `planned` (or `running` if already confirmed), and the user has the exact Seller Central steps (or the honest fallback plan) and a date to return with results.
- The user understands the bootcamp finishes here with a tested package ready to upload or A/B, with no promise of a sales result, and that when results land, `/improvement-loop` runs on them.

## Update status.md

Set PROVE to `done: package ready to upload` (or `in-progress: A/B pending` if the user opted into and launched an A/B) with upload-pack.md as the artifact. Add a Log line: `[date] Upload pack issued: full package copied to output/, ready to upload. A/B [not requested / launched / pending launch / queued].`

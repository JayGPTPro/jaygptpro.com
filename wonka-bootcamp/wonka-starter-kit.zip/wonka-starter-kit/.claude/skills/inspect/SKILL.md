---
name: inspect
description: The mandatory QA gate between image generation and the human's pick. Opens every image with vision, scores 6 dimensions, runs the mechanical mobile squint test, applies the compliance gate, ranks variants, and auto-fixes cheap fails before the user ever sees the set. Use after /main-image, /secondary-images, /aplus, /variations, or /fix, or when the user asks to review, score, QA, grade, or rank images. Triggers: /inspect, "inspect the images", "QA these", "score the set", "which image is best", "review what we generated".
---

# The Inspection Room

| Meta | Value |
|------|-------|
| Room | The Inspection Room |
| Station | INSPECT |
| Needs | The full generated package: listing images in `images/`, A+ modules in `aplus/`, and variation imagery in `variations/`; the brief (`brief/creative-brief.md`), the Reference Sheet (`reference/reference-sheet.md`), the brand kit (`factory/Brand/brand-kit.md`) |
| Saves to | factory/Products/[product]/scorecards/scorecard-[YYYY-MM-DD].md |
| Typical cost | Free to inspect. Auto-fixes via /fix cost cents per edit (each one is logged). |

## What this room does

Nothing leaves the Factory without passing this room, and "nothing" means the FULL package: the listing images (`images/`), the A+ modules (`aplus/`), and the variation imagery (`variations/`). Every generated image, whatever its asset class, is opened with vision, described literally, scored, checked against the compliance avoid-list, and force-ranked against its sibling variants. Cheap defects are fixed automatically BEFORE the user sees anything, so the human's job is to pick winners, never to discover defects.

Different asset classes are judged differently. Do NOT apply the listing-image set rules (no incumbent, no people in a main, one emotional frame, no repeated face) blindly to A+ or variations; each class gets its own checklist (see step 6).

## Before you start

- Verify the package has at least one image to inspect across `images/`, `aplus/`, and `variations/`. If all three are empty, the room is closed: tell the user the generation rooms (/main-image, /secondary-images, /aplus, /variations) run first, and stop. If `images/` has files but `aplus/` and/or `variations/` are empty, note it: check the product's INVENT sub-status in `status.md`. Inspect what exists, and flag the missing sub-parts (unless recorded as a conscious skip, e.g. "Variations: n/a", or as the lawful trailing marker "Variations: pending (Episode 12)", which is not a gap).
- Read `brief/creative-brief.md`. Each image must be judged against the JOB its brief slot assigned it. If the brief is missing, mark this station BLOCKED, say /creative-brief must run first, and stop. Do not score against guesses.
- Read `reference/reference-sheet.md` and the reference photos in `reference/` (or note `source: amazon_scraped` if that is what the Reference Sheet records). Product accuracy is judged against the Reference Sheet, never against memory.
- Read `factory/Brand/brand-kit.md` for colors, fonts, and tone. If missing, score brand fit as "no kit on file" rather than inventing a standard.
- Read `research/persona.md` for the casting targets (real buyer age plus the aspirational display skew) if any images contain people.

## Process

1. **Inventory the whole package.** List every file in `images/`, `aplus/`, AND `variations/` (including `_fixN` versions). Group each file by ASSET CLASS:
   - **Main image** (`images/`, main-* slots): product-only hero.
   - **Secondary image** (`images/`, s* slots): benefit, proof, lifestyle, scale, and so on.
   - **A+ module** (`aplus/`, m* files): an Enhanced Brand Content module.
   - **Variation main** (`variations/`, main-[variant] files): a per-variation hero.
   - **Variation swatch** (`variations/`, swatch-[variant] files): the tiny variation-picker thumbnail.
   Within each class, group variants of the same slot/module/child together using filenames, the brief, `aplus/aplus-plan.md`, and `variations/variations-plan.md`. If `aplus/` or `variations/` is empty and not recorded as a conscious skip or a pending-Episode-12 marker in the INVENT sub-status, note the gap.

2. **Open EVERY image with vision.** Use the Read tool on each file across all three folders. No image is scored unseen. For each image, first write a 1 to 2 line LITERAL description of what is actually visible: product, text you can read, people, props, background. This description is evidence; if you cannot honestly describe it, you have not looked.

3. **Run the mechanical squint test on every image.** Full-size eyeballing is forbidden; small text always looks fine at full size. Make a downscaled copy at ~160px wide and READ that copy:
   Run from the kit root with full paths, resampling by WIDTH:
   ```bash
   mkdir -p "factory/Products/[product]/scorecards/squint"
   sips --resampleWidth 160 "factory/Products/[product]/images/[file].png" --out "factory/Products/[product]/scorecards/squint/[file]-160.png"   # macOS
   # Windows/ImageMagick: magick convert "factory/Products/[product]/images/[file].png" -resize 160x "factory/Products/[product]/scorecards/squint/[file]-160.png"
   ```
   Then open the 160px copy with Read. Record verbatim which words are still readable and which dissolve. Pass = the one dominant message reads in under 2 seconds at that size.

4. **Score 6 dimensions, 1 to 5 each. Apply them ASSET-CLASS-AWARE (below).** For every image:
   - **Message clarity**: one dominant message, and it matches the JOB the brief slot / A+ module / variation assigned this image. Two competing headlines or an off-brief message caps this at 2.
   - **Legibility**: based ONLY on the squint test result from step 3. If the dominant message failed at 160px, this dimension is 1 or 2, whatever it looked like at full size. Variation swatches are held to this HARD: a swatch that cannot be read at tiny size fails its whole job.
   - **Product accuracy**: the image matches the Reference Sheet. Correct size, shape, label, colors, material, and parts (true colors, real button layout, a two-mic machine shows BOTH mics; glass must read as translucent glass, never opaque plastic). A beautiful image of the wrong product scores 1. For variations, the product must match the Reference Sheet and stay consistent with its sibling variants; only the varying attribute (color/size/scent) may differ.
   - **Brand fit**: colors, fonts, and tone versus `brand-kit.md`. A font that fights the brand look is a real deduction, not a nitpick.
   - **Craft**: no AI artifacts, no garbled or misspelled text, no wrong hands or melted objects, clean edges, believable lighting.
   - **Casting** (people-bearing images only, otherwise record `null`): the displayed person matches the persona's aspirational display age, looks authentic. For the LISTING-IMAGE set, the person must also be a DIFFERENT person from every other people-bearing listing image (see the set-level checks). A+ people are judged on authenticity and age-fit only; the different-person rule is scoped to the listing set, not enforced across A+ modules.

   **Asset-class scoring notes:**
   - **Main image**: product-only. Judged on product accuracy, craft, and (if any) a single physical-on-label element. Has an incumbent (the live Amazon main) as its benchmark to beat.
   - **Secondary image**: full 6-dimension scoring as above.
   - **A+ module**: NO incumbent (A+ is not A/B-tested and has no "live" competitor to beat, so do not down-score it for lacking one). People ARE allowed in A+ (it sits below the gallery). Judge each module on module clarity (one job, one message), legibility, compliance, and brand fit. Craft and product accuracy still apply.
   - **Variation main**: product-only, exactly like any main image. No people.
   - **Variation swatch**: judged on tiny-size legibility (must read as the intended color/size/scent chip at thumbnail scale) and consistency with the Reference Sheet and the rest of the variation set. A swatch legitimately REPEATS the product; that is its job, so never flag a swatch for "repeating the product" or for matching its siblings.

5. **Apply the COMPLIANCE GATE (pass/fail, no partial credit).** EVERY image, all classes, FAILS the gate if it contains any of: medical or disease claims, invented percentages or statistics, star ratings or review references, fake badges or awards, third-party logos rendered as graphics, or flag graphics. Real certifications the product actually carries (as they appear on the real label) are allowed.
   **MAIN-specific gate (listing MAIN images and VARIATION MAIN images only):** additionally FAILS if it contains a person, face, or hand, or any overlay text or graphics (anything not physically on the product/label). This main-only rule does NOT apply to secondary images, A+ modules (people and overlay copy are allowed there), or swatches.
   A compliance FAIL sinks the image to the bottom of its slot's/module's ranking regardless of its scores, and it may not be presented as a candidate until fixed.

6. **Run the set-level checks, PER asset class.** Do not pool all classes into one set; a swatch repeating the product or an A+ module reusing a face is not a defect.

   **LISTING-IMAGE set only** (`images/`: mains + secondaries):
   - Duplicate messages: no two listing images carry the same headline or make the same point. Flag any pair.
   - Emotional frame: at least one emotional or lifestyle frame exists in the listing set. Flag if missing.
   - Repeated face: the same person may not appear in two listing images. Flag any repeat.
   - Selling-points coverage: walk the brief's selling-points checklist item by item. Each point is covered by a named image or was consciously skipped in writing in the brief. Any point that simply vanished is a flag.

   **A+ set** (`aplus/`), lighter checklist:
   - Modules cohesive: the modules read as one story hero-to-trust, on-brand and consistent.
   - One message each: no two modules share a headline; each module has a single dominant job.
   - Comparison honest: any comparison module uses real, honest differentiators only (no invented wins).
   (A+ modules MAY reuse a face and MAY repeat product shots; do not flag those.)

   **Variation set** (`variations/`), lighter checklist:
   - Visually consistent set: all variants share angle, lighting, and background family with the Reference Sheet; only the target attribute varies.
   - Correct per-variation labeling: each main/swatch is tagged to the right real child, and the swatch reads as that child's attribute at tiny size.
   (A variation swatch legitimately repeats the product and matches its siblings; that is the job. Never false-flag a swatch for repetition or for looking like the others.)

7. **Rank each group's variants 1..N** (per listing slot, per A+ module, and per variation child). Compliance passes rank above compliance fails, always. Among passes, rank by total score. Stated tie-break, in order: legibility first, then product accuracy, then message clarity. Write the tie-break reason whenever it was used.

8. **AUTO-FIX cheap fails, then re-score (paid-edit policy).** Build the list of cheap, safe fixes: remove a stray element or fake badge, shorten an over-long label, swap a non-compliant word or claim. Present the fix list with a one-line total cost estimate (cents) and get ONE go-ahead from the user; then route them all to `/fix`. Do NOT auto-fix things that need regeneration (tiny text that must be enlarged, layout, casting); list those as "regenerate with a tighter brief" items instead. Re-run steps 2 to 5 on each fixed image and update its scores and rank, and only then present the scorecard. Log every edit per the Fixing Room rules.

9. **Write the scorecard** to `scorecards/scorecard-[YYYY-MM-DD].md` using the Output format, then present the ranked recommendation to the user. The user should only be choosing between gate-passed candidates.

## Output format

`scorecards/scorecard-[YYYY-MM-DD].md`:

```markdown
# Inspection Scorecard . [Product Name] . [YYYY-MM-DD]

Built from: images/ ([N] files), aplus/ ([N] modules or "empty / n-a"), variations/ ([N] files or "empty / n-a"), brief/creative-brief.md, reference/reference-sheet.md (source: [manual/amazon_scraped]), factory/Brand/brand-kit.md, research/persona.md

## Listing-image verdicts

### [filename.png] . slot: [main / secondary 2 / ...]
- What I see: [1-2 line literal description]
- Squint test (160px): [PASS/FAIL] . readable: "[words]" . lost: "[words]"
- Scores: message [x]/5, legibility [x]/5, product accuracy [x]/5, brand fit [x]/5, craft [x]/5, casting [x/5 or null]
- Compliance gate: [PASS / FAIL: exact violation]
- Verdict: [SHIP / FIX: what and how / REGENERATE: what the tighter brief must say]

[...repeat per listing image...]

## A+ module verdicts

### [m3-comparison.png] . module: [hero / benefit / comparison / ...]
- What I see: [1-2 line literal description]
- Squint test (160px): [PASS/FAIL] . readable: "[words]" . lost: "[words]"
- Scores: message [x]/5, legibility [x]/5, product accuracy [x]/5, brand fit [x]/5, craft [x]/5, casting [x/5 or null]
- Compliance gate: [PASS / FAIL: exact violation] (no incumbent expected; people allowed)
- Verdict: [SHIP / FIX / REGENERATE]

[...repeat per A+ module, or "A+ not generated / n-a per INVENT sub-status"...]

## Variation verdicts

### [swatch-amber.png] . child: [amber] . type: [variation main / swatch]
- What I see: [1-2 line literal description]
- Squint test (160px): [PASS/FAIL] . tiny-size legibility: [reads as amber / illegible]
- Scores: message [x]/5, legibility [x]/5, product accuracy [x]/5, brand fit [x]/5, craft [x]/5, casting [null]
- Compliance gate: [PASS / FAIL: exact violation] (variation main = product-only, no people)
- Verdict: [SHIP / FIX / REGENERATE]

[...repeat per variation image, or "variations not generated / n-a per INVENT sub-status"...]

## Set-level summary

### Listing-image set
- Duplicate messages: [none / files X and Y both say "..."]
- Emotional frame: [present in file X / MISSING]
- Repeated face: [none / files X and Y share a model]
- Selling points: [n]/[total] covered. Missing: [point -> proposed home or "consciously skipped, see brief"]

### A+ set
- Modules cohesive: [yes / issue]
- One message each: [yes / M2 and M4 share a headline]
- Comparison honest: [yes / no comparison module / issue]

### Variation set
- Visually consistent: [yes / [child] drifts on background/lighting]
- Per-variation labeling: [all children correctly tagged / issue]

## Rankings (per group)
- MAIN: 1. [file] ([score]) 2. [file] ([score]) [tie-break used: legibility]
- SECONDARY [n]: ...
- A+ [module]: 1. [file] ([score]) ...
- VARIATION [child]: 1. [file] ([score]) ...

## Fixes applied this session
- [file] -> [file_fixN]: [what changed] . re-scored [old] -> [new]

## Needs regeneration (send back to /main-image or /secondary-images, or /aplus or /variations as relevant)
- [file]: [defect] . brief must add: [exact instruction]

## Recommendation
[Ranked pick per slot, one sentence each. The human decides; this is the recommendation.]
```

## Golden Standards check

Before presenting, verify:
- [ ] Every file across `images/`, `aplus/`, AND `variations/` was opened with Read and has a literal description. No image scored unseen. Any empty sub-folder is either a recorded conscious skip (INVENT sub-status) or flagged as a gap.
- [ ] Every image has a 160px squint copy on disk and the legibility score cites it. No full-size legibility judgments. Swatches were read at tiny size specifically.
- [ ] Product accuracy was judged against the Reference Sheet, not memory.
- [ ] Every compliance FAIL names the exact violation and sits at the bottom of its ranking. The MAIN-only gate (no people/overlay) was applied to listing mains and variation mains only, not to secondaries, A+ modules, or swatches.
- [ ] Set-level checks ran PER asset class: the four listing-set checks; the A+ checklist (cohesive, one message each, comparison honest); the variation checklist (consistent set, correct labeling). No swatch was false-flagged for repeating the product, and no A+ module for reusing a face.
- [ ] Cheap fails were listed with a one-line total cost estimate, approved with one go-ahead, fixed, and re-scored BEFORE presenting; nothing on the pick list is a known-defective image.
- [ ] Rankings state the tie-break wherever one was used.
- [ ] The scorecard file exists on disk.

## Wonka lines

Openers:
- "The Inspection Room. Charm stays at the door; only the candy speaks here."
- "Let's see what the machines made. I warn you, I am impossible to flatter."
- "Every piece on the belt, please. Nothing skips the light."

Closers:
- "Now THAT is a piece of candy. Ship the winners to the Tasting Room."
- "Inspected, fixed, ranked. Your only job now is to point at the one you'd click."
- "Wrong, sir, wrong, on two of them. But the Fixing Room already earned its keep. The rest gleam."

## Definition of Done

- `scorecards/scorecard-[date].md` exists with a verdict card for every image across all three asset folders (listing images, A+ modules, variations), the per-class set-level summaries, per-group rankings, fix log, and a recommendation. Any empty sub-folder is recorded as a conscious skip or flagged as a gap.
- All cheap auto-fixes were applied and re-scored; regeneration items are listed with their tighter-brief instructions.
- The user was presented only gate-passed, ranked candidates to pick from.

## Update status.md

Set INSPECT to `done` (or `in-progress` if regenerations are pending) with the scorecard filename as the artifact. Add a Log line: `[date] Inspection complete: [n] images scored, [n] auto-fixed, [n] sent back for regeneration. Scorecard: scorecard-[date].md`.

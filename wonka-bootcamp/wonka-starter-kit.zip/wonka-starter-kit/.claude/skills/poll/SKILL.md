---
name: poll
description: Real shoppers vote on the candidate images through the ProductPinion survey MCP, built and run entirely inside Claude (no external website). The survey always includes the live Amazon incumbent, is targeted to the real buyer persona, and the human approves the cost and publishes before any money is spent. Pulls results back via the MCP, computes vote shares, and mines the "why" comments. Use when candidates are picked and it is time to test, or when results arrive. Triggers: /poll, "run the survey", "ProductPinion", "test the images", "which one wins", "survey the images", "here are the results".
---

# The Poll Room

| Meta | Value |
|------|-------|
| Room | The Poll Room |
| Station | PROVE (step 1 of 3) |
| Needs | Gate-passed candidate images picked by the user, the CURRENT live Amazon main image (the incumbent), `research/persona.md`, the ProductPinion MCP connected |
| Saves to | factory/Products/[product]/tests/poll-[YYYY-MM-DD].md, plus a row in factory/Recipe Book/experiments.md (appended when the survey goes live, updated when results arrive) |
| Typical cost | Varies by respondent count and provider (tell the user to confirm the live estimate the MCP returns). Wonka never spends this; the human approves the cost and publishes. |

## What this room does

A designer's opinion is not data, and neither is Wonka's. This room puts the candidate images in front of real shoppers and counts votes. Wonka BUILDS the survey and RUNS it through the ProductPinion MCP, entirely inside Claude, with no external website to visit. Wonka assembles the candidate images plus the live Amazon incumbent, near-equal metadata, random order, targets the real buyer persona, and presents the cost estimate the MCP returns. The human approves the cost and publishes (that is the step that spends money); Wonka never spends silently. When the results come back through the MCP, Wonka computes the shares, calls the winner honestly (or calls a tie honestly), mines the "why" comments for patterns the Recipe Book can keep, and hands off to `/fix` MODE B for post-survey refinement of the winner.

Tool-agnostic: if ProductPinion is unavailable, the same survey can run via Prolific or PickFu; the method is identical.

## Before you start

- Confirm the user has PICKED the candidates (Inspection Room done, human selection made). If no picks exist, send them back to the scorecard first.
- **The incumbent is mandatory.** Get the CURRENT live Amazon main image (screenshot or download from the live listing) and include it as one of the options in every test. A winner only counts if it beats reality. If the product is not live yet, note `incumbent: none (pre-launch)` explicitly and say the result is weaker for it.
- Read `research/persona.md` for the REAL buyer demographics (age range, gender). If it is missing, mark this station BLOCKED and ask for the Research Room output. Do not target a guess.
- **Casting age vs targeting age:** the aspirational display age used for models in the images is for CASTING ONLY. Respondent targeting always uses the REAL buyer age. Never shave years off the audience.
- Confirm all candidate files exist on disk and open each once with Read to confirm you are testing the files the user actually picked (including any `_fixN` versions).
- Confirm the ProductPinion MCP is connected. If it is not, say so and offer the tool-agnostic fallback (Prolific or PickFu, same method); do not switch silently.

## Process

1. **Choose the survey type.**
   - **Preference survey (default for main images):** all options shown together, respondents pick the one they would click, then answer why. This is the main-image test.
   - For a full gallery or A+ question, a preference survey comparing sets works, but the main image is always tested first and alone.

2. **Assemble the option list.** The user's candidates PLUS the incumbent, in random order. Label them neutrally (A, B, C...), never "current" or "new": respondents must not know which is the incumbent. Keep metadata near-equal across options (same crop ratio, no option gets a flattering border or size).

3. **Build the survey inside Claude (ProductPinion MCP):**
   - **Question wording, exactly:** "Which of these would you click if you were shopping for [product, in plain shopper words]?" plus the follow-up "Why did you choose that one?" Make sure the written-reason (why) question is enabled so comments come back.
   - **Options:** the labeled image list from step 2 (candidates plus the live incumbent), uploaded through the MCP, with filenames mapped in the local spec for the user's eyes only.
   - **Audience targeting:** age range and gender from the REAL buyer persona, plus an Amazon-shopper filter so voters are actual Amazon shoppers. Add any persona-critical trait the MCP supports (for example "has purchased supplements") only if the persona demands it.
   - **Respondents:** 50 (default). Fewer than 50 makes the tie zone huge; more is better if the budget allows.

4. **Get the cost estimate and hand off for publishing. Wonka NEVER publishes or spends.** Have the MCP return the live cost estimate for the configured survey. Present the built survey, the option images, and that one cost line, and tell the user: "You approve and publish, I analyze." The human approving and publishing is the step that spends money; wait for it. Never call any publish/spend action on your own.

5. **Log the experiment when the survey goes live.** When the human confirms the survey is published/live through the MCP, append a row to `factory/Recipe Book/experiments.md` using the canonical 8-column schema:

   `| Date | Product | Type | Candidates | Winner | Margin | Key why | Status |`

   Set Type to `taste-test` and Status to `running`. Candidates = short names of the images in the grid, including "incumbent". Leave Winner / Margin / Key why blank for now.

6. **When results arrive** (pull them back through the ProductPinion MCP once the survey completes):
   - Compute each option's vote share (votes / total, as a percentage).
   - **Call the winner only if the lead is meaningful.** Rule of thumb, written into every report: with 50 votes, a gap under ~10 percentage points is a coin flip. Under that gap, either extend the survey with more respondents or treat it as a tie; never crown a coin flip.
   - Always report how the winner did AGAINST THE INCUMBENT specifically. Beating our own other candidate means little if the incumbent still leads.
   - **Mine the "why" comments.** Group them into patterns (for example: "8 of 14 winner comments mention the size callout", "the loser's text was called 'busy' 5 times"). Quote 2 or 3 verbatim. Patterns feed `/fix` MODE B and `/improvement-loop`.
   - **Update the experiments.md row.** Find the `taste-test` row appended at publish time and fill in: Winner, Margin (e.g. "42% vs 31%, n=50"), Key why (one clause), and Status = `won` / `lost` / `inconclusive`. `won` only if a candidate beat the incumbent meaningfully (the ~10-point rule).

7. **Write the test file** to `tests/poll-[YYYY-MM-DD].md` per the Output format, then hand off. Send the mined "why" comments to `/fix` MODE B to refine the winning candidate; if the top complaint needs a spatial change, build one challenger via `/main-image` and plan a re-test. If there is a real winner that beat the incumbent and the user does not want a refinement round, the Shipping Room (`/publish`) is open. Either way, `/improvement-loop` runs on the result.

## Output format

`tests/poll-[YYYY-MM-DD].md`:

```markdown
# Taste Test . [Product Name] . [YYYY-MM-DD]

Built from: candidates picked on scorecard-[date].md, incumbent from the live listing, research/persona.md

## Setup
- Method: [ProductPinion preference survey via MCP / fallback: Prolific or PickFu, same method]
- Options: A=[filename], B=[filename], C=incumbent (live Amazon main) [order randomized]
- Question: "Which of these would you click if you were shopping for [product]?"
- Audience: age [real buyer range], [gender], Amazon shoppers, n=[50]
- Cost: [estimate the MCP returned], approved and published by the user on [date]

## Survey spec (as built and handed off for approval)
[the exact survey configuration passed to the ProductPinion MCP]

## Results
| Option | File | Votes | Share |
|---|---|---|---|
| A | [file] | [n] | [x]% |
| C (incumbent) | live main | [n] | [x]% |

- Verdict: [WINNER: option X beat the incumbent by [n] points / TIE: lead under ~10 points at n=50, extend or treat as tie / INCUMBENT HELD: our candidates lost]
- Confidence note: [n] votes; gaps under ~10 points at n=50 are coin flips.

## Why they voted (comment mining)
- Pattern: [x of y comments say ...] . example: "[verbatim quote]"
- Pattern: ...

## Next step
[/fix MODE B to refine option X from the comments / /publish for option X / a challenger via /main-image / extend the survey / back to the Creative Brief with these lessons]
```

## Golden Standards check

Before presenting, verify:
- [ ] The incumbent is one of the options (or `pre-launch, no incumbent` is stated in writing).
- [ ] Targeting uses the REAL buyer age from persona.md, never the aspirational casting age.
- [ ] Options are labeled neutrally and ordered randomly; no option is visually favored.
- [ ] The question wording matches the standard, and "why" comments are collected.
- [ ] The survey was built and run inside Claude via the ProductPinion MCP (no external website); the MCP cost estimate was shown and the HUMAN approved and published. No spend happened from this side.
- [ ] The verdict respects the ~10-point rule at n=50; no coin flip was crowned.
- [ ] The winner's performance against the INCUMBENT is stated explicitly.
- [ ] The test file exists on disk with results and mined comments (or with the spec and `status: awaiting results`).

## Wonka lines

Openers:
- "To the Poll Room. My opinion retires at this door; the shoppers take it from here."
- "Fifty strangers, one question, no mercy. Exactly how I like my data."
- "We don't guess in this factory. We test. Bring the incumbent; it fights too."

Closers:
- "The shoppers have spoken. I merely work here. Option B takes the ticket."
- "A tie, honestly earned. We extend the poll or we call it even; we do not squint at a coin flip."
- "This batch lost. Good. Now we know two things the shoppers hate, and the Recipe Book just got smarter."

## Definition of Done

- `tests/poll-[date].md` exists with the full survey spec, the option map, and either results plus verdict plus mined comments, or `status: awaiting results` after handoff.
- `factory/Recipe Book/experiments.md` has the run's row: appended with Type `taste-test` and Status `running` when the human confirmed the survey was live, and updated with Winner / Margin / Key why / Status (`won` / `lost` / `inconclusive`) once results were analyzed.
- The user knows the exact next step (approve and publish, results pulled back, or proceed to `/fix` MODE B, `/publish`, and `/improvement-loop`).

## Update status.md

Set PROVE to `in-progress` with the test file as the artifact. Add a Log line: `[date] Poll [built and handed off for approval / results in: verdict]. See tests/poll-[date].md.`

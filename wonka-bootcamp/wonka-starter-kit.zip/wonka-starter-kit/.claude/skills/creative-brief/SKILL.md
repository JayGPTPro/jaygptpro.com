---
name: creative-brief
description: Produce the full creative brief for the product's creative package, per-slot briefs, casting, compliance, coverage map, and test hypotheses. Use when research is done and the user wants the brief that generation will follow. Triggers: /creative-brief, "write the brief", "create the creative brief", "build the brief", "plan my image set", "shot list".
---

# The Brief Room

| Meta | Value |
|------|-------|
| Room | The Brief Room |
| Station | BRIEF |
| Needs | ALL research/ files (insights, reviews, persona, selling-points, competitors), factory/Brand/brand-kit.md, factory/Recipe Book/ learnings |
| Saves to | factory/Products/[product]/brief/creative-brief.md (the brief for the FULL package: main + secondary images + A+ content + product variations) |
| Typical cost | Free. Writing only; the spending starts in the generation rooms. |

## What this room does

This is the heart of the Factory. The Brief turns everything the Research Room learned into a per-image creative brief for the FULL creative package: the main image, the secondary gallery, the A+ content modules, and the product variations. One job and one message per asset, casting specs, compliance notes, and a coverage map that proves no selling point was dropped by accident. Every asset the factory produces (in the Main Image Room, the Secondary Images Room, the A+ Room, and the Variations Room) is judged against this document. No brief, no candy.

## Before you start

Check inputs, in this order:
- `research/insights.md`, `research/reviews.md`, `research/persona.md`, `research/selling-points.md`, `research/competitors.md`: if ANY is missing, the station is **BLOCKED**. Point to `/meet-my-product` and stop.
- `factory/Brand/brand-kit.md`: if missing, offer `/brand-kit` first. The user may proceed, but every visual-style field is then marked `pending brand kit` and must be filled before generation.
- `reference/reference-sheet.md`: not required to WRITE the brief, but note its state; if the reference is not yet LOCKED, remind the user that `/reference-sheet` must pass its smoke test before any generation room runs on this brief.
- `factory/Recipe Book/`: read any learnings and tested winners. Past test results OVERRIDE general best practices; if the Recipe Book says a style lost for this brand, do not brief it again. **Say what you found, out loud, either way.** If the book has patterns, name the ones this brief applies. If the book is EMPTY, say so in one line and make the promise explicit: "The Recipe Book is empty; this is your first product, so this brief runs on research and best practices alone. After your first Tasting Round, this book starts filling, and your next brief will not start from zero." That single line is how the user first SEES the learning loop, episodes before it closes.
- Read `status.md` Owner intel: must-include and avoid items bind this brief.

## Process

1. **Open with provenance.** The first line of `creative-brief.md` is `Built from:` listing every input file read, with dates. Missing inputs are named honestly (`brand kit: pending`).

2. **Write the strategy summary** (5 to 10 lines): what this creative package must PROVE to convert this persona. Anchor it in the top pain points, the sharpest objection, the whitespace opening, and the best-frame target from the competitor teardown. Include the funnel diagnosis from `research/insights.md`: the MAIN image is the CTR lever (it wins the click on the search page), while the secondary gallery and A+ are the CVR lever (they close the sale after the click). This paragraph is the tiebreaker for every slot decision below.

3. **Design the set structure.** Default set: 1 MAIN plus 5 to 7 SECONDARY slots (a full Amazon gallery of 6 to 8 images). Assign each secondary exactly ONE job from this menu (adapt to the product, cover the strategy):
   - Benefit hero (the number one benefit, visualized)
   - Ingredient or material proof (what it is made of, shown honestly)
   - How-to (usage in 2 to 4 steps)
   - Lifestyle emotional (the persona's dream outcome, with a person)
   - Comparison or objection-buster (versus the old way or the generic option; answer the top objection)
   - Scale and dimensions (real size, hand or context for scale)
   Set-level rules: no two slots share a message; at least one emotional frame; the strongest hook goes earliest in the gallery order.

4. **Brief the MAIN image.** Product only. NO people, no faces, no hands, EVER, in any variant. Write 4 distinct STRATEGY variants to test (fewer only if the research genuinely cannot support 4 distinct bets; then say so) (for example: clean product on white with a physical on-label seal visible; product plus honest ingredient props; product plus premium packaging angle). Each variant states its composition, what makes it distinct, and its hypothesis (why it might out-click the current live image). Keep main-image text near zero; anything on the product must exist on the real label.

5. **Brief every SECONDARY slot.** Each slot gets:
   - **Job**: the one thing this image proves.
   - **Message**: ONE headline, maximum 6 words. Prefer verbatim customer language from `reviews.md`.
   - **Composition**: what is in frame, product placement, prop accuracy named EXPLICITLY (correct materials and details: "chia seeds are tiny specks, not sunflower seeds"; "the karaoke machine must match the real product exactly: true colors, real button layout, BOTH microphones present, never one").
   - **Supporting elements**: up to 3 short labels or icons, no more. Legibility constraints restated: one dominant message, minimum text size about 3.5% of the short edge, must pass the 160px squint test.
   - **Casting spec** (people-bearing slots only): a DIFFERENT specific person per slot, described concretely (age as displayed, hair, ethnicity; vary these across the set). Displayed age uses the aspirational skew from `research/persona.md` applied to the persona's REAL age. Write the casting INTO the slot brief text, because generation tools ignore separate age fields.
   - **Compliance notes**: what this slot must NOT contain, from the avoid-list (no medical claims, no invented percentages, no star ratings or review references, no fake badges, no third-party logos rendered as graphics, no flag graphics) plus any owner-intel avoids.
   - **Brand style**: colors (hex), font style, and tone pulled from `brand-kit.md`.

6. **Plan the A+ content modules.** A+ is part of the same package and is briefed here (the A+ Room generates it off this plan). Design a module set (a typical A+ is 5 to 7 modules) where each module has ONE job and ONE message, cover the CVR story: brand intro, benefit deep-dive, ingredient or material proof, how-to, a comparison module where it genuinely helps the shopper decide (comparison modules are good A+ practice), and a lifestyle or trust closer. For each module, write: job, one headline, the supporting copy points (short), the image concept, casting (if people appear, same aspirational-skew and diversity rules as secondaries), and the compliance avoid-list. Legibility applies to A+ too: one dominant message per module, big legible text, no icon soup. A+ is NOT A/B-tested like the main image, but it may be realigned later if a test flips the winning angle.

7. **Plan the product variations.** List the REAL variations the product actually has (sizes, colors, scents, counts, bundles). Do not invent variations. For each variation, brief the imagery it needs: its own variation-specific MAIN, plus swatches or thumbnails that read clearly in the variation picker. Every variation stays consistent with the locked Reference Sheet (same product identity, only the varying attribute changes) and with the brand kit. If the product has no variations, state `variations: none (single SKU)` and skip.

8. **Fill the coverage map (across the full package).** Take every ID from `research/selling-points.md` and map it to at least one asset across MAIN, SECONDARY, A+, and VARIATIONS. Every table stake must land on at least one asset. Items not mapped anywhere are listed under "Consciously skipped" WITH the reason (off-strategy, cannot be shown honestly, tested loser per Recipe Book, slot budget). An empty reason is not allowed; silence is how selling points die.

9. **Rank the test hypotheses.** For the main variants: which one tests FIRST against the incumbent (the current live Amazon image) and why, with the expected winning mechanism ("variant A makes both microphones readable at thumbnail size; incumbent shows only one"). One or two backup hypotheses follow.

10. **Run the Golden Standards check below, then present.** Show the user the strategy summary, the slot list with jobs and messages, the A+ module list, the variations list, and the coverage-map totals. Point to `brief/creative-brief.md` for the full brief. Ask for their read: they know their product; a wrong assumption is cheapest to fix here.

## Output format

`brief/creative-brief.md`:

```markdown
# Creative Brief . [Product Name]
Built from: research/insights.md ([date]), research/reviews.md, research/persona.md,
research/selling-points.md, research/competitors.md, factory/Brand/brand-kit.md,
factory/Recipe Book/ ([learnings applied or "empty"]). Written [YYYY-MM-DD].

## Strategy summary
[5 to 10 lines: what the set must prove, for whom, against what incumbent and competitors, plus the funnel diagnosis]

## Set structure
| Slot | Job | Message (max 6 words) | People |
|---|---|---|---|
| MAIN | product hero | [near zero text] | NO. Never. |
| S1 | [job] | "[headline]" | [yes: casting id / no] |

## MAIN image (4 variants, product only, no people)
### Variant A: [name]
- Composition: ...
- Distinct because: ...
- Hypothesis vs incumbent: ...
(repeat per variant)

## Secondary slots
### S1 . [Job]
- Message: "[headline, max 6 words]" (source: [review quote / insight])
- Composition: [including explicit material/botanical accuracy lines]
- Supporting elements: [max 3]
- Legibility: one dominant message, min text ~3.5% short edge, 160px squint must pass
- Casting: [displayed age, hair, ethnicity, distinct from all other slots] or "no people"
- Compliance: [slot-specific avoid items]
- Brand: [hex colors, font style, tone from brand-kit]
(repeat per slot)

## A+ content modules (5 to 7 modules, one job each)
### M1 . [Job]
- Message: "[headline]"
- Copy points: [short supporting points]
- Image concept: [what is shown]
- Casting: [aspirational-skew + distinct person, or "no people"]
- Compliance: [module-specific avoid items]
(repeat per module; include a comparison module where it genuinely helps the shopper decide)

## Product variations
- Variations (real): [size / color / scent / count / bundle list, or "none (single SKU)"]
### [Variation name]
- Variation MAIN concept: [product-only, consistent with the Reference Sheet]
- Swatch / picker thumbnail: [what reads clearly at small size]
- Consistency note: [same product identity as the Reference Sheet; only the varying attribute changes]
(repeat per variation)

## Selling-points coverage map (full package)
| ID | Selling point | Mapped to (MAIN / S# / M# / Variation) | Skipped because |
|---|---|---|---|
| SP1 | [point] | S2, M3 | |
| SP7 | [point] | . | [explicit reason] |
Covered: [N/total]. Consciously skipped: [M], all with reasons. Every table stake mapped to at least one asset.

## Test hypotheses (ranked)
1. MAIN Variant [X] vs incumbent: [mechanism]. Test first.
2. [backup]

## Avoid list (restated)
[compliance avoid-list + owner-intel avoids + Recipe Book losers]
```

Also update `research/selling-points.md`: fill its "Mapped to" and "Skipped because" columns to match the coverage map.

## Golden Standards check

Before presenting, verify:
- [ ] Provenance line lists every input actually read; missing inputs named, not papered over.
- [ ] MAIN briefs contain zero people in every variant, and 4 genuinely distinct strategies, not one idea in four outfits.
- [ ] Every secondary has ONE job and ONE message of 6 words or fewer; no two slots share a message.
- [ ] Every people-bearing slot has a distinct casting spec written into the brief text, aspirational skew applied, variety across the set.
- [ ] Materials and botanicals named explicitly wherever the product's substance matters.
- [ ] A+ modules briefed: each one job and one message, comparison module included where it helps, legibility and compliance applied.
- [ ] Variations briefed from the REAL SKU list (none invented); each has its variation MAIN plus swatch, consistent with the Reference Sheet; or `variations: none (single SKU)` stated.
- [ ] Coverage map spans MAIN + SECONDARY + A+ + VARIATIONS, accounts for 100% of selling-point IDs (mapped or skipped-with-reason, zero blanks), and every table stake lands on at least one asset.
- [ ] At least one emotional frame; the strongest hook leads the gallery order.
- [ ] Recipe Book learnings applied; no re-briefing of documented losers.
- [ ] Avoid-list restated in the brief itself, so the generation rooms cannot miss it.

## Wonka lines

Openers:
- "The Brief Room. My favorite floor. Every great candy starts with a recipe, every great image starts with a brief."
- "Research in, brief out. Watch closely, this is where the magic gets its instructions."
- "Ladies and gentlemen... we write the Brief."

Closers:
- "The Brief is written: [N] frames, every selling point accounted for, nothing skipped in silence."
- "Read it twice. The generation rooms follow this to the letter, so any doubts speak now."
- "No brief, no candy. And now you have a brief. To the Main Image Room."

## Definition of Done

- `brief/creative-brief.md` exists with provenance, strategy summary (with the CTR/CVR funnel diagnosis), MAIN variants, all secondary slot briefs, the A+ module plan, the variations plan, a 100% full-package coverage map (MAIN + SECONDARY + A+ + VARIATIONS), ranked test hypotheses, and the restated avoid list.
- `research/selling-points.md` columns updated to match.
- The user has seen the summary and had the chance to correct assumptions (or, in a solo/assistant run, the brief records `Owner review: PENDING` and the generation rooms surface it before spending).

## Update status.md

Set BRIEF to `done` (or `blocked: [missing input]`), artifact `brief/creative-brief.md`, and add a Log line: `[date] Creative brief written (full package): [N] image slots, [K] A+ modules, [V] variations, [X/Y] selling points mapped, [M] consciously skipped.`

---
name: creative-brief
description: Write the full creative brief for a product's whole creative package. Main image variants written as test hypotheses, the secondary slot plan, the A+ module plan, the variations plan, casting, compliance, a selling-points coverage map, and ranked test hypotheses. Use when research is done and the user wants the plan every generation room will follow. Triggers: /creative-brief, "write the brief", "create the creative brief", "build the brief", "plan my image set", "plan my A+", "shot list", "brief room".
---

# The Brief Room

| Meta | Value |
|------|-------|
| Room | The Brief Room |
| Station | BRIEF |
| Day | Day 4 of the bootcamp. Outside the bootcamp, run it whenever RESEARCH is done. |
| Needs | All five `research/` files (hard), plus `factory/Brand/brand-kit.md`, `reference/reference-sheet.md`, `factory/Recipe Book/`, `factory/Wonka's Notebook/notebook.md`, `status.md` Owner intel (see the input table) |
| Saves to | factory/Products/[product]/brief/creative-brief.md (the brief for the FULL package: main image + secondary gallery + A+ modules + product variations) |
| Typical cost | Free, and say so out loud. Writing a brief and re-rolling it costs nothing. This is the last free gate before anything costs credits. |

## What this room does

This is the heart of the Factory. The Brief turns everything the Research Room learned into a per-asset creative brief for the FULL creative package: the main image, the secondary gallery, the A+ modules, and the product variations. One job and one message per asset, casting specs, compliance notes, and a coverage map that proves no selling point was dropped by accident. Every asset the factory produces later is judged against this document. No brief, no candy.

It has a second job that matters just as much. **A brief decides what the images are allowed to PROMISE.** The most expensive listing failure in the world is an image that promised something the product does not always deliver, because the buyer arrives excited, gets something else, and writes a one star review about a product working exactly as specified. Every message in this document goes through the promise check in step 10 before it reaches a generation room.

## Before you start

Read the inputs first, then handle each one exactly as this table says. Never guess at an input, and never present a guess as research.

| Input | If it is missing |
|---|---|
| `research/insights.md`, `reviews.md`, `persona.md`, `selling-points.md`, `competitors.md` | **HARD BLOCK.** These are the previous room's output, not something the owner "has" or "does not have". Name the missing file, point to `/meet-my-product`, and stop. The block clears with one command. If the owner insists on proceeding anyway, refuse in plain words and say what it would take: a brief written from memory of the category is decoration, and it would spend real credits on invented problems. |
| A research file that EXISTS but records a waiver, a BLOCKED marker, or a thin sample ("no critical reviews provided") | **PROCEED.** Copy the gap verbatim into `## Gaps carried forward` in the brief and lower the confidence line. Never read a waiver stub as evidence. |
| `factory/Brand/brand-kit.md` | **PROCEED** and offer `/brand-kit`. Every visual-style field is marked `pending brand kit` and must be filled before generation. Say out loud which two things are missing with it: the APPROVED CLAIMS table and the brand avoid list, which is what step 10 tests against. |
| `reference/reference-sheet.md` not locked, or missing | **PROCEED.** Writing costs nothing and the brief does not need the lock. Record the status in the provenance line and remind the owner that no generation room opens until `Reference status: LOCKED` and `Smoke test: PASS`. |
| `factory/Recipe Book/` | **PROCEED.** See step 1: its state gets reported out loud either way. |
| `factory/Wonka's Notebook/notebook.md` | **PROCEED** silently if absent. If present, apply any owner working-style preferences it records for briefs. |
| `status.md` Owner intel (must-include, avoid, known winners) | **PROCEED.** If it reads "none given", write `owner intel: none given` in the brief. Never invent intel. |
| The real variation list (sizes, colors, scents, counts, bundles) | **ASK the owner.** If the answer is "I do not know", write `variations: unconfirmed` plus the one line on how to confirm it (the listing's variation picker, or Seller Central). Never write `none` on a guess. |
| The current live main image and gallery (the incumbent) | If the product is not live yet, record `incumbent: none (pre-launch)` and the main hypotheses become candidate versus candidate instead of candidate versus incumbent. |

## Process

1. **Report the Recipe Book state OUT LOUD, before writing a word of the brief.** Read `factory/Recipe Book/`. If it holds patterns and tested winners, name the ones this brief will apply, and treat them as overriding general best practice: a style that lost a test for this brand does not get briefed again, and the losing row is cited. If it is EMPTY, say so in one line and make the promise explicit: "The Recipe Book is empty. This is your first product, so this brief runs on your research and on best practice alone. After your first Tasting Round that book starts filling, and your next brief will not start from zero." That single line is how the owner first SEES the learning loop, days before it closes.

2. **Extract the selling-points checklist FIRST, and keep it open as the spine.** Before any strategy, before any slot, pull every ID from `research/selling-points.md` into a working coverage table: ID, selling point, source, and an EMPTY target column. Every table stake, top feature, whitespace opening, differentiator, and material or quality signal is on it. This table is what the brief gets built around, not something checked against it afterwards. It gets closed in step 11 and it is what stops selling points dying in silence.

3. **Open the file with provenance.** The first line of `creative-brief.md` is `Built from:` listing every input actually read, with dates, and stating honestly:
   - the five research files, and whether any carries a waiver;
   - the Reference Sheet's status AND its photo source (`source: manual_photos` or `source: amazon_scraped`). Write the source plainly. A reference built from listing and review images carries more guessing about size, backs and sides, and the brief is where that is visible to anyone reading it later;
   - the brand kit, or `brand kit: pending`;
   - the Recipe Book state (`empty` or the learnings applied).

4. **Write the strategy summary (5 to 10 lines).** What this package must PROVE to convert this persona. Anchor it in the top pain points, the sharpest objection, the whitespace opening, and the best frame from the competitor teardown. Then state the funnel diagnosis from `research/insights.md` and let it set the WEIGHTING: the MAIN image is the CTR lever (it wins the click in search), the secondary gallery and A+ are the CVR lever (they close the sale and set expectations). A click leak means the brief piles onto the main. A close leak means it piles onto the gallery and the A+. If the diagnosis is marked `estimated` or `no data`, say so here in the brief, do not launder it into certainty, and hedge across both. This paragraph is the tiebreaker for every decision below.

5. **Design the set structure.** Default: 1 MAIN plus 5 to 7 SECONDARY slots (Amazon shows roughly 6 to 8 gallery images including the main). Fewer strong slots beat more mushy ones; the scarce thing is messages, not pixels. Assign each secondary exactly ONE job from this menu, adapted to the product:
   - Benefit hero (the number one benefit, visualized)
   - Ingredient or material proof (what it is made of, shown honestly)
   - How-to or setup (usage in 2 to 4 steps)
   - Lifestyle emotional (the persona's outcome, with a person)
   - Comparison or objection-buster (versus the old way or the generic option; answer the top objection)
   - Scale and dimensions (real size, a hand or a context object for scale)
   Set-level rules: no two slots share a message, at least one emotional frame, the strongest hook leads the gallery order.

6. **Brief the MAIN image.** Product only. NO people, no faces, no hands, EVER, in any variant. NO overlay text or graphics of any kind: the only marks allowed are what physically exists on the product and its label.
   - First, read the incumbent. Write one line on what the current live main image does and what it fails to answer. Every hypothesis below beats THAT image by a named mechanism.
   - Write 4 distinct STRATEGY variants. **Distinctness test: each variant must state a different REASON A SHOPPER CLICKS.** Two variants that differ only in angle, background or props are one bet in two outfits: merge them and find a real fourth reason, or drop to 3 variants and say so in writing. Never pad to four with near duplicates.
   - Each variant states its composition, what makes it distinct, and its hypothesis ("variant C makes the real height readable at thumbnail size; the incumbent gives no scale reference at all").
   - Amazon's requirements for the MAIN slot are strict about background, frame fill, and props, and the current requirements page is the authority, not this brief. Any variant that leans on props gets a one-line flag in the brief so it is a deliberate call with open eyes, never an accident.

7. **Brief every SECONDARY slot.** This local brief is your THINKING artifact and it stays thorough. But it is a DISTILLATION SOURCE, not text to forward: the generation rooms route each part to the field that enforces it. Each slot gets:
   - **Job**: the one thing this image proves.
   - **Message**: ONE headline, maximum 6 words. Count the words. Prefer customer language from `reviews.md` reshaped into our own copy. **Use their words, never their review**: a customer's phrasing as our headline is smart, the same line presented AS a review (quotation marks plus stars, "verified buyer", a rating graphic) is a compliance problem. (Routes to the header-phrase field as finished on-image copy, never pasted into slot text.)
   - **Composition**: what is in frame, product placement, whether a person appears, and prop and material accuracy named EXPLICITLY. Name the real materials from the Reference Sheet, especially where a render would flatter them ("the base is stainless steel, the tiers and the auger are plastic; do not render the whole machine as gleaming steel"), and name the real part count ("all four tiers visible"). (This IS the 2 to 5 sentence content brief the generation room sends.)
   - **Supporting elements**: up to 3 short labels or icons, no more. Win legibility by subtraction: fewer elements means bigger text. (The count routes to a one-line constraint. The ~3.5% minimum size and the 160px squint test are the INSPECTION room's mechanical checks, never generation text.)
   - **Casting** (people-bearing slots only): name the avatar this slot uses, with an EXPLICIT displayed age (the aspirational skew from `research/persona.md` applied to the persona's REAL age) and gender. A DIFFERENT avatar per people-slot, and the avatar count matches the people-slot count. Casting is a structured field the generation room sets at planning; it never appears inside composition text, because blank avatar fields, not weak prose, were the real cause of the old age drift.
   - **Constraints**: short, and only what is genuinely ours to enforce. No medical claims, no invented percentages, no star ratings or review references, no flag graphics, plus the brand kit and owner-intel avoids that apply to this slot. (Third-party logos, fake badges, and floating graphics are blocked by Genrupt system-side. Noted here for the fallback path and for inspection, never restated to Genrupt.)
   - **Source**: which research line this slot answers to (a review pain, a listing spec, a whitespace item, owner intel). A slot with no source line is decoration.
   - Brand style (colors, fonts, tone) is NOT part of a slot brief: the branding preset applied to the flow owns the look, and design-dictating slot text overrides it and flattens the output.

8. **Plan the A+ modules.** A+ is part of the same package and is briefed here; the A+ Room generates off this plan. Design 5 to 7 modules (never more than 7), each with ONE job and ONE message, covering the CVR story: brand or hero banner, 2 to 3 benefit modules, an ingredients or how-it-works module, a comparison module where it genuinely helps the shopper decide, a lifestyle or story module, and a trust, specs or FAQ closer built from the real questions in `reviews.md`. For each module write: job, one headline, short copy points, the image concept, casting (same rules as secondaries, a distinct avatar from the gallery's), and the compliance avoid items. No module repeats another's headline. Legibility applies to A+ too: one dominant message, big legible text, no icon soup. A+ is not A/B tested like the main image, but it may be realigned later if a Tasting Round flips the winning angle.

9. **Plan the product variations.** List the REAL variations the product has. Do not invent variations, and do not write `none` on a guess (see the input table). For each real variation, brief its own variation-specific MAIN plus the swatch or picker thumbnail that reads clearly at small size, consistent with the locked Reference Sheet (same product identity, only the varying attribute changes) and the brand kit. If there are genuinely none, write `variations: none (single SKU)` in the file rather than leaving the section empty: writing the absence down is the coverage discipline applied to a whole section. This section may be amended later, once a winner exists, through the revision protocol in step 14.

10. **Run the PROMISE CHECK on every message in the brief.** Take each headline, each A+ headline and copy point, and anything printed on the product in a MAIN variant, and ask three questions:
    1. **Is it sourced?** Point to the listing, the label, the reviews, or owner intel. No source, no claim. A claim the brand kit's APPROVED CLAIMS table does not carry is not ours to make.
    2. **Do the reviews contradict or SPLIT on it?** A theme buyers argue about (some say it is a breeze, some say it is a hassle) is not a promise, it is a coin flip. A promise on a split theme betrays a chunk of buyers by design.
    3. **Would a buyer who believes this line and then opens the box feel misled?** If yes, that headline is the next one star review.
    The fix has one shape every time: **keep the job, drop the promise, show the mechanism.** The image teaches how the thing works and leaves the outcome unpromised. Record the result in the brief as one line: `Promise check: [N] messages tested, [M] rewritten, [reason for each rewrite]`. Any message that stays deliberately close to the line records why it is safe. Do NOT hand a brief to a human without running this. It is the cheapest possible place to catch a promise the product cannot always keep.
    Then RESTATE the avoid list at the end of the brief, in the brief's own words: the brand kit's avoid list, the boundary of its APPROVED CLAIMS table, the owner-intel avoids, any Recipe Book losers, and the standing compliance items. The generation rooms read this file and not the brand kit, so an avoid that lives only in the brand kit is an avoid that does not exist.

11. **Close the coverage map.** Return to the spine from step 2 and fill every target cell across MAIN, SECONDARY, A+ and VARIATIONS. Every table stake must land on at least one asset. Anything not mapped goes in the skipped column WITH a reason from this menu, never blank:
    - off-strategy for this package;
    - cannot be shown honestly (no evidence, or the claim is not ours to make);
    - **creative cannot fix it** (a part that arrives cracked, a shipping problem, a manual that is missing). Name WHO owns it instead: packaging, quality control, the manual, customer service. A coverage map is a written record of what images cannot fix, and most briefs quietly pretend that category does not exist;
    - tested loser (cite the Recipe Book row);
    - slot budget (say what won the slot instead).
    Partial mapping is lawful and gets written down: keeping an idea while dropping an unsupportable specific ("the rental comparison goes in the A+ closer, the dollar figure comes out; it is one reviewer's rental market, not a fact about ours") is recorded as mapped WITH the note. Then update `research/selling-points.md` so its "Mapped to" and "Skipped because" columns match this map exactly, with zero blank cells.

12. **Rank the test hypotheses.** Which MAIN variant runs FIRST against the incumbent and why, with the expected winning mechanism spelled out. One or two backups follow. A hypothesis is a testable claim about a mechanism, never a statement of taste: "it looks better" is not a hypothesis. The Tasting Room settles these later (Day 8 in the bootcamp).

13. **Scan for placeholders, run the Golden Standards check, then present.** Search the finished file for `TBD`, `XXX`, `insert`, `lorem`, `[` and `pending`. The only lawful survivors are the ones this skill declares on purpose: `pending brand kit`, `variations: unconfirmed`, `incumbent: none (pre-launch)`, `Owner review: PENDING`. Anything else means an input is missing: name which one, out loud. Then re-read the saved file from disk to confirm it wrote, run the checklist below, and present to the owner: the strategy summary, the slot list with jobs and messages, the A+ module list, the variations line, the coverage totals, and the promise-check line. Point to `brief/creative-brief.md` for the whole thing. Then ask for their read, plainly: this is a draft until they approve it, they know their product and their buyers, and a wrong assumption is cheapest to fix right here, for free.

14. **The revision protocol (when the owner pushes back).** Pushback is the review step working, and it usually comes from a better memory of what makes buyers angry, not from better taste.
    - Change ONLY what was asked. Never rewrite the brief around one note.
    - Re-run the affected checks only: the promise check on the new message, uniqueness against the other slots, and the coverage map if that slot carried a selling point (confirm the point still lands somewhere).
    - Record it in `## Revisions` at the bottom of the file: date, what changed, and the owner's REASON in their words. In six months that reason is the only thing that explains the file.
    - Re-present the revised block, not the whole document.
    - If an instruction collides with a factory law (people in the main image, a claim with no evidence, a promise the reviews split on), say so plainly, offer the closest lawful version, and let the owner decide. Never silently comply, and never silently refuse.

## Output format

`brief/creative-brief.md`. Keep this section order: the coverage map sits high, right under the strategy, because it is the index of the whole brief.

```markdown
# Creative Brief . [Product Name]
Built from: research/insights.md ([date]), research/reviews.md ([N pos, M crit]),
research/persona.md (source: [brand_registry_export / estimated]), research/selling-points.md,
research/competitors.md, reference/reference-sheet.md ([LOCKED / not locked], source:
[manual_photos / amazon_scraped]), factory/Brand/brand-kit.md ([done / pending]),
factory/Recipe Book/ ([learnings applied / empty]). Written [YYYY-MM-DD].
Owner review: [PENDING / approved YYYY-MM-DD]

## Gaps carried forward
- [any waived or thin input, verbatim, and what it weakens] (or "none")
- Confidence: [high / medium / low], because [one line]

## Strategy summary
[5 to 10 lines: what the package must prove, for whom, against which incumbent and competitors,
plus the funnel diagnosis and the weighting it sets. Mark it `estimated` where it is estimated]

## Selling-points coverage map (full package)
| ID | Selling point | Mapped to (MAIN / S# / M# / Variation) | Skipped because |
|---|---|---|---|
| SP1 | [point] | S2, M3 | |
| SP7 | [point] | . | creative cannot fix it: [who owns it instead] |
Covered: [N/total]. Consciously skipped: [M], every one with a reason.
Every table stake mapped to at least one asset.

## Promise check
[N] messages tested, [M] rewritten. [What was rewritten and why]

## Set structure
| Slot | Job | Message (max 6 words) | People |
|---|---|---|---|
| MAIN | product hero | none (zero overlay text) | NO. Never. |
| S1 | [job] | "[headline]" | [avatar id / no] |

## MAIN image ([N] variants, product only, no people, zero overlay text)
Incumbent read: [what the current live main does, and what it fails to answer]
### Variant A: [name]
- Composition: ...
- Distinct because (the reason a shopper clicks): ...
- Hypothesis vs incumbent: [mechanism]
- Props flag: [none / leans on props, check against the current Amazon requirements page]
(repeat per variant)

## Secondary slots
### S1 . [Job]
- Message: "[headline, max 6 words]" (source: [review quote / insight])   -> header-phrase field
- Composition (the 2 to 5 sentence content brief): [scene, objects, person or not, explicit
  material and part accuracy]
- Supporting elements: [max 3]   -> one-line constraint
- Casting: [avatar id, displayed age, gender] or "no people"   -> custom avatars, never slot text
- Constraints (short): [e.g. no invented percentages, no star ratings, plus brand-kit avoids]
- Source: [the research line this slot answers to]
(repeat per slot; brand look comes from the branding preset, never written per slot)

## A+ content modules ([5 to 7], one job each)
### M1 . [Job]
- Message: "[headline]"
- Copy points: [short supporting points]
- Image concept: [what is shown]
- Casting: [avatar id, displayed age, gender, distinct from the gallery] or "no people"
- Compliance: [module-specific avoid items]
(repeat; include a comparison module where it genuinely helps the shopper decide)

## Product variations
- Variations (real): [list, or "none (single SKU)", or "unconfirmed: [how to confirm]"]
### [Variation name]
- Variation MAIN concept: [product-only, consistent with the Reference Sheet]
- Swatch / picker thumbnail: [what reads clearly at small size]
- Consistency note: [same product identity; only the varying attribute changes]

## Test hypotheses (ranked)
1. MAIN Variant [X] vs incumbent: [mechanism]. Test first.
2. [backup]

## Avoid list (restated)
[the brand kit's avoid list + its APPROVED CLAIMS boundary + owner-intel avoids +
Recipe Book losers + the standing compliance items]

## Revisions
- [YYYY-MM-DD] [what changed] . owner's reason: "[their words]"
```

Also update `research/selling-points.md`: fill its "Mapped to" and "Skipped because" columns to match the coverage map exactly.

## Golden Standards check

Before presenting, verify every line. A box that cannot be ticked is fixed, not narrated.

- [ ] Recipe Book state was reported OUT LOUD before writing, and its learnings applied or its emptiness stated.
- [ ] Provenance lists every input actually read, including the Reference Sheet's status and photo source, and names missing inputs instead of papering over them.
- [ ] MAIN: zero people in every variant, zero overlay text or graphics in every variant, an incumbent read written, and every variant a genuinely different reason to click (or fewer than 4 variants, with that said in writing).
- [ ] Every secondary has ONE job and ONE message. Word-count each headline: 7 words or more is a fail, rewrite it.
- [ ] No two assets share a message. Compare on MEANING, not wording ("a little goes a long way" and "one drop is enough" are the same message).
- [ ] Every people-bearing slot names a DISTINCT avatar with an explicit displayed age and gender, the avatar count matches the people-slot count, and casting appears nowhere inside composition text.
- [ ] Materials, part counts and botanicals named explicitly wherever the product's substance matters, and named as they really are, not as a render would flatter them.
- [ ] A+ briefed: 5 to 7 modules, never more than 7, one job and one message each, comparison module where it helps, legibility and compliance applied.
- [ ] Variations briefed from the REAL list (none invented), or `none (single SKU)` or `unconfirmed` stated in writing.
- [ ] **Promise check run on every message**, its line written in the file, and every split-theme or unsourced promise rewritten to keep the job and drop the promise.
- [ ] Coverage map spans MAIN + SECONDARY + A+ + VARIATIONS, accounts for 100% of the selling-point IDs with zero blank cells, and every table stake lands on at least one asset.
- [ ] At least one emotional frame, and the strongest hook leads the gallery order.
- [ ] Avoid list restated in the brief itself, carrying the BRAND KIT's avoids and approved-claims boundary, so the generation rooms cannot miss it.
- [ ] Placeholder scan clean: no `TBD`, `XXX`, `insert`, or stray `[` beyond the declared markers.
- [ ] The saved file was re-read from disk after writing, and `research/selling-points.md` matches the map.

## Wonka lines

Openers:
- "The Brief Room. My favorite floor. Every great candy starts with a recipe, every great image starts with a brief."
- "Research in, brief out. Watch closely, this is where the magic gets its instructions."
- "Ladies and gentlemen... we write the Brief."

Closers:
- "The Brief is written: [N] frames, every selling point accounted for, nothing skipped in silence."
- "Read it twice. The generation rooms follow this to the letter, so any doubts speak now, while doubts are still free."
- "No brief, no candy. And now you have a brief. To the Main Image Room."

On the promise check:
- "Every line in here is a promise. I would rather break one on paper than on your buyer's kitchen table."

## Definition of Done

- `brief/creative-brief.md` exists on disk and was re-read after writing, carrying: provenance (with the Reference Sheet source), gaps carried forward, the strategy summary with the funnel diagnosis, the full coverage map, the promise-check line, the set structure table, the MAIN variants with an incumbent read and a mechanism per hypothesis, every secondary slot brief, the A+ module plan, the variations plan, ranked test hypotheses, and the restated avoid list.
- The coverage map accounts for 100% of the IDs in `research/selling-points.md`, zero blank cells, every table stake mapped.
- Every headline is 6 words or fewer, and no two assets carry the same message.
- The promise check ran and its result is written in the file.
- `research/selling-points.md` columns updated to match.
- `Owner review:` records the truth: `approved [date]` if the owner approved it in this session, otherwise `PENDING`, which the generation rooms surface before they spend anything.
- The placeholder scan came back clean apart from the declared markers.

## Update status.md

Set BRIEF to `done` (or `blocked: [missing research file]`), artifact `brief/creative-brief.md`, and add a Log line: `[date] Creative brief written (full package): [N] image slots, [K] A+ modules, [V] variations, [X/Y] selling points mapped, [M] consciously skipped, promise check [P] rewritten. Owner review: [approved / pending].` If the brief was written with a gap (a waived research input, a pending brand kit, an unlocked reference), name it on that line so a later session can top it up before generation.

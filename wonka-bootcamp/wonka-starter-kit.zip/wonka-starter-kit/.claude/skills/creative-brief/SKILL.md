---
name: creative-brief
description: Write the distillation brief for a product's whole creative package. Sorts finished research into the structured decisions Genrupt accepts. the secondary slot plan, the three main-image controls plus selection criteria, casting as 1 to 2 custom avatars, compliance, a selling-points coverage map, ranked test hypotheses, and a ready Genrupt handoff (the Funnel A payload, the cast, per-slot Funnel B proposals). A+ is deliberately not briefed. Genrupt plans it alone. Use when research is done and the user wants the plan every generation room will follow. Triggers: /creative-brief, "write the brief", "create the creative brief", "build the brief", "plan my image set", "shot list", "brief room".
---

# The Brief Room

| Meta | Value |
|------|-------|
| Room | The Brief Room |
| Station | BRIEF |
| Day | Day 4 of the bootcamp. Outside the bootcamp, run it whenever RESEARCH is done. |
| Needs | All five `research/` files plus `research/product-report.md` (hard), plus `factory/Brand/brand-kit.md`, `2-reference/reference-sheet.md`, `factory/Improvement Log.md`, `status.md` Owner intel (see the input table) |
| Saves to | factory/Products/[product]/brief/creative-brief.md (the distillation brief for the FULL package: main-image controls + secondary gallery + variations + the Genrupt handoff) |
| Typical cost | Free, and say so out loud. Writing a brief and re-rolling it costs nothing. This is the last free gate before anything costs credits. |

## What this room does

This is the heart of the Factory, and its job changed shape with the intake contract: **Genrupt owns planning, prompting, and generation. This room owns DISTILLATION.** We never write image prompts. The Brief turns everything the Research Room learned into the small set of structured decisions Genrupt actually accepts, sorted into the two funnels from the intake guide (`guides/genrupt-intake-guide.md`): Funnel A, product facts that are true no matter which images get made, and Funnel B, per-slot creative decisions that edit the plan Genrupt returns. One job and one message per secondary slot, the three main-image controls, a cast of 1 to 2 avatars, compliance notes, a coverage map that proves no selling point was dropped by accident, and a **Genrupt handoff** section that the generation rooms can send almost verbatim. Every asset the factory produces later is judged against this document. No brief, no candy.

It has a second job that matters just as much. **A brief decides what the images are allowed to PROMISE.** The most expensive listing failure in the world is an image that promised something the product does not always deliver, because the buyer arrives excited, gets something else, and writes a one star review about a product working exactly as specified. Every message in this document goes through the promise check in step 10 before it reaches a generation room.

Three house decisions shape what this room does NOT do anymore:
- **The main image is chosen, not briefed.** We decide three controls with the owner (tactic, hang-tag text, packaging preference) and write selection criteria. Genrupt generates the candidates, the human picks on Day 5. No authored main variants.
- **A+ is hands-off.** No content brief, no module plan. Genrupt decides the A+ alone; our job there is generate, inspect, fix.
- **Casting is a structured field and style is a preset.** Who appears goes in `customAvatars` (guide 2.1), the look comes from the branding preset plus one styleImage built by `/brand-kit`. Neither ever appears as prose in a slot brief.

## Before you start

Read the inputs first, then handle each one exactly as this table says. Never guess at an input, and never present a guess as research.

| Input | If it is missing |
|---|---|
| `research/insights.md`, `reviews.md`, `persona.md`, `selling-points.md`, `competitors.md`, plus `research/product-report.md` (the unified report) | **HARD BLOCK.** These are the previous room's output, not something the owner "has" or "does not have". Name the missing file, point to `/meet-my-product`, and stop. The block clears with one command. If the owner insists on proceeding anyway, refuse in plain words and say what it would take: a brief written from memory of the category is decoration, and it would spend real credits on invented problems. |
| A research file that EXISTS but records a waiver, a BLOCKED marker, or a thin sample ("no critical reviews provided") | **PROCEED.** Copy the gap verbatim into `## Gaps carried forward` in the brief and lower the confidence line. Never read a waiver stub as evidence. |
| `factory/Brand/brand-kit.md` | **PROCEED** and offer `/brand-kit`. Say out loud what is missing with it: the APPROVED CLAIMS table and the brand avoid list (what step 10 tests against), AND the `brandingPresetId` plus the one `styleImage` (what the handoff's Funnel A payload carries). Mark those handoff fields `pending brand kit`; they must be filled before generation. |
| `2-reference/reference-sheet.md` not locked, or missing | **PROCEED.** Writing costs nothing and the brief does not need the lock. Record the status in the provenance line and remind the owner that no generation room opens until `Reference status: LOCKED` and `Smoke test: PASS`. |
| `factory/Improvement Log.md` | **PROCEED.** See step 1: its state gets reported out loud either way. If present, also apply any owner working-style preferences it records for briefs. |
| `status.md` Owner intel (must-include, avoid, known winners) | **PROCEED.** If it reads "none given", write `owner intel: none given` in the brief. Never invent intel. |
| The real variation list (sizes, colors, scents, counts, bundles) | **ASK the owner.** If the answer is "I do not know", write `variations: unconfirmed` plus the one line on how to confirm it (the listing's variation picker, or Seller Central). Never write `none` on a guess. |
| The current live main image and gallery (the incumbent) | If the product is not live yet, record `incumbent: none (pre-launch)` and the main-image selection criteria judge candidate versus candidate instead of candidate versus incumbent. |

## Two rules that override everything below

**THE SKIPPED LIST IS A NEGATIVE CONSTRAINT, NOT BOOKKEEPING.** A selling point
the research CONSCIOUSLY dropped (wrong for this product, a split theme, a
tested loser, cannot be shown honestly) may NEVER be asserted by any slot, any
headline, or any hang-tag. The coverage map records it once; from that moment it
is forbidden text. Before presenting the brief, re-read every slot against the
skipped column and delete or rewrite any line that resurrects a dropped point.
`brief_lint.py` enforces this mechanically, so a brief that brings one back
cannot pass the gate. The failure this prevents is real and it is quiet: a point
gets rejected in research for a good reason, nobody re-reads the slots, and the
rejected claim ships on an image.

**FACTUAL CLAIMS ABOUT WHAT THE PRODUCT *IS* ARE A HUMAN GATE.** You may reword,
shorten and sharpen any message freely. You may NOT introduce or change a claim
about the product's material, capacity, dimensions, piece count, certification,
origin, or safety status. That holds even when the Improvement Log says a
similar claim won for a similar product. When a promising message depends on a
factual change you cannot verify from the listing, the bible, or owner intel,
SPLIT IT: keep the part that carries no factual risk, keep the company's own
stated fact, and escalate the factual question to the owner with the evidence.
Two reasons this is absolute. A wrong factual claim is the one image defect that
survives every quality gate, because it renders perfectly. And it is never
contained to one image: the same untrue fact usually sits in the title, the
bullets and the A+ too, so quietly "fixing" it in creative hides a listing-wide
problem instead of surfacing it.

## Process

1. **Report the Improvement Log state OUT LOUD, before writing a word of the brief.** Read `factory/Improvement Log.md`. If it holds patterns and tested winners, name the ones this brief will apply, and treat them as overriding general best practice: a style that lost a test for this brand does not get briefed again, and the losing row is cited. If it is EMPTY, say so in one line and make the promise explicit: "The Improvement Log is empty. This is your first product, so this brief runs on your research and on best practice alone. After your first Tasting Round that book starts filling, and your next brief will not start from zero." That single line is how the owner first SEES the learning loop, days before it closes.

2. **Extract the selling-points checklist FIRST, and keep it open as the spine.** Before any strategy, before any slot, pull every ID from `research/selling-points.md` into a working coverage table: ID, selling point, source, and an EMPTY target column. Every table stake, top feature, whitespace opening, differentiator, and material or quality signal is on it. This table is what the brief gets built around, not something checked against it afterwards. It gets closed in step 11 and it is what stops selling points dying in silence.

3. **Open the file with provenance.** The first line of `creative-brief.md` is `Built from:` listing every input actually read, with dates, and stating honestly:
   - the five research files plus `research/product-report.md`, and whether any carries a waiver;
   - the Reference Sheet's status AND its photo source (`source: manual_photos` or `source: amazon_scraped`). Write the source plainly. A reference built from listing and review images carries more guessing about size, backs and sides, and the brief is where that is visible to anyone reading it later;
   - the brand kit, or `brand kit: pending`;
   - the Improvement Log state (`empty` or the learnings applied).

4. **Write the strategy summary (5 to 10 lines).** What this package must PROVE to convert this persona. Anchor it in the top pain points, the sharpest objection, the whitespace opening, and the best frame from the competitor teardown. Then state the funnel diagnosis from `research/insights.md` and let it set the WEIGHTING: the MAIN image is the CTR lever (it wins the click in search), the secondary gallery and A+ are the CVR lever (they close the sale and set expectations). A click leak means the main-image selection criteria and the first Tasting Round carry the weight. A close leak means the brief piles onto the gallery, and the A+ inspection gets read with that leak in mind. If the diagnosis is marked `estimated` or `no data`, say so here in the brief, do not launder it into certainty, and hedge across both. This paragraph is the tiebreaker for every decision below.

5. **Design the set structure.** Default: 1 MAIN plus 5 to 7 SECONDARY slots (Amazon shows roughly 6 to 8 gallery images including the main). Fewer strong slots beat more mushy ones; the scarce thing is messages, not pixels. Assign each secondary exactly ONE job from this menu, adapted to the product:
   - Benefit hero (the number one benefit, visualized)
   - Ingredient or material proof (what it is made of, shown honestly)
   - How-to or setup (usage in 2 to 4 steps)
   - Lifestyle emotional (the persona's outcome, with a person)
   - Comparison or objection-buster (versus the old way or the generic option; answer the top objection)
   - Scale and dimensions (real size, a hand or a context object for scale)
   Set-level rules: no two slots share a message, at least one emotional frame, the strongest hook leads the gallery order. The MAIN sits in the structure as a CHOICE, not a brief: its content comes from Genrupt's candidates.

6. **Decide the three main-image controls, and write the selection criteria.** The main image is chosen, not briefed. Nothing in this brief writes main-image content, and slot 1 is round-tripped unchanged through every plan save. What this step produces instead:
   - First, read the incumbent. Write one line on what the current live main image does and what it fails to answer. The winning candidate must beat THAT image by a named mechanism.
   - Then, WITH THE OWNER, answer the three controls the setup flow exposes: **tactic**, **hang-tag text**, and **packaging preference**. Never pick a tactic the owner has not answered for (guide section 6). Hang-tag text is on-image publishing, so it goes through the promise check in step 10 like any headline.
   - Then write **SELECTION CRITERIA**: 3 to 5 named questions the winning main must answer, each tied to a mechanism from the research ("does the real height read at thumbnail size? the incumbent gives no scale reference at all", "does the flow question get answered before the click?"). These criteria are the Day 5 instrument: Genrupt generates many main candidates in the Main Image Room, and the human picks WITH THIS LIST IN HAND, not by taste. Include the standing compliance basics as pass/fail criteria (product only, no people, no overlay text or graphics beyond what physically exists on the product and its label, and Amazon's current main-image requirements page as the authority on background, frame fill, and props).

7. **Brief every SECONDARY slot.** This local brief is your THINKING artifact and it stays thorough. But it is a DISTILLATION SOURCE, not text to forward: step 13 routes each part to the structured field that enforces it. Each slot gets:
   - **Job**: the one thing this image proves.
   - **Buyer question**: the same job phrased as the shopper would ask it, one question. (Routes to `buyerQuestion`.)
   - **Message**: ONE headline, maximum 6 words. Count the words. Prefer customer language from `reviews.md` reshaped into our own copy. **Use their words, never their review**: a customer's phrasing as our headline is smart, the same line presented AS a review (quotation marks plus stars, "verified buyer", a rating graphic) is a compliance problem. (Routes to `headerPhrases` as finished on-image copy, never pasted into slot text.)
   - **Composition**: what is in frame, product placement, whether a person appears, and prop and material accuracy named EXPLICITLY. Name the real materials from the Reference Sheet, especially where a render would flatter them ("the base is stainless steel, the tiers and the auger are plastic; do not render the whole machine as gleaming steel"), and name the real part count ("all four tiers visible"). (This IS the 2 to 5 sentence `contentBrief` the generation room sends. Product fidelity itself is enforced by the reference images and the product description in Funnel A; the sentence here is a backstop, not the mechanism.)
   - **Supporting elements**: up to 3 short labels or icons, no more. Win legibility by subtraction: fewer elements means bigger text. (The count routes to a one-line constraint. The ~3.5% minimum size and the 160px squint test are the INSPECTION room's mechanical checks, never generation text.)
   - **People**: whether a person appears in this slot, yes or no. That is ALL the slot carries about people. WHO appears lives in the avatar fields (guide 2.1): the cast in step 13 is 1 to 2 `customAvatars` translated from `research/persona.md`, applied by Genrupt to every people-bearing slot. Casting prose in a brief is retired; per-image variety is automatic and is never requested in prose. Blank avatar fields, not weak prose, were the real cause of the old age drift.
   - **Constraints**: short, and only what is genuinely ours to enforce and covered by no structured field. No medical claims, no invented percentages, no star ratings or review references, no flag graphics, plus the brand kit and owner-intel avoids that apply to this slot. (Third-party logos, fake badges, and floating graphics are blocked by Genrupt system-side. Noted here for the fallback path and for inspection, never restated to Genrupt.)
   - **Source**: which research line this slot answers to (a review pain, a listing spec, a whitespace item, owner intel). A slot with no source line is decoration.
   - Brand style (colors, fonts, tone) is NOT part of a slot brief: the branding preset plus the one styleImage own the look, and design-dictating slot text overrides it and flattens the output.

8. **Record the A+ decision, and nothing more.** A+ is deliberately NOT briefed. That is the house decision, not an omission: Genrupt plans and produces the A+ alone, because A+ exists to be beautiful and impressive and Genrupt does that well. This brief records exactly two things: (a) one line stating that A+ is hands-off and that the A+ Room's job is generate, inspect, fix; (b) which selling points from the spine are EXPECTED to land in A+ rather than the gallery. Those points get marked in the coverage map as `expected in A+ (Genrupt-planned), verified at inspection`, and the inspection after A+ generation is the gate that confirms they actually landed. No module list, no A+ headlines, no A+ casting, no A+ copy points. If a later Tasting Round flips the winning angle, the A+ may be realigned then.

9. **Plan the product variations.** List the REAL variations the product has. Do not invent variations, and do not write `none` on a guess (see the input table). For each real variation, brief its own variation-specific MAIN plus the swatch or picker thumbnail that reads clearly at small size, consistent with the locked Reference Sheet (same product identity, only the varying attribute changes) and the brand kit. If there are genuinely none, write `variations: none (single SKU)` in the file rather than leaving the section empty: writing the absence down is the coverage discipline applied to a whole section. This section may be amended later, once a winner exists, through the revision protocol in step 16.

10. **Run the PROMISE CHECK on every message in the brief.** Take each secondary headline, the hang-tag text from step 6, and anything the brief asks to appear printed on the product, and ask three questions:
    1. **Is it sourced?** Point to the listing, the label, the reviews, or owner intel. No source, no claim. A claim the brand kit's APPROVED CLAIMS table does not carry is not ours to make.
    2. **Do the reviews contradict or SPLIT on it?** A theme buyers argue about (some say it is a breeze, some say it is a hassle) is not a promise, it is a coin flip. A promise on a split theme betrays a chunk of buyers by design.
    3. **Would a buyer who believes this line and then opens the box feel misled?** If yes, that headline is the next one star review.
    The fix has one shape every time: **keep the job, drop the promise, show the mechanism.** The image teaches how the thing works and leaves the outcome unpromised. Record the result in the brief as one line: `Promise check: [N] messages tested, [M] rewritten, [reason for each rewrite]`. Any message that stays deliberately close to the line records why it is safe. Do NOT hand a brief to a human without running this. It is the cheapest possible place to catch a promise the product cannot always keep. A+ text is Genrupt's, so it cannot be promise-checked here; the SAME three questions run against the generated A+ at inspection, and that is written into the A+ line from step 8.
    Then RESTATE the avoid list at the end of the brief, in the brief's own words: the brand kit's avoid list, the boundary of its APPROVED CLAIMS table, the owner-intel avoids, any Improvement Log losers, and the standing compliance items. The generation rooms read this file and not the brand kit, so an avoid that lives only in the brand kit is an avoid that does not exist.

11. **Close the coverage map.** Return to the spine from step 2 and fill every target cell across MAIN, SECONDARY, A+ and VARIATIONS. Every table stake must land on at least one asset. MAIN mappings point at a selection criterion or a control ("MAIN: selection criterion 2", "MAIN: hang-tag"), because the main has no authored content. A+ mappings are always the marker `expected in A+ (Genrupt-planned), verified at inspection`, never a module number. Anything not mapped goes in the skipped column WITH a reason from this menu, never blank:
    - off-strategy for this package;
    - cannot be shown honestly (no evidence, or the claim is not ours to make);
    - **creative cannot fix it** (a part that arrives cracked, a shipping problem, a manual that is missing). Name WHO owns it instead: packaging, quality control, the manual, customer service. A coverage map is a written record of what images cannot fix, and most briefs quietly pretend that category does not exist;
    - tested loser (cite the Improvement Log row);
    - slot budget (say what won the slot instead).
    Partial mapping is lawful and gets written down: keeping an idea while dropping an unsupportable specific ("the rental comparison is expected in A+, the dollar figure comes out; it is one reviewer's rental market, not a fact about ours") is recorded as mapped WITH the note. Then update `research/selling-points.md` so its "Mapped to" and "Skipped because" columns match this map exactly, with zero blank cells.

12. **Rank the test hypotheses.** With no authored main variants, a hypothesis is no longer "variant C beats the incumbent". It is a ranked bet about MECHANISMS: which selection criterion from step 6 most decides the click for this product, and which challenger ANGLE should meet the winner in a later Tasting Round. Rank the selection criteria first (the top one is the criterion the Day 5 pick weighs heaviest, and the mechanism the first Tasting Round tests against the incumbent), then list 1 or 2 challenger angles (a different tactic, a different packaging preference, a whitespace frame the first pick did not use) as the backup tests. A hypothesis is a testable claim about a mechanism, never a statement of taste: "it looks better" is not a hypothesis. The Tasting Room settles these later (Day 8 in the bootcamp).

13. **Draft the Genrupt handoff.** This is the distillation itself: translate the brief into the two funnels, ready for the generation rooms to send. The triage discipline from guide section 5 applies: distill, do not forward. If any field's content reads like research notes, it is not done.
    - **Funnel A payload draft** (`projectSetup`): the product title, description, and bullet points REWRITTEN as one clean set from the listing copy and the product facts (never pasted verbatim, and every factual claim traceable to the listing, the label, or the Reference Sheet); which photos from `2-reference/photos/` go to `productImages` and which to `packagingImages`, with a one-sentence `note` only where an image establishes something specific ("shows the matte texture", "correct label revision"); the `brandingPresetId` from the brand kit; and the ONE `styleImage` the brand kit chose. Exactly one styleImage, the single best, never a rotation. Local photos are flagged `upload first, HTTPS URLs only`.
    - **The cast**: 1 to 2 `customAvatars` translated from `research/persona.md`, carrying label, description (occupation, life stage, what they are doing with the product), age, gender, ethnicity (`varied` unless the persona pins it), location, and income. **The age field carries the DISPLAYED age: the aspirational skew from `research/persona.md` applied to the persona's real age, exactly as research computed it.** One avatar for one locked persona across the set, two when the research genuinely found two buyers. Note in the handoff that sending `customAvatars` makes these the whole cast, and that per-image variety within the cast is automatic.
    - **Per-slot Funnel B proposals**, one block per secondary slot, PROPOSED as edits to the plan Genrupt will return, never as a replacement for it: `buyerQuestion` (from the slot's buyer-question line), `contentBrief` (the slot's 2 to 5 composition sentences), `headerPhrases` (the slot's message as finished on-image copy, 120 characters or fewer, no placeholders), and `customInstructions` ONLY where a constraint has no structured home, kept to a couple of short sentences with `mode: ADDITIVE`. Slot 1 is marked `round-trip unchanged` and carries nothing. Respect every cap at draft time (2 alternates, 24 header phrases, 700/120/4000 characters) so validation never rejects the call.

14. **Run `brief_lint.py`, and fix the BRIEF until it passes.** From the kit root:
    `python3 .claude/skills/creative-brief/brief_lint.py factory/Products/[product]/brief/creative-brief.md`
    It is mechanical on purpose: it does not get tired, and it checks the things
    that are cheap to fix in a text file and expensive to fix in a batch of
    images. Casting text in a slot, design direction in a slot, an over-long
    content brief, a headline over the cap, people in the main, authored
    main-image content, a briefed A+, two slots sharing a message, a rejected
    point resurfacing, a banned claim, an unresolved placeholder. **Zero errors
    before the brief is presented.** Fix the brief, never the linter, and never
    self-certify the checks by hand and call it linted. If the script is missing,
    say so plainly rather than skipping the gate.

15. **Scan for placeholders, run the Golden Standards check, then present.** Search the finished file for `TBD`, `XXX`, `insert`, `lorem`, `[` and `pending`. The only lawful survivors are the ones this skill declares on purpose: `pending brand kit`, `variations: unconfirmed`, `incumbent: none (pre-launch)`, `Owner review: PENDING`, `upload first`. Anything else means an input is missing: name which one, out loud. Then re-read the saved file from disk to confirm it wrote, run the checklist below, and present to the owner: the strategy summary, the three main-image controls and the selection criteria, the slot list with jobs and messages, the A+ hands-off line, the variations line, the coverage totals, the promise-check line, and whether the Genrupt handoff is complete or carries pending fields. Point to `brief/creative-brief.md` for the whole thing. Then ask for their read, plainly: this is a draft until they approve it, they know their product and their buyers, and a wrong assumption is cheapest to fix right here, for free.

16. **The revision protocol (when the owner pushes back).** Pushback is the review step working, and it usually comes from a better memory of what makes buyers angry, not from better taste.
    - Change ONLY what was asked. Never rewrite the brief around one note.
    - Re-run the affected checks only: the promise check on the new message, uniqueness against the other slots, the coverage map if that slot carried a selling point (confirm the point still lands somewhere), and the matching Funnel B block in the handoff, which must be re-drafted to match the revised slot.
    - Record it in `## Revisions` at the bottom of the file: date, what changed, and the owner's REASON in their words. In six months that reason is the only thing that explains the file.
    - Re-present the revised block, not the whole document.
    - If an instruction collides with a factory law (people in the main image, a claim with no evidence, a promise the reviews split on, a request to write casting or style prose into a slot, a request to brief the A+), say so plainly, offer the closest lawful version, and let the owner decide. Never silently comply, and never silently refuse.

## Output format

`brief/creative-brief.md`. Keep this section order: the coverage map sits high, right under the strategy, because it is the index of the whole brief, and the Genrupt handoff sits LAST, because it is the distilled product of everything above it.

```markdown
# Creative Brief . [Product Name]
Built from: research/insights.md ([date]), research/reviews.md ([N pos, M crit]),
research/persona.md (source: [brand_registry_export / estimated]), research/selling-points.md,
research/competitors.md, research/product-report.md ([date]), 2-reference/reference-sheet.md
([LOCKED / not locked], source: [manual_photos / amazon_scraped]), factory/Brand/brand-kit.md
([done / pending]), factory/Improvement Log.md ([learnings applied / empty]). Written [YYYY-MM-DD].
Owner review: [PENDING / approved YYYY-MM-DD]

## Gaps carried forward
- [any waived or thin input, verbatim, and what it weakens] (or "none")
- Confidence: [high / medium / low], because [one line]

## Strategy summary
[5 to 10 lines: what the package must prove, for whom, against which incumbent and competitors,
plus the funnel diagnosis and the weighting it sets. Mark it `estimated` where it is estimated]

## Selling-points coverage map (full package)
| ID | Selling point | Mapped to (MAIN criterion / S# / A+ / Variation) | Skipped because |
|---|---|---|---|
| SP1 | [point] | S2 | |
| SP4 | [point] | expected in A+ (Genrupt-planned), verified at inspection | |
| SP7 | [point] | . | creative cannot fix it: [who owns it instead] |
Covered: [N/total]. Consciously skipped: [M], every one with a reason.
Every table stake mapped to at least one asset.

## Promise check
[N] messages tested, [M] rewritten. [What was rewritten and why]
(A+ text is Genrupt's: the same three questions run at A+ inspection.)

## Set structure
| Slot | Job | Message (max 6 words) | People |
|---|---|---|---|
| MAIN | product hero | chosen from Genrupt candidates, zero overlay text | NO. Never. |
| S1 | [job] | "[headline]" | [yes / no] |

## Main image (chosen, not briefed)
Incumbent read: [what the current live main does, and what it fails to answer]
The three controls (answered WITH the owner, never assumed):
- Tactic: [owner's answer]
- Hang-tag text: [owner's answer, promise-checked] (or "none")
- Packaging preference: [owner's answer]
Selection criteria (the Day 5 pick instrument, ranked in step 12):
1. [named question the winning main must answer] . mechanism: [why this wins the click vs the incumbent]
2. [criterion]
3. [criterion]
Pass/fail basics for every candidate: product only, no people, zero overlay text or graphics
beyond what physically exists on the product and its label, and the current Amazon main-image
requirements page as the authority on background, frame fill, and props.
Slot 1 is round-tripped unchanged in every plan save.

## Secondary slots
### S1 . [Job]
- Buyer question: "[the shopper's phrasing]"   -> buyerQuestion
- Message: "[headline, max 6 words]" (source: [review quote / insight])   -> headerPhrases
- Composition (the 2 to 5 sentence content brief): [scene, objects, person or not, explicit
  material and part accuracy]   -> contentBrief
- Supporting elements: [max 3]   -> one-line constraint
- People: [yes / no] (WHO is the cast in the handoff, never prose here)
- Constraints (short, only what no structured field covers): [e.g. no invented percentages,
  no star ratings, plus brand-kit avoids]
- Source: [the research line this slot answers to]
(repeat per slot; brand look comes from the branding preset + styleImage, never written per slot)

## A+ content
A+ is hands-off (house decision): Genrupt plans and produces it alone. The A+ Room's job is
generate, inspect, fix. Expected to land in A+, verified at inspection: [SP IDs from the map].
The promise check's three questions run against the generated A+ at inspection.

## Product variations
- Variations (real): [list, or "none (single SKU)", or "unconfirmed: [how to confirm]"]
### [Variation name]
- Variation MAIN concept: [product-only, consistent with the Reference Sheet]
- Swatch / picker thumbnail: [what reads clearly at small size]
- Consistency note: [same product identity; only the varying attribute changes]

## Test hypotheses (ranked)
1. Selection criterion [X] decides the click: [mechanism vs the incumbent]. The Day 5 pick weighs
   this heaviest, and Tasting Round 1 tests the picked candidate against the incumbent on it.
2. Challenger angle: [a different tactic / packaging preference / whitespace frame] . [mechanism].
   Meets the winner in a later Tasting Round.

## Avoid list (restated)
[the brand kit's avoid list + its APPROVED CLAIMS boundary + owner-intel avoids +
Improvement Log losers + the standing compliance items]

## Genrupt handoff

### Funnel A payload draft (projectSetup)
- Title: [rewritten clean]
- Description: [one clean description, every claim traceable]
- Bullet points: [rewritten clean]
- productImages: [which files from 2-reference/photos/, each with a note only where it earns one]
- packagingImages: [box / label / pouch files]
- (local files: upload first, HTTPS URLs only)
- brandingPresetId: [from brand kit / pending brand kit]
- styleImage: [the one image the brand kit chose / pending brand kit]

### Cast (customAvatars, 1 to 2)
- Avatar 1: label "[persona label]", description "[occupation, life stage, use]",
  age "[DISPLAYED age, aspirational skew from persona.md applied]", gender "[...]",
  ethnicity "[varied unless the persona pins it]", location "[...]", income "[...]"
- (sending customAvatars makes these the whole cast; per-image variety is automatic)

### Funnel B proposals (per slot, proposed as edits to Genrupt's returned plan)
- Slot 1 (MAIN): round-trip unchanged.
- Slot [n] ([imageType]):
  - buyerQuestion: "[...]"
  - contentBrief: "[2 to 5 sentences]"
  - headerPhrases: ["[finished on-image copy, <=120 chars]"]
  - customInstructions: [ADDITIVE, "[a couple of short sentences]" / none]

## Revisions
- [YYYY-MM-DD] [what changed] . owner's reason: "[their words]"
```

Also update `research/selling-points.md`: fill its "Mapped to" and "Skipped because" columns to match the coverage map exactly.

## Golden Standards check

Before presenting, verify every line. A box that cannot be ticked is fixed, not narrated.

- [ ] Improvement Log state was reported OUT LOUD before writing, and its learnings applied or its emptiness stated.
- [ ] Provenance lists every input actually read, including `research/product-report.md` and the Reference Sheet's status and photo source, and names missing inputs instead of papering over them.
- [ ] MAIN: no authored content anywhere. The three controls carry the OWNER's answers (never assumed), the incumbent read is written, 3 to 5 selection criteria each name a mechanism, and slot 1 is marked round-trip unchanged in the handoff.
- [ ] Every secondary has ONE job, ONE buyer question, and ONE message. Word-count each headline: 7 words or more is a fail, rewrite it.
- [ ] No two assets share a message. Compare on MEANING, not wording ("a little goes a long way" and "one drop is enough" are the same message).
- [ ] Casting prose appears NOWHERE in any slot text: slots carry only yes/no on people, and the handoff cast is 1 to 2 customAvatars with the displayed (aspirational) age from `research/persona.md`. Per-image variety is not requested in prose anywhere.
- [ ] Materials, part counts and botanicals named explicitly wherever the product's substance matters, and named as they really are, not as a render would flatter them.
- [ ] A+ carries the hands-off line and the expected-in-A+ SP list, and NOTHING else: no modules, no A+ headlines, no A+ casting.
- [ ] No style prose anywhere: no colors, fonts, or hex codes in any slot or handoff text; the look rides on `brandingPresetId` plus the one styleImage.
- [ ] Variations briefed from the REAL list (none invented), or `none (single SKU)` or `unconfirmed` stated in writing.
- [ ] **Promise check run on every authored message including the hang-tag text**, its line written in the file, and every split-theme or unsourced promise rewritten to keep the job and drop the promise.
- [ ] Coverage map spans MAIN + SECONDARY + A+ + VARIATIONS, accounts for 100% of the selling-point IDs with zero blank cells, every table stake lands on at least one asset, and every A+ mapping carries the `expected in A+ (Genrupt-planned), verified at inspection` marker.
- [ ] At least one emotional frame, and the strongest hook leads the gallery order.
- [ ] Avoid list restated in the brief itself, carrying the BRAND KIT's avoids and approved-claims boundary, so the generation rooms cannot miss it.
- [ ] Genrupt handoff complete: Funnel A draft (clean title/description/bullets, image routing, brandingPresetId, exactly one styleImage), the cast, and a Funnel B block per secondary slot within every cap (2 alternates, 24 header phrases, 700/120/4000 chars). Pending fields say `pending brand kit`, never sit blank.
- [ ] No field in the handoff reads like research notes: distilled, deduplicated, defensible.
- [ ] Placeholder scan clean: no `TBD`, `XXX`, `insert`, or stray `[` beyond the declared markers.
- [ ] The saved file was re-read from disk after writing, and `research/selling-points.md` matches the map.

## Wonka lines

Openers:
- "The Brief Room. My favorite floor. Every great candy starts with a recipe, every great image starts with a brief."
- "Research in, brief out. Watch closely, this is where the magic gets its instructions."
- "Ladies and gentlemen... we write the Brief."

Closers:
- "The Brief is written: [N] frames, every selling point accounted for, nothing skipped in silence."
- "Read it twice. The generation rooms send this almost word for word, so any doubts speak now, while doubts are still free."
- "No brief, no candy. And now you have a brief. To the Main Image Room, where Genrupt cooks and you choose."

On the promise check:
- "Every line in here is a promise. I would rather break one on paper than on your buyer's kitchen table."

On the handoff:
- "We do not tell the machine how to cook. We hand it the finest ingredients, perfectly sorted, and then we taste everything it serves."

## Definition of Done

- [ ] `brief_lint.py` run on the saved brief and reporting **zero errors** (warnings may stand, with a reason)
- [ ] Every slot re-read against the coverage map's skipped column: no dropped point is asserted anywhere
- [ ] No factual claim about material, capacity, dimensions, count, certification, origin or safety was introduced or changed; any such question was escalated to the owner instead

- `brief/creative-brief.md` exists on disk and was re-read after writing, carrying: provenance (with the Reference Sheet source), gaps carried forward, the strategy summary with the funnel diagnosis, the full coverage map, the promise-check line, the set structure table, the main-image section with the incumbent read, the three owner-answered controls and the selection criteria, every secondary slot brief, the A+ hands-off record, the variations plan, ranked test hypotheses, the restated avoid list, and the complete Genrupt handoff (Funnel A draft, cast, per-slot Funnel B proposals, slot 1 round-trip unchanged).
- The coverage map accounts for 100% of the IDs in `research/selling-points.md`, zero blank cells, every table stake mapped, A+ expectations marked for verification at inspection.
- Every headline is 6 words or fewer, no two assets carry the same message, and no slot or handoff text carries casting or style prose.
- The promise check ran on every authored message including the hang-tag text, and its result is written in the file.
- `research/selling-points.md` columns updated to match.
- `Owner review:` records the truth: `approved [date]` if the owner approved it in this session, otherwise `PENDING`, which the generation rooms surface before they spend anything.
- The placeholder scan came back clean apart from the declared markers.

## Update status.md

Set BRIEF to `done` (or `blocked: [missing research file]`), artifact `brief/creative-brief.md`, and add a Log line: `[date] Creative brief written (distillation): [N] secondary slots, main controls decided + [C] selection criteria, A+ hands-off, [V] variations, [X/Y] selling points mapped ([A] expected in A+), promise check [P] rewritten, Genrupt handoff drafted. Owner review: [approved / pending].` If the brief was written with a gap (a waived research input, a pending brand kit or preset, an unlocked reference), name it on that line so a later session can top it up before generation.

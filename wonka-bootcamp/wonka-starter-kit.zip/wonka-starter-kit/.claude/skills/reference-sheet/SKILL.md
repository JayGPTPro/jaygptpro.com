---
name: reference-sheet
description: Lock the product reference so every generated image shows the REAL product, then prove the lock with one mandatory control image checked by human eyes. Use before any image batch, or when the user is ready to prepare their product photos for generation. Triggers: /reference-sheet, "lock the product", "reference photos", "product reference", "build the reference sheet", "smoke test", "the mold".
---

# The Reference Room

| Meta | Value |
|------|-------|
| Room | The Reference Room |
| Station | INVENT gate. Nothing generates until the reference is LOCKED and the smoke test has PASSED |
| Taught on | Day 3, lesson 1. Runs again whenever a new product enters the Factory |
| Needs | The product folder with `status.md`; the user's own product photos in `reference/` (all angles + one hand-for-scale + label close-ups), or an explicitly approved fallback; ONE working generation machine for the smoke test (Genrupt MCP, or the OpenAI key on the fallback path) |
| Saves to | factory/Products/[product]/reference/ (source photos, cleaned references, smoke-test-[N].png, reference-sheet.md) |
| Typical cost | The reference build, plus ONE control image per smoke-test attempt. Genrupt path: a few credits each. Fallback path: cents. Always estimated out loud and approved before anything is spent. |

## What this room does

A reference made from guesses produces images shaped like guesses. This room does two jobs, and the second one is the one everybody skips.

1. **Lock.** The REAL product, its exact size, part count, materials, cap and label, written as a spec and locked as the reference every later generation must match.
2. **Prove.** ONE product-only control image, generated the same way the batch will be generated, opened and judged by human eyes. A reference can sit there marked approved and still produce the wrong product. **Approved is a status. Eyes on a control image are the evidence.**

A beautiful image of the wrong product is worth less than no image at all, and it is a returns problem and a compliance problem at the same time. This room is the only insurance against it, and every room downstream inherits whatever quality it gets here.

## Before you start

Check these in order. Any miss = station **BLOCKED**, named out loud, with a pointer.

1. **The product.** `factory/Products/[product]/` exists with its `status.md`. Missing: point to `/meet-my-product` and stop. If more than one product folder exists, ASK which product this run is for. Never guess from the newest folder, and never build a reference against a folder the user did not name. The creative brief is NOT a precondition: this room runs before it, and the brief is better for having a locked reference to write against.
2. **A machine for the smoke test.** Genrupt MCP connected (Path A, primary) or the OpenAI key present (Path B, fallback). If Genrupt was expected but is not answering, say so and offer the fallback explicitly; never switch paths silently. If NEITHER machine is available, the inventory and the spec can still be written, but the room ends PARKED (see "If the smoke test cannot run"). Never write LOCKED without a passed smoke test.
3. **The photos, asked for FIRST, every time.** The required set:

| Shot | Why it exists |
|---|---|
| Front | the face of the product, the angle every image starts from |
| Back | skip it and the model invents your back label, every time |
| Both sides (2 shots) | shape and depth, so the product is not rendered flat |
| Top down | lids, openings, tier counts, anything only visible from above |
| One hand-for-scale (a hand holding or beside the product) | scale is the single thing image models get most wrong. A dimension in inches does not fix it. A hand in the frame does |
| Label and texture close-ups | so label text and finish get copied instead of approximated |

Saved into `reference/`. Phone photos in decent light are fine, completeness beats beauty. If `/meet-my-product` already collected them, inventory what is there instead of asking for them again.

**Two sources are never allowed in a reference:**
- **A competitor's photo.** It locks THEIR product, their angle, their lighting. Competitors belong in the teardown as the benchmark to match and beat, never in the reference.
- **Any AI-generated image, including one this Factory made.** A reference built from a generation locks that generation's mistakes and compounds them.

**"I don't have that" is a first class answer.** Every version of it has a defined path, and none of them is a dead end:

| The user says | What happens |
|---|---|
| "I have no photos of my own and cannot take any" | The fallback: the product's OWN listing gallery plus CUSTOMER REVIEW images. Only on explicit approval in plain words, after you name what gets weaker. A generic "continue" is not approval. Ask it straight: "shall I build the reference from the listing gallery and the review photos only, accepting weaker size and back-of-product accuracy?" On a yes, record `source: amazon_scraped` with the approval date, and say plainly that the smoke test now matters double |
| "I have some shots but not all of them" | Named gap waiver. Record each accepted gap and what the model is now free to invent because of it. Proceed |
| "I don't have Genrupt" | Path B, recorded as `gpt_image_fallback`. The lock is genuinely weaker and the written spec carries the weight. Say so rather than implying the lock is as strong |
| "I have neither machine right now" | Inventory and spec still get written. The room ends PARKED with the smoke test owed, and INVENT stays closed |
| "I have no product and no listing images at all" | There is nothing to lock, and pretending otherwise would be a fake artifact. Say so plainly and close the room. `/brand-kit` and `/creative-brief` can run meanwhile |

**On the fallback path, mine the customer review images.** A brand gallery is lit to sell and skips exactly the angles a reference needs most. A review photo is the product on a real counter, at its real size, from angles no brand ever shoots. On that path they are the best input in the folder. This is also how the bootcamp's on-camera demo runs, because that listing belongs to another seller and there is no unit in the room. Say that plainly whenever it comes up, and hold the owner to real photos of their own product.

## Process

1. **Inventory the sources.** List what is actually in `reference/` against the required set, as a table, and name what each gap COSTS in the model's behavior, not just that it is missing ("no back shot, so the model will invent your back label"). Ask the user to fill the gaps or waive them by name. Then make provenance visible in the folder itself: rename source files so anyone can see where they came from (`own-front.jpg`, `gallery-01.jpg`, `review-photo-02.jpg`). Provenance that lives only inside a markdown file is provenance nobody checks.

2. **Write the product spec.** This is what the smoke test gets judged against, so write it like a manufacturer, not like an art director:
   - Overall size and dimensions, and weight if known
   - **Every countable thing, counted** (tiers, lids, compartments, cables, pieces in the box)
   - Material and finish PER PART (a stainless steel base with plastic tiers is two materials, and saying so is the difference between premium and cheap on screen)
   - Every included part and accessory
   - Label text exactly as printed, and the brand name spelled as it is spelled
   - Colors, product and label
   - Power, voltage, plug type, where it applies

   **Every line carries its source**: seen in photo [file], stated by the owner, or read off the listing. **Never invent a spec value.** If something cannot be seen or confirmed, write `unknown` and say out loud that the model is now free to invent it. `unknown` is a legitimate spec value; a confident guess is a defect that ships.

3. **Announce the cost, get ONE go-ahead, then spend.** One line before anything is built: "Reference build plus one control image on [path], estimated [credits or dollars]. Proceed?" Nothing is spent before the yes. Every additional control image after a FAIL gets its own one-line re-quote. Never let a re-roll loop run on the first approval.

4. **Build the reference. Path A: Genrupt (primary).**
   - Find the reference-sheet capability in the connected tool list and READ ITS INPUT SCHEMA before calling it. Feed the photos the way the schema actually supports (image URLs, or Genrupt's own upload path, the app's reference-images upload or the CLI bridge, per Genrupt's current docs, linked in `guides/mcp-setup-guide.md`).
   - **Never silently fall back to listing images.** That fallback needs the explicit approval described above.
   - Review the returned sheet WITH the user, panel by panel: is this their product, right size, right parts, right label, in every panel? A wrong panel now is a wrong product in every image later.
   - Approve the reference and **record the returned asset id exactly as returned**. If the approve call fails, errors, or returns no id, the reference is NOT locked: say so and stop. Never write an id from memory, from a previous run, or from a hopeful guess.
   - The generation rooms verify this id before every batch. That is a check, not a proof. The proof is the smoke test in step 6.

5. **Build the reference. Path B: gpt-image fallback (no Genrupt).**
   - For each key angle, use gpt-image to clean the photo to a plain white background, square crop, even lighting, with NO change to the product itself: same label, same proportions, same cap, same materials. The prompt must say so explicitly.
   - Save as `reference/ref-front.png`, `reference/ref-back.png`, and so on. **The originals are never edited, moved, or overwritten.**
   - On this path there is no true lock, so the written spec from step 2 carries the weight: the generation rooms prepend it to every call. Say plainly that fidelity is weaker here and that the Inspection Room will have to bite harder.

6. **SMOKE TEST. Mandatory, both paths, no exceptions.**
   - **Same path, same model as the coming batch.** On the Genrupt path pass `modelId: "gpt_image_2"`, exactly as the generation rooms will. A control image made on a different engine tests a machine you are not going to use.
   - **It must be a FRESH generation that inherits the reference.** The preview panels the reference tool returns are NOT a smoke test. They are the tool describing its own work. The control image is a new generation, made the way a batch is made.
   - **Keep the control prompt minimal**: the product, plain background, no text, no graphics, no props, no people, and empty of contents (an appliance shows no food, a bottle shows no pour). Two reasons. A long descriptive prompt tests your prose instead of the lock, and contents test the promise instead of the machine. The promise belongs in the brief, on purpose, with eyes open. (On Path B the spec IS prepended, because there the spec is the lock; say so, and read the result as "this is what the spec buys me".)
   - Save as `reference/smoke-test-[N].png`, N counting up per attempt. **Never overwrite an attempt.** Failed controls are evidence.
   - **OPEN the file and look at it.** A returned URL, a success status, a filename, or an `approved` flag is not a look. If the file cannot be opened and actually seen, the smoke test has NOT run and nothing may be written about it.
   - Report your own read first, against the spec, using the four-point check below. Then hand the verdict to the human.

   **The four-point check** (run it in this order, out loud, every attempt):

   | Check | Passes when | Fails when |
   |---|---|---|
   | Parts and count | every part present, every countable thing counted right (a four tier fountain shows four tiers, a two lid pot shows two lids) | a part is missing, a part is invented, or the count is off by even one |
   | Materials | each part reads as its real material: steel as metal, plastic as plastic, glass as translucent glass with reflections | premium reads cheap or cheap reads premium; one material swallows the others |
   | Scale and proportions | reads as the size it really is, checked against the hand-for-scale shot (or against review photos on the fallback path) | a counter-top machine renders as catering equipment, or a large product renders as a travel size |
   | Nothing invented | no text, badge, seal, ribbon or award graphic that is not physically on the real product; the label is readable and spelled correctly | the model has decorated the product with things that would be a compliance problem on a live listing |

   - **PASS is the HUMAN'S word, never Wonka's.** Ask for the call in plain words. Silence, "ok", "continue" or "looks good, next" is not a verdict; ask again, naming the four checks. Only then write the PASS, the control image filename and the date.
   - **FAIL**: name the defect in NOUNS ("three tiers, and the tower reads as chrome"), not in feelings ("it looks off"). Fix the actual cause (add the missing angle, tighten the spec, rebuild the sheet), re-quote the cost, generate ONE fresh control, and look again. Log every attempt with its number and its defect.
   - **After three failed attempts, STOP generating and diagnose out loud.** Repeated failures are one of three things: a missing source angle, a spec too vague to judge against, or the wrong path for this product. Name which one you believe it is, ask for the specific missing input, and park the room rather than burning credits in a loop. A control image is cheap, twelve of them are not.
   - **NEVER proceed to a batch on a failed, parked, or skipped smoke test.** One control image is cheap. A wrong-product batch is not.

7. **Write `reference-sheet.md` with full provenance, then update `status.md`.** Both files, every run, including runs that end parked or blocked.

## If the smoke test cannot run

Machines go down. This is the defined behavior, and it is neither a dead end nor a shortcut:

- Write everything that does not need a machine: the photo inventory, the waivers, the full product spec, and the source line.
- Write `Reference status: not locked (smoke test parked: [exact reason])` in `reference-sheet.md`. **Never LOCKED, never PASS, never a placeholder verdict.**
- Put the exact blocker in `status.md` under `Blocked on`, and leave INVENT closed. The generation rooms check for `LOCKED` plus `Smoke test: PASS` and will correctly refuse to run.
- Point the user at the work that costs nothing and needs no machine: `/brand-kit` runs fine right now, and the Brief Room can be written while the reference waits.
- Say exactly what will resume the room: "when Genrupt answers again, say `run the smoke test` and we finish in one image."

## When to re-lock

The reference is not permanent. Send the product back through this room when:

- The packaging, label, or physical form changes, including a new variant that is genuinely a different shape.
- `/inspect` fails product fidelity on more than one image in a batch. That is a reference problem wearing an image problem's clothes, and no amount of editing fixes it.
- A new product enters the Factory. **Every product gets its own Reference Sheet.** References are never shared between products, not even between siblings in the same brand.

## Output format

`factory/Products/[product]/reference/reference-sheet.md`:

```markdown
# Reference Sheet . [Product Name]
Built: [YYYY-MM-DD]
Built from: [N] source images in reference/, owner input on [date]
source: manual_photos | amazon_scraped (listing gallery + customer review images, explicitly approved by [name] on [date])

## Photo inventory
| Required shot | Present | File | If missing, what the model is free to invent |
|---|---|---|---|
| Front | yes | own-front.jpg | . |
| Back | MISSING (gap waived by owner [date]) | | the entire back panel and its label |
| Left side | yes | gallery-03.jpg | . |
| Right side | yes | gallery-04.jpg | . |
| Top down | yes | review-photo-02.jpg | . |
| Hand-for-scale | MISSING (no unit in hand) | | true size; judged against review photos instead |
| Label / texture close-up | yes | own-label.jpg | . |

## Product spec
| Field | Value | Source |
|---|---|---|
| Size / dimensions | [exact, or unknown] | [photo file / owner / listing] |
| Weight | [value or unknown] | [source] |
| Countable parts | [e.g. 4 tiers, 1 auger, 1 base] | [source] |
| Materials and finish, per part | [part: material, finish] | [source] |
| Included parts and accessories | [everything in the box that can appear in an image] | [source] |
| Label text | [exactly as printed] | [source] |
| Colors | [product + label] | [source] |
| Power / voltage | [value, or n/a] | [source] |

Anything marked `unknown` is something the model is free to invent. That is the risk this line records.

## Reference lock
- Path: genrupt | gpt_image_fallback
- Genrupt reference asset id: [id exactly as returned] (Path A) or cleaned refs: [file list] (Path B)
- Approved: [YYYY-MM-DD]. Approved is a status, not proof. The smoke test below is the proof.

## Smoke test (mandatory)
| Attempt | Control image | Cost | Verdict | Defect named |
|---|---|---|---|---|
| 1 | reference/smoke-test-1.png | [est] | FAIL | three tiers rendered, tower read as chrome |
| 2 | reference/smoke-test-2.png | [est] | PASS | . |

- Checked against the spec by: [user name], with Wonka reading first
- Four-point check on the passing image: parts and count [ok], materials [ok], scale [ok], nothing invented [ok]
- Smoke test: PASS
- Reference status: LOCKED [YYYY-MM-DD]

## Notes
[waived gaps, fallback warnings, what the generation rooms should watch hardest, anything that would explain a future fidelity miss]
```

Three lines are read mechanically by other rooms and must be written literally, exactly as spelled here: `source:`, `Smoke test: PASS` (or `FAIL: [reason]`), and `Reference status: LOCKED [date]`. Until a PASS, the status line reads `not locked` with the reason in brackets. Do not reword them, do not decorate them, do not write them early.

## Golden Standards check

Before presenting, verify:
- [ ] The user's own photos were requested FIRST, before any fallback was mentioned. The fallback ran only on explicit, named approval, recorded as `source: amazon_scraped` with a date.
- [ ] No competitor image and no AI-generated image is in the reference set.
- [ ] The spec is complete and SOURCED, with `unknown` written where a value could not be confirmed. Nothing was invented to fill a field.
- [ ] Cost was announced and approved before the reference build, and re-quoted before every extra control image.
- [ ] The reference exists on the chosen path: an asset id exactly as returned by the tool (Path A), or cleaned reference files plus the spec (Path B). No id was written from memory.
- [ ] The control image is a FRESH generation on the same path and model as the coming batch, not a preview panel from the reference tool.
- [ ] The control image file was actually opened and looked at, and the four-point check was run against the spec.
- [ ] The PASS came from the human in words. Wonka never wrote PASS on his own judgment.
- [ ] Every attempt is on disk as `smoke-test-[N].png` and logged with its defect. Nothing was overwritten. Originals untouched.
- [ ] `reference-sheet.md` and `status.md` were both written, including on a parked or blocked run.
- [ ] No batch, no extra images, nothing beyond the approved control image was generated in this room.

## Wonka lines

Openers:
- "The Reference Room. Get this wrong and every candy downstream comes out the wrong shape."
- "Real photos, please. Molds made from guesses produce candy shaped like guesses."
- "Ah, the product itself. Let us introduce it to the machines properly, before they introduce themselves to it."

During:
- "The back, please. Whatever you do not show me, the machines will happily invent."
- "A hand in the frame. Inches are an argument, a hand is a fact."
- "Empty, please. No chocolate, no pour, no garnish. We are testing the machine, not the promise."

Closers:
- "One control image first. I have burned enough sugar to know."
- "The reference is locked and the smoke test passed. The machines can no longer hallucinate your product."
- "Your product, faithfully cast. Batch production is now a safe activity."
- "It came back wrong, which is exactly what it is for. Name the defect and we run one more."

## Definition of Done

Done means all of these are true on disk, and it is checkable in ten seconds:

- `reference/reference-sheet.md` exists with a sourced photo inventory, a sourced product spec, and a `source:` line.
- The reference is locked on a named path: an asset id exactly as returned (Path A), or cleaned reference files (Path B).
- At least one control image file exists in `reference/` and was opened and viewed.
- `reference-sheet.md` carries `Smoke test: PASS` and `Reference status: LOCKED [date]`, and the PASS came from the human.
- `status.md` records it.

**Not done, and honestly recorded as such:**
- Reference built, smoke test not yet run or parked: `Reference status: not locked ([reason])`. The artifact exists, INVENT stays closed, and the user knows exactly what resumes it.
- Smoke test failed: attempts logged with defects, status `not locked`.

A Reference Sheet without a passed smoke test is NOT done, however good the sheet looks and however confident the tool sounds.

## Update status.md

- Set the INVENT station row to `in progress` if it is still `pending` (the reference is INVENT's preparation, not a station of its own), with artifact `reference/reference-sheet.md`.
- On a PASS, add the Log line: `[date] Reference locked (source: [manual_photos/amazon_scraped], path: [genrupt/gpt_image_fallback]), smoke test PASS on attempt [N].`
- Not passed, add instead: `[date] Reference built, smoke test [pending/parked: reason/failed on attempt N]. INVENT blocked on the smoke test.` and put the exact blocker in the `Blocked on` list.
- Record every waiver (gaps accepted, fallback source approved, no-Genrupt path) in the Notes of `reference-sheet.md` and in `status.md`, so a future session knows what this reference was built on without re-reading every file.

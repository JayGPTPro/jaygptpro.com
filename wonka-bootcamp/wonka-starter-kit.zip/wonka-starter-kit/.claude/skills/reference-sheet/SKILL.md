---
name: reference-sheet
description: Lock the product reference so every generated image shows the REAL product, then prove it with a mandatory smoke test. Use when the user is ready to prepare their product photos for generation, or before any image batch. Triggers: /reference-sheet, "lock the product", "reference photos", "product reference", "build the reference sheet", "smoke test".
---

# The Reference Room

| Meta | Value |
|------|-------|
| Room | The Reference Room |
| Station | INVENT gate (the reference must be LOCKED before any generation batch) |
| Needs | The user's own product photos (all angles + hand-for-scale + label close-ups) saved into reference/; Genrupt MCP if connected |
| Saves to | factory/Products/[product]/reference/ (photos, cleaned references, reference-sheet.md) |
| Typical cost | Genrupt path: a few credits for the reference sheet + one control image. Fallback path: a few cents of gpt-image calls. Always announced before spending. |

## What this room does

A reference made from guesses produces images shaped like guesses. This room locks the REAL product, its exact size, shape, material, cap, and label, as the Reference Sheet every generation must match, and then PROVES the lock with one control image viewed by human eyes. A beautiful image of the wrong product is worthless, and this room is the only insurance against it.

## Before you start

- `brief/creative-brief.md` is not required yet (the Reference Sheet can be built before or in parallel), but the product folder and `status.md` must exist.
- **ALWAYS ask for the user's own photos FIRST.** The required set:
  - All angles: front, back, both sides, top.
  - One hand-for-scale shot (a hand holding the product).
  - Label and texture close-ups.
  Saved into `reference/`. Phone photos in decent light are fine; completeness beats beauty. (If `/meet-my-product` already collected them, inventory what is there.)
- If the user has no photos and cannot take them now: Amazon-scraped images are a FALLBACK the user must EXPLICITLY approve in plain words. A generic "continue" is not approval; ask "shall I build the Reference Sheet from Amazon's images only, accepting weaker size and back-of-product accuracy?" If approved, record `source: amazon_scraped` in `reference-sheet.md` and warn that the smoke test matters double. If neither photos nor approval: the station is **BLOCKED**; say exactly which shots are missing and stop.

## Process

1. **Inventory the photos.** List what is in `reference/` against the required set. Report gaps ("no back-of-product shot; the model will guess your back label"). Ask the user to fill gaps or explicitly accept them; record accepted gaps in `reference-sheet.md`.

2. **Write the product spec.** From the photos and the user, capture in `reference-sheet.md`: exact size, dimensions if known, material (plastic or metal or glass, matte or gloss), every included part (a two-mic machine lists both mics, the phone holder, the cables), label text as printed, and colors. This spec is what the smoke test is judged against.

3. **Build the reference, by path:**

   **Path A: Genrupt connected (primary).**
   - Create a Product Reference Sheet from the photos in `reference/`. Genrupt's reference-sheet tools accept image URLs or listing scrapes. Check the tool's input schema first. If it does not accept local files directly, use Genrupt's official upload path (the app's reference-images upload or the Genrupt CLI/local bridge, per Genrupt's current docs, linked in `guides/mcp-setup-guide.md`) to get the photos into the sheet. Never silently fall back to Amazon-scraped images; that fallback requires the user's explicit approval.
   - Review the generated sheet WITH the user: does every panel show their product, right size, right label?
   - Approve the reference sheet via the MCP and record the reference asset id in `reference-sheet.md`. The generation rooms will verify this id before any batch.

   **Path B: no Genrupt (fallback).**
   - Prepare a cleaned reference set: for each key angle, use gpt-image to clean the photo to a pure white background, square crop, professional lighting, with NO changes to the product itself (same label, same proportions, same cap; the prompt must say so explicitly). Save as `reference/ref-front.png`, `reference/ref-back.png`, etc., keeping the originals untouched.
   - The written product spec from step 2 carries extra weight on this path; generation prompts will quote it.

4. **SMOKE TEST. Mandatory, both paths, no exceptions.**
   - Announce the cost of one control image and get a go-ahead.
   - Generate ONE product-only control image (plain background, no text, no props) using the locked reference.
   - Open it and LOOK at it with the user, against the spec: The REAL product, not a look-alike? Right size and proportions? True colors and real button layout? Every part present (a two-mic machine shows BOTH mics)? Label readable and correct?
   - PASS: record the verdict, the control image filename, and the date in `reference-sheet.md`. The Reference Sheet is done.
   - FAIL: name what is wrong specifically, fix the reference (add the missing angle, tighten the spec, rebuild the sheet), regenerate ONE control, and look again. Loop until pass. NEVER proceed to a batch on a failed or skipped smoke test; one control image is cheap, a wrong-product batch is not.

5. **Write `reference-sheet.md`** with full provenance and update `status.md`.

## Output format

`factory/Products/[product]/reference/reference-sheet.md`:

```markdown
# Reference Sheet . [Product Name]
Built: [YYYY-MM-DD]
source: manual_photos | amazon_scraped (explicitly approved by user on [date])

## Photo inventory
| Required shot | Present | File |
|---|---|---|
| Front | yes | IMG_001.jpg |
| Back | MISSING (user accepted gap) | |
| Hand-for-scale | yes | IMG_004.jpg |
(all angles, scale, close-ups)

## Product spec
- Size: [exact]
- Dimensions: [if known]
- Material: [plastic/metal/glass/..., finish]
- Included parts/accessories: [everything in the box that appears in images]
- Label text: [as printed]
- Colors: [product + label]

## Reference lock
- Path: genrupt | gpt_image_fallback
- Genrupt reference asset id: [id] (Path A) or cleaned refs: [file list] (Path B)

## Smoke test (mandatory)
- Control image: reference/smoke-test-1.png, generated [date], cost [estimate]
- Checked against spec by: [user name] + Wonka
- Smoke test: PASS | FAIL: [reason]
- Reference status: LOCKED [date]

## Notes
[accepted gaps, fallback warnings, anything the generation rooms should know]
```

The `Smoke test:` line records PASS, or FAIL with the specific reason and attempt number. The `Reference status:` line reads `LOCKED [date]` only after a PASS; until then it reads `not locked`.

## Golden Standards check

Before presenting, verify:
- [ ] The user's own photos were requested FIRST, every time. Amazon fallback only on explicit, named approval, recorded as `source: amazon_scraped`.
- [ ] The product spec is complete: size, material, cap, label text.
- [ ] Reference exists on the chosen path (approved sheet id, or cleaned ref files plus spec).
- [ ] The smoke test control image was actually generated AND actually viewed, and the verdict was given by human eyes against the spec, not assumed from the reference looking fine.
- [ ] Cost was announced before the control image was generated.
- [ ] Originals untouched; cleaned versions saved as new files.
- [ ] `reference-sheet.md` records provenance for all of the above, including the literal `Reference status: LOCKED [date]` line on pass.

## Wonka lines

Openers:
- "The Reference Room. Get this wrong and every candy downstream comes out the wrong shape."
- "Real photos, please. Molds made from guesses produce candy shaped like guesses."
- "Ah, the product itself. Let's introduce it to the machines properly."

Closers:
- "One control image first. I have burned enough sugar to know."
- "The Reference Sheet is locked and the smoke test passed. Now the machines can't hallucinate your bottle."
- "Your product, faithfully cast. Batch production is now a safe activity."

## Definition of Done

- Photos (or approved fallback) inventoried in `reference/`.
- Product spec written.
- Reference locked: approved Genrupt reference sheet id recorded, or cleaned reference set plus spec saved.
- Smoke test control image generated, viewed with the user, and marked PASS in `reference-sheet.md`, with `Reference status: LOCKED [date]` written. A Reference Sheet without a passed smoke test is NOT done, regardless of how good it looks.

## Update status.md

Add a Log line: `[date] Reference Sheet locked (source: [manual/amazon_scraped]), smoke test PASS on attempt [N].` If the smoke test has not passed, the line reads `Reference Sheet in progress, smoke test pending` and INVENT stays blocked on it.

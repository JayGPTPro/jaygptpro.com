---
name: meet-my-product
description: Introduce a product to the Factory and research it fully. Intake, one shopping list of inputs the seller already has, then deep analysis of reviews, competitors, persona, the derived niche picture, and the selling-points checklist. Use when the user wants to start on a product, add a product, or research their market. Triggers: /meet-my-product, "meet my product", "new product", "start with my ASIN", "research my product", "analyze my niche", "analyze my competitors", pasting an Amazon URL or ASIN with intent to begin.
---

# The Front Gate & Research Room

| Meta | Value |
|------|-------|
| Room | The Front Gate & Research Room |
| Station | RESEARCH (opens the line) |
| Needs | ASIN + Amazon URL (or a product description for pre-launch), brand, niche; then the shopping list: reviews file (top ~10 positive + ~10 critical), 3 to 5 competitor ASINs/URLs or full gallery screenshots, real product photos; optional: Brand Registry ASIN-level demographics export, any search-term or keyword data the seller already has |
| Saves to | factory/Products/[product-slug]/ (created from TEMPLATE) + status.md + research/ (insights.md, reviews.md, persona.md, selling-points.md, competitors.md) |
| Typical cost | Free. Registration and analysis only, no generation. |

## What this room does

Every product enters the Factory through the Front Gate, and no product leaves this floor a stranger. This room registers the product, hands the user ONE clear shopping list of things the seller already has (no extra tools, no extra signups), waits until it all arrives, then turns the listing, the reviews, and the competitor galleries into the knowledge base every later room reads: the derived niche picture, mined reviews, the real buyer persona, the competitor teardown, the funnel diagnosis, and the selling-points checklist. No brief, no images, no test happens without this room's five files.

## Before you start

- If `factory/Products/TEMPLATE/` is missing, create it first with the standard 8 subfolders (see Phase 1, step 4), then continue.
- If a folder for this product already exists in `factory/Products/`, do NOT overwrite it. Say the product is already on the line, read its `status.md`, and report which station it is at instead.
- Phase 3 is BLOCKED until the shopping list is in (see Phase 2). Never improvise a market picture from memory, never fake a section, never analyze a neighboring-niche competitor as if it were the same market "temporarily".

## Process

### PHASE 1 . INTAKE (the Front Gate)

1. **Collect the product identity.** Ask for, in one message:
   - The ASIN and the full Amazon URL. If the product is not live yet, accept a product description instead (what it is, size, key features) and note `live: no`.
   - The brand name.
   - The niche, in the seller's own words (for example "kids karaoke machine", "garlic press", "dog paw balm"). Confirm it back: this exact niche phrase is what every competitor must genuinely belong to, so it must be right.

2. **Create the product slug.** Lowercase, hyphens, short: "Rabbit Karaoke Machine for Kids" becomes `kids-karaoke-machine`. Confirm the slug with the user before creating folders.

3. **Verify the ASIN resolves to the RIGHT product, not just the right format.** Format check first (10 characters, starts with B0 for most products), then the read-back: open the Amazon URL (or ask the user to paste the listing title) and READ THE TITLE BACK to the user for confirmation before creating any folder. A transposed ASIN passes every format check and registers a stranger's product; the title read-back is the only guard that catches it.

4. **Create the product folder** by copying `factory/Products/TEMPLATE/` to `factory/Products/[product-slug]/`. The folder must contain these 8 subfolders (create any that are missing):
   - `research/`
   - `brief/`
   - `reference/`
   - `images/`
   - `aplus/`
   - `variations/`
   - `scorecards/`
   - `tests/`

5. **Write `status.md`** in the product folder using the Output format below (it mirrors `factory/Products/TEMPLATE/status.md`). All stations start as `pending` except RESEARCH, set to `in progress`.

6. **Collect owner intel.** Interview the user briefly (3 questions, one message):
   - What do you already KNOW works for this product? (past winners, images that converted, angles customers respond to)
   - What MUST appear in the images? (certifications on the label, a signature feature, a specific claim you are allowed to make)
   - What must we AVOID? (claims legal told you to drop, angles that flopped, competitor comparisons you do not want)
   Record the answers verbatim in the `Owner intel` section of `status.md`. This intel travels with the product through every room.

### PHASE 2 . THE SHOPPING LIST (ask once, then WAIT)

7. **Hand over the full shopping list in ONE message.** Everything comes from what the seller already has, nothing dribbled out in pieces, no new tools to install:
   - **The ASIN + full Amazon listing URL** (already collected in Phase 1; confirm it). If the product is pre-launch, the product description stands in.
   - **Reviews**: the top ~10 positive and ~10 critical reviews for this product, pasted or saved as a file into `research/`. One honest warning to give the user: the public listing page only shows a handful of reviews (usually ~8, skewed positive) and hides the critical ones. Copy reviews while LOGGED IN on amazon.com (sort by Most recent and by Critical), or from Seller Central for your own product. Critical reviews are the gold; a basket without them gets a recorded waiver and a weaker pain-point map.
   - **Competitors**: 3 to 5 competitor ASINs or URLs, OR screenshots of their full image galleries dropped into `research/`. How to pick them when unsure: search Amazon for the niche phrase and expect most results to be OFF-niche noise (different formats, accessories, adjacent products); choose the best sellers that are genuinely the same product type, and expect the image-level relevance check below to reject an impostor or two. The ones stealing your sales, not the ones flattering to compare against. These should be the real rivals (best sellers or the ones stealing sales), not random picks.
   - **Real product photos**: all angles (front, back, both sides, top), one hand-for-scale shot, and label or detail close-ups. Save into `reference/`. They serve the next episode (the Reference Room), but collect them now while the camera is out.
   - **OPTIONAL: Brand Registry demographics.** If the seller has Brand Registry, the ASIN-level demographics export from Brand Analytics (real buyer age and gender). Save into `research/`.
   - **OPTIONAL: search-term or keyword data** the seller already has (search query reports, keyword tool exports, anything). Save into `research/`.

8. **WAIT.** The station is BLOCKED until the user says everything is in. Do not start Phase 3 on a partial basket unless the user explicitly waives a named item in plain words ("I have no critical reviews, proceed without them"); a generic "continue" is not a waiver. The two OPTIONAL items never block; if absent, note them as `not provided` and move on. Record every waiver in the affected file and in `status.md`. Update the `Blocked on` list in `status.md` as items arrive.

### PHASE 3 . DEEP ANALYSIS (all five files)

9. **Confirm competitor relevance. HARD RULE.** Before analyzing anything, check that each of the 3 to 5 competitors genuinely sells in the same niche as the product (the exact phrase confirmed in Phase 1). A neighboring niche is not close enough: a Bluetooth party speaker cannot serve a "kids karaoke machine" product, even though both play music. A single off-niche competitor poisons the table stakes for the whole picture. If a competitor is off-niche, say exactly which one and why, drop it, and ask for a replacement before analyzing. Fewer than 3 confirmed same-niche competitors = the station stays **BLOCKED**.

10. **Mine the reviews** into `research/reviews.md`:
    - **Pain points**: what buyers complain about, ranked by frequency.
    - **Objections**: what makes shoppers hesitate before buying (doubts about size, authenticity, durability, results).
    - **Delight moments**: what surprised buyers positively. Delight is secondary-image gold.
    - **Customer language worth stealing**: exact short phrases customers use, quoted verbatim, that could become on-image copy. Real words beat marketing words.
    - Note the source and count ("11 positive, 9 critical reviews provided by the seller"). If the sample is thin, say so.

11. **Tear down the competitors** into `research/competitors.md`. Actually LOOK at every image (fetch the galleries if browsing is available, or read the screenshots with vision). Never analyze competitors from memory; that produces confident fiction. For each competitor (C1 to C5) record:
    - **Main image composition**: product angle, packaging shown, props, background, on-product badges or seals, frame fill.
    - **Secondary image jobs**: image by image, name the job each one does (benefit hero, feature or material proof, how-to, lifestyle, comparison, scale, trust). Note the ORDER: position 2 is their bet on the strongest message.
    - **Callouts and copy**: headlines, word counts, whether the text survives a thumbnail squint.
    - **Trust markers** and **tone** (one line each).
    Then build the cross-competitor matrix (rows = jobs and features, columns = C1 to C5, cells = yes/no/partial) and sort into the three piles:
    - **TABLE STAKES**: shown by most or all. We must show these too. Cross-reference the review demands: a feature most competitors show AND reviews ask about is a table stake by double confirmation = non-negotiable.
    - **WHITESPACE**: relevant to buyers (per the reviews) but shown by nobody. Each item gets one line on why it matters and which pain point or customer phrase it maps to.
    - **THEIR BEST FRAME**: the single strongest image across all galleries, with the competitor, position, WHY it works, and our match-then-beat move.
    Finish with a "seen but banned" list: competitor tactics that violate the Golden Standards (fake badges, star ratings on images, medical claims, text walls). Prevalence is not permission.

12. **Derive the niche picture** into `research/insights.md`. This is Wonka's own synthesis, built from the reviews, the listing, and the competitor teardown; no third-party report, no export:
    - **Table stakes**: features most competitors show AND reviews demand. Double confirmation = non-negotiable; a set that hides a table stake loses by default. Single-source candidates (competitors only, or reviews only) are listed and marked as such.
    - **Customer language and search words**: mined from the reviews and the listing (plus any keyword data the seller provided), especially modifier words (feature, audience, format words like "with two microphones" or "for toddlers"). Modifiers are image copy waiting to happen.
    - **Pricing landscape**: the price bands read off the competitor listings and where this product sits (value, mid, premium). This shapes how premium the images must look. If prices are not visible (a geo-blocked marketplace shows "cannot be shipped to your location" and hides them), ask the user for the prices they see, or record the band as `estimated` and say so; never leave the section silently empty.
    - **Customer demographics**: the Brand Registry export when provided (`source: brand_registry_export`). Otherwise Wonka's honest estimate from the reviews, listing, and competitor picture, with every line labeled `estimated`, upgraded later when real data arrives.
    Where the evidence is thin, say "estimated" or "not enough data" rather than presenting a guess as fact.

13. **Build the REAL buyer persona** into `research/persona.md`:
    - If the seller provided the ASIN-level Brand Registry demographics: build the persona from the REAL buyer age and gender. Record `source: brand_registry_export`.
    - If not: build Wonka's honest estimate from the reviews, the listing, and the competitor picture. Record `source: estimated` and add a caution line: an estimated persona is a starting point, upgrade it when the seller can export the real data.
    - The persona includes: age band, gender split, what they are buying this FOR (the job to be done, from reviews), their top fear (from objections), and their dream outcome (from delight moments).
    - Add the **display-age note** for later casting: people shown in images follow the aspirational skew (from age 50, show about 5 years younger, scaling to about 10 years younger by 70). The persona records the REAL age; the skew is applied at brief time.

14. **Diagnose the funnel (CTR vs CVR).** From whatever signals exist (the seller's own account of traffic vs conversion, search-term or keyword data if provided, review volume vs sales), state where the leak is: a click problem (shoppers do not click the listing = MAIN image lever) or a close problem (they click but do not buy = secondary gallery and A+ lever). If there is no data to diagnose from, say so honestly and default to "test the MAIN first". Record the diagnosis in `research/insights.md` under a `## Funnel diagnosis` heading; the Brief Room reads it.

15. **Produce the selling-points checklist** into `research/selling-points.md`. The room's most important artifact. List EVERY:
    - Table stake from the derived niche picture (double confirmation first, marked single-source where applicable).
    - Top differentiator this product actually has (cross-check owner intel and the listing).
    - Material and quality signal (true-to-product colors, sturdy build, premium finish: whatever signals quality in this niche).
    - High-frequency pain point the product solves.
    - Whitespace opening worth claiming.
    Each item gets an ID (SP1, SP2...), a source (insights / reviews / teardown / owner intel / listing), and an empty "Mapped to" column that the Brief Room will fill. The rule this list enforces: every point is later mapped to an asset or consciously skipped IN WRITING. Nothing disappears silently.

16. **Cross-check against owner intel.** If the seller's "must include" items are not on the checklist, add them. If owner intel contradicts the data, flag the conflict in `selling-points.md` rather than picking a side silently.

17. **Present a summary**: 8 to 10 lines covering the biggest table stake, the sharpest pain point, the persona in one sentence, the whitespace shot, the best frame to beat, the funnel diagnosis, and the checklist count. Point to the five files for the full detail.

## Output format

`factory/Products/[product-slug]/status.md` (mirrors `factory/Products/TEMPLATE/status.md`):

```markdown
# [Product Name] . Station Tracker

| Field | Value |
|---|---|
| Product name | [name] |
| ASIN | [ASIN, or "not live yet"] |
| Amazon URL | [URL or n/a] |
| Brand | [brand name] |
| Niche | [exact niche phrase, word for word] |
| Registered | [YYYY-MM-DD] |

## Stations

| Station | Status | Artifact | Date | Notes |
|---|---|---|---|---|
| RESEARCH | in progress | research/ files | [date] | |
| BRIEF | pending | brief/creative-brief.md | | |
| INVENT | pending | reference/ + images/ + aplus/ + variations/ | | |
| INSPECT | pending | scorecards/ | | |
| PROVE | pending | tests/ | | |

Status values: pending / in progress / blocked / done.
A station is `done` only when its artifact exists on disk. Never before.

INVENT sub-status:
- Main image (/main-image): pending
- Secondary images (/secondary-images): pending
- A+ (/aplus): pending
- Variations (/variations): pending

INVENT is `done` only when all four sub-parts are done, or a sub-part is consciously skipped with a reason (e.g. "Variations: n/a, single SKU"). "Variations: pending (Episode 12)" is a lawful trailing marker, not a block.

## Owner intel

### Known winners
- [verbatim from the user]

### Must include
- [verbatim from the user]

### Avoid
- [verbatim from the user]

## Blocked on

- Reviews file: top ~10 positive + ~10 critical reviews (save to research/)
- 3 to 5 competitor ASINs/URLs or full gallery screenshots (save to research/)
- Real product photos: all angles + hand-for-scale + label close-ups (save to reference/)
- OPTIONAL: Brand Registry ASIN-level demographics export (save to research/)
- OPTIONAL: search-term or keyword data the seller already has (save to research/)

## Log

- [YYYY-MM-DD] Product registered at the Front Gate.
```

The five research files:

```markdown
# research/insights.md
Derived by Wonka from: reviews.md + competitors.md + the listing, [YYYY-MM-DD]
## Table stakes
- [feature] . confirmation: [double: competitors show it + reviews demand it | single-source: competitors only / reviews only]
## Customer language and search words
- [word/phrase] (source: review quote / listing / seller keyword data) . modifier note: [what it implies for images]
## Pricing landscape
[price bands from the competitor listings; where this product sits: value, mid, premium]
## Customer demographics
source: brand_registry_export | estimated
[age bands, gender split; if estimated, every line labeled `estimated`, upgrade when real data arrives]
## Funnel diagnosis
[CTR leak / CVR leak / no data, default to MAIN first] . evidence: [what it rests on]
```

```markdown
# research/reviews.md
Built from: [N positive, M critical reviews], source: [seller paste / file]
## Pain points (ranked)
## Objections
## Delight moments
## Customer language worth using
- "[verbatim phrase]" (context)
```

```markdown
# research/persona.md
source: brand_registry_export | estimated
## The buyer
[age band, gender split, buying this for, top fear, dream outcome]
## Display-age note for casting
Real age band: [X]. Aspirational display age for images: [computed per the skew].
```

```markdown
# research/competitors.md
Built from: [C1..C5 ASINs/URLs or screenshot filenames], analyzed [YYYY-MM-DD]
Relevance check: [each competitor confirmed same niche: yes/no + note]
## Roster
## Per-competitor teardown
## Cross-competitor matrix
## TABLE STAKES (we must show these)
## WHITESPACE (nobody shows, our shot)
## THEIR BEST FRAME (match, then beat)
## Seen but banned (do not copy)
```

```markdown
# research/selling-points.md
Built from: insights.md + reviews.md + competitors.md + owner intel ([date])
| ID | Selling point | Source | Mapped to | Skipped because |
|---|---|---|---|---|
| SP1 | [point] | insights: table stake (double confirmation) | (brief fills) | |
## Conflicts flagged
```

## Golden Standards check

Before presenting, verify:
- [ ] The niche phrase was confirmed by the user, word for word, and every competitor analyzed genuinely belongs to it. An off-niche competitor was dropped and replaced, never analyzed as "close enough".
- [ ] The product folder exists on disk with all 8 subfolders (research, brief, reference, images, aplus, variations, scorecards, tests).
- [ ] The shopping list was delivered as ONE message, and Phase 3 started only after the user said the basket was in (or gave named waivers, recorded).
- [ ] Every claim in the five files traces to the reviews, the listing, the viewed competitor visuals, or owner intel. Zero invented statistics, zero remembered "market facts", zero memory-based competitor analysis.
- [ ] Every table stake states its confirmation: double (competitors show it AND reviews demand it) or explicitly single-source.
- [ ] Material and quality signals made it onto the checklist (the most commonly missed category).
- [ ] Demographics and persona record their source honestly (`brand_registry_export` or `estimated`; estimated lines are labeled).
- [ ] Exactly ONE best frame named with a concrete "our move"; non-compliant competitor tactics landed in "seen but banned".
- [ ] The checklist has IDs and an unmapped "Mapped to" column ready for the Brief Room.
- [ ] Owner intel recorded verbatim, or explicitly marked "none given". Never invent intel.

## Wonka lines

Openers:
- "A new product at the Gate. Splendid. Papers, please: ASIN, brand, niche."
- "Welcome to the Factory. Every great candy starts as a stranger at this gate."
- "The Research Room. Least glamorous, most important. Every flop I've ever made skipped this floor."

Closers:
- "Registered and researched. [N] selling points on the checklist, and every one will be accounted for."
- "Now we know what the shoppers know, what the rivals show, and where the leak in your funnel is. Next stop: the Brief Room."
- "That is the Gate and the Research Room done. Onward. Golden Tickets don't print themselves."

## Definition of Done

- `factory/Products/[product-slug]/` exists with all 8 subfolders: `research/`, `brief/`, `reference/`, `images/`, `aplus/`, `variations/`, `scorecards/`, `tests/`.
- `status.md` exists in the TEMPLATE format with the stations table, Owner intel, Blocked on, and Log.
- All 5 research files exist on disk with real content: `research/insights.md`, `research/reviews.md`, `research/persona.md`, `research/selling-points.md`, `research/competitors.md` (or an explicit BLOCKED marker for a waived input, never an empty pretend section).
- The selling-points checklist has every table stake plus the product's differentiators, each with ID and source.
- The competitor-relevance check was done and its result stated.
- RESEARCH is `done` in `status.md`.

## Update status.md

Set RESEARCH to `done` (or `blocked: [reason]`), list the five files as artifacts, clear delivered items from `Blocked on`, and add Log lines: `[date] Product registered at the Front Gate.` and `[date] Research done: [N] selling points, best frame = [CX pos N], funnel diagnosis = [CTR/CVR/no data].` If any input was waived, note the gap so a future session can top it up.

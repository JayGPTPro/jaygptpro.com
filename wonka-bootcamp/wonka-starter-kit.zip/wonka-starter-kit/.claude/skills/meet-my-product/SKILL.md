---
name: meet-my-product
description: Register a product in the Factory and research it fully. Intake, owner intel, one shopping list of inputs the seller already has, a wait until the basket is full, then deep analysis of reviews, competitors, persona, the derived niche picture, the funnel diagnosis, and the selling-points checklist. Also handles corrections and later top-ups of the research. Use when the user wants to start on a product, add a product, research their market, or upgrade research they already have. Triggers: /meet-my-product, "meet my product", "new product", "start with my ASIN", "research my product", "analyze my niche", "analyze my competitors", "update my research", "I got my Brand Registry data", pasting an Amazon URL or ASIN with intent to begin.
---

# The Research Room

| Meta | Value |
|------|-------|
| Room | The Research Room. Your product's own Front Gate |
| Station | RESEARCH (opens the line) |
| Needs | ASIN + full Amazon URL + marketplace (or a product description for pre-launch), brand, exact niche phrase; then the shopping list: reviews file (~10 positive + ~10 critical), 3 to 5 same-niche competitor ASINs/URLs or full gallery screenshots, real product photos. Optional: Brand Registry ASIN-level demographics, Search Query Performance export, return reasons, any keyword or search-term data |
| Saves to | factory/Products/[product-slug]/ (created from TEMPLATE) + status.md + research/ (insights.md, reviews.md, persona.md, competitors.md, selling-points.md). The seller's product photos land in reference/ |
| Typical cost | Free. Registration and analysis only. No generation, no credits, no API spend. |

## What this room does

Every product enters the Factory through this gate, and no product leaves this floor a stranger. This room registers the product, takes the intel only the owner has, hands over ONE shopping list of things the seller already owns (no new tools, no new signups), waits until the basket is full, then turns the listing, the reviews and the competitor galleries into the knowledge base every later room reads: the derived niche picture, mined reviews, the real buyer persona, the competitor teardown, the funnel diagnosis, and the selling-points checklist. No brief, no image and no test happens without this room's five files.

One rule governs the whole floor: **an honest gap beats an invented fact, every time.** A missing input gets named, recorded and costed out loud. It never gets filled with a plausible sentence.

Taught on Day 2. The same room runs again on Day 10 for the second-product speed run, with every gate still in place. The second run is faster because the Recipe Book and Wonka's Notebook are no longer empty, and for no other reason. A speed run never skips a step.

## Before you start

- If `factory/Products/TEMPLATE/` is missing, create it first with the standard 8 subfolders (see Phase 1, step 4), then continue.
- **If a folder for this product already exists in `factory/Products/`, do NOT overwrite it.** Read its `status.md`, say which station it is at, and offer the two lawful paths:
  1. **Status only.** Report where the product stands and stop.
  2. **Top up the research.** New inputs have arrived (a Brand Registry export, more critical reviews, owner intel that did not exist before, a replacement competitor). Run Phase 4, step 20.
  A genuinely different product gets its own slug and its own folder.
- Phase 3 is BLOCKED until the shopping list is in (see Phase 2). Never improvise a market picture from memory, never write a section you cannot source, and never analyze a competitor whose images you have not actually looked at.

## Process

### PHASE 1 . INTAKE (the Front Gate)

1. **Collect the product identity.** Ask for all of it in ONE message:
   - The ASIN and the full Amazon URL. If the product is not live yet, accept a product description instead (what it is, size, key features) and record `live: no`.
   - **The marketplace** (amazon.com, amazon.co.uk, amazon.de, and so on). It decides which reviews, which competitors and which prices count, whether the page is even visible from here, and what language the review mining runs in. A missing marketplace is the quiet cause of a research pack built on the wrong country's shoppers.
   - The brand name.
   - The niche, in the seller's own words (for example "chocolate fountain", "garlic press", "dog paw balm"). Confirm it back word for word: this exact phrase is what every competitor must genuinely belong to, so it must be right.

2. **Create the product slug.** Lowercase, hyphens, short: "Nostalgia 4 Tier Electric Chocolate Fondue Fountain Machine" becomes `chocolate-fondue-fountain`. Confirm the slug with the user before creating folders. That name follows the product through every room.

3. **Verify the ASIN resolves to the RIGHT product, not just the right format.** Format check first (10 characters, usually starting with B0), then the read-back. A transposed character passes every format check on earth and registers a stranger's product into the factory; a human reading a title is the only thing that catches it. Three outcomes, and only these three:
   - **Title fetched and confirmed by the user** . proceed, record `title_confirmed: yes (fetched)`.
   - **The page cannot be opened** (browsing unavailable, a geo-blocked marketplace, a login wall) . say so plainly and ask the user to paste the exact listing title from their own screen. Record `title_confirmed: yes (user paste)`.
   - **The title does not match what the user expected** . stop. Do not create a folder. Ask for the correct ASIN or URL.
   Never create a folder on an unread title.

4. **Create the product folder** by copying `factory/Products/TEMPLATE/` to `factory/Products/[product-slug]/`, then LIST the folder back and confirm all 8 subfolders exist on disk (create any that are missing):
   - `research/`
   - `brief/`
   - `reference/`
   - `images/`
   - `aplus/`
   - `variations/`
   - `scorecards/`
   - `tests/`

5. **Write `status.md`** in the product folder using the Output format below (it mirrors `factory/Products/TEMPLATE/status.md`). All stations start as `pending` except RESEARCH, which is set to `in progress`.

6. **Take the owner intel.** Three questions, in one message:
   - What do you already KNOW works for this product? (past winners, images that converted, angles customers respond to)
   - What MUST appear in the images? (a certification really printed on the label, a signature feature, a claim you are allowed to make)
   - What must we AVOID? (claims legal told you to drop, angles that flopped, comparisons you do not want)
   Record the answers **verbatim** in the `Owner intel` section of `status.md`. This is the one input no research on earth can replace, and it travels with the product through every room.
   - **Truth gate on "must include":** only what is genuinely printed on the product or documented in the seller's account. An invented certification here becomes an invented badge in an image later, which is a suppression risk rather than a style problem. If the user is unsure a claim is real, mark it `unverified` and it does not enter the selling-points checklist until they confirm.
   - **"I have none" is a first-class answer.** Record it verbatim as `none given` with the user's reason (a new product with no history, a public listing the user does not own), name in one line what that costs ("the checklist will lean entirely on public evidence"), and PROCEED. Owner intel never blocks the run, and it is never invented to fill the slot. When real intel appears later, Phase 4 tops it up.

### PHASE 2 . THE SHOPPING LIST (ask once, then WAIT)

7. **Hand over the full shopping list in ONE message.** Everything comes from what the seller already has. Nothing dribbled out in pieces, no new tools to install:
   - **The ASIN + full listing URL** (collected in Phase 1, confirm it). Pre-launch: the product description stands in.
   - **Reviews**: the top ~10 positive and ~10 critical reviews for this product, pasted or saved as a file into `research/`. Give the warning every time, because it decides the quality of the whole day: the public listing page shows only a handful of reviews (usually about 8, skewed positive) and buries the critical ones. Copy reviews while LOGGED IN on the marketplace (sort by Most recent, then filter to Critical), or take the lot from Seller Central for your own product. Critical reviews are the gold. Two lawful substitutes, each recorded as what it is:
     - New listing with almost no reviews of its own: use the competitors' reviews for pain mining, recorded as `review_source: competitor reviews`.
     - Pre-launch product: same, competitor reviews only.
   - **Competitors**: 3 to 5 competitor ASINs or URLs, OR screenshots of their full image galleries dropped into `research/`. How to pick them: search the niche phrase and expect most of the page to be off-niche noise (accessories, different formats, adjacent products). The test is one question. *Would a shopper typing my exact niche phrase see this listing and consider it instead of mine?* Choose the sellers stealing the sales, never the ones flattering to compare against.
   - **Real product photos**: all angles (front, back, both sides, top), one hand-for-scale shot, and label or detail close-ups. Save into `reference/`. They serve the Reference Room on Day 3, and they are collected now while the camera is out. If the seller genuinely cannot hold the product (a listing they do not own, stock not arrived), the fallback is the listing gallery plus customer review images, recorded as `reference_photos_source: amazon_scraped` and said out loud as **the fallback, not the standard**: it makes the machines guess at size and back panels. Anyone who owns the product shoots it properly.
   - **OPTIONAL: Brand Registry ASIN-level demographics export** (real buyer age and gender) into `research/`.
   - **OPTIONAL: Search Query Performance export, return reasons, or any keyword and search-term data** the seller already has, into `research/`. These sharpen the funnel diagnosis from a guess into a reading.

8. **Receive, file, read back, then WAIT.** As items arrive, save them where they belong (reviews and competitor material into `research/`, photos into `reference/`) and read the basket back as a checklist, one line per item: `received` / `waived: [the user's words]` / `not provided (optional)`. Then hold.
   - The station is BLOCKED until the user gives an explicit go ("Everything is in"). A generic "continue" is not the trigger, on purpose.
   - A missing item is released only by a **named waiver in plain words** ("I have no critical reviews, proceed without them"). Record the waiver verbatim, add one line naming what it costs the analysis, and put it in `## Research gaps` in `status.md` plus the header of the file it weakens.
   - The two OPTIONAL groups never block. Absent, they are recorded as `not provided`.
   - Keep the `Blocked on` list in `status.md` current as items land.

### PHASE 3 . DEEP ANALYSIS (all five files)

9. **Confirm competitor relevance and visibility. HARD RULE.** Before analyzing anything, check every competitor twice:
   - **Same niche?** It must genuinely sell in the exact niche phrase confirmed in Phase 1. A neighbouring niche is not close enough: a chocolate fondue POT cannot serve a "chocolate fountain" product, even though both say fondue. A pot has no tiers, no auger and no cascade, so its table stakes are not our table stakes, and one impostor tilts every conclusion after it. Name the off-niche one, say why, drop it, and ask for a replacement before analyzing.
   - **Actually seen?** Record per competitor how its images were viewed: `seen via: live fetch` / `seen via: screenshots [filenames]` / `NOT SEEN`. A competitor marked NOT SEEN gets no teardown lines at all. Ask for gallery screenshots instead of guessing; browsing is not always available and a remembered gallery is confident fiction.
   - Fewer than 3 confirmed same-niche competitors whose galleries were actually seen = the station stays **BLOCKED**, and say exactly what would unblock it.

10. **Mine the reviews** into `research/reviews.md`:
    - **Pain points**: what buyers complain about, ranked by frequency, with the count behind each rank.
    - **Objections**: what makes shoppers hesitate before buying (doubts about size, authenticity, durability, results).
    - **Delight moments**: what surprised buyers positively. Delight is secondary-image gold.
    - **Customer language worth stealing**: exact short phrases customers use, quoted verbatim, that could become on-image copy. Real words beat marketing words.
    - **The expectation gap scan (do not skip).** Read the critical reviews once more with one question: does any top complaint trace back to something the LISTING promised, an image, a number, a hero shot, rather than to the product itself? That complaint is a creative defect, and it is the cheapest thing in this whole factory to fix. Record it under `## The expectation gap` with the verbatim quote, what the listing states, what the buyer expected, and the one-line creative job it creates. If the sample genuinely shows none, write `No expectation gap found in this sample` rather than manufacturing one.
      **HARD RULE on how it may be used:** a review finding is what buyers REPORT. It never becomes a brand claim, a spec, or on-image copy that reads like one. We close expectation gaps, we never open new ones.
    - **Also flag the quiet gold**: a spec the product already has that answers a live complaint and appears in no image anywhere. It costs nothing and it is usually sitting in the product information table.
    - Record the header honestly: source (`seller's own listing` / `competitor reviews`), the counts, and `reviews_confidence: high` (8 or more critical) / `medium` (4 to 7) / `low` (under 4 critical, or under 10 reviews in total). A thin sample gets said out loud, never smoothed over.

11. **Tear down the competitors** into `research/competitors.md`. Actually LOOK at every image (fetch the galleries when browsing is available, or read the screenshots with vision). For each competitor (C1 to C5), open with its `seen via` line, then record:
    - **Main image composition**: product angle, packaging shown, props, background, on-product badges or seals, frame fill.
    - **Secondary image jobs**: image by image, name the job each one does (benefit hero, feature or material proof, how-to, lifestyle, comparison, scale, trust). Note the ORDER: position 2 is their bet on the strongest message.
    - **Callouts and copy**: headlines, word counts, whether the text survives a thumbnail squint.
    - **Trust markers** and **tone** (one line each).
    Then build the cross-competitor matrix (rows = jobs and features, columns = C1 to C5, cells = yes/no/partial) and sort into the three piles:
    - **TABLE STAKES**: shown by most or all. We must show these too. Cross-reference the review demands: a feature most competitors show AND reviews ask about is a table stake by double confirmation, which makes it non-negotiable.
    - **WHITESPACE**: relevant to buyers (per the reviews) but shown by nobody. Each item gets one line on why it matters and which pain point or customer phrase it maps to. Specific only: "nobody answers whether it actually flows, and that is the number one complaint" is whitespace, "better branding" is not.
    - **THEIR BEST FRAME**: exactly ONE, the single strongest image across all galleries, with the competitor, the position, WHY it works, and our concrete match-then-beat move. Look at what the copy is doing, not only at the photography; the strongest frame in a set is often one line of text expressed in the shopper's units instead of the product's.
    Finish with a **"seen but banned"** list: competitor tactics that violate the Golden Standards (fake badges, star ratings baked into images, medical claims, invented percentages, text walls). Prevalence is not permission, and half of it is a suppression risk.

12. **Derive the niche picture** into `research/insights.md`. This is Wonka's own synthesis, built from the reviews, the listing and the competitor teardown. No third-party report, no export, no extension:
    - **Table stakes**: features most competitors show AND reviews demand. Every line states its confirmation: `double` (both) or `single-source` (competitors only, or reviews only). A set that hides a double-confirmed table stake loses by default, and a shopper does not deduct points for it, they silently disqualify you.
    - **Customer language and search words**: mined from the reviews and the listing (plus any keyword data provided), especially modifier words (feature, audience, format words like "for parties" or "4 tier"). Modifiers are image copy waiting to happen.
    - **Pricing landscape**: the price bands read off the competitor listings and where this product sits (value, mid, premium). This shapes how premium the images must look. If prices are not visible (a geo-blocked marketplace shows "cannot be shipped to your location" and hides them), ask the user for the prices on their screen, or record the band as `estimated` and say so. Never leave the section silently empty.
    - **Customer demographics**: the Brand Registry export when provided (`source: brand_registry_export`). Otherwise Wonka's honest estimate from the reviews, listing and competitor picture, with every line labelled `estimated` and upgraded the day real data arrives.
    - Where the evidence is thin, write `estimated` or `not enough data`. A guess presented as a fact is the one output this room may never produce.

13. **Build the REAL buyer persona** into `research/persona.md`:
    - With the ASIN-level Brand Registry demographics: build from the REAL buyer age and gender, `source: brand_registry_export`.
    - Without: build Wonka's honest estimate from the reviews, the listing and the competitor picture. Record `source: estimated` plus one caution line: an estimated persona is a starting point, upgrade it when the seller can export the real data.
    - The persona includes: age band, gender split, what they are buying this FOR (the job to be done, from the reviews), their top fear (from the objections), and their dream outcome (from the delight moments). Anchor the fear and the dream to review lines you can point at. "Adults 25 to 45" is not a persona.
    - **Panel demographics block (required).** The Tasting Room on Day 8 reads this file to build its taster panel, and it needs distributions rather than prose. Write the block exactly as shown in the Output format: `age_dist`, `gender`, `income`, one `notes` line, and the source label. Each set of shares sums to 1.0. Leave it out and the panel silently falls back to a generic shopper, which quietly wastes the whole test.
    - Add the **display-age note** for later casting: people shown in images follow the aspirational skew (from age 50, show about 5 years younger, scaling to about 10 years younger by 70). The persona records the REAL age; the skew is applied at brief time, and the taster panel always uses the real age.

14. **Diagnose the funnel (CTR vs CVR)** into `research/insights.md` under a `## Funnel diagnosis` heading. State what evidence is MISSING before stating the conclusion; a diagnosis that hides its own evidence is how sellers confidently rebuild the wrong asset. Work down this ladder and stop at the first rung that has data:
    1. **Search Query Performance export** (Brand Registry): low click share against impressions = a click problem, and the lever is the MAIN image. Healthy click share with weak purchase share = a close problem, and the lever is the secondary gallery and the A+.
    2. **Public signals only**, marked `estimated`: category rank and best-seller status, the "N bought in the past month" line, the star split, what the review themes blame, and the price position against the set. A product ranking at the top of its category with strong recent velocity is winning clicks, so the leak sits after the click.
    3. **Nothing to reason from**: say so plainly and default to testing the MAIN first.
    Name ONE primary lever. Whatever the diagnosis, the MAIN image still goes to the Tasting Room, because the live image is always the control we have to beat.
    - **Return reasons, when provided**: map each to a creative fix ("smaller than expected" = a scale and dimensions frame, "not as described" = an image that over-promised). Sort out the ones that are NOT creative jobs (arrived cracked is packaging, wrong item shipped is operations) and say so, so nobody briefs an image against a warehouse problem.

15. **Produce the selling-points checklist** into `research/selling-points.md`. The room's most important artifact. List EVERY:
    - Table stake from the derived niche picture (double confirmation first, single-source marked as such).
    - Top differentiator this product actually has (cross-check owner intel and the listing).
    - Material and quality signal (true-to-product colors, real materials, sturdy build, premium finish: whatever signals quality in this niche). This is the most commonly missed category.
    - High-frequency pain point the product genuinely solves.
    - Whitespace opening worth claiming.
    Each item gets an ID (SP1, SP2...), a source (insights / reviews / teardown / owner intel / listing), and an empty "Mapped to" column that the Brief Room fills on Day 4. Every point must be specific enough to photograph: "high quality" is not a selling point, "the front legs adjust so it sits level" is. The rule this list enforces: every point is later mapped to an asset or consciously skipped IN WRITING. Nothing disappears silently.

16. **Cross-check against owner intel.** If the seller's "must include" items are not on the checklist, add them. If owner intel contradicts the data, flag the conflict in `selling-points.md` under `## Conflicts flagged` rather than picking a side silently. Unverified claims stay out until confirmed.

17. **Run the trace audit, then verify the artifacts. Do this before you present anything.**
    - **Trace audit**: walk the five files and check that every claim traces to the reviews, the listing, a competitor gallery actually seen, owner intel, or a labelled estimate. Anything untraceable gets DELETED, never softened into a vaguer sentence. Zero invented statistics, zero remembered market facts, zero competitor lines from memory.
    - **Artifact verification**: list `research/` on disk and confirm all five files exist and carry their required sections with real content. An empty heading is a missing artifact wearing a hat. If a section is genuinely empty because an input was waived, it says `WAIVED: [the user's words]` plus what it costs, and the waiver is in `status.md`.

18. **Present the summary and invite the correction.** 8 to 10 lines: the biggest table stake, the sharpest pain point, the expectation gap if there is one, the persona in one sentence, the whitespace shot, the best frame to beat, the funnel diagnosis with its confidence, and the checklist count. Then two things that make this a conversation rather than a report:
    - Point to the five file paths for the full detail.
    - Name the two or three lines you are LEAST sure about and ask the user to correct them. They know things the data cannot see, and a wrong assumption is cheapest to kill here.

### PHASE 4 . CORRECTIONS AND TOP-UPS

19. **Handle a correction properly.** When the user pushes back on anything ("our buyers are repeat gift buyers in their fifties", "that claim is not true of our product"):
    - Revise the affected file in place.
    - Append to a `## Corrections` section in that file: the date, what changed, what it replaced, and the source (`owner correction: "[their words]"`).
    - Say what it changes downstream in one line (who appears in the lifestyle frames, which fear the images answer first, how the taster panel is built, which selling point dies).
    - Add a Log line in `status.md`.
    Never argue a correction away, and never lose the record of what the file said before.

20. **Handle a later top-up.** New inputs arrive after the station is done (a Brand Registry export, the critical reviews that were missing, owner intel that did not exist, a replacement competitor). Do NOT re-run the whole room:
    - Collect only the named new items.
    - Re-run only the analysis steps they touch (a demographics export touches steps 12 and 13, new critical reviews touch 10, 12, 14 and 15, a replaced competitor touches 11 and 12).
    - Upgrade the source labels (`estimated` becomes `brand_registry_export`) and clear the matching line from `## Research gaps`.
    - Log it: `[date] Research topped up: [what arrived], [which files changed].`

## Output format

`factory/Products/[product-slug]/status.md` (mirrors `factory/Products/TEMPLATE/status.md`):

```markdown
# [Product Name] . Station Tracker

| Field | Value |
|---|---|
| Product name | [name] |
| ASIN | [ASIN, or "not live yet"] |
| Amazon URL | [URL or n/a] |
| Marketplace | [amazon.com / amazon.co.uk / ...] |
| Brand | [brand name] |
| Niche | [exact niche phrase, word for word] |
| Title confirmed | [yes (fetched) / yes (user paste)] |
| Reference photos source | [seller_photos / amazon_scraped (fallback)] |
| Registered | [YYYY-MM-DD] |

## Stations

| Station | Status | Artifact | Date | Notes |
|---|---|---|---|---|
| RESEARCH | in progress | research/ files | [date] | |
| BRIEF | pending | brief/creative-brief.md | | |
| INVENT | pending | reference/ + images/ + aplus/ + variations/ | | |
| INSPECT | pending | scorecards/ | | |
| PROVE | pending | tests/ | | |

Status values: pending / in progress / blocked / done.
A station is `done` only when its artifact exists on disk. Never before.

INVENT sub-status:
- Main image (/main-image): pending
- Secondary images (/secondary-images): pending
- A+ (/aplus): pending
- Variations (/variations): pending

INVENT is `done` only when all four sub-parts are done, or a sub-part is consciously skipped with a
reason (e.g. "Variations: n/a, single SKU"). "Variations: pending (Day 10)" is a lawful trailing
marker, not a block.

## Owner intel

### Known winners
- [verbatim from the user, or "none given: [their reason]"]

### Must include
- [verbatim from the user, or "none given: [their reason]"]

### Avoid
- [verbatim from the user, or "none given: [their reason]"]

## Blocked on

- Reviews file: top ~10 positive + ~10 critical reviews (save to research/)
- 3 to 5 same-niche competitor ASINs/URLs or full gallery screenshots (save to research/)
- Real product photos: all angles + hand-for-scale + label close-ups (save to reference/)
- OPTIONAL: Brand Registry ASIN-level demographics export (save to research/)
- OPTIONAL: Search Query Performance export, return reasons, keyword data (save to research/)

## Research gaps

- [item waived, in the user's own words] . cost: [what the analysis loses] . upgrade when: [what would close it]

## Log

- [YYYY-MM-DD] Product registered at the Front Gate.
```

The five research files:

```markdown
# research/insights.md
Derived by Wonka from: reviews.md + competitors.md + the listing, [YYYY-MM-DD]
## Table stakes
- [feature] . confirmation: [double: competitors show it + reviews demand it | single-source: competitors only / reviews only]
## Customer language and search words
- [word/phrase] (source: review quote / listing / seller keyword data) . modifier note: [what it implies for images]
## Pricing landscape
[price bands from the competitor listings; where this product sits: value, mid, premium. Mark `estimated` if prices were not visible]
## Customer demographics
source: brand_registry_export | estimated
[age bands, gender split; if estimated, every line labelled `estimated`, upgrade when real data arrives]
## Funnel diagnosis
Evidence available: [SQP export / public signals only / none]
[CTR leak = MAIN lever | CVR leak = gallery and A+ lever | no data, default MAIN first] . confidence: [measured / estimated]
Reasoning: [rank, velocity, star split, review themes, price position]
Return reasons mapped: [reason -> creative fix] | not creative: [reason -> packaging / operations]
## Corrections
- [YYYY-MM-DD] [what changed, what it replaced] (source: owner correction: "[their words]")
```

```markdown
# research/reviews.md
Built from: [N positive, M critical], review_source: [seller's own listing | competitor reviews],
reviews_confidence: [high | medium | low], [YYYY-MM-DD]
## Pain points (ranked)
- [pain] . [count] mentions
## Objections
## Delight moments
## Customer language worth using
- "[verbatim phrase]" (context)
## The expectation gap
[the complaint the listing's own images or numbers caused: verbatim quote, what the listing states,
what the buyer expected, the creative job it creates. Or: "No expectation gap found in this sample"]
RULE: review finding, never restated as a brand claim or on-image spec.
## Quiet gold
[a spec the product already has that answers a live complaint and appears in no image]
```

```markdown
# research/persona.md
source: brand_registry_export | estimated
## The buyer
[age band, gender split, buying this FOR (job to be done), top fear (from objections),
dream outcome (from delight moments). Fear and dream each anchored to a review line]
## Panel demographics (read by the Tasting Room)
age_dist: {"35-44": 0.5, "45-54": 0.3, "55-64": 0.2}
gender: {"female": 0.8, "male": 0.2}
income: {"middle income": 1.0}
notes: [one line on who this is]
(each set of shares sums to 1.0; label estimated where estimated)
## Display-age note for casting
Real age band: [X]. Aspirational display age for images: [computed per the skew].
The panel and the screener always use the REAL age.
## Corrections
- [YYYY-MM-DD] [what changed] (source: owner correction: "[their words]")
```

```markdown
# research/competitors.md
Built from: [C1..C5 ASINs/URLs or screenshot filenames], analyzed [YYYY-MM-DD]
## Roster
| # | Competitor | Same niche? | Seen via |
|---|---|---|---|
| C1 | [name/ASIN] | yes | live fetch / screenshots: [files] |
(dropped competitors listed with the reason; NOT SEEN gets no teardown)
## Per-competitor teardown
## Cross-competitor matrix
## TABLE STAKES (we must show these)
## WHITESPACE (nobody shows, our shot)
## THEIR BEST FRAME (exactly one: competitor, position, why it works, our match-then-beat move)
## Seen but banned (do not copy)
```

```markdown
# research/selling-points.md
Built from: insights.md + reviews.md + competitors.md + owner intel ([date])
| ID | Selling point | Source | Mapped to | Skipped because |
|---|---|---|---|---|
| SP1 | [point] | insights: table stake (double confirmation) | (brief fills) | |
## Conflicts flagged
## Corrections
```

## Golden Standards check

Before presenting, verify every line:
- [ ] Marketplace recorded, and the niche phrase confirmed by the user word for word.
- [ ] The listing title was READ BACK and confirmed (fetched or pasted) before any folder was created.
- [ ] The product folder exists on disk with all 8 subfolders, verified by listing it, not assumed.
- [ ] The shopping list went out as ONE message, and Phase 3 started only after an explicit go (or named, recorded waivers).
- [ ] Every competitor carries a `seen via` line; nothing was analyzed from memory; off-niche entries were dropped and replaced, never kept as "close enough"; at least 3 confirmed and seen.
- [ ] Every claim in the five files traces to the reviews, the listing, a gallery actually viewed, owner intel, or a labelled estimate. The trace audit ran and untraceable lines were deleted.
- [ ] Every table stake states its confirmation type: double or single-source.
- [ ] Reviews file states its source, its counts and its confidence, and the expectation-gap section is present (a finding, or an explicit "none found").
- [ ] Material and quality signals made it onto the checklist.
- [ ] Persona carries the panel demographics block with shares that sum to 1.0, plus its source label.
- [ ] The funnel diagnosis names its missing evidence FIRST, states its confidence, and names one lever.
- [ ] Exactly ONE best frame named with a concrete move; non-compliant tactics landed in "seen but banned".
- [ ] The checklist has IDs, sources, and an unfilled "Mapped to" column ready for the Brief Room.
- [ ] Owner intel recorded verbatim, or explicitly `none given` with the user's reason. Never invented.
- [ ] Every waiver and gap is in `## Research gaps` with its cost and what would close it.

## Wonka lines

Openers:
- "A new product at the Gate. Splendid. Papers, please: ASIN, marketplace, brand, niche."
- "Welcome to the Factory. Every great candy starts as a stranger at this gate."
- "The Research Room. Least glamorous, most important. Every flop I have ever made skipped this floor."

Closers:
- "Registered and researched. [N] selling points on the checklist, and every one will be accounted for."
- "Now we know what the shoppers know, what the rivals show, and where the leak in your funnel is. Next stop: the Reference Room."
- "One gap on this floor, written down and priced, and not a single invented fact. That is how a factory earns its trust."

On a gap:
- "I have no [item], so I have written that down instead of writing something prettier. Here is what it costs us, and here is what would fix it."

## Definition of Done

- `factory/Products/[product-slug]/` exists on disk with all 8 subfolders: `research/`, `brief/`, `reference/`, `images/`, `aplus/`, `variations/`, `scorecards/`, `tests/`.
- `status.md` exists in the TEMPLATE format with the identity table (marketplace, title confirmed, reference photos source), the stations table, Owner intel, Blocked on, Research gaps, and Log.
- All 5 research files exist with real content and their required sections: `research/insights.md` (table stakes with confirmation, customer language, pricing, demographics, funnel diagnosis), `research/reviews.md` (ranked pains, objections, delight, verbatim language, expectation-gap section), `research/persona.md` (buyer, panel demographics block, display-age note), `research/competitors.md` (roster with `seen via`, teardown, matrix, table stakes, whitespace, one best frame, seen but banned), `research/selling-points.md` (IDs, sources, empty Mapped to column). A waived input leaves an explicit `WAIVED` marker, never an empty pretend section.
- The competitor relevance and visibility check ran and its result is stated in `competitors.md`.
- The trace audit ran: nothing in the five files is untraceable.
- Every gap and waiver is recorded in `status.md` under `## Research gaps` with its cost.
- The user has seen the summary and been invited to correct it.
- RESEARCH is `done` in `status.md`.

## Update status.md

Set RESEARCH to `done` (or `blocked: [reason]`), list the five files as artifacts, clear delivered items from `Blocked on`, and add the Log lines:
`[date] Product registered at the Front Gate.`
`[date] Research done: [N] selling points, best frame = [CX pos N], funnel diagnosis = [CTR/CVR/no data, confidence], gaps = [count].`
Corrections and top-ups each get their own Log line as they happen, so a future session can see what the research learned after it was first written.

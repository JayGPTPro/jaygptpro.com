---
name: main-image
description: Run the MAIN image generation for the hero slot. The main image is chosen, not briefed. The three main-image controls (tactic, hang-tag text, packaging preference) are decided in the brief and confirmed with the owner, Genrupt generates many main candidates, and this room collects every candidate into images/ and supports the human pick against the brief's selection criteria. Slot 1 is protected and round-trips unchanged in every plan save. A gpt-image fallback, used only when Genrupt is down, may still author mains from the brief. Product only, no people, no overlay text, cost quoted and approved before the batch. Also produces the Round 2 challenger and any regeneration a scorecard or a tasting note orders. Use when the brief, the locked reference, and the brand kit are done and the user wants the hero image. Triggers: /main-image, "make the main image", "hero image", "generate the mains", "main image room", "round 2 challenger", "regenerate main-02".
---

# The Main Image Room

| Meta | Value |
|------|-------|
| Room | The Main Image Room |
| Station | INVENT (the main image is one of the four Invent sub-parts) |
| Taught | Day 5. Reused on Day 9 for the Round 2 challenger and for winner regenerations |
| Needs | brief/creative-brief.md (the MAIN section with the three main-image decisions answered and the selection criteria), 2-reference/reference-sheet.md (LOCKED, smoke test PASS), factory/Brand/brand-kit.md (branding preset + styleImage, built by /brand-kit), one working generation machine |
| Saves to | factory/Products/[product]/images/ (main-01.png .. main-NN.png) + images/batch-log.md |
| Typical cost | Genrupt: a few credits per candidate, quoted per batch off the live balance. Fallback: gpt-image API per call. ALWAYS estimated and approved before anything runs. |

## The contract this room lives under

**The main image is chosen, not briefed.** Genrupt owns the planning, the prompting, and the generation of the hero slot. Our side owns exactly three decisions, and nothing else touches slot 1:

1. **Tactic.** Which main-image strategy Genrupt runs (from the tactics the setup flow offers).
2. **Hang-tag text.** What, if anything, goes on a physical hang-tag. "None" is a real answer.
3. **Packaging preference.** How the packaging shows, per the options the setup flow exposes.

These three are decided in the creative brief and CONFIRMED with the owner before generation. **Never pick a tactic the owner has not answered for.** An unanswered control is a stop, not a default.

**Slot 1 is protected.** In every `save_listing_builder_plan_review`, slot 1 round-trips byte-for-byte unchanged: no contentBrief, no headerPhrases, no customInstructions, no slot referenceImages, ever. The hero is shaped only by the three controls, the locked reference, and the branding preset. Rules pasted as prose into the slot stop behaving like rules and start competing with Genrupt's own direction, and the big prohibitions are enforced system-side anyway.

Genrupt generates MANY main candidates from those controls. This room's job is to run that generation, collect ALL the candidates into `images/`, and then support the HUMAN choice against the selection criteria the brief wrote down. The human picks. This room never does.

## What this room does

The Main Image Room produces the single most important asset on the listing: the hero shot the shopper sees in search results, at the size of a postage stamp, in a row of competitors, for well under a second. It confirms the three main-image decisions from the brief with the owner, runs Genrupt's main-candidate generation, collects every candidate that comes off the machine, and lays them out beside the brief's selection criteria so the human can choose with clear eyes. Scope of THIS room is the MAIN image only. Secondary images, A+ modules, and variation imagery are generated in their own rooms (`/secondary-images`, `/aplus`, `/variations`). Nothing that comes out of this room is a winner; the shortlist the human picks goes to the Inspection Room next.

## What this room never does

- Never writes a brief, header phrase, custom instruction, or slot reference onto slot 1. The main is edited only through tactic, hang-tag text, and packaging preference.
- Never picks a tactic, hang-tag text, or packaging preference the owner has not answered for. Silence is not a default.
- Never picks the winner, scores, or ranks. The human picks; `/inspect` gates.
- Never edits an existing image. Removals, word swaps, and shortenings are `/fix`.
- Never invents a product fact. Every attribute comes from the Reference Sheet and the brief.
- Never spends a credit or a cent without an explicit go-ahead for that specific batch.
- Never presents output as final, approved, ready, or "the best one".
- Never drops a candidate silently. Every candidate Genrupt produces is collected, logged, and shown.

## Before you start

Check ALL FOUR preconditions. Open the files; do not take `status.md`'s word for them. Any miss = station **BLOCKED**, with the exact ask and a pointer.

1. `brief/creative-brief.md` exists and its MAIN section carries the three main-image decisions (tactic, hang-tag text, packaging preference) and the selection criteria the human choice will be judged against. Missing section: point to `/creative-brief`. Section present but a decision unanswered: the room does not guess, see the table below.
2. `2-reference/reference-sheet.md` exists and reads `Reference status: LOCKED` and `Smoke test: PASS`. An approved reference WITHOUT a passed smoke test does not count; the smoke test is the only proof the lock actually holds. Missing or unpassed: point to `/reference-sheet`.
3. `factory/Brand/brand-kit.md` exists, with the branding preset id and the styleImage that `/brand-kit` built. Style comes ONLY from there; this room never describes style, colors, or fonts in prose. Missing: point to `/brand-kit`.
4. A generation machine is alive: Genrupt MCP connected (Path A, primary) or an OpenAI key for the fallback (Path B). Never switch paths silently, and never assume a machine is alive because it was alive on the last run.

**"I don't have it" is a real answer, and most of the time the run proceeds.** What blocks is missing EVIDENCE and missing DECISIONS, never missing convenience.

| The owner says | What happens |
|---|---|
| "No Genrupt" | Path B fallback, with the weaker-fidelity warning said out loud, one concept generated and viewed before the rest. The run proceeds. |
| "No Genrupt and no OpenAI key" | Both machines down: the room is CLOSED. Say exactly what is missing, point to `guides/mcp-setup-guide.md`, record `blocked: no generation machine` in `status.md`, and stop. Never fake, never "describe" images instead. |
| The brief has no answered tactic | STOP. Present the tactics the setup flow actually offers, in the owner's language, and wait for the answer. Never pick one, never default, never infer from enthusiasm. Record the answer back into the brief. |
| "No hang-tag" / "no packaging preference" | Fine. "None" is a real answer for both. Record it and proceed. |
| "I can't afford the full batch" | Quote the smallest batch the tactic supports, run that, and name the trim in the batch log as a conscious cut. A named cut is fine; a silent one is not. |
| "Skip the smoke test, just go" | Refused. The lock and its smoke test are evidence, not paperwork, and skipping them is what turns one wrong reference into a whole wrong batch. Back to `/reference-sheet`. |
| No answer on the cost line | Nothing runs. Park the station as `in progress`, say what is waiting, and stop. |

## Process

1. **Read the MAIN section and confirm the three decisions.** Read the tactic, the hang-tag text, and the packaging preference from the brief and read them back to the owner in one line each. If any of the three is missing or marked open, stop and ask (see the table). The brief also carries the SELECTION CRITERIA: what a winning main must do for THIS product (the mechanism that beats the incumbent, the table stakes that must read at thumbnail size). Read those back too, because they are the yardstick of step 8. Confirmation of all three controls comes BEFORE any spend.

2. **The main-image laws. Non-negotiable, every product, every candidate.** These laws now serve two jobs: they are the FILTER every collected candidate is checked against before the human sees it (step 10), and they are the AUTHORING rules on the fallback path (step 6). On the Genrupt path they are never pasted into the slot as prose; the big prohibitions are enforced system-side, and a violation that comes off the machine anyway is a bug to report and a candidate to pull, not something to argue with in a brief.
   - **PRODUCT ONLY.** No people, no faces, no hands, no product-in-use. The hero shot is the product. Full stop.
   - **NO overlay text or graphics.** No headlines, callouts, arrows, or floating seals. The ONLY marks allowed are what physically exists on the product, its label or box, and the hang-tag the owner approved. Best Seller flags, star ratings, review counts, and award graphics are never allowed: Amazon draws its own on the search tile, and a drawn one is a fake badge.
   - **The product is the real product.** Real material, true proportions, and every part present and countable (a four tier machine shows all four tiers, steel reads as metal and not plastic), matching the locked reference exactly.
   - **Never promise what the product cannot deliver as sold.** This is the most expensive mistake in this room: an over-promising hero wins the click and buys the one-star review. If the research names a gap between what the category's pictures suggest and what buyers report actually happens, the winning candidate must show the buyer's reality, not the fantasy.
   - **No new product facts.** If an attribute is not in the Reference Sheet or the brief, it does not exist and must not be depicted.

3. **Quote the cost, then stop.** Read the live credit balance first (a free read, the same fuel gauge `/machines-check` uses) so the quote is real; if the connection does not expose a gauge, say "balance not available on this connection" rather than guessing a number. One line: "Main candidates on [path], tactic [name], estimated [credits/dollars], balance [X]. Proceed?" If the balance will not cover the batch, say the exact shortfall in that same line. No batch starts without a yes. The approval covers THIS batch only: retries, regenerations, and Round 2 each get their own line. Never spend first and quote after.

4. **Generate. Path A: Genrupt (primary).** Plan from the ASIN, answer the setup questions with the owner's confirmed three decisions, review the plan, edit only what our side owns, then generate the main slot. Operating rules, all mandatory, each one already paid for in burned batches:
   - **Slot 1 round-trips UNCHANGED in every plan save.** `save_listing_builder_plan_review` always carries the full slot array; slot 1 in that array is exactly what `get_listing_builder_plan_review` returned, byte for byte. The three controls are set through the setup flow's main-image questions, never through the slot.
   - **Always pass `modelId: "gpt_image_2"` explicitly on every generation call.** Never rely on the tool's default model; an unspecified call silently generates on a different engine with weaker text rendering.
   - **Edit the existing plan; never re-plan.** Re-running the planner wipes every slot edit. Fix through the plan-review/save path only.
   - **Style comes from the branding preset and the styleImage only** (from `factory/Brand/brand-kit.md`). Never restate colors, fonts, or aesthetics in any text field.
   - **Verify the approved reference asset id from `2-reference/reference-sheet.md` is attached** so the product lock is inherited. If you cannot confirm it is attached, do NOT generate: an unattached reference is a paid batch of somebody else's product.
   - **When regenerating a candidate, make sure the call is a fresh generation, not a cached result** (if the tool exposes an idempotency or request key, use a new one).
   - **Casting never applies here**, because mains never contain people. Avatars live in `/secondary-images` per the intake guide, and even there as structured fields, never prose.
   - **If the brief's winning mechanism cannot be expressed through the three controls, say so out loud.** Then either pick the nearest control combination WITH the owner, or run that one idea on the fallback path, and record which in the batch log. Never smuggle a strategy into the protected slot as prose.

5. **Collect ALL the candidates.** Genrupt produces many main candidates from one run; every one of them comes home. Poll `get_listing_builder_slot_results` until the batch settles, download every candidate, and save each to `images/` under the naming contract in step 7. No cherry-picking at collection time: a candidate you dislike is still a candidate, and the human may disagree with you. The count Genrupt reports planned is the count this room reconciles in step 9.

6. **Generate. Path B: gpt-image fallback. FALLBACK-ONLY BEHAVIOR.** This path exists for one situation: Genrupt is down or absent and the owner said proceed. On this path, and ONLY on this path, the room still AUTHORS mains from the brief, because there is no Genrupt planner to choose for us. This is the old way kept alive as a spare tire, and it is announced as such. Per concept:
   - Confirm the key: if `$OPENAI_API_KEY` is not set, load it from the `.env` in the Factory root before the first call. No key at all means the room is closed (see the table above).
   - Author one concept per distinct strategy in the brief's MAIN section, in the brief's order (concept 1 becomes the next free `main-NN`).
   - Attach the Reference Sheet's cleaned reference images from `2-reference/photos/` to the call.
   - Use the concept direction as the prompt, prepending the product spec from `2-reference/reference-sheet.md` (exact size, material, parts and their count, label text) so the model cannot drift. All the laws of step 2 are authoring rules here.
   - Say the honest warning up front: product fidelity holds less tightly here than on the locked path, so drift is likelier and inspection matters double.
   - Generate ONE concept first, VIEW it, and only continue if the product renders faithfully. If it does not, stop and tighten the reference rather than burning the batch.

7. **Save to `images/` under one flat naming contract.** Never overwrite, never delete, never renumber.
   - New candidates: `main-01.png` .. `main-NN.png`, numbered in the order they come off the machine (Genrupt path) or in the brief's strategy order (fallback path). Every later room and every later day refers to these images by filename, so the numbering is a promise: never renumber after the fact.
   - A REGENERATION of an existing candidate keeps its number and gains a suffix: `main-02-v2.png`, saved beside an untouched `main-02.png`. Keeping the number keeps candidate ids stable, which is what lets a round-over-round tasting comparison line up.
   - A NEW candidate that is not a re-bake of an existing one (the Round 2 challenger) takes the NEXT FREE number in the same sequence: `main-09.png`. There is no separate series.
   - Surgical edits are `/fix`'s work and land as complete set snapshots in `edits/vN/` (same filenames, the round in the folder name), never in `images/` and never by this room.

8. **Support the human choice.** This is the second half of the room's job and it is service, not judgment. Lay every law-passing candidate out for the owner side by side, with three things next to them: the brief's SELECTION CRITERIA restated in one short list, the incumbent read (what the current live main does and fails to do, from the brief), and a reminder that the shopper sees these at postage-stamp size in a row of rivals. Offer to show any candidate downscaled to thumbnail size on request. Answer questions about what each candidate does against the criteria, factually. Do NOT rank, do NOT recommend, do NOT say which one you would pick, and do NOT read a preference into the owner's silence. The owner names the shortlist (one or several) that advances. Record the picks and, in one line each, the owner's stated reason. If the owner asks "which would you choose", say that the pick is theirs by design, and offer the criteria comparison again.

9. **Handle failures out loud, and reconcile the count.** Every planned candidate ends in exactly one of three states: **generated**, **failed** (record the exact error), or **skipped** (record the reason, e.g. the owner's approved trim from the cost table). State the arithmetic before handing off: planned N = generated M + failed K + skipped S. If the numbers do not add up, the batch is not done. On a mid-batch tool error, retry once; generation resumes from saved slots, so what already landed is not paid for twice. If the machine is down for good, keep what landed, record the failure, and offer the fallback for the rest with its own cost line. A quietly shorter batch is the one thing that must never happen.

10. **Run the fidelity and law check on every collected candidate, then stop judging.** Open every file and look. This room checks four catastrophic classes only, each with a fixed action:
    - **(a) Not the product** (wrong part count, wrong material, wrong shape). ONE candidate drifted: pull it from the choice set, log it, and regenerate if the owner wants the slot refilled. ALL of them drifted: STOP, spend nothing more, and go back to `/reference-sheet` to re-lock with a fresh smoke test. On the Genrupt path a wholesale drift with the reference confirmed attached is also a bug to report, not a prompt to write.
    - **(b) A person, a face, or a hand.** Never enters the choice set. Pull and log it.
    - **(c) Overlay text, a drawn badge, a star rating** (anything beyond the product, its label, and the approved hang-tag). Never enters the choice set. Pull and log it.
    - **(d) A failed or blank render.** Log it with its error and retry or record per step 9.
    A pulled candidate stays on disk and in the log (never delete), it just does not get shown as a choice. Then STOP. Scores, the squint test, the compliance verdicts, and the deep ranking belong to `/inspect`, and duplicating them here just gives the owner two opinions to referee.

11. **Round 2: the challenger and the ordered regenerations (Day 9).** Two different jobs arrive here after a Tasting Round, and both must be traceable:
    - **The challenger.** ONE only, and optional. Build it only when the tasting notes handed you a thesis that Round 1 never tested. On the Genrupt path a challenger is a NEW generation under a DIFFERENT control setting, usually a different tactic, confirmed with the owner like any tactic; it is never a prose brief on slot 1. On the fallback path it may be authored from the thesis directly. It must be a different STRATEGY, not different decoration: two shades of the same idea split votes and teach nothing. It carries the honesty law from step 2 even harder, because a challenger born from a praise theme is exactly where over-promising creeps in. Write its provenance into the batch log: the theme it came from, how many tasters said it, and which control changed. Then hand it straight to `/inspect`; no image enters the Tasting Room ungated, not even one born from data. If no theme reached enough mentions to build on, SAY SO and skip it. An uncited challenger is a reroll wearing a costume.
    - **Regenerations ordered by `/fix` MODE B.** When a taster objection routes to REGENERATE (framing, size in frame, layout, anything spatial), it comes back here. On the Genrupt path that means a fresh generation under the same or an owner-adjusted control setting, with the objection recorded; on the fallback path the tighter sentence is carried in the prompt. Save it as `[winner]-v2.png` and record which note drove it. Same rule for scorecard-driven regenerations in MODE A.
    - **Otherwise the mains stay frozen.** Do not re-run this room just because a later room is open. After the batch passes the gate, a main changes only when a scorecard flag or a tasting note orders it.

12. **Log the batch** in `images/batch-log.md` (append, never overwrite) using the format below: the candidate map with the controls that produced it, the batch row, the reconciliation, the human shortlist with reasons, and any Round 2 provenance.

13. **Hand off.** Tell the owner: "The mains are out of the machines and your shortlist is named. Nothing here is approved yet. Next stop is the Inspection Room: run `/inspect` before you fall in love with anything." Then name the rest of the INVENT station: `/secondary-images` for the gallery, `/aplus` for the modules, `/variations` if the product sells variants. The full package goes to Inspection together.

## Output format

`factory/Products/[product]/images/` after a run:

```
images/
  main-01.png
  main-02.png
  ...
  main-08.png
  main-02-v2.png       (a regeneration, beside its untouched original)
  main-09.png          (Round 2 challenger, next free number)
  batch-log.md
```

`images/batch-log.md`:

```markdown
# Batch Log . [Product Name]

## Controls confirmed (before spend)
Tactic: [name, as the setup flow names it] (owner confirmed [date])
Hang-tag text: [text, or "none"]
Packaging preference: [choice, or "none"]

## Candidate map
| File | Path | Produced by | Law check | Result |
|---|---|---|---|---|
| main-01.png | genrupt | tactic [name] | pass | generated |
| main-02.png | genrupt | tactic [name] | pass | generated |
| main-03.png | genrupt | tactic [name] | PULLED: [law class + one line] | generated |
| main-04.png | genrupt | tactic [name] | . | failed: [exact error] |
| main-05.png | fallback | brief strategy "[variant name]" | pass | generated |

## Batches
| Date | Room | Path | Model | Candidates | Est. cost | Approved | Notes |
|---|---|---|---|---|---|---|---|
| [date] | main-image | genrupt / gpt_image_fallback | gpt_image_2 | 8 | [est] | yes ([date]) | planned 8 = generated 7 + failed 1 + skipped 0 |

## Human shortlist
- Picked: main-02, main-05. Owner's reasons: main-02 "[one line, owner's words]", main-05 "[one line]".
- Criteria they were judged against: [the brief's selection criteria, one line].

## Round 2 provenance (only when a challenger or an ordered regeneration ran)
- main-09.png . challenger. Theme: "[the taster theme, quoted]" ([N] tasters, Tasting Round 1 card). Control changed: [tactic X to tactic Y, owner confirmed]. Different strategy from the winner because: [one line].
- main-02-v2.png . regeneration ordered by /fix MODE B. Note that drove it: "[quoted note]" ([N] tasters). What changed: [control adjustment or fallback sentence].
```

## Golden Standards check

Before handing off, verify:
- [ ] All four preconditions were checked by opening the files, and any block was reported with its exact ask, not worked around.
- [ ] All three main-image decisions (tactic, hang-tag text, packaging preference) came from the brief and were confirmed with the owner BEFORE spending. No control was defaulted, guessed, or inferred.
- [ ] Slot 1 round-tripped unchanged in every plan save: zero brief text, zero headers, zero custom instructions, zero slot references on the main.
- [ ] Cost was quoted against the live balance in one line and explicitly approved before anything ran. Retries and Round 2 got their own approval.
- [ ] EVERY candidate Genrupt produced was collected, saved, and logged. None dropped silently, including the ones pulled by the law check.
- [ ] Every candidate shown to the owner is PRODUCT ONLY: no people, faces, or hands.
- [ ] No overlay text or graphics on any shown candidate, and no drawn badge, star rating, or review reference. Only the product, its label, and the approved hang-tag.
- [ ] Nothing shown over-promises what the product delivers as sold, and no product fact appears that is not in the Reference Sheet or the brief.
- [ ] Genrupt path: `modelId: "gpt_image_2"` on every call, plan edited not re-planned, reference asset id confirmed attached, style only via the branding preset and styleImage.
- [ ] Fallback path: announced as fallback, key confirmed, references from `2-reference/photos/` attached, product spec prepended, weaker-fidelity warning given, first concept viewed before the rest.
- [ ] Naming contract held: machine order (or brief order on fallback), `-v2` beside an untouched original for regenerations, next free number for the challenger, no overwrites, no renumbering.
- [ ] The reconciliation adds up (planned = generated + failed + skipped) and every failure carries its exact error, every skip its named reason.
- [ ] The human choice was supported, never made: criteria restated, candidates laid out, thumbnail view offered, no ranking or recommendation given, the owner's picks and reasons recorded.
- [ ] Round 2 only: the challenger cites its theme and mention count, changed a control rather than adding prose, and went to `/inspect` before any tasting.
- [ ] Batch log written with the confirmed controls, the candidate map, the batch row, the reconciliation, and the shortlist.
- [ ] The owner was pointed to the Inspection Room, and no image was called final, approved, ready, or best.

## Wonka lines

Openers:
- "The Main Image Room. One square inch of shelf, and the machines will offer you many ways to win it."
- "The hero shot is the product. Full stop. We set three dials, the machines do the rest, and YOU do the choosing."
- "Come in, come in. Today the factory bakes a whole tray of heroes, and you pick the one the shop window gets."
- "Money first, because this factory never spends silently. Here is the number. Say the word."

Closers:
- "A tray of contenders, out of the machines, every last one collected. Your shortlist is noted. Inspection Room, next."
- "Fresh mains, still warm. Whether your pick is THE main is a question for the shoppers, not for either of us."
- "I laid them out and held the yardstick. The choosing was yours, as it always is in this room."
- "A challenger born from what a hundred tasters told us, with its parentage written on it. Now let them judge their own child."

## Definition of Done

- The three main-image decisions are confirmed with the owner and recorded in the batch log before any spend.
- Every candidate the run produced is accounted for on disk: a collected file in `images/` named per the contract, or a recorded failure with its exact error, or a named conscious skip. Planned = generated + failed + skipped, stated.
- `images/batch-log.md` exists with the confirmed controls, the candidate map, path, model, count, approved cost, the reconciliation, and the human shortlist with the owner's reasons. Round 2 runs also carry their provenance lines.
- The fidelity and law check ran on every file, and no image with a person, overlay text, or a wrong product was shown as a choice.
- The human named the shortlist; this room recorded it without ranking or recommending.
- `status.md` updated per below.
- The owner was explicitly handed to `/inspect`, with `/secondary-images`, `/aplus`, and `/variations` named as the rest of the INVENT station, and no output was presented as final.

## Update status.md

In the INVENT sub-status block, set `Main image (/main-image): done` (or `in progress` if the batch is partial, waiting on the cost go-ahead, or waiting on the owner's shortlist, or `blocked: [precondition or unanswered control]`). Artifact `images/main-01..NN.png` + `images/batch-log.md`. Then check the whole INVENT sub-status block: when all four sub-parts (Main image, Secondary images, A+, Variations) are `done` or `n/a` with a reason (variations may be n/a or a lawful trailing marker), set the INVENT station row to `done`; otherwise leave it `in progress`. Log line: `[date] Main candidates generated: [M] of [N] planned on [path], tactic [name], cost approved [est], [K] failed, [S] skipped, [P] pulled by the law check. Owner shortlisted [files]. Awaiting inspection.` For a Round 2 run: `[date] Round 2 challenger main-[NN] generated from the "[theme]" tasting note ([N] tasters), control change [X to Y]. Inspected before tasting.` Name the remaining INVENT rooms as next steps, with INSPECT to follow once the full package exists.

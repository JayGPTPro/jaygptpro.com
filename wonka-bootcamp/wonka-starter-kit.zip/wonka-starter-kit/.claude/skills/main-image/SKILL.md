---
name: main-image
description: Generate 4 distinct MAIN image concepts from the creative brief's MAIN section, using Genrupt (primary) or gpt-image (fallback), product-only, no people, no overlay text, with cost approval before the batch. Use when the brief, the locked reference, and the brand kit are done and the user wants the hero image. Triggers: /main-image, "make the main image", "hero image", "generate the mains", "main image room", "round 2 main challenger".
---

# The Main Image Room

| Meta | Value |
|------|-------|
| Room | The Main Image Room |
| Station | INVENT (the main image is one of the four Invent sub-parts) |
| Needs | brief/creative-brief.md (the MAIN section), reference/reference-sheet.md (LOCKED, smoke test PASS), factory/Brand/brand-kit.md |
| Saves to | factory/Products/[product]/images/ (main-01.png .. main-04.png) |
| Typical cost | Genrupt: credits per image, batch of 4. Fallback: gpt-image API per call. ALWAYS estimated and approved before the batch. |

## What this room does

The Main Image Room produces the single most important asset on the listing: the hero shot the shopper sees in search results. It reads the MAIN section of the creative brief, which carries the distinct strategy variants, and generates 4 distinct concepts, one per strategy, against the locked reference and dressed in the brand kit. Scope of THIS room is the MAIN image only. Secondary images, A+ modules, and variation imagery are generated in their own rooms (`/secondary-images`, `/aplus`, `/variations`) off the same brief and the same locked reference. Nothing that comes out of this room is final; everything goes to the Inspection Room next.

## Before you start

Check ALL three preconditions. Any miss = station **BLOCKED**, with a pointer:
1. `brief/creative-brief.md` exists with a MAIN section and is marked done in `status.md`. Missing: point to `/creative-brief`. Sub-check: if the brief contains "pending brand kit", resolve those fields from `factory/Brand/brand-kit.md` before generating; if the brand kit is missing too, the station is BLOCKED.
2. `reference/reference-sheet.md` exists with `Reference status: LOCKED` and `Smoke test: PASS`. An approved reference WITHOUT a passed smoke test does not count; the smoke test is the only proof the lock actually holds. Missing or unpassed: point to `/reference-sheet`.
3. `factory/Brand/brand-kit.md` exists. Missing: point to `/brand-kit`.
Also confirm which generation path applies: Genrupt MCP connected (primary) or gpt-image fallback. If Genrupt is expected but not responding, say so and offer the fallback explicitly; never switch paths silently.

## Process

1. **Load the brief's MAIN section.** Read the distinct main-image strategy variants (angle, prop story, composition, background family). The batch plan is 4 distinct concepts, one per strategy; if the brief carries fewer than 4 strategies, generate one concept per strategy and say so rather than padding with near-duplicates.

2. **Enforce the main-image hard rules in every concept brief.** These are non-negotiable, every product, every batch:
   - **PRODUCT ONLY.** No people, no faces, no hands, no product-in-use. The hero shot is the product. Full stop.
   - **NO overlay text or graphics.** No headlines, callouts, badges, arrows, or floating seals. The ONLY text or marks allowed are what physically exists on the product and its label. Real certifications appear only as they appear on the physical label, which the reference shows.
   - The product must read as its real material and true proportions, matching the locked reference exactly.
   - Clean background per the brief; props allowed only if the brief's strategy calls for them and they never obscure the product.

3. **Estimate cost and get a go-ahead.** One line: "4 main concepts on [path], estimated [credits/dollars]. Proceed?" No batch starts without a yes. If the user wants to trim, generate the brief's two highest-priority strategies first.

4. **Generate. Path A: Genrupt (primary).** Use the Genrupt MCP listing builder flow: plan from the ASIN, review the plan, EDIT the plan to match the brief, then generate. Operating rules, all mandatory, each one paid for in burned batches:
   - **Always pass `modelId: "gpt_image_2"` explicitly on every generation call.** Never rely on the tool's default model; an unspecified call silently generates on a different engine with weaker text rendering.
   - **Edit the existing plan; never re-plan.** Re-running the planner wipes every slot edit. Fix slots through the plan-review/save path only.
   - **When regenerating a concept, make sure the tool call is a fresh generation, not a cached result** (if the tool exposes an idempotency or request key, use a new one).
   - **Never instruct the model to render a third-party logo or award badge.** The content checker fails the whole image, and a floating badge on a main is a policy violation anyway.
   - Verify the approved reference asset id from `reference/reference-sheet.md` is attached to the generation so the product lock is inherited.
   - Restate per concept: product-only, no overlay text or graphics, brand-accurate label, and the brief's avoid list, carried verbatim into each slot brief.
   (Casting-in-brief-text rules do not apply here because mains never contain people; they live in `/secondary-images`.)

5. **Generate. Path B: gpt-image fallback (no Genrupt).** Per concept:
   - Attach the reference sheet's cleaned reference images to the call.
   - Use the concept brief as the prompt, prepending the product spec from `reference/reference-sheet.md` (exact size, material, cap, label text) so the model cannot drift.
   - Expect weaker product fidelity than the locked Genrupt path, and say so to the user up front. Inspect each output harder: compare the product in every image to the reference before accepting it.
   - Generate ONE concept first, view it, and only continue to the other three if the product renders faithfully; if it does not, stop and tighten the reference rather than burning the batch.

6. **Save everything to `images/`** as `main-01.png`, `main-02.png`, `main-03.png`, `main-04.png`, matching the brief's strategy order. Never overwrite; a regenerated concept saves as `main-02-v2.png` beside the first attempt.

7. **Round 2 (Episode 10 challengers).** When generating a data-driven challenger off the tasting notes from a completed Tasting Round, name the files `main-r2-01.png`, `main-r2-02.png`, and so on, and CITE the comment insight that drove each challenger in the batch log (for example: "r2-01: shoppers said the machine looked small, pushed product to 85% of frame"). A round-2 challenger without a cited insight is just a reroll; do not generate one.

8. **Log the batch** in `images/batch-log.md`: date, path, model, image count, cost estimate vs approved, any failures with their error, and round-2 insight citations if applicable.

9. **Do a first-pass sanity look, then hand off.** Open the images and check only for catastrophic misses (wrong product, failed generation, sneaked-in text or people). Do NOT present them as results. Tell the user: "The mains are out of the machines. Next stop is the Inspection Room: run /inspect before you fall in love with anything." NEVER present raw generations as final; that is the Inspection Room's whole reason to exist.

10. **Continue the INVENT station.** This room is one of four Invent sub-parts. Point the user onward: `/secondary-images` for the gallery, `/aplus` for the modules, `/variations` if the product sells variants, then the full package goes to Inspection together.

## Output format

`factory/Products/[product]/images/` after a run:

```
images/
  main-01.png
  main-02.png
  main-03.png
  main-04.png
  main-r2-01.png       (round 2 only)
  batch-log.md
```

`images/batch-log.md`:

```markdown
# Batch Log . [Product Name]
| Date | Room | Path | Model | Images | Est. cost | Approved | Notes |
|---|---|---|---|---|---|---|---|
| [date] | main-image | genrupt / gpt_image_fallback | gpt_image_2 | 4 | [est] | yes ([date]) | [failures, retries, r2 insight citations] |
```

## Golden Standards check

Before handing off, verify:
- [ ] All three preconditions were checked BEFORE generating, and any block was reported, not worked around.
- [ ] Cost was estimated and explicitly approved before the batch.
- [ ] Every concept is PRODUCT ONLY: no people, faces, or hands anywhere in any main.
- [ ] No overlay text or graphics on any main; only what physically exists on the product and label.
- [ ] The 4 concepts are genuinely DISTINCT strategies from the brief, not four rerolls of one idea.
- [ ] Genrupt path: `modelId: "gpt_image_2"` passed on every call, plan edited not re-planned, no third-party logo render instructed, reference asset id attached.
- [ ] Fallback path: references attached, product spec prepended, weaker-fidelity warning given, first concept verified before the rest.
- [ ] Files saved as main-01..main-04 (or main-r2-XX with cited insights); no originals overwritten.
- [ ] Batch log written.
- [ ] The user was pointed to the Inspection Room, and no image was called final, approved, or ready.

## Wonka lines

Openers:
- "The Main Image Room. One square inch of shelf, four ways to win it."
- "The hero shot is the product. Full stop. Now, which of our four ideas earns the click?"
- "Come in, come in. Today we make the candy the whole shop window is built around."

Closers:
- "Four contenders, out of the machines. Nothing leaves this factory uninspected: Inspection Room, next."
- "Fresh mains, still warm. Whether one of them is THE main is a question for the shoppers, not for us."
- "Machines off, heroes in the tray. Bring your reading glasses to /inspect."

## Definition of Done

- Every MAIN strategy from the brief has one generated concept in `images/` as main-01..main-04 (or main-r2-XX with a cited insight), or a recorded failure with its error in the batch log.
- Batch log exists with path, model, count, and approved cost.
- The user was explicitly handed to `/inspect`, with `/secondary-images`, `/aplus`, and `/variations` named as the rest of the INVENT station; no output was presented as final.

## Update status.md

In the INVENT sub-status block, set `Main image (/main-image): done` (or `in progress` if the batch is partial, or `blocked: [precondition]`). Artifact `images/main-01..04.png` + `images/batch-log.md`. Then check the whole INVENT sub-status block: when all four sub-parts (Main image, Secondary images, A+, Variations) are `done` or `n/a` with a reason (variations may be n/a), set the INVENT station row to `done`; otherwise leave it `in progress`. Log line: `[date] Main image concepts generated: [N] on [path], cost approved [est]. Awaiting inspection.` Name the remaining INVENT rooms as next steps, with INSPECT to follow once the full package exists.

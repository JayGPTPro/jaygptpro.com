---
name: main-image
description: Generate the MAIN image concepts from the creative brief's MAIN section, one per test hypothesis, using Genrupt (primary) or gpt-image (fallback). Product only, no people, no overlay text, cost quoted and approved before the batch. Also produces the Round 2 challenger and any regeneration a scorecard or a tasting note orders. Use when the brief, the locked reference, and the brand kit are done and the user wants the hero image. Triggers: /main-image, "make the main image", "hero image", "generate the mains", "main image room", "round 2 challenger", "regenerate main-02".
---

# The Main Image Room

| Meta | Value |
|------|-------|
| Room | The Main Image Room |
| Station | INVENT (the main image is one of the four Invent sub-parts) |
| Taught | Day 5. Reused on Day 9 for the Round 2 challenger and for winner regenerations |
| Needs | brief/creative-brief.md (the MAIN section), reference/reference-sheet.md (LOCKED, smoke test PASS), factory/Brand/brand-kit.md, one working generation machine |
| Saves to | factory/Products/[product]/images/ (main-01.png .. main-NN.png) + images/batch-log.md |
| Typical cost | Genrupt: a few credits per image, quoted per batch off the live balance. Fallback: gpt-image API per call. ALWAYS estimated and approved before anything runs. |

## What this room does

The Main Image Room produces the single most important asset on the listing: the hero shot the shopper sees in search results, at the size of a postage stamp, in a row of competitors, for well under a second. It reads the MAIN section of the creative brief, which carries the distinct strategy variants, and generates one concept per strategy against the locked reference and the brand kit. Scope of THIS room is the MAIN image only. Secondary images, A+ modules, and variation imagery are generated in their own rooms (`/secondary-images`, `/aplus`, `/variations`) off the same brief and the same locked reference. Nothing that comes out of this room is a candidate; it is output. Everything goes to the Inspection Room next.

## What this room never does

- Never picks a winner, scores, or ranks. That is `/inspect`, and after it the human.
- Never edits an existing image. Removals, word swaps, and shortenings are `/fix`.
- Never invents a product fact. Every attribute comes from the Reference Sheet and the brief.
- Never spends a credit or a cent without an explicit go-ahead for that specific batch.
- Never presents output as final, approved, ready, or "the best one".

## Before you start

Check ALL FOUR preconditions. Open the files; do not take `status.md`'s word for them. Any miss = station **BLOCKED**, with the exact ask and a pointer.

1. `brief/creative-brief.md` exists and has a MAIN section with named strategy variants. Missing: point to `/creative-brief`. Sub-check: if the brief contains "pending brand kit", resolve those fields from `factory/Brand/brand-kit.md` before generating; if the brand kit is missing too, the station is BLOCKED.
2. `reference/reference-sheet.md` exists and reads `Reference status: LOCKED` and `Smoke test: PASS`. An approved reference WITHOUT a passed smoke test does not count; the smoke test is the only proof the lock actually holds. Missing or unpassed: point to `/reference-sheet`.
3. `factory/Brand/brand-kit.md` exists. Missing: point to `/brand-kit`.
4. A generation machine is alive: Genrupt MCP connected (Path A, primary) or an OpenAI key for the fallback (Path B). Never switch paths silently, and never assume a machine is alive because it was alive on the last run.

**"I don't have it" is a real answer, and most of the time the run proceeds.** What blocks is missing EVIDENCE, never missing convenience.

| The owner says | What happens |
|---|---|
| "No Genrupt" | Path B fallback, with the weaker-fidelity warning said out loud, one concept generated and viewed before the rest. The run proceeds. |
| "No Genrupt and no OpenAI key" | Both machines down: the room is CLOSED. Say exactly what is missing, point to `guides/mcp-setup-guide.md`, record `blocked: no generation machine` in `status.md`, and stop. Never fake, never "describe" images instead. |
| "The brief only has 2 or 3 real strategies" | Generate one concept per real strategy. Three is the floor for a meaningful test. Below three, say plainly that the test will be under-covered and name what is missing. Never pad with rerolls of one idea. |
| "I can't afford four" | Generate the top N by the brief's ranked hypotheses. Name the dropped hypothesis in the batch log as a conscious skip. A named skip is fine; a silent one is not. |
| "Skip the smoke test, just go" | Refused. The lock and its smoke test are evidence, not paperwork, and skipping them is what turns one wrong reference into a whole wrong batch. Back to `/reference-sheet`. |
| No answer on the cost line | Nothing runs. Park the station as `in progress`, say what is waiting, and stop. |

## Process

1. **Load the MAIN section and fix the numbering contract BEFORE spending.** Read the strategy variants IN THE BRIEF'S ORDER. That order is the file numbering: brief variant 1 becomes `main-01.png`, variant 2 becomes `main-02.png`, and so on. Read them back to the owner in one line each, naming the bet every concept carries, and confirm the mapping. Every later room and every later day refers to these images by filename, so the mapping is a promise: never renumber after the fact.

2. **Check the bets are genuinely distinct.** Four rerolls of one idea is not a test, it is one guess with extra steps. Each concept must carry a different REASON to click. If two variants collapse into the same bet, say so and send it back to `/creative-brief` to sharpen the strategies. That is a brief problem and it cannot be fixed by generating more pictures.

3. **The main-image laws. Non-negotiable, every product, every concept.**
   - **PRODUCT ONLY.** No people, no faces, no hands, no product-in-use. The hero shot is the product. Full stop.
   - **NO overlay text or graphics.** No headlines, callouts, arrows, or floating seals. The ONLY marks allowed are what physically exists on the product and its label or box. A badge belongs on a main only because it is really printed there. Best Seller flags, star ratings, review counts, and award graphics are never drawn in: Amazon draws its own on the search tile, and a drawn one is a fake badge.
   - **The product is the real product.** Real material, true proportions, and every part present and countable (a four tier machine shows all four tiers, steel reads as metal and not plastic), matching the locked reference exactly.
   - **Never promise what the product cannot deliver as sold.** This is the most expensive mistake in this room: an over-promising hero wins the click and buys the one-star review. If the research names a gap between what the category's pictures suggest and what buyers report actually happens, the concept shows the buyer's reality, not the fantasy.
   - **No new product facts.** If an attribute is not in the Reference Sheet or the brief, it does not exist and it is not depicted.
   - Clean background per the brief. Props only where the strategy calls for them, and never obscuring the product.

4. **Quote the cost, then stop.** Read the live credit balance first (a free read, the same fuel gauge `/machines-check` uses) so the quote is real; if the connection does not expose a gauge, say "balance not available on this connection" rather than guessing a number. One line: "[N] main concepts on [path], estimated [credits/dollars], balance [X]. Proceed?" If the balance will not cover the batch, say the exact shortfall in that same line. No batch starts without a yes. The approval covers THIS batch only: retries, regenerations, and Round 2 each get their own line. Never spend first and quote after.

5. **Generate. Path A: Genrupt (primary).** Plan from the ASIN, review the plan, EDIT the plan to match the brief, then generate. Operating rules, all mandatory, each one already paid for in burned batches:
   - **Always pass `modelId: "gpt_image_2"` explicitly on every generation call.** Never rely on the tool's default model; an unspecified call silently generates on a different engine with weaker text rendering.
   - **Edit the existing plan; never re-plan.** Re-running the planner wipes every slot edit. Fix through the plan-review/save path only.
   - **When regenerating a concept, make sure the call is a fresh generation, not a cached result** (if the tool exposes an idempotency or request key, use a new one).
   - **Never instruct the model to render a third-party logo or award badge.** The content checker fails the whole image, and a floating badge on a main is a policy violation anyway.
   - **Verify the approved reference asset id from `reference/reference-sheet.md` is attached** so the product lock is inherited. If you cannot confirm it is attached, do NOT generate: an unattached reference is a paid batch of somebody else's product.
   - **The MAIN slot is PROTECTED: never write briefs, headers, or custom instructions on it.** The hero is shaped only by the main-image controls (strategy and tactic choice, hang-tag text, packaging preference), the locked reference, and the smoke test. Do not restate product-only or no-overlay text into the slot: rules pasted as text stop behaving like rules and start competing with your creative direction, and the big prohibitions are blocked system-side. A fidelity break with the controls set correctly is a bug to report, not something to argue with in prose.
   - **If a brief strategy cannot be expressed through those controls, say so out loud.** Then either use the nearest control combination or run that ONE concept on the fallback path, and record which in the batch log. Never smuggle a strategy into the protected slot as prose.
   - (Casting never applies here, because mains never contain people. Casting lives in `/secondary-images` via custom avatars.)

6. **Generate. Path B: gpt-image fallback (no Genrupt).** Per concept:
   - Confirm the key: if `$OPENAI_API_KEY` is not set, load it from the `.env` in the Factory root before the first call. No key at all means the room is closed (see the table above).
   - Attach the Reference Sheet's cleaned reference images to the call.
   - Use the concept brief as the prompt, prepending the product spec from `reference/reference-sheet.md` (exact size, material, parts and their count, label text) so the model cannot drift.
   - Say the honest warning up front: product fidelity holds less tightly here than on the locked path, so drift is likelier and inspection matters double.
   - Generate ONE concept first, VIEW it, and only continue if the product renders faithfully. If it does not, stop and tighten the reference rather than burning the batch.

7. **Save to `images/` under one flat naming contract.** Never overwrite, never delete, never renumber.
   - New concepts from the brief: `main-01.png` .. `main-NN.png`, in the brief's variant order.
   - A REGENERATION of an existing concept keeps its number and gains a suffix: `main-02-v2.png`, saved beside an untouched `main-02.png`. Keeping the number keeps candidate ids stable, which is what lets a round-over-round tasting comparison line up.
   - A NEW candidate that is not a re-bake of an existing one (the Round 2 challenger) takes the NEXT FREE number in the same sequence: `main-05.png`. There is no separate series.
   - Surgical edits (`_fixN`) are written by `/fix` and never by this room.

8. **Round 2: the challenger and the ordered regenerations (Day 9).** Two different jobs arrive here after a Tasting Round, and both must be traceable:
   - **The challenger.** ONE only, and optional. Build it only when the tasting notes handed you a thesis that Round 1 never tested. It must be a different STRATEGY, not different decoration: two shades of the same idea split votes and teach nothing. It carries the honesty law from step 3 even harder, because a challenger born from a praise theme is exactly where over-promising creeps in. Write its provenance into the batch log: the theme it came from and how many tasters said it. Then hand it straight to `/inspect`; no image enters the Tasting Room ungated, not even one born from data. If no theme reached enough mentions to build on, SAY SO and skip it. An uncited challenger is a reroll wearing a costume.
   - **Regenerations ordered by `/fix` MODE B.** When a taster objection routes to REGENERATE (framing, size in frame, layout, anything spatial), it comes back here with the exact sentence the tighter brief must carry. Generate it, save it as `[winner]-v2.png`, and record which note drove it. Same rule for scorecard-driven regenerations in MODE A.
   - **Otherwise the mains stay frozen.** Do not re-run this room just because a later room is open. After the batch passes the gate, a main changes only when a scorecard flag or a tasting note orders it.

9. **Handle failures out loud, and reconcile the count.** Every planned concept ends in exactly one of three states: **generated**, **failed** (record the exact error), or **skipped** (record the hypothesis name and the reason). State the arithmetic before handing off: planned N = generated M + failed K + skipped S. If the numbers do not add up, the batch is not done. On a mid-batch tool error, retry once; generation resumes from saved slots, so what already landed is not paid for twice. If the machine is down for good, keep what landed, record the failure, and offer the fallback for the rest with its own cost line. A quietly shorter batch is the one thing that must never happen.

10. **Run the fidelity and law check, then stop judging.** Open every generated file and look. This room checks four catastrophic classes only, each with a fixed action:
    - **(a) Not the product** (wrong part count, wrong material, wrong shape). ONE concept drifted: regenerate that one with a tighter sentence. ALL of them drifted: STOP, spend nothing more, and go back to `/reference-sheet` to re-lock with a fresh smoke test. This matters double when the reference was built from listing and review images instead of the owner's own photos.
    - **(b) A person, a face, or a hand.** Never advances as a main. Regenerate.
    - **(c) Overlay text, a drawn badge, a star rating.** Regenerate. Text born into a main is a regeneration, never an edit.
    - **(d) A failed or blank render.** Log it with its error and retry or record per step 9.
    Then STOP. Scores, the squint test, the compliance verdicts, and the ranking belong to `/inspect`, and duplicating them here just gives the owner two opinions to referee.

11. **Log the batch** in `images/batch-log.md` (append, never overwrite) using the format below: the concept-to-file map with each bet, the batch row, the reconciliation, and any Round 2 provenance.

12. **Hand off.** Tell the owner: "The mains are out of the machines. Nothing here is a candidate yet, it is output. Next stop is the Inspection Room: run `/inspect` before you fall in love with anything." Then name the rest of the INVENT station: `/secondary-images` for the gallery, `/aplus` for the modules, `/variations` if the product sells variants. The full package goes to Inspection together.

## Output format

`factory/Products/[product]/images/` after a run:

```
images/
  main-01.png
  main-02.png
  main-03.png
  main-04.png
  main-02-v2.png       (a regeneration, beside its untouched original)
  main-05.png          (Round 2 challenger, next free number)
  batch-log.md
```

`images/batch-log.md`:

```markdown
# Batch Log . [Product Name]

## Concept map (the file numbering contract, set from the brief's order)
| File | Strategy from the brief | The bet it carries | Result |
|---|---|---|---|
| main-01.png | [variant name] | [why somebody clicks this one] | generated |
| main-02.png | [variant name] | [bet] | generated |
| main-03.png | [variant name] | [bet] | failed: [exact error] |
| main-04.png | [variant name] | [bet] | skipped: [reason, named hypothesis] |

## Batches
| Date | Room | Path | Model | Images | Est. cost | Approved | Notes |
|---|---|---|---|---|---|---|---|
| [date] | main-image | genrupt / gpt_image_fallback | gpt_image_2 | 4 | [est] | yes ([date]) | planned 4 = generated 3 + failed 1 + skipped 0 |

## Round 2 provenance (only when a challenger or an ordered regeneration ran)
- main-05.png . challenger. Theme: "[the taster theme, quoted]" ([N] tasters, Tasting Round 1 card). Different strategy from the winner because: [one line].
- main-01-v2.png . regeneration ordered by /fix MODE B. Note that drove it: "[quoted note]" ([N] tasters). Tighter brief sentence carried: "[the exact sentence]".
```

## Golden Standards check

Before handing off, verify:
- [ ] All four preconditions were checked by opening the files, and any block was reported with its exact ask, not worked around.
- [ ] The concept-to-file mapping was confirmed with the owner BEFORE spending, and nothing was renumbered afterwards.
- [ ] The bets are genuinely distinct; no two concepts are the same idea in different clothes.
- [ ] Cost was quoted against the live balance in one line and explicitly approved before anything ran. Retries and Round 2 got their own approval.
- [ ] Every concept is PRODUCT ONLY: no people, faces, or hands anywhere in any main.
- [ ] No overlay text or graphics on any main, and no drawn badge, star rating, or review reference. Only what physically exists on the product and its label.
- [ ] Nothing depicted over-promises what the product delivers as sold, and no product fact appears that is not in the Reference Sheet or the brief.
- [ ] Genrupt path: `modelId: "gpt_image_2"` on every call, plan edited not re-planned, reference asset id confirmed attached, no third-party logo instructed, the MAIN slot round-tripped with zero brief text on it.
- [ ] Fallback path: key confirmed, references attached, product spec prepended, weaker-fidelity warning given, first concept viewed before the rest.
- [ ] Naming contract held: brief order for new concepts, `-v2` beside an untouched original for regenerations, next free number for the challenger, no overwrites.
- [ ] The reconciliation adds up (planned = generated + failed + skipped) and every failure carries its exact error, every skip its named reason.
- [ ] Round 2 only: the challenger cites its theme and mention count, is a different strategy, and went to `/inspect` before any tasting.
- [ ] The fidelity and law check ran on every file, with the all-drifted case escalated to a reference re-lock instead of more spend.
- [ ] Batch log written with the concept map, the batch row, and the reconciliation.
- [ ] The owner was pointed to the Inspection Room, and no image was called final, approved, ready, or best.

## Wonka lines

Openers:
- "The Main Image Room. One square inch of shelf, four ways to win it."
- "The hero shot is the product. Full stop. Now, which of our four bets earns the click?"
- "Come in, come in. Today we make the candy the whole shop window is built around."
- "Money first, because this factory never spends silently. Here is the number. Say the word."

Closers:
- "Four contenders, out of the machines. Nothing leaves this factory uninspected: Inspection Room, next."
- "Fresh mains, still warm. Whether one of them is THE main is a question for the shoppers, not for us."
- "Nothing on that screen is a candidate. It is output. The two words are not the same in this factory."
- "A challenger born from what a hundred tasters told us, with its parentage written on it. Now let them judge their own child."

## Definition of Done

- Every MAIN strategy from the brief is accounted for on disk: a generated file in `images/` named per the contract, or a recorded failure with its exact error, or a named conscious skip. Planned = generated + failed + skipped, stated.
- `images/batch-log.md` exists with the concept-to-file map, path, model, count, approved cost, and the reconciliation. Round 2 runs also carry their provenance lines.
- The fidelity and law check ran on every file, and no image with a person, overlay text, or a wrong product was handed on as a main.
- `status.md` updated per below.
- The owner was explicitly handed to `/inspect`, with `/secondary-images`, `/aplus`, and `/variations` named as the rest of the INVENT station, and no output was presented as final.

## Update status.md

In the INVENT sub-status block, set `Main image (/main-image): done` (or `in progress` if the batch is partial or waiting on the cost go-ahead, or `blocked: [precondition]`). Artifact `images/main-01..NN.png` + `images/batch-log.md`. Then check the whole INVENT sub-status block: when all four sub-parts (Main image, Secondary images, A+, Variations) are `done` or `n/a` with a reason (variations may be n/a or a lawful trailing marker), set the INVENT station row to `done`; otherwise leave it `in progress`. Log line: `[date] Main image concepts generated: [M] of [N] planned on [path], cost approved [est], [K] failed, [S] skipped. Files main-01..NN mapped to the brief's variant order. Awaiting inspection.` For a Round 2 run: `[date] Round 2 challenger main-[NN] generated from the "[theme]" tasting note ([N] tasters). Inspected before tasting.` Name the remaining INVENT rooms as next steps, with INSPECT to follow once the full package exists.

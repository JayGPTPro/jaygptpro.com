---
name: fix
description: Surgical image edits in the Fixing Room, in two modes. MODE A (pre-tasting, QA-driven) fixes the defects the Inspection Room flagged. MODE B (post-tasting, note-driven) reads the Tasting Card notes and refines the winning main image and the weakest gallery frame. Routes every item to edit or regenerate BEFORE touching anything, refuses fixes that break a house rule or fight the research, runs safe edits on the OpenAI gpt-image edit API for cents, always keeps the original, verifies side by side, re-inspects, and logs every edit and every routing decision. Triggers: /fix, "fix this image", "remove the badge", "shorten that text", "change the word", "edit the image", "refine the winner", "act on the tasting notes", or fix items coming from /inspect or /tasting-room.
---

# The Fixing Room

| Meta | Value |
|------|-------|
| Room | The Fixing Room |
| Station | INSPECT (fix leg, MODE A) and PROVE (post-tasting refinement, MODE B) |
| Taught | Day 5, MODE A, as the second half of the quality loop. MODE B on Day 9, off the Tasting Cards. Runs again whenever a scorecard or a Tasting Card names a defect |
| Needs | The image file and the exact defect (MODE A: the scorecard. MODE B: the Tasting Card notes), `OPENAI_API_KEY`, plus `reference/reference-sheet.md` and `brief/creative-brief.md` whenever a fix changes on-image text |
| Saves to | the asset's own folder: `factory/Products/[product]/images/`, `aplus/`, or `variations/` (as `[name]_fixN.png`, original kept) + `fixes-log.md` in that same folder |
| Typical cost | Cents per edit, roughly $0.02 to $0.10 at low quality. Every edit is counted, logged, and quoted before it runs. |

## What this room does

Some defects cost cents to fix. Others need a whole new bake. This room decides which is which FIRST, then performs only the safe surgical edits: one precise change at a time on the direct OpenAI image edit API, the original always preserved, every result verified against it and re-inspected before it counts. Anything that needs regeneration goes back to its generation room (`/main-image`, `/secondary-images`, `/aplus`, `/variations`) with a tighter brief, never through here. The room services every image class: mains, secondaries, A+ module images, and variation imagery. A fix always saves beside its original, in that asset's own folder.

The Fixing Room runs in TWO modes, and this is a core promise of the bootcamp: creative does not stop at "generated", it improves with evidence.

- **MODE A . pre-tasting, QA-driven (Day 5).** Fix the specific defects the Inspection Room flagged, so only gate-passing candidates ever reach the Tasting Room. MODE A removes flaws.
- **MODE B . post-tasting, note-driven (Day 9).** After a Tasting Round, read the Tasting Cards and refine TWO targets: the winning MAIN image, from the main race Card's friction themes, and the WEAKEST GALLERY FRAME, from the gallery race Card's frame-by-frame layer. Optionally hand `/main-image` one challenger brief that answers the single biggest objection, for Tasting Round 2. MODE B chases conversion.

Both modes use the same routing table, the same refusal gate, the same edit API, the same keep-the-original discipline, and the same verification. The only difference is where the fix list comes from: the scorecard, or the Tasting Card notes.

## What this room never does

- **Never regenerates.** A regenerate-class defect leaves this room as a written brief instruction, not an edit.
- **Never edits the incumbent.** The live Amazon image is the benchmark to beat and it belongs to another seller. It is never an edit base and never a generation reference.
- **Never overwrites, renames, or deletes an original.** The owner prunes their own files.
- **Never puts a word on an image that is not traceable** to the Reference Sheet, the brief, or the live listing. A fix is the easiest place in the whole factory to invent a product fact. It does not happen here.
- **Never spends without one approved cost line**, single edit or batch.
- **Never edits an image it has not opened with Read**, and never logs a fix as SUCCESS it has not opened again afterwards.
- **Never presents a failed, unverified, or un-re-inspected fix as a candidate.**

## Before you start

- **State the mode out loud.** MODE A if the list comes from an Inspection Room scorecard. MODE B if it comes from a completed Tasting Round. It changes only where the list comes from, never how edits run.
- **MODE B: read the Cards first.** Open the latest `tests/tasting-r[N]-[date]/tasting-card.md` (both Cards if two races ran), and confirm from the verdict band which file WON the main race and which frame the frame-by-frame layer named weakest. Refinement targets the winner and the weakest frame. It never targets losing candidates.
- **Confirm the exact target files exist**, in their asset folder, and open each one with Read so you can see the defect yourself. Echo the list back in one line before doing anything.
- **Confirm the key.** If `$OPENAI_API_KEY` is not set, load it from the Factory root `.env` first: `export OPENAI_API_KEY=$(grep '^OPENAI_API_KEY=' .env | cut -d= -f2)`.
- **Get one sentence for the defect and one for the desired result.** "Make it better" is not a fix order. Ask for the specific change.
- **Paid-edit policy.** Build the WHOLE list first, present it with ONE total cost line, get ONE go-ahead, then run it all. Never one ping per item, and never a silent cent.

### "I don't have it" is a real answer

Missing convenience never stops this room. Missing EVIDENCE stops only the item it belongs to. Record every gap in the log and proceed.

| The owner says | What happens |
|---|---|
| "No scorecard, but this badge has to go" | Proceed on the stated defect. Log `list source: owner, no scorecard on file`. |
| "No Tasting Card, but they said the text was busy" (MODE B) | Proceed on the stated notes. Log `notes source: owner recollection, no Card on file`, and say plainly that without mention counts the theme rule cannot be applied, so the change is a lean and not an instruction. |
| "No reference sheet / no brief" and a fix changes on-image text | Do not invent. Read the new wording back and get the owner to confirm it is literally true of the product. Log `wording verified by owner, no reference sheet on file`. |
| "I deleted the original" | The edit can still run, but say plainly that the side-by-side check is degraded. Verify against the scorecard's literal description instead and log `no original on file, verification degraded`. |
| "No OpenAI key" | Paid edits are closed, the ROOM IS NOT. Run the whole list through the refusal gate and the routing table, log every decision, hand the regenerate items to their rooms, and park the edit items as `blocked: no key` with a pointer to `guides/mcp-setup-guide.md`. |
| No answer on the cost line | Nothing paid runs. Park the station `in-progress`, say exactly what is waiting, and stop. |
| "Just fix all of them, do not ask" | The routing and the refusal gate still run. Present the list with the one cost line anyway. One go-ahead, then everything at once. |

## The refusal gate. Two fixes Wonka will not run

Apply this to every item BEFORE routing. A refusal is a result, not a failure: it gets logged with its reason and its reroute, and the owner may override in writing.

1. **A fix that breaks a house rule.** The commonest one by far: an objection about the MAIN image that can only be answered with text or a graphic. A main carries no overlay text, no callouts, no badges, no arrows, ever. Also refused everywhere: adding a star rating or review reference, a drawn award or Best Seller badge, a third-party logo, a flag graphic, an invented percentage, or a medical claim. **Reroute, do not build:** the message goes to a secondary frame where it is allowed to live, and the gallery often already has that frame. Example: tasters say they cannot tell how big the fountain is. No "8 x 8 x 18 IN" callout may be added to the main. It goes to the gallery scale frame.
2. **A fix that fights the research.** The panel is cheap and fast, which is exactly why it never quietly overrules expensive real evidence like reviews, returns, and the selling-points checklist. Example: tasters ask for a bigger, fuller chocolate cascade, but the reviews report that a fill at the listed capacity gives a thin flow. Answering that objection sells a promise the product cannot keep as sold, which is the complaint that drives its one-star reviews. Record it in the test file, do not execute it. The owner can override; the reason goes in the log.

## Process

1. **Write the instruction list before any surgery.** Orders first, scalpel second. One line per item: what changes, which asset it belongs to, and the evidence that justifies it.
   - **MODE A:** each item cites the scorecard flag (the dimension and the element).
   - **MODE B:** each item cites the exact tasting note and the number of tasters who raised it. **A theme needs repetition: one taster is noise, three or more is an instruction.** Below three mentions, record it as noise and do not act. **If no theme reaches three, MODE B runs no edits at all**: say so, log `no qualifying theme, no refinement`, and let Round 2 run as a confirmation against the challenger or the next best gate-passed candidate. Changing a winner without a reason is how winners get broken.
   - A good instruction: "Remove the two smallest callouts. Justified by: five tasters said the text was busy." A bad one: "Make it pop more." Strike anything that reads like taste smuggled in as data.

2. **Run the refusal gate** (above) on every item. Refused items get their reason and their reroute written down now, and they never reach the routing table.

3. **ROUTE EVERY SURVIVING ITEM. This decision is the room.**

   | Defect | Route |
   |---|---|
   | Shorten or remove text | SAFE AS EDIT |
   | Remove an element (badge, card, stray object) | SAFE AS EDIT |
   | Swap a word or a claim for a shorter, truer one | SAFE AS EDIT |
   | Recolor an accent | SAFE AS EDIT |
   | Enlarge text | REGENERATE |
   | Move or resize anything | REGENERATE |
   | Change layout or composition | REGENERATE |
   | Fix casting, a face, or a person | REGENERATE |
   | Fix the product itself (wrong part count, wrong material, wrong label) | REGENERATE |

   The reason is mechanical: the edit endpoint re-renders the whole frame, so removal and substitution are reliable, and anything spatial comes back garbled or subtly wrong. **For every REGENERATE item: do not edit it.** Send it to its generation room with the exact sentence the tighter brief must contain, for example "The machine has FOUR tiers. All four must be visible and countable." Record the routing decision in the log even when no edit runs. An image needing three or more edits is a regeneration wearing a disguise: say so and recommend the ovens.

4. **Present the plan and get ONE go-ahead. Nothing paid runs before this.**

   ```
   Fix plan . [product] . MODE [A/B]
   1. [file]  EDIT       [change]            [evidence]   ~$0.0X
   2. [file]  EDIT       [change]            [evidence]   ~$0.0X
   3. [file]  REGENERATE [change]            [evidence]   no charge here
   4. [file]  REFUSED    [change]            [rule broken / research it contradicts] -> [reroute]
   Total for [n] edits: ~$0.XX. One yes and I run the lot.
   ```

5. **Write the surgical prompt.** It names ONE change and freezes everything else. One change per API call.
   - "Remove the red BEST SELLER ribbon from the top left corner. Change nothing else in the image."
   - "Change the text 'HOLDS 4 LBS' to 'HOLDS 32 OZ'. Keep the exact same font, size, color, and position. Change nothing else."
   - **Any text a fix introduces must be true and sourced.** Check the new wording against the Reference Sheet, the brief, or the live listing, and write that source into the log. A shorter lie is still a lie.

6. **Run the edit on the OpenAI images.edit endpoint directly**, low quality unless the owner asks for higher, using the newest gpt-image model on the account (as of mid 2026, `gpt-image-2`). Run from the kit root with full paths:

   ```bash
   curl -s https://api.openai.com/v1/images/edits \
     -H "Authorization: Bearer $OPENAI_API_KEY" \
     -F model="gpt-image-2" \
     -F image="@factory/Products/[product]/[asset-folder]/[name].png" \
     -F prompt="[the surgical prompt]" \
     -F quality="low" \
   | python3 -c '
   import sys, json, base64, pathlib
   r = json.load(sys.stdin)
   if "error" in r:
       sys.exit("EDIT FAILED, nothing written: " + str(r["error"].get("message", r["error"])))
   out = pathlib.Path(sys.argv[1])
   out.write_bytes(base64.b64decode(r["data"][0]["b64_json"]))
   print("wrote", out, out.stat().st_size, "bytes")
   ' "factory/Products/[product]/[asset-folder]/[name]_fix1.png"
   ```

   The guard matters: the API error is checked BEFORE the output file is opened, so a refused or failed call leaves no file at all instead of an empty one pretending to be a fix. **If the "wrote ... bytes" line did not print, no image exists.** Never log that item as anything but FAILED.

7. **Name and save. The original is sacred.** Save as `[name]_fix1.png` beside the untouched original, then `_fix2`, `_fix3` for later rounds. Chain later edits off the LATEST fix file and keep incrementing the same counter on the base name. Never overwrite, never rename, never move the original. If an edit FAILS verification, rename that output to `[name]_fixN-rejected.png` so no later room can mistake it for a candidate, and take the next number for the retry.

8. **Verify side by side, against the true original.** Open the original AND the new file with Read and compare deliberately. For a `_fix2` or later, open the immediate parent AND the original, because each re-render drifts a little and the drift compounds where a single-step check cannot see it. Check four things:
   - (a) the requested change actually happened,
   - (b) every other piece of text still reads exactly as before, transcribed word for word, not glanced at,
   - (c) the product is untouched: label, material, colors, and part count (a four tier machine still shows four tiers),
   - (d) nothing new appeared anywhere in the frame.
   Anything else changed means the edit FAILED. Rename it rejected, log it, and either retry ONCE with a tighter prompt or route it to regeneration. **Two failed attempts on the same defect is a regeneration, not a third try.**

9. **Re-inspect mechanically. Nothing is fixed because it feels fixed.** Write a real 160px copy of the fixed file to `scorecards/squint/` and READ that copy, then re-run the compliance gate and the six scores per the Inspection Room. A fix to a gallery frame also re-runs the listing set-level checks, because a change to one frame can duplicate another frame's message.

   ```bash
   mkdir -p "factory/Products/[product]/scorecards/squint"
   sips --resampleWidth 160 "factory/Products/[product]/[asset-folder]/[name]_fix1.png" --out "factory/Products/[product]/scorecards/squint/[name]_fix1-160.png"   # macOS
   magick "[in].png" -resize 160x "[out]-160.png"                                                                                                              # Windows / ImageMagick
   python3 -c "from PIL import Image; im=Image.open('[in].png'); im.resize((160, round(im.height*160/im.width))).save('[out]-160.png')"                         # anywhere with Pillow
   ```

   A fix that passes replaces its parent in the slot ranking. Update the current scorecard. A fix that fails the gate is not a fix.

10. **Log every item** in the asset folder's `fixes-log.md` (`images/`, `aplus/`, or `variations/`; create it on first use). Append, never overwrite. Every item gets a line: edits, regenerate routings, refusals, and blocked items alike.

11. **Hand off.**
    - **MODE A:** back to `/inspect` for the updated scorecard, then the human picks from gate-passed candidates only.
    - **MODE B:** the refined winner and the refined frame go back to `/tasting-room` for Round 2 with `compare_to` set. **The refined winner keeps its Round 1 candidate id in the Round 2 config**, even though the filename now carries `_fixN`. Change the id and the round-over-round delta, which is the only number that says whether the fix worked, cannot line up.

## Output format

`[asset-folder]/fixes-log.md`, one entry per item, appended:

```markdown
## [YYYY-MM-DD HH:MM] [name].png -> [name]_fixN.png
- Mode: [A: pre-tasting QA-driven / B: post-tasting note-driven]
- Target: [the flagged image / the main race WINNER / the weakest gallery frame]
- Defect or request: [what was wrong or wanted]
- Evidence: [MODE A: scorecard flag, dimension and element / MODE B: the exact note, verbatim, and the taster count]
- Route: [EDIT / REGENERATE, sent to /[room] with the exact brief sentence / REFUSED: which rule or which research finding, and where it was rerouted / BLOCKED: what is missing]
- Prompt: "[the exact surgical prompt]"
- New wording source: [Reference Sheet / brief / live listing / owner-confirmed. n-a if no text changed]
- Result: [SUCCESS, [n] bytes written / FAILED: what else broke -> renamed _fixN-rejected]
- Side-by-side check: [change OK, other text transcribed and intact, product and part count intact, nothing new]
- Re-inspection: squint [PASS/FAIL] at 160px, compliance [PASS/FAIL], scores [summary]
- Cost: ~$[0.0X]
- Running total this product: ~$[X.XX] across [n] edits
```

## Golden Standards check

Before presenting, verify:
- [ ] The mode is stated. MODE B targeted the winning main and the weakest gallery frame, never a loser, and each edit names the note and the taster count that drove it.
- [ ] The three-mention rule was applied in MODE B, and a run with no qualifying theme made NO edits and said so.
- [ ] The refusal gate ran on every item. Every refusal names the rule it would break or the research it contradicts, plus where the message was rerouted.
- [ ] The routing table was applied BEFORE any edit. No REGENERATE-class defect was pushed through the edit API, and every regenerate item left with the exact sentence its tighter brief must contain.
- [ ] Every edit prompt names one change and ends with an explicit "change nothing else".
- [ ] Every word a fix put on an image is true and its source is named in the log.
- [ ] The full list was presented with ONE total cost line and ONE go-ahead came back BEFORE any paid edit ran.
- [ ] Every original file still exists, untouched, and every fix sits beside it as `_fixN`. Failed fixes are renamed `_fixN-rejected` so no later room can pick them.
- [ ] Original and fix were both opened, other on-image text was transcribed and confirmed, and the product part count was counted, not assumed.
- [ ] Every fixed image has a 160px squint copy on disk and passed the compliance gate. No full-size legibility judgments.
- [ ] Every item is in `fixes-log.md`: edits, routings, refusals, and blocked items.
- [ ] All output is English with zero em or en dashes.

## Troubleshooting

- **"wrote ... bytes" never printed:** no file was written. Read the error the guard printed. Nothing is logged as SUCCESS.
- **A verification or organization error from the API:** the OpenAI organization needs its one-time verification at platform.openai.com. See `guides/mcp-setup-guide.md`. The room parks as blocked, the routing still runs.
- **The API refuses the prompt on content policy:** almost always a face, a person, or a third-party logo in the instruction. Rewrite the prompt to name only the region and the change, or route it to regeneration.
- **The fix landed but something across the frame broke:** that defect was regenerate territory. Rename the output rejected, keep the original, and send it to the ovens with a tighter brief.
- **`sips` not found (Windows):** use the ImageMagick or Pillow line in step 9. Missing Pillow: `python3 -m pip install pillow`.
- **The same defect failed twice:** stop editing. Two failures is the routing table telling you it was never an edit.

## Wonka lines

Openers:
- "To the Fixing Room. Small tools, steady hands, and absolutely no improvising."
- "One flaw, one scalpel. We do not repaint the whole candy to fix a smudge."
- "Bring the patient in. And bring the original. We never operate without it."

Closers:
- "Fixed, verified, and the original sleeps safely beside it. Back to the Inspection belt."
- "Two cents of surgery and the candy is whole. I do enjoy a bargain."
- "That one needs the ovens, not the scalpel. Off to the generation rooms with a stricter brief."
- "No. Not on a main image, not for anyone. The message is welcome. It moves to the gallery, where it is legal."
- "A hundred tasters asked for a lie, and a hundred reviewers already paid for it. Noted, and refused."
- "The tasters told us what to sharpen, and we sharpened exactly that. Now let them taste it again."

## Definition of Done

A run is done in one of two lawful shapes, and both end with the log on disk.

**Shape one, edits ran:**
- Every fixed image exists as `[name]_fixN.png` beside its untouched original, and every failed attempt is renamed `_fixN-rejected`.
- Every fix was verified side by side against the true original and re-inspected, with its 160px squint copy on disk.
- `fixes-log.md` holds a complete entry per item, including the running cost total.

**Shape two, no edit ran** (everything routed, refused, or blocked):
- `fixes-log.md` still holds an entry per item with its route or refusal reason. A routing-only run is a real result and it is never dressed up as an edit.

In both shapes:
- Every REGENERATE item left with the exact sentence its tighter brief must contain, addressed to a named room.
- MODE B: each change is tied to a note and its taster count, the refined winner keeps its Round 1 candidate id, and any challenger is queued with `/main-image` for Round 2.

## Update status.md

Add a Log line: `[date] Fixing Room (MODE [A/B]): [n] edits on [files], [n] routed to regeneration, [n] refused, ~$[X.XX] spent. See [asset-folder]/fixes-log.md.`

MODE A: INSPECT stays `in-progress` until the re-inspection passes, then it follows the Inspection Room's status. MODE B: PROVE stays `in-progress`, and the refined winner plus the refined frame go back to `/tasting-room` for Round 2, or on to `/ready-to-upload` if no re-test is wanted.

---
name: fix
description: Surgical image edits in the Fixing Room, in two modes. MODE A (pre-survey, QA-driven) fixes the defects the Inspection Room flagged. MODE B (post-survey, comment-driven refinement) reads the poll "why" comments from /poll and refines the winning candidate. Routes each defect to edit vs regenerate, runs safe edits on the OpenAI gpt-image edit API for cents, always keeps the original, verifies the result side by side, and logs every edit. Triggers: /fix, "fix this image", "remove the badge", "shorten that text", "change the word", "edit the image", "refine the winner", "act on the survey comments", or fix items coming from /inspect or /poll.
---

# The Fixing Room

| Meta | Value |
|------|-------|
| Room | The Fixing Room |
| Station | INSPECT (fix leg, MODE A) and PROVE (post-survey refinement, MODE B) |
| Needs | The image file to fix, the exact defect or the survey comments, OpenAI API key (gpt-image edit endpoint) |
| Saves to | factory/Products/[product]/images/ (as `name_fixN.png`, original kept) + images/fixes-log.md |
| Typical cost | Cents per edit (roughly $0.02 to $0.10 per image at low quality). Every edit is counted and logged. |

## What this room does

Some defects cost cents to fix; others need a whole new bake. This room decides which is which FIRST, then performs only the safe surgical edits: precise, minimal changes on the direct OpenAI image edit API, with the original always preserved and every result verified against it. Anything that needs regeneration goes back to /main-image or /secondary-images with a tighter brief, never through here.

The Fixing Room runs in TWO modes, and this is a core promise of the bootcamp: creative does not stop at "generated," it improves with evidence.

- **MODE A . pre-survey, QA-driven.** Fix the specific defects the Inspection Room flagged, so only gate-passing candidates reach the Poll Room.
- **MODE B . post-survey, comment-driven refinement.** After a poll (`/poll`), read the "why" comments, extract the top 2 to 3 things shoppers disliked or wanted, and make targeted surgical edits to the WINNING candidate. Optionally build one challenger variant that addresses the single biggest complaint, to re-test against the winner. This is how a winning image gets sharper before it ever goes live.

Both modes use the same routing table, the same direct edit API, the same keep-the-original discipline, and the same verification below. The difference is only WHERE the fix list comes from: the scorecard (MODE A) or the voter comments (MODE B).

## Before you start

- **Establish the mode first.** MODE A if the fix list comes from an Inspection Room scorecard (pre-survey). MODE B if it comes from a completed poll's "why" comments via /poll (post-survey refinement of the winner). State which mode you are in; it changes only where the fix list is sourced, not how edits run.
- **MODE B only:** read the latest `tests/poll-[date].md`, including the mined "why" comments, and confirm which file WON. The refinement targets the winning candidate, not the losers. Extract the top 2 to 3 things shoppers disliked or asked for; each becomes a candidate fix.
- Confirm the target file exists in `images/` and open it with Read so you can see the defect yourself. Never edit an image you have not viewed.
- Confirm the OpenAI API key is available. If $OPENAI_API_KEY is not set, load it from the .env file in the kit root first (`export OPENAI_API_KEY=$(grep '^OPENAI_API_KEY=' .env | cut -d= -f2)`). If there is no key at all, this room is closed: say exactly what is missing, point to `guides/mcp-setup-guide.md`, and mark the fix BLOCKED.
- Confirm the exact defect and the desired result in one sentence each. A vague "make it better" is not a fix order; ask for the specific change.
- **Paid-edit policy (every paid run, single or batch):** present the fix list with a one-line total cost estimate (cents) and get one go-ahead; then run them all. Never spend silently.

## Process

0. **MODE B only . build the refinement list from the comments.** Turn the top 2 to 3 voter complaints or requests into concrete image changes on the WINNING candidate. Map each comment to a specific edit and record which comment drove it (for example: "'text is too busy' (5 comments) -> remove the two smallest callouts"; "'wish I could see the size' (4 comments) -> add a short size label"). Then route each change through the table in step 1 like any other fix. If the top complaint needs a spatial change (layout, casting, bigger element), it is a REGENERATE: build one CHALLENGER variant of the winner via /main-image (or /secondary-images for a gallery frame) that addresses that single biggest complaint, and plan to re-test it against the current winner in the next poll. Keep the refinement list short and targeted; MODE B sharpens a proven winner, it does not redesign it. (MODE A skips this step and takes its list from the scorecard.)

1. **ROUTE THE DEFECT FIRST. This decision is the room.**

   | Defect | Route |
   |---|---|
   | Shorten or remove text | SAFE AS EDIT |
   | Remove an element (badge, card, stray object) | SAFE AS EDIT |
   | Swap a word or a claim | SAFE AS EDIT |
   | Recolor an accent | SAFE AS EDIT |
   | Enlarge text | REGENERATE |
   | Move or resize elements | REGENERATE |
   | Change layout or composition | REGENERATE |
   | Fix casting, a face, or a person | REGENERATE |
   | Fix the product itself (wrong bottle, wrong label, wrong material) | REGENERATE |

   Why the split: the edit API re-renders the frame, so removal and substitution are reliable, but anything spatial (size, position, layout, faces, the product) comes back garbled or subtly wrong. For every REGENERATE item: do NOT edit. Send it back to /main-image or /secondary-images with a tighter brief, and write the exact sentence the new brief must contain (for example: "Headline maximum 4 words, occupying at least 10% of the image height"). Record the routing decision in the fixes log even when no edit runs.

2. **Write the surgical prompt.** The prompt names ONE change and freezes everything else:
   - "Remove the circular badge in the top right corner. Change nothing else in the image."
   - "Change the text 'CURES DRY SKIN' to 'FOR DRY SKIN'. Keep the exact same font, size, color, and position. Change nothing else."
   One change per edit call. If an image needs three fixes, that is three sequential edits (or one regeneration; if it needs three or more fixes, say so and recommend regenerating instead).

3. **Run the edit on the OpenAI gpt-image edit API directly** (the images.edit endpoint), low quality unless the user asks for higher. Use the newest gpt-image model available on the account (list models if unsure; as of mid 2026 that is gpt-image-2 via the images.edit endpoint). Example shape, run from the kit root:
   ```bash
   curl -s https://api.openai.com/v1/images/edits \
     -H "Authorization: Bearer $OPENAI_API_KEY" \
     -F model="[newest gpt-image model]" \
     -F image="@factory/Products/[product]/images/[name].png" \
     -F prompt="[surgical prompt]" \
     -F quality="low" \
     | python3 -c "import sys,json,base64; open('factory/Products/[product]/images/[name]_fixN.png','wb').write(base64.b64decode(json.load(sys.stdin)['data'][0]['b64_json']))"
   ```
   Note: if the API returns a verification error, the OpenAI organization needs one-time verification at platform.openai.com; see `guides/mcp-setup-guide.md`.

4. **Name and save correctly. The original is sacred.** Save the result as `[name]_fix1.png` next to the original (then `_fix2`, `_fix3` for later rounds; a fix of a fix increments the number, it never overwrites). Never delete, overwrite, or move the original. The user prunes files; you do not.

5. **Verify side by side.** Open BOTH the original and the fixed file with Read and compare deliberately. Edits re-render the whole frame and can quietly break things far from the fix: other text garbles, the label warps, a prop shifts. Check: (a) the requested change happened, (b) every other piece of text still reads exactly as before, (c) the product, label, and layout are untouched. If anything else changed, the edit FAILED: keep the file for the record, mark it failed in the log, and either retry with a tighter prompt or route to regeneration.

6. **Re-run the inspect checks on the fixed image.** Squint test at 160px, the 6 dimension scores, and the compliance gate, per the Inspection Room. A fix that passes replaces its parent in the slot ranking; update the current scorecard if one exists.

7. **Log the edit** in `images/fixes-log.md` (create the file on first use). Append, never overwrite.

## Output format

`images/fixes-log.md` (append one entry per edit or routing decision):

```markdown
## [YYYY-MM-DD HH:MM] [name].png -> [name]_fixN.png
- Mode: [A: pre-survey QA-driven / B: post-survey comment-driven refinement]
- Defect / request: [what was wrong or wanted]
- Driven by: [MODE A: scorecard flag / MODE B: the exact voter comment(s) and how many said it]
- Route: EDIT [or: REGENERATE, sent back to /main-image or /secondary-images as a challenger variant, no edit run]
- Prompt: "[the exact surgical prompt]"
- Result: [SUCCESS / FAILED: what else broke]
- Side-by-side check: [requested change OK, other text intact, product intact]
- Re-inspection: squint [PASS/FAIL], compliance [PASS/FAIL], scores [summary]
- Cost estimate: ~$[0.0X]
- Running total this product: ~$[X.XX] across [N] edits
```

## Golden Standards check

Before presenting, verify:
- [ ] The mode is stated (A pre-survey / B post-survey), and MODE B edits target the WINNING candidate and each names the voter comment that drove it.
- [ ] The routing table was applied BEFORE any edit; no REGENERATE-class defect was pushed through the edit API.
- [ ] Each edit prompt names one change and ends with an explicit "change nothing else" instruction.
- [ ] The original file still exists, untouched, and the fix is saved as `_fixN` beside it.
- [ ] Original and fix were both viewed side by side, and other on-image text was read and confirmed intact.
- [ ] The fixed image was re-inspected (squint test + compliance gate), not assumed good.
- [ ] The edit is logged in `fixes-log.md` with prompt, result, and cost estimate.
- [ ] The fix list was presented with a one-line total cost estimate and the user gave one go-ahead BEFORE any paid edit ran (single or batch).

## Wonka lines

Openers:
- "To the Fixing Room. Small tools, steady hands, and absolutely no improvising."
- "One flaw, one scalpel. We do not repaint the whole candy to fix a smudge."
- "Bring the patient in. And bring the original; we never operate without it."

Closers:
- "Fixed, verified, and the original sleeps safely beside it. Back to the Inspection belt."
- "Two cents of surgery and the candy is whole. I do enjoy a bargain."
- "That one needs the ovens, not the scalpel. Off to the generation rooms with a stricter brief."
- "The shoppers told us what to sharpen, and we sharpened exactly that. Now let them taste it again."

## Definition of Done

- The fixed image exists as `[name]_fixN.png` next to its untouched original.
- The side-by-side verification and the re-inspection both ran, and the result is recorded.
- `images/fixes-log.md` has the complete entry (mode, defect/request, what drove it, route, prompt, result, cost).
- Every REGENERATE-class defect was routed back with its exact tighter-brief instruction, not edited.
- MODE B: the refinement targeted the winning candidate, each edit is tied to the voter comment that drove it, and any challenger variant is queued for a re-test.

## Update status.md

Add a Log line: `[date] Fixing Room (MODE [A/B]): [n] edits on [files], [n] routed to regeneration, ~$[X.XX] spent. See images/fixes-log.md.` For MODE A, INSPECT stays `in-progress` until the re-inspection passes, then follows the Inspection Room's status. For MODE B, PROVE stays `in-progress`: the refined winner (and any challenger variant) goes back to the Poll Room (/poll) to re-test, or on to the Shipping Room (/publish) if no re-test is wanted.

---
name: factory-report
description: The Factory status report. Scans every product's station tracker and artifacts, reports where each product stands, what is blocked and on whom, and the one next action per product, plus a factory-wide summary and Wonka's recommendation for the week. Written so it can run as a weekly scheduled task. Use for any status question. Triggers: /factory-report, "status", "where are we", "factory report", "what's on the line", "what should I do this week", "weekly report".
---

# The Factory Floor

| Meta | Value |
|------|-------|
| Room | The Factory Floor |
| Station | All stations (read-only overview) |
| Needs | `factory/Products/*/status.md` plus each product's artifact folders; `factory/Recipe Book/` |
| Saves to | factory/Factory Log/[YYYY-MM-DD]-report.md |
| Typical cost | Free. Read-only; this room touches nothing on the line. |

## What this room does

The owner walks the floor. This skill reads the actual state of the Factory from disk (never from memory of past sessions), reports each product's station, its finished artifacts, its blockers and who owns them, and the single next action that moves it forward. It ends with a factory-wide view and one concrete recommendation for the week. It is written so it can run as a weekly scheduled task. If scheduled runs are not available in the user's setup, the fallback is one command every Monday: /factory-report.

## Before you start

- Get today's real date from the system (run `date` in the shell); the report filename and every "days waiting" figure depend on it.
- If `factory/Products/` is empty or missing, the Factory is new: say so, skip the scan, and offer `/meet-my-product` and the tour. Still write a short report noting an empty line.
- This room is read-only. It never edits a status.md, never generates, never fixes. If the scan reveals a wrong status (an artifact exists but the station says pending), REPORT the mismatch; do not silently correct it.

## Process

1. **Scan every product.** For each folder in `factory/Products/` (skip `TEMPLATE/`):
   - Read `status.md` in its canonical TEMPLATE format: the stations table (RESEARCH / BRIEF / INVENT / INSPECT / PROVE; statuses: pending / in progress / blocked / done), the INVENT sub-status block (Main image / Secondary images / A+ / Variations), the Owner intel section, the "Blocked on" line, and the Log.
   - Verify against reality on disk: list the actual files in `research/`, `brief/`, `reference/`, `images/`, `aplus/`, `variations/`, `scorecards/`, `tests/`. An artifact on disk is the truth; a status claim without its artifact is a mismatch to report.
   - Note the newest log date, to compute how long the product has been sitting.

2. **Determine each product's current station** (the first station that is not done), what is DONE (with the actual artifact filenames as proof), and what is IN PROGRESS. INVENT counts as `done` ONLY when there are artifacts in `images/` AND `aplus/` AND `variations/`, OR the INVENT sub-status block records a conscious skip (e.g. `Variations (/variations): n/a`) for any missing sub-part. Report the INVENT sub-status for any product at or past the INVENT station, four lines: Main image (/main-image), Secondary images (/secondary-images), A+ (/aplus), Variations (/variations); images alone is `in progress`, not `done`.

3. **Identify blockers, and name the owner of each.** Every blocked item is either:
   - **On the user**: missing niche export, missing product photos, poll not yet published, results not pasted, A/B not launched, spend approval pending.
   - **On Wonka**: an artifact promised but not produced, a fix batch not run, a scorecard pending.
   State it plainly: "waiting on YOU for the photos, 6 days now" or "waiting on ME: the scorecard, I owe it this session."

4. **Pick THE ONE NEXT ACTION per product.** Exactly one, concrete, with the command that does it ("Run /inspect on the 8 new images" or "Export Top Niche Insights for 'garlic press' and drop it in research/"). A list of five next steps is a way of choosing none.

5. **Check running experiments.** Read `factory/Recipe Book/experiments.md`: any row with Status `running` gets a line with its expected end date. Overdue check: a row with Status `running` and Type `amazon-ab` whose Date is older than 10 weeks gets a nudge ("the castor oil A/B should have results by now: check Manage Your Experiments and bring me the verdict for /improvement-loop"). Rows are written by /poll (taste-test) and /publish (amazon-ab); /improvement-loop finalizes them.

6. **Build the factory-wide summary:** products in flight (count and names), tests running, Recipe Book size (patterns count, and how many at USE strength), and any product idle for more than 7 days.

7. **Write Wonka's recommendation for the week.** ONE priority ("this week: get castor oil through the Poll Room; everything else can simmer"), chosen by impact: closest to a publish pack first, longest-stuck second.

8. **Save the report** to `factory/Factory Log/[YYYY-MM-DD]-report.md` and present it. When running as a scheduled Routine with the user away, the saved file IS the deliverable; keep the spoken summary to five lines.

9. **Offer the Routine once.** If the user runs this manually and no weekly schedule exists yet, offer once: "Want me to walk the floor every Monday morning by myself? One scheduled Routine and you get this report with your coffee."

## Output format

`factory/Factory Log/[YYYY-MM-DD]-report.md`:

```markdown
# Factory Report . [YYYY-MM-DD]

## Products on the line

### [Product Name] . station: [INSPECT]
- Done: RESEARCH (research/insights.md, research/persona.md), BRIEF (brief/creative-brief.md), INVENT (images/: 8 files, aplus/: 7 modules, variations/: 6 files or "n/a, no variations")
- INVENT sub-status: Main image (/main-image) done, Secondary images (/secondary-images) done, A+ (/aplus) done, Variations (/variations) done (or n/a)
- In progress: INSPECT (scorecard pending)
- Blocked: [none / waiting on USER: publish the ProductPinion survey, 3 days / waiting on WONKA: scorecard]
- Idle: [n] days since last log entry
- Mismatches: [none / status says INVENT pending but images/ has 8 files]
- NEXT ACTION: [one line + the command]

[...repeat per product...]

## Experiments running
- [product]: A/B launched [date], results due ~[date]. [on track / OVERDUE: fetch the verdict]

## Factory-wide
- Products in flight: [n] ([names])
- Tests running: [n]
- Recipe Book: [n] patterns ([n] at USE strength), [n] owner preferences
- Idle over 7 days: [none / product X, n days]

## Wonka's recommendation for the week
[ONE priority, one short paragraph: what, why it is first, and the first command to run.]
```

## Golden Standards check

Before presenting, verify:
- [ ] Every product folder in `factory/Products/` was scanned; none skipped, TEMPLATE excluded.
- [ ] Every "done" claim in the report is backed by a named artifact file verified on disk.
- [ ] INVENT is only called `done` when images/, aplus/, and variations/ all have artifacts (or a sub-part is recorded as a conscious skip in the INVENT sub-status); the sub-status is reported for any product at or past INVENT.
- [ ] Every blocker names its owner (user or Wonka) and how long it has waited.
- [ ] Each product has exactly ONE next action, with its command.
- [ ] Status/disk mismatches are reported, not silently fixed.
- [ ] Overdue A/B experiments are flagged with a fetch-the-verdict nudge.
- [ ] The weekly recommendation is a single priority, not a list.
- [ ] The report file exists in `factory/Factory Log/` with today's real date.

## Wonka lines

Openers:
- "Walking the floor. Every belt, every kettle, every excuse."
- "Ah, inspection day for the Factory itself. Let's see who's been napping."
- "Status, you say. I read the shelves, not my memory. One moment."

Closers:
- "That's the floor walked. One priority this week; the rest is noise and nougat."
- "Two products humming, one waiting on you, and the book grows fatter. Decent week ahead."
- "The Factory never sleeps. It naps, occasionally. Castor oil has napped six days; wake it."

## Definition of Done

- `factory/Factory Log/[YYYY-MM-DD]-report.md` exists with every product's card, the experiments check, the factory-wide summary, and the one-priority recommendation.
- Every claim in it traces to a file on disk read this session.
- The user (or the Routine transcript) has the five-line spoken summary and the single week priority.

## Update status.md

This room does not edit product status files (read-only). If a mismatch was found, tell the user which product's `status.md` disagrees with its folder and offer to reconcile it in the relevant room's next run.

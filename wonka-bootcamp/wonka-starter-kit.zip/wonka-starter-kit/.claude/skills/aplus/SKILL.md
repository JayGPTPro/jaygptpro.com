---
name: aplus
description: Plan and generate the product's Amazon A+ content (Enhanced Brand Content) module set from the brief's A+ plan, the locked Reference Sheet, and the brand kit, with legibility and compliance gated on every module and one cost approval before generation. Use after the brief is written and the Reference Sheet is locked and the user wants A+ modules. Triggers: /aplus, "build the A+", "A+ content", "enhanced brand content", "make the A+ modules", "A+ room".
---

# The A+ Room

| Meta | Value |
|------|-------|
| Room | The A+ Room |
| Station | INVENT (A+ lives under Invent, alongside listing images and variations) |
| Needs | brief/creative-brief.md (the A+ module plan), reference/reference-sheet.md (LOCKED, smoke test PASS), factory/Brand/brand-kit.md |
| Saves to | factory/Products/[product]/aplus/ |
| Typical cost | Genrupt: credits per module image, one module set. Fallback: gpt-image API per call. ALWAYS estimated and approved before the batch. |

## What this room does

The A+ Room builds the Enhanced Brand Content that sits below the fold on the listing: the story section that turns a browser who already scrolled past the gallery into a buyer. It reads the A+ plan the Brief wrote, generates each module against the locked Reference Sheet and the brand kit, and gates every module on the same Golden Standards as the listing images. A+ is part of the Invent station, produced off the same locked reference and corrected persona as the gallery. It is not A/B tested like the main image, so it does not gate the launch, but it must never ship illegible or non-compliant.

## Before you start

Check inputs, in this order. Any hard miss = station **BLOCKED**, with a pointer:
- `brief/creative-brief.md`: must exist and contain an A+ module plan. If missing, the station is BLOCKED. Point to `/creative-brief` and stop. Do not invent a module set from scratch here; the Brief carries the strategy, the persona, and the selling-points coverage.
- `reference/reference-sheet.md`: must exist with `Reference status: LOCKED` and `Smoke test: PASS`. An approved reference without a passed smoke test does not count. Missing or unpassed: point to `/reference-sheet` and stop.
- `factory/Brand/brand-kit.md`: colors, fonts, tone. If missing, offer `/brand-kit`; the user may proceed, but every brand-style field is marked `pending brand kit` and must be filled before generation.
- Read `status.md` Owner intel: must-include and avoid items bind these modules too.
- Confirm the generation path: Genrupt MCP connected (primary) or gpt-image fallback. Never switch paths silently.

## Process

1. **Load the A+ plan.** Read the A+ section of the Brief plus the selling-points coverage map. Confirm which points the A+ carries versus the gallery, so nothing is dropped and nothing is doubled without reason.

2. **Validate the brief's module plan against best practice (do NOT design from scratch; the brief's A+ plan from step 1 is the plan).** Use this checklist to confirm the plan covers the story a strong public A+ tells, cap the total at 7 modules, and flag any gap back to the brief rather than inventing modules here. The story a coherent A+ runs, hero to trust:
   - **Brand or hero banner**: the brand promise in one line, the product shown honestly.
   - **2 to 3 feature or benefit modules**: one benefit each, visualized, one headline each.
   - **Ingredients or how-it-works module**: what it is made of or how it works, shown accurately.
   - **Comparison module**: this product versus the old way or the generic option, on the dimensions the persona cares about. A comparison module is a strong asset for a public seller; include it and fill it with honest, real differentiators only.
   - **Lifestyle or story module**: the persona's outcome, a person allowed here (A+ is below the gallery, not the main image).
   - **Trust, specs, or FAQ module**: dimensions, materials, certifications the product actually carries, and the top real questions from `research/reviews.md`.
   Give each module ONE job and ONE dominant message. No module repeats another's headline.

3. **Write each module brief** off the Brief and the brand kit:
   - **Message**: one headline, kept short; supporting copy in short scannable lines, never a wall of text.
   - **Composition**: product placement, prop and product accuracy named explicitly (materials read as what they are, the right props, the right details; a two-mic machine shows both mics). Product matches the Reference Sheet.
   - **Casting** (modules with people only): write the person's description and displayed age INTO the module brief text, because the image model ignores separate age fields. Apply the aspirational skew from CLAUDE.md to the persona's real age, and cast a different person than the gallery uses.
   - **Brand style**: hex colors, font style, tone from the brand kit.
   - **Compliance**: the avoid-list restated per module (no medical or disease claims, no invented percentages, no star ratings or review references, no fake badges or awards, no third-party logos rendered as graphics, no flag graphics). Real certifications only as they appear on the label.

4. **Estimate cost and get one go-ahead.** One line: "[N] A+ modules on [path], estimated [credits/dollars]. Proceed?" No generation starts without a yes.

5. **Generate. Path A: Genrupt (primary).** Generate the A+ from the locked reference so the product lock is inherited. Rules, all mandatory:
   - **Always pass `modelId: "gpt_image_2"` explicitly on every call.** Never rely on the tool default; an unspecified call silently uses a weaker engine.
   - Attach the approved reference asset id from `reference/reference-sheet.md` so the product lock holds.
   - Put casting age and full person description inside the module brief text, never only in an avatar field.
   - Never instruct the model to render a third-party logo or award badge; the content checker fails the whole image.
   - Carry the one-headline, short-copy, big-legible-text constraint into every module brief verbatim.

6. **Generate. Path B: gpt-image fallback (no Genrupt).** Attach the Reference Sheet's cleaned reference images to every call and prepend the product spec from `reference/reference-sheet.md` (size, material, cap, label text) so the model cannot drift. Expect weaker product fidelity and say so; inspect each module harder against the reference. This path makes accurate on-module product rendering harder, so generate the hero module first, view it, and only continue if the product renders faithfully.

7. **Save everything to `aplus/`** with module-numbered filenames: `m1-hero.png`, `m2-benefit.png`, `m3-comparison.png`, and so on, matching the module plan. Never overwrite; a regenerated module saves beside the first attempt.

8. **Run the Golden Standards check below, then hand off.** Do a first-pass sanity look for catastrophic misses only. Do NOT present these as final. Point the user to the Inspection Room: "The A+ modules are out of the machines. Next stop is /inspect before anything ships."

## Output format

`factory/Products/[product]/aplus/` after a run:

```
aplus/
  m1-hero.png
  m2-benefit.png
  m3-benefit.png
  m4-ingredients.png
  m5-comparison.png
  m6-lifestyle.png
  m7-trust-faq.png
  aplus-plan.md
```

`aplus/aplus-plan.md`:

```markdown
# A+ Plan . [Product Name]
Built from: brief/creative-brief.md ([date]), reference/reference-sheet.md (LOCKED), factory/Brand/brand-kit.md.

## Modules
| Module | Job | Headline | People | Selling point(s) |
|---|---|---|---|---|
| M1 hero | brand promise | "[headline]" | no | SP1 |
| M5 comparison | vs the old way | "[headline]" | no | SP4, SP6 |

## Generation
| Date | Path | Model | Modules | Est. cost | Approved |
|---|---|---|---|---|---|
| [date] | genrupt / gpt_image_fallback | gpt_image_2 | 7 | [est] | yes ([date]) |
```

## Golden Standards check

Before handing off, verify:
- [ ] Brief A+ plan and Reference Sheet lock were both present; a miss was reported as BLOCKED, not worked around.
- [ ] Every module has ONE job and ONE dominant message; no two modules share a headline.
- [ ] Legibility holds: short copy, big text, no wall of text; each module readable on mobile.
- [ ] Compliance avoid-list honored on every module; real certifications only as on the label.
- [ ] Comparison module uses honest, real differentiators only.
- [ ] Genrupt path: `modelId: "gpt_image_2"` on every call, Reference Sheet reference id attached, casting in brief text, no third-party logo render.
- [ ] Fallback path: references attached, product spec prepended, weaker-fidelity warning given.
- [ ] Cost estimated and approved before generating; files saved module-numbered, no overwrites.
- [ ] User was pointed to the Inspection Room; no module called final.

## Wonka lines

Openers:
- "The A+ Room. Below the fold is where the browser becomes the buyer. We do not waste the second act."
- "Six or seven modules, one story, start to finish. Watch how it builds."
- "Ladies and gentlemen... the A+. The gallery hooks them; this closes them."

Closers:
- "The modules are out of the machines, the story runs hero to trust. Off to /inspect before a word of it ships."
- "A+ built off the same locked Reference Sheet as the gallery, so the candy matches on every shelf."
- "Nothing here is final until the Inspection Room says so. Onward."

## Definition of Done

- Every planned A+ module has at least one generated image in `aplus/`, module-numbered, or a recorded failure with its error.
- `aplus/aplus-plan.md` exists with the module table and the generation record (path, model, count, approved cost).
- The user was explicitly handed to the Inspection Room; no module was presented as final.

## Update status.md

A+ is part of the INVENT station. In the INVENT sub-status block, set `A+ (/aplus): done` (or leave `pending` / mark `blocked: [precondition]` if this room did not complete). Artifact `aplus/` + `aplus/aplus-plan.md`. Then check the whole INVENT sub-status block: when all four sub-parts (Main image, Secondary images, A+, Variations) are `done` or `n/a` with a reason, set the INVENT station row to `done`; otherwise leave it `in progress`. Add a Log line: `[date] A+ generated: [N] modules on [path], cost approved [est]. Awaiting inspection.`

---
name: aplus
description: Generate the Amazon A+ content (Enhanced Brand Content) module set from the brief's A+ plan, the locked Reference Sheet and the brand kit. Fixes module order, builds the comparison chart with a proof for every row, traces every printed claim to the spec sheet, never uses a carousel, and takes one cost approval before generating. Use after the brief is written and the Reference Sheet is locked. Triggers: /aplus, "build the A+", "A+ content", "enhanced brand content", "make the A+ modules", "comparison module", "A+ room".
---

# The A+ Room

| Meta | Value |
|------|-------|
| Room | The A+ Room |
| Day | 7, the last building room. The Tasting Room (Day 8) is next |
| Station | INVENT (A+ is one of the four Invent sub-parts) |
| Needs | `brief/creative-brief.md` (the A+ module plan + the coverage map), `reference/reference-sheet.md` (LOCKED, smoke test PASS), `factory/Brand/brand-kit.md`, `research/reviews.md` (the dominant objection + the real questions), `images/` (the secondary set, for the extension check) |
| Saves to | `factory/Products/[product]/aplus/` (module images + `aplus-plan.md`) |
| Typical cost | Genrupt: credits for one concept of 6 or 7 modules. Fallback: gpt-image per module. ALWAYS estimated and approved once, before the batch. |

## What this room does

A+ content is the second product page, the section below the bullets that carries what a bullet cannot. The shopper who scrolls that far is interested and unsure, hunting for a reason to buy or a reason to leave. This room answers her. If the page does not answer her, she scrolls into the reviews and takes her answer from the angriest customer there.

The room reads the A+ plan the Brief already wrote, orders it, builds it against the locked Reference Sheet and the brand kit, and gates every claim before a credit is spent. It designs nothing from scratch: the Brief carries the strategy, the persona and the selling-points coverage.

Scope of THIS room is the A+ modules only. The main image, the secondary gallery and variation imagery come out of their own rooms (`/main-image`, `/secondary-images`, `/variations`) off the same brief and the same locked reference, and they stay untouched here. Nothing out of this room is final: `/inspect` runs next.

**This room publishes nothing.** It produces module files and a plan; the owner uploads them to their own listing in Seller Central. The bootcamp's on-camera demo runs on a listing that belongs to another seller, so the demo A+ is built and inspected and then goes nowhere. Say so plainly if the subject comes up.

A+ does not enter either Tasting Room race (Day 8 races the main candidates and the gallery only), so it never gates the launch. It may be realigned on Day 9 if the tasting notes flip the winning angle. That is not a reason to ship it illegible or unprovable.

## Before you start

**Two HARD gates. A miss on either = station BLOCKED, with a pointer, and no generation.**

1. `brief/creative-brief.md` exists and contains the A+ module plan. Missing: point to `/creative-brief` and stop. Never invent a module set here to keep moving.
2. `reference/reference-sheet.md` exists with `Reference status: LOCKED` and `Smoke test: PASS`. An approved reference WITHOUT a passed smoke test does not count; the smoke test is the only proof the lock holds. Missing or unpassed: point to `/reference-sheet` and stop.

**Everything else is a GAP, not a wall. "I don't have it" is a first-class answer: record it and proceed.** Ask for each one, take the answer, write it into the plan's `Gaps` block, and keep going. Never guess the content, and never let a gap pass unrecorded.

| Input | If the owner says "I don't have it" |
|---|---|
| `factory/Brand/brand-kit.md` | Offer `/brand-kit` once. If the answer stays no, proceed and record `brand style: no kit on file`. Generate on the product's existing look, and tell `/inspect` to score brand fit as "no kit on file" instead of inventing a standard. |
| `research/reviews.md` | Proceed and record `objection source: none on file`. Build the trust or FAQ module from the listing's own spec and questions. NEVER invent a buyer complaint or a customer question. |
| Owner intel in `status.md` (must-include / avoid) | Proceed and record `owner intel: none given`. |
| Brand Registry / A+ eligibility status | Blocks nothing here. Record it and move on; the files are built either way. |
| A live ASIN (product not listed yet) | Use the product-title plus description path with the reference photos attached (see step 8). Record `source: no_asin`. |

**Then confirm the machine, and never switch paths silently.** Genrupt MCP connected is Path A. If Genrupt is down, or the tool reports insufficient credits, say so in one line and OFFER the gpt-image fallback (Path B) with its weaker product fidelity named. If the owner declines both, park the room `blocked: generation machine unavailable`, with `aplus-plan.md` already written to disk so no thinking is lost.

## Process

1. **Load the plan and the page's neighbours.** Read the A+ section of the Brief, the selling-points coverage map, and the restated avoid list. Then read the messages already carried by the secondary set (`brief/creative-brief.md` slot list plus the files in `images/`). You need both: the A+ must EXTEND the gallery, never restate it. A module that repeats a secondary image is a wasted module. If the gallery has not been generated yet, run the extension check against the brief's secondary slot plan alone and note in the plan that it was checked against the plan and not against finished frames.

2. **Name the objection this page exists to answer.** From `research/reviews.md`, state in one sentence the number one thing buyers complain about in this category, and point at the module that answers it. Most sellers never build that module because it feels like admitting a weakness. Answering it honestly on your own page is how you take it away from your reviews. If no module answers it, that is a gap in the brief: say so and offer to fix the brief before generating, rather than inventing a module here.

3. **Validate the set against the six module jobs, then FIX THE ORDER.** Do not design from scratch; check the brief's plan against the story a strong public A+ runs, hero to trust, and flag gaps back to the brief:
   - **Hero or brand banner**: the promise in one line, the product shown honestly. Not an "about us" paragraph.
   - **Two or three benefit modules**: ONE benefit each. Four benefits crammed into one module means none of them land.
   - **How it works, or what it is made of**: shown accurately. For many products this is the module that closes the sale.
   - **Comparison module**: this product against the generic option or the old way, on the dimensions the persona actually cares about. Own rules in step 4.
   - **Lifestyle or story**: the outcome the buyer is buying. People ARE allowed in A+ (it sits below the gallery, and the no-people rule is the MAIN image's rule).
   - **Specs, trust or FAQ**: real dimensions, real materials, real certifications, and the top genuine questions from the review research.

   **Cap the set at 7 modules. Six is plenty.** More modules is not more page; it is more things to keep sharp. An eighth module needs its JOB written into the brief in one sentence first, and if the job cannot be written, the module was not needed.

   **Order is a variable that no single image ever had.** The page is read top down and she stops somewhere, so the strongest module goes FIRST. Burying the best answer in module five is close to not having it. Record the running order in the plan and name why the lead module leads.

4. **Build the comparison module row by row, with a proof per row.** This is the highest-leverage module on the page and the one that gets a seller in trouble. Write every row into the plan's comparison table before generating. Four rules, none optional:
   - **Real rows only, and "provable" is the bar, not "true".** Each row names its proof: the spec sheet, the physical label, the listing's own stated claim. If the proof is "everyone knows", cut the row.
   - **Never a named brand.** Compare against "the generic option", "typical alternatives", or "the old way". A named comparison invites a dispute even when you are completely right, and it buys nothing.
   - **No prices, no discounts, no shipping claims, anywhere in the A+.** Price and promotional claims do not belong down here, and modules stay up long after a price moves.
   - **Never invent a loss for the other column.** One fabricated row poisons the whole chart. If the other column cannot be stated honestly, the row goes.

   Four provable rows beat six with one soft row. **A point the brief CONSCIOUSLY SKIPPED may not walk back in through a module.** If it belongs on the page after all, the brief changes first and says why.

5. **Sweep every printed claim for provenance before generating.** A+ has more room for words than any other asset, which is exactly why it is where unprovable claims appear:
   - Every number, capacity, dimension, material and certification that will print on a module traces to the listing spec, the physical label, or the brand's own stated claim. Record the source in the plan.
   - **A number that came from a customer review NEVER prints as a brand claim.** Review evidence decides WHICH module exists and how it is worded (an expectation-setting how-to module, for instance), and never supplies the number on the module.
   - **A module may not contradict the listing's own spec.** A brand asset arguing with its own spec sheet is a refund waiting to happen.
   - The standing avoid-list still applies to every module: no medical or disease claims, no invented percentages or statistics, no star ratings or review references, no fake badges or awards, no third-party logos rendered as graphics, no flag graphics. Real certifications appear only as they appear on the real label.

6. **Write each module brief** off the Brief and the brand kit. Keep each one short and routed:
   - **Message.** ONE headline, 6 words or fewer, plus either up to three short supporting lines or up to four icons and labels. Never both at full budget. Win legibility by SUBTRACTION: fewer elements means bigger text. A+ fails the mobile squint test more than any asset class you will make, because it feels like the place for MORE and then renders in a narrow phone column as a grey smudge.
   - **Composition.** Product placement, and product accuracy named explicitly: the real material, the real parts, all of them present and countable (a four tier fountain shows all four tiers; stainless steel reads as metal and not plastic; glass reads as glass). The product matches the Reference Sheet.
   - **Casting** (modules with people only). The A+ generator has NO structured avatar field, unlike the listing builder, so casting for A+ lives in the prompt-instruction field as ONE short sentence per people module: explicit displayed age (the persona's real age with the aspirational skew from `CLAUDE.md`) and gender, and a person visibly distinct from the faces already in the gallery, so the page does not read as one model following the shopper around. One sentence, never a paragraph of casting prose.
   - **Brand style.** From the brand kit or the branding preset applied to the flow. Never paste hex codes or font names into module text; design-dictating text overrides the brand engine and flattens the output.
   - **Compliance.** One or two short constraint sentences, only what the engine does not already block system-side. Third-party logos and fake badges are blocked by Genrupt; do not spend words restating them.

7. **Write `aplus/aplus-plan.md` FIRST, read it back, then take ONE cost approval.** The plan is written to disk BEFORE any generation, so a stalled or blocked batch still leaves a real artifact. Read back to the owner, in this order:
   - every module with its ONE job and ONE message, in running order;
   - which module leads, and why it is the strongest hook;
   - the comparison rows, each with where it came from;
   - what the A+ EXTENDS versus what the gallery already said;
   - the locked Reference Sheet and the brand kit being generated on (and, on the bootcamp demo or any `amazon_scraped` reference, the one honest sentence: this reference was built from listing and review imagery because there is no unit in hand, and anyone running this on their own product shoots it properly, every angle plus a hand for scale);
   - any recorded gaps;
   - then ONE cost line: "[N] modules, [C] concept(s), [mode], on [path], estimated [credits/dollars]. Proceed?"

   No generation starts without a yes. If a module cannot state its job in one sentence, stop there and fix it in the brief. It is free now and a regeneration later.

8. **Generate. Path A: Genrupt (primary).** Two calls, never one:
   - **Preflight first**, without `setupConfirmed`. It returns the setup questions, the matching market analyses and the numbered listing-image candidates. It spends nothing and starts nothing. Relay any notices it returns, including reference-image limits.
   - **Then the confirmed call**, with every decision explicit:
     - `modelId: "gpt_image_2"` on EVERY call. An unspecified call silently generates on a weaker engine.
     - `moduleCount`: 6 or 7, matching the plan. **Never try to control module count in prose**; the field exists, prose does not work.
     - `conceptCount`: 1 unless the owner asked for alternates. Every extra concept multiplies the cost.
     - `mode`: desktop by default. "Both" doubles the batch; the chosen concept can be converted afterwards with `send_aplus_concept_to_mode` instead of paying for both up front.
     - `resolution: "1K"`. Standard A+ modules render at about 970 px wide, so a larger resolution costs more and buys nothing.
     - **Carousel NEVER enabled.** House rule: content hidden behind a swipe is seen by a fraction of the people who see content in the scroll. If a message is worth having, it goes in the scroll.
     - Module briefs go in the prompt-instruction field (`mustIncludeContent`) with `promptMode: append`. Use `override` only if the owner explicitly asks to replace the generated prompt.
     - **References.** The product lock is inherited from the ASIN's approved Reference Sheet, which is exactly why this room refuses to run before the lock. For style references, do NOT attach the owner's designed gallery wholesale: select the clean product shots (`listingReferenceMode: "selected"` with their indexes) or `none`, and pass the cleaned reference photos as additional reference URLs. The current gallery is what the factory is trying to beat; inheriting its design is how a new page comes out looking like the old one.
     - **No live ASIN**: pass the product title and description text with the reference photos attached, and record `source: no_asin` in the plan.
     - On a genuine re-run, set a FRESH idempotency key, or the call replays the cached run instead of generating.
   - **Then poll.** A+ generation typically takes 3 to 5 minutes. Obey the tool's stated wait, leave at least 60 seconds between checks, and stay quiet between checks instead of narrating status. If the tool reports insufficient credits, stop and say so plainly: top up, or switch to Path B explicitly.

9. **Generate. Path B: gpt-image fallback (no Genrupt).** One call per module:
   - Attach the Reference Sheet's cleaned reference images to EVERY call and prepend the product spec from `reference/reference-sheet.md` (size, material, parts, label text) so the model cannot drift.
   - Request the widest landscape frame the API offers, and keep critical text away from the edges: modules get placed into Amazon's module templates at upload.
   - **Generate the LEAD module first, view it, and continue only if the product renders faithfully.** If it does not, stop and tighten the reference rather than burning the batch.
   - Expect weaker product fidelity, say so up front, and inspect each module harder against the reference.
   - If a module's copy renders garbled, SHORTEN it rather than re-rolling the same wall of text.

10. **Land the files on disk, then prove they are there.** A preview link is not an artifact.
    - Genrupt: pick the concept number with the owner, export it (images ZIP), and place the files into `aplus/`, named in the plan's running order: `m1-hero.png`, `m2-benefit.png`, `m3-comparison.png`, and so on.
    - Then run a directory listing of `aplus/` and cite the real filenames and the real count. If the count is short of the plan, name the missing module numbers and re-run ONLY those, with their own one-line cost estimate and go-ahead. Modules save individually, so a partial batch is a nuisance and never a disaster.
    - Never overwrite. A regenerated module saves beside the first attempt, for example `m3-comparison-v2.png`.
    - Update `aplus-plan.md` with the generation record: path, model, module count, mode, estimated cost, approval date, and any failures with their error.

11. **First-pass sanity look, then hand off.** Open the modules and check ONLY for catastrophic misses: wrong product, wrong part count, a missing module, a rendered logo, a failed generation. Do NOT present these as results, and never call a module final. Hand to the Inspection Room with the page-level asks named, because a page is judged as a scroll and not as a grid: "The A+ is out of the machines. Next stop is /inspect: per-module standards, mobile legibility first, compliance on every claim and every comparison row, plus the page-level checks. Module order, one message each, and whether this extends the gallery or repeats it."

12. **Continue the INVENT station.** This room is one of four Invent sub-parts. Point onward: `/main-image` and `/secondary-images` if they are not done, `/variations` if the product sells variants (lawfully trailing to Day 10 if that is what `status.md` records), and then the full package goes to Inspection together.

## Output format

`factory/Products/[product]/aplus/` after a run:

```
aplus/
  m1-hero.png
  m2-benefit.png
  m3-how-it-works.png
  m4-comparison.png
  m5-lifestyle.png
  m6-specs-faq.png
  aplus-plan.md
```

`aplus/aplus-plan.md` (written BEFORE generation, updated after):

```markdown
# A+ Plan . [Product Name]
Built from: brief/creative-brief.md ([date]), reference/reference-sheet.md (LOCKED [date], source: [manual/amazon_scraped]), factory/Brand/brand-kit.md, research/reviews.md.

## Gaps recorded
- [input]: not available ([owner's words], [date]). Effect: [what it changes].
- (or "none")

## The objection this page answers
[One sentence from research/reviews.md] . answered by module [M#].

## Modules (running order)
| # | Job | Headline | People | Selling point(s) | Extends (not repeats) |
|---|---|---|---|---|---|
| M1 hero | brand promise, leads because [reason] | "[headline]" | no | SP1 | opens the page |
| M4 comparison | vs the generic option | "[headline]" | no | SP4, SP6 | gallery showed it, this proves it |

## Comparison rows
| Row | This product | The generic option | Proof | Verdict |
|---|---|---|---|---|
| [dimension] | [ours] | [theirs, honestly] | [spec sheet / label / listing claim] | keep |
| [dimension] | [ours] | [theirs] | none, one review only | CUT |

## Claim provenance
| Claim printed on a module | Module | Source |
|---|---|---|
| [number / material / certification] | M2 | spec sheet |

## Generation
| Date | Path | Model | Modules | Mode | Concepts | Resolution | Carousel | Est. cost | Approved |
|---|---|---|---|---|---|---|---|---|---|
| [date] | genrupt / gpt_image_fallback | gpt_image_2 | 6 | desktop | 1 | 1K | no | [est] | yes ([date]) |

Files on disk (verified [date]): m1-hero.png, m2-benefit.png, ... ([N] of [N] planned)
Failures: [module + error, or "none"]
```

## Golden Standards check

Before handing off, verify:
- [ ] Both hard gates were checked BEFORE generating (brief A+ plan present; Reference Sheet LOCKED with smoke test PASS), and any miss was reported as BLOCKED, not worked around.
- [ ] Every soft input was asked for, and each "I don't have it" is written into the plan's `Gaps` block. Nothing missing was invented.
- [ ] The dominant buyer objection is named and a module answers it, or the gap is recorded.
- [ ] Set capped at 7 modules, running order fixed, and the lead module is the strongest hook with the reason written down.
- [ ] Every module has ONE job and ONE dominant message; no two modules share a headline.
- [ ] Each module EXTENDS the gallery instead of restating it; the extension column is filled.
- [ ] Legibility budget honored per module: headline 6 words or fewer, then either up to 3 short lines or up to 4 icons and labels, never both at full budget.
- [ ] Comparison chart: every row has a named proof, no named brand, no price or promotional claim, no invented loss for the other column. A row without proof was cut, and a consciously skipped brief point did not walk back in.
- [ ] Claim provenance table filled: every printed number traces to spec, label or the brand's own claim. No review-sourced number printed as a brand claim, and no module contradicts the listing's own spec.
- [ ] Compliance avoid-list honored on every module; real certifications only as they appear on the label.
- [ ] Cost estimated once and explicitly approved BEFORE any spend; any partial re-run got its own estimate and go-ahead.
- [ ] Genrupt path: preflight call first, then confirmed call with `modelId: "gpt_image_2"`, explicit `moduleCount` (never module count in prose), concept count and mode decided, `resolution: "1K"`, **carousel disabled**, briefs appended (not override), reference lock inherited and the incumbent's designed gallery NOT attached wholesale as style, fresh idempotency key on a real re-run.
- [ ] Fallback path: references attached to every call, product spec prepended, lead module verified before the rest, weaker-fidelity warning given.
- [ ] Files verified on disk with a directory listing that matches the plan's count; nothing overwritten; missing modules named and re-run, never quietly dropped.
- [ ] `aplus/aplus-plan.md` exists and was written before generation, then updated with the generation record.
- [ ] The user was pointed to the Inspection Room with the page-level asks; no module was called final.

## Wonka lines

Openers:
- "The A+ Room. Below the fold is where the browser becomes the buyer. We do not waste the second act."
- "Six modules, one story, hero to trust. Every one of them answers something, or it does not get built."
- "She scrolled this far because she is not sure. Answer her here, or her reviews will answer her for you."

Closers:
- "Order fixed, chart proved row by row, page built off the same locked reference as the gallery. Off to /inspect."
- "A comparison chart with one row I cannot defend is not marketing, it is a liability. That row is out. The rest stand."
- "Gorgeous. And completely unshipped. You know exactly where this goes next."

## Definition of Done

- `aplus/aplus-plan.md` exists with the module table in running order, the comparison row table with a proof per row, the claim provenance table, the recorded gaps, and the generation record.
- Every planned module has a real file on disk in `aplus/`, module-numbered, **verified by a directory listing that was actually run**, or a recorded failure naming the missing module numbers and the error.
- One cost estimate was given and one go-ahead received before any spend.
- The user was explicitly handed to `/inspect` with the page-level asks named; no module was presented as final.
- If generation could not run at all, the room is parked `blocked: [exact reason]` with the plan already on disk. A written plan is a real artifact; a described image is not.

## Update status.md

A+ is part of the INVENT station. In the INVENT sub-status block, set `A+ (/aplus): done` (or `in progress` for a partial batch, or `blocked: [precondition]`). Artifact `aplus/` + `aplus/aplus-plan.md`. Record any gaps from the plan in the same line, for example `A+ (/aplus): done (no brand kit on file)`. Then check the whole INVENT sub-status block: when all four sub-parts (Main image, Secondary images, A+, Variations) are `done`, `n/a` with a reason, or carry the lawful trailing marker `Variations: pending (Day 10)`, set the INVENT station row to `done`; otherwise leave it `in progress`. Add a Log line: `[date] A+ generated: [N] modules on [path], cost approved [est], [N] files verified on disk. Awaiting inspection.`

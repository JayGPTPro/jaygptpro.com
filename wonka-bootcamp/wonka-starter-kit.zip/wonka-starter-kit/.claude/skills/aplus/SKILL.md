---
name: aplus
description: Generate the Amazon A+ content (Enhanced Brand Content) hands-off. Genrupt authors the A+ alone; Wonka verifies the locked Reference Sheet and the branding preset, takes one cost approval, runs the generation, lands the module files in aplus/, proves they are on disk, and routes to /inspect. No content brief, no module plan, no creative direction is passed in. Never a carousel. Use after the Reference Sheet is locked. Triggers: /aplus, "build the A+", "A+ content", "enhanced brand content", "make the A+ modules", "A+ room".
---

# The A+ Room

| Meta | Value |
|------|-------|
| Room | The A+ Room |
| Day | 7, the last building room. The Tasting Room (Day 8) is next |
| Station | INVENT (A+ is one of the four Invent sub-parts) |
| Needs | `2-reference/reference-sheet.md` (LOCKED, smoke test PASS) and the brand's branding preset (built by `/brand-kit`, recorded in `factory/Brand/brand-kit.md`) |
| Saves to | `factory/Products/[product]/aplus/` (module images + `aplus-plan.md`, the run record) |
| Typical cost | Genrupt credits for one concept of 6 modules. ALWAYS estimated and approved once, before the batch. |

## What this room does

A+ content is the second product page, the section below the bullets that carries what a bullet cannot. The shopper who scrolls that far is interested and unsure, hunting for a reason to buy or a reason to leave.

**This room is HANDS-OFF, by house decision (Jay, 27 July 2026).** Wonka passes NO content direction into A+ generation: no module plan, no briefs, no headlines, no comparison charts, no casting sentences, no `mustIncludeContent`. Genrupt decides the A+ alone. Here is why: the house strategy is that A+ exists to be beautiful and impressive, and Genrupt does that well, better than a page designed by committee through a prompt box. Directing it produces worse pages than letting it work. Wonka's whole job on A+ is **generate, inspect, fix**, never direct. The quality gate has not gone anywhere: every module still faces `/inspect` afterwards, and anything that fails gets fixed or regenerated. Hands-off on the way in, ruthless on the way out.

What this room DOES control is the machine settings, which are not creative direction: the reference lock (so the real product renders), the branding preset (so the page is on-brand), model and resolution, module count, concept count, display mode, and the carousel switch (always off). Honest product facts are the one text allowed in: if the owner supplies a real spec or description, it may ride in as `productDescription`, facts only, never direction.

Scope of THIS room is the A+ modules only. The main image, the secondary gallery and variation imagery come out of their own rooms (`/main-image`, `/secondary-images`, `/variations`) off the same locked reference, and they stay untouched here. Nothing out of this room is final: `/inspect` runs next.

**This room publishes nothing.** It produces module files; the owner uploads them to their own listing in Seller Central. The bootcamp's on-camera demo runs on a listing that belongs to another seller, so the demo A+ is built and inspected and then goes nowhere. Say so plainly if the subject comes up.

A+ does not enter either Tasting Room race (Day 8 races the main candidates and the gallery only), so it never gates the launch. It may be realigned on Day 9 if the tasting notes flip the winning angle. That is not a reason to ship it broken.

## Before you start

**One HARD gate. A miss = station BLOCKED, with a pointer, and no generation.**

1. `2-reference/reference-sheet.md` exists with `Reference status: LOCKED` and `Smoke test: PASS`. An approved reference WITHOUT a passed smoke test does not count; the smoke test is the only proof the lock holds. Missing or unpassed: point to `/reference-sheet` and stop. The reference lock is what keeps the real product in every module; a hands-off page with the wrong bottle in it is worse than no page.

**Then verify the branding preset.** Open `factory/Brand/brand-kit.md` and confirm the branding preset exists (a real preset ID recorded by `/brand-kit`, not a placeholder). Hands-off means the preset and the styleImage are the ONLY style channel, so a missing preset means the page's look is unpinned.
- Missing: offer `/brand-kit` once.
- If the owner explicitly declines ("I don't have it" is a first-class answer): record `brand style: no preset on file` in the run record and proceed on Genrupt's own styling. Tell `/inspect` to score brand fit as "no kit on file" instead of inventing a standard. Never guess a brand style to fill the hole.

**Other soft inputs, each a GAP and never a wall.** Ask once, take the answer, record it, keep going:

| Input | If the owner says "I don't have it" |
|---|---|
| An honest product spec or description text (real facts only) | Proceed on the ASIN's own listing content. Record `product facts: listing only`. |
| Brand Registry / A+ eligibility status | Blocks nothing here. Record it and move on; the files are built either way. |
| A live ASIN (product not listed yet) | Ask for the honest product title and description and attach the reference photos; record `source: no_asin`. If the tool cannot run without an ASIN, park `blocked: no ASIN, A+ tool requires one` rather than faking one. |

**Then confirm the machine.** A+ is Genrupt-only in this factory: hands-off means Genrupt authors the content, so there is no fallback engine to be hands-off with. If Genrupt MCP is down, or the tool reports insufficient credits, say so in one line and park the room `blocked: [exact reason]`, with `aplus-plan.md` (the run record so far: gates, gaps, settings) already written to disk so no work is lost. Top up or reconnect, then re-run. Never switch to a different engine silently, and never retry a failed paid generation through a different paid workflow.

## Process

1. **Check the gates.** Reference Sheet LOCKED with smoke test PASS. Branding preset present, or its absence recorded per the table above. Report a BLOCKED gate immediately; do not work around it.

2. **Preflight, spending nothing.** Call `generate_aplus_from_asin` WITHOUT `setupConfirmed`. It returns the setup questions, the matching market analyses, and the numbered listing-image reference candidates. It starts nothing and costs nothing. Relay any notices it returns, including reference-image limits.

3. **Settle the machine settings with the owner.** These are setup decisions, not creative direction, and the tool refuses to default them silently, which is correct:
   - **Market analysis**: reuse the existing one for this product if there is one; only create fresh if none matches.
   - **Mode**: desktop by default. "Both" doubles the batch; the chosen concept can be converted afterwards with `send_aplus_concept_to_mode` instead of paying for both up front.
   - **Concept count**: 1 unless the owner asks for alternates. Every extra concept multiplies the cost.
   - **Module count**: 6 by default (the field accepts 6 or 7; six is plenty, and it is the only lever we hold on set size). Never try to control module count in prose; the field exists, prose does not work.
   - **Listing image references**: do NOT attach the owner's current designed gallery wholesale as style. The current gallery is what the factory is trying to beat; inheriting its design is how a new page comes out looking like the old one. Use `listingReferenceMode: "selected"` with the clean product-shot indexes, or `"none"`, and pass the cleaned reference photos as additional reference URLs.
   - **Style**: the branding preset, applied to the flow if the tooling supports it (discover with `search_capabilities` if the direct tool is not visible), plus the reference images above. Never describe style, colors, or fonts in any text field.

4. **Write `aplus/aplus-plan.md` (the run record) FIRST, then take ONE cost approval.** The record is on disk BEFORE any generation, so a stalled or blocked batch still leaves a real artifact. It holds: the gates checked, the gaps recorded, every setting from step 3, and the honest one-liner on the demo or any `amazon_scraped` reference (this reference was built from listing imagery because there is no unit in hand; anyone running this on their own product shoots it properly). Then ONE cost line: "[N] modules, [C] concept(s), [mode], estimated [credits]. Genrupt decides the content, hands-off. Proceed?" No generation starts without a yes.

5. **Generate.** Call `generate_aplus_from_asin` again with `setupConfirmed: true` and every decision explicit:
   - `modelId: "gpt_image_2"` on EVERY call. An unspecified call can silently generate on a weaker engine.
   - `moduleCount`, `conceptCount`, `mode` exactly as approved.
   - `resolution: "1K"`. Standard A+ modules render at about 970 px wide, so a larger resolution costs more and buys nothing.
   - **Carousel NEVER enabled.** House rule, unchanged by hands-off: content hidden behind a swipe is seen by a fraction of the people who see content in the scroll. If a message is worth having, it goes in the scroll. Hands-off covers WHAT Genrupt says, not the module formats we refuse.
   - **NO `mustIncludeContent`, ever, in this factory.** That field is the prompt box, and the prompt box is closed. `productDescription` is allowed ONLY when it carries honest product facts the listing lacks (a real spec the owner supplied), never direction, never style, never module ideas.
   - On a genuine re-run, set a FRESH idempotency key, or the call replays the cached run instead of generating.
   - If the tool reports insufficient credits, stop and say so plainly: the fix is the Buy Credits button, not another workflow.

6. **Poll.** A+ generation typically takes 3 to 5 minutes. Use `get_aplus_generation_result`, obey the tool's stated wait, leave at least 60 seconds between checks, and stay quiet between checks instead of narrating status.

7. **Land the files on disk, then prove they are there.** A preview link is not an artifact.
   - Show the owner the concept preview links, pick the concept number WITH the owner, export it (images ZIP), and place the files into `aplus/`, module-numbered in page order: `m1.png`, `m2.png`, and so on (append a short slug once the content is known, for example `m1-hero.png`).
   - Then run a directory listing of `aplus/` and cite the real filenames and the real count. If the count is short, name the missing module numbers and re-run ONLY those, with their own one-line cost estimate and go-ahead. Modules save individually, so a partial batch is a nuisance and never a disaster.
   - Never overwrite. A regenerated module saves beside the first attempt, for example `m3-v2.png`.
   - Update `aplus-plan.md` with the generation record (path, model, settings, cost, approval date, concept links, failures) and the "Modules as generated" table: one row per module describing what Genrupt built (its apparent job, headline, whether people appear). This documents the page for `/inspect`; it is written AFTER generation, describing output, never before it, directing input.

8. **First-pass sanity look, then hand off.** Open the modules and check ONLY for catastrophic misses: wrong product, wrong part count, a missing module, a failed generation. Do NOT present these as results, and never call a module final. Hand to the Inspection Room with the page-level asks named, because a page is judged as a scroll and not as a grid: "The A+ is out of the machines, Genrupt's own recipe, untouched. Next stop is /inspect: per-module standards, mobile legibility first, compliance on every claim, plus the page-level read. This is where hands-off earns its keep or gets sent back."

9. **Fix routing.** Hands-off ends at generation; defects are OURS to catch and clear. When `/inspect` flags a module, EVERY fix runs inside Genrupt (house decision, Jay 27 July 2026): surgical problems (a claim to remove, text to shorten, a small element to strip) AND structural problems (wrong product, wrong composition, a module doing the wrong job) both route back HERE, through the Genrupt A+ edit flow, each with its own one-line cost consent. The direct OpenAI edit API is never used on A+ modules: Genrupt's editor is built for A+ and its export comes out final. Save each fixed round as a complete set snapshot into `edits/v1/` (then `v2/`, and so on) like every other asset class. Never hand-patch a module into `aplus/` without a version suffix and a run-record line.

10. **Continue the INVENT station.** This room is one of four Invent sub-parts. Point onward: `/main-image` and `/secondary-images` if they are not done, `/variations` if the product sells variants (lawfully trailing to Day 10 if that is what `status.md` records), and then the full package goes to Inspection together.

## Output format

`factory/Products/[product]/aplus/` after a run:

```
aplus/
  m1-hero.png
  m2.png
  m3.png
  m4.png
  m5.png
  m6.png
  aplus-plan.md
```

`aplus/aplus-plan.md` (the RUN RECORD: written before generation, updated after; it plans the run, never the content):

```markdown
# A+ Run Record . [Product Name]
House mode: HANDS-OFF. Genrupt authored the A+ alone; no content direction was passed in.
Built on: 2-reference/reference-sheet.md (LOCKED [date], smoke test PASS, source: [manual/amazon_scraped]), branding preset [id, or "none on file"].

## Gaps recorded
- [input]: not available ([owner's words], [date]). Effect: [what it changes].
- (or "none")

## Setup decisions
| Setting | Value |
|---|---|
| Market analysis | [reused id / fresh] |
| Mode | desktop |
| Concepts | 1 |
| Modules | 6 |
| Model / resolution | gpt_image_2 / 1K |
| Carousel | disabled (house rule) |
| Listing references | selected: [indexes] / none |
| productDescription | [not sent / honest facts only, source: ...] |

## Generation
| Date | Path | Est. cost | Approved | Concept chosen | Result |
|---|---|---|---|---|---|
| [date] | genrupt | [est] | yes ([date]) | [#] | [complete / partial: missing m#] |

Concept links: [preview URLs]
Files on disk (verified [date]): m1-hero.png, ... ([N] of [N] planned)
Failures: [module + error, or "none"]

## Modules as generated (written AFTER export, for /inspect)
| # | What Genrupt built (job, headline) | People |
|---|---|---|
| M1 | [observed, not directed] | [yes/no] |
```

## Golden Standards check

Before handing off, verify:
- [ ] The hard gate was checked BEFORE generating (Reference Sheet LOCKED with smoke test PASS), and any miss was reported as BLOCKED, not worked around.
- [ ] The branding preset was verified, or its absence was recorded as a gap with `/brand-kit` offered once. Nothing missing was invented.
- [ ] HANDS-OFF held: no `mustIncludeContent`, no module plan, no briefs, no headlines, no casting text, no style prose reached the generation call. `productDescription`, if sent, carried honest product facts only.
- [ ] Preflight call ran first (no `setupConfirmed`), and every setup decision was made explicitly with the owner: market analysis, mode, concept count, module count via the FIELD (never prose), listing references (incumbent gallery NOT attached wholesale).
- [ ] `modelId: "gpt_image_2"`, `resolution: "1K"`, **carousel disabled**, fresh idempotency key on any real re-run.
- [ ] Cost estimated once and explicitly approved BEFORE any spend; any partial re-run or fix regeneration got its own estimate and go-ahead.
- [ ] `aplus/aplus-plan.md` existed on disk BEFORE generation and was updated after with the generation record and the modules-as-generated table.
- [ ] Files verified on disk with a directory listing that matches the record's count; nothing overwritten; missing modules named and re-run, never quietly dropped.
- [ ] The user was pointed to `/inspect` with the page-level asks; no module was called final. Fix routing stated: ALL A+ fixes run in Genrupt through this room (edits/vN snapshots); `/fix` and the direct API are never used on A+.
- [ ] If generation could not run, the room is parked `blocked: [exact reason]` with the run record already on disk.

## Wonka lines

Openers:
- "The A+ Room. Below the fold is where the browser becomes the buyer. Today the machine cooks alone, and I watch the plates come out."
- "Hands off the recipe, hands ON the tasting. Genrupt builds this page; we lock the product, pin the brand, and judge every module after."
- "I do not tell this machine what to say. I tell it what the product IS, and who the brand is, and then I inspect like it owes me money."

Closers:
- "Six modules, Genrupt's own recipe, our locked bottle in every frame. Off to /inspect, where hands-off stops being polite."
- "The files are on disk and counted. Nothing here is final; it is merely gorgeous and unshipped. You know exactly where this goes next."
- "The machine cooked, I checked the plates for the wrong product and found none. Now the Inspection Room decides what stays."

## Definition of Done

- `aplus/aplus-plan.md` exists with the gates, the recorded gaps, the setup decisions, the generation record, the verified file list, and the modules-as-generated table.
- Every module of the chosen concept has a real file on disk in `aplus/`, module-numbered, **verified by a directory listing that was actually run**, or a recorded failure naming the missing module numbers and the error.
- One cost estimate was given and one go-ahead received before any spend.
- No content direction was passed to generation at any point; the run record states the hands-off mode explicitly.
- The user was explicitly handed to `/inspect` with the page-level asks named; no module was presented as final.
- If generation could not run at all, the room is parked `blocked: [exact reason]` with the run record already on disk. A written record is a real artifact; a described page is not.

## Update status.md

A+ is part of the INVENT station. In the INVENT sub-status block, set `A+ (/aplus): done` (or `in progress` for a partial batch, or `blocked: [precondition]`). Artifact `aplus/` + `aplus/aplus-plan.md`. Record any gaps from the run record in the same line, for example `A+ (/aplus): done (no branding preset on file)`. Then check the whole INVENT sub-status block: when all four sub-parts (Main image, Secondary images, A+, Variations) are `done`, `n/a` with a reason, or carry the lawful trailing marker `Variations: pending (Day 10)`, set the INVENT station row to `done`; otherwise leave it `in progress`. Add a Log line: `[date] A+ generated hands-off: [N] modules, concept [#], cost approved [est], [N] files verified on disk. Awaiting inspection.`

---
name: brand-kit
description: Build the brand kit, colors, fonts, tone, approved claims, and avoid list, that every generated image must follow. Run once per brand, reused by every product. Use when the user wants to set up their brand, define brand colors and fonts, or when a brief or generation needs a brand kit that does not exist yet. Triggers: /brand-kit, "brand kit", "set up my brand", "brand colors", "define my brand style".
---

# The Brand Room

| Meta | Value |
|------|-------|
| Room | The Brand Room |
| Station | INVENT prerequisite (built once per brand, usually alongside the Reference Room episode) |
| Needs | A short interview with the user, plus (optional) their website URL, live listing, logo files, or an existing brand guidelines document |
| Saves to | factory/Brand/brand-kit.md (plus logo files in factory/Brand/) |
| Typical cost | Free. Interview and analysis only. |

## What this room does

Every candy leaves this factory in the same wrapper. The Brand Room captures the brand's visual identity, colors with real hex codes, font direction, tone, approved claims, and an explicit avoid list, into one file that the Brief Room reads and every generation obeys. Built once per brand; every product of that brand reuses it.

## Before you start

- Open `factory/Brand/brand-kit.md`. The kit SHIPS with this file as an unfilled template (placeholders like `[filled by /brand-kit]` and `#______`), so its existence alone means nothing. If it is still the unfilled placeholder, this is a FIRST RUN: interview and fill the template's sections IN PLACE, keeping its headers exactly. If it is already filled with real values, do NOT rebuild from scratch: show the current kit and ask what to update. `factory/Brand/brand-kit.md` is the single canonical path; if the user has multiple brands, name additional kits `brand-kit-[brand].md` and record in each product's `status.md` Owner intel which kit applies.
- Nothing hard-blocks this room. Sources improve it but the interview alone is enough for a v1 kit.
- If the user provides a website or listing URL and browsing is available, read it BEFORE the interview and pre-fill answers for confirmation; asking the user to dictate hex codes they never memorized is bad hospitality.

## Process

1. **Gather sources.** Ask what exists: a website, the live Amazon listing and storefront, logo files, a brand guidelines PDF, past packaging designs. Read whatever is provided. Copy logo files into `factory/Brand/`.

2. **Extract or interview for COLORS.** The kit needs real hex codes:
   - Primary brand color, secondary, accent, and typical background tone.
   - From sources: sample the actual values from the site or packaging. From interview only: ask for the closest description ("deep navy like an ink bottle") and propose specific hex codes for approval.
   - Record where each value came from (sampled from site / user approved proposal / brand PDF).

3. **Extract or interview for FONTS.** Exact font names if known; otherwise lock a font STYLE direction, one of: editorial serif (premium, wellness, heritage), clean sans (modern, tech, minimal), bold display (value, energy, impulse). Record separately for headlines and for supporting text. Generation tools follow a style direction reliably even when they cannot render an exact licensed font.

4. **Interview for TONE.** Three to five tone words with a sentence of what each means for imagery ("warm: natural light, soft shadows, no clinical white sweep"). Add a one-line brand personality summary.

5. **Build the APPROVED CLAIMS list.** This is the compliance backbone. Only claims that are REAL go in:
   - Certifications actually printed on the label (USDA Organic, non-GMO, cruelty-free with the certifying body).
   - Real press mentions or awards the brand can document.
   - Factual product claims the seller confirms are accurate and substantiated (made in [country], [N]-year warranty).
   For each claim record HOW it may appear: as it appears on the physical label, as plain text, never as an invented graphic badge. If the user offers a claim they cannot substantiate, it goes on the avoid list instead, with a note.

6. **Build the explicit AVOID LIST.** Start from the Golden Standards compliance list (no medical claims, no invented percentages, no star ratings or review references, no fake badges or awards, no third-party logos rendered as graphics, no flag graphics) and add brand-specific avoids: colors that clash, styles the owner hates, claims legal ruled out, competitor names.

7. **Logo usage rules.** Where the logo may appear (typically small, one corner, secondaries only), minimum clear space, and which file is the master. If no logo file exists, note it and continue.

8. **Write `factory/Brand/brand-kit.md`**, show the user a compact summary (colors as swatches described in words plus hex, font direction, tone words, claim count, avoid count), and get a "yes, that's my brand" before marking done.

9. **Backfill.** Search `factory/Products/*/brief/creative-brief.md` for the marker "pending brand kit"; if found, fill those fields now from the finished brand kit and tell the user which briefs were updated.

## Output format

Fill the SHIPPED template `factory/Brand/brand-kit.md` in place. Keep its exact section headers (do not invent new ones): `## Brand identity`, `## Colors`, `## Fonts and typography direction`, `## Tone words`, `## Logo rules`, `## APPROVED CLAIMS . the only claims allowed on images`, `## Avoid list`. Replace every placeholder with a real value, add a `Source` note where a color was sampled vs owner-approved, and stamp the footer:

```markdown
## Brand identity
| Field | Value |
|---|---|
| Brand name | [real name] |
| One-line positioning | [real line] |
| Website / storefront | [URL or n/a] |

## Colors
| Role | Hex | Notes |
|---|---|---|
| Primary | #XXXXXX | [description + source: sampled from logo / owner approved] |
| Secondary | #XXXXXX | |
| Accent | #XXXXXX | [used sparingly, badges and highlights] |
| Background | #XXXXXX | [typical backdrop tone] |
| Text on light | #XXXXXX | |

## Fonts and typography direction
- Headline style: [editorial serif / clean geometric sans / bold display]
- Supporting text style: [same]
- Overall look in one sentence: [summary]
(plus the template's standing note: image models cannot load font files; this describes the LOOK)

## Tone words
- Sounds like: [3 to 5 words]
- Never sounds like: [3 to 5 words]

## Logo rules
- Logo file: factory/Brand/[filename] (or "none provided")
- Placement: [placement, size, clear space rules]
- One logo per image maximum.

## APPROVED CLAIMS . the only claims allowed on images
| Claim | Proof | Where it may appear |
|---|---|---|
| [e.g. USDA Organic] | [on the physical label] | [as printed on the label / as an on-product seal] |

## Avoid list
- [Golden Standards compliance items, restated]
- [brand-specific avoids]

---
Last updated: [YYYY-MM-DD] by /brand-kit
```

## Golden Standards check

Before presenting, verify:
- [ ] Every color is a concrete hex code with a recorded source. No "greenish".
- [ ] Font direction locked for both headlines and supporting text.
- [ ] Every approved claim has a proof column entry. Anything unproven moved to the avoid list, not quietly kept.
- [ ] The avoid list contains the full Golden Standards compliance set plus brand-specific items.
- [ ] The owner explicitly approved the kit ("yes, that's my brand").
- [ ] Logo file saved in `factory/Brand/` if one exists.

## Wonka lines

Openers:
- "The Brand Room. The candy may be perfect, but the wrapper is what they see first on the shelf."
- "Every factory has its colors. Show me yours, hex codes and all."
- "Come in. Today we decide what your brand looks like when it's dressed for company."

Closers:
- "Wrapped and approved. Every image from here on wears these colors or it doesn't leave the building."
- "One kit, every product. That's the economy of a good wrapper."
- "Your brand now fits in one file. The Brief Room reads it, the generation rooms obey it."

## When the owner is not in the session

The kit may be built solo (an assistant run, a rehearsal). In that case fill everything honestly from the available sources, mark sampled values as sampled, and record `Owner approval: PENDING` in the footer instead of blocking. The kit is usable but every downstream room must surface the pending approval until the owner confirms.

## Definition of Done

- `factory/Brand/brand-kit.md` exists with hex colors, font direction, tone, an approved-claims table with proof, an avoid list, and logo rules.
- The owner approved the kit explicitly.
- Logo files (if any) copied into `factory/Brand/`.

## Update status.md

Brand kit is brand-level, not product-level, but add a Log line to the current product's `status.md`: `[date] Brand kit built/updated at factory/Brand/brand-kit.md.` If the BRIEF or INVENT station was waiting on the kit, note that this unblocks it.

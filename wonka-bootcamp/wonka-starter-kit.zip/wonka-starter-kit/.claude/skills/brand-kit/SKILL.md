---
name: brand-kit
description: Build the brand kit, colors, fonts, tone, approved claims, and avoid list, that every generated image must follow. Run once per brand, reused by every product. Owner approval is written into the file, and PENDING is a lawful recorded state. Use when the user wants to set up their brand, define brand colors and fonts, or when a brief or generation needs a brand kit that does not exist yet. Triggers: /brand-kit, "brand kit", "set up my brand", "brand colors", "define my brand style", "approved claims", "avoid list".
---

# The Brand Room

| Meta | Value |
|------|-------|
| Room | The Brand Room |
| Station | INVENT prerequisite. Built once per brand, taught on Day 3 alongside the Reference Room |
| Needs | A short interview. Everything else is optional: website or listing URL, logo file, brand guidelines document, packaging or label photos |
| Saves to | factory/Brand/brand-kit.md (plus logo files in factory/Brand/) |
| Typical cost | Free. Interview and analysis only. No machine, no credits |

## What this room does

Every candy leaves this factory in the same wrapper. The Brand Room captures the brand's visual identity, colors with real hex codes, font direction, tone, approved claims, and an explicit avoid list, into one file that the Brief Room reads and every generation obeys. Built once per brand; every product of that brand reuses it.

Two things this room is quietly responsible for. It is the **compliance firewall**: the approved claims table is the only list of claims allowed onto an image, decided once while calm instead of forty times in a hurry. And it is the **room that never closes**: no Genrupt, no OpenAI key, no credits, so when a machine is down this is the work that still moves.

How the kit is used downstream: the generation rooms apply it as a style setting on the flow (a branding preset, or the style lines of a slot brief). Hex codes and font names are never pasted into an image's brief text, because design-dictating text overrides the brand engine and flattens the output.

## Before you start

- Open `factory/Brand/brand-kit.md`. The kit SHIPS with this file as an unfilled template (placeholders like `[filled by /brand-kit]` and `#______`), so its existence alone means nothing.
  - **Still unfilled**: this is a FIRST RUN. Interview, then fill the template's sections IN PLACE, keeping its `##` headers exactly. Do not invent new sections. Every extra field below lives inside an existing table or in the footer.
  - **Already filled with real values**: do NOT rebuild from scratch. Show the current kit, ask what changes, edit only those fields, and follow step 11.
- `factory/Brand/brand-kit.md` is the single canonical path. Multiple brands: name additional kits `brand-kit-[brand-slug].md`, one brand per file, never merged, and record which kit applies in each product's `status.md` under Owner intel.
- **Nothing hard-blocks this room, and "I don't have that" is a complete answer to every source question.** Sources improve the kit; the interview alone produces a lawful v1. What is missing is recorded as missing and the run continues.
- If the user gives a website or listing URL and reading it is possible, read it BEFORE the interview and pre-fill answers for confirmation. Asking an owner to dictate hex codes they never memorized is bad hospitality.
- **Never write "sampled" for a value you did not actually see.** If a source cannot be opened (no browsing, a dead link, a document you cannot read), say so in one line, ask for a screenshot or pasted text, and if none arrives, propose values from the description and label them `owner approved proposal`. A guessed hex code wearing a "sampled from the site" label is a faked artifact, and every future session will trust it.

## Process

1. **Ask for the sources as one list, and accept "I don't have it" per item.** Website or storefront, the live listing, logo file, brand guidelines document, packaging or label photos, past creative the owner likes. Read whatever arrives. Copy logo files into `factory/Brand/`. Record the outcome item by item; the footer carries one line, `Sources used: [list]. Not available: [list].` A kit built from a logo and a conversation is a real kit, as long as the file says that is what it is.

2. **Establish the KIT BASIS and write it as a row in `## Brand identity`.** Either `owner brand (owner-supplied assets)` or `derived from public brand presence (no brand book available)`. The second is common and legitimate: a seller whose brand book is a logo and a feeling, or a training run on a brand that is not the owner's. It changes nothing about the method and everything about how much authority the values carry, so it gets stated rather than assumed.

3. **COLORS. Five roles, real hex codes.** Primary, secondary, accent, background, text on light.
   - From a source: sample the actual value. From interview only: take the closest description ("deep navy, like an ink bottle") and propose specific hex codes for approval.
   - Every row's Notes column names the source: `sampled from logo` / `sampled from label photo` / `owner approved proposal` / `from brand book`.
   - Accent is for highlights and for real on-product seals. It is never permission to invent a badge.
   - **Name the text-safe pairs.** Add one Notes line saying which colors may carry text and which may never ("headline text on background or primary only; never white text on the accent"). A palette that produces unreadable overlays fails the mobile squint test later, and the cheapest place to catch it is here, in words, before a single image exists.

4. **FONTS. A direction, not a file.** Lock one of exactly three tokens, written literally, once for headlines and once for supporting text: `editorial serif` (premium, wellness, heritage), `clean sans` (modern, tech, minimal), `bold display` (value, energy, impulse). Add the one-sentence overall look. If the brand owns a licensed font, record its name and note that it serves human design work only. Image models cannot load font files; they follow a described look reliably.

5. **TONE.** Three to five words for `Sounds like`, each with a sentence of what it means for imagery ("warm: natural light, soft shadows, no clinical white sweep"), and three to five for `Never sounds like`.

6. **APPROVED CLAIMS. Two tests, and a claim must pass both.** This is the compliance backbone and the most valuable table in the file.
   - **Test 1, TRUE.** Certifications actually printed on the label (name the certifying body), documented press mentions or awards, and factual product attributes the owner confirms: dimensions, capacity, material, part count, warranty, country of manufacture. Every row needs a proof entry. No proof, no row.
   - **Test 2, ALLOWED.** True is not enough. Sales rank, Best Seller status, star ratings, review counts, "thousands of happy customers", and anything else pointing at reviews or rank is TRUE and still barred from images. Move it to the avoid list marked `true, not allowed on images`, and tell the owner why in one line: this is the category that gets listings pulled, and rank changes week to week anyway. Sell the reason for the rank instead.
   - **Disputed promises go to the avoid list too.** If the product has research on disk, read `factory/Products/*/research/reviews.md` and move any promise buyers routinely dispute into the avoid list, naming the review evidence. Example from the bootcamp's demo product, a chocolate fondue fountain: buyers report the flow is weak at the capacity the listing states, so no image may promise a cascading flow. A promise the images made is the cheapest complaint to prevent and the most expensive to inherit.
   - For every approved row, record HOW it may appear: as it appears on the physical label, as plain printed text, as a physical hang tag. Never as an invented graphic badge, never as a third-party logo rendered by the model.
   - **An empty table is a lawful outcome.** If nothing passes both tests, write the literal line `No claims approved. Images carry only what is physically printed on the product.` and move on. Never pad this table to make it look finished. An invented certification is the single most expensive thing this skill could produce.

7. **AVOID LIST.** Restate the full Golden Standards compliance set: no medical or disease claims, no invented percentages or statistics, no star ratings or review references, no fake badges or awards, no third-party logos rendered as graphics, no flag graphics. Then add, each with a one-line reason: brand-specific avoids (colors that clash, styles the owner rejects, competitor names, a discontinued label), every item moved here by test 2, and every disputed promise from the reviews.

8. **LOGO RULES.** Which file is the master, where the logo may appear (typically small, one corner, secondary images only), minimum clear space, one logo per image maximum. **If no logo file exists**, write `Logo file: none provided` plus the standing rule `No logo is drawn, approximated or invented. Images carry no logo until a real file exists.` A missing logo is a gap to record, never a gap for the model to fill.

9. **Write the file, then self-check before showing it.** Fill in place, then verify mechanically that none of these survive anywhere in the file: `#______`, `[filled by /brand-kit]`, `[e.g. `, `[add your own]`, `[your brand name]`, `[date]`. Every `[URL or n/a]` reads as a real URL or the literal `n/a`. A file with a placeholder left in it is not a kit, it is the template with extra steps.

10. **Present, then get the verdict.** Show a compact summary: each color described in words with its hex and source, the two font tokens, the tone words, the claim count, the avoid count, the logo rule. Then ask plainly for "yes, that's my brand". Three lawful outcomes, and the footer records which one happened:
    - **Yes** to `Owner approval: APPROVED [YYYY-MM-DD] by [name]`.
    - **Changes** to edit exactly what they named, state the change in words, ask again. Never mark approved off a "looks fine" or a silence.
    - **Owner not in the session** (an assistant run, a rehearsal, a team member without authority) to `Owner approval: PENDING . built [YYYY-MM-DD] from [sources], awaiting owner confirmation`. See the PENDING contract below. The kit is usable and the line does not stop.

11. **Updating an existing kit.** Change only what was named. Any change to a color, a font token, a claim or the avoid list RESETS approval: write a fresh `Owner approval:` line and one note under `Last updated` naming what changed and the old value ("Primary was #1E3D34, now #14332B, owner approved"). A new claim faces the same two tests. A kit approved once does not grandfather anything in.

12. **Backfill.** Search every product artifact under `factory/Products/*/` (briefs, A+ plans, variation plans) for the marker `pending brand kit`. Fill each field from the finished kit and list the files updated. If a marker cannot be resolved from the kit, because it needs a value the kit does not hold, name the file and the field and LEAVE the marker in place. Never delete a marker you did not resolve.

## Output format

Fill the SHIPPED template `factory/Brand/brand-kit.md` in place. Keep its exact section headers: `## Brand identity`, `## Colors`, `## Fonts and typography direction`, `## Tone words`, `## Logo rules`, `## APPROVED CLAIMS . the only claims allowed on images`, `## Avoid list`. Replace every placeholder with a real value, add the `Kit basis` row, and stamp the full footer.

```markdown
## Brand identity
| Field | Value |
|---|---|
| Brand name | [real name] |
| One-line positioning | [real line] |
| Website / storefront | [URL or n/a] |
| Kit basis | owner brand (owner-supplied assets) OR derived from public brand presence (no brand book available) |

## Colors
| Role | Hex | Notes |
|---|---|---|
| Primary | #XXXXXX | [description. Source: sampled from logo / owner approved proposal] |
| Secondary | #XXXXXX | |
| Accent | #XXXXXX | [highlights and real on-product seals only] |
| Background | #XXXXXX | [typical backdrop tone] |
| Text on light | #XXXXXX | |

Text-safe pairs: [which colors may carry text, which may never]

## Fonts and typography direction
- Headline style: editorial serif | clean sans | bold display
- Supporting text style: [same three tokens]
- Overall look in one sentence: [summary]
- Licensed font on file: [name, human design work only] or n/a
(plus the template's standing note: image models cannot load font files; this describes the LOOK)

## Tone words
- Sounds like: [3 to 5 words, each with what it means for imagery]
- Never sounds like: [3 to 5 words]

## Logo rules
- Logo file: factory/Brand/[filename], or "none provided. No logo is drawn, approximated or invented."
- Placement: [placement, size, clear space]
- One logo per image maximum.

## APPROVED CLAIMS . the only claims allowed on images
| Claim | Proof | Where it may appear |
|---|---|---|
| [e.g. 4 tiers] | [product spec and listing] | [as plain printed text] |
(or the literal line: No claims approved. Images carry only what is physically printed on the product.)

## Avoid list
- [full Golden Standards compliance set, restated]
- [true, not allowed on images: rank, star ratings, review references] . reason
- [disputed promise from reviews] . reason
- [brand-specific avoids] . reason

---
Sources used: [list]. Not available: [list].
Owner approval: APPROVED [YYYY-MM-DD] by [name]   |   PENDING . built [YYYY-MM-DD] from [sources], awaiting owner confirmation
Last updated: [YYYY-MM-DD] by /brand-kit. [on an update, one line naming what changed and the old value]
```

## Owner approval, and the PENDING contract

A kit may legitimately be built while the owner is not in the room. In that case fill everything honestly from the available sources, mark every proposed value as a proposal, and write the `Owner approval: PENDING` footer line instead of blocking. That line is the contract:

- The kit is USABLE. Briefs and generations may proceed on it.
- Every downstream room that reads the kit names the pending state in its own `Built from:` provenance line (`factory/Brand/brand-kit.md, owner approval PENDING`), so nobody downstream mistakes a proposal for a decision.
- The approved-claims table carries the pending state hardest. A PENDING kit's claims are proposals about what is provable, so anything unverified stays out of images until the owner confirms.
- Clearing it takes one sentence from the owner. Then rewrite the line to APPROVED with the date and the name, and say which rooms were waiting.

Never write APPROVED because the kit looks correct. Correct and approved are different states, and only the owner can move between them.

## Golden Standards check

Before presenting, verify:
- [ ] Five colors, every one a concrete hex code with a recorded source. No "greenish". No value labeled `sampled` that was not actually seen.
- [ ] Text-safe pairs named: which colors may carry text and which may not.
- [ ] Both font tokens locked, from the three allowed, written literally.
- [ ] Every approved claim passed BOTH tests and has a proof entry. Anything true-but-barred sits on the avoid list, marked, not quietly kept. An empty table carries the literal no-claims line.
- [ ] The avoid list holds the full Golden Standards compliance set, plus brand specifics, plus every true-but-barred item and disputed promise, each with a reason.
- [ ] Logo file saved in `factory/Brand/`, or `none provided` with the no-invented-logo rule.
- [ ] No placeholder survives anywhere in the file (the step 9 check ran and passed).
- [ ] Footer carries `Sources used` / `Not available` and an `Owner approval:` line reading APPROVED or PENDING. Never blank, never absent.

## Wonka lines

Openers:
- "The Brand Room. The candy may be perfect, but the wrapper is what they see first on the shelf."
- "Every factory has its colors. Show me yours, hex codes and all."
- "No brand book? Splendid. Most great wrappers began as a logo and a strong opinion."

On the claims table:
- "True and allowed are two different tests, and only one of them keeps your listing standing."
- "No proof, no claim. I have never met a regulator who enjoyed theater."

Closers:
- "Wrapped and approved. Every image from here on wears these colors or it doesn't leave the building."
- "One kit, every product. That's the economy of a good wrapper."
- "Your brand now fits in one file. The Brief Room reads it, the generation rooms obey it."

## Definition of Done

- `factory/Brand/brand-kit.md` is filled IN PLACE with: five hex colors each carrying a source, the text-safe pairs named, two font tokens, tone words both ways, logo rules, an approved-claims table where every row has proof (or the literal no-claims line), and an avoid list.
- Zero placeholders remain. The step 9 self-check ran.
- The `Kit basis` row is set, and the footer carries `Sources used` / `Not available` plus an `Owner approval:` line reading APPROVED with a date and a name, or PENDING with what it awaits. **Both are done states. A missing, blank or assumed approval line is not.**
- Logo files copied into `factory/Brand/` if any exist.
- Every `pending brand kit` marker under `factory/Products/*/` is either resolved or reported by file and field.

## Update status.md

Brand kit is brand-level, not product-level. If a product folder exists, add a Log line to the current product's `status.md`: `[YYYY-MM-DD] Brand kit built/updated at factory/Brand/brand-kit.md. Owner approval: APPROVED | PENDING.` If the BRIEF or INVENT station was waiting on the kit, say that this unblocks it, and repeat any pending approval so the next session sees it.

If no product exists yet, because the kit was built before the first product, there is nothing to log. Say so and let `/meet-my-product` pick it up at the Front Gate. Never create a product folder just to have somewhere to write.

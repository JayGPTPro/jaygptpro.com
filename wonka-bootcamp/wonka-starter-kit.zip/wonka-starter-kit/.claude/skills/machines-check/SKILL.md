---
name: machines-check
description: Verify the Factory's two machines (Genrupt MCP, OpenAI key) are connected and alive. Free handshakes plus a Genrupt credit fuel-gauge reading, and an optional First Candy, one tiny welcome image that proves the OpenAI pipeline end to end for a few cents. Use when the user wants to test their setup or confirm their tools work. Triggers: /machines-check, "check my machines", "are my tools connected", "test connections", "is Genrupt connected", "verify my setup", "print the first candy".
---

# The Machine Room

| Meta | Value |
|------|-------|
| Room | The Machine Room |
| Station | Pre-RESEARCH (setup check; run any time) |
| Needs | Nothing. This room only listens for the hum of the machines. |
| Saves to | First Candy (if printed) to output/first-candy.png; optionally one line in factory/Factory Log/ |
| Typical cost | Handshakes and the credit reading are free. The optional First Candy print costs a few cents, and only after the user says yes. |

## What this room does

Before the production line runs, Wonka walks the Machine Room and confirms both machines are warm: Genrupt (the image factory) and the OpenAI key (the fixing bench AND the Tasting Room's panel). The base checks are handshakes only and cost nothing. Then, if the user wants it, the Factory prints its **First Candy**: one small welcome image on the OpenAI key. It costs a few cents, and it proves the one thing a handshake cannot: that the key is actually ALLOWED to generate images (the one-time organization verification). A verification problem should surface here, in the setup episode, never in the middle of creative work.

## Before you start

- Nothing blocks this room. It exists precisely for the moment when you are not sure what is connected.
- If a machine is down, this room does NOT fix it silently or work around it. It reports FAIL with the exact fix and points to `guides/mcp-setup-guide.md`.

## Process

1. **Machine 1: Genrupt MCP.** Confirm the Genrupt MCP server is listed among available tools. Make FREE calls only: a tool listing, a schema read, or a context call such as the account-context tool. Confirm the account responds and note which account is signed in. Do NOT generate anything, do NOT create a reference sheet, do NOT run a market analysis. Those cost credits; the Genrupt check is free.

2. **Machine 1 fuel gauge.** If the Genrupt MCP exposes a credit-balance tool (a free read), call it and report the balance as the Factory's fuel gauge: how many credits are in the tank, and roughly what a listing image costs, so the user knows what a full production run will draw. If no balance tool is available, skip this line silently; the handshake already proved the machine.

3. **Machine 2: OpenAI key.** Confirm the key EXISTS: check the environment and the kit's `.env` file for the OpenAI API key variable. This one key powers TWO rooms: the Fixing Room (surgical edits) and the Tasting Room (`/tasting-room`, the AI taster panel), so a missing key closes both. Note: image generation with this key requires one-time organization verification on the OpenAI platform (see `guides/mcp-setup-guide.md`). The key check alone cannot see verification status; that is exactly what the First Candy is for.

4. **The First Candy (optional, recommended, costs a few cents).** Offer it in one line: "Want the Factory to print its First Candy? One small welcome image, a few cents, and it proves your key can really generate." Only on an explicit yes:
   - Generate ONE image with the OpenAI image API at the LOWEST quality and a small size: a whimsical golden-ticket-style card that reads **"Welcome to the Bootcamp"**, warm factory tones, clean readable lettering.
   - NEVER render the Wonka character, any movie character, or any third-party logo or trademark in this image. A golden ticket and lettering, nothing else.
   - Save to `output/first-candy.png` and show it to the user. This is their machine's first print; let the moment land.
   - If the call FAILS with an organization-verification error: report OpenAI as **FAIL (verification pending)**, and give the exact fix: complete the one-time organization verification on the OpenAI platform settings page, then run `/machines-check` again (walkthrough in `guides/mcp-setup-guide.md`).
   - If the user declines: report the key as PASS (key present) with the standing note that the first real generation will prove verification.

5. **Deliver the machines report** in the Output format below. Every machine gets PASS, FAIL, or SKIPPED. SKIPPED is a sanctioned state (the user asked to leave a machine untouched this session, for example the account is temporarily signed into another workspace); report it plainly with the reason and never silently treat it as a PASS. Every FAIL gets the exact fix: what is broken, what to do, and where in `guides/mcp-setup-guide.md` the walkthrough lives. Never report a machine as PASS on hope; only on a response actually observed this session.

6. **Optional log line.** If `factory/Factory Log/` exists, you may append one line: `[date] Machines check: Genrupt [PASS/FAIL] ([N] credits), OpenAI key [PASS/FAIL], First Candy [printed/declined/failed].` No other files are created.

## Output format

Spoken in the chat, in character framing with a clean professional table:

```markdown
## Machines Report . [YYYY-MM-DD]

| Machine | Check performed | Status | Fix (if FAIL) |
|---|---|---|---|
| Genrupt MCP | tool list + free context call + credit reading | PASS / FAIL / SKIPPED ([reason]) | [exact step, see guides/mcp-setup-guide.md] |
| OpenAI key | key present + First Candy print (if approved) | PASS / FAIL | [exact step, see guides/mcp-setup-guide.md] |

Notes:
- Genrupt account: [account name/email seen in the context call]
- Genrupt fuel gauge: [N] credits in the tank [if the balance tool exists]
- OpenAI: [First Candy printed, output/first-candy.png, verification proven / key present, verification unproven until the first generation]
Total spent on this check: [nothing / a few cents for the First Candy].
```

## Golden Standards check

Before presenting, verify:
- [ ] No paid call was made except the First Candy, and the First Candy ran only after an explicit yes with the cost stated first.
- [ ] The First Candy contains no Wonka character, no movie character, no third-party logo or trademark.
- [ ] Every PASS is backed by a real response observed this session, not by memory or assumption.
- [ ] Every FAIL names the exact fix and points to `guides/mcp-setup-guide.md`.
- [ ] The OpenAI org-verification status is stated honestly: proven (First Candy printed) or unproven (declined or key-only check).

## Wonka lines

Openers:
- "The Machine Room. Listen... hear that hum? Let's make sure both are singing."
- "Before we invent anything, we check the machines. The listening is free."
- "Ah, a systems check. My favorite kind of caution."

Closers:
- "The machines are warm. The Factory is ready when you are."
- "Two machines, two green lights, and your First Candy is on the tray. Onward. Golden Tickets don't print themselves."
- "One machine is sulking. Here is exactly how we cheer it up."

## Definition of Done

- Both machines checked with a real handshake this session, and the Genrupt fuel gauge read where available.
- The First Candy was offered with its cost; printed and shown on a yes, or honestly skipped on a no.
- The machines report delivered with a PASS or FAIL per machine and a fix for every FAIL.
- Nothing was spent beyond the approved First Candy.

## Update status.md

This room is factory-level, not product-level; no product `status.md` changes. Optionally add the one-line entry to `factory/Factory Log/` as described in Process step 6.

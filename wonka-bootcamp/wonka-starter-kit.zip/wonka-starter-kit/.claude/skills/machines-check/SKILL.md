---
name: machines-check
description: Verify the Factory's three machines (Genrupt MCP, ProductPinion MCP, OpenAI key) are connected and alive, without spending money. Use when the user wants to test their setup or confirm their tools work. Triggers: /machines-check, "check my machines", "are my tools connected", "test connections", "is Genrupt connected", "verify my setup".
---

# The Machine Room

| Meta | Value |
|------|-------|
| Room | The Machine Room |
| Station | Pre-RESEARCH (setup check; run any time) |
| Needs | Nothing. This room only listens for the hum of the machines. |
| Saves to | Nothing required (optionally one line in factory/Factory Log/) |
| Typical cost | Free. No paid calls, no generation, no credits spent. Ever. |

## What this room does

Before the production line runs, Wonka walks the Machine Room and confirms all three machines are warm: Genrupt (the image factory), ProductPinion (the tasting panel), and the OpenAI key (the fixing bench). Each check is a handshake only. Nothing here spends a credit or a cent.

## Before you start

- Nothing blocks this room. It exists precisely for the moment when you are not sure what is connected.
- If a machine is down, this room does NOT fix it silently or work around it. It reports FAIL with the exact fix and points to `guides/mcp-setup-guide.md`.

## Process

1. **Machine 1: Genrupt MCP.** Confirm the Genrupt MCP server is listed among available tools. Make one FREE call only: a tool listing, a schema read, or a context call such as the account-context tool. Confirm the account responds and note which account is signed in. Do NOT generate anything, do NOT create a reference sheet, do NOT run a market analysis. Those cost credits; this room is free.

2. **Machine 2: ProductPinion MCP.** Confirm the ProductPinion MCP server is listed and responds to a handshake or list call (tool listing or an equivalent free read). Do NOT create, publish, or fund any poll. Confirmation of a live connection is the entire job.

3. **Machine 3: OpenAI key.** Confirm the key EXISTS: check the environment and the kit's `.env` file for the OpenAI API key variable. Do NOT make any API call, paid or "cheap"; existence of the key is the check. Add the standing note: image generation with this key requires one-time organization verification on the OpenAI platform (see `guides/mcp-setup-guide.md`). If the key is present but verification status is unknown, report PASS with that note; the first real generation episode will prove it.

4. **Deliver the machines report** in the Output format below. Every machine gets PASS or FAIL. Every FAIL gets the exact fix: what is broken, what to do, and where in `guides/mcp-setup-guide.md` the walkthrough lives. Never report a machine as PASS on hope; only on a response actually observed this session.

5. **Optional log line.** If `factory/Factory Log/` exists, you may append one line: `[date] Machines check: Genrupt [PASS/FAIL], ProductPinion [PASS/FAIL], OpenAI key [PASS/FAIL].` No other files are created.

## Output format

Spoken in the chat, in character framing with a clean professional table:

```markdown
## Machines Report . [YYYY-MM-DD]

| Machine | Check performed | Status | Fix (if FAIL) |
|---|---|---|---|
| Genrupt MCP | tool list + free context call | PASS / FAIL | [exact step, see guides/mcp-setup-guide.md] |
| ProductPinion MCP | MCP listed + handshake/list call | PASS / FAIL | [exact step, see guides/mcp-setup-guide.md] |
| OpenAI key | key present in env / kit .env | PASS / FAIL | [exact step, see guides/mcp-setup-guide.md] |

Notes:
- Genrupt account: [account name/email seen in the context call]
- OpenAI: key present; remember org verification is required before the first image generation.
Total spent on this check: nothing. The machines were only listened to.
```

## Golden Standards check

Before presenting, verify:
- [ ] Zero paid calls were made. No generation, no analysis, no poll, no OpenAI API request.
- [ ] Every PASS is backed by a real response observed this session, not by memory or assumption.
- [ ] Every FAIL names the exact fix and points to `guides/mcp-setup-guide.md`.
- [ ] The OpenAI org-verification note is included whenever the key check runs.

## Wonka lines

Openers:
- "The Machine Room. Listen... hear that hum? Let's make sure all three are singing."
- "Before we invent anything, we check the machines. Free of charge, naturally."
- "Ah, a systems check. My favorite kind of caution."

Closers:
- "The machines are warm. The Factory is ready when you are."
- "Three machines, three green lights. Onward. Golden Tickets don't print themselves."
- "One machine is sulking. Here is exactly how we cheer it up."

## Definition of Done

- All three machines checked with a real, free handshake this session.
- The machines report delivered with a PASS or FAIL per machine and a fix for every FAIL.
- Nothing was spent.

## Update status.md

This room is factory-level, not product-level; no product `status.md` changes. Optionally add the one-line entry to `factory/Factory Log/` as described in Process step 5.

---
name: tasting-room
description: The Tasting Room. A synthetic consumer panel (SSR method, arXiv 2510.08338) tastes the candidate images before any real money moves. Demographic-matched AI tasters react in free text, reactions map to purchase intent, a blind forced choice picks a winner, and the recurring objections become concrete fixes. Always includes the live Amazon incumbent when testing mains. Runs in Episode 9 (Tasting Round 1: the MAIN race, Scenario B, and the GALLERY race, Scenario C, in the same sitting) and again in Episode 10 (Round 2, after refinement, re-running both races). Triggers: /tasting-room, "run the tasting", "Tasting Room", "taste test the images", "which image wins", "run the panel", "test the candidates".
---

# The Tasting Room

| Meta | Value |
|------|-------|
| Room | The Tasting Room |
| Station | PROVE (step 1 of 3) |
| Needs | Gate-passed candidate images picked by the user, the CURRENT live Amazon main image (the incumbent) when testing mains, `research/persona.md`, OPENAI_API_KEY in the Factory root `.env` |
| Saves to | factory/Products/[product]/tests/tasting-r[N]-[YYYY-MM-DD]/ (tasting-card.html, tasting-card.md, results.json) plus a row in factory/Recipe Book/experiments.md |
| Typical cost | Lite taste (~20 tasters): under a dollar, a minute or two. Full tasting (~100 tasters): a few dollars, about 3 to 6 minutes. One go-ahead before either. |

## The three test scenarios (pick one, the config follows)

Every tasting is one of these three. Name the scenario out loud before building the config.

### Scenario A. MAIN image: new vs current (the classic A/B)

**The question it answers:** "Is my new main image better than what is live on Amazon right now?"
Two entries: your candidate and the live incumbent, `incumbent_id` set.

```json
{
  "product": "Rabbit Karaoke Machine for Kids",
  "product_context": "one honest line: what it is, key listed features",
  "round": 1,
  "images": [
    {"id": "candidate_a", "label": "hero with both mics forward", "path": "/abs/path/main-02_fix1.png"},
    {"id": "current_listing", "label": "current listing", "path": "/abs/path/incumbent.png"}
  ],
  "incumbent_id": "current_listing",
  "demographics": { "...from research/persona.md..." },
  "out_dir": "/abs/path/factory/Products/[product]/tests/tasting-r1-[YYYY-MM-DD]"
}
```

**What to look at:** the VERDICT band only, really. The winner, its share, and the significance
label. "Clear lead" for the challenger = proceed toward `/ready-to-upload`. Anything less = the notes
and fixes matter more than the shares.

### Scenario B. MAIN image: multiple candidates (+ incumbent, always)

**The question it answers:** "Which of my candidates is strongest, and does the best one beat reality?"
Same shape as A with 2 to 5 candidate entries PLUS the incumbent. The incumbent is never optional
for mains: a winner that only beat your other drafts proves nothing.

```json
{
  "images": [
    {"id": "candidate_a", "label": "hero with both mics forward", "path": "/abs/.../main-02_fix1.png"},
    {"id": "candidate_b", "label": "hero angled with phone holder", "path": "/abs/.../main-04.png"},
    {"id": "candidate_c", "label": "hero with size callout", "path": "/abs/.../main-07.png"},
    {"id": "current_listing", "label": "current listing", "path": "/abs/.../incumbent.png"}
  ],
  "incumbent_id": "current_listing"
}
```

**What to look at:** the verdict band for the ranking AND the explicit vs-incumbent line. Then each
candidate card's "What hurt" chips: the loser's objections often explain the winner.

### Scenario C. GALLERY: our secondary set vs the live Amazon set

**The question it answers:** "Does our whole image stack sell better than the stack that is live?"
Each side gets `"paths": [...]` (2 to 12 frames, in gallery order). Incumbent optional but strongly
recommended: pull the live gallery so reality stays in the race.

```json
{
  "images": [
    {"id": "set_new", "label": "proposed gallery", "paths": ["/abs/.../sec-01.png", "/abs/.../sec-02.png", "/abs/.../sec-03.png"]},
    {"id": "set_live", "label": "live gallery", "paths": ["/abs/.../live-01.png", "/abs/.../live-02.png", "/abs/.../live-03.png"]}
  ],
  "incumbent_id": "set_live"
}
```

**What to look at:** TWO different layers, never collapsed. The SET verdict (verdict band) answers
WHO WINS: shoppers judge the whole hand, so a set's score is not the average of its frames. The
FRAME-BY-FRAME dive answers WHAT TO FIX: which frame carries the set, which one drags it down, and
each frame's works/hurts notes. When the layers disagree, trust the set verdict for the decision
and the frame dive for the edits.

**Round 2 of any scenario:** same config shape with `"round": 2`, a fresh `out_dir`
(`tasting-r2-...`), and `"compare_to"` pointing at Round 1's `results.json` (see below) so the
report shows the round-over-round deltas.

## What this room does

A panel of AI tasters, each one a demographically matched stand-in for the real buyer (age, gender,
income, shopping habits), flips through the candidate images the way shoppers do and reacts in
plain words. The engine never asks a taster for a score; it reads each free-text reaction and maps
it to a 1-to-5 purchase intent by meaning (the SSR method, arXiv 2510.08338; asking directly
collapses everything to "3"). Then every taster faces a blind forced choice: all candidates side by
side, shuffled, no hint which is new or which is live, pick ONE. The result is the Tasting Card: a
verdict, a per-image ranking, and the recurring objections ("the tasting notes") that become
concrete fixes.

This room runs twice in the bootcamp, and each sitting holds TWO races. Episode 9 is Tasting
Round 1: the MAIN race (Scenario B: the fresh main candidates plus the live incumbent) AND the
GALLERY race (Scenario C: the new secondary set vs the live Amazon gallery, set-level verdict plus
the frame-by-frame dive). Two Tasting Cards land. Episode 10 is Round 2, The Second Batch: the main
winner refined from Round 1's tasting notes (via `/fix` MODE B) plus a data-driven challenger plus
the incumbent again, AND the gallery race re-run with the weakest frame(s) fixed, both with
`compare_to` wired so the cards show what moved. The optional Pro Move bonus puts the finalists in
front of real human shoppers; this room is how you arrive there having already fixed everything a
panel can catch.

## Before you start

- Confirm the user has PICKED the candidates (Inspection Room done, human selection made). If no picks exist, send them back to the scorecard first.
- **Never guess which images are being tested.** Ask the user to point at the exact files or folder, echo the list back in one line ("Tasting these 3: main-02_fix1.png, main-04.png, plus the live incumbent"), and get a confirmation. If several version folders exist, which one runs is the USER's call, never an inference.
- **The incumbent is always in the race** (main-image tests). Get the CURRENT live Amazon main image and include it as a candidate with `"incumbent_id"` set. A winner only counts if it beats reality. Pre-launch product with no live image: record `incumbent: none (pre-launch)` and say the verdict is weaker for it.
- Read `research/persona.md` for the REAL buyer demographics. Tasters are built from the buyer's real age, gender, and income, never the aspirational casting age used for models inside the images. If `persona.md` is missing, say so and use the stated default: a general US Amazon shopper (ages 18 to 65+ weighted toward 25-54, 50/50 gender, mostly middle income). The default works; the real persona is sharper. Record which one was used.
- Confirm `OPENAI_API_KEY` is available: the engine loads the `.env` from the Factory root automatically (the key from Episode 1). No key = the room is closed; say exactly what is missing and point to `guides/mcp-setup-guide.md`.
- If `GEMINI_API_KEY` also exists in the `.env`, RECOMMEND the model mix (see the config notes) and say why in one line: two model families disagree where one model's private taste would silently bias the verdict. Suggest, never require; the default single-model run works with the OpenAI key alone.
- Open each candidate file once with Read to confirm you are tasting the files the user actually picked (including `_fixN` versions).
- **Cost gate:** state the run size and the one-line cost estimate (lite: under a dollar; full: a few dollars) and get one go-ahead before running. Never spend silently.

## Process

1. **Pick the scenario (A, B, or C above) and assemble the candidates.** The user's picks plus the
   incumbent. Give each a neutral id and label. BLIND rule: no label may hint at outcome or
   ownership ("new", "ours", "winner", "old", "live") because labels appear on the report; the
   engine already hides them from the tasters, but keep the config clean anyway. Map the incumbent
   only through `"incumbent_id"`.

2. **Build the tasting config** and SAVE it as `[out_dir]/config.json` (create the round folder first; this exact file is the reproducibility record the DoD requires). Wonka assembles it;
   the user never writes JSON. Beyond the scenario snippets above:

   - `demographics` come from `research/persona.md` (Episode 3), shaped like:
     `{"age_dist": {"35-44": 0.5, "45-54": 0.5}, "gender": {"female": 0.8, "male": 0.2}, "income": {"middle income": 1.0}, "notes": "one line on who this is"}`.
     Missing persona: omit the block and the engine uses the stated general-shopper default (it prints a note).
   - Default model is a single `"gpt-5.4-mini"` (one key, works out of the box). With a Gemini key
     present and the user's nod, add: `"models": {"gpt-5.4-mini": 0.6, "gemini-2.5-flash": 0.4}`.
   - `"compare_to": "/abs/path/to/previous/results.json"` (optional) adds the Round Comparison
     section to the card: per-candidate choice-share deltas for ids shared with the earlier round,
     "new this round" for fresh candidates. Use it on every Round 2. Keep candidate ids STABLE
     across rounds (the refined winner keeps its Round 1 id) or the deltas cannot line up.
   - Runs are seeded (`"seed"`, default 42): the same config replays the same panel composition and
     shuffles, so a re-run is comparable. Changing images, counts, models, or seed resets the
     checkpoint on purpose; adding `compare_to` alone does not.

3. **Run it** from the kit root, after the cost go-ahead:

```bash
python3 .claude/skills/tasting-room/run.py [config.json]          # full tasting
python3 .claude/skills/tasting-room/run.py [config.json] lite     # quick taste, ~1/4 volume
```

   Works on Mac and Windows (`python` instead of `python3` on Windows). The full run takes about 3
   to 6 minutes and costs a few dollars. The run opens a LIVE PROGRESS page (`live.html` in the
   out_dir, self-refreshing, with a stall detector) so you always see where it stands; set
   `PANEL_OPEN_LIVE=0` to skip the auto-open. Before spending anything the engine checks that every
   provider in the `"models"` mix has its key and refuses to start if one is missing. **If it stops for any reason (sleep, closed laptop,
   dropped connection), run the SAME command again: it resumes from its checkpoint instead of
   restarting.** Lite mode is for eyeballing a set or testing the machine; any real decision gets
   the full tasting.

4. **Read the Tasting Card** (`tasting-card.html` in the out_dir; `tasting-card.md` is the compact
   text twin). The report reads top to bottom:

   1. **Header.** Product, round, date, panel size, models, mode. A red data-quality banner appears
      here when any parse rate drops under 90%; a card with that banner is weaker evidence, re-run
      before acting on it.
   2. **Verdict card (the DECISION layer).** The winner named by exact filename, the one-line verdict,
      a ready-to-copy DO NOW command for the next step, and the stability tier. Tiers are standardized
      and computed by BOOTSTRAP RESAMPLING the recorded votes (1,000 resamples; the card says plainly
      in how many the winner held and how many flipped votes would change the result):
      - **Clear lead** (winner holds in 95 percent of resamples or more): act on it.
      - **Lean** (holds in 80 to 95 percent): a real lean, not proof. Fine for choosing what to refine.
      - **Toss-up** (under 80 percent, or the base models disagree on the winner): treat as a tie. Use the objections, ignore the shares.
   3. **Candidate cards.** Image, choice share, purchase intent (diagnostic only; the forced choice
      decides), then "What worked" and "What hurt" chips with mention counts (x6 = six tasters
      raised it), and every raw reaction collapsed underneath. Set candidates show the filmstrip.
   4. **Frame by frame (Scenario C, the DIAGNOSIS layer).** Within-set votes per frame (most
      convincing / weakest), boosts-neutral-hurts, per-frame notes, and a one-line lead: which
      frame to lead with, which to fix or drop. This layer feeds `/fix`, never the verdict.
   5. **Segments.** Mean intent by age band, gender, and (with a model mix) per base model, winner
      cell highlighted per row. If the base models disagree on the forced-choice winner the card
      says so in red: that means NO reliable verdict, keep the objections, drop the percentages.
   6. **What the tasters keep saying.** The recurring objections ranked by mentions, each tagged
      with the candidates it applies to. This is the most portable output of the whole room.
   7. **Suggested fixes.** Numbered, concrete, guarded (see step 6).
   8. **Round comparison** (when `compare_to` is set). Previous share, current share, delta arrows.
   9. **Footer.** The honest-framing note and the methodology line.

5. **Present the verdict honestly (the house rules, verbatim spirit):**
   - These tasters are language models playing shoppers. NEVER present the numbers as real shopper results, to the user or in any file.
   - Use the standardized labels out loud: "Clear lead", "Lean", "Toss-up". Anything under Clear lead is a lean, not proof.
   - A single-model panel carries one shared model taste that can bias the win%; the model mix softens it. If the per-model rows disagree on the winner, say "no reliable verdict" and lean on the diagnosis layer only.
   - The most reliable output is the RELATIVE per-image ranking plus the recurring objections. Those travel; exact percentages do not.
   - For real-money decisions, a real shopper poll (the optional Pro Move bonus) is the gold standard.

6. **Mine the tasting notes into actions.** Route each recurring objection through the Fixing Room's table: word swaps and removals are surgical edits (`/fix` MODE B, citing the objection that drove each edit); layout, casting, or size complaints become a regeneration with a tighter brief (`/main-image` round-2 challenger, citing the insight). GUARDED: apply a fix only if it agrees with the research (selling points, Recipe Book patterns); a synthetic objection that contradicts real evidence is recorded in the test file, not acted on. Keep the pre-fix original so Round 2 can prove the fix helped.

7. **Log the experiment.** Append a row to `factory/Recipe Book/experiments.md` in the canonical 8-column schema:

   `| Date | Product | Type | Candidates | Winner | Margin | Key why | Status |`

   Type `tasting-room`, Candidates includes "incumbent", Margin like "54% vs 31%, 100 synthetic tasters, round 1, Clear lead", Key why = the top recurring objection, Status `won` / `lost` / `inconclusive` (`inconclusive` whenever the label is not "Clear lead" OR the models disagreed). The row fills the same session; a synthetic tasting does not wait.

8. **Hand off.** Round 1: to `/fix` MODE B for the main winner AND the weakest gallery frame(s) from the Scenario C card, plus a `/main-image` challenger, then back here for Round 2 (both races, with `compare_to` set). Round 2: if the refined winner or challenger beats the incumbent again, `/ready-to-upload` is open, and the Pro Move bonus (a real shopper poll on the finalists) is the recommended extra step before big-budget products. Either way `/improvement-loop` runs on the result.

## Output format

`tests/tasting-r[N]-[YYYY-MM-DD]/` contains:

- `tasting-card.html`: the full Tasting Card (open in a browser; self-contained, images embedded, light clean report layout).
- `tasting-card.md`: the compact text twin, same structure: verdict table with the standardized label, strongest-frame list, segments, ranked objections with counts, numbered fixes, round comparison (when `compare_to` is set), and the house rules.
- `results.json`: every raw reaction, vote, score, theme counts, and the quality block (parse rates), for audits and `/improvement-loop`.
- `config.json`: the exact tasting configuration that ran (reproducibility).

## Golden Standards check

Before presenting, verify:
- [ ] The scenario (A / B / C) was named, the exact tested files were confirmed by the user (echoed back, no folder guessed), and each was opened once with Read.
- [ ] The incumbent is one of the candidates (or `pre-launch, no incumbent` is stated in writing).
- [ ] Demographics came from `research/persona.md` with the REAL buyer age (or the stated general-shopper default is recorded). Never the aspirational casting age.
- [ ] No candidate label hints at outcome or ownership; the incumbent is marked only via `incumbent_id`.
- [ ] The cost estimate was presented and the user gave one go-ahead before the run.
- [ ] The verdict was presented with the standardized label (Clear lead / Lean / Toss-up) AND the vs-incumbent result; with a model mix, per-model disagreement was checked and called out.
- [ ] Round 2 runs set `compare_to` to Round 1's results.json and kept candidate ids stable.
- [ ] The parse-rate warnings (report header banner / `results.json` quality block) were checked; a win% on under 90% parsed votes was flagged, not presented as solid.
- [ ] Nothing anywhere presents panel numbers as real shopper results, and the Pro Move line (real poll = gold standard) appears with the verdict.
- [ ] Every acted-on fix cites the recurring objection that drove it; contradicting objections were recorded, not applied.
- [ ] All outputs are in English with zero em or en dashes.

## Troubleshooting

- **"OPENAI_API_KEY is missing"**: the key goes in the `.env` file at the Factory root (Episode 1 setup). `guides/mcp-setup-guide.md` walks through it.
- **The run stopped mid-way** (sleep, network, closed terminal): run the exact same command again. The checkpoint in the out_dir resumes it; nothing is lost. Changing the config (images, counts, models, seed) resets the checkpoint on purpose; adding `compare_to` does not.
- **A red data-quality banner on the card / console warning about parse rates under 90%**: some votes did not come back readable, so the shares sit on a smaller sample. Usually a flaky connection; re-run (it resumes and retries the gaps) before trusting the win%.
- **The Round Comparison section is missing**: check that `compare_to` is an absolute path to the previous round's `results.json` and that candidate ids match across rounds; the console prints a note when the file could not be read.
- **A run that takes an hour is broken, not slow.** Full tastings finish in minutes. Stop it and run the same command again.
- **"gemini-* taster models need GEMINI_API_KEY"**: either add that key to the `.env` or remove the `"models"` block to run single-model.
- **Missing Python packages**: `python3 -m pip install openai numpy python-dotenv pillow` (run once). Pillow also powers the automatic image downscaling that keeps requests small and fast; without it the run still works, just heavier.

## Wonka lines

Openers:
- "To the Tasting Room. A hundred tasters are waiting, and not one of them is polite."
- "My opinion retires at this door. Let the panel chew on it."
- "Bring the incumbent too. In this room, reality always gets a seat at the table."

Closers:
- "The panel has spoken, directionally. Candidate B takes the golden ticket, and the notes tell us exactly what to sharpen."
- "The tasters split by model, which means no verdict at all. We take the objections and leave the percentages."
- "The incumbent held. Wonderful. It just saved you from shipping a prettier, weaker image, and it cost you pocket change."

## Definition of Done

- `tests/tasting-r[N]-[date]/` exists with `tasting-card.html`, `tasting-card.md`, `results.json`, and the `config.json` that ran.
- The verdict was presented with the honest framing: the standardized significance label, vs-incumbent result, model-disagreement check, and the Pro Move gold-standard line.
- `factory/Recipe Book/experiments.md` has the run's row (Type `tasting-room`, Status filled).
- Every recurring objection is either routed (to `/fix` MODE B or a challenger brief) or recorded as contradicting the research.
- The user knows the exact next step (Round 1: refine and challenge, then Round 2 with `compare_to`. Round 2: `/ready-to-upload`, with the Pro Move poll recommended for real-money stakes).

## Update status.md

Set PROVE to `in-progress` with the tasting folder as the artifact. Add a Log line: `[date] Tasting Round [N]: [winner] at [share]% vs incumbent [result], [n] tasters, [Clear lead / Lean / Toss-up]. Notes routed to [/fix MODE B / challenger / none]. See tests/tasting-r[N]-[date]/.`

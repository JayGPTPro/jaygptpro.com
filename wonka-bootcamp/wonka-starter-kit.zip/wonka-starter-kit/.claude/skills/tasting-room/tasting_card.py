#!/usr/bin/env python3
"""Tasting Card v3 renderer. Renders a Tasting Room results.json (the exact
output of panel.py) into the v3 research-bureau Tasting Card.

Same CLI contract as tasting_card.py:
    tasting_card_v3.py <results.json> [out.html]
Default output: <results dir>/tasting-card.html

Scenario detection (same as panel.py stacks_mode):
  A. MAIN IMAGE RACE: every candidate is a single image. Ranked full-width
     rows on one common axis, verdict card on top, per-image reaction drawers
     under every image, avatar wall, demographics, model agreement.
  B. GALLERY DUEL: any candidate is a stack (a whole gallery). Set-level split
     scoreboard, independent per-set strips and standalone frame cards (sets
     may have ANY frame counts, no pairing is implied), per-frame note
     drawers, global set-level transcript.

Honesty rules baked in:
  - Only fields the engine actually wrote are rendered. Missing telemetry
    rows are omitted, never invented. No names are invented for personas.
  - Tier vocabulary (CLEAR LEAD / LEAN / TOSS-UP) is computed at build time
    by bootstrap resampling the recorded forced-choice votes. No z-scores,
    no sampling-theory language.
  - "synthetic tasters, not real shoppers" labeling everywhere.
  - No em or en dashes in any output (build fails if one slips through).
"""

import base64
import html as H
import json
import math
import mimetypes
import random
import sys
import time
from collections import Counter, defaultdict
from pathlib import Path

# ---------------------------------------------------------------------------
# text hygiene + tiny helpers
# ---------------------------------------------------------------------------

def clean(s):
    return str("" if s is None else s).replace("\u2014", ", ").replace("\u2013", "-")


def esc(s):
    return H.escape(clean(s), quote=True)


def img_data_uri(path):
    p = Path(path)
    if not p.exists():
        return ""
    mime = mimetypes.guess_type(str(p))[0] or "image/png"
    return f"data:{mime};base64,{base64.b64encode(p.read_bytes()).decode()}"


def theme_items(lst):
    """Normalize strengths/objections/top_works to [(text, count)]; accepts
    {"text","count"} dicts and legacy plain strings alike."""
    out = []
    for t in lst or []:
        if isinstance(t, dict):
            txt = clean(t.get("text", "")).strip()
            cnt = t.get("count")
            if txt:
                out.append((txt, int(cnt) if isinstance(cnt, (int, float)) and cnt else None))
        elif clean(t).strip():
            out.append((clean(t).strip(), None))
    return out


SENT_POS, SENT_NEG = 3.4, 2.6


def sentiment(ssr):
    if ssr is None:
        return "neutral"
    if ssr >= SENT_POS:
        return "positive"
    if ssr <= SENT_NEG:
        return "negative"
    return "neutral"


SENTCLS = {"positive": "ok", "negative": "bad", "neutral": "mid"}

TIER_LABEL = {"clear": "CLEAR LEAD", "lean": "LEAN", "tossup": "TOSS-UP"}
TIER_MEANING = {
    "clear": "Safe to act on this alone.",
    "lean": "Directionally useful, confirm with another round before shipping.",
    "tossup": "Do not act, improve candidates and re-run.",
}


def bootstrap_stability(vote_counts, seed=42, resamples=1000):
    """vote_counts: [(key, votes)]. Bootstrap resample the recorded votes and
    report the share of resamples where the winner stays strictly first, plus
    the minimum number of vote switches that would erase rank 1. All computed
    here at build time; no client-side math."""
    pool = []
    for k, v in vote_counts:
        pool += [k] * v
    n = len(pool)
    ordered = sorted(vote_counts, key=lambda kv: -kv[1])
    winner = ordered[0][0]
    if n == 0 or len(ordered) < 2:
        return {"tier": "tossup", "holds": 0, "of": resamples, "flip_votes": 0, "winner": winner}
    rng = random.Random(seed)
    holds = 0
    for _ in range(resamples):
        c = Counter(pool[rng.randrange(n)] for _ in range(n))
        top = c.most_common(2)
        if top[0][0] == winner and (len(top) == 1 or top[0][1] > top[1][1]):
            holds += 1
    gap = ordered[0][1] - ordered[1][1]
    flip = gap // 2 + 1
    share = holds / resamples
    tier = "clear" if share >= 0.95 else ("lean" if share >= 0.80 else "tossup")
    return {"tier": tier, "holds": holds, "of": resamples, "flip_votes": flip, "winner": winner}


def stamp_svg(tier, date_str, n):
    label = TIER_LABEL[tier]
    parts = label.split(" ")
    font = "IBM Plex Mono,monospace"
    if len(parts) == 2:
        center = (
            f'<text x="50" y="47" text-anchor="middle" font-size="12" font-weight="700" fill="currentColor" font-family="{font}">{parts[0]}</text>'
            f'<text x="50" y="60" text-anchor="middle" font-size="12" font-weight="700" fill="currentColor" font-family="{font}">{parts[1]}</text>'
        )
    else:
        center = f'<text x="50" y="54" text-anchor="middle" font-size="13" font-weight="700" fill="currentColor" font-family="{font}">{label}</text>'
    inner = (
        '<circle cx="50" cy="50" r="33" fill="none" stroke="currentColor" stroke-width="1" stroke-dasharray="3 3"/>'
        if tier == "lean"
        else ""
    )
    ring = f"THE TASTING ROOM . {n} SYNTHETIC TASTERS"
    return (
        '<div class="stamp v3"><svg viewBox="0 0 100 100" role="img" aria-label="report stamp: ' + label + '">'
        '<defs><path id="stampT" d="M 50 50 m -40 0 a 40 40 0 1 1 80 0 a 40 40 0 1 1 -80 0"/>'
        '<path id="stampB" d="M 14 58 A 38 38 0 0 0 86 58"/></defs>'
        '<circle cx="50" cy="50" r="47" fill="none" stroke="currentColor" stroke-width="2.5"/>'
        + inner
        + f'<text font-size="6.2" letter-spacing="1.1" fill="currentColor" font-family="{font}">'
        f'<textPath href="#stampT" startOffset="2%">{ring}</textPath></text>'
        + center
        + f'<text font-size="7" fill="currentColor" font-family="{font}">'
        f'<textPath href="#stampB" startOffset="50%" text-anchor="middle">{esc(date_str)}</textPath></text>'
        "</svg></div>"
    )


BANNED = ["\u2014", "\u2013", "z =", "far outside chance", "statistically significant"]


def assert_clean(doc):
    for b in BANNED:
        if b in doc:
            raise SystemExit("BUILD FAILED, banned string in output: %r" % b)


HONEST_BOX = (
    "These are synthetic tasters, not real shoppers. Before big-money changes, "
    "confirm with a real-shopper poll or an on-Amazon A/B. This card tells you "
    "which candidates deserve that spend."
)

# ---------------------------------------------------------------------------
# CSS (research bureau design system, v3)
# ---------------------------------------------------------------------------

CSS = r"""
@import url('https://fonts.googleapis.com/css2?family=IBM+Plex+Mono:wght@400;500;600&family=IBM+Plex+Sans:wght@400;500;600;700&family=IBM+Plex+Serif:ital,wght@0,600;0,700;1,400&display=swap');
:root {
  --paper:#FAF6EF; --paper2:#F3EDE1; --card:#FFFDF8; --ink:#221A12; --muted:#7A6E5E;
  --hair:#E2D8C6; --hair2:#CFC2AA;
  --copper:#B3591E; --copper-ink:#8F4413; --copper-lt:#C98A45; --copper-bg:#F5E7D8;
  --bench:#2F6FB5; --bench-bg:#E8EFF7; --bench-bd:#BFD2E6;
  --good:#2E6B3F; --good-bg:#E6EFE4; --good-bd:#B9D2B4;
  --bad:#A93226; --bad-bg:#F6E4E0; --bad-bd:#E0BBB3;
  --track:#EDE5D4;
}
* { margin:0; padding:0; box-sizing:border-box; }
html { background:#E9E2D3; }
body { font-family:'IBM Plex Sans','Helvetica Neue',sans-serif; color:var(--ink); font-size:15px; line-height:1.55; }
.mono { font-family:'IBM Plex Mono',monospace; }
button { font:inherit; }
mark { background:var(--copper-bg); color:var(--copper-ink); padding:0 2px; }
.muted { color:var(--muted); }
.sheet { max-width:1060px; margin:26px auto; background:var(--paper); border:1px solid var(--hair2);
  box-shadow:0 2px 6px rgba(60,45,20,0.10), 0 18px 44px rgba(60,45,20,0.13); }
/* masthead */
.mast { border-bottom:3px double var(--ink); padding:30px 48px 18px; position:relative; }
.eyebrow { font-family:'IBM Plex Mono',monospace; font-size:11px; letter-spacing:0.22em; color:var(--copper-ink); font-weight:600; }
.mast h1 { font-family:'IBM Plex Serif',serif; font-weight:700; font-size:34px; letter-spacing:-0.01em; margin-top:4px; }
.mast .sub { color:var(--muted); font-size:13.5px; margin-top:2px; max-width:620px; }
.stamp { position:absolute; right:48px; top:26px; width:92px; height:92px;
  display:flex; flex-direction:column; align-items:center; justify-content:center; text-align:center;
  color:var(--copper-ink); transform:rotate(7deg); font-family:'IBM Plex Mono',monospace; opacity:0.85; }
.stamp.v3 { border:none; padding:0; opacity:0.9; }
.stamp.v3 svg { width:100%; height:100%; overflow:visible; display:block; }
/* status banner */
.status { display:flex; align-items:center; gap:14px; margin:20px 48px 0; padding:13px 18px;
  background:var(--good-bg); border:1px solid var(--good-bd); border-radius:6px; }
.status .dot { width:34px; height:34px; border-radius:50%; background:var(--good); color:#fff; display:flex;
  align-items:center; justify-content:center; font-size:17px; flex:none; }
.status b { font-size:15px; } .status .s { font-size:12.5px; color:#41563F; }
.status .hon { font-family:'IBM Plex Mono',monospace; font-size:10.5px; color:#41563F; margin-top:3px; letter-spacing:0.04em; }
.warnbox { margin:14px 48px 0; border:1px solid var(--bad-bd); background:var(--bad-bg); color:var(--bad);
  border-radius:6px; padding:10px 14px; font-size:13px; }
/* audience chips */
.chipsrow { display:flex; flex-wrap:wrap; gap:7px; padding:14px 48px 0; }
.achip { font-family:'IBM Plex Mono',monospace; font-size:10.5px; letter-spacing:0.04em; padding:3.5px 11px;
  border-radius:999px; background:var(--paper2); border:1px solid var(--hair2); color:#5C5142; }
.achip.hot { background:var(--copper-bg); border-color:var(--copper-lt); color:var(--copper-ink); }
/* question */
.qline { padding:20px 48px 6px; }
.qline .q { font-family:'IBM Plex Serif',serif; font-weight:700; font-size:23px; }
.qline .q em { color:var(--copper-ink); font-style:normal; }
.qline .qsub { font-size:12.5px; color:var(--muted); margin-top:3px; }
/* sections */
section { padding:26px 48px 30px; border-bottom:1px solid var(--hair2); }
.shead { display:flex; align-items:baseline; gap:12px; margin-bottom:18px; }
.snum { font-family:'IBM Plex Mono',monospace; font-size:11px; color:var(--copper-ink); font-weight:600; }
.shead h3 { font-size:12.5px; letter-spacing:0.17em; font-weight:700; }
.shead .rule { flex:1; border-top:1px solid var(--hair2); }
.shead .note { font-family:'IBM Plex Mono',monospace; font-size:10.5px; color:var(--muted); }
/* insight cards */
.insight { background:var(--card); border:1px solid var(--hair2); border-radius:8px; padding:18px 20px; }
.insight .ih { display:flex; align-items:center; gap:9px; font-weight:700; font-size:14px; margin-bottom:8px; }
.insight .ih .spark { color:var(--copper-ink); }
.insight p { font-size:13.5px; color:#4A4033; }
.icards { display:grid; grid-template-columns:repeat(3,1fr); gap:12px; margin-top:14px; }
.icard { background:var(--paper); border:1px solid var(--hair); border-radius:7px; padding:12px 14px; }
.icard b { display:block; font-size:13px; margin-bottom:4px; }
.icard p { font-size:12px; color:var(--muted); }
.icard .tagline { font-family:'IBM Plex Mono',monospace; font-size:9.5px; letter-spacing:0.1em; color:var(--copper-ink); margin-bottom:5px; display:block; }
.icard a { color:var(--copper-ink); }
.icmd { display:flex; align-items:center; flex-wrap:wrap; gap:8px; margin-top:10px; padding-top:9px; border-top:1px dashed var(--hair); }
.icmd .cmdpill { font-size:11px; padding:5px 8px; }
.efftag { font-family:'IBM Plex Mono',monospace; font-size:10px; letter-spacing:0.06em; color:var(--muted);
  border:1px solid var(--hair2); border-radius:2px; padding:2px 7px; }
a.evd { color:var(--copper-ink); text-decoration:underline dotted; text-underline-offset:2px; font-weight:600; cursor:pointer; }
/* ranked objections + fixes */
.objs { list-style:none; margin:14px 0 0; }
.objs li { display:flex; align-items:baseline; gap:10px; padding:7px 0; border-bottom:1px dotted var(--hair); font-size:13px; }
.objs li:last-child { border-bottom:none; }
.ocount { min-width:36px; font-family:'IBM Plex Mono',monospace; font-weight:600; color:var(--bad); font-size:12px; }
.otext { flex:1; color:#4A4033; }
.oapp { font-family:'IBM Plex Mono',monospace; font-size:10px; color:var(--muted); }
ol.fixes { margin:8px 0 0 20px; }
ol.fixes li { margin:6px 0; font-size:13px; color:#4A4033; }
.guard { font-family:'IBM Plex Mono',monospace; font-size:10.5px; color:var(--muted); margin-top:14px; }
.blockhead { font-family:'IBM Plex Mono',monospace; font-size:10.5px; letter-spacing:0.18em; color:var(--muted);
  margin:22px 0 4px; padding-top:14px; border-top:1px dashed var(--hair); }
/* export row */
.exportrow { display:flex; justify-content:flex-end; align-items:center; gap:4px; padding:10px 48px 0; flex-wrap:wrap;
  font-family:'IBM Plex Mono',monospace; font-size:10.5px; letter-spacing:0.08em; color:var(--muted); }
.exportrow button { background:none; border:none; cursor:pointer; color:var(--muted); font-family:'IBM Plex Mono',monospace;
  font-size:10.5px; letter-spacing:0.08em; padding:12px 8px; min-height:44px; }
.exportrow button:hover { color:var(--copper-ink); }
.exportrow .sep { color:var(--hair2); }
/* tier + delta chips */
.tier { display:inline-block; font-family:'IBM Plex Mono',monospace; font-size:11px; font-weight:600; letter-spacing:0.08em;
  padding:4px 11px; border-radius:3px; }
.tier.clear { background:var(--good-bg); color:var(--good); border:1px solid var(--good-bd); }
.tier.lean { background:var(--copper-bg); color:var(--copper-ink); border:1px solid var(--copper-lt); }
.tier.tossup { background:var(--paper2); color:var(--muted); border:1px solid var(--hair2); }
.delta { display:inline-block; font-family:'IBM Plex Mono',monospace; font-size:10px; font-weight:600; letter-spacing:0.06em;
  padding:2.5px 9px; border-radius:2px; white-space:nowrap; }
.delta.up { background:var(--good-bg); color:var(--good); border:1px solid var(--good-bd); }
.delta.down { background:var(--bad-bg); color:var(--bad); border:1px solid var(--bad-bd); }
.delta.bench { background:var(--bench-bg); color:var(--bench); border:1px solid var(--bench-bd); }
/* verdict card */
.verdictcard { margin:18px 48px 0; background:var(--card); border:1px solid var(--hair2); border-top:3px solid var(--copper);
  border-radius:6px; display:grid; grid-template-columns:140px 1fr auto; gap:20px; padding:18px 20px 10px; }
.vmedia { display:flex; flex-direction:column; gap:6px; align-self:start; }
.vthumb { background:#fff; border:1px solid var(--copper-lt); padding:5px; }
.vthumb img { width:100%; display:block; }
.vstripthumbs { display:flex; flex-direction:column; gap:5px; }
.vstripthumbs .vthumb { display:flex; align-items:center; justify-content:center; height:52px; }
.vstripthumbs .vthumb img { max-width:100%; max-height:100%; width:auto; object-fit:contain; }
.vline { font-family:'IBM Plex Serif',serif; font-weight:700; font-size:22px; line-height:1.35; }
.vreason { font-size:13px; color:#4A4033; margin-top:4px; }
.vflip { font-family:'IBM Plex Mono',monospace; font-size:11px; color:var(--muted); margin-top:7px; }
.donow { display:flex; align-items:center; flex-wrap:wrap; gap:9px; margin-top:12px; }
.donow .dlbl { font-family:'IBM Plex Mono',monospace; font-size:10px; font-weight:600; letter-spacing:0.14em; color:var(--copper-ink); }
.cmdpill { font-family:'IBM Plex Mono',monospace; font-size:12px; background:var(--paper2); border:1px solid var(--hair2);
  border-radius:4px; padding:6px 11px; color:#4A4033; overflow-wrap:anywhere; }
.copybtn { background:none; border:1px solid var(--hair2); border-radius:3px; cursor:pointer; color:var(--copper-ink);
  font-family:'IBM Plex Mono',monospace; font-size:10px; font-weight:600; letter-spacing:0.1em; padding:9px 12px; }
.copybtn:hover { border-color:var(--copper-lt); background:var(--copper-bg); }
.thenline { font-family:'IBM Plex Mono',monospace; font-size:11px; color:var(--muted); margin-top:9px; }
.vnums { display:flex; flex-direction:column; align-items:flex-end; gap:7px; text-align:right; }
.vpct { font-family:'IBM Plex Serif',serif; font-weight:700; font-size:48px; line-height:1; color:var(--copper-ink); font-variant-numeric:tabular-nums; }
.vfoot { grid-column:1 / -1; display:flex; justify-content:space-between; align-items:center; gap:8px; flex-wrap:wrap;
  border-top:1px dashed var(--hair); margin-top:10px; padding-top:6px;
  font-family:'IBM Plex Mono',monospace; font-size:10px; letter-spacing:0.06em; color:var(--muted); }
/* filename caption, click to copy */
.fname { font-family:'IBM Plex Mono',monospace; font-size:10px; color:var(--muted); white-space:nowrap; overflow:hidden;
  text-overflow:ellipsis; cursor:copy; margin-top:6px; position:relative; }
.fname:hover { color:var(--copper-ink); }
.fname.copied::after { content:'copied'; position:absolute; right:0; top:0; background:var(--good-bg); color:var(--good); padding:0 6px; }
/* notes drawer */
details.notesdrawer { margin-top:14px; border-top:1px dashed var(--hair); padding-top:12px; }
details.notesdrawer summary { list-style:none; display:flex; align-items:center; gap:10px; min-height:44px; cursor:pointer;
  font-family:'IBM Plex Mono',monospace; font-size:11px; font-weight:600; letter-spacing:0.08em; color:var(--copper-ink);
  background:var(--paper2); border:1px solid var(--hair2); border-radius:5px; padding:0 12px; user-select:none; }
details.notesdrawer summary::-webkit-details-marker { display:none; }
details.notesdrawer summary::before { content:'\25B8'; font-size:11px; transition:transform 0.2s ease-out; }
details.notesdrawer[open] summary { border-radius:5px 5px 0 0; }
details.notesdrawer[open] summary::before { transform:rotate(90deg); }
details.notesdrawer summary .sumtally { margin-left:auto; color:var(--muted); font-weight:400; }
.drawerinner { border:1px solid var(--hair2); border-top:none; border-radius:0 0 5px 5px; background:var(--card); }
.drawerhead { font-family:'IBM Plex Mono',monospace; font-size:10px; color:var(--muted); padding:10px 12px 0; line-height:1.6; }
.filterrow { display:flex; flex-wrap:wrap; gap:6px; align-items:center; padding:10px 12px; border-bottom:1px dashed var(--hair); }
.fchip { font-family:'IBM Plex Mono',monospace; font-size:10.5px; padding:6px 11px; border-radius:999px; background:var(--paper2);
  border:1px solid var(--hair2); color:#5C5142; cursor:pointer; user-select:none; }
.fchip.on { background:var(--copper-bg); border-color:var(--copper-lt); color:var(--copper-ink); font-weight:600; }
.fcount { margin-left:auto; font-family:'IBM Plex Mono',monospace; font-size:10px; color:var(--muted); }
.drawerbody { max-height:340px; overflow-y:auto; -webkit-overflow-scrolling:touch; padding:4px 12px 12px; }
@media (prefers-reduced-motion:no-preference) {
  details.notesdrawer[open] .drawerinner { animation:drawerin 0.2s ease-out; }
}
@keyframes drawerin { from { opacity:0; transform:translateY(-4px); } to { opacity:1; transform:none; } }
/* response rows */
.resp { display:grid; grid-template-columns:34px 1fr auto; gap:11px; padding:11px 4px; border-top:1px dashed var(--hair); align-items:start; }
.resp:first-of-type { border-top:none; }
.rav { width:34px; height:34px; border-radius:50%; color:#fff; display:flex; align-items:center; justify-content:center;
  font-family:'IBM Plex Mono',monospace; font-size:10px; font-weight:600; }
.rtxt { font-size:13px; color:#3B3226; }
.rmeta { font-family:'IBM Plex Mono',monospace; font-size:10px; color:var(--muted); margin-top:3px; }
.rmeta a { color:var(--copper-ink); }
.rnum { font-family:'IBM Plex Mono',monospace; font-size:10px; color:var(--hair2); font-weight:600; }
.rnum-inline { display:none; }
.sentchip { display:inline-block; font-size:10px; padding:1px 7px; border-radius:2px; margin-left:6px; vertical-align:1px;
  font-family:'IBM Plex Mono',monospace; }
.sentchip.ok { background:var(--good-bg); color:var(--good); }
.sentchip.bad { background:var(--bad-bg); color:var(--bad); }
.sentchip.mid { background:var(--paper2); color:var(--muted); }
.vchip { display:inline-block; font-size:10px; padding:1px 7px; border-radius:2px; margin-left:6px; vertical-align:1px;
  font-family:'IBM Plex Mono',monospace; background:var(--copper-bg); color:var(--copper-ink); }
.wd { margin-top:4px; font-size:12px; }
.wd.ok { color:var(--good); }
.wd.bad { color:var(--bad); }
/* pull quotes */
.pullquotes { display:grid; grid-template-columns:1fr 1fr; gap:10px; margin-top:14px; }
.pq { background:var(--paper2); border-left:3px solid var(--hair2); padding:9px 12px; }
.pq.praise { border-left-color:var(--good); }
.pq.object { border-left-color:var(--bad); }
.pq .pqt { font-family:'IBM Plex Serif',serif; font-style:italic; font-size:12.5px; color:#3B3226; }
.pq .pqa { font-family:'IBM Plex Mono',monospace; font-size:10px; color:var(--muted); margin-top:5px; }
.pq .pqnone { font-family:'IBM Plex Mono',monospace; font-size:10.5px; color:var(--muted); }
/* report A: the race */
.raceaxis { display:flex; justify-content:space-between; align-items:baseline; gap:8px;
  font-family:'IBM Plex Mono',monospace; font-size:10px; letter-spacing:0.08em; color:var(--muted); margin-bottom:12px; }
.raceaxis span:nth-child(2) { flex:1; text-align:center; min-width:0; }
.race { display:grid; grid-template-columns:200px 1fr; gap:20px; background:var(--card); border:1px solid var(--hair2);
  border-radius:8px; padding:16px; margin-bottom:14px; align-items:start; }
.race.win { border:2px solid var(--copper); box-shadow:0 8px 22px rgba(179,89,30,0.12); }
.raceimg { background:#fff; border:1px solid var(--hair); border-radius:6px; aspect-ratio:1/1;
  display:flex; align-items:center; justify-content:center; overflow:hidden; }
.raceimg img { max-width:100%; max-height:100%; object-fit:contain; }
.racehead { display:flex; align-items:center; gap:10px; flex-wrap:wrap; }
.racelbl { font-family:'IBM Plex Mono',monospace; font-size:11px; letter-spacing:0.12em; font-weight:600; color:#4A4033; }
.winchip { display:inline-block; background:var(--copper); color:#FFF6EC; font-family:'IBM Plex Mono',monospace;
  font-size:10px; font-weight:600; letter-spacing:0.12em; padding:2.5px 10px; border-radius:2px; }
.racenum { display:flex; align-items:baseline; gap:10px; margin-top:6px; }
.racepct { font-family:'IBM Plex Serif',serif; font-weight:700; font-size:44px; line-height:1; font-variant-numeric:tabular-nums; }
.race.win .racepct { color:var(--copper-ink); }
.racevotes { font-family:'IBM Plex Mono',monospace; font-size:10.5px; color:var(--muted); }
.racetrack { position:relative; height:12px; background:var(--track); border-radius:6px; margin-top:10px; }
.racefill { position:absolute; left:0; top:0; bottom:0; border-radius:6px; }
.benchrule { position:absolute; top:-4px; bottom:-4px; border-left:2px dashed var(--bench); }
.benchrule .rlbl { position:absolute; top:calc(100% + 6px); left:-2px; font-family:'IBM Plex Mono',monospace;
  font-size:10px; color:var(--bench); white-space:nowrap; }
.race.win .pullquotes { margin-top:26px; }
/* demographics */
.demo { display:grid; grid-template-columns:130px 1fr 130px; gap:12px; align-items:center; padding:7px 0; }
.demo .lbl { font-family:'IBM Plex Mono',monospace; font-size:11px; color:var(--muted); text-align:right; }
.demo .dtrack { height:22px; position:relative; border-radius:3px; }
.dtrack { background:var(--track); display:flex; }
.dseg { height:100%; position:relative; }
.dseg .dpct { position:absolute; inset:0; display:flex; align-items:center; justify-content:center;
  font-family:'IBM Plex Mono',monospace; font-size:10px; color:#FFF6EC; }
.dtick { position:absolute; top:-3px; bottom:-3px; border-left:2px solid var(--ink); opacity:0.4; }
.demo.flip { border-left:3px solid var(--copper); padding-left:8px; }
.flipchip { display:inline-block; background:var(--copper-bg); color:var(--copper-ink); border:1px solid var(--copper-lt);
  font-family:'IBM Plex Mono',monospace; font-size:10px; font-weight:600; letter-spacing:0.08em; padding:2px 8px; border-radius:2px; }
.demofoot { font-family:'IBM Plex Mono',monospace; font-size:10.5px; color:var(--muted); margin-top:14px; }
.subhead { font-size:12.5px; color:var(--muted); margin:-10px 0 14px; }
.dn-inline { display:none; }
/* model agreement */
.mrgrid { display:grid; grid-template-columns:180px 1fr; gap:12px; align-items:center; padding:6px 0; }
.mrlbl { font-family:'IBM Plex Mono',monospace; font-size:11px; color:var(--muted); text-align:right; }
.agreechip { display:inline-block; font-family:'IBM Plex Mono',monospace; font-size:10.5px; font-weight:600; letter-spacing:0.06em;
  padding:5px 11px; border-radius:3px; margin-top:8px; }
.agreechip.yes { background:var(--good-bg); color:var(--good); border:1px solid var(--good-bd); }
.agreechip.no { background:var(--bad-bg); color:var(--bad); border:1px solid var(--bad-bd); }
/* avatar wall v3 */
.wall { display:grid; grid-template-columns:repeat(20, 1fr); gap:6px; }
.av { position:relative; aspect-ratio:1; border-radius:50%; display:flex; align-items:center; justify-content:center;
  font-family:'IBM Plex Mono',monospace; font-size:9.5px; font-weight:600; color:#fff; cursor:pointer; }
.av.sel { outline:2px solid var(--ink); outline-offset:2px; }
.wall-legend { display:flex; gap:16px; margin-top:14px; flex-wrap:wrap; }
.wl { display:flex; align-items:center; gap:7px; font-family:'IBM Plex Mono',monospace; font-size:11px; color:var(--muted); }
.wl i { width:12px; height:12px; border-radius:50%; display:inline-block; }
.walltoggle { display:flex; gap:8px; margin-bottom:14px; }
.wtbtn { font-family:'IBM Plex Mono',monospace; font-size:10.5px; letter-spacing:0.08em; padding:9px 13px; border-radius:3px;
  background:var(--paper2); border:1px solid var(--hair2); color:#5C5142; cursor:pointer; min-height:40px; }
.wtbtn.on { background:var(--copper-bg); border-color:var(--copper-lt); color:var(--copper-ink); font-weight:600; }
.wgroup { margin-bottom:14px; }
.wglbl { font-family:'IBM Plex Mono',monospace; font-size:10.5px; letter-spacing:0.1em; color:var(--muted); margin-bottom:6px; }
.wglbl i { display:inline-block; width:10px; height:10px; border-radius:50%; margin-right:7px; vertical-align:-1px; }
#tt { position:absolute; background:var(--ink); color:var(--paper); font-size:11.5px; line-height:1.4; padding:8px 11px;
  border-radius:5px; width:220px; z-index:60; display:none; pointer-events:none; box-shadow:0 6px 18px rgba(0,0,0,0.25); }
.tdetail { margin-top:14px; background:var(--card); border:1px solid var(--hair2); border-left:3px solid var(--copper);
  padding:12px 14px; display:none; }
.tdetail.on { display:block; }
.tdetail .tdh { font-family:'IBM Plex Mono',monospace; font-size:11px; color:var(--muted); display:flex; align-items:center; gap:8px; flex-wrap:wrap; }
.tdetail .tdh i { width:12px; height:12px; border-radius:50%; display:inline-block; }
.tdetail .tdc { font-size:13px; color:#3B3226; margin-top:7px; }
.tdetail a { color:var(--copper-ink); font-family:'IBM Plex Mono',monospace; font-size:10.5px; }
/* flash pulse */
.flash { animation:flashbg 1.5s ease-out; }
@keyframes flashbg { 0% { background:var(--copper-bg); } 100% { background:transparent; } }
/* lightbox */
.lightbox { position:fixed; inset:0; background:rgba(34,26,18,0.88); z-index:100; display:none;
  align-items:center; justify-content:center; flex-direction:column; padding:20px; }
.lightbox.open { display:flex; }
.lbpanel { background:#fff; padding:14px; max-width:88vw; display:flex; gap:16px; align-items:center; justify-content:center; }
.lbpanel img.lbmain { max-width:70vw; max-height:64vh; display:block; }
.lbthumbwrap { display:none; text-align:center; font-family:'IBM Plex Mono',monospace; font-size:10px; color:var(--muted); }
.lbthumbwrap img.lbthumb { width:160px; display:block; border:1px solid var(--hair2); margin-bottom:4px; }
.lightbox.squint .lbthumbwrap { display:block; }
.lbcap { margin-top:12px; background:var(--paper); border:1px solid var(--hair2); padding:10px 16px; max-width:88vw; font-size:12px; color:#3B3226; }
.lbcap .lbtitle { font-weight:600; }
.lbcap .lbmeta { font-family:'IBM Plex Mono',monospace; font-size:10px; color:var(--muted); margin-top:2px; }
.lbcap .lbq { margin-top:4px; font-size:12px; }
.lbctrl { display:flex; gap:10px; margin-top:12px; }
.lbctrl .copybtn { background:var(--paper); min-height:44px; }
.lbnav { position:fixed; top:50%; transform:translateY(-50%); background:var(--paper); border:1px solid var(--hair2);
  width:44px; height:44px; border-radius:50%; font-size:18px; cursor:pointer; color:var(--ink); z-index:101; }
.lbprev { left:14px; } .lbnext { right:14px; }
body.lb-lock { overflow:hidden; }
[data-lb] { cursor:zoom-in; }
/* report B: scoreboard + frame cards + transcript */
.splitnames { display:flex; justify-content:space-between; font-family:'IBM Plex Mono',monospace; font-size:10.5px;
  letter-spacing:0.12em; color:var(--muted); margin-bottom:5px; }
.splitnames .l { color:var(--copper-ink); font-weight:600; } .splitnames .r { color:var(--bench); font-weight:600; }
.splitbar { display:flex; height:28px; border-radius:5px; overflow:hidden; margin-bottom:20px; }
.splitbar i { display:flex; align-items:center; height:100%; color:#fff; font-family:'IBM Plex Serif',serif; font-weight:700; font-size:20px; font-style:normal; }
.splitbar .sl { justify-content:flex-start; padding-left:12px; }
.splitbar .sr { justify-content:flex-end; padding-right:12px; }
.setshare { display:grid; grid-template-columns:200px 1fr 90px; gap:12px; align-items:center; padding:6px 0;
  font-family:'IBM Plex Mono',monospace; font-size:11px; color:var(--muted); }
.setshare .sst { height:18px; background:var(--track); border-radius:4px; position:relative; }
.setshare .sst i { position:absolute; left:0; top:0; bottom:0; border-radius:4px; }
.setblock { border:1px solid var(--hair2); border-radius:10px; background:var(--card); padding:14px; margin-top:14px; }
.setblock.win { border:2px solid var(--copper); }
.setbar { display:flex; align-items:center; gap:10px; flex-wrap:wrap; margin-bottom:12px; }
.setname { font-family:'IBM Plex Mono',monospace; font-size:11px; letter-spacing:0.13em; font-weight:600; }
.setblock.win .setname { color:var(--copper-ink); }
.cntchip { font-family:'IBM Plex Mono',monospace; font-size:10px; letter-spacing:0.1em; border:1px solid var(--hair2); border-radius:999px; padding:2px 9px; color:var(--muted); background:var(--paper2); }
.setvotes { font-family:'IBM Plex Mono',monospace; font-size:10px; color:var(--muted); letter-spacing:0.08em; }
.setwinchip { margin-left:auto; background:var(--copper); color:#FFF6EC; font-family:'IBM Plex Mono',monospace;
  font-size:10px; font-weight:600; letter-spacing:0.12em; padding:3px 10px; border-radius:3px; }
.setbenchchip { margin-left:auto; background:var(--bench-bg); color:var(--bench); border:1px solid var(--bench-bd);
  font-family:'IBM Plex Mono',monospace; font-size:10px; font-weight:600; letter-spacing:0.12em; padding:3px 10px; border-radius:3px; }
.strip { display:grid; grid-template-columns:repeat(auto-fill, minmax(84px, 1fr)); gap:12px; min-width:0; }
.sframe { position:relative; min-width:0; }
.sframe .fimg, .fcimg { background:#fff; border:1px solid var(--hair); border-radius:6px; aspect-ratio:1;
  display:flex; align-items:center; justify-content:center; overflow:hidden; min-width:0; }
.sframe img, .fcimg img { width:100%; height:100%; object-fit:contain; }
.fpos { position:absolute; top:-8px; left:-8px; width:22px; height:22px; border-radius:50%; background:var(--ink); color:var(--paper);
  font-family:'IBM Plex Mono',monospace; font-size:10.5px; font-weight:600; display:flex; align-items:center; justify-content:center; z-index:2; }
.scap { font-family:'IBM Plex Mono',monospace; font-size:10px; letter-spacing:0.05em; margin-top:5px; font-weight:600; }
.scap.carries { color:var(--copper-ink); } .scap.pulls { color:#557C2A; }
.scap.barely { color:var(--muted); font-weight:400; } .scap.drags { color:var(--bad); }
.framecard { border:1px solid var(--hair2); border-radius:8px; background:var(--card); margin-top:14px; overflow:hidden; }
.framecard.setA { border-left:3px solid var(--copper); }
.framecard.setB { border-left:3px solid var(--bench); }
.framecard .notesdrawer { margin-top:0; border-top:none; padding:0 16px 14px; }
.fcgrid { display:grid; grid-template-columns:116px 1fr; gap:16px; padding:14px 16px; }
.fcleft { position:relative; }
.fcbody { min-width:0; }
.fchead { display:flex; align-items:center; gap:9px; flex-wrap:wrap; }
.setchip { font-family:'IBM Plex Mono',monospace; font-size:10px; font-weight:600; letter-spacing:0.12em; padding:2px 8px; border-radius:2px; color:#FFF6EC; }
.fcofn { font-family:'IBM Plex Mono',monospace; font-size:10px; color:var(--muted); letter-spacing:0.1em; }
.ftag { margin-left:auto; display:inline-block; font-family:'IBM Plex Mono',monospace; font-size:10px; font-weight:600; letter-spacing:0.08em;
  padding:3px 9px; border-radius:3px; white-space:nowrap; }
.ftag.carries { background:var(--copper); color:#FFF6EC; }
.ftag.pulls { background:none; color:#557C2A; border:1px solid #557C2A; }
.ftag.barely { background:none; color:var(--muted); border:1px solid var(--hair2); }
.ftag.drags { background:var(--bad); color:#FFF3F0; }
.fcrole { font-size:14.5px; font-weight:600; margin-top:7px; }
.fctake { margin-top:6px; font-size:12.5px; color:#4A4033; background:var(--paper); border-left:3px solid var(--copper-lt);
  border-radius:0 5px 5px 0; padding:5px 10px; }
.mbarwrap { display:flex; align-items:center; gap:10px; margin-top:9px; flex-wrap:wrap; }
.mentionbar { flex:1 1 160px; max-width:340px; height:10px; border-radius:5px; background:var(--track); overflow:hidden; }
.mentionbar i { display:block; height:100%; border-radius:5px; }
.mlabel { font-family:'IBM Plex Mono',monospace; font-size:10px; color:var(--muted); letter-spacing:0.06em; }
.mchip { font-family:'IBM Plex Mono',monospace; font-size:10px; padding:2px 8px; border-radius:2px; }
.mchip.ok { background:var(--good-bg); color:var(--good); }
.mchip.bad { background:var(--bad-bg); color:var(--bad); }
.mchip.mid { background:var(--paper2); color:var(--muted); }
.chips { display:flex; flex-wrap:wrap; gap:6px; margin-top:9px; }
.tchip { font-family:'IBM Plex Mono',monospace; font-size:10.5px; border-radius:5px; padding:3px 9px; background:var(--paper2); border:1px solid var(--hair2); color:#5C5142; }
.tchip.ok { background:var(--good-bg); border-color:var(--good-bd); color:var(--good); }
.tchip.bad { background:var(--bad-bg); border-color:var(--bad-bd); color:var(--bad); }
.fquote { font-family:'IBM Plex Serif',serif; font-style:italic; font-size:12.5px; color:#4A4033; margin-top:10px; }
.fquote .qby { font-family:'IBM Plex Mono',monospace; font-style:normal; font-size:10px; color:var(--muted); margin-left:8px; }
.nomention { padding:12px 16px; border-top:1px dashed var(--hair); background:var(--paper2);
  font-family:'IBM Plex Mono',monospace; font-size:10.5px; color:var(--muted); letter-spacing:0.05em; }
/* global feed (B) */
.feedhead { font-family:'IBM Plex Mono',monospace; font-size:10px; color:var(--muted); letter-spacing:0.06em; margin-bottom:9px; }
.feedtabs { display:flex; gap:0; border:1px solid var(--hair2); border-radius:7px 7px 0 0; overflow:hidden; background:var(--paper2); }
.ftab { flex:1; text-align:center; padding:10px 6px; font-family:'IBM Plex Mono',monospace; font-size:11px; letter-spacing:0.06em;
  color:var(--muted); border-left:1px solid var(--hair2); cursor:pointer; user-select:none; }
.ftab:first-child { border-left:none; }
.ftab.on { background:var(--card); color:var(--copper-ink); font-weight:600; box-shadow:inset 0 -3px 0 var(--copper); }
.feedwrap { border:1px solid var(--hair2); border-top:none; border-radius:0 0 7px 7px; background:var(--card);
  max-height:480px; overflow-y:auto; padding:6px 16px 14px; }
.feedpane { display:none; }
.feedpane.on { display:block; }
/* methodology + footer */
.method { display:grid; grid-template-columns:1fr 1fr; gap:26px; padding:24px 48px; background:var(--paper2); border-bottom:1px solid var(--hair2); }
.method h4 { font-family:'IBM Plex Mono',monospace; font-size:10.5px; letter-spacing:0.18em; color:var(--muted); margin-bottom:8px; }
.method p, .method li { font-size:12.5px; color:#4A4033; }
.method ul { list-style:none; }
.method li { padding:2.5px 0; border-bottom:1px dotted var(--hair); display:flex; justify-content:space-between; gap:10px; }
.method li span:last-child { font-family:'IBM Plex Mono',monospace; text-align:right; }
.method li.long { display:block; }
.method li.long span:last-child { display:block; text-align:left; }
.honest { border:1px solid var(--copper-lt); background:var(--copper-bg); padding:12px 14px; font-size:12.5px; color:var(--copper-ink); margin-top:12px; }
.tierlegend { list-style:none; margin-top:8px; }
.tierlegend li { padding:3px 0; font-size:12.5px; color:#4A4033; display:flex; gap:8px; align-items:baseline; border-bottom:none; }
.foot { display:flex; justify-content:space-between; align-items:center; padding:15px 48px 18px;
  font-family:'IBM Plex Mono',monospace; font-size:10.5px; letter-spacing:0.1em; color:var(--muted); gap:10px; flex-wrap:wrap; }
.printid { display:none; font-family:'IBM Plex Mono',monospace; font-size:10px; letter-spacing:0.08em; color:var(--muted); padding:10px 48px 18px; }
/* comparison table */
.cmptbl { width:100%; border-collapse:collapse; font-size:13px; margin-top:6px; }
.cmptbl th { text-align:left; font-family:'IBM Plex Mono',monospace; font-size:10px; letter-spacing:0.08em; color:var(--muted);
  padding:7px 10px; border-bottom:1px solid var(--hair2); }
.cmptbl td { padding:7px 10px; border-bottom:1px dotted var(--hair); color:#4A4033; }
/* responsive */
@media (max-width:760px) {
  .mast, section, .method, .foot, .qline, .printid { padding-left:18px; padding-right:18px; }
  .status, .warnbox { margin-left:18px; margin-right:18px; }
  .chipsrow { padding:12px 18px 0; }
  .icards { grid-template-columns:1fr; }
  .wall { grid-template-columns:repeat(10,1fr); }
  .method { grid-template-columns:1fr; }
  .stamp { display:flex; }
  .stamp.v3 { position:absolute; right:18px; top:16px; width:64px; height:64px; }
  .mast { padding-right:96px; }
  .verdictcard { grid-template-columns:1fr; margin:16px 18px 0; gap:14px; }
  .verdictcard .vmedia { max-width:170px; }
  .vstripthumbs { flex-direction:row; }
  .vstripthumbs .vthumb { flex:1; height:56px; }
  .vnums { flex-direction:row; align-items:baseline; justify-content:flex-start; gap:12px; text-align:left; flex-wrap:wrap; }
  .vline { font-size:18px; }
  .vpct { font-size:40px; }
  .exportrow { padding:10px 18px 0; justify-content:flex-start; }
  .achip { font-size:11px; }
  .icard .tagline, .efftag { font-size:10px; }
  .av { font-size:10px; }
  .rmeta, .rnum, .fname, .pq .pqa { font-size:10px; }
  .copybtn, .fchip, .wtbtn { min-height:44px; }
  .mrgrid { grid-template-columns:1fr; gap:4px; }
  .mrlbl { text-align:left; }
  .race { grid-template-columns:96px 1fr; gap:12px; padding:12px; }
  .racepct { font-size:30px; }
  .strip { grid-template-columns:repeat(3,1fr); row-gap:16px; }
  .fcgrid { grid-template-columns:96px 1fr; gap:12px; padding:12px; }
  .splitbar i { font-size:16px; }
  .setshare { grid-template-columns:1fr; gap:4px; }
  .lbpanel img.lbmain { max-width:84vw; }
}
@media (max-width:480px) {
  .resp { grid-template-columns:34px 1fr; }
  .rnum { display:none; }
  .rnum-inline { display:inline; }
  .pullquotes { grid-template-columns:1fr; }
  .demo { display:block; }
  .demo .lbl { text-align:left; margin-bottom:4px; }
  .dn-inline { display:inline; }
  .dn-col { display:none; }
  .fcgrid { grid-template-columns:1fr; }
  .fcleft { max-width:180px; }
}
@media (max-width:420px) { .strip { grid-template-columns:repeat(2,1fr); } }
@media print {
  html { background:#fff; }
  .sheet { box-shadow:none; max-width:none; border:none; }
  * { print-color-adjust:exact; -webkit-print-color-adjust:exact; }
  section, .verdictcard, .icard, .method, .race, .insight, .demo, .framecard, .setblock { break-inside:avoid; }
  .lightbox, .exportrow, .walltoggle, #tt, .lbnav { display:none !important; }
  .drawerbody, .feedwrap { max-height:none; overflow:visible; }
  details.notesdrawer:not([open]) summary::after { content:' . full notes in the interactive card'; font-weight:400; color:var(--muted); }
  .feedpane { display:block; }
  .printid { display:block; }
}
"""

# ---------------------------------------------------------------------------
# JS (single template; PAYLOAD is JSON computed in Python)
# ---------------------------------------------------------------------------

JS_TMPL = r"""
var P = __PAYLOAD__;
function tcCopyFallback(text){ var ta=document.createElement('textarea'); ta.value=text; ta.style.position='fixed';
  ta.style.opacity='0'; document.body.appendChild(ta); ta.select();
  try{ document.execCommand('copy'); }catch(e){} document.body.removeChild(ta); }
function tcCopy(btn, text){
  function ok(){ if(!btn) return; if(!btn.dataset.lbl) btn.dataset.lbl=btn.textContent;
    btn.textContent='COPIED'; setTimeout(function(){ btn.textContent=btn.dataset.lbl; },1500); }
  if(navigator.clipboard && navigator.clipboard.writeText){
    navigator.clipboard.writeText(text).then(ok, function(){ tcCopyFallback(text); ok(); });
  } else { tcCopyFallback(text); ok(); }
}
function tcFlash(el){ if(!el) return; el.classList.remove('flash'); void el.offsetWidth;
  el.classList.add('flash'); setTimeout(function(){ el.classList.remove('flash'); },1600); }

document.addEventListener('DOMContentLoaded', function(){
  // hydrate images (each data URI stored exactly once, in P.imgs)
  document.querySelectorAll('img[data-ik]').forEach(function(im){
    var u = P.imgs[im.dataset.ik]; if(u) im.src = u;
  });

  // filename captions: click copies the full path
  document.querySelectorAll('.fname').forEach(function(el){
    el.addEventListener('click', function(){
      var t = el.getAttribute('title') || el.textContent;
      if(navigator.clipboard && navigator.clipboard.writeText){ navigator.clipboard.writeText(t); }
      else { tcCopyFallback(t); }
      el.classList.add('copied'); setTimeout(function(){ el.classList.remove('copied'); },1000);
    });
  });

  // copy buttons
  document.querySelectorAll('.copycmd').forEach(function(b){
    b.addEventListener('click', function(){ tcCopy(b, b.dataset.cmd); });
  });
  document.querySelectorAll('.copyverdict').forEach(function(b){
    b.addEventListener('click', function(){ tcCopy(b, P.verdict_text); });
  });

  // CSV download (precomputed at build time from the run data)
  var csv = document.getElementById('csvbtn');
  if(csv) csv.addEventListener('click', function(){
    var blob = new Blob([P.csv], {type:'text/csv'});
    var a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = P.csv_name;
    document.body.appendChild(a); a.click();
    setTimeout(function(){ URL.revokeObjectURL(a.href); a.remove(); }, 0);
  });
  var pr = document.getElementById('printbtn');
  if(pr) pr.addEventListener('click', function(){ window.print(); });

  // filter rows: chips filter .resp rows inside the same drawer / pane
  document.querySelectorAll('.filterrow').forEach(function(row){
    var scope = row.parentElement;
    var chips = row.querySelectorAll('.fchip');
    var counter = row.querySelector('.fcount');
    function rows(){ return scope.querySelectorAll('.drows .resp'); }
    chips.forEach(function(ch){
      ch.addEventListener('click', function(){
        chips.forEach(function(x){ x.classList.remove('on'); });
        ch.classList.add('on');
        var f = ch.dataset.f, n = 0, total = 0;
        rows().forEach(function(r){
          total++;
          var show = f === 'all'
            || (f.indexOf('s:') === 0 && r.dataset.sent === f.slice(2))
            || (f === 'voter' && r.dataset.voter === '1');
          r.style.display = show ? '' : 'none';
          if(show) n++;
        });
        if(counter) counter.textContent = n + ' of ' + total + ' shown';
      });
    });
  });

  // drawers: Escape closes the focused drawer; on small screens one open at a time
  var drawers = Array.prototype.slice.call(document.querySelectorAll('details.notesdrawer'));
  drawers.forEach(function(d){
    d.addEventListener('toggle', function(){
      if(!d.open) return;
      if(window.innerWidth <= 760){
        var before = d.getBoundingClientRect().top;
        drawers.forEach(function(o){ if(o !== d && o.open) o.open = false; });
        var after = d.getBoundingClientRect().top;
        window.scrollBy(0, after - before);
      }
    });
  });
  document.addEventListener('keydown', function(e){
    if(e.key !== 'Escape') return;
    if(document.querySelector('.lightbox.open')) return;
    var d = document.activeElement && document.activeElement.closest ? document.activeElement.closest('details.notesdrawer') : null;
    if(d && d.open){ d.open = false; var s = d.querySelector('summary'); if(s) s.focus(); }
  });

  // global feed tabs (report B)
  function showTab(k){
    document.querySelectorAll('.ftab').forEach(function(x){ x.classList.toggle('on', x.dataset.k === k); });
    document.querySelectorAll('.feedpane').forEach(function(p){ p.classList.toggle('on', p.dataset.set === k); });
  }
  document.querySelectorAll('.ftab').forEach(function(tab){
    tab.addEventListener('click', function(){ showTab(tab.dataset.k); });
    tab.addEventListener('keydown', function(e){ if(e.key === 'Enter' || e.key === ' '){ e.preventDefault(); showTab(tab.dataset.k); } });
  });

  // open a taster's primary note (drawer or transcript tab), scroll + flash
  var TBYID = {};
  P.tasters.forEach(function(t){ TBYID[t.syn] = t; });
  function openNote(syn){
    var t = TBYID[syn]; if(!t) return;
    if(t.open.type === 'drawer'){
      var d = document.getElementById(t.open.key);
      if(d){ d.open = true; d.scrollIntoView({block:'nearest'}); }
    } else if(t.open.type === 'tab'){
      showTab(t.open.key);
      var feed = document.querySelector('.feedwrap');
      if(feed) feed.scrollIntoView({block:'nearest'});
    }
    var row = document.getElementById(t.anchor);
    if(row){ row.scrollIntoView({block:'nearest'}); tcFlash(row); }
  }
  document.querySelectorAll('[data-jump]').forEach(function(a){
    a.addEventListener('click', function(e){ e.preventDefault(); openNote(a.dataset.jump); });
  });

  // evidence anchors: open the target drawer / card, flash it
  document.querySelectorAll('a.evd').forEach(function(a){
    a.addEventListener('click', function(e){
      e.preventDefault();
      var target = document.querySelector(a.getAttribute('href'));
      if(!target) return;
      var d = target.tagName === 'DETAILS' ? target : target.querySelector('details.notesdrawer');
      if(d) d.open = true;
      target.scrollIntoView({block:'nearest'});
      tcFlash(target.tagName === 'DETAILS' ? target.querySelector('summary') : target);
    });
  });

  // lightbox with SEARCH SIZE (160px) toggle
  var items = P.lb;
  if(items.length){
    var lb = document.createElement('div'); lb.className = 'lightbox';
    lb.innerHTML = '<button class="lbnav lbprev" aria-label="previous image">&#8249;</button>'+
      '<div class="lbpanel"><img class="lbmain" alt=""><div class="lbthumbwrap"><img class="lbthumb" alt=""><div>search thumbnail size</div></div></div>'+
      '<div class="lbcap"><div class="lbtitle"></div><div class="lbmeta"></div><div class="lbq"></div></div>'+
      '<div class="lbctrl"><button class="copybtn lbtoggle">SEARCH SIZE</button><button class="copybtn lbclose">CLOSE</button></div>'+
      '<button class="lbnav lbnext" aria-label="next image">&#8250;</button>';
    document.body.appendChild(lb);
    var cur = 0;
    function show(i){ cur = (i + items.length) % items.length; var it = items[cur];
      var src = P.imgs[it.ik] || '';
      lb.querySelector('.lbmain').src = src; lb.querySelector('.lbthumb').src = src;
      lb.querySelector('.lbtitle').textContent = it.label;
      lb.querySelector('.lbmeta').textContent = it.meta + (it.file ? ' | ' + it.file : '');
      lb.querySelector('.lbq').textContent = it.quotes || ''; }
    function open(i){ show(i); lb.classList.add('open'); document.body.classList.add('lb-lock'); }
    function close(){ lb.classList.remove('open'); lb.classList.remove('squint'); document.body.classList.remove('lb-lock'); }
    lb.querySelector('.lbprev').addEventListener('click', function(e){ e.stopPropagation(); show(cur-1); });
    lb.querySelector('.lbnext').addEventListener('click', function(e){ e.stopPropagation(); show(cur+1); });
    lb.querySelector('.lbclose').addEventListener('click', close);
    lb.querySelector('.lbtoggle').addEventListener('click', function(e){ e.stopPropagation(); lb.classList.toggle('squint'); });
    lb.addEventListener('click', function(e){ if(e.target === lb) close(); });
    document.addEventListener('keydown', function(e){
      if(!lb.classList.contains('open')) return;
      if(e.key === 'Escape') close();
      if(e.key === 'ArrowLeft') show(cur-1);
      if(e.key === 'ArrowRight') show(cur+1); });
    document.querySelectorAll('[data-lb]').forEach(function(el){
      el.addEventListener('click', function(){ open(parseInt(el.dataset.lb, 10) || 0); });
    });
  }

  // avatar wall: grouped waffle default, shuffle toggle, tooltip, tap detail card
  var GRP = {};
  P.groups.forEach(function(g){ GRP[g.key] = g; });
  var pinned = null;
  var fine = window.matchMedia('(hover:hover) and (pointer:fine)').matches;
  var sheet = document.querySelector('.sheet');
  function initTips(container){
    if(!fine) return;
    sheet.style.position = 'relative';
    var tt = document.getElementById('tt');
    if(!tt){ tt = document.createElement('div'); tt.id = 'tt'; sheet.appendChild(tt); }
    container.addEventListener('mouseover', function(e){
      var av = e.target.closest ? e.target.closest('.av') : null;
      if(!av || !av.dataset.tip){ tt.style.display = 'none'; return; }
      tt.textContent = av.dataset.tip; tt.style.display = 'block';
      var sr = sheet.getBoundingClientRect(), r = av.getBoundingClientRect();
      var left = r.left - sr.left + r.width/2 - 110;
      left = Math.max(8, Math.min(left, sr.width - 236));
      tt.style.left = left + 'px';
      tt.style.top = (r.top - sr.top - tt.offsetHeight - 8) + 'px';
    });
    container.addEventListener('mouseleave', function(){
      var tt2 = document.getElementById('tt'); if(tt2) tt2.style.display = 'none';
    });
  }
  function avEl(t){
    var g = GRP[t.group];
    var d = document.createElement('div'); d.className = 'av'; d.style.background = g.color;
    d.textContent = t.n; d.dataset.tid = t.syn;
    d.dataset.tip = t.syn + ' . ' + t.meta + ' . chose ' + g.label + ' . "' + t.comment.slice(0, 90) + '..."';
    d.setAttribute('role','button'); d.setAttribute('tabindex','0');
    function activate(){
      if(pinned === t.syn){ openNote(t.syn); return; }
      pinned = t.syn;
      document.querySelectorAll('.av.sel').forEach(function(x){ x.classList.remove('sel'); });
      document.querySelectorAll('.av[data-tid="' + t.syn + '"]').forEach(function(x){ x.classList.add('sel'); });
      var card = document.getElementById('tdetail');
      card.innerHTML = '<div class="tdh"><i style="background:' + g.color + '"></i><b>' + t.syn + '</b><span>' + t.meta +
        '</span><span>chose ' + g.label + '</span></div>' +
        '<div class="tdc"></div><a href="#" id="tdlink">read the full note</a>';
      card.querySelector('.tdc').textContent = t.comment;
      card.classList.add('on');
      document.getElementById('tdlink').addEventListener('click', function(e){ e.preventDefault(); openNote(t.syn); });
    }
    d.addEventListener('click', activate);
    d.addEventListener('keydown', function(e){ if(e.key === 'Enter' || e.key === ' '){ e.preventDefault(); activate(); } });
    return d;
  }
  var wallHost = document.getElementById('wallhost');
  function renderWall(mode){
    if(!wallHost) return;
    wallHost.innerHTML = '';
    pinned = null;
    if(mode === 'group'){
      P.groups.forEach(function(g){
        var members = P.tasters.filter(function(t){ return t.group === g.key; });
        if(!members.length) return;
        var b = document.createElement('div'); b.className = 'wgroup';
        var l = document.createElement('div'); l.className = 'wglbl';
        l.innerHTML = '<i style="background:' + g.color + '"></i>' + g.label + ', ' + members.length;
        b.appendChild(l);
        var w = document.createElement('div'); w.className = 'wall';
        members.forEach(function(t){ w.appendChild(avEl(t)); });
        b.appendChild(w);
        wallHost.appendChild(b);
      });
    } else {
      var w = document.createElement('div'); w.className = 'wall';
      var n = P.tasters.length;
      for(var i = 0; i < n; i++) w.appendChild(avEl(P.tasters[(i * 37) % n]));
      wallHost.appendChild(w);
    }
    if(!wallHost.dataset.tipsInit){ wallHost.dataset.tipsInit = '1'; initTips(wallHost); }
  }
  document.querySelectorAll('.wtbtn').forEach(function(b){
    b.addEventListener('click', function(){
      document.querySelectorAll('.wtbtn').forEach(function(x){ x.classList.remove('on'); });
      b.classList.add('on');
      renderWall(b.dataset.mode);
    });
  });
  renderWall('group');
  var wn = document.getElementById('wallnote');
  if(wn) wn.textContent = fine ? 'HOVER OR CLICK ANY TASTER' : 'TAP ANY TASTER';
});
"""

# ---------------------------------------------------------------------------
# shared context derivation
# ---------------------------------------------------------------------------

INC_COLOR = "#2F6FB5"
OPT_COLORS = ["#B3591E", "#C98A45", "#557C2A", "#8F4413", "#6B5B4A", "#9C6B4E"]
NOVOTE_COLOR = "#7A6E5E"


def syn_id(pid):
    return f"SYN-{int(pid):03d}"


def sex_letter(gender):
    g = clean(gender).strip().lower()
    if g.startswith("f"):
        return "F"
    if g.startswith("m"):
        return "M"
    return (g[:1].upper() or "?")


def taster_meta(p):
    return f"{sex_letter(p.get('gender'))} {p.get('age', '?')}, {clean(p.get('income', ''))}"


def conditioned_line(p):
    bits = [clean(p.get("shopping_style", "")), clean(p.get("familiarity", ""))]
    return "; ".join(b for b in bits if b)


def build_ctx(res, src):
    cfg = res["config"]
    agg = res["aggregate"]
    images = res["images"]
    personas = res["personas"]
    n = len(personas)
    pmap = {p["id"]: p for p in personas}
    vote_of = {}
    for c in res.get("choices", []):
        vote_of[c["persona_id"]] = c.get("chosen")
    parsed_votes = [v for v in vote_of.values() if v]
    total_votes = max(1, len(parsed_votes))

    ranked = sorted(images, key=lambda i: -agg[i["id"]].get("choice_votes", 0))
    inc_id = cfg.get("incumbent_id")
    if inc_id not in agg:
        inc_id = None
    winner_id = res.get("verdict", {}).get("winner_id") or ranked[0]["id"]

    stab = bootstrap_stability(
        [(i["id"], agg[i["id"]].get("choice_votes", 0)) for i in images],
        seed=cfg.get("seed", 42),
    )
    # model agreement: computed from recorded votes; a disagreement forces TOSS-UP
    mix = cfg.get("models") or {cfg.get("model", ""): 1.0}
    model_names = sorted({p.get("model") for p in personas if p.get("model")})
    models_agree = None
    model_winners = {}
    if len(model_names) > 1:
        for m in model_names:
            cnt = Counter(vote_of.get(p["id"]) for p in personas if p.get("model") == m and vote_of.get(p["id"]))
            if cnt:
                model_winners[m] = cnt.most_common(1)[0][0]
        models_agree = len(set(model_winners.values())) <= 1
        if models_agree is False:
            stab["tier"] = "tossup"

    run_date = res.get("run_date") or time.strftime("%Y-%m-%d", time.localtime(src.stat().st_mtime))
    round_no = cfg.get("round", 1)
    rid = f"TR-{run_date.replace('-', '')[4:]}-R{round_no}"
    ctx_snip = clean(cfg.get("product_context", "")).strip()
    short_ctx = ctx_snip if len(ctx_snip) <= 72 else ctx_snip[:72].rsplit(" ", 1)[0] + "..."
    product = cfg.get("product") or cfg.get("asin") or cfg.get("niche") or short_ctx or "this product"

    quality = res.get("quality", {})
    warns = []
    cpr = quality.get("choice_parse_rate")
    if cpr is not None and cpr < 0.9:
        warns.append(
            f"Only {round(cpr * 100)}% of forced-choice votes parsed. The shares on this card sit on a "
            "reduced sample; re-run (it resumes) before trusting the verdict."
        )
    wvr = quality.get("within_vote_parse_rate")
    if wvr is not None and wvr < 0.9:
        warns.append(f"Only {round(wvr * 100)}% of within-set votes parsed. The per-frame ranking sits on a reduced sample.")
    rt, ro = quality.get("reactions_total", 0), quality.get("reactions_ok", 0)
    if rt and ro / rt < 0.9:
        warns.append(f"Only {ro}/{rt} taster reactions completed. Check the API connection and re-run (it resumes).")

    ages = [p.get("age") for p in personas if isinstance(p.get("age"), (int, float))]
    pct_f = round(100 * sum(1 for p in personas if sex_letter(p.get("gender")) == "F") / max(1, n))
    demo_notes = clean((cfg.get("demographics") or {}).get("notes", ""))

    return dict(
        res=res, cfg=cfg, agg=agg, images=images, ranked=ranked, personas=personas, pmap=pmap,
        vote_of=vote_of, total_votes=total_votes, n=n, inc_id=inc_id, winner_id=winner_id,
        stab=stab, tier=stab["tier"], mix=mix, model_names=model_names, models_agree=models_agree,
        model_winners=model_winners, run_date=run_date, round_no=round_no, rid=rid,
        product=product, product_context=ctx_snip, quality=quality, warns=warns,
        themes=res.get("themes", {}), comparison=res.get("comparison"),
        age_span=(min(ages), max(ages)) if ages else (None, None), pct_f=pct_f,
        demo_notes=demo_notes, seed=cfg.get("seed", 42),
        mode="lite" if cfg.get("_mode") == "lite" else "full",
    )


# ---------------------------------------------------------------------------
# shared HTML pieces
# ---------------------------------------------------------------------------

def masthead(ctx, eyebrow, sub):
    return f"""
  <header class="mast">
    <div class="eyebrow">{eyebrow}</div>
    <h1>Tasting Card</h1>
    <div class="sub">{sub}</div>
    {stamp_svg(ctx['tier'], ctx['run_date'], ctx['n'])}
  </header>"""


def status_block(ctx):
    warn = ""
    if ctx["warns"]:
        warn = "<div class='warnbox'><b>Data quality warning.</b> " + " ".join(esc(w) for w in ctx["warns"]) + "</div>"
    return f"""
  <div class="status">
    <div class="dot">&#10003;</div>
    <div><b>Tasting complete.</b>
      <div class="s">{ctx['n']} tasters answered. Report {ctx['rid']}, {esc(ctx['run_date'])}, {ctx['mode']} mode.</div>
      <div class="hon">Synthetic panel. Directional signal.</div>
    </div>
  </div>{warn}"""


def export_row():
    return """
  <div class="exportrow">
    <button id="csvbtn">DOWNLOAD CSV</button><span class="sep">.</span>
    <button class="copyverdict">COPY VERDICT</button><span class="sep">.</span>
    <button id="printbtn">PRINT / PDF</button>
  </div>"""


def chips_row(ctx, extra=None):
    amin, amax = ctx["age_span"]
    chips = [f'<span class="achip hot">{ctx["n"]} SYNTHETIC TASTERS</span>']
    if ctx["demo_notes"]:
        note = ctx["demo_notes"] if len(ctx["demo_notes"]) <= 52 else ctx["demo_notes"][:52].rsplit(" ", 1)[0] + "..."
        chips.append(f'<span class="achip">{esc(note.upper())}</span>')
    if amin is not None:
        chips.append(f'<span class="achip">{ctx["pct_f"]}% F &middot; AGES {amin} TO {amax}</span>')
    chips.append(f'<span class="achip">SEED {esc(ctx["seed"])} &middot; MODELS: {esc(", ".join(ctx["mix"]))}</span>')
    if ctx["mode"] == "lite":
        chips.append('<span class="achip">LITE MODE</span>')
    for e in extra or []:
        chips.append(f'<span class="achip">{e}</span>')
    return '<div class="chipsrow">' + "".join(chips) + "</div>"


def tier_chip(ctx, extra=""):
    return f'<span class="tier {ctx["tier"]}">{TIER_LABEL[ctx["tier"]]}{extra}</span>'


def tier_legend():
    return (
        '<ul class="tierlegend">'
        f'<li><span class="tier clear">CLEAR LEAD</span><span>winner holds in at least 95% of 1,000 resamples of the recorded votes. {TIER_MEANING["clear"]}</span></li>'
        f'<li><span class="tier lean">LEAN</span><span>holds in 80 to 95% of resamples. {TIER_MEANING["lean"]}</span></li>'
        f'<li><span class="tier tossup">TOSS-UP</span><span>holds in under 80% of resamples, or the base models disagree on the winner. {TIER_MEANING["tossup"]}</span></li>'
        "</ul>"
    )


def method_block(ctx, howto_extra, presentation):
    amin, amax = ctx["age_span"]
    q = ctx["quality"]
    stab = ctx["stab"]
    rows = [
        '<li class="long"><span>Method basis</span><span>SSR, semantic similarity rating (arXiv 2510.08338)</span></li>',
        f'<li><span>Panel</span><span>{ctx["n"]} tasters, {ctx["pct_f"]}% F'
        + (f", ages {amin} to {amax}" if amin is not None else "") + "</span></li>",
        f'<li class="long"><span>Conditioning</span><span>age, sex, income, shopping traits from: {esc(ctx["demo_notes"]) or "default general US Amazon shopper (no buyer persona supplied)"}</span></li>',
        '<li class="long"><span>Panel cannot see</span><span>price, review count, brand reputation, delivery promise</span></li>',
        f'<li class="long"><span>Presentation</span><span>{presentation}</span></li>',
        f'<li><span>Models</span><span>{esc(", ".join(ctx["mix"]))}, seed {esc(ctx["seed"])}</span></li>',
        f'<li><span>Stability</span><span>winner holds in {stab["holds"]:,} of {stab["of"]:,} resamples</span></li>',
    ]
    if q:
        parse = f'{q.get("reactions_ok", "?")}/{q.get("reactions_total", "?")} reactions'
        if q.get("choice_parse_rate") is not None:
            parse += f', {round(q["choice_parse_rate"] * 100)}% choices parsed'
        rows.append(f'<li><span>Data quality</span><span>{parse}</span></li>')
    cal = clean(ctx["cfg"].get("calibration", "")) or "Not yet calibrated against a human panel for this niche"
    rows.append(f'<li class="long"><span>Calibration</span><span>{esc(cal)}</span></li>')
    return f"""
  <div class="method">
    <div>
      <h4>HOW TO READ THIS CARD</h4>
      <p>{ctx['n']} AI tasters, each conditioned on the buyer demographics, judged the images and explained
      their picks in their own words. The verdict is directional: a strong signal plus a map of objections.
      It replaces guessing, never reality.</p>
      {tier_legend()}
      {howto_extra}
      <div class="honest">{HONEST_BOX}</div>
    </div>
    <div>
      <h4>PANEL SPECIFICATION</h4>
      <ul>{''.join(rows)}</ul>
    </div>
  </div>"""


def footer_block(ctx, next_line):
    return f"""
  <footer class="foot">
    <span>THE TASTING ROOM &middot; CARD {ctx['rid']}</span>
    <span>{next_line}</span>
    <span>SYNTHETIC PANEL, NOT REAL SHOPPERS</span>
  </footer>
  <div class="printid">THE TASTING ROOM . CARD {ctx['rid']} . n={ctx['n']} SYNTHETIC TASTERS . {esc(ctx['run_date'])}</div>"""


def comparison_section(ctx, snum):
    comp = ctx["comparison"]
    if not comp or not comp.get("rows"):
        return ""
    prev_r = comp.get("prev_round")
    rows = []
    for row in sorted(comp["rows"], key=lambda r: -r.get("share", 0)):
        cur = f"{round(row.get('share', 0) * 100)}%"
        if "delta_pts" in row:
            d = row["delta_pts"]
            delta = ("+" if d > 0 else "") + f"{d} pts"
            prev = f"{round((row.get('prev_share') or 0) * 100)}%"
        else:
            prev, delta = "new this round", "."
        rows.append(f"<tr><td>{esc(row['id'])} <span class='muted'>{esc(row.get('label', ''))}</span></td>"
                    f"<td>{prev}</td><td>{cur}</td><td>{delta}</td></tr>")
    dropped = ""
    if comp.get("dropped_ids"):
        dropped = f"<p class='guard'>Not in this round: {esc(', '.join(comp['dropped_ids']))}.</p>"
    return f"""
  <section>
    <div class="shead"><span class="snum">{snum}</span><h3>ROUND COMPARISON</h3><span class="rule"></span>
      <span class="note">VS ROUND {esc(prev_r) if prev_r else 'PREVIOUS'}</span></div>
    <table class="cmptbl">
      <thead><tr><th>CANDIDATE</th><th>PREVIOUS</th><th>THIS ROUND</th><th>DELTA</th></tr></thead>
      <tbody>{''.join(rows)}</tbody>
    </table>
    {dropped}
  </section>"""


def objections_and_fixes(ctx, opt_anchor):
    """Ranked objections list + guarded suggested fixes. opt_anchor maps an
    image id to the element id its evidence anchor should open."""
    themes = ctx["themes"]
    obj = themes.get("objections_ranked") or []
    obj = sorted(obj, key=lambda o: -(o.get("count") or 0))
    obj_rows = []
    for o in obj:
        cnt = o.get("count")
        applies = " ".join(
            f'<a class="evd" href="#{opt_anchor(a)}">{esc(a)}</a>' if opt_anchor(a) else esc(a)
            for a in (o.get("applies_to") or [])
        )
        obj_rows.append(
            f"<li><span class='ocount'>{('x' + str(cnt)) if cnt else ''}</span>"
            f"<span class='otext'>{esc(o.get('text', ''))}</span><span class='oapp'>{applies}</span></li>"
        )
    edits = "".join(f"<li>{esc(e)}</li>" for e in themes.get("suggested_edits", []))
    cross = "".join(f"<li><span class='ocount'>&#10022;</span><span class='otext'>{esc(c)}</span></li>"
                    for c in themes.get("cross_takeaways", []))
    out = ""
    if obj_rows:
        out += f'<div class="blockhead">RANKED OBJECTIONS &middot; WHAT THE TASTERS KEEP SAYING</div><ul class="objs">{"".join(obj_rows)}</ul>'
    if edits:
        out += ('<div class="blockhead">SUGGESTED FIXES &middot; GUARDED</div>'
                '<p class="guard">Apply a fix only if it agrees with your research. A synthetic objection that '
                'contradicts real evidence gets recorded, not acted on. Keep the pre-fix original so a later '
                'round can prove the fix helped.</p>'
                f'<ol class="fixes">{edits}</ol>')
    if cross:
        out += f'<div class="blockhead">CREATIVE RULES THIS PANEL SUGGESTS</div><ul class="objs">{cross}</ul>'
    return out


def resp_row_html(anchor_id, av_color, av_letter, text_html, sent, meta, idx, voter=False, extra=""):
    vchip = '<span class="vchip">voter</span>' if voter else ""
    scls = SENTCLS[sent]
    return (
        f'<div class="resp" id="{anchor_id}" data-sent="{sent}" data-voter="{"1" if voter else ""}">'
        f'<div class="rav" style="background:{av_color}">{av_letter}</div>'
        f'<div><div class="rtxt">{text_html}<span class="sentchip {scls}">{sent}</span>{vchip}</div>'
        f'{extra}'
        f'<div class="rmeta">{meta}<span class="rnum-inline"> . #{idx}</span></div></div>'
        f'<div class="rnum">#{idx}</div></div>'
    )


def filter_row(total, pos, neu, neg, voters=None):
    chips = [
        f'<span class="fchip on" data-f="all">All {total}</span>',
        f'<span class="fchip" data-f="s:positive">Positive {pos}</span>',
        f'<span class="fchip" data-f="s:neutral">Neutral {neu}</span>',
        f'<span class="fchip" data-f="s:negative">Negative {neg}</span>',
    ]
    if voters is not None:
        chips.append(f'<span class="fchip" data-f="voter">Voters {voters}</span>')
    return f'<div class="filterrow">{"".join(chips)}<span class="fcount">{total} of {total} shown</span></div>'


# ---------------------------------------------------------------------------
# REPORT A: MAIN IMAGE RACE
# ---------------------------------------------------------------------------

def build_report_a(ctx):
    res, agg, cfg = ctx["res"], ctx["agg"], ctx["cfg"]
    ranked, inc_id, winner_id = ctx["ranked"], ctx["inc_id"], ctx["winner_id"]
    pmap, vote_of, n, total_votes = ctx["pmap"], ctx["vote_of"], ctx["n"], ctx["total_votes"]
    themes = ctx["themes"]

    imgs = {}  # ik -> data uri (each stored once)
    def ik_of(path):
        key = f"i{len(imgs)}"
        for k, v in imgs.items():
            if v[0] == path:
                return k
        imgs[key] = (path, img_data_uri(path))
        return key

    # option records
    opts = []
    ci = 0
    for rank, img in enumerate(ranked):
        iid = img["id"]
        a = agg[iid]
        path = (img.get("paths") or [img.get("path", "")])[0]
        is_inc = iid == inc_id
        if is_inc:
            color = INC_COLOR
        else:
            color = OPT_COLORS[ci % len(OPT_COLORS)]
            ci += 1
        reactions = [r for r in res.get("reactions", []) if r["image_id"] == iid and not clean(r["text"]).startswith("__ERROR__")]
        reactions.sort(key=lambda r: -(r.get("ssr") or 0))
        sents = Counter(sentiment(r.get("ssr")) for r in reactions)
        opts.append(dict(
            id=iid, label=clean(a.get("label", iid)), path=path, ik=ik_of(path),
            votes=a.get("choice_votes", 0), share=round(a.get("choice_share", 0) * 100),
            ssr=a.get("ssr_mean"), is_inc=is_inc, is_winner=iid == winner_id, color=color,
            reactions=reactions, pos=sents["positive"], neu=sents["neutral"], neg=sents["negative"],
            key=f"opt{rank}",
        ))
    winner = next(o for o in opts if o["is_winner"])
    inc = next((o for o in opts if o["is_inc"]), None)
    ax_max = max(60, int(math.ceil(max(o["share"] for o in opts) / 10.0) * 10))

    def opt_display(o):
        return "YOUR LIVE IMAGE" if o["is_inc"] else o["label"].upper()

    def fname_html(o):
        base = Path(o["path"]).name
        return f'<div class="fname" title="{esc(o["path"])}">{esc(base)}</div>'

    def pullquotes(o):
        rs = o["reactions"]
        ph = '<div class="pq praise"><div class="pqnone">No reactions recorded</div></div>'
        oh = '<div class="pq object"><div class="pqnone">No low-intent reaction recorded</div></div>'
        if rs:
            top = rs[0]
            p = pmap.get(top["persona_id"], {})
            ph = (f'<div class="pq praise"><div class="pqt">&ldquo;{esc(top["text"])}&rdquo;</div>'
                  f'<div class="pqa">{syn_id(top["persona_id"])} . {esc(taster_meta(p))} . intent {top.get("ssr", "?")}</div></div>')
            low = rs[-1]
            if (low.get("ssr") or 5) <= 3.0 and low is not top:
                p2 = pmap.get(low["persona_id"], {})
                oh = (f'<div class="pq object"><div class="pqt">&ldquo;{esc(low["text"])}&rdquo;</div>'
                      f'<div class="pqa">{syn_id(low["persona_id"])} . {esc(taster_meta(p2))} . intent {low.get("ssr", "?")}</div></div>')
        return f'<div class="pullquotes">{ph}{oh}</div>'

    def drawer(o):
        rows = []
        for i, r in enumerate(o["reactions"], 1):
            pid = r["persona_id"]
            p = pmap.get(pid, {})
            meta = f"{syn_id(pid)} &middot; persona: {esc(taster_meta(p))} &middot; conditioned as: {esc(conditioned_line(p))}"
            rows.append(resp_row_html(
                anchor_id=f"note-{o['key']}-{pid}", av_color=o["color"], av_letter=sex_letter(p.get("gender")),
                text_html=esc(r["text"]), sent=sentiment(r.get("ssr")), meta=meta, idx=i,
                voter=vote_of.get(pid) == o["id"],
            ))
        head = (f"Every taster reacted to every image; these are all {len(o['reactions'])} reactions to this one. "
                "Verbatim reactions generated in persona. Sentiment auto-classified from the SSR purchase-intent "
                f"score ({SENT_POS} and up positive, {SENT_NEG} and under negative). "
                "Rows marked VOTER belong to tasters whose forced-choice click went to this image.")
        return f"""<details class="notesdrawer" id="drawer-{o['key']}">
      <summary>READ ALL {len(o['reactions'])} REACTIONS<span class="sumtally">{o['pos']} POSITIVE / {o['neu']} NEUTRAL / {o['neg']} NEGATIVE</span></summary>
      <div class="drawerinner">
        <div class="drawerhead">{head}</div>
        {filter_row(len(o['reactions']), o['pos'], o['neu'], o['neg'], voters=o['votes'])}
        <div class="drawerbody"><div class="drows">{''.join(rows)}</div></div>
      </div>
    </details>"""

    lb_items = []
    def race_row(o):
        lb_idx = len(lb_items)
        lb_items.append(dict(
            ik=o["ik"], label=opt_display(o), meta=f'{o["votes"]} of {total_votes} votes ({o["share"]}%)',
            file=o["path"], quotes="",
        ))
        fillw = o["share"] / ax_max * 100
        chip = ""
        if o["is_inc"]:
            chip = '<span class="delta bench">BENCHMARK, THE SCORE TO BEAT</span>'
        elif inc:
            dv = o["share"] - inc["share"]
            chip = f'<span class="delta {"up" if dv > 0 else "down"}">{"+" if dv > 0 else ""}{dv} PTS VS LIVE</span>'
        winchip = '<span class="winchip">WINNER</span>' if o["is_winner"] else ""
        rule = ""
        if inc:
            rulel = inc["share"] / ax_max * 100
            rlbl = f'<span class="rlbl">YOUR LIVE IMAGE {inc["share"]}%</span>' if o["is_winner"] else ""
            rule = f'<span class="benchrule" style="left:{rulel:.1f}%">{rlbl}</span>'
        return f"""
    <div class="race{' win' if o['is_winner'] else ''}" id="race-{o['key']}">
      <div class="raceleft">
        <div class="raceimg" data-lb="{lb_idx}"><img data-ik="{o['ik']}" alt="{esc(opt_display(o))}"></div>
        {fname_html(o)}
      </div>
      <div class="raceright">
        <div class="racehead"><span class="racelbl">{esc(opt_display(o))}</span>{winchip}{chip}</div>
        <div class="racenum"><span class="racepct">{o['share']}%</span><span class="racevotes">{o['votes']} OF {total_votes} VOTES &middot; INTENT {o['ssr'] if o['ssr'] is not None else '?'}</span></div>
        <div class="racetrack"><i class="racefill" style="width:{fillw:.1f}%;background:{o['color']}"></i>{rule}</div>
        {pullquotes(o)}
        {drawer(o)}
      </div>
    </div>"""

    race_rows = "".join(race_row(o) for o in opts)

    # ---- verdict card -------------------------------------------------------
    stab = ctx["stab"]
    holds_str = f"{stab['holds']:,} of {stab['of']:,} resamples"
    wbase = Path(winner["path"]).name
    if inc and not winner["is_inc"]:
        vline = f"{esc(winner['label'])} ({esc(wbase)}) beats your live image {winner['share']} to {inc['share']}, {TIER_LABEL[ctx['tier']].lower()}."
    elif inc and winner["is_inc"]:
        runner = opts[1] if len(opts) > 1 else None
        vline = f"No candidate beat your live image. The incumbent holds, {winner['share']} to {runner['share'] if runner else 0}."
    else:
        runner = opts[1] if len(opts) > 1 else None
        vline = f"{esc(winner['label'])} ({esc(wbase)}) leads the race {winner['share']} to {runner['share'] if runner else 0}, {TIER_LABEL[ctx['tier']].lower()}."
    w_strengths = theme_items(themes.get("images", {}).get(winner["id"], {}).get("strengths"))
    vreason = f'The winning notes centered on: {esc(w_strengths[0][0])}.' if w_strengths else "See the notes under each image for what decided it."
    edits = [clean(e) for e in themes.get("suggested_edits", []) if clean(e)]
    donow = ""
    if edits:
        cmd = edits[0]
        donow = (f'<div class="donow"><span class="dlbl">DO NOW</span><span class="cmdpill">{esc(cmd)}</span>'
                 f'<button class="copybtn copycmd" data-cmd="{esc(cmd)}">COPY</button></div>')
    thenline = f'<div class="thenline">THEN: Re-run Round {ctx["round_no"] + 1} with the edited winner in the race.</div>'
    delta_chip = ""
    if inc and not winner["is_inc"]:
        delta_chip = f'<span class="delta up">+{winner["share"] - inc["share"]} PTS VS LIVE</span>'
    verdict_text = (
        f"Tasting Card {ctx['rid']}: {winner['label']} ({wbase}) wins the main image race with "
        f"{winner['share']}% of {total_votes} votes"
        + (f", beating the live image by {winner['share'] - inc['share']} points" if inc and not winner["is_inc"] else "")
        + f". {TIER_LABEL[ctx['tier']]}, holds in {holds_str}."
        + (f" Do now: {edits[0]}" if edits else "")
        + f" n={n} synthetic tasters, not real shoppers."
    )
    verdictcard = f"""
  <div class="verdictcard">
    <div class="vmedia">
      <div class="vthumb" data-lb="0"><img data-ik="{winner['ik']}" alt="winner"></div>
      <div class="fname" title="{esc(winner['path'])}">{esc(wbase)}</div>
    </div>
    <div class="vbody">
      <div class="vline">{vline}</div>
      <div class="vreason">{vreason}</div>
      <div class="vflip">This lead would flip only if {stab['flip_votes']} of the {total_votes} votes changed sides.</div>
      {donow}
      {thenline}
    </div>
    <div class="vnums">
      <span class="vpct">{winner['share']}%</span>
      {delta_chip}
      {tier_chip(ctx, f", holds in {holds_str}")}
    </div>
    <div class="vfoot">
      <span>{ctx['rid']} . n={n} SYNTHETIC TASTERS . {esc(ctx['run_date'])}</span>
      <button class="copybtn copyverdict">COPY VERDICT</button>
    </div>
  </div>"""

    # ---- insight section ----------------------------------------------------
    def opt_by_id(iid):
        return next((o for o in opts if o["id"] == iid), None)

    def opt_anchor(iid):
        o = opt_by_id(iid)
        return f"drawer-{o['key']}" if o else ""

    icards = []
    if w_strengths:
        txt, cnt = w_strengths[0]
        claim = f'<a class="evd" href="#drawer-{winner["key"]}">{cnt or "several"} winning-image reactions</a>'
        icards.append(
            f'<div class="icard"><span class="tagline">DOUBLE DOWN</span><b>What won the click</b>'
            f'<p>{claim} raise &ldquo;{esc(txt)}&rdquo; about {esc(wbase)}. Counts are the AI tally over the '
            f'reactions in that drawer. Keep this cue in every future candidate.</p>'
            f'<div class="icmd"><span class="efftag">NOTE</span></div></div>'
        )
    obj_ranked = sorted(themes.get("objections_ranked") or [], key=lambda o: -(o.get("count") or 0))
    if obj_ranked:
        o0 = obj_ranked[0]
        applies = (o0.get("applies_to") or [None])[0]
        anch = opt_anchor(applies) if applies else ""
        link = (f'<a class="evd" href="#{anch}">{o0.get("count") or "several"} reactions</a>' if anch
                else f'{o0.get("count") or "several"} reactions')
        pill = ""
        if edits:
            pill = (f'<span class="cmdpill">{esc(edits[0])}</span>'
                    f'<button class="copybtn copycmd" data-cmd="{esc(edits[0])}">COPY</button>'
                    f'<span class="efftag">one edit</span>')
        icards.append(
            f'<div class="icard"><span class="tagline">FIX BEFORE ROUND {ctx["round_no"] + 1}</span><b>Top recurring objection</b>'
            f'<p>{link} raise &ldquo;{esc(o0.get("text", ""))}&rdquo;. The panel&rsquo;s first suggested fix targets it.</p>'
            f'<div class="icmd">{pill or "<span class=\'efftag\'>NOTE</span>"}</div></div>'
        )
    cross = themes.get("cross_takeaways") or []
    if cross:
        icards.append(
            f'<div class="icard"><span class="tagline">CREATIVE RULE</span><b>What converts for this audience</b>'
            f'<p>{esc(cross[0])}</p>'
            f'<div class="icmd"><span class="efftag">NOTE</span></div></div>'
        )
    para = (
        f"{esc(winner['label'])} took {winner['share']}% of {total_votes} votes"
        + (f", {'+' if winner['share'] - inc['share'] > 0 else ''}{winner['share'] - inc['share']} points against your live image"
           if inc and not winner["is_inc"] else "")
        + ". "
        + (f"The winning notes centered on {esc(w_strengths[0][0])}. " if w_strengths else "")
        + (f"The loudest recurring objection across candidates: {esc(obj_ranked[0].get('text', ''))}. " if obj_ranked else "")
        + "Every count below is a link into the exact notes behind the number."
    )
    insight_section = f"""
  <section>
    <div class="shead"><span class="snum">02</span><h3>WHAT DECIDED IT</h3><span class="rule"></span><span class="note">AI SYNTHESIS OF THE PANEL NOTES</span></div>
    <div class="insight">
      <div class="ih"><span class="spark">&#10022;</span> The verdict in one paragraph</div>
      <p>{para}</p>
      <div class="icards">{''.join(icards)}</div>
      {objections_and_fixes(ctx, opt_anchor)}
    </div>
  </section>"""

    # ---- panel wall payload ---------------------------------------------------
    groups = [dict(key=o["key"], label=opt_display(o), color=o["color"], n=o["votes"]) for o in opts]
    novote = [p for p in ctx["personas"] if not vote_of.get(p["id"])]
    if novote:
        groups.append(dict(key="novote", label="NO PARSED VOTE", color=NOVOTE_COLOR, n=len(novote)))
    key_of = {o["id"]: o["key"] for o in opts}
    tasters_payload = []
    for p in ctx["personas"]:
        pid = p["id"]
        voted = vote_of.get(pid)
        gkey = key_of.get(voted, "novote")
        # the taster's primary note = their reaction to the image they chose
        # (or to the top-ranked image when no vote parsed)
        home = opt_by_id(voted) if voted else opts[0]
        rx = next((r for r in home["reactions"] if r["persona_id"] == pid), None)
        tasters_payload.append(dict(
            syn=syn_id(pid), n=str(pid), meta=esc(taster_meta(p)), group=gkey,
            comment=clean(rx["text"]) if rx else "(no reaction recorded)",
            anchor=f"note-{home['key']}-{pid}",
            open=dict(type="drawer", key=f"drawer-{home['key']}"),
        ))
    legend = "".join(f'<span class="wl"><i style="background:{g["color"]}"></i>{esc(g["label"])} ({g["n"]})</span>' for g in groups)

    wall_section = f"""
  <section>
    <div class="shead"><span class="snum">03</span><h3>THE PANEL &middot; ALL {n} TASTERS</h3><span class="rule"></span><span class="note" id="wallnote">HOVER OR CLICK ANY TASTER</span></div>
    <div class="walltoggle">
      <button class="wtbtn on" data-mode="group">GROUP BY VOTE</button>
      <button class="wtbtn" data-mode="shuffle">SHUFFLE</button>
    </div>
    <div id="wallhost"></div>
    <div class="tdetail" id="tdetail"></div>
    <div class="wall-legend">{legend}</div>
  </section>"""

    # ---- demographics ---------------------------------------------------------
    buckets = []
    bands = sorted({p.get("age_band") for p in ctx["personas"] if p.get("age_band")})
    for b in bands:
        buckets.append((f"AGES {b.upper()}", [p for p in ctx["personas"] if p.get("age_band") == b]))
    genders = sorted({clean(p.get("gender", "")) for p in ctx["personas"]})
    for g in genders:
        buckets.append((g.upper(), [p for p in ctx["personas"] if clean(p.get("gender", "")) == g]))
    demo_rows = ""
    any_flip = False
    min_n = None
    for lbl, members in buckets:
        voters = [p for p in members if vote_of.get(p["id"])]
        nn = len(voters)
        if nn == 0:
            continue
        min_n = nn if min_n is None else min(min_n, nn)
        counts = [sum(1 for p in voters if vote_of.get(p["id"]) == o["id"]) for o in opts]
        leader = opts[max(range(len(opts)), key=lambda j: counts[j])]["id"]
        flips = leader != winner["id"]
        any_flip = any_flip or flips
        segs = ""
        for o, c in zip(opts, counts):
            w = c / nn * 100
            pct = f'<span class="dpct">{round(w)}%</span>' if w >= 8 else ""
            segs += f'<i class="dseg" style="width:{w:.1f}%;background:{o["color"]}">{pct}</i>'
        tick = f'<span class="dtick" style="left:{winner["share"]}%"></span>'
        flipchip = ' <span class="flipchip">FLIPS THE WINNER</span>' if flips else ""
        demo_rows += f"""<div class="demo{' flip' if flips else ''}">
      <div class="lbl">{esc(lbl)}<span class="dn-inline"> . n = {nn}</span></div>
      <div class="dtrack">{segs}{tick}</div>
      <div class="lbl dn-col" style="text-align:left">n = {nn}{flipchip}</div></div>"""
    pm = round(196 * math.sqrt(0.25 / max(1, min_n or 1)))
    demo_foot = (
        f"Buckets this small carry roughly plus or minus {pm} points per share (smallest bucket n = {min_n}). "
        "Only gaps larger than that are worth acting on. "
        + ("One slice flips the winner above; treat it as a flag to explore, not a conclusion."
           if any_flip else "In this run no group flipped the winner.")
    )
    # model agreement
    model_html = ""
    if ctx["models_agree"] is not None:
        rows = ""
        for m in ctx["model_names"]:
            members = [p for p in ctx["personas"] if p.get("model") == m and vote_of.get(p["id"])]
            if not members:
                continue
            counts = {o["id"]: sum(1 for p in members if vote_of.get(p["id"]) == o["id"]) for o in opts}
            segs = "".join(
                f'<i class="dseg" style="width:{counts[o["id"]] / len(members) * 100:.1f}%;background:{o["color"]}"></i>'
                for o in opts)
            rows += (f'<div class="mrgrid"><div class="mrlbl">{esc(m)} . n = {len(members)}</div>'
                     f'<div class="dtrack" style="height:14px">{segs}</div></div>')
        chip = ('<span class="agreechip yes">ALL MODEL FAMILIES RANK THE SAME WINNER</span>' if ctx["models_agree"]
                else '<span class="agreechip no">MODELS DISAGREE ON THE WINNER, treat as toss-up</span>')
        model_html = f'<div class="blockhead">MODEL AGREEMENT</div>{rows}{chip}'
    demo_section = f"""
  <section>
    <div class="shead"><span class="snum">04</span><h3>WHO VOTED FOR WHAT</h3><span class="rule"></span></div>
    <div class="subhead">Slices describe this panel. They are too small to prove subgroup differences.</div>
    {demo_rows}
    <div class="wall-legend" style="margin-top:12px">{legend}</div>
    <div class="demofoot">{demo_foot} The dark tick marks the winner's overall {winner['share']}% share.</div>
    {model_html}
  </section>"""

    # ---- CSV -------------------------------------------------------------------
    csv_rows = [["taster_id", "age", "age_band", "gender", "income", "model",
                 "shopping_style", "skepticism", "attention", "familiarity",
                 "vote", "candidate", "candidate_label", "ssr", "sentiment", "reaction"]]
    for o in opts:
        for r in o["reactions"]:
            p = pmap.get(r["persona_id"], {})
            csv_rows.append([
                syn_id(r["persona_id"]), p.get("age", ""), p.get("age_band", ""), p.get("gender", ""),
                p.get("income", ""), p.get("model", ""), p.get("shopping_style", ""), p.get("skepticism", ""),
                p.get("attention", ""), p.get("familiarity", ""),
                clean(vote_of.get(r["persona_id"], "")), o["id"], o["label"], r.get("ssr", ""),
                sentiment(r.get("ssr")), clean(r["text"]),
            ])
    csv_text = to_csv(csv_rows)

    payload = dict(
        rid=ctx["rid"], verdict_text=verdict_text, csv=csv_text, csv_name=f"{ctx['rid']}.csv",
        imgs={k: v[1] for k, v in imgs.items()},
        groups=groups, tasters=tasters_payload, lb=lb_items,
    )

    k = len(opts)
    sub = (f"Round {ctx['round_no']}. {k} images went on the shelf"
           + (f": {k - 1} candidates and your live Amazon image" if inc else " (no live image in the race)")
           + f". {n} synthetic tasters, each conditioned on the buyer demographics, picked the one they would click.")
    qsub = (f"All {k} shown side by side, order randomized per taster."
            + (" Your current live image is always in the race." if inc else
               " No live listing was in the race (pre-launch), so this verdict is weaker."))
    howto_extra = (f'<p style="margin-top:8px">Every image carries its own drawer with all {total_votes} reactions '
                   'to it. Every note on this card is under an image.</p>')
    presentation = f"{k} images side by side, order randomized per taster"
    next_line = f"NEXT: APPLY THE FIX, THEN ROUND {ctx['round_no'] + 1}" if edits else f"NEXT: ROUND {ctx['round_no'] + 1}"

    body = f"""{masthead(ctx, 'THE TASTING ROOM &middot; MAIN IMAGE RACE', sub)}
{status_block(ctx)}
{export_row()}
{verdictcard}
{chips_row(ctx)}
  <div class="qline">
    <div class="q">Q: You are shopping for <em>{esc(ctx['product'])}</em>. Which image do you click?</div>
    <div class="qsub">{qsub}</div>
  </div>
  <section>
    <div class="shead"><span class="snum">01</span><h3>THE RACE &middot; RANKED BY CLICKS</h3><span class="rule"></span><span class="note">FULL NOTES UNDER EACH IMAGE</span></div>
    <div class="raceaxis"><span>0</span><span>SHARE OF {total_votes} VOTES &middot; ONE COMMON SCALE, 0 TO {ax_max}</span><span>{ax_max}</span></div>
    {race_rows}
  </section>
{insight_section}
{wall_section}
{demo_section}
{comparison_section(ctx, '05')}
{method_block(ctx, howto_extra, presentation)}
{footer_block(ctx, next_line)}"""

    return assemble(ctx, "Main Image Race", body, payload)


# ---------------------------------------------------------------------------
# REPORT B: GALLERY DUEL
# ---------------------------------------------------------------------------

def frame_taxonomy(strongest, weakest, vote_total, net):
    """One tag per frame. Thresholds printed verbatim in the methodology box."""
    if net is not None and net < 0:
        return ("drags", "DRAGS")
    if vote_total:
        sp = strongest / vote_total
        if sp >= 0.25:
            return ("carries", "CARRIES")
        if (strongest + weakest) <= max(2, round(0.05 * vote_total)) and abs(net or 0) <= 1:
            return ("barely", "BARELY NOTICED")
    elif net is not None and net <= 1 and net >= -1:
        return ("barely", "BARELY NOTICED")
    return ("pulls", "PULLS ITS WEIGHT")


def build_report_b(ctx):
    res, agg = ctx["res"], ctx["agg"]
    ranked, inc_id, winner_id = ctx["ranked"], ctx["inc_id"], ctx["winner_id"]
    pmap, vote_of, n, total_votes = ctx["pmap"], ctx["vote_of"], ctx["n"], ctx["total_votes"]
    themes = ctx["themes"]
    image_agg = res.get("image_agg", {}) or {}

    imgs = {}
    path_ik = {}
    def ik_of(path):
        if path in path_ik:
            return path_ik[path]
        key = f"i{len(imgs)}"
        imgs[key] = img_data_uri(path)
        path_ik[path] = key
        return key

    # set records
    set_colors = []
    ci = 0
    sets = []
    for rank, img in enumerate(ranked):
        iid = img["id"]
        a = agg[iid]
        is_inc = iid == inc_id
        color = INC_COLOR if is_inc else OPT_COLORS[ci % len(OPT_COLORS)]
        if not is_inc:
            ci += 1
        paths = img.get("paths") or [img.get("path", "")]
        reactions = [r for r in res.get("reactions", []) if r["image_id"] == iid and not clean(r["text"]).startswith("__ERROR__")]
        reactions.sort(key=lambda r: -(r.get("ssr") or 0))
        sents = Counter(sentiment(r.get("ssr")) for r in reactions)
        rows = image_agg.get(iid) or []
        sets.append(dict(
            id=iid, key=f"set{rank}", label=clean(a.get("label", iid)).upper(), color=color,
            votes=a.get("choice_votes", 0), share=round(a.get("choice_share", 0) * 100),
            is_inc=is_inc, is_winner=iid == winner_id, paths=paths, rows=rows,
            reactions=reactions, pos=sents["positive"], neu=sents["neutral"], neg=sents["negative"],
            cls="setB" if is_inc else "setA",
        ))
    winner = next(s for s in sets if s["is_winner"])

    wv = res.get("within_votes", []) or []
    wv_by = {}
    for v in wv:
        wv_by[(v["persona_id"], v["set_id"])] = v

    # per-frame derived records
    max_str = 1
    for s in sets:
        frames = []
        for idx, path in enumerate(s["paths"], 1):
            row = next((r for r in s["rows"] if r.get("idx") == idx), None)
            st = (row or {}).get("strongest_votes") or 0
            wk = (row or {}).get("weakest_votes") or 0
            vt = (row or {}).get("vote_total") or 0
            net = (row or {}).get("net_impact")
            taxk, taxl = frame_taxonomy(st, wk, vt, net)
            frames.append(dict(
                idx=idx, path=path, ik=ik_of(path), row=row, strongest=st, weakest=wk,
                vote_total=vt, net=net, taxk=taxk, taxl=taxl,
                boosts=(row or {}).get("boosts", 0), hurts=(row or {}).get("hurts", 0),
                neutral=(row or {}).get("neutral", 0), fb=(row or {}).get("feedback") or [],
                nfb=(row or {}).get("n", 0), ssr=(row or {}).get("ssr_mean"),
                takeaway=clean((row or {}).get("takeaway", "")),
                top_works=theme_items((row or {}).get("top_works")),
                top_doesnt=theme_items((row or {}).get("top_doesnt")),
                key=f"{s['key']}-f{idx}",
            ))
            max_str = max(max_str, st)
        s["frames"] = frames

    lb_items = []
    lb_index = {}
    def lb_of(s, f):
        if f["key"] in lb_index:
            return lb_index[f["key"]]
        i = len(lb_items)
        lb_index[f["key"]] = i
        lb_items.append(dict(
            ik=f["ik"], label=f"{s['label']}, frame {f['idx']} of {len(s['frames'])}",
            meta=(f"most convincing for {f['strongest']} of {f['vote_total']} set voters, "
                  f"{f['boosts']} boosts / {f['hurts']} hurts" if f["vote_total"] else "no within-set votes recorded"),
            file=f["path"], quotes=f["takeaway"],
        ))
        return i

    def fname_html(f, mini=False):
        base = Path(f["path"]).name
        return f'<div class="fname{" mini" if mini else ""}" title="{esc(f["path"])}">{esc(base)}</div>'

    # ---- scoreboard -----------------------------------------------------------
    if len(sets) == 2:
        a, b = sets[0], sets[1]
        splitbar = f"""
    <div class="splitnames"><span class="l">{esc(a['label'])}{' (WINNER)' if a['is_winner'] else ''}</span><span class="r">{esc(b['label'])}{' (ON AMAZON TODAY)' if b['is_inc'] else ''}</span></div>
    <div class="splitbar"><i class="sl" style="width:{a['share']}%;background:{a['color']}">{a['share']}%</i><i class="sr" style="width:{max(0, 100 - a['share'])}%;background:{b['color']}">{b['share']}%</i></div>"""
    else:
        rows = ""
        for s in sets:
            rows += (f'<div class="setshare"><span>{esc(s["label"])}</span>'
                     f'<span class="sst"><i style="width:{s["share"]}%;background:{s["color"]}"></i></span>'
                     f'<span>{s["share"]}% ({s["votes"]})</span></div>')
        splitbar = rows

    def strip_block(s):
        tag = ('<span class="setwinchip">SET WINNER</span>' if s["is_winner"]
               else ('<span class="setbenchchip">ON AMAZON TODAY</span>' if s["is_inc"] else ""))
        cells = ""
        for f in s["frames"]:
            cells += (f'<div class="sframe"><div class="fpos">{f["idx"]}</div>'
                      f'<div class="fimg" data-lb="{lb_of(s, f)}"><img data-ik="{f["ik"]}" alt="frame {f["idx"]}"></div>'
                      f'<div class="scap {f["taxk"]}">{f["taxl"]}</div>'
                      f'{fname_html(f, mini=True)}</div>')
        return f"""
    <div class="setblock {'win' if s['is_winner'] else ''}">
      <div class="setbar"><span class="setname" style="color:{s['color']}">{esc(s['label'])}</span>
        <span class="cntchip">{len(s['frames'])} FRAMES</span>
        <span class="setvotes">{s['votes']} OF {total_votes} VOTES</span>{tag}</div>
      <div class="strip">{cells}</div>
    </div>"""

    # ---- frame cards ------------------------------------------------------------
    def frame_card(s, f):
        m = f["nfb"]
        barw = round(f["strongest"] / max_str * 100)
        if f["vote_total"]:
            mlabel = f"MOST CONVINCING FOR {f['strongest']} OF {f['vote_total']} SET VOTERS"
        else:
            mlabel = "NO WITHIN-SET VOTES RECORDED"
        chips = ""
        if m:
            chips = (f'<span class="mchip ok">{f["boosts"]} boosts</span>'
                     f'<span class="mchip bad">{f["hurts"]} hurts</span>'
                     f'<span class="mchip mid">sampled n = {m}</span>')
        weak = f'<span class="mchip bad">{f["weakest"]} called it weakest</span>' if f["weakest"] else ""
        wchips = "".join(f'<span class="tchip ok">{esc(t)}{(" x" + str(c)) if c else ""}</span>' for t, c in f["top_works"])
        dchips = "".join(f'<span class="tchip bad">{esc(t)}{(" x" + str(c)) if c else ""}</span>' for t, c in f["top_doesnt"])
        themechips = f'<div class="chips">{wchips}{dchips}</div>' if (wchips or dchips) else ""
        take = f'<div class="fctake">{esc(f["takeaway"])}</div>' if f["takeaway"] else ""
        # representative quote: the highest-intent boosting note, verbatim
        quote = ""
        boosts_fb = sorted([x for x in f["fb"] if x.get("impact") == "boosts"], key=lambda x: -(x.get("ssr") or 0))
        pick = boosts_fb[0] if boosts_fb else (f["fb"][0] if f["fb"] else None)
        if pick:
            p = pmap.get(pick.get("persona_id"), {})
            quote = (f'<div class="fquote">&ldquo;{esc(pick.get("reaction", ""))}&rdquo;'
                     f'<span class="qby">{syn_id(pick.get("persona_id", 0))}, {esc(taster_meta(p))}</span></div>')
        # drawer
        if not f["fb"]:
            drawer = ('<div class="nomention">No per-frame notes were collected for this frame in this run. '
                      'The set-level notes live in the full transcript below.</div>')
        else:
            rows = []
            fb_sorted = sorted(f["fb"], key=lambda x: -(x.get("ssr") or 0))
            sc = Counter("positive" if x.get("impact") == "boosts" else ("negative" if x.get("impact") == "hurts" else "neutral") for x in fb_sorted)
            for i, x in enumerate(fb_sorted, 1):
                pid = x.get("persona_id", 0)
                p = pmap.get(pid, {})
                extra = ""
                if clean(x.get("works", "")):
                    extra += f'<div class="wd ok">+ {esc(x["works"])}</div>'
                if clean(x.get("doesnt", "")):
                    extra += f'<div class="wd bad">- {esc(x["doesnt"])}</div>'
                sent = "positive" if x.get("impact") == "boosts" else ("negative" if x.get("impact") == "hurts" else "neutral")
                meta = (f"{syn_id(pid)} &middot; persona: {esc(taster_meta(p))} &middot; conditioned as: {esc(conditioned_line(p))}"
                        f' &middot; <a href="#note-{s["key"]}-{pid}" data-jump="{syn_id(pid)}">full set-level note</a>')
                rows.append(resp_row_html(
                    anchor_id=f"fnote-{f['key']}-{pid}", av_color=s["color"], av_letter=sex_letter(p.get("gender")),
                    text_html=esc(x.get("reaction", "")), sent=sent, meta=meta, idx=i,
                    voter=vote_of.get(pid) == s["id"], extra=extra,
                ))
            head = (f"{m} structured single-frame notes from a sampled sub-panel of {m} of the {n} tasters. "
                    "Tasters voted on whole sets, not single frames; these notes judge this frame alone. "
                    "BOOSTS / HURTS is each taster's own call on whether this frame moves them toward or away from buying.")
            drawer = f"""<details class="notesdrawer" id="drawer-{f['key']}">
        <summary>READ ALL {m} FRAME NOTES<span class="sumtally">{f['boosts']} BOOSTS / {f['neutral']} NEUTRAL / {f['hurts']} HURTS</span></summary>
        <div class="drawerinner">
          <div class="drawerhead">{head}</div>
          {filter_row(m, sc['positive'], sc['neutral'], sc['negative'])}
          <div class="drawerbody"><div class="drows">{''.join(rows)}</div></div>
        </div>
      </details>"""
        return f"""
    <article class="framecard {s['cls']}" id="frame-{f['key']}">
      <div class="fcgrid">
        <div class="fcleft">
          <div class="fcpos fpos">{f['idx']}</div>
          <div class="fcimg" data-lb="{lb_of(s, f)}"><img data-ik="{f['ik']}" alt="frame {f['idx']}"></div>
          {fname_html(f)}
        </div>
        <div class="fcbody">
          <div class="fchead">
            <span class="setchip" style="background:{s['color']}">{esc(s['label'])}</span>
            <span class="fcofn">FRAME {f['idx']} OF {len(s['frames'])} &middot; ITS OWN GALLERY ORDER</span>
            <span class="ftag {f['taxk']}">{f['taxl']}</span>
          </div>
          {take}
          <div class="mbarwrap"><div class="mentionbar"><i style="width:{barw}%;background:{s['color']}"></i></div>
            <span class="mlabel">{mlabel}</span>{chips}{weak}</div>
          {themechips}
          {quote}
        </div>
      </div>
      {drawer}
    </article>"""

    frame_sections = ""
    sec_letters = "ABCDEFGH"
    for si, s in enumerate(sets):
        cards = "".join(frame_card(s, f) for f in s["frames"])
        tagline = "EACH FRAME STANDS ON ITS OWN"
        frame_sections += f"""
  <section>
    <div class="shead"><span class="snum">02{sec_letters[si]}</span><h3>FRAME BY FRAME &middot; {esc(s['label'])} ({len(s['frames'])} FRAMES)</h3><span class="rule"></span><span class="note">{tagline}</span></div>
    {cards}
  </section>"""

    # ---- verdict card ------------------------------------------------------------
    stab = ctx["stab"]
    holds_str = f"{stab['holds']:,} of {stab['of']:,} resamples"
    inc_set = next((s for s in sets if s["is_inc"]), None)
    runner = sets[1] if len(sets) > 1 else None
    if inc_set and not winner["is_inc"]:
        vline = (f"Your proposed {len(winner['frames'])}-frame set leads the live {len(inc_set['frames'])}-frame set "
                 f"{winner['share']} to {inc_set['share']}.")
    elif inc_set and winner["is_inc"]:
        vline = (f"The live {len(winner['frames'])}-frame set holds off the proposed {len(runner['frames']) if runner else 0}-frame set "
                 f"{winner['share']} to {runner['share'] if runner else 0}.")
    else:
        vline = f"{esc(winner['label'])} leads the duel {winner['share']} to {runner['share'] if runner else 0}."
    w_strengths = theme_items(themes.get("images", {}).get(winner["id"], {}).get("strengths"))
    vreason = f"The winning notes centered on: {esc(w_strengths[0][0])}." if w_strengths else "The verdict is per set; the frame cards below say what to fix."
    edits = [clean(e) for e in themes.get("suggested_edits", []) if clean(e)]
    donow = ""
    if edits:
        donow = (f'<div class="donow"><span class="dlbl">DO NOW</span><span class="cmdpill">{esc(edits[0])}</span>'
                 f'<button class="copybtn copycmd" data-cmd="{esc(edits[0])}">COPY</button></div>')
    thenline = f'<div class="thenline">THEN: Re-run the duel with the fixed frames. Aim for CLEAR LEAD before shipping.</div>'
    mini = "".join(
        f'<div class="vthumb" data-lb="{lb_of(winner, f)}"><img data-ik="{f["ik"]}" alt="frame {f["idx"]}"></div>'
        for f in winner["frames"][:3]
    )
    delta_chip = ""
    if inc_set and not winner["is_inc"]:
        delta_chip = f'<span class="delta up">+{winner["share"] - inc_set["share"]} PTS VS LIVE SET</span>'
    verdict_text = (
        f"Tasting Card {ctx['rid']} (gallery duel): {winner['label'].title()} wins the set vote "
        f"{winner['share']} to {inc_set['share'] if inc_set and not winner['is_inc'] else (runner['share'] if runner else 0)}"
        f" of {total_votes}. {TIER_LABEL[ctx['tier']]}, holds in {holds_str}."
        + (f" Do now: {edits[0]}" if edits else "")
        + f" n={n} synthetic tasters, not real shoppers."
    )
    verdictcard = f"""
  <div class="verdictcard">
    <div class="vmedia"><div class="vstripthumbs">{mini}</div></div>
    <div class="vbody">
      <div class="vline">{vline} {TIER_LABEL[ctx['tier']].title()}.</div>
      <div class="vreason">{vreason}</div>
      <div class="vflip">The lead disappears if {stab['flip_votes']} of the {total_votes} votes change sides.</div>
      {donow}
      {thenline}
    </div>
    <div class="vnums">
      <span class="vpct">{winner['share']}%</span>
      {delta_chip}
      {tier_chip(ctx, f", holds in {holds_str}")}
    </div>
    <div class="vfoot">
      <span>{ctx['rid']} . n={n} SYNTHETIC TASTERS . {esc(ctx['run_date'])}</span>
      <button class="copybtn copyverdict">COPY VERDICT</button>
    </div>
  </div>"""

    # ---- insight section -----------------------------------------------------------
    def set_anchor(iid):
        s = next((s for s in sets if s["id"] == iid), None)
        return f"race-{s['key']}" if False else (f"feed-{s['key']}" if s else "")

    # strongest / weakest frame callouts (computed)
    all_frames = [(s, f) for s in sets for f in s["frames"]]
    strongest_sf = max(all_frames, key=lambda sf: sf[1]["strongest"]) if all_frames else None
    drag_sf = None
    drags = [(s, f) for s, f in all_frames if f["taxk"] == "drags" and not s["is_inc"]]
    if drags:
        drag_sf = max(drags, key=lambda sf: sf[1]["hurts"])
    icards = []
    if strongest_sf and strongest_sf[1]["vote_total"]:
        s0, f0 = strongest_sf
        icards.append(
            f'<div class="icard"><span class="tagline">DOUBLE DOWN</span><b>The strongest frame in either gallery</b>'
            f'<p><a class="evd" href="#frame-{f0["key"]}">{f0["strongest"]} of {f0["vote_total"]} within-set votes</a> '
            f'pick {esc(s0["label"].lower())} frame {f0["idx"]} ({esc(Path(f0["path"]).name)}) as the most convincing. '
            f'{esc(f0["takeaway"]) if f0["takeaway"] else ""}</p>'
            f'<div class="icmd"><span class="efftag">NOTE</span></div></div>'
        )
    if drag_sf:
        s1, f1 = drag_sf
        pill = ""
        if edits:
            pill = (f'<span class="cmdpill">{esc(edits[0])}</span>'
                    f'<button class="copybtn copycmd" data-cmd="{esc(edits[0])}">COPY</button>'
                    f'<span class="efftag">one edit</span>')
        icards.append(
            f'<div class="icard"><span class="tagline">FIX BEFORE ROUND {ctx["round_no"] + 1}</span><b>The frame costing votes</b>'
            f'<p><a class="evd" href="#frame-{f1["key"]}">{f1["hurts"]} of {f1["nfb"]} frame notes</a> say '
            f'{esc(s1["label"].lower())} frame {f1["idx"]} ({esc(Path(f1["path"]).name)}) hurts the sale'
            f'{", and " + str(f1["weakest"]) + " within-set votes call it the weakest" if f1["weakest"] else ""}.</p>'
            f'<div class="icmd">{pill or "<span class=\'efftag\'>NOTE</span>"}</div></div>'
        )
    cross = themes.get("cross_takeaways") or []
    if cross:
        icards.append(
            f'<div class="icard"><span class="tagline">CREATIVE RULE</span><b>What converts for this audience</b>'
            f'<p>{esc(cross[0])}</p><div class="icmd"><span class="efftag">NOTE</span></div></div>'
        )
    obj_ranked = sorted(themes.get("objections_ranked") or [], key=lambda o: -(o.get("count") or 0))
    para = (
        f"The verdict is per set: {esc(winner['label'].lower())} took {winner['share']}% of {total_votes} votes. "
        + (f"The winning notes centered on {esc(w_strengths[0][0])}. " if w_strengths else "")
        + (f"The loudest recurring objection: {esc(obj_ranked[0].get('text', ''))}. " if obj_ranked else "")
        + "The frame cards above say what to keep and what to fix; every count is a link into the notes behind it."
    )
    insight_section = f"""
  <section>
    <div class="shead"><span class="snum">03</span><h3>WHAT DECIDED IT</h3><span class="rule"></span><span class="note">AI SYNTHESIS OF THE PANEL NOTES</span></div>
    <div class="insight">
      <div class="ih"><span class="spark">&#10022;</span> The verdict in one paragraph</div>
      <p>{para}</p>
      <div class="icards">{''.join(icards)}</div>
      {objections_and_fixes(ctx, lambda iid: next((f"feed-{s['key']}" for s in sets if s["id"] == iid), ""))}
    </div>
  </section>"""

    # ---- panel wall --------------------------------------------------------------
    groups = [dict(key=s["key"], label=s["label"], color=s["color"], n=s["votes"]) for s in sets]
    novote = [p for p in ctx["personas"] if not vote_of.get(p["id"])]
    if novote:
        groups.append(dict(key="novote", label="NO PARSED VOTE", color=NOVOTE_COLOR, n=len(novote)))
    key_of = {s["id"]: s["key"] for s in sets}
    tasters_payload = []
    for p in ctx["personas"]:
        pid = p["id"]
        voted = vote_of.get(pid)
        home = next((s for s in sets if s["id"] == voted), sets[0])
        rx = next((r for r in home["reactions"] if r["persona_id"] == pid), None)
        tasters_payload.append(dict(
            syn=syn_id(pid), n=str(pid), meta=esc(taster_meta(p)), group=key_of.get(voted, "novote"),
            comment=clean(rx["text"]) if rx else "(no reaction recorded)",
            anchor=f"note-{home['key']}-{pid}",
            open=dict(type="tab", key=home["key"]),
        ))
    legend = "".join(f'<span class="wl"><i style="background:{g["color"]}"></i>CHOSE {esc(g["label"])} ({g["n"]})</span>'
                     if g["key"] != "novote" else
                     f'<span class="wl"><i style="background:{g["color"]}"></i>{esc(g["label"])} ({g["n"]})</span>'
                     for g in groups)
    wall_section = f"""
  <section>
    <div class="shead"><span class="snum">04</span><h3>THE PANEL &middot; ALL {n} TASTERS</h3><span class="rule"></span><span class="note" id="wallnote">HOVER OR CLICK ANY TASTER</span></div>
    <div class="walltoggle">
      <button class="wtbtn on" data-mode="group">GROUP BY VOTE</button>
      <button class="wtbtn" data-mode="shuffle">SHUFFLE</button>
    </div>
    <div id="wallhost"></div>
    <div class="tdetail" id="tdetail"></div>
    <div class="wall-legend">{legend}</div>
  </section>"""

    # ---- global transcript (kept: votes are per set) -------------------------------
    def feed_pane(s, on=False):
        rows = []
        for i, r in enumerate(s["reactions"], 1):
            pid = r["persona_id"]
            p = pmap.get(pid, {})
            meta = f"{syn_id(pid)} &middot; persona: {esc(taster_meta(p))} &middot; conditioned as: {esc(conditioned_line(p))}"
            rows.append(resp_row_html(
                anchor_id=f"note-{s['key']}-{pid}", av_color=s["color"], av_letter=sex_letter(p.get("gender")),
                text_html=esc(r["text"]), sent=sentiment(r.get("ssr")), meta=meta, idx=i,
                voter=vote_of.get(pid) == s["id"],
            ))
        return (f'<div class="feedpane{" on" if on else ""}" id="feed-{s["key"]}" data-set="{s["key"]}">'
                f'{filter_row(len(s["reactions"]), s["pos"], s["neu"], s["neg"], voters=s["votes"])}'
                f'<div class="drows">{"".join(rows)}</div></div>')

    tabs = "".join(
        f'<div class="ftab{" on" if i == 0 else ""}" data-k="{s["key"]}" role="button" tabindex="0">{esc(s["label"])} &middot; {s["votes"]}</div>'
        for i, s in enumerate(sets)
    )
    panes = "".join(feed_pane(s, on=(i == 0)) for i, s in enumerate(sets))
    transcript_section = f"""
  <section>
    <div class="shead"><span class="snum">05</span><h3>THE FULL TRANSCRIPT &middot; EVERY SET REACTION</h3><span class="rule"></span></div>
    <div class="feedhead">Verbatim reactions generated in persona. Sentiment auto-classified from the SSR purchase-intent score.
    Votes are per SET; the frame cards above draw their frame notes from a separate per-frame pass. Rows marked VOTER
    belong to tasters whose forced choice went to that set.</div>
    <div class="feedtabs">{tabs}</div>
    <div class="feedwrap">{panes}</div>
  </section>"""

    # ---- model agreement -------------------------------------------------------------
    model_section = ""
    if ctx["models_agree"] is not None:
        rows = ""
        for m in ctx["model_names"]:
            members = [p for p in ctx["personas"] if p.get("model") == m and vote_of.get(p["id"])]
            if not members:
                continue
            segs = ""
            for s in sets:
                c = sum(1 for p in members if vote_of.get(p["id"]) == s["id"])
                segs += f'<i class="dseg" style="width:{c / len(members) * 100:.1f}%;background:{s["color"]}"></i>'
            rows += (f'<div class="mrgrid"><div class="mrlbl">{esc(m)} . n = {len(members)}</div>'
                     f'<div class="dtrack" style="height:14px">{segs}</div></div>')
        chip = ('<span class="agreechip yes">ALL MODEL FAMILIES RANK THE SAME WINNER</span>' if ctx["models_agree"]
                else '<span class="agreechip no">MODELS DISAGREE ON THE WINNER, treat as toss-up</span>')
        model_section = f"""
  <section>
    <div class="shead"><span class="snum">06</span><h3>MODEL AGREEMENT</h3><span class="rule"></span><span class="note">{len(ctx['model_names'])} MODEL FAMILIES</span></div>
    {rows}{chip}
  </section>"""

    # ---- CSV ---------------------------------------------------------------------------
    csv_rows = [["taster_id", "age", "age_band", "gender", "income", "model", "vote",
                 "set", "set_label", "ssr", "sentiment", "best_frame_in_set", "weakest_frame_in_set", "reaction"]]
    for s in sets:
        for r in s["reactions"]:
            pid = r["persona_id"]
            p = pmap.get(pid, {})
            v = wv_by.get((pid, s["id"]), {})
            csv_rows.append([
                syn_id(pid), p.get("age", ""), p.get("age_band", ""), p.get("gender", ""), p.get("income", ""),
                p.get("model", ""), clean(vote_of.get(pid, "")), s["id"], s["label"], r.get("ssr", ""),
                sentiment(r.get("ssr")), v.get("best", ""), v.get("worst", ""), clean(r["text"]),
            ])
    csv_text = to_csv(csv_rows)

    payload = dict(
        rid=ctx["rid"], verdict_text=verdict_text, csv=csv_text, csv_name=f"{ctx['rid']}.csv",
        imgs=imgs, groups=groups, tasters=tasters_payload, lb=lb_items,
    )

    counts_str = " + ".join(str(len(s["frames"])) for s in sets)
    sub = (f"Round {ctx['round_no']}. {len(sets)} whole galleries went head to head"
           + (f": your proposed {len(winner['frames'])}-frame set against the {len(inc_set['frames'])}-frame gallery live on Amazon today"
              if inc_set and not winner["is_inc"] else "")
           + f". {n} synthetic tasters browsed each stack and picked the page they would buy from.")
    qsub = ("The galleries have different frame counts and orders. Each taster browsed each stack as it would "
            "appear on Amazon. The verdict is per set, so no frame matching is needed or implied.")
    tax_para = ('<p style="margin-top:8px"><b>The frame taxonomy.</b> A frame DRAGS when its hurts outnumber its '
                'boosts (net impact below zero). CARRIES: at least 25% of within-set votes pick it most convincing. '
                'BARELY NOTICED: it draws 5% or fewer of the best/worst votes and its net impact is within 1. '
                'Everything else PULLS ITS WEIGHT.</p>'
                '<p style="margin-top:8px">The verdict is per SET: tasters judge the whole stack, so a set&rsquo;s '
                'score is not the average of its frames. The frame cards answer WHAT TO FIX. The galleries are not '
                'matched frame to frame, and no matching is implied.</p>')
    presentation = f"{len(sets)} stacks, {counts_str} frames, gallery order, sides randomized per taster"
    next_line = f"NEXT: APPLY THE FIX, THEN ROUND {ctx['round_no'] + 1}" if edits else f"NEXT: ROUND {ctx['round_no'] + 1}"

    body = f"""{masthead(ctx, 'THE TASTING ROOM &middot; GALLERY DUEL &middot; SET VS SET', sub)}
{status_block(ctx)}
{export_row()}
{verdictcard}
{chips_row(ctx, extra=[f"{counts_str} FRAMES &middot; {len(sets)} STACKS"])}
  <div class="qline">
    <div class="q">Q: {len(sets)} galleries, same product. <em>Which page sells it better?</em></div>
    <div class="qsub">{qsub}</div>
  </div>
  <section>
    <div class="shead"><span class="snum">01</span><h3>THE SCOREBOARD</h3><span class="rule"></span><span class="note">SET-LEVEL VERDICT</span></div>
    {splitbar}
    {''.join(strip_block(s) for s in sets)}
  </section>
{frame_sections}
{insight_section}
{wall_section}
{transcript_section}
{model_section}
{comparison_section(ctx, '07')}
{method_block(ctx, tax_para, presentation)}
{footer_block(ctx, next_line)}"""

    return assemble(ctx, "Gallery Duel", body, payload)


# ---------------------------------------------------------------------------
# assembly
# ---------------------------------------------------------------------------

def to_csv(rows):
    out = []
    for r in rows:
        cells = []
        for v in r:
            v = clean(v)
            if any(ch in v for ch in ',"\n'):
                v = '"' + v.replace('"', '""') + '"'
            cells.append(v)
        out.append(",".join(cells))
    return "\n".join(out)


def assemble(ctx, kind, body, payload):
    js = JS_TMPL.replace("__PAYLOAD__", json.dumps(payload).replace("</", "<\\/"))
    doc = f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Tasting Card {ctx['rid']} | {kind}</title>
<style>{CSS}</style>
</head>
<body>
<div class="sheet">
{body}
</div>
<script>{js}</script>
</body>
</html>"""
    assert_clean(doc)
    return doc


def main():
    if len(sys.argv) < 2:
        raise SystemExit("usage: tasting_card_v3.py <results.json> [out.html]")
    src = Path(sys.argv[1])
    res = json.loads(src.read_text())
    out = Path(sys.argv[2]) if len(sys.argv) > 2 else src.parent / "tasting-card.html"
    ctx = build_ctx(res, src)
    stacks_mode = any(len(i.get("paths") or [1]) > 1 for i in res["images"])
    doc = build_report_b(ctx) if stacks_mode else build_report_a(ctx)
    out.write_text(doc)
    print(f"wrote {out} ({len(doc):,} bytes)")
    print(f"scenario: {'B gallery duel' if stacks_mode else 'A main image race'} | tier: {TIER_LABEL[ctx['tier']]} "
          f"({ctx['stab']['holds']}/{ctx['stab']['of']} resamples) | models agree: {ctx['models_agree']}")


if __name__ == "__main__":
    main()

# Day 4: The Creative Brief

This is the bootcamp's first big WOW, and it is not an image. It is a plan.

Today Wonka takes everything from the Research Room, your locked product reference, and your brand kit, and writes one creative brief for your ENTIRE product page: the main image, the full secondary set, your A+ modules, and your variation plan. One document, every asset accounted for, every selling point given a home or consciously written off, and, because every input already exists, **zero placeholders**.

This is the recipe. No candy gets made without it.

## What you will have by the end of today

- **A full package brief (`brief/creative-brief.md`)**: main image + secondary set + A+ modules + variation plan, each asset with one job and one dominant message
- The **three main-image controls** (tactic, hang-tag text, packaging preference) decided WITH you, plus **selection criteria** written as ranked test hypotheses, so the Day 5 pick and the Tasting Room have a yardstick. The main is chosen, not briefed: nothing in this document writes main-image content
- A **coverage map**: every selling point mapped to a specific asset, or consciously skipped in writing with a real reason
- A **cast of 1 to 2 custom avatars** translated from your REAL buyer. Casting is a structured field the machine applies to every people-bearing image; it is never prose inside an image brief
- Compliance decided in advance, so nothing gets briefed that would get rejected or resented later

**Time needed:** 60 to 90 minutes, and most of that is reading and arguing. Writing the brief itself takes minutes and costs nothing. This is the most valuable hour of the bootcamp. Spend it awake.

## What you will need at hand

- Your `research/` folder from Day 2: `insights.md`, `reviews.md`, `persona.md`, `selling-points.md`, `competitors.md`
- Day 3's locked reference (with its passed smoke test) and your finished `factory/Brand/brand-kit.md`. Wonka reads them, you just need them done.
- Your real SKU list, if your product sells in colors, sizes, counts or bundles
- Your own opinions. You are the editor of this document, not a spectator.

---

## Lesson 1: The strategy inside the brief

### The four rules

Four rules run through this document. Learn them and you will read every creative brief you ever receive, from Wonka or from a human, with much sharper eyes.

**One asset, one job, one message.** The fastest way to make a weak image is to cram five messages into it. An image that says three things says nothing. Each frame gets one thing to prove, and the set works because every piece does one job well.

**The main image is chosen, not briefed, and it is product only.** No people, no faces, no hands, in any candidate, ever. The hero fights for the click at thumbnail size, and clutter loses the click. People, product in use and lifestyle all sell beautifully, in the secondary images. Your brief decides only three controls (tactic, hang-tag text, packaging preference) and the selection criteria; the machine generates many candidates and YOU pick. There is a full strategy lesson on the main image in the next room.

**Plan the set, not the slots.** No two assets share a message. At least one frame is emotional rather than another spec sheet. The strongest hook leads the gallery. And every selling point is mapped to an asset, or skipped in writing with a reason. That mapping is the coverage map, and it is the difference between a set that covers your market and a set that covers whatever the model found interesting.

**The funnel diagnosis sets the weighting.** From Day 2: if your click share is weak, the problem is the main image and the brief piles the weight onto the main-image selection criteria and the first Tasting Round. If clicks are fine and conversion is not, the problem is the detail page and the brief piles onto the secondaries and the A+. If you have no funnel data because the listing is new, say so and Wonka marks the diagnosis estimated and hedges across both.

**And this is where research stops being homework.** In the demo product, the number one complaint is a promise the images made: the pictures showed a full cascade, buyers filled the machine to the number on the box, and got a trickle. Nobody lied in words. The images over-promised, and the reviews punished it for years.

Ask that question of your own product before you read a single slot: **is there a complaint in my reviews that my current images caused?** If there is, the first job of this brief is to stop repeating it.

### The rules that get baked in before generation

Most people generate a pile of images and then discover half of them have text nobody can read on a phone, or a claim that could get a listing suppressed. Then they spend a weekend fixing. The factory does the opposite: the rules go into the brief, so the problems mostly never happen. Prevention is cheaper than cleanup, every time.

Three families of rules go in, and each one is routed to the channel that actually enforces it. That routing matters: dumping every rule as text into an image request makes the images worse, because your rules end up competing with your creative direction for the model's attention.

- **Legibility.** One dominant message per asset. The headline travels as its own short piece of finished on-image copy, capped at about six words, and everything else gets subtracted. Fewer elements means bigger text. The mechanical checks (minimum text size, the 160 pixel squint test) belong to the Inspection Room, not to the generation request.
- **Compliance.** Only what is genuinely yours: no medical claims, no invented percentages, no star ratings or review references, no flag graphics. Fake badges, third-party logos and floating graphics are blocked by the generation engine anyway. And nothing goes on an image that is not physically true of your product: if the base is steel and the body is plastic, the render says so.
- **Accuracy and casting.** Accuracy comes from your locked reference, not from adjectives. Casting is a structured field: your buyer is defined as 1 to 2 custom avatars with an explicit age and gender, with the aspirational skew applied (from age 50 the displayed model looks about 5 years younger, scaling to about 10 years younger by 70). Per-image variety is automatic: within your cast, the machine varies appearance so a different person appears in every people-bearing image, and nobody asks for variety in prose. Nothing screams AI like the same face five times, and the inspection still checks no face repeats.

### The one input that teaches by being absent

Before writing, Wonka checks the **Improvement Log**, the factory's memory of what YOUR market has actually voted for. Today he will tell you it is empty, because this is your first product, so this brief runs on research and best practice alone. Remember that line. After your first Tasting Round the book starts filling, and the next time this command runs the sentence reads differently: he opens the book, tells you what already won for you, and briefs from it. Today is the only day it is ever empty.

## Lesson 2: /creative-brief, the full package

One command, and three days of inputs become a plan for your whole product page. Watch the file in this order, because that is the order it is written in and each part answers the one before it:

- **`Built from:`** the provenance line. Your five research files, your locked reference sheet, your brand kit, and the Improvement Log marked empty. Nothing in this factory appears out of thin air, and this line is where you pull the thread when a slot surprises you.
- **The strategy summary**, with your funnel diagnosis stated, and marked estimated if you have no data.
- **The coverage map.** Every selling point, and the asset that carries it. Then, at the bottom, the points with nothing in the mapped column and a written reason instead. Those lines are the most valuable part of the document, because one of them is usually a complaint that no image can fix, written down as such instead of quietly becoming a wasted frame.
- **Four sections**: MAIN, the incumbent read, the three owner-answered controls, and 3 to 5 ranked selection criteria (no authored main content anywhere). SECONDARY, one job and one capped message per slot. A+, the hands-off line: Genrupt plans and produces the A+ alone, and the brief records only which selling points are expected to land there, verified at inspection. VARIATIONS, your real SKUs or the absence stated in writing.
- **The avoid list, restated** at the end, carrying your brand kit's items so the generation rooms cannot miss them.

Then the part that matters more than the writing: **it is a draft until you approve it.** In the video a slot gets killed on camera because its headline promised something the reviews are split on. That was a call about buyers rather than about taste, and it is your job in the missions below.

---

## MISSION 1: Write the brief

Everything so far was ingredients:

```
/creative-brief
```

Wonka writes the full package brief and saves it to `brief/creative-brief.md`. He also fills in the "Mapped to" and "Skipped because" columns in `research/selling-points.md` so the two files agree.

Read it slowly, top to bottom, before you react to anything.

## MISSION 2: Audit it against the coverage map

This is the five minute audit that catches almost everything. Ask for the table on its own:

```
Show me the selling-points coverage table: which asset covers each point,
and which points you consciously skipped and why.
```

Then check three things:

1. **Every table stake is mapped somewhere.** A table stake is what every competitor already shows. Missing one does not make you distinctive, it makes you look incomplete.
2. **Every skipped point has a real written reason**: off strategy, cannot be shown honestly, tested loser, slot budget. An empty reason is not allowed. Silence is how selling points die.
3. **The things images cannot fix are written down as such.** If your top complaint is that the product arrives damaged, no image fixes that. The right output is a line in the coverage map saying so, and a note to whoever owns packaging. A brief that quietly pretends that category does not exist is a brief that will waste your credits on an unwinnable frame.

If a point you care about is missing, name it:

```
[Selling point] is a table stake in my niche and it is not in the brief.
Add it and tell me which asset carries it and what that asset gives up.
```

## MISSION 3: Push back on at least one slot

This is your hour, and the brief is a draft until you approve it. Push:

```
Why did you give secondary 3 that job instead of [the thing I care about]?
```

```
Swap the message on secondary 5 for [X] and tell me what we lose.
```

```
Which selling points does the brief EXPECT to land in the A+? The A+ itself
is hands-off, so tell me what the inspection will verify actually landed.
```

He will either defend the choice with data or concede and update the file. Both are useful.

**The highest value pushback is not about taste, it is about promises.** Read every headline and ask: does my product actually deliver this, for most buyers, most of the time? If a headline promises speed, ease or a result your reviews are split on, kill it:

```
Slot [N] promises [X]. My reviews are split on that, so a chunk of buyers
will feel lied to. Same job, honest framing, and no claim the listing does
not already make.
```

He revises that one slot, records the reason in the file, and leaves everything else alone.

One more check in the same family, and it takes ten seconds:

```
Check every headline and label in the brief against the avoid list in my
brand kit. Flag anything that promises something on that list.
```

You wrote that avoid list in the Brand Room while you were calm. This is the moment it earns its place.

When you are happy:

```
The brief is approved. Update status.md.
```

## MISSION 4: Confirm the two structural things

Two quick checks that make the generation days go smoothly:

```
List every slot in the brief that will contain a person, then read me the
cast: the 1 to 2 custom avatars in the handoff, each with an explicit age
and gender. Confirm no slot text describes a person.
```

```
Confirm the variations plan matches my real SKUs. I sell in these
variations: [list them, or say "no variations"].
```

If you have no variations, the brief should say `variations: none (single SKU)` in writing rather than inventing three. Fixing casting and variation logic here is a free edit to a document. Fixing it after generation costs credits.

**Share the WOW:** post a screenshot of your favorite part of the brief to the group, the coverage map or a single slot. Reading dozens of full-package briefs for dozens of different products is a masterclass in listing strategy, and it is free.

---

## What good looks like

Scroll your brief and check for these. A brief that has all of them is ready for the Main Image Room:

- A `Built from:` line at the top naming your actual research files, your locked reference and your brand kit, with the Improvement Log marked empty
- A strategy summary that names what this package has to PROVE, and states the funnel diagnosis (and marks it estimated if you have no data)
- **Main image**: an incumbent read, the three controls answered by YOU (tactic, hang-tag text, packaging preference), and 3 to 5 ranked selection criteria, each naming a mechanism that beats your current live image. No authored main content anywhere, and slot 1 marked round-trip unchanged
- **Secondaries**: roughly five to seven slots, each with one job, one headline of six words or fewer, a composition brief specific enough to generate from, and a source line tracing back to a review or an insight
- **A+**: the hands-off line, plus the selling points expected to land there, marked for verification at inspection. No module list, no A+ headlines, no A+ copy
- **Variations**: your real SKUs planned, or the absence stated in writing
- A coverage map accounting for one hundred percent of your selling points, mapped or skipped with reasons
- The avoid list from your brand kit restated at the end of the brief, so the generation rooms read it every time
- At least one emotional frame, and no two assets carrying the same message
- Not a single "TBD" anywhere

The selection-criteria test is the one people fail. Criteria that all restate "looks better" are one opinion in five outfits. Ask directly:

```
Are these selection criteria each a different MECHANISM for winning the
click, tied to my research? If any two test the same thing, replace one.
```

## When it goes wrong

**Wonka refuses to write the brief.** He is missing an input and he will name it: a research file, the brand kit, or a reference that is not locked yet. That refusal is the integrity rule working. Finish the missing command and re-run.

**The brief feels thin or generic.** The research underneath it was thin. Go back and paste more critical reviews, then:
```
Re-run the /meet-my-product analysis with these reviews, then rewrite the brief.
```

**Two slots are saying the same thing.** A set-level failure, and free to fix here:
```
Slots 3 and 5 carry the same message. Re-cut one of them and tell me which
selling point it should carry instead.
```

**It lists more images than you think you need.** The scarce thing is messages, not pixels:
```
Which secondaries could we cut without dropping a selling point?
```
Let the coverage table answer. Six sharp slots beat eight padded ones.

**A section feels underweighted.** Check the funnel diagnosis before you argue. If it says your problem is the click, a leaner A+ section is correct, not a bug. If the weighting still feels wrong, tell him your real priority and he rebalances.

**You want to use a customer's review as a headline.** Use their words, never their review. A customer's phrasing as your own copy converts. The same sentence with stars, quote marks, or a "verified buyer" tag is a compliance problem.

Everything else: `guides/troubleshooting.md`.

---

## Before the next room (10 minutes)

The next room is where the words become pixels: the Main Image Room generates your first real candidates. To arrive ready:

1. **Re-read the main image section of your brief.** The next room confirms your three controls, the machine generates many candidates, and you will pick with exactly those selection criteria in hand.
2. Confirm the line is clean:
```
Give me a one-line status: brief approved, reference locked, smoke test
passed, brand kit done?
```
Four yeses and the Main Image Room opens without friction.
3. Block 60 to 90 minutes for the next room, somewhere you can actually look at images properly. Not a phone-only session.

## Definition of Done for Day 4

- [ ] `/creative-brief` ran and `brief/creative-brief.md` exists, covering main + secondaries + A+ + variations
- [ ] Zero placeholders: every brand field filled from the brand kit, every product reference from the locked reference
- [ ] The three main-image controls answered by you, the incumbent read written, and 3 to 5 ranked selection criteria. No authored main-image content anywhere
- [ ] Every asset has one job and one dominant message, and no two assets share a message
- [ ] Every selling point mapped to an asset or consciously skipped in writing with a real reason
- [ ] The cast is 1 to 2 custom avatars with explicit age and gender, and no slot text describes a person
- [ ] Compliance decided in the brief, and no headline promising something your reviews do not support
- [ ] Variations planned from your real SKU list, or stated as none in writing
- [ ] You pushed back on at least one slot and approved the result. `status.md` shows BRIEF done
- [ ] You generated nothing today

Next room: the Main Image Room. Your three controls go in, a tray of candidates comes out, and you pick with your selection criteria in hand, then the quality loop, taught once and taught properly, so you own it for the rest of the bootcamp. "No brief, no candy. And now you have a brief."

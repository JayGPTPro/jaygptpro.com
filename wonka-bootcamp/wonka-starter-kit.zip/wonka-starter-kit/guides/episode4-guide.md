# Episode 4: The Reference Room

This episode you prepare the two things every image needs before a brief is even written: a Mold of your REAL product, so the AI produces YOUR product and not a hallucinated cousin of it, and your brand's look, locked into a file. Then you run the single highest-ROI habit in the whole Factory: the smoke test. No batch generation this episode. This episode makes everything downstream trustworthy, and here is the sentence to remember: **the better the mold, the better everything downstream.**

## What you will have by the end of this episode

- A locked Mold: your real product as the generation reference
- **A passed smoke test: one control image you looked at with your own eyes, confirming the Mold holds before any batch runs**
- A filled Brand Kit (`factory/Brand/brand-kit.md`): colors, typography direction, tone, approved claims

**Time needed:** 45 to 75 minutes, including a little generation wait for the smoke test.

## What you will need at hand

- Product photos already sitting in the `reference/` folder (all angles, hand-for-scale, label close-ups)
- Your logo file (PNG, transparent background if you have one)
- Brand colors (hex codes if you know them; your label photos work as a fallback)
- Your list of REAL certifications and press mentions, with proof for each

---

## Lesson 1: The Mold (the difference between your product and a hallucination)

Image models are enthusiastic liars about products. Ask for "a kids karaoke machine" and you get A machine: wrong colors, one microphone instead of two, buttons that never existed, a front panel that says "Karoake". Charming, useless, and dangerous if it ships.

The Mold fixes this. Your real photos (all angles, hand-for-scale, label close-ups) are locked in Genrupt as the **product reference**, and every generation is forced to match it. This is why Episode 1 sent you to take photos: the model needs to know the back of your label and the true size in a human hand, not guess them.

And this is why the Mold comes BEFORE the brief. Every image the Factory will ever make for this product, main, secondaries, A+, variations, is poured from this one Mold. A precise Mold means a precise everything. A sloppy Mold means every downstream episode inherits the slop. The better the mold, the better everything downstream.

## Lesson 2: The smoke test (the non-skippable 5 minutes)

Here is the scenario the smoke test prevents. You lock the Mold, you feel good, you fire off a batch of images, you wait, and they all come back with a subtly wrong product: the wrong colors, or one microphone where your product has two. The lock LOOKED applied. It was not. The batch is garbage, and the credits are spent.

So: after locking the Mold, Wonka generates **ONE cheap control image** of the product alone, and you LOOK at it with your own eyes. Right size? Right shape? Right label? Right material (glass reads as glass)? Only after your "yes" does any batch ever run. Five minutes, a few cents, and it protects every credit you will spend in the generation episodes. Wonka will refuse to batch without it, and he is right to.

## Lesson 3: The Wrapper (why brand consistency is a file, not a vibe)

An image can pass every quality test and still be wrong, because it does not look like YOUR brand. Fonts drift, colors drift, tone drifts, and three products later your storefront looks like three different companies.

The fix is boring and powerful: the brand is a file. `factory/Brand/brand-kit.md` holds your colors as hex codes, your typography direction, your tone words, your logo rules, and, most importantly, your **approved claims list**: the only certifications, press mentions, and awards allowed to appear on any image, each with its proof. Wonka reads this file before every single generation. If a claim is not in the file, it does not go on an image. Ever.

The brand kit lives at the Brand level, not the product level, so it wraps every product you ever run through the Factory. Fill it once, benefit forever.

## Lesson 4: Why generation waits for a later episode

You might feel ready to generate. Resist it. Two reasons:

1. **The recipe does not exist yet.** Generation without a brief is a vending machine, and you did not sign up for a vending machine. The next episode writes the full-package brief, and it will be a better brief BECAUSE the Mold and the brand kit already exist: zero placeholders, zero "to be decided later".
2. **The smoke test is a go/no-go gate**, and its whole value is that you look at the control image with fresh, unhurried eyes and either approve it or send the Mold back. Splitting preparation (this episode) from production (the generation episodes) is deliberate: it stops "I already spent the credits, might as well keep going" thinking. Lock, smoke-test, approve, then invent when the recipe is ready.

---

## MISSION 1: The Reference Room

```
/reference-sheet
```

Wonka takes the photos from your `reference/` folder and builds the product reference in Genrupt, then locks it. If your photos are incomplete, he will stop and name exactly what is missing (usually the hand-for-scale shot or the back label). Take the missing shot now; it is faster than arguing with him, and he will not budge anyway.

**No photos at all?** He can fall back to your Amazon listing's existing images, but only if you explicitly say so, and he will record the Mold as built from scraped images. Accuracy will be lower. Real photos are twenty minutes of your life; take them.

## MISSION 2: The smoke test (the go/no-go moment)

Wonka now generates ONE product-only control image and shows it to you:

```
Run the smoke test.
```

Look at it like an inspector, not a fan. Check against your real product:

- [ ] Size and proportions right? (compare with the hand-for-scale photo)
- [ ] Shape, buttons, and included pieces right? (nothing missing, nothing invented)
- [ ] Label text readable and correct, brand name spelled right?
- [ ] Colors and material true? True colors, glossy looks glossy, matte looks matte

If something is wrong, say exactly what: `The machine shows one microphone, mine comes with two. Fix the mold and re-run the smoke test.` Repeat until it passes. Only then:

```
Smoke test approved. Record it in status.md. Do NOT batch anything; the recipe comes first.
```

Wonka records the approved smoke test in `status.md` so the Inventing Room later knows the Mold is trusted.

## MISSION 3: The Brand Room

```
/brand-kit
```

Wonka interviews you and fills `factory/Brand/brand-kit.md`. Have your brand assets at hand: logo file, colors, real certifications with proof. Two parts deserve extra care:

- **Colors:** if you have exact hex codes, give them. If not, point him at your label or website: `Extract my brand colors from [URL or "the label photos in my reference folder"]`.
- **Approved claims:** this is the legal firewall. Only real, provable things enter this table. When in doubt, leave it out; an image can always be strengthened later, a false claim on a live listing cannot be un-shipped.

Verify: `Show me the finished brand-kit.md` and read the approved claims table one more time.

## MISSION 4: Confirm the foundations

One line, so the next episode opens clean:

```
Give me a one-line status: mold locked, smoke test approved, brand kit done?
```

Three yeses means the Brief Room has everything it needs. This is exactly the setup that makes the next episode's brief special: research AND mold AND brand kit all exist, so the recipe can be written with zero placeholders.

**Share the WOW:** post your smoke test image next to a photo of your real product in your support channel (the group, or reply to any bootcamp email). Watching everyone's real products click into place, correct size, correct label, correct glass, is this episode's shared moment.

---

## Common Episode 4 questions

**"I don't have Genrupt. Can I still build a Mold?"**
There is no true locked reference without Genrupt, so generation later falls back to OpenAI's image model using your reference photos as loose references. Tell Wonka plainly: `I don't have Genrupt, use the fallback path.` He will note it, and product accuracy will lean harder on the Inspection Room later. Everything remains doable.

**"My smoke test looks great. Can I just generate now?"**
You can ask, but the recipe does not exist yet, and generation without a brief is exactly the vending-machine habit this bootcamp replaces. The recommended path is to stop at a passed smoke test and let the Brief Room decide WHAT gets generated before any credits move.

**"The smoke test keeps coming back wrong."**
That is the smoke test doing its job. A Mold that will not hold is a Mold worth fixing before you spend batch credits. Tell Wonka exactly what is wrong (`the cap is the wrong shape`, `the label is unreadable`) and let him re-lock. If it will not converge after a few tries, share it in your support channel; a second pair of eyes usually spots the missing photo angle.

## Before the next episode (10 minutes)

1. Confirm the one-line status above came back all yes.
2. **Re-read your selling-points checklist and whitespace section** from Episode 3. The next episode turns all of it into one brief for your entire product page, and you will be its editor. Come with opinions.
3. If your product sells in variations (colors, sizes, bundles), jot down your real SKU list. The recipe plans for them.

## Definition of Done for Episode 4

- [ ] `/reference-sheet` ran: Mold locked from YOUR real photos (or an explicit, recorded fallback)
- [ ] Smoke test generated, checked with your own eyes, and approved BEFORE any batch
- [ ] `/brand-kit` ran: `brand-kit.md` filled, approved claims table reviewed by you
- [ ] `status.md` records the passed smoke test and the brand kit
- [ ] You did NOT batch-generate anything this episode

## Troubleshooting note

If the smoke-test product looks like the WRONG product (wrong size, wrong label, wrong material), the Mold is not actually locked: do not proceed, and tell Wonka `The mold isn't holding. Re-lock it and give me a fresh smoke test.` If the Genrupt MCP is not responding, restart Claude completely and check `guides/mcp-setup-guide.md`. If Wonka cannot find your photos, they are probably in the wrong folder; ask `Which exact folder do the reference photos go in?` Everything else: `guides/troubleshooting.md`.

Next episode: the Brief Room, and the bootcamp's first big WOW. From the research, the locked Mold, and the brand kit, Wonka writes one brief for your entire product page: main image, secondaries, A+, and variations. "Every great candy starts with a recipe."

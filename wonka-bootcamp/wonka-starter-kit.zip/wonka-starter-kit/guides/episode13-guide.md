# Episode 13: The Improvement Loop

Graduation. Your product is through the line, tested twice, packaged, and heading live. This final episode does the closing that most courses skip and this Factory never does: `/improvement-loop`, one command that writes BOTH books, what your MARKET taught you into the Recipe Book, and what this RUN taught Wonka into his Notebook. Then you set the weekly heartbeat, see how much of this work carries over to your next product, walk the graduation checklist, and graduate. This is where the promise comes true: the next product takes half the time.

## What you will have by the end of this episode

- A Recipe Book entry (what converts in your market) and a Wonka's Notebook entry (how Wonka works better)
- A weekly `/factory-report` habit set
- A clear view of how much carries over to your next products
- **A graduated Factory, and an operating rhythm for running it after the bootcamp**

**Time needed:** 45 to 75 minutes.

## What you will need at hand

- Your completed run: the two survey rounds analyzed, the Golden Ticket packaged (Episode 11), the variation family done (Episode 12)
- `guides/graduation-checklist.md` open for the final mission
- Your shortlist of next products

---

## Lesson 1: The Factory learns twice (the two closing loops)

Before you graduate, the Factory records two different kinds of lesson, and the distinction is the whole design. One command, `/improvement-loop`, updates BOTH books:

- **The Recipe Book: what converts in your MARKET.** The pattern that won (or lost), the evidence strength, the niche, the voters' why. Every future `/creative-brief` reads this book before writing a brief, so your market knowledge compounds across products.
- **Wonka's Notebook: how WONKA does his own job better.** Where the process snagged this run, which defects he could have prevented upstream, what he learned about working with you. He reads this Notebook at the start of every session, so HE starts each one sharper.

Two books, one command, one compounding factory. Your third product will be better than your first for both reasons at once.

## Lesson 2: The heartbeat (what keeps a factory alive)

Courses end; factories run. The difference is a heartbeat: one weekly report that tells you where every product stands, what is blocked, and the one next action. That is `/factory-report`, and this episode you set it as a habit, scheduled if your Claude setup supports scheduled tasks on this folder, calendar-reminded if not. Two minutes a week is what "the factory keeps running" costs.

(One honest note: this is a reminder-driven habit, not an unattended cloud service that runs while your machine is off.)

## Lesson 3: The factory, multiplied (why product two is faster)

The last big idea of the bootcamp is arithmetic. Product one carried all the fixed costs: you learned the method, built the brand kit, calibrated Wonka. Product two skips most of that. The brand kit already exists. The Recipe Book already knows what your market rewards. Wonka's Notebook already knows how you work and where he snagged last time. The line gets faster and better with every run, which is precisely what "the factory learns twice" was for.

That is the promise made concrete: the next product takes about half the time, because half the work is already done and the other half is done smarter. Run the next product at a sustainable pace, one product every week or two through the full line. Never skip stations to go faster; the line IS the speed, rework is what is slow.

---

## MISSION 1: Run the Improvement Loop (both books, one command)

```
/improvement-loop
```

Wonka closes both loops in one pass. First the market lesson: he writes the results of BOTH survey rounds into `factory/Recipe Book/`, the patterns that won and lost, the evidence strength, the niche, the voters' why. From now on, every future `/creative-brief` reads this book first. Then the process lesson: he reviews this RUN, where the line snagged, which fixes he could have prevented upstream, what he learned about how you like to work, and writes it to `factory/Wonka's Notebook/notebook.md`, which he reads at the start of every session.

This 10-minute step is the compounding engine of the whole system. Never skip it, especially on losses; losses teach faster.

## MISSION 2: Read the Notebook back

Then ask him:

```
Read back your Notebook entry for this run. What will you do differently on product two?
```

His answer is your Creative Director's first performance self-review. Keep it.

## MISSION 3: Set the Factory's heartbeat

```
Help me set the weekly factory-report habit. Can a scheduled task run on this folder in my setup, or should I use a weekly calendar reminder?
```

If scheduled tasks are available in your Claude setup and can run on this folder, schedule `/factory-report` weekly. If not, put a 2-minute weekly reminder in your calendar and run the single command yourself. Either way the report lands in `factory/Factory Log/`.

Then run one manually so you see what the weekly ritual looks like:

```
/factory-report
```

Your first report will be short: one product, one great bootcamp. That is what page one of a factory's history looks like.

## MISSION 4: Point the machine at what is next

```
Here are the next products I'm considering for the line: [your 1 to 3 products]. For each, tell me what the Front Gate will need, what carries over (brand kit, Recipe Book patterns, your Notebook), and what must be built fresh (photos, niche export, mold).
```

Notice how much carries over. Then, if you are ready, open the gate for product two right now:

```
/meet-my-product
```

Twenty minutes of intake, and the Factory is running its second product while the first one's A/B matures. This exact moment, product two entering the line the same hour product one ships, is what you bought with the bootcamp.

## MISSION 5: Graduate

Run through `guides/graduation-checklist.md`, top to bottom. Everything should check. Then the closing move:

```
Wonka, the first product is through the line. Give me your honest review of this bootcamp run, and what the factory should do differently on product two.
```

Read his answer. Then post your graduation in the bootcamp group: the before/after, the survey numbers from both rounds, one voter comment that changed your mind, and one sentence on what surprised you.

---

## After the bootcamp

The operating rhythm that keeps the Factory compounding lives at the bottom of `guides/graduation-checklist.md`: the weekly report, the per-product cadence, the monthly Recipe Book review, and the always-rule (`/improvement-loop` the same day any test result lands). Follow it and every product that leaves this Factory is better than the one before it.

## Definition of Done for Episode 13

- [ ] `/improvement-loop` ran: the Recipe Book has its first real entries (both rounds) AND Wonka's Notebook has its first process entry, and you read it
- [ ] Weekly `/factory-report` habit set; one report run manually into `factory/Factory Log/`
- [ ] Next products assessed; the Front Gate opened for product two (or scheduled)
- [ ] Graduation checklist walked and fully closed; `status.md` shows PROVE done
- [ ] Graduation posted in the bootcamp group

## Troubleshooting note

If `/improvement-loop` reports it has nothing to write, the survey analysis or the run status was never saved; point Wonka at the `tests/` folder and `status.md` and have him read the run first. If a scheduled task will not attach to this folder, that is fine, use the calendar-reminder path; the report is the same either way. If the graduation checklist flags a missing artifact, that is the integrity system working; go complete the named gap rather than checking the box by hand. Everything else: `guides/troubleshooting.md`.

That is the bootcamp. You arrived with a folder and a zip file. You leave with a Creative Director who researched your market, locked your real product, briefed and built a full package, gated its quality, tested it twice on real shoppers, refined it from their own words, packaged it for upload, multiplied it across your catalog, and who starts every future session a little smarter than the last. Run the line again. And again.

"Same factory, next candy. Onward."

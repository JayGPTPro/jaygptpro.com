# Day 3: The Reference Room

Today you prepare the two things every image needs before a brief is even written: a Mold of your REAL product, so the machines produce YOUR product instead of a hallucinated cousin of it, and your brand's look, locked into a file. In between the two you run the highest return habit in the whole factory: the smoke test, one control image you check with your own eyes before the Mold is trusted with anything. No batch generation today. Today is what makes everything downstream trustworthy, and here is the sentence to carry: **the better the mold, the better every image after it.**

## What you will have by the end of the day

- A locked Mold: your real product as the reference every generation must match, with its source recorded
- **A passed smoke test: one control image you looked at with your own eyes, confirming the Mold holds before any batch runs**
- A filled Brand Kit (`factory/Brand/brand-kit.md`): colors as hex codes, font direction, tone, approved claims, avoid list

**Time needed:** 45 to 75 minutes, including a short wait for the smoke test to generate.

## What you will need at hand

- Your product photos, already in your product's `2-reference/photos/` folder: all angles (front, back, both sides, top), one hand-for-scale shot, and label or texture close ups
- Your logo file (PNG, transparent background if you have one)
- Your brand colors, hex codes if you know them. Your label or your website works as a fallback
- Your list of REAL certifications, awards and press mentions, with proof for each. If you cannot prove it, leave it out

**Missing photos?** Take them before you start. Phone camera, plain background, daylight, twenty minutes. It is the cheapest twenty minutes in this bootcamp and everything today depends on it.

---

## The idea behind today

### Part one: the Mold, and why AI cannot be trusted with your product

Image models are enthusiastic liars about products. Ask for "a chocolate fountain" and you get A fountain: the wrong number of tiers, a chrome tower where the real machine is steel and plastic, and a size that belongs at a hotel wedding rather than on a kitchen counter. Charming, useless, and genuinely dangerous if it ships, because an image that oversells is a returns problem and a compliance problem at the same time.

The Mold fixes this. Your real photos are locked as the **product reference**, and every generation from here is forced to match it. On disk it has a boring name, `2-reference/reference-sheet.md`, and it is the most valuable boring file you will make.

Two things it needs that people skip:

- **The back.** If you do not show it, the model invents it.
- **The hand-for-scale shot.** Scale is the single thing AI gets most wrong about products. A dimension in inches does not fix it. A hand in the frame does.

And this is why the Mold comes BEFORE the brief. Every image the factory ever makes for this product, main, secondaries, A+, variations, gets poured from this one Mold. A precise Mold means a precise everything. A sloppy Mold means every room downstream inherits the slop.

### Part two: the smoke test, the five minutes you never skip

Here is the scenario the smoke test prevents. You lock the Mold, you feel good, you fire off a batch, you wait, and every image comes back with a subtly wrong product. The lock LOOKED applied. It was not. The batch is garbage and the credits are gone.

So after locking, Wonka generates **ONE product-only control image**, plain background, no text, no props, and you LOOK at it. Right parts, right count? Right materials? Right size? Nothing invented? Only after your yes does any batch ever run.

Note what "approved" means and does not mean. Approved is a status the tool writes. Your eyes on a control image are the evidence. Those are not the same thing, and the smoke test exists precisely because approved references still produce the wrong product.

### Part three: the wrapper, why brand consistency is a file and not a vibe

An image can pass every quality test and still be wrong, because it does not look like YOUR brand. Fonts drift, colors drift, tone drifts, and three products later your storefront looks like three different companies.

The fix is boring and powerful: the brand becomes a file. `factory/Brand/brand-kit.md` holds your colors as hex codes, your font direction, your tone words, your logo rules, and the part most sellers skip, your **approved claims list**: the only certifications, awards and press mentions allowed to appear on any image, each with its proof. Wonka reads this file before every single generation. If a claim is not in the file, it does not go on an image.

The kit lives at the Brand level, not inside the product folder, so it wraps every product you ever run through the factory. Fill it once, benefit forever.

### Part four: why generation still waits

You might feel ready to generate today. Resist it, for two reasons.

1. **The brief does not exist yet.** Generating without a brief is a vending machine, and you did not sign up for a vending machine. Day 4 writes the full package brief, and it is a better brief BECAUSE the Mold and the brand kit already exist. Zero placeholders, nothing "to be decided later".
2. **The smoke test is a go or no go gate**, and its whole value is that you look at the control image with fresh, unhurried eyes and either approve it or send the Mold back. Splitting preparation from production is deliberate. It stops the "I already spent the credits, might as well keep going" thinking that ruins batches.

---

## MISSION 1: Lock the product

```
/reference-sheet
```

Wonka inventories the photos in your `2-reference/photos/` folder against the required set, then builds the product reference. It is not LOCKED yet, and he will not write that word until the smoke test passes in Mission 2. If your photos are incomplete he stops and names exactly what is missing, usually the hand-for-scale shot or the back. Take the missing shot now. It is faster than arguing with him, and he will not budge anyway.

He also writes the **product spec** from your photos and from you: exact size and dimensions, material and finish, every included part, the label text as printed, and the true colors. That spec is what the smoke test gets judged against, so correct him where he is wrong. If your base is stainless steel and the parts on top are plastic, say so. Material accuracy is a real quality gate later, and it starts here.

**No photos and no way to take them?** This is the no-photos path. He can fall back to your listing images, but only if you approve it explicitly, in words. A generic "continue" is not approval. The sentence looks like this:

```
Yes, build the reference sheet from my listing images only, with no photos
of my own. I accept the weaker size and back-of-product accuracy. Record
the source honestly in the file.
```

He records `source: amazon_scraped` in the file, and your smoke test now matters double.

**On that path, mine your customer review images too.** A brand gallery is lit to sell, and it skips the angles a reference needs most. A review photo is the product on somebody's real counter, at its real size, from angles no brand ever shoots. Save them into `2-reference/photos/` alongside the gallery images. You will watch me build the demo reference from exactly those two sources on camera, because that machine is not in my house. It is the fallback, not the standard. Yours is in your house.

**Never a competitor's photo.** A competitor's image locks THEIR machine, their angle, their lighting. Competitors are for the teardown, as a benchmark to match and beat. They never go in the Mold.

Verify before moving on:

```
Show me the reference-sheet.md you just wrote: the photo inventory, the source line, and the product spec.
```

## MISSION 2: The smoke test (the go or no go moment)

```
Run the smoke test.
```

Wonka quotes the cost first, generates ONE product-only control image, and hands you the verdict. Open it large, next to a real photo of your product, and check it like an inspector rather than a fan:

- [ ] **Parts and count.** Every part present, nothing invented, and anything countable counted (four tiers is four tiers, two lids is two lids)
- [ ] **Materials.** Steel reads as steel, plastic as plastic, glass as translucent glass with reflections. Wrong material makes premium look cheap
- [ ] **Scale.** Compare against your hand-for-scale photo. Does it read as the size it really is?
- [ ] **Label and text.** Readable, correct, brand name spelled right, and no text that is not physically on the product
- [ ] **Nothing invented.** No badges, seals, ribbons or award graphics the model decided would look nice

If something is wrong, say exactly what, in nouns. Here is the demo machine's version, so you can see the shape of it:

```
The control image shows three tiers and the tower reads as chrome. Mine
has four tiers, and the tiers are plastic on a stainless steel base. Fix
the reference and run one fresh control image.
```

Swap in your own product's nouns. "It looks wrong" buys you a re-roll. Naming the part, the count and the material buys you a fix. Repeat until it passes. Then, and only then:

```
Smoke test passed. Record the PASS and lock the reference. Do NOT batch
anything, the brief comes first.
```

Wonka writes the PASS, the control image filename and the date into `reference-sheet.md`, stamps the line `Reference status: LOCKED`, and logs it in `status.md` so the generation rooms know the Mold is trusted.

**One thing not to test today.** The control image is the product alone: no props, no scene, no story. You are testing the machine, not the promise. What the product does for a buyer is the brief's job, and the brief is next.

## MISSION 3: The Brand Room

```
/brand-kit
```

Wonka interviews you and fills the shipped template at `factory/Brand/brand-kit.md`. Have your assets at hand: logo file, colors, real certifications with proof. Three parts deserve extra care.

**Colors.** If you have exact hex codes, give them. If not, point him at a source and let him propose:

```
Extract my brand colors from [URL], or from the label photos in my 2-reference folder. Propose hex codes and mark each one as a proposal until I approve it.
```

Every value should carry a source note: sampled from the site, sampled from the label, owner approved proposal, or taken from a brand book. In three months you will want to know which is which.

**Fonts.** You are locking a style direction, not a font file. Image models cannot load your licensed font, but they follow a look reliably: editorial serif, clean sans, or bold display. Pick the one that is actually you.

**Approved claims.** This is the legal firewall, and it is the most valuable table in the file. Only real, provable things go in, each with its proof and a note on how it may appear. When in doubt, leave it out. An image can always be strengthened later. A false claim on a live listing cannot be un-shipped.

Then read the avoid list carefully, because it holds the idea that saves people the most trouble: **true and allowed are two different tests.** Your Best Seller rank may be completely true and it still does not belong on an image, along with star ratings and any reference to reviews. Sell the reason you became a best seller instead. That one is yours to keep.

Verify:

```
Show me the finished brand-kit.md.
```

Read the approved claims table one more time before you say yes. Then say it in plain words, because he waits for it.

## MISSION 4: Confirm the foundations

One line, so the next room opens clean:

```
Give me a one-line status: reference locked, smoke test passed, brand kit done?
```

Three yeses means the Brief Room has everything it needs. This is exactly the setup that makes Day 4's brief special: research AND Mold AND brand kit all exist, so the brief can be written with zero placeholders.

**Share the win:** post your smoke test image next to a photo of your real product in your support channel (the group, or a reply to any bootcamp email). Watching everyone's real product click into place, correct size, correct material, correct label, is this day's shared moment.

---

## What good looks like

- Your `reference-sheet.md` says `source: manual_photos`. If it says `amazon_scraped`, that was a decision you made in words, not one that happened to you
- The product spec names your real materials, not "metal-ish"
- The control image is boring. Product alone, plain background, correct in every detail you would notice on the shelf
- Your brand kit has hex codes, not "our green", and every approved claim has a proof next to it
- `status.md` shows the reference locked and the smoke test PASS
- Nothing else was generated today

## When it goes wrong

| What you see | What it means | What to do |
|---|---|---|
| Control image shows the wrong parts or the wrong count | The Mold is not holding | Name the specific defect, re-lock, run ONE fresh control image |
| Product looks the right shape but the wrong size | Missing or weak hand-for-scale shot | Add the scale shot to `2-reference/photos/`, re-lock, re-test |
| Material reads wrong (plastic looks like metal, and so on) | The spec is too vague | Correct the spec in words, re-lock, re-test |
| Text or badges appear that are not on the real product | The model is filling gaps | Say "remove all text and badges, this product has none", re-test |
| Genrupt errors mid smoke test | Machine problem, not a Mold problem | Restart Claude, retry, and ask Wonka to re-run his machines check. If Genrupt is down, do `/brand-kit` now and smoke test later |
| Wonka refuses to move to a batch | Working as designed | He is right. The brief comes first |

## Common Day 3 questions

**"I don't have Genrupt. Can I still build a Mold?"**
There is no true locked reference without it, so generation later falls back to using your reference photos as loose references with your OpenAI key. Tell Wonka plainly: `I don't have Genrupt, use the no-Genrupt fallback.` He records it, product accuracy leans harder on the written spec and on the Inspection Room later, and he will say so honestly rather than pretend the lock is as strong. (Different problem from the no-photos path above, and a different fallback. You can be on one, both, or neither.)

**"My smoke test looks great. Can I generate now?"**
You can ask, but the brief does not exist yet, and generating without one is exactly the habit this bootcamp replaces. Stop at a passed smoke test and let the Brief Room decide WHAT gets generated before any credits move.

**"The smoke test keeps coming back wrong."**
That is the smoke test doing its job. A Mold that will not hold is a Mold worth fixing before you spend batch credits. Be specific about the defect, let him re-lock, and if it will not converge after a few attempts, post it in your support channel. A second pair of eyes usually spots the missing angle.

**"Can I use my competitor's photos? Theirs are better than mine."**
No. Their photo locks their machine. Yours is the only product this factory is allowed to reproduce. Their images belong in the teardown, as the benchmark you brief against and beat.

**"I have no brand book, no logo, nothing."**
Then your v1 kit takes ten minutes instead of five. Point Wonka at your listing and your packaging, let him propose hex codes, approve them, and move on. A kit with honestly labeled proposals beats no kit by a mile, and you can upgrade it any time.

**"Can I skip the brand kit and come back to it?"**
Before is much better than after. Without it, every asset drifts toward generic AI beige. It is also where your claims get decided, and you want that decided while you are calm, not while you are choosing between four finished images.

## Before Day 4 (10 minutes)

1. Confirm the one-line status came back all yes.
2. **Re-read your selling-points checklist and your whitespace section** from Day 2. The next room turns all of it into one brief for your entire product page, and you are its editor. Come with opinions.
3. If your product sells in variations (colors, sizes, bundles), jot down your real SKU list. The brief plans for them.

## Definition of Done for Day 3

- [ ] `/reference-sheet` ran: the Mold is built from YOUR real photos, or from an explicit, recorded fallback
- [ ] The product spec is accurate: size, materials, parts, label text
- [ ] Smoke test generated, checked with your own eyes, and PASSED before any batch
- [ ] `reference-sheet.md` carries the line `Reference status: LOCKED`
- [ ] `/brand-kit` ran: `brand-kit.md` filled, and you read the approved claims table yourself
- [ ] `status.md` records the passed smoke test and the brand kit
- [ ] You did NOT batch generate anything today

## Troubleshooting note

If the smoke test product looks like the WRONG product (wrong size, wrong material, wrong label), the Mold is not actually locked. Do not proceed. Tell Wonka `The mold isn't holding. Re-lock it and give me a fresh control image.` If the Genrupt MCP is not responding, restart Claude completely and check `guides/mcp-setup-guide.md`. If Wonka cannot find your photos they are probably in the wrong place; ask `Which exact folder do the reference photos go in?` Everything else: `guides/troubleshooting.md`.

Next: the Brief Room, and the bootcamp's first big WOW. From your research, your locked Mold and your brand kit, Wonka writes one brief for your entire product page: main image, secondaries, A+, and variations, with zero placeholders. This is the recipe, and no candy gets made without it.

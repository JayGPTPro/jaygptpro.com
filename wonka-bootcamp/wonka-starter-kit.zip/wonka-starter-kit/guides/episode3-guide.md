# Episode 3: Wonka, Meet My Product

This episode you feed Wonka everything about your product, and he earns his salary before touching a single pixel. He digests your listing, your reviews, and your competitors, DERIVES the niche picture himself, builds the real buyer persona, runs a funnel diagnosis so you know whether your problem is getting the click or getting the sale, and tears down your competitors to find the whitespace nobody owns. No images this episode. This is the foundation everything else stands on.

## What you will have by the end of this episode

- A research digest: what your niche demands, what buyers love and hate, who actually buys
- A selling-points checklist where every table stake is named
- A funnel diagnosis: is your problem the main image (getting clicked) or the detail page (getting bought)
- A competitor teardown: what everyone shows, which frames are strong, and the whitespace nobody shows

**Time needed:** 60 to 90 minutes. Most of it is reading what Wonka produces, which is the fun part.

## What you will need at hand

- Your Episode 2 homework in the inputs folder on your Desktop: your reviews file, your competitor gallery screenshots (with the listing URLs), your product photos, and (optionally) your Brand Analytics demographics
- Your owner intel jotted down (known winners, must-include, avoid); Wonka interviews you for it at the Gate today
- Your product's ASIN, Amazon URL, brand name, and your exact niche phrase, decided in Episode 2

---

## Lesson 1: Why research beats taste

Here is the uncomfortable truth about listing images: the prettiest image is usually not the winning image. The winning image is the one that answers, at thumbnail size, the exact question the buyer brought to the search page.

You cannot know that question by taste. You know it from two sources, and Wonka cross-references them:

1. **Competitors** tell you the visual landscape: what every gallery in the niche already shows (you must match it) and what nobody shows (your chance to own something).
2. **Reviews** tell you the emotional truth: what buyers celebrate, what they return, what they wish someone had shown them before buying. A critical review is a buyer writing your image brief for free.

From those two, Wonka DERIVES the niche picture himself: no report to export, no third-party tool. A **table stake** is a feature most competitors show AND reviews demand; that double confirmation is what makes it non-negotiable (in kids karaoke machines, showing TWO microphones is a table stake; in phone cases, drop protection is). Customer language and search words are mined from the reviews and your listing; the pricing landscape comes from the competitor listings.

The rule that runs through this whole Factory: **every selling point gets mapped to an asset, or gets skipped in writing, with a reason.** Nothing important disappears silently.

## Lesson 2: The real buyer, not the imagined one

Most listings are art-directed for an imagined customer, often 25 years younger than the person actually clicking Buy. Wonka builds the persona from the data in front of him: the voice in your reviews, plus the language of your listing and your competitors'. If you have Brand Registry and exported ASIN-level demographics (Episode 2 optional homework), even better: those are your ACTUAL buyers, and they usually skew older than anyone imagines. If you do not, Wonka gives an honest demographic estimate, labeled `estimated` in the digest, and upgrades it the moment real data arrives.

This persona decides real things later: who appears in lifestyle images, what fears the images answer, what language goes in headlines, and how the Tasting Room's panel of tasters is screened. Get it wrong here and every downstream episode inherits the mistake.

## Lesson 3: Table stakes vs whitespace

Two words you will use for the rest of your selling career:

- **Table stakes**: what most competitors show AND reviews demand (the double confirmation from Lesson 1). Missing one = silent disqualification. You do not get points for these, you get eliminated without them.
- **Whitespace**: what nobody in the niche shows, but reviews say buyers care about. This is where a new image set wins.

The competitor teardown exists to sort every visual idea into one of those two buckets.

## Lesson 4: The funnel diagnosis (where to spend your effort)

Because you are building the FULL package this bootcamp (main image, secondaries, A+, variations), it helps to know where your listing actually leaks. There are two very different problems, and they need different fixes:

- **Low click-share** = shoppers see you in search and scroll past. That is a MAIN-IMAGE problem (the CTR lever). Fix the hero shot.
- **Good click-share but low purchase-share** = shoppers click, then leave without buying. That is a DETAIL-PAGE problem (the CVR lever). Fix the secondaries and A+.

If you have Brand Registry, your Search Query Performance export tells you which one you have. If you do not, Wonka reasons from what you know and your reviews. Either way, the diagnosis steers the Episode 5 recipe toward the assets that will move the needle.

---

## MISSION 1: Walk through the Front Gate and feed the Research Room

This whole episode runs on ONE command:

```
/meet-my-product
```

It does everything, in order. First, the **Front Gate**: Wonka registers your product (ASIN, full Amazon URL, brand, and your exact niche phrase; confirm the phrase carefully, it defines which competitors count as the same niche), creates the product's factory folder with its station tracker, and interviews you for your **owner intel**: what you already know works, what must appear, what to avoid. Answer in plain language; he records it verbatim and it travels with the product through every room.

Then the **shopping list**: the same one he previewed for you in Episode 2. You did the homework, so this is a delivery, not a scramble: hand him the reviews file and the competitor screenshots (with the listing URLs), and move your product photos into the product's `reference/` folder. If anything is missing, he names it exactly and waits. That is by design: the Research Room does not run on guesses. Fix the gap, then tell him:

```
Everything is in.
```

Now the digestion runs. Wonka reads your listing, the reviews, the competitor galleries, and your owner intel, and DERIVES the niche picture: table stakes (double-confirmed by competitors and reviews), top features buyers care about, pain points from critical reviews, search language, demographics (real if you supplied the export, honestly labeled `estimated` if not), the buyer persona, and the funnel diagnosis. One check happens before any of it: he confirms your 3 to 5 competitors are genuinely the same niche, because a neighboring-niche competitor poisons the table stakes. Everything is saved to your product's `research/` folder.

One habit to start today, because it will serve you the whole bootcamp: verify the artifact exists.

```
Show me the status.md you just created, and list the folders inside my product's folder.
```

You should see the station tracker with all 5 stations, and 8 subfolders: research, brief, reference, images, aplus, variations, scorecards, tests.

**Your job while reading it:** react. You know things the data does not. Tell him:

```
Correction: [what he got wrong or what the data misses, e.g. "our buyers are mostly repeat customers, the persona should reflect that"]
```

He updates the digest. This is a conversation, not a report you file away.

## MISSION 2: Sanity-check the selling points

The digest ends with the **selling-points checklist**: every table stake, top feature, differentiator, and material/quality signal, each one destined for an asset. Interrogate it:

```
Show me the selling-points checklist. For each point, tell me where it came from (competitors, reviews, or my owner intel).
```

Then check three things yourself:

1. **Is anything missing that YOU know matters?** You gave Wonka your owner intel at the Gate this episode; make sure it survived into the checklist.
2. **Is anything on the list that is not true of your product?** Kill it now, loudly. A false selling point becomes a false image becomes a return.
3. **Is any point vague?** "High quality" is not a selling point. "Two wireless microphones, so siblings don't fight over one" is.

## MISSION 3: Read the funnel diagnosis

Find the diagnosis in the digest and make sure you agree with it:

```
Give me the funnel diagnosis in one line: is my problem the main image (click-share) or the detail page (purchase-share), and what's the evidence?
```

If you have your own sense of where the listing leaks (from your own sales data), tell him. This one line quietly steers how much weight the Episode 5 recipe puts on the main image versus the secondaries and A+.

## MISSION 4: The Spy Balcony

The competitor teardown is part of the same `/meet-my-product` analysis; Wonka moves to it once the digest is confirmed. He will ask you for 3 to 5 competitor ASINs or URLs. Pick the ones actually beating you on your main keyword, not the ones you find flattering to compare against, and confirm with him that every one is genuinely YOUR niche; a neighboring-niche competitor poisons the table stakes. One expectation to set: if Wonka cannot browse the competitor listings from your machine, he will ask you to screenshot their image galleries into `research/`; the Episode 2 homework already had you do exactly that. He tears down their galleries: what every one of them shows (table stakes confirmed), which of their frames are strong (worth matching, then beating), and what nobody shows (your whitespace). Saved to `research/competitors.md`.

Read the whitespace section twice. That is where the recipe finds its unfair advantage. And do not just note their weaknesses; note their STRONGEST frames too. A competitor's best image is a benchmark you build the recipe to match, then beat.

**Share the WOW:** post your competitor teardown's whitespace section to the bootcamp group. Seeing dozens of sellers each find the gap nobody in their niche is filling is half the education.

---

## Before the next episode (10 to 15 minutes)

The next episode is the Reference Room, where your REAL product and your brand's look get locked into files before any brief is written. It goes faster if you:

1. **Confirm your product photos are in the `reference/` folder** (all angles + hand-for-scale + label close-ups). Ask Wonka: `Check my reference folder. Do you have everything you need to build the reference sheet in the next episode?` If anything is missing, take the shot now; it is twenty minutes of your life.
2. **Gather your brand assets:** logo file (PNG, transparent background if you have it), your brand colors if you know them (hex codes if possible, but "the green on our label" also works), and any real certifications or press mentions with proof. The `/brand-kit` interview goes fast when these are at hand.
3. **Re-read your whitespace section and your selling-points checklist.** Come to the coming episodes with an opinion. You will be a better editor for having slept on the research.

## Definition of Done for Episode 3

- [ ] `/meet-my-product` ran to completion: research digest + persona + selling-points checklist + funnel diagnosis exist in `research/`
- [ ] You corrected or confirmed the persona and checklist (at least one reaction sent)
- [ ] You read and agree with the funnel diagnosis (main image vs detail page)
- [ ] The competitor teardown is done: `research/competitors.md` exists with table stakes, strong frames, and whitespace
- [ ] `status.md` shows RESEARCH done
- [ ] Homework: reference photos confirmed complete, brand assets gathered

## Troubleshooting note

If the table stakes feel off, check the competitor set first: a neighboring-niche competitor poisons the list; ask Wonka `List the competitors you analyzed. Are they all genuinely [my niche phrase]?` and swap out any that are not. If the digest feels generic, your reviews input was probably thin; paste 10 more critical reviews and say: `Re-run the analysis with these reviews.` Everything else: `guides/troubleshooting.md`.

Next episode: the Reference Room. You lock a reference of your REAL product so the AI cannot invent a different one, run the one cheap test that protects all your generation credits, and lock your brand's look into a file. "Measure twice, invent once."

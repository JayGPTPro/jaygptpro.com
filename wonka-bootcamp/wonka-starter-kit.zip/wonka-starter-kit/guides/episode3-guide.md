# Episode 3: Wonka, Meet My Product

This episode you feed Wonka everything about your product, and he earns his salary before touching a single pixel. He digests your niche data and reviews, builds the real buyer persona, runs a funnel diagnosis so you know whether your problem is getting the click or getting the sale, and then tears down your competitors to find the whitespace nobody owns. No images this episode. This is the foundation everything else stands on.

## What you will have by the end of this episode

- A research digest: what your niche demands, what buyers love and hate, who actually buys
- A selling-points checklist where every table stake is named
- A funnel diagnosis: is your problem the main image (getting clicked) or the detail page (getting bought)
- A competitor teardown: what everyone shows, which frames are strong, and the whitespace nobody shows

**Time needed:** 60 to 90 minutes. Most of it is reading what Wonka produces, which is the fun part.

## What you will need at hand

- Your Episode 2 homework on the shelf: the Top Niche Insights export, your reviews, and (optionally) competitor gallery screenshots and your Brand Analytics demographics, all in `research/`
- Your owner intel already on file (you gave it to Wonka at the Front Gate in Episode 2)

---

## Lesson 1: Why research beats taste

Here is the uncomfortable truth about listing images: the prettiest image is usually not the winning image. The winning image is the one that answers, at thumbnail size, the exact question the buyer brought to the search page.

You cannot know that question by taste. You know it from three sources:

1. **Top Niche Insights** tells you the niche's **table stakes**: the features so expected that missing one silently disqualifies you (in castor oil, "glass bottle" is a table stake; in air fryer liners, size accuracy is). It also tells you demographics, search terms, and what top products emphasize.
2. **Reviews** tell you the emotional truth: what buyers celebrate, what they return, what they wish someone had shown them before buying. A critical review is a buyer writing your image brief for free.
3. **Competitors** tell you the visual landscape: what every gallery in the niche already shows (you must match it) and what nobody shows (your chance to own something).

The rule that runs through this whole Factory: **every selling point gets mapped to an asset, or gets skipped in writing, with a reason.** Nothing important disappears silently.

## Lesson 2: The real buyer, not the imagined one

Most listings are art-directed for an imagined customer, often 25 years younger than the person actually clicking Buy. Wonka builds the persona from the data in front of him: the niche demographics from your insights export, plus the voice in your reviews. If you have Brand Registry and exported ASIN-level demographics (Episode 2 optional homework), even better: those are your ACTUAL buyers, and they usually skew older than the niche average.

This persona decides real things later: who appears in lifestyle images, what fears the images answer, what language goes in headlines, and who gets surveyed in the Tasting Room. Get it wrong here and every downstream episode inherits the mistake.

## Lesson 3: Table stakes vs whitespace

Two words you will use for the rest of your selling career:

- **Table stakes**: what every serious player in the niche shows. Missing one = silent disqualification. You do not get points for these, you get eliminated without them.
- **Whitespace**: what nobody in the niche shows, but reviews say buyers care about. This is where a new image set wins.

The competitor teardown exists to sort every visual idea into one of those two buckets.

## Lesson 4: The funnel diagnosis (where to spend your effort)

Because you are building the FULL package this bootcamp (main image, secondaries, A+, variations), it helps to know where your listing actually leaks. There are two very different problems, and they need different fixes:

- **Low click-share** = shoppers see you in search and scroll past. That is a MAIN-IMAGE problem (the CTR lever). Fix the hero shot.
- **Good click-share but low purchase-share** = shoppers click, then leave without buying. That is a DETAIL-PAGE problem (the CVR lever). Fix the secondaries and A+.

If you have Brand Registry, your Search Query Performance export tells you which one you have. If you do not, Wonka reasons from what you know and your reviews. Either way, the diagnosis steers the Episode 5 recipe toward the assets that will move the needle.

---

## MISSION 1: Feed the Research Room

This whole episode runs on ONE command, the same one that opened the Front Gate in Episode 2:

```
/meet-my-product
```

Wonka picks up exactly where the Front Gate left off. He checks the shopping list he handed you (the Top Niche Insights export, the reviews, your product photos, plus the optional extras) against what is actually on the shelf. If anything is missing, he names it exactly and waits. That is by design: the Research Room does not run on guesses. Fix the gap (export the insights, paste the reviews), then tell him:

```
Everything is in.
```

Now the digestion runs. Wonka reads the insights export, the reviews, and your owner intel, and produces the research digest: niche table stakes, top features buyers care about, pain points from critical reviews, search language, demographics, the buyer persona, and the funnel diagnosis. Everything is saved to your product's `research/` folder.

**Your job while reading it:** react. You know things the data does not. Tell him:

```
Correction: [what he got wrong or what the data misses, e.g. "our buyers are mostly repeat customers, the persona should reflect that"]
```

He updates the digest. This is a conversation, not a report you file away.

## MISSION 2: Sanity-check the selling points

The digest ends with the **selling-points checklist**: every table stake, top feature, differentiator, and material/quality signal, each one destined for an asset. Interrogate it:

```
Show me the selling-points checklist. For each point, tell me where it came from (insights, reviews, or my owner intel).
```

Then check three things yourself:

1. **Is anything missing that YOU know matters?** You told Wonka your owner intel in Episode 2; make sure it survived into the checklist.
2. **Is anything on the list that is not true of your product?** Kill it now, loudly. A false selling point becomes a false image becomes a return.
3. **Is any point vague?** "High quality" is not a selling point. "Glass bottle, not plastic" is.

## MISSION 3: Read the funnel diagnosis

Find the diagnosis in the digest and make sure you agree with it:

```
Give me the funnel diagnosis in one line: is my problem the main image (click-share) or the detail page (purchase-share), and what's the evidence?
```

If you have your own sense of where the listing leaks (from your own sales data), tell him. This one line quietly steers how much weight the Episode 5 recipe puts on the main image versus the secondaries and A+.

## MISSION 4: The Spy Balcony

The competitor teardown is part of the same `/meet-my-product` analysis; Wonka moves to it once the digest is confirmed. He will ask you for 3 to 5 competitor ASINs or URLs. Pick the ones actually beating you on your main keyword, not the ones you find flattering to compare against. One expectation to set: if Wonka cannot browse the competitor listings from your machine, he will ask you to screenshot their image galleries into `research/`; the Episode 2 homework already suggested doing exactly that. He tears down their galleries: what every one of them shows (table stakes confirmed), which of their frames are strong (worth matching, then beating), and what nobody shows (your whitespace). Saved to `research/competitors.md`.

Read the whitespace section twice. That is where the recipe finds its unfair advantage. And do not just note their weaknesses; note their STRONGEST frames too. A competitor's best image is a benchmark you build the recipe to match, then beat.

**Share the WOW:** post your competitor teardown's whitespace section to the bootcamp group. Seeing dozens of sellers each find the gap nobody in their niche is filling is half the education.

---

## Before the next episode (10 to 15 minutes)

The next episode is the Reference Room, where your REAL product and your brand's look get locked into files before any brief is written. It goes faster if you:

1. **Confirm your product photos are in the `reference/` folder** (all angles + hand-for-scale + label close-ups). Ask Wonka: `Check my reference folder. Do you have everything you need to build the reference sheet in the next episode?` If anything is missing, take the shot now; it is twenty minutes of your life.
2. **Gather your brand assets:** logo file (PNG, transparent background if you have it), your brand colors if you know them (hex codes if possible, but "the green on our label" also works), and any real certifications or press mentions with proof. The `/brand-kit` interview goes fast when these are at hand.
3. **Re-read your whitespace section and your selling-points checklist.** Come to the coming episodes with an opinion. You will be a better editor for having slept on the research.

## Definition of Done for Episode 3

- [ ] `/meet-my-product` ran to completion: research digest + persona + selling-points checklist + funnel diagnosis exist in `research/`
- [ ] You corrected or confirmed the persona and checklist (at least one reaction sent)
- [ ] You read and agree with the funnel diagnosis (main image vs detail page)
- [ ] The competitor teardown is done: `research/competitors.md` exists with table stakes, strong frames, and whitespace
- [ ] `status.md` shows RESEARCH done
- [ ] Homework: reference photos confirmed complete, brand assets gathered

## Troubleshooting note

If `/meet-my-product` says it cannot find the insights export, it is usually filed in the wrong product folder or exported for a different niche phrase than the one you confirmed in Episode 2; ask Wonka `Which exact niche do you need, and where should the file be?` and he will name both. If the digest feels generic, your reviews input was probably thin; paste 10 more critical reviews and say: `Re-run the analysis with these reviews.` Everything else: `guides/troubleshooting.md`.

Next episode: the Reference Room. You lock a reference of your REAL product so the AI cannot invent a different one, run the one cheap test that protects all your generation credits, and lock your brand's look into a file. "Measure twice, invent once."

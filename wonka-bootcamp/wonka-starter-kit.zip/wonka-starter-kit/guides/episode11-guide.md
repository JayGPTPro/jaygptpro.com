# Episode 11: Publish & Test

Survey 2 has filled, and this episode the winner gets crowned by data twice over. Wonka reads the survey-2 verdict, `/publish` packages your full tested set into a ready-to-upload deliverable, and then you learn the practical craft almost every course skips: exactly how to upload your winning creative to Amazon, and how to run a real on-Amazon A/B test in Manage Your Experiments. By the end you have a package that is not just built, it is ready to go live.

## What you will have by the end of this episode

- The survey-2 verdict: a twice-tested winner with voters' own words behind it
- **A Golden Ticket package: a full, tested creative package ready to upload to Amazon**
- A clear, step-by-step plan for getting it live: the direct upload path, and the Manage Your Experiments A/B path
- Your hypothesis and the metric to watch, recorded, so "did it work?" has a real answer later

**Time needed:** 60 to 90 minutes total, once survey 2 has filled. The reading is quick; the upload/A/B lesson is where the time goes.

## What you will need at hand

- Survey 2 filled, and the ProductPinion MCP connected so Wonka can pull the results
- Seller Central login (for the upload, and for the optional A/B if you have Brand Registry)
- Your gate-passed full package: main winner, secondary set, A+ modules

---

## Lesson 1: What two rounds of testing actually bought you

Look at the chain of evidence under the image you are about to crown: it was briefed from niche data and reviews, generated against your real product, gate-checked on six dimensions, chosen by real shoppers over your live image, refined by those shoppers' own comments, and then tested AGAIN against a data-driven challenger. No agency deliverable on earth comes with that paper trail.

That paper trail is the point. When you upload this image, you are not hoping. You are executing a decision your own market already made. And when someone asks "why this image?", you have voters' verbatim words as the answer.

## Lesson 2: The Golden Ticket (the finish line of the build)

The Golden Ticket is the package: the twice-tested main image, the gate-passed secondary set, the A+ modules, the evidence trail, the hypothesis, and the metric to watch. It is ready to upload as-is. This is the point in the bootcamp where you cross from "creative built" to **a full, tested creative package ready to upload.**

The package includes the control (your current live image) on purpose. Keeping the before next to the after is how you (and anyone you report to) can see exactly what changed and why.

## Lesson 3: Getting it live, path one (direct upload)

For most graduates, the move is simple: upload the winner and note the date. Here is the exact path for the main image:

1. Log in to **Seller Central**.
2. Go to **Inventory, then Manage Inventory** (or **Manage All Inventory**).
3. Find your ASIN, click **Edit**, and open the **Images** tab (called "Product Images" or "Manage Images" depending on your account).
4. Replace the **main image** slot with your winning main. Add or replace the **secondary images** with your gate-passed set, in the order your recipe planned.
5. **Save and finish.** Image updates can take a little time to appear live; Amazon sometimes reviews them first.
6. For **A+ content**: go to **Advertising, then A+ Content Manager** (or **Brands, then A+ Content Manager**), create or edit the A+ for your ASIN, and build it from your gate-passed modules.

Then record the swap: the date, your before metrics (sessions, unit session percentage, conversion), and the hypothesis. Compare after 3 to 4 weeks. Less rigorous than a controlled test, still a data-informed upgrade, and your two survey rounds already de-risked it.

## Lesson 4: Getting it live, path two (the on-Amazon A/B)

If you have Brand Registry, there is a more rigorous option: **Amazon's Manage Your Experiments**, a true on-Amazon A/B where Amazon splits real traffic between your current main and your winner and reports which converts better. It takes weeks to mature (Amazon suggests 8 to 10 for reliable results) and requires eligibility, which is exactly why it is a choice rather than a requirement. Your Taste Tests already de-risked the change; the A/B, if you run it, turns "de-risked" into "proven on Amazon itself".

The exact path:

1. Log in to **Seller Central**.
2. Menu: **Brands, then Manage Your Experiments.**
3. Click **Create a New Experiment**, then **A/B Test Your Main Image** (main image is the cleanest single-variable test; A+ and title tests exist too).
4. Select your ASIN, upload the winner as **version B**, paste the hypothesis from your Golden Ticket, set the duration (Amazon suggests 8 to 10 weeks), and schedule it.
5. Let it run. **No decisions before the test matures**; peeking is fine, flinching is not.

**No Brand Registry?** Use path one (direct upload) and note your before/after metrics as a straight swap. Consider starting Brand Registry enrollment in parallel; it unlocks the proper A/B for your next product. Either way, the package is ready; uploading is your call and your timing.

---

## MISSION 1: Read the survey-2 verdict

```
Pull the survey 2 results and give me the final verdict: refined winner or challenger, the margins, and what the round-2 comments add to what we learned in round 1.
```

Wonka saves the analysis to `tests/`. Whichever image won, it is now a twice-tested winner: chosen over the incumbent, then confirmed against a data-driven challenger (or dethroned by one, which is the same information wearing a different hat). If the margins are thin, ask him to say so honestly and note it in the evidence.

## MISSION 2: The Golden Ticket

```
/publish
```

Wonka assembles the package into `tests/publish-pack.md` and the ready-to-ship files into `output/`: the twice-tested winning main image, the full supporting set (secondaries and A+), the control (your current live image), the hypothesis ("new main image will lift CTR because voters said X"), the metric to watch, and an entry in the experiments log.

Verify it is real, not just described:

```
Show me exactly what's in output/ now, and confirm the publish-pack.md lists the winner, the supporting set, the control, the hypothesis, and the metric to watch.
```

## MISSION 3: Make your go-live plan

Now decide HOW it goes live, and have Wonka write the plan into your files so future-you knows what you did:

```
Based on my account, which go-live path fits: the direct upload, or the Manage Your Experiments A/B? Walk me through the exact steps for my path, and record the plan and the metric to watch in the experiments log.
```

If you have Brand Registry and want the rigorous route, ask for the A/B walkthrough specifically; if not, ask for the direct-upload checklist. Either way you leave this episode knowing precisely where each file goes and what number tells you it worked.

## MISSION 4: Upload (or schedule the upload)

Do the upload now if you can, following Lesson 3 or Lesson 4 for your path. If your team handles uploads, hand them the `output/` folder and the embedding order from the Golden Ticket. Then log what happened:

```
I uploaded the package today (or: I scheduled the A/B to start on [date]). Record the go-live date and the before metrics in the experiments log, and note the date I should check results.
```

The package is ready and the plan is recorded. That is the "Test" half of Publish & Test set in motion.

**Share the WOW:** post your before/after main image and the survey numbers from both rounds in the bootcamp group. A twice-tested winner, going live with its evidence, is exactly what this bootcamp promised.

---

## Before the next episode

The next episode is the multiplier: the Variations Room, where the winning listing spreads to your color/size/scent variations. To arrive ready, jot down your real variation SKUs for this product (colors, sizes, scents, bundles), or confirm it has none. If it truly has none, the next episode is short and mostly about planning your next products.

## Definition of Done for Episode 11

- [ ] Survey-2 results pulled and analyzed; the twice-tested verdict saved in `tests/`
- [ ] `/publish` ran: `tests/publish-pack.md` exists, the full tested package is in `output/`, experiment logged
- [ ] You chose a go-live path (direct upload or Manage Your Experiments A/B) and have the exact steps
- [ ] The package uploaded, or the A/B scheduled, or the upload consciously scheduled for a set date
- [ ] Go-live date, before metrics, and the metric to watch recorded in the experiments log; `status.md` updated

## Troubleshooting note

If the survey-2 results will not pull, confirm the MCP connection and that the survey finished filling. If Manage Your Experiments does not show your ASIN, eligibility (Brand Registry plus traffic thresholds) is the usual cause; use the direct-upload path meanwhile and start Brand Registry enrollment. If `/publish` reports a missing artifact (a set not gate-passed, a test not logged), that is the integrity system working; go complete the named gap rather than forcing the package. If an uploaded image does not appear live, Amazon may still be reviewing it, give it time before re-uploading. Everything else: `guides/troubleshooting.md`.

Next episode: the Variations Room, where the same tested creative multiplies across your whole variation family for almost nothing. "You didn't build an image. You built a factory. Now we turn up the volume."

# Episode 11: Publish & Test

Two Tasting Rounds are on the books, and this episode the winner gets crowned. Wonka recaps the twice-tasted verdict, `/ready-to-upload` packages your full tested set into a ready-to-upload deliverable, and then you learn the practical craft almost every course skips: exactly how to upload your winning creative to Amazon, and how to run a real on-Amazon A/B test in Manage Your Experiments. By the end you have a package that is not just built, it is ready to go live.

## What you will have by the end of this episode

- The twice-tasted verdicts, confirmed: a winning main AND a winning gallery, each with two rounds of tasting notes behind it
- **A Golden Ticket package: a full, tested creative package ready to upload to Amazon**
- A clear, step-by-step plan for getting it live: the direct upload path, and the Manage Your Experiments A/B path
- Your hypothesis and the metric to watch, recorded, so "did it work?" has a real answer later
- The optional Pro Move on your radar: a real-shopper poll for big-money decisions

**Time needed:** 60 to 90 minutes total. The reading is quick; the upload/A/B lesson is where the time goes.

## What you will need at hand

- The Tasting Cards from both rounds in `tests/` (main race and gallery race, Round 1 and Round 2, from the last two episodes)
- Seller Central login (for the upload, and for the optional A/B if you have Brand Registry)
- Your gate-passed full package: main winner, secondary set, A+ modules

---

## Lesson 1: What two rounds of tasting actually bought you

Look at the chain of evidence under the package you are about to crown: it was briefed from your competitor teardown and reviews, generated against your real product, gate-checked on six dimensions, and then raced twice. The main image was preferred over your live image by a demographic-matched panel, refined from that panel's own notes, and tasted AGAIN (against a data-born challenger, if you fielded one). The gallery raced your live Amazon gallery set against set, had its weakest frames refined from the frame-by-frame notes, and raced again. No agency deliverable on earth comes with that paper trail.

That paper trail is the point, and so is naming it honestly: two Tasting Rounds are a strong directional case plus a mined list of your buyers' likely objections, answered. They are not real-shopper proof; the on-Amazon A/B (or the optional Pro Move below) is where proof lives. When someone asks "why this image?", you have the tasters' verbatim notes as the answer, and you say what they are.

## Lesson 2: The Golden Ticket (the finish line of the build)

The Golden Ticket is the package: the twice-tasted main image, the gate-passed secondary set, the A+ modules, the evidence trail, the hypothesis, and the metric to watch. It is ready to upload as-is. This is the point in the bootcamp where you cross from "creative built" to **a full, tested creative package ready to upload.**

The package includes the control (your current live image) on purpose. Keeping the before next to the after is how you (and anyone you report to) can see exactly what changed and why.

## Lesson 3: Getting it live, path one (direct upload)

For most graduates, the move is simple: upload the winner and note the date. Here is the exact path for the main image:

1. Log in to **Seller Central**.
2. Go to **Inventory, then Manage Inventory** (or **Manage All Inventory**).
3. Find your ASIN, click **Edit**, and open the **Images** tab (called "Product Images" or "Manage Images" depending on your account).
4. Replace the **main image** slot with your winning main. Add or replace the **secondary images** with your gate-passed set, in the order your recipe planned.
5. **Save and finish.** Image updates can take a little time to appear live; Amazon sometimes reviews them first.
6. For **A+ content**: go to **Advertising, then A+ Content Manager** (or **Brands, then A+ Content Manager**), create or edit the A+ for your ASIN, and build it from your gate-passed modules.

Then record the swap: the date, your before metrics (sessions, unit session percentage, conversion), and the hypothesis. Compare after 3 to 4 weeks. Less rigorous than a controlled test, still a data-informed upgrade, and your two Tasting Rounds already de-risked it.

## Lesson 4: Getting it live, path two (the on-Amazon A/B)

If you have Brand Registry, there is a more rigorous option: **Amazon's Manage Your Experiments**, a true on-Amazon A/B where Amazon splits real traffic between your current main and your winner and reports which converts better. It takes weeks to mature (Amazon suggests 8 to 10 for reliable results) and requires eligibility, which is exactly why it is a choice rather than a requirement. Your Tasting Rounds already de-risked the change; the A/B, if you run it, turns "de-risked" into "proven on Amazon itself".

The exact path:

1. Log in to **Seller Central**.
2. Menu: **Brands, then Manage Your Experiments.**
3. Click **Create a New Experiment**, then **A/B Test Your Main Image** (main image is the cleanest single-variable test; A+ and title tests exist too).
4. Select your ASIN, upload the winner as **version B**, paste the hypothesis from your Golden Ticket, set the duration (Amazon suggests 8 to 10 weeks), and schedule it.
5. Let it run. **No decisions before the test matures**; peeking is fine, flinching is not.

**No Brand Registry?** Use path one (direct upload) and note your before/after metrics as a straight swap. Consider starting Brand Registry enrollment in parallel; it unlocks the proper A/B for your next product. Either way, the package is ready; uploading is your call and your timing.

## Lesson 5: The Pro Move (optional, for big-money decisions)

Between the instant panel and the weeks-long A/B sits one more tool: a **real-shopper poll**. PickFu, ProductPinion, or any panel you prefer; the method does not care which. Real people matched to your buyer see your finalists and vote, usually within a day, for a real (but modest) fee.

When is it worth it? When the decision is big enough that you want human eyes before Amazon's: a hero product's main image, a packaging change across a whole line, a rebrand. The flow is simple: take the Tasting Room's finalists (never more than 2 or 3), run them past real shoppers, and let the humans break any remaining tie. It is not required, it is not part of the bootcamp's guarantee, and most images will never need it. But when the stakes are real money, real shoppers are the gold standard, and now you know exactly where they fit.

---

## MISSION 1: Confirm the twice-tasted verdict

```
Read the Tasting Cards from both rounds in tests/, both races, and give me the final verdicts: the winning main (refined winner or challenger), the gallery race's set verdict, the margins in both rounds, and what Round 2's notes added to Round 1. Say plainly whether each verdict is clear.
```

Whichever main won, it now carries two rounds of evidence: preferred over the incumbent, then confirmed (against a data-born challenger, if you fielded one; dethroned by one is the same information wearing a different hat). And the gallery carries its own two-round paper trail: raced set against set vs your live gallery, refined frame by frame, raced again. If the margins are thin, Wonka says "no clear verdict" and you decide: refine and re-taste (cheap, fast), or escalate the finalists to the optional real-shopper poll from Lesson 5 before packaging.

## MISSION 2: The Golden Ticket

```
/ready-to-upload
```

Wonka assembles the package into `tests/upload-pack.md` and the ready-to-ship files into `output/`: the twice-tasted winning main image, the twice-raced gallery, the A+ modules, the control (your current live images), the hypothesis ("new main image will lift CTR because the tasters said X"), the metric to watch, and an entry in the experiments log.

Verify it is real, not just described:

```
Show me exactly what's in output/ now, and confirm the upload-pack.md lists the winner, the supporting set, the control, the hypothesis, and the metric to watch.
```

## MISSION 3: Make your go-live plan

Now decide HOW it goes live, and have Wonka write the plan into your files so future-you knows what you did:

```
Based on my account, which go-live path fits: the direct upload, or the Manage Your Experiments A/B? Walk me through the exact steps for my path, and record the plan and the metric to watch in the experiments log.
```

If you have Brand Registry and want the rigorous route, ask for the A/B walkthrough specifically; if not, ask for the direct-upload checklist. Either way you leave this episode knowing precisely where each file goes and what number tells you it worked.

## MISSION 4: Upload (or schedule the upload)

Do the upload now if you can, following Lesson 3 or Lesson 4 for your path. If your team handles uploads, hand them the `output/` folder and the embedding order from the Golden Ticket. Then log what happened:

```
I uploaded the package today (or: I scheduled the A/B to start on [date]). Record the go-live date and the before metrics in the experiments log, and note the date I should check results.
```

The package is ready and the plan is recorded. That is the "Test" half of Publish & Test set in motion.

**Share the WOW:** post your before/after main image and the margins from both Tasting Rounds in the bootcamp group. A twice-tasted winner, going live with its evidence, is exactly what this bootcamp promised.

---

## Before the next episode

The next episode is the multiplier: the Variations Room, where the winning listing spreads to your color/size/scent variations. To arrive ready, jot down your real variation SKUs for this product (colors, sizes, scents, bundles), or confirm it has none. If it truly has none, the next episode is short and mostly about planning your next products.

## Definition of Done for Episode 11

- [ ] The Tasting Cards from both rounds read, both races; the twice-tasted verdicts confirmed (or honestly called thin, with your decision recorded)
- [ ] `/ready-to-upload` ran: `tests/upload-pack.md` exists, the full tested package is in `output/`, experiment logged
- [ ] You chose a go-live path (direct upload or Manage Your Experiments A/B) and have the exact steps
- [ ] The package uploaded, or the A/B scheduled, or the upload consciously scheduled for a set date
- [ ] Go-live date, before metrics, and the metric to watch recorded in the experiments log; `status.md` updated
- [ ] You know when the optional real-shopper poll (the Pro Move) is worth its fee, and when it is not

## Troubleshooting note

If Wonka cannot find a Tasting Card, it lives in the product's `tests/tasting-r[N]-[date]/` folder as `tasting-card.md`; point him at it (and re-run `/tasting-room` only if a round truly never completed). If Manage Your Experiments does not show your ASIN, eligibility (Brand Registry plus traffic thresholds) is the usual cause; use the direct-upload path meanwhile and start Brand Registry enrollment. If `/ready-to-upload` reports a missing artifact (a set not gate-passed, a round not logged), that is the integrity system working; go complete the named gap rather than forcing the package. If an uploaded image does not appear live, Amazon may still be reviewing it, give it time before re-uploading. Everything else: `guides/troubleshooting.md`.

Next episode: the Variations Room, where the same tested creative multiplies across your whole variation family for almost nothing. "You didn't build an image. You built a factory. Now we turn up the volume."

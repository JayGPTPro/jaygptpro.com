# Episode 6: The Main Image Room

This episode the Factory produces its most valuable single asset: the main image, the one picture that decides whether a shopper scrolling search results ever meets your product at all. You will generate 4 main image concepts against the recipe, inspect them, and fix them, and in doing so you will run the Factory's core quality loop, generate, inspect, fix, for the first of three times. Master it here on one image; the next two episodes just widen it.

## What you will have by the end of this episode

- **4 main image concepts: product-only, no people, each a different strategy for winning the click**
- A scorecard on the mains: every candidate scored, ranked, and marked pass/fail with specific reasons
- Flagged candidates repaired via surgical fixes, with originals kept
- A working understanding of what makes main images convert

**Time needed:** 75 to 100 minutes, including generation waiting time.

## What you will need at hand

- The approved `brief/creative-brief.md` (Wonka reads it; you should have the main image brief fresh in your head)
- Episode 4's passed smoke test and locked Mold
- Your OpenAI key working (the Fixing Room runs on it)
- Your phone, for one honest look at a candidate at real thumbnail size

---

## Lesson 1: The main image is a different animal

Every other asset on your listing gets seen by people who already clicked. The main image gets seen by everyone who DIDN'T, at thumbnail size, next to ten competitors, for well under two seconds. It has one job: win the click. That job shapes hard rules:

- **Product-only.** No people, no faces, no hands. The hero is the product, full stop.
- **No overlay text or graphics.** Only what physically exists on the product and its label. (This is also Amazon policy for main images, and it is where most "creative" mains die in review.)
- **Instant legibility.** The product must read, size, type, and key claim on the physical label, at 160 pixels wide.

Everything persuasive you want to ADD to a main image has to be physically true: the real label, real certification seals printed on the bottle, the real color of the real product. That constraint is not a limitation; it is the game.

## Lesson 2: Converting main-image strategies (the ways to win the click)

Within those hard rules, there is real strategic room. The strongest recurring strategies:

1. **The dominant product.** The product fills the frame edge to edge, bigger and bolder than every competitor's thumbnail. Cheap, reliable, and the first thing to test if your current main is a timid product-on-white.
2. **The physical difference, made visible.** If your product's edge is physical (glass not plastic, 16oz not 8oz, metal not nylon), stage the shot so the material or size reads instantly: light that shows glass as glass, an angle that shows thickness.
3. **The on-label trust signal.** If your real label carries a certification (USDA Organic, GMP), angle and light the product so the seal is legible at thumbnail size. Trust you can prove beats claims you cannot.
4. **The un-boxed reveal.** Show the product plus what is physically included (the dropper, the applicator, the accessories laid out with it), when the bundle is the differentiator.
5. **The pattern interrupt.** Every competitor shoots straight-on on white? A slight hero angle, a dramatic shadow, a propped composition (where the props are physically real and allowed) can win the eye without breaking policy.

Your recipe's main image brief already picked a direction from your research. The 4 concepts you generate now are variations on how to execute it, so the Taste Test later measures strategy against strategy, not luck against luck.

## Lesson 3: The quality loop (generate, inspect, fix)

Here is the loop you will run three times in this bootcamp, once per asset class:

1. **Generate** against the brief (`/main-image` this episode; `/secondary-images` and `/aplus` in the next two). Batches always contain defects. That is normal and planned for.
2. **Inspect** (`/inspect`): every image scored on 6 dimensions, a mechanical squint test at 160px, a hard compliance gate, and a ranking. Wonka finds the defects so your eyes are spent on decisions, not debugging.
3. **Fix** (`/fix` MODE A): surgical edits for the cheap flaws (a word, an element, a color), regeneration with a tighter brief for the structural ones. Originals always kept, fixes saved beside them as `_fixN` files.

The order matters: human review is for picking winners, not finding defects. Wonka inspects first, fixes what is cheap, and only then asks for your judgment.

## Lesson 4: What generation actually costs

This is an episode where real money moves (unless it is covered by your included Genrupt month, which for this bootcamp it is). Order of magnitude: the smoke test was cents; 4 main concepts are a small batch. Wonka's standing rule holds regardless: **he never spends silently.** Before the batch, he states the estimated cost in one line and waits for your go-ahead. Compare that with $50 to $200 per image at a design agency, and enjoy the moment.

---

## MISSION 1: Confirm the line is ready

Before spending anything:

```
Confirm we're clear to invent: recipe approved, brand kit done, mold locked, smoke test passed. List anything blocking.
```

If Wonka names a gap, fix it first. Generation on an unverified Mold is exactly the money-waster the smoke test exists to prevent.

## MISSION 2: Invent the mains

The main event:

```
/main-image
```

The skill is scoped to the main image and nothing else: it generates 4 main image concepts from the brief, product-only, no people, no overlay text or graphics, and it states the batch cost before spending.

Wonka assembles the recipe's main brief, the brand kit, and the locked Mold, states the cost in one line, and waits. Give the go-ahead:

```
Approved, go.
```

He generates the 4 concepts into `images/`. While the batch runs, re-read the recipe's main image brief so you know what each incoming concept is supposed to do.

## MISSION 3: Inspect the mains (scoped run)

```
/inspect scoped to the main image candidates only.
```

Wonka opens each concept with vision, scores the six dimensions (message clarity, legibility, product accuracy, brand fit, craft, casting), runs the mechanical 160px squint test, applies the compliance gate, and force-ranks the 4. The scorecard saves to `scorecards/`.

How to read it: per-image scores are the diagnosis, compliance is a separate PASS/FAIL that no score can buy back, and the ranking is an input to your decision, not the decision. For every FAIL there should be a specific reason and the cheapest fix. Vague verdicts are not allowed in this room; if you see one, push:

```
Concept 3 got "weak composition". That's vague. What exactly fails, on which dimension, and what's the fix?
```

## MISSION 4: Do the squint test yourself, once

You should feel this standard in your hands at least once in the bootcamp, and the main image is the place:

```
Show me the top-ranked main concept at squint size, next to full size.
```

Look at the tiny version the way a shopper does: two seconds, phone in one hand, coffee in the other. Can you tell what the product is, its size, its material? Now you know why main images live or die at 160 pixels.

## MISSION 5: The Fixing Room

```
/fix
```

Wonka presents the full fix list for the flagged mains, routes each item (surgical edit vs regenerate), and puts ONE total cost line at the bottom (surgical edits are cents each). One go-ahead from you, then he runs the whole batch of fixes; he does not ping you edit by edit. Every fix is saved as a new file next to its original.

When the fixes land, close the loop; a fixed image has not passed anything until it is re-inspected:

```
Re-inspect the fixed mains and update the scorecard.
```

Repeat fix and re-inspect until all 4 concepts are gate-passed. Two rounds is typical. Do NOT pick a winner yet; that choice belongs to real shoppers in the Tasting Room, and to you just before it.

**Share the WOW:** post your current live main image next to your top-ranked new concept in the bootcamp group. This before/after pair is the whole bootcamp in one post.

---

## Before the next episode (10 minutes)

The next episode runs the exact same loop on the secondary set, which is bigger and has people in it. To arrive ready:

1. Re-read the recipe's secondary set: each slot's job, message, and casting note.
2. Confirm this episode closed clean: `One-line status: are 4 gate-passed main concepts saved in images/ with the scorecard in scorecards/?`
3. Nothing else. Do not generate ahead; set thinking (the next episode's lesson) changes how you receive a batch.

## Definition of Done for Episode 6

- [ ] The line was confirmed ready (recipe, brand kit, mold, smoke test) before spending
- [ ] `/main-image` ran with your cost go-ahead: 4 concepts in `images/`
- [ ] All concepts are product-only, no people, no overlay text or graphics
- [ ] `/inspect` ran scoped to the mains: scorecard in `scorecards/` with scores, compliance gate, reasons, ranking
- [ ] You personally saw one candidate at 160px squint size
- [ ] `/fix` ran on flagged concepts: fixes saved as `_fixN`, originals intact, fixed concepts re-inspected
- [ ] All 4 concepts gate-passed; no winner picked yet
- [ ] `status.md` updated

## Troubleshooting note

If a generated main shows the WRONG product (wrong size, wrong label, glass reading as plastic), the Mold is not holding: stop, do not generate more, and tell Wonka `The mold isn't holding. Re-lock it and give me a fresh smoke test.` If a "fixed" image comes back with new garbled text, that flaw was regenerate-territory, not edit-territory; tell Wonka `This fix garbled the text. Route it to regenerate with a tighter brief.` If a concept sneaks in a person or overlay text, it is not a main; Wonka reclassifies it to the secondary set and generates a replacement concept. Everything else: `guides/troubleshooting.md`.

Next episode: the same loop, wider. The full secondary set, where people finally appear, every image carries a different message, and you learn to judge a SET instead of a picture. "One image is a note. A set is a song."

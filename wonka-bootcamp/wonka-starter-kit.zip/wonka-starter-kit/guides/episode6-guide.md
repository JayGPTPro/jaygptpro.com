# Day 6: The Secondary Images Room

In the Main Image Room you ran the quality loop on one image and came out with gate passed main candidates and your named shortlist. Today you run the same loop on a much harder job: the full gallery, the images that win the sale after your main image wins the click.

There is almost no new machinery today. The commands are `/secondary-images`, `/inspect` and `/fix`, and you already know two of the three. This guide does not re-explain them. If the loop has gone fuzzy, the Day 5 guide and the Day 5 quality loop lesson are the reference, and they were built to be rewatched. What is new here is SET thinking: a gallery is a team, and a team can fail in ways no single player can. That is the whole day.

## What you will have by the end

- A full secondary set generated from your brief, one job and one message per frame, with at least one emotional frame in there
- A scorecard with something the main image never needed: a SET level section, grading your frames as a team
- Every flagged frame repaired, the round saved as a complete `edits/vN/` snapshot, with your originals untouched in `images/`
- A gate passed gallery, ready for the A+ Room, and headed for its own race in the Tasting Room later

**Time needed:** 60 to 90 minutes, including generation waiting time.

**Cost:** one image batch on your generation credits, plus cents on your OpenAI key for repairs. Wonka quotes both before he spends, and you approve once.

## What you need at hand

- Your approved `brief/creative-brief.md`. The secondary slot plan lives in it, and it does the driving today.
- Your locked reference sheet with a passed smoke test, and your brand kit. Nothing new to prepare, this is Day 3 paying off.
- Your OpenAI key working. The Fixing Room runs on it.
- Your gate passed main candidates sitting in `images/`, with any fixes in the latest `edits/vN/` snapshot. They stay untouched today, and so does the main image scorecard with its ranking. The Tasting Room reads that ranking back later, so nothing today may re-rank or rewrite it.

---

## What to understand before you run anything

### 1. A gallery is a team, not a pile of pictures

Your main image is a solo. Your gallery is a team, and a shopper does not judge it image by image. She swipes through it as one experience, on a phone, usually before she reads a single bullet point.

Which means a set can fail in four ways that are completely invisible when you look at pictures one at a time:

- **Two frames share a message.** Both are fine alone. Together, one of them is a wasted slot that a real question needed.
- **The same face appears twice.** Each frame is fine alone. Together they read as stock photography, and trust drops the moment a shopper notices.
- **No emotional frame.** Every frame is a competent spec sheet, nobody ever felt anything, so nobody bought.
- **A selling point fell off the map.** Every frame covers something, and yet nobody covers the one thing your buyer needed to see, and she quietly disqualifies you.

So the factory has four set level rules, and they came out of your brief: no two frames share a message, at least one emotional frame, a different person in every people frame, and every selling point covered by a named frame or skipped in writing with a reason.

### 2. One frame per silent question

A shopper who clicked is asking a series of silent questions. Will this solve my problem? How big is it really? Is it any good? Do people like me use this? What do I actually get?

Your gallery answers those questions, one frame per question. A frame trying to answer three questions answers none. That is the anti clutter rule from your brief, applied to a whole gallery instead of a single image.

And if your product has a famous complaint in its reviews, the frame that answers it head on is usually the most valuable frame in the whole set, because it is the one nobody else in your category is willing to make. The bootcamp demo product is the perfect example: its loudest complaint is that the thing does not perform the way the pictures promised. The single best frame in that gallery is the honest answer to exactly that.

### 3. Casting, and why a repeated face is never an edit

People appear in your secondaries and never in your main. Three casting rules, all already baked into your brief:

1. **Cast the real buyer**, the persona from your research day, not the buyer you wish you had.
2. **The aspirational skew.** From age 50 the displayed person looks about 5 years younger, scaling to about 10 years younger by 70. Vital and healthy, same life stage, still recognisably "me" to the buyer.
3. **A different person in every people frame.** Generators love to cast one person and reuse her across a whole set.

The mechanical detail that matters: casting rides structured avatar fields, 1 to 2 avatars from your persona with an explicit age and gender on each, and a second avatar only when your research genuinely found two buyers. Per-image variety within that cast is automatic, so nobody asks for it in prose, and casting is NOT written into image brief text, which is the old method and no longer works. So when the same face comes back, the repair is upstream in the avatars (confirm the explicit age and gender, and whether the second persona avatar should join the cast), followed by a regenerate. Never try to edit a face. It comes back wrong every time.

### 4. Legibility, the one reminder worth repeating

You already know the standard and the squint test. The only new thing is volume: a set gives you a whole gallery of chances to overload a frame instead of one, and label soup is the most common defect of this day. When a frame fails at 160 pixels, subtract. "Remove the two weakest labels and enlarge the headline", not another nudge.

### 5. A note on the demo, and on your own photos

The bootcamp demo product is not our listing and there is no unit on the desk, so its reference sheet was built from the listing gallery and from customer review images, and it records that source honestly. That is the weaker path, and the factory says so out loud rather than pretending otherwise.

You are not in that position. Shoot your product properly: all angles, front, back, sides and top, one shot with a hand in frame for scale, and close ups of the label. Your set will hold its product likeness tighter than the demo's does, and every frame you generate for the rest of the bootcamp benefits.

---

## MISSION 1: Confirm the line, then build the set

Quick check first, so nothing generates on a broken foundation:

```
Confirm we're clear to build the secondary set: brief approved, reference locked
and smoke-tested, brand kit done, main candidates already gate-passed. Anything
blocking?
```

Then the batch:

```
/secondary-images

Generate all secondary slots from the brief, on the locked reference. The main
image candidates stay untouched.
```

**What good looks like:** before Wonka spends anything he reads your slots back, one job each, confirms the casting avatars with an explicit age and gender, confirms the locked reference is attached, and quotes the batch cost in one line. Then he stops and waits for you.

Read that read back properly. It is the last cheap moment to catch a slot that drifted from its job. If two slots sound like the same sentence when he says them out loud, they will look like the same frame when they land. Fix that in the brief now, not in the images later.

Then approve, once:

```
Approved. Run it.
```

While the batch runs, re-read the secondary section of your brief so you know each incoming frame's job before you see it. Judging an image against what it was SUPPOSED to do is a completely different exercise from judging whether you like it.

## MISSION 2: Receive the set as a set

When the batch lands, look at the grid before you look at any single frame. Open the folder in gallery view and take in all six at once.

```
Show me the secondary set in gallery order. For each frame, remind me which slot
it fills and what its one message is supposed to be.
```

**What good looks like:** frames that feel like a team. Different backgrounds, different jobs, different sentences. If two of them look like they came from the same shoot, note it and keep going, the inspection will confirm it in a minute.

Note your gut reactions, and do not start fixing anything by hand. The Inspection Room does that systematically in a moment, and it does it better than your eye does at full size.

## MISSION 3: Inspect the set, then read the set level section FIRST

```
/inspect

Inspect the secondary set. Full standards on every image, plus the set-level
checks: message overlap, repeated faces, the emotional frame, and selling-points
coverage against the brief.
```

Everything from the Main Image Room runs again unchanged: the literal description of each frame, the mechanical squint test at 160 pixels with the downscaled copies written to `scorecards/squint/`, six dimensions scored, the compliance gate. You do not need to re-learn any of it, and you should not slow down for it. Same rule as the main image: no new copies in that squint folder means the legibility scores were eyeballed at full size and the pass is worth nothing.

What is new is the second half of the card. Read it FIRST, before you repair anything. If Wonka offers to fix the cheap fails immediately, hold him:

```
Hold the fixes for a moment. Show me the set-level section first.
```

**What good looks like in the set level section:**

- **Message overlap:** either "none", or two files named explicitly with the sentence they both ended up saying.
- **Emotional frame:** present and named, or flagged as missing.
- **Repeated face:** "none", or the two files that share a person.
- **Selling points coverage:** a table, every point mapped to a named frame, and anything not in the set recorded as a conscious skip with a reason written down.

That last row is the one people skim and should not. A skip is completely fine. A silent skip is not. The difference between a decision and an oversight is whether the reason exists in writing.

Interrogate anything vague:

```
Frame 6 got "cluttered". What exactly fails at squint size, and what is the
cheapest fix: subtract labels, or regenerate?
```

And verify the promise from your brief survived generation:

```
Show me the selling-points coverage table against the generated set. What is
covered, what was consciously skipped, and did anything get lost in generation?
```

## MISSION 4: One fix list, one approval

```
/fix

Fix everything on the secondary scorecard. Build the routed fix list with one
cost line first.
```

**What good looks like:** the complete list arrives BEFORE anything runs, with every item routed and one total cost line. The routing rule is the one from the Main Image Room and it never changes: shorten, remove or swap a word is a surgical edit for cents; enlarge, re-layout, re-cast, or fix the product itself is a regenerate with a tighter brief. The routing card in the Day 5 guide is the page to keep open.

Three things ARE different when the loop runs on a set:

1. **One list, one approval.** Six frames, one cost line, one go ahead. You are not approving six times.
2. **The routing is usually mixed.** A typical set produces one cheap edit plus one or two regenerations. That is healthy, not a sign something went wrong.
3. **The re-inspection covers the WHOLE SET, not just the frames you fixed.** A repair can fix the player and break the team. Recast one person and she might now match the other one. Re-message one frame and it might collide with a different one. So all four set level checks run again from scratch.

Typical requests this day, so you see the range:

```
Shorten the headline on frame 2 from 7 words to 4. Keep everything else exactly.
```

```
Frames 4 and 5 have the same person. Check the custom avatars, give each one an
explicit age and gender, add a distinct second avatar, and regenerate frame 5.
```

```
The scale shot doesn't read, the hand looks too large. Regenerate with a tighter
brief on true proportions.
```

Then close the loop:

```
Re-inspect the whole set including the set-level checks, and update the scorecard.
```

Repeat until the set is gate passed individually AND as a team. Two rounds is typical. Three is normal if your set carries three or more people frames.

**Share the win:** post your full set as ONE grid in the group, not as a single favourite frame. A six frame gallery where every frame does a different job is something most listings, including big brands, simply do not have.

---

## When it goes wrong

**The same face keeps coming back after a regenerate.**
The avatars are underspecified, not the briefs. `Check the custom avatars: explicit age and gender on each, add a distinct second avatar, then regenerate that slot.` Casting text inside a slot brief does nothing at all.

**A frame keeps failing legibility even after a fix.**
Stop nudging and subtract. `Remove the two weakest labels and enlarge the headline.` If it fails a third time, that slot is carrying two jobs. Go back to the brief and cut one.

**The product drifts: wrong shape, wrong finish, a part missing.**
That is a reference problem, not a fix problem, and it is never an edit. `The reference isn't holding on frame N. Re-check the lock and regenerate that slot.` If it drifts on several frames at once, stop and re-lock the reference before spending anything more.

**Two frames still say the same thing after a regenerate.**
The brief is the problem, not the image. Whichever frame drifted from its assigned job is the one to fix, and fix it in the brief first: `Rewrite slot N's message so it does not overlap with slot M, keep its assigned job.` Then regenerate that one slot.

**Wonka refuses to generate.**
He is missing a precondition and he will name it: the brief, a locked reference with a passed smoke test, or the brand kit. That refusal is the integrity rule doing its job. Finish the missing step and come back.

**My set has no people at all, so the casting rules do nothing.**
Legitimate for some products. The other three set rules still apply in full, and the emotional frame is now harder and more important: an emotional frame without people has to carry the feeling through setting, light and moment.

**My gallery has fewer than five real jobs to do.**
Then build fewer frames. Six distinct jobs beat nine overlapping ones, and a set of five sharp frames is a better gallery than seven padded ones. If you want an extra frame, give it a JOB in the brief first. Never generate an extra and go looking for a job to give it afterwards.

**Everything passed with no flags.**
Possible with a tight brief. Verify two things by hand: put your people frames side by side and look at the faces yourself, then open your busiest frame's 160 pixel copy from `scorecards/squint/` and try to read it. If there are no copies from this run in that folder, the inspection did not really happen. If both hold, trust the pass.

Anything else: `guides/troubleshooting.md`.

## Definition of Done for Day 6

- [ ] `/secondary-images` ran with your cost approval, full set saved in `images/`
- [ ] Every frame fills its brief slot with one dominant message
- [ ] Your main candidates are untouched, and so is the main image scorecard with its ranking
- [ ] `/inspect` ran with the set level checks, a NEW secondary scorecard saved in `scorecards/` beside the main image one, and a 160 pixel copy of every frame in `scorecards/squint/`
- [ ] All four set level checks are green: no message overlap, no repeated face, one emotional frame present, selling points covered
- [ ] Anything not covered is recorded as a conscious skip, in writing, with a reason
- [ ] `/fix` ran on everything flagged, the round saved as a new complete `edits/vN/` snapshot with originals untouched, whole set re-inspected clean
- [ ] `status.md` updated: secondary images done and gate passed

## Before the next day (10 minutes)

The next room finishes your product page: A+ content, below the fold, running the same loop one more time. To arrive ready:

1. Re-read the A+ line of your brief: the selling points EXPECTED to land in the A+. The page itself is hands-off, Genrupt designs it, and that list is what tomorrow's inspection verifies.
2. Confirm today closed clean: `One-line status: is the full secondary set gate-passed in images/, with the set-level checks green?`
3. Note your A+ eligibility if you know it. Brand Registry? Premium A+ available on your account? Not sure, and Wonka will help you check.

One thing to hold onto before you close the laptop. Your gallery passed a QUALITY gate today. That is craft, not proof. Later in this bootcamp this exact set races the live gallery in the Tasting Room, judged as a set by about a hundred tasters built from your real buyer, with a frame by frame dive after the verdict. Craft happens here. Verdicts happen there.

Next: the A+ Room. "The gallery gets them interested. The A+ gets them nodding."

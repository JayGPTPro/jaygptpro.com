# Episode 10: The Second Batch

The shoppers have voted. This episode you do what almost nobody in e-commerce does: you act on the WHY. Wonka reads every voter comment, makes targeted edits to the winning image based on what real buyers actually said, generates a data-driven round-2 challenger, and publishes survey 2. One round of testing finds a winner; a second round, built from the first round's comments, is how a good image becomes the best image you can currently make.

## What you will have by the end of this episode

- The survey-1 verdict: winner, margins, and a distilled read of the why-comments
- **A refined winner: targeted post-survey edits, each one answering a specific voter comment**
- A data-driven round-2 challenger, generated from what the comments revealed
- **Survey 2 published: refined winner vs challenger vs the incumbent benchmark, filling between episodes**

**Time needed:** 60 to 90 minutes, once survey 1 has filled.

## What you will need at hand

- Survey 1 filled (or nearly; Wonka will tell you if the sample is too thin to read)
- The ProductPinion MCP connected, so Wonka can pull results
- Your OpenAI key working (the comment-driven edits run on it)

---

## Lesson 1: The why is worth more than the winner

The vote tells you which image won. The comments tell you WHY: "I could actually read the label", "the third one looked cheap", "I trust the one showing the certification", "I couldn't tell how big it is". That why is the asset. It transfers to your next product, your A+ content, even your PPC copy. The winner is one image; the why is a pattern.

Most people run a poll, note the winner, and ship it. The comments, the most expensive part of what they paid for, go unread. You are going to mine them the same day and act on them the same day.

## Lesson 2: Comment-driven refinement (MODE B)

You have used `/fix` in MODE A: cleaning QA defects the Inspection Room flagged, before any human saw the images. This episode you use the SAME room in MODE B: refining a proven winner using real shoppers' own words.

The difference matters. MODE A removes flaws; MODE B chases conversion. If voters said "I wish I could see the size", the fix adds or strengthens a scale cue. If several said "the text was hard to read", the message gets bigger (by subtraction, as always). If comments praised something unexpected, that element gets protected and amplified. Every edit traces to a specific comment; nothing is changed on a hunch.

The same routing rules hold: word swaps and removals are surgical edits (cents); layout, casting, and size changes are regenerations with a tighter brief. Originals always kept as `_fixN` siblings.

## Lesson 3: The data-driven challenger

Here is where round 2 earns its name. The comments do not just improve the winner; they often reveal a hypothesis nobody tested. Maybe voters kept mentioning the certification seal that only one candidate showed clearly. Maybe three comments asked about quantity. That is a NEW creative direction, one that emerged from data rather than brainstorming.

So round 2 fields two entrants: the **refined winner** (survey 1's champion, improved by its own voters) and a **challenger** built around the strongest untested hypothesis from the comments. If the challenger wins, the comments found something your original four concepts missed. If the refined winner holds, you have double-confirmed it. Either way you learn, and the Recipe Book gets richer.

## Lesson 4: When the incumbent won round 1

It happens, and it is a GOOD outcome: you just avoided replacing a working image with a worse one, for the price of one survey. The comments now tell you exactly why the incumbent holds, what buyers trust about it, and what your candidates lacked. Round 2 becomes: refine your best candidate to close that specific gap, add a challenger built on the strongest comment insight, and test again. Wonka will be characteristically honest about it: the candy lost, here is why, here is what changes. Losses teach faster than wins.

---

## MISSION 1: Pull and read the results

```
Pull the ProductPinion survey results and tell me: the winner, the margins, and a distilled read of the "why" comments, grouped by theme.
```

Wonka pulls everything through the MCP, saves the analysis to `tests/`, and gives you the verdict. Make him show his work:

```
Show me the strongest 10 comments verbatim, and tell me which theme each supports.
```

Reading real buyers' words about YOUR images is one of the bootcamp's quiet highlights. Somewhere in there is a sentence that will change how you brief creative forever.

## MISSION 2: Refine the winner (MODE B)

```
Run /fix in MODE B on the winning image. Read the voter comments, list the targeted edits they justify, tie each edit to the comment that justifies it, and give me one cost line before you run anything.
```

Review the fix list. Every item should read like: "Edit: enlarge the label area. Justified by: 4 comments saying they could not read it." Strike anything that feels like taste smuggled in as data. Give the one go-ahead. When the edits land:

```
Show me the refined winner next to the original winner, and tell me which voter comment each edit answers.
```

## MISSION 3: Generate the round-2 challenger

```
From the survey comments, what is the strongest creative hypothesis we did NOT test in round 1? Propose a challenger concept built on it.
```

Discuss it; this is a strategy conversation, and your product knowledge matters. When you agree on the concept:

```
/main-image for ONE round-2 challenger only: the concept we just agreed on. State the cost first.
```

Then gate it like everything else:

```
/inspect the challenger, and /fix anything flagged.
```

No image enters a survey un-inspected, not even a data-driven one.

## MISSION 4: Publish survey 2

```
/poll for round 2: the refined winner vs the challenger, with the incumbent still in the grid as the benchmark. Same audience targeting as round 1. Show me the package and the cost.
```

Same auditor's review as last episode: neutrality, random order, incumbent present, persona targeting, cost line. Then the human clicks:

```
The round-2 package looks right. Walk me through approving the cost and publishing.
```

Once it is live: `Survey 2 is published and live.` Wonka logs it, and again, you stop. It fills between episodes.

**Share the WOW:** post one voter comment and the exact edit it produced (before/after crops) to the bootcamp group. "A shopper said X, so we changed Y" is the most persuasive sentence in this whole business.

---

## Before the next episode

Let survey 2 fill. Same rule as before: peek if you must, decide nothing.

Optional, 10 minutes: read the Episode 11 guide's opening. The next episode reads survey 2's verdict, packages the twice-tested winning set into a Golden Ticket, and teaches you the practical part almost every course skips: exactly how to upload to Amazon and how to run a real on-Amazon A/B test.

## Definition of Done for Episode 10

- [ ] Survey-1 results pulled and analyzed: winner, margins, and themed why-comments saved in `tests/`
- [ ] `/fix` MODE B ran: refined winner saved as `_fixN`, every edit tied to a specific voter comment
- [ ] A round-2 challenger concept agreed, generated, inspected, and gate-passed
- [ ] Survey 2 built with the refined winner, the challenger, and the incumbent benchmark
- [ ] Cost approved and survey 2 PUBLISHED by you
- [ ] Experiment logged; `status.md` updated

## Common Episode 10 questions

**"The incumbent won round 1. Is round 2 still worth running?"**
Especially then. You now know exactly why the incumbent holds, from the voters' own mouths. Refine your best candidate to close that named gap, build the challenger on the strongest comment insight, and test again. Beating a strong incumbent on the second try, with its own voters' words as the map, is the whole method working.

**"Can I skip the challenger and just re-test the refined winner?"**
You can, but you would be spending a survey to confirm what round 1 already suggested. The challenger is where the new information lives; it costs one more generation and turns survey 2 from a confirmation into an experiment.

**"How different should the challenger be?"**
Different strategy, not different decoration. If the refined winner is a dominant-product shot, the challenger might lead with the certification seal or the material story. Two shades of the same idea split votes without teaching anything.

## Troubleshooting note

If results will not pull, confirm the MCP is connected (run `/machines-check`) and that the survey actually finished filling; a survey in progress returns partial data. If a MODE B edit garbles text, it was regenerate-territory: `Route this refinement to regenerate with a tighter brief.` If the comments are thin or low-quality, the audience screening may have been too loose; tell Wonka and he will tighten targeting for survey 2. If the vote was a near-tie, ask `Was the margin statistically meaningful, or should round 2 treat this as undecided?` and let him answer honestly. Everything else: `guides/troubleshooting.md`.

Next episode: Publish & Test. Survey 2's verdict comes in, the Golden Ticket packages the full winning set, and you learn the practical craft of getting it live: uploading to Amazon and running an A/B in Manage Your Experiments. "Golden Tickets don't print themselves. Almost, though."

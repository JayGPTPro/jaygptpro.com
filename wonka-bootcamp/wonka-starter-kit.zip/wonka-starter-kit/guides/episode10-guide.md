# Day 10: Variations and The Improvement Loop

Your package is tested and packaged. That package is the thing the guarantee is written against, and the guarantee closes today, when the tenth day and the checklist are both done. Today is about what happens after a run finishes, which is the part almost every course skips.

Three moves and a graduation. You multiply the winner across the variations you actually sell. You put a second product through the Front Gate and time it, because that number is what these ten days really bought you. Then you close the two learning loops, which is the only reason your third product will be better than your first. And then you graduate.

## What you will have by the end of today

- **A variation family built from your twice tested winner**: one matched set off the same locked reference, with a map showing where every file embeds on Amazon. Or a conscious, written `n/a` if your product genuinely has no children
- Your upload pack extended so it covers the whole family
- **A second product through the Front Gate and into a full brief**, with a real elapsed time next to product one's
- **Your first Improvement Log entries** (what your market taught you, read at the start of every future brief) **and your first the Improvement Log entries** (how Wonka works better, read at the start of every session)
- A weekly `/factory-report` habit, and one report on disk
- A completed graduation checklist

**Time needed:** 90 to 120 minutes, plus whatever your second product's inputs take to gather. This is the longest day in the bootcamp because the second product gets a full research pass and a full brief, the same work that filled two rooms on product one. Gather the inputs first and the day runs short. Split it across two sittings if you would rather: the variation family and the speed run in one, the loops and graduation in the other.

## What you will need at hand

- Day 9's finished state: the refined winner, the gate-passed gallery and A+, all four Tasting Cards in `tests/`, and `tests/upload-pack.md` with its Variations line still reading pending
- **The real list of children your product sells.** Colors, sizes, scents, flavors, bundles. Or a confident "none"
- **Your second product's inputs, gathered BEFORE you start.** Photos from all angles plus a scale shot, the listing URL or a description, a reviews file, and 3 to 5 competitor URLs. The speed run is a demonstration of the line, so do not let it become a demonstration of you hunting for files
- Genrupt working, with credits for a small variation batch
- `guides/graduation-checklist.md` open

---

## Lesson 1: Why variations come last, and the one rule that governs the room

You may have wondered why this room waited until the final day. The answer is arithmetic.

Variations multiply whatever you feed them. Adapt an untested listing to five children and you have multiplied a guess by five. Adapt a twice tested winner and every child inherits creative that already beat your live image in two Tasting Rounds. That is this whole bootcamp in one sentence: build once, test until proven, then multiply.

Now the rule that governs the room, and it is the reason `/variations` will push back on you before it generates anything.

**Never a child you do not sell.** Not a color you are considering. Not a size you might launch. Not a bundle that exists only as a plan. An invented variant is a real listing error: a shopper picks it, it does not exist as you showed it, and you get a return and a review out of it. Wonka will ask you for the real child list and he will refuse to guess, which is exactly what you want from him.

On the demo product this plays out on camera in the least convenient way possible. The demo listing sells one configuration and the brief said so back on Day 4: variations, none, single SKU, in writing. So the room opens by refusing, and only then does the honest version get built.

### If you are a single SKU seller

Most sellers reading this are, and most of them close this room assuming it is not for them. Two things are true for you:

1. **A multipack is the one variation type that invents zero product facts.** Two of the same real product is still the same real product. Only the count changes. It is also the child most single SKU sellers genuinely add first. If you are planning one, build it here.
2. **If you are not, record `n/a` in writing and move on.** A room that correctly reads your product and records the absence is a completed room, exactly like the coverage map recording a consciously skipped selling point. It is not a gap on your checklist.

Either way, today's real work for you is the speed run and the two loops, and those apply to everybody.

### If you change the plan, change the document first

If your brief says single SKU and you are now adding a bundle, amend the brief before you generate. Date it, write the reason. It takes twenty seconds and it means that in six weeks, when you or somebody else wonders why bundle images exist for a single SKU product, the answer is in the file rather than in somebody's memory.

### The consistency trap, and why you are immune

Look at almost any variation family on Amazon. The blue one is shot at a different angle to the pink one, on a slightly different background, in slightly different light, because the photos were taken months apart by different people. A shopper cannot name what is wrong, and she feels it anyway. The listing reads as amateur.

Your factory does not have this problem, for a reason you already own: the locked reference. Every child generates against the same product reference, the same brand kit, and the same shot language as the winner. The family comes out matched because only one variable was allowed to move.

Consistency here is not a design skill you have to supply. It is a property of having locked the reference once.

One flag worth knowing: if a "variation" is genuinely a different physical product rather than a different colour or count of the same one, it needs its OWN reference and its own smoke test. Wonka will spot this and say so. Most variations do not need it, and the ones that do are cheaper to catch now than after a batch.

### Where the files actually land

A perfect image in the wrong slot does nothing, so know the map before you generate.

- **Parent and child.** Your children sit under one non buyable parent listing. Shoppers land on the parent and pick a child. Each child is its own buyable SKU.
- **Per child main image.** Each child needs its own main showing THAT child accurately, in the same composition as the rest. A buyer who picks the two pack and sees one unit has been told something untrue before she has paid.
- **Swatches.** The small thumbnails that drive the variation picker. Judge them at the size they actually render, which is tiny. A swatch has one job: telling her at a glance which one she is choosing. A shrunken product photo does not do that job.
- **Shared gallery and A+.** Much of your secondary set and your A+ serves the whole family. Your variations plan marks what is shared and what is per child.

`/variations` writes this map for your specific product, so nothing lands in the wrong slot.

## Lesson 2: What the speed run proves, and what it does not

The second product is the mission that tells you whether you bought a course or a line. It is also the one people get wrong in both directions, so be precise about the claim.

**What actually carries over.** The reference process. The brand kit. The brief method. The research method. The inspect and fix routing. The Tasting Room method. None of that is specific to your first product, none of it gets rebuilt, and you already know how to drive it. That is why product two moves at a different speed.

**What does not carry over.** Market insight. Product two is in its own niche with its own buyer, its own competitors and its own table stakes, so it runs its own research and its own rounds. A pattern proven in one niche is a hypothesis in another, and Wonka will say so rather than reuse it.

**What does not get skipped.** Every gate is still standing: the reference lock, the smoke test, the inspections, both Tasting Rounds. Faster never means fewer gates. If the run feels faster because something got waved through, that is not the line working, that is you in a hurry.

**And one honest gap you should watch for.** When Wonka writes product two's brief he will tell you the Improvement Log is empty. Product two walked into your factory knowing nothing product one learned. Everything this run taught is in your head and in your test files, and your head is not a factory input. That gap is the entire reason there is one more lesson after this one, and closing it is the difference between a factory that multiplies and one that compounds.

One more thing that is not a cheat and gets mistaken for one: the inputs are gathered before the clock starts. Gathering was the participant's job on product one and it is the participant's job here. It was never the part the factory was going to speed up.

## Lesson 3: The two loops, and why they are separate

This is the idea the whole factory was built around, and it takes one command to use.

- **Part 1 of the Improvement Log: what your MARKET wants.** The patterns your Tasting Rounds proved, with the numbers, the sample size, the niche and the date attached, and an honest strength grade. One test is a weak signal. Two consistent tests is a prior that future briefs apply by default. A real Amazon A/B result outranks a Tasting Round, because real purchase behaviour beats synthetic tasters. Every future `/creative-brief` reads this part before writing a word.
- **Part 2 of the Improvement Log: how WONKA works better.** Where the process snagged this run, which defects he could have prevented upstream by planning differently, what he learned about how you like to work. He reads this at the start of every session, so he begins each one sharper.

The distinction is the design. "Shoppers want to see how big it is" is a market fact and belongs in the Improvement Log. "Plan a scale frame at brief time instead of discovering it from a tasting round" is a process change and belongs in Part 2. Same run, two different lessons, two different readers.

Most people close neither loop. They finish a project, feel clever for a week, and the lesson evaporates. Ten minutes of this command is the entire mechanism behind "product three is better than product one", and it is the one shortcut today that actually costs you something if you skip it.

## Lesson 4: Graduation, and what your next product actually costs now

Be precise about this, because it is the most valuable sentence of the bootcamp and it is easy to inflate.

You own reusable machinery: the reference process, the brand kit, the brief method, the research method. You will feel that in Mission 4 today when product two moves visibly faster. And after Mission 5 you also own two books that know things, both read automatically.

So the honest shape of your next run: research and a full package brief in a single session instead of a week of rooms. Generation and inspection on the same gates you already trust. Two Tasting Rounds inside one sitting, because the panel runs in minutes. The only long clock left is the optional on Amazon A/B, and that runs at Amazon's pace in the background while you work on something else.

Half the time is a fair way to describe the WORK and the DECISIONS. It is not a claim about your sales, and nobody honest will make you one. Whether any of this moves your revenue depends on your product, your price and your niche, and that is exactly what an A/B on your own listing measures. Results vary by product and niche.

And then the promise, in the exact words it was made in: **complete all 10 days and the graduation checklist, and you have a full, tested creative package ready to upload by the end of the bootcamp, or a full refund.** Your output folder is the package. The checklist is what closes the guarantee, so walk it rather than assume it, and if it flags a missing artifact, go and fill the gap. A checkbox ticked over a hole is the one way to finish this bootcamp with less than you paid for.

---

## MISSION 1: Tell the room what you actually sell

Before you run anything, get the child list straight in your own head. Colors, sizes, scents, flavors, bundle counts. Only what exists, or what you are genuinely creating as a SKU.

```
/variations
```

Wonka checks the preconditions, reads your brief's variations section back to you, and asks for the real child list. Give him the true one.

**If your brief said single SKU and you are adding a bundle**, amend the document before anything generates:

```
This product sells one configuration. I am adding [the children you are
really creating] as the family. Amend the brief's VARIATIONS section from
"none, single SKU" to this plan, with today's date and the reason, before
you generate anything.
```

**If you genuinely have no children and no bundle planned:**

```
This product has no variations and I am not planning a bundle. Record
variations as n/a in status.md with the reason.
```

That is a completed room. Skip to Mission 4.

## MISSION 2: Generate the family

When the plan reads correctly, give the one go-ahead:

```
Generate the family: per child main and swatch for every child, on the
locked reference, matching the winning composition.
```

**What good looks like in the read-back, before a credit is spent:**
- Every child named, and every one of them real
- The theme stated as ONE dimension (color, or size, or count)
- Composition, angle, lighting and background held constant, with only the varying attribute moving
- The winning composition named as the source, not a fresh design
- One cost line, one go-ahead

Then look at the family as a family, not one image at a time:

```
Show me all the variation images together as one strip. Are these a matched
set, with only the variable changing?
```

If one is off, name it plainly: `The three pack is lit differently from the others. Regenerate it against the locked reference so only the count changes.`

## MISSION 3: Inspect the family and extend the pack

The gate does not take a day off, even on a victory lap.

```
/inspect scoped to the variation images: per image scores, plus the family
checks. Reference fidelity per child, true counts, and whether these read
as siblings.
```

Then the fixes, with the routing you already know:

```
/fix
```

One cost line, one go-ahead, re-inspect to green, and the original never moves. Every round lands as a complete set snapshot in the next `edits/vN/` folder: the surgical edit re-saves its file fixed, the regeneration lands as the new version, and the untouched files are copied in as-is, so the latest folder always holds the whole current family. Two routing rules matter here more than anywhere:

- **Counts and proportions are structural.** A wrong count or a stretched unit regenerates against the locked reference. It is never an edit, and a cheap edit here is how a family stops looking like a family.
- **Different physical product means a different reference.** If a child is genuinely a different item rather than a different colour or count, it gets its own reference and its own smoke test before it gets images.

Then confirm where everything goes, and extend the pack:

```
For each variation image, tell me exactly where it embeds: which child's
main, which shared asset, which swatch.
```

```
Extend the upload pack with the variation family and the embedding map, and
flip the Variations line in tests/upload-pack.md from pending to the real
family. Then update status.md.
```

Your upload pack now covers the whole family: twice tested main, gate-passed gallery and A+, and a matched variation set with a map.

**Share the WOW:** post your family as one strip in the group. A matched, consistent variation family is something most listings, including big brands, never manage.

## MISSION 4: The second product speed run

This is the mission that proves you bought a line and not a product.

Gather the inputs first. Photos from all angles plus a scale shot, the listing or a description, the reviews file, 3 to 5 competitor URLs. Then note the time and start.

```
/meet-my-product

Second product: [your product]. Everything on the shopping list is already
in the folder: photos, the listing, the reviews file, the competitor URLs.
Run the full intake and the research.
```

When the research lands, go straight into the brief:

```
/creative-brief

Full package brief for the new product, same standard as product one.
```

Note the time again. Then look at what actually happened: a full research pass and a full package brief, with no re-teaching, no tour, and nothing skipped. The gates are all still ahead of you, exactly as they were on product one.

You do not need to finish product two today. Getting it through the gate and into a brief is the mission. Two products on the line at once is what a factory looks like.

One thing to notice, because it sets up the next mission: when Wonka writes this brief he will tell you the Improvement Log is empty. Product two walked in knowing nothing product one learned. That is about to change, and it is the last thing you do today.

## MISSION 5: Close both loops

```
/improvement-loop
```

He reads the Improvement Log, then reads your Tasting Cards including the notes, and writes both parts of it.

**Part A, the Improvement Log.** Your market's patterns with the evidence attached: the result numbers, the sample size, the niche, the date, and an honest strength grade. What lost goes in too, because losses teach faster. If you stated a creative preference during the run, it gets recorded as taste and labeled as taste, never dressed up as data.

**Part B, the process lessons (Part 2 of the log).** The process lessons from this run: what he would plan differently, what he could have prevented upstream, what he learned about how you like to work. Each one with a real trigger from this run, a lesson generalized one careful step, and a concrete change to apply next time.

Then read his entry back to him, out loud if you like:

```
Read back your process lesson entry for this run. What will you do differently on
product two?
```

That answer is your Creative Director's first performance self review. Keep it, and screenshot it. It is the strangest and best thing this factory produces.

## MISSION 6: Set the weekly rhythm

```
/factory-report
```

The whole floor in one view: where each product stands, what is blocked and on whom, exactly one next action each, and one priority.

Then set the habit:

```
Help me set the weekly factory-report habit. Can a scheduled task run on
this folder in my setup, or should I use a recurring reminder?
```

If your Claude setup can schedule a task on this folder, schedule it and let the report come to you. If it cannot, a recurring calendar reminder and one command does the same job. Be clear eyed about which one you have: this is a habit with a reminder attached, and it does not run while your machine is off.

## MISSION 7: Graduate

The promise, in the exact words it was made in: **complete all 10 days and the graduation checklist, and you have a full, tested creative package ready to upload by the end of the bootcamp, or a full refund.** It was never a promise about your sales, and it never will be. Results vary by product and niche.

Walk `guides/graduation-checklist.md` top to bottom. The **Guarantee checklist** is the refund condition and should fully close. The **Factory Owner extras** are recommended, and today's missions already covered most of them.

If the checklist flags a missing artifact, that is the integrity system doing its job. Go fill the gap rather than ticking the box by hand.

His honest review of the run is already written and saved, in Mission 5. Do not ask for it again here, because an answer given after the loop has closed is an off the record opinion that lands in no file. This last prompt is the send off, and that is all it is:

```
Wonka, any words for a graduate of the factory?
```

**If you are in the group, share your graduation:** the before and after, both rounds' margins side by side, one tasting note that changed your mind, and one sentence on what surprised you. It is not a requirement and it is not on the checklist. It is just the best thread of the round.

Special respect if your own pick lost in Round 1 and you are graduating with a winner the tasters chose and then improved. That journey is the whole bootcamp inside one person.

---

## Definition of Done for Day 10

- [ ] `/variations` ran on your REAL children, or variations recorded as `n/a` in `status.md` with the reason. Nothing invented
- [ ] If you changed the plan from single SKU, the brief was amended with the date and the reason BEFORE generating
- [ ] The family is a matched set: same staging, same composition, only the variable changing
- [ ] `/inspect` and `/fix` ran on the family: gate-passed, every fix beside an untouched original, counts and proportions regenerated rather than edited
- [ ] You know exactly where each variation image embeds: per child mains, shared assets, swatches
- [ ] `tests/upload-pack.md` extended with the family and the embedding map, Variations line no longer pending
- [ ] Second product through `/meet-my-product` and into `/creative-brief`, with the elapsed time noted
- [ ] `/improvement-loop` ran: first Improvement Log pattern rows with evidence, AND first process lesson entries, and you read the process lesson back
- [ ] `/factory-report` ran, one report exists in `factory/Factory Log/`, and the weekly habit is set
- [ ] Graduation checklist walked; `status.md` shows all stations resolved

Sharing your graduation in the group is not on this list on purpose. It is worth doing and it is not a completion condition, and not every ticket comes with a group.

---

## When it goes wrong

**Wonka gives you a variation you do not sell.** Stop and give him the real child list. Then make sure it lands in the process lessons when you run `/improvement-loop`, because "confirm the real variation list before planning" is exactly the kind of process lesson that part of the log exists for. Never present or upload a variant that does not exist, whatever it looks like.

**The family is not a matched set.** The reference was not held across the batch. `These are not a matched set. Regenerate the odd ones against the locked reference so only the variable changes.` If it keeps happening, check that the reference is still LOCKED with a passing smoke test.

**A child renders with the wrong count, or stretched.** Structural, so it regenerates. A multipack is a different arrangement and never a zoomed copy of one unit. If a size child is involved and you do not have real photos of the larger size, get them before generating. Guessed proportions are how "not as described" returns start.

**A "variation" turns out to be a different product.** Then it needs its own reference and its own smoke test. Say so and Wonka will set it up. This is cheaper to notice now than after a batch of images that all look slightly wrong.

**The speed run stalls because inputs are missing.** That is the gathering, not the factory, and it was never the part that got faster. Stop, gather properly, and restart. The line only runs at its real speed when the shopping list is full before you open the gate.

**`/improvement-loop` says it has nothing to write.** Check that you are in the factory folder and that the Tasting Cards and `status.md` are on disk. The command reads the run, so with no completed round there is nothing to learn from. If the run genuinely taught nothing clean, an honest "nothing new" is the right entry. The log is read automatically, so an invented lesson pollutes every session that follows.

**Your pattern entry and process entry look the same.** Route them properly. Market fact to Part 1, read at every brief. Process change to Part 2, read at every session start. Ask him to sharpen whichever one drifted into the other's job.

**A process lesson is vague.** Push for a number or a named cause. An entry earns its place with evidence from this run. An empty lessons table beats a noisy one.

**A scheduled task will not attach to this folder.** Fine, use the reminder path. The report is identical either way, and the discipline is in running it, not in what triggers it.

**Everything else:** `guides/troubleshooting.md`.

---

## After the bootcamp

The operating rhythm lives at the bottom of `guides/graduation-checklist.md`: the weekly report, one product every week or two through the full line, a monthly review of both books, and the always rule, which is `/improvement-loop` the same day any test result lands. An unrecorded result is a lesson the factory never receives.

Two things to do next, in this order. Finish product two through its own full line, its own Tasting Rounds included. That is the run where this stops being a course you took and becomes a thing you own. And keep walking the floor once a week.

You arrived with a folder and a zip file. You leave with a Creative Director who researched your market, locked your real product, briefed and built a full package, gated its quality, tasted it twice against your live listing, refined it from the tasters' own words, packaged it ready to upload, multiplied it across your family, and who now starts every session a little smarter than the last.

"Same factory, next candy. Onward."

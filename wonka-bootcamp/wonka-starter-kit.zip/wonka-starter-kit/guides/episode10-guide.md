# Episode 10: The Second Batch

The tasters have voted, twice over. This episode you do what almost nobody in e-commerce does: you act on the WHY, immediately. Wonka reads every tasting note on BOTH of Round 1's Tasting Cards, makes targeted edits to the winning main image and to the weakest gallery frames based on the objections, optionally generates a data-born round-2 challenger, and runs Tasting Round 2, both races again, all in the same sitting. One round of testing finds a winner; a second round, built from the first round's notes, is how a good package becomes the best package you can currently make.

## What you will have by the end of this episode

- Both Round 1 verdicts, digested: winners, margins, and the tasting notes from BOTH cards grouped by theme
- **A refined main winner AND refined gallery frames: targeted post-tasting edits, each one answering a specific taster objection**
- A data-born round-2 challenger, generated from what the notes revealed (optional, recommended)
- **Tasting Round 2 run, both races again: the refined winner (plus the challenger, if you built one) vs the incumbent benchmark, and the refined gallery vs the live gallery, the Cards saved and waiting** (on the show we let them sit unopened until the next episode; you are free to peek at yours tonight)

**Time needed:** 60 to 90 minutes, start to finish. No waiting between rounds; that is the point.

## What you will need at hand

- Round 1's two Tasting Cards in `tests/` (from last episode)
- Your OpenAI key working (both the edits and Tasting Round 2 run on it)

---

## Lesson 1: The why is worth more than the winner

The vote tells you which image won. The tasting notes tell you WHY: "I could actually read the label", "the third one looked cheap", "I trust the one showing the certification", "I couldn't tell how big it is". That why is the asset. It transfers to your next product, your A+ content, even your PPC copy. The winner is one image; the why is a pattern.

Most people run a test, note the winner, and ship it. The reasons, the most valuable part of what they paid for, go unread. You are going to mine them the same hour and act on them the same hour. This used to be impossible when a survey took days to fill; now the only thing between Round 1 and Round 2 is this episode.

## Lesson 2: Objection-driven refinement (MODE B)

You have used `/fix` in MODE A: cleaning QA defects the Inspection Room flagged, before anyone voted. This episode you use the SAME room in MODE B: refining a proven winner using the tasters' own notes.

The difference matters. MODE A removes flaws; MODE B chases conversion. If tasters said "I wish I could see the size", the fix adds or strengthens a scale cue. If several said "the text was hard to read", the message gets bigger (by subtraction, as always). If the notes praised something unexpected, that element gets protected and amplified. Every edit traces to a specific objection or note on a Tasting Card; nothing is changed on a hunch.

And MODE B works both cards. The main card's notes refine the winning main; the gallery card's frame-by-frame notes point at the weakest frame or two in your set, and those get the same objection-driven treatment. A gallery race that named your scale shot as the frame tasters skipped is handing you the exact edit that lifts the whole set.

The same routing rules hold: word swaps and removals are surgical edits (cents); layout, casting, and size changes are regenerations with a tighter brief. Originals always kept as `_fixN` siblings.

## Lesson 3: The data-born challenger

Here is where Round 2 earns its name. The notes do not just improve the winner; they often reveal a hypothesis nobody tested. Maybe the tasters kept mentioning the certification seal that only one candidate showed clearly. Maybe the size question recurred across images. That is a NEW creative direction, one that emerged from data rather than brainstorming.

So Round 2 can field two entrants: the **refined winner** (Round 1's champion, improved by its own tasting notes) and a **challenger** built around the strongest untested hypothesis from the notes. The challenger is OPTIONAL, and recommended: if it wins, the notes found something your original concepts missed; if the refined winner holds, you have double-confirmed it. Either way you learn, and the Recipe Book gets richer. Skipping it is legitimate too (the round then simply re-confirms the refined winner against the incumbent); building it is where the new information lives.

## Lesson 4: When the incumbent won Round 1

It happens, and it is a GOOD outcome: you just avoided replacing a working image with a worse one, for a few dollars. The notes now tell you exactly why the incumbent holds, what the panel trusted about it, and what your candidates lacked. Round 2 becomes: refine your best candidate to close that specific gap, add a challenger built on the strongest insight from the notes, and taste again. Wonka will be characteristically honest about it: the candy lost, here is why, here is what changes. Losses teach faster than wins.

And a Round 1 that came back "no clear verdict"? Same play. The objections are still real; fix them, sharpen the contrast between the entrants, and let Round 2 break the tie.

---

## MISSION 1: Mine both Tasting Cards

```
Read both of Round 1's Tasting Cards and give me: the main race winner and margins, the gallery race's set verdict and its weakest frames, and the tasting notes from both cards grouped by theme, strongest theme first.
```

Wonka reads both cards from `tests/` and gives you the distilled why. Make him show his work:

```
Show me the strongest 10 tasting notes verbatim, from either card, and tell me which theme each supports.
```

Reading a hundred tasters' reactions to YOUR images is one of the bootcamp's quiet highlights. Somewhere in there is a sentence that will change how you brief creative forever.

## MISSION 2: Refine the winner and the weakest gallery frames (MODE B)

```
Run /fix in MODE B on the winning main image AND on the gallery race's weakest frames. Read both Tasting Cards' notes, list the targeted edits they justify, tie each edit to the note or objection that justifies it, and give me one cost line before you run anything.
```

Review the fix list. Every item should read like: "Edit: enlarge the label area. Justified by: 4 tasters saying they could not read it." Strike anything that feels like taste smuggled in as data. Give the one go-ahead. When the edits land:

```
Show me the refined winner next to the original winner, and each refined gallery frame next to its original, and tell me which taster objection each edit answers.
```

## MISSION 3: Generate the round-2 challenger (optional, recommended)

The challenger is your call: skipping it keeps Round 2 as a confirmation; building it turns Round 2 into an experiment. Recommended, never required. If you build it:

```
From the Tasting Cards, what is the strongest creative hypothesis we did NOT test in Round 1? Propose a challenger concept built on it.
```

Discuss it; this is a strategy conversation, and your product knowledge matters. When you agree on the concept:

```
/main-image for ONE round-2 challenger only: the concept we just agreed on. State the cost first.
```

Then gate it like everything else:

```
/inspect the challenger, and /fix anything flagged.
```

No image enters the Tasting Room un-inspected, not even a data-born one.

## MISSION 4: Run Tasting Round 2 (both races)

```
/tasting-room for Round 2, both races: the refined winner (plus the challenger, if we built one) with the incumbent still in the lineup as the benchmark, and the refined gallery vs the live gallery again. Same panel demographics as Round 1. Show me the lineups and the cost.
```

Confirm the incumbent is present, the gallery race is set vs set, and the panel matches the persona, give the go-ahead, and the races run in minutes. Run Round 2 now. On the show we let the Cards sit unopened until the next episode; you are free to peek at yours tonight. If you do, read them the same way as Round 1:

```
Walk me through Round 2's Tasting Cards: verdicts, margins, what the notes add to Round 1. Are these clear verdicts? Then log Round 2 in the experiments log and status.md.
```

Same honesty rules as always: a thin margin or a split panel is "no clear verdict", said plainly. And remember what this verdict is: a directional read from AI tasters, strong enough to pick a winner for your package, honest enough to know it is not real-shopper proof.

**Share the WOW:** post one tasting note and the exact edit it produced (before/after crops) to the bootcamp group, plus both rounds' margins. "A taster said X, so we changed Y, and it gained Z points in the same sitting" is the most persuasive sentence in this whole business.

---

## Before the next episode

Nothing must fill and nothing must wait; Round 2's verdict is already on the card. Optional, 10 minutes: read the Episode 11 guide's opening. The next episode packages the twice-tasted winning set into a Golden Ticket and teaches the practical part almost every course skips: exactly how to upload to Amazon and how to run a real on-Amazon A/B test.

## Definition of Done for Episode 10

- [ ] Both of Round 1's Tasting Cards mined: winners, margins, weakest gallery frames, and themed tasting notes reviewed
- [ ] `/fix` MODE B ran on the main winner AND the weakest gallery frames: refinements saved as `_fixN`, every edit tied to a specific tasting note or objection
- [ ] OPTIONAL (recommended): a round-2 challenger concept agreed, generated, inspected, and gate-passed
- [ ] Tasting Round 2 ran, both races: the refined winner (plus the challenger, if built) vs the incumbent benchmark, and the refined gallery vs the live gallery
- [ ] Tasting Round 2 RAN and its Tasting Cards exist in `tests/` (reading the verdicts happens in the next episode; peeking early is allowed)
- [ ] Round 1 (both races) logged in the experiments log; `status.md` updated (Round 2 logs when its Cards are read)

## Common Episode 10 questions

**"The incumbent won Round 1. Is Round 2 still worth running?"**
Especially then. You now know exactly why the incumbent holds, from the panel's own notes. Refine your best candidate to close that named gap, build the challenger on the strongest insight, and taste again. Beating a strong incumbent on the second try, with the notes as the map, is the whole method working.

**"Can I skip the challenger and just re-taste the refined winner?"**
Yes; the challenger is optional and skipping it is a legitimate Round 2. Just know the trade: without it you are spending a round to confirm what Round 1 already suggested. The challenger is where the new information lives; it costs one more generation and turns Round 2 from a confirmation into an experiment. That is why it is recommended, and why it is never required.

**"How different should the challenger be?"**
Different strategy, not different decoration. If the refined winner is a dominant-product shot, the challenger might lead with the certification seal or the material story. Two shades of the same idea split votes without teaching anything.

**"Round 2 disagreed with Round 1. Which do I trust?"**
Read both cards' margins and notes. If Round 2's margin is clear and its notes explain the flip (the refinement or the challenger genuinely changed the story), trust Round 2; it tested better images. If both margins are thin, the honest answer is "no clear verdict": pick by the notes and your judgment, record the reason, and consider the optional real-shopper poll (next episode's Pro Move) before betting big.

## Troubleshooting note

If a tasting run stops midway, run the same `/tasting-room` command again; it resumes where it left off rather than starting over or double-spending. If the Tasting Card reports a low parse rate (many taster responses could not be scored), treat the verdict as weaker and re-run the round. If a MODE B edit garbles text, it was regenerate-territory: `Route this refinement to regenerate with a tighter brief.` If the notes feel thin or generic, tell Wonka; he will tighten the panel's persona conditioning for Round 2. Everything else: `guides/troubleshooting.md`.

Next episode: Publish & Test. The Golden Ticket packages the full winning set, and you learn the practical craft of getting it live: uploading to Amazon and running an A/B in Manage Your Experiments. "Golden Tickets don't print themselves. Almost, though."

# Episode 12: The Variations Room

This episode is the multiplier. Everything you built, the research, the Mold, the brand kit, the twice-tested winning creative, was expensive to build ONCE. This episode you spend it again for almost nothing: the Variations Room adapts your winning listing to your color, size, scent, and bundle variations as one matched, consistent family, and embeds them correctly under your parent listing. One tested listing is a win. A whole tested variation family is a catalog.

## What you will have by the end of this episode

- **Variation imagery: every color/size/bundle of your product shown as a matched, consistent set, adapted from the winning creative**
- A clear picture of how variations embed on Amazon (parent/child, per-child main images, swatches)
- Your winning package extended: the Golden Ticket now covers the whole variation family
- The quality loop run one last time, on the family
- **Product two through the Front Gate and into its brief: the Second Product Speed-Run**

**Time needed:** 60 to 90 minutes, including generation waiting time. If your product truly has no variations, this episode is shorter: you do Missions 4 and 5 and you are done.

## What you will need at hand

- The winning creative from Episode 11 (the Golden Ticket package)
- The same locked Mold and brand kit
- Your real variation SKU list (colors, sizes, scents, flavors, bundles), or a confident "none"
- Your pick for product two (a live ASIN, or a pre-launch with photos); the Speed-Run at the end opens its gate

---

## Lesson 1: Why variations come AFTER the winner

You may have wondered why the Variations Room waited until now. The answer is economics: variations multiply whatever you feed them. Adapt an untested listing to five colors and you have multiplied a guess by five. Adapt a twice-tested winner and every child SKU inherits creative that already beat your live image in two Tasting Rounds.

That is the order of this whole bootcamp in one sentence: build once, test until proven, THEN multiply.

## Lesson 2: The consistency trap

If your blue variant's image is shot at a different angle, on a different background, with different light than your pink variant's image, the buyer feels the mismatch even if they cannot name it, and the listing looks amateur. This is the consistency trap, and almost every variation family on Amazon falls into it, because the photos were taken months apart by different people.

Your Factory is immune, for a reason you already know: the Mold. Every variation image generates against the same locked product reference and the same brand kit, so the family comes out as a matched set: same staging, same light, same quality, only the variable (the color, the size, the bundle contents) changing. Consistency is not a design skill you supply; it is a property of doing the Mold once and reusing it.

One flag: if a variation is a genuinely different physical product (a different machine, not just a different color), it needs its own Mold and smoke test. Wonka will spot this and ask; most variations do not need it.

## Lesson 3: How variations actually embed on Amazon

Worth five minutes so the images you generate land correctly:

- **Parent/child structure.** Your variations live under one parent listing; each child (each color, size) has its OWN image gallery. The parent's gallery is what most browsers see first.
- **Per-child main images.** Each child needs a main image showing ITS variant accurately, same composition, its color/size. A buyer who picks "the 8oz" and sees a 16oz photo is a return waiting to happen.
- **Swatches.** For color/style variations, small swatch images drive the variation picker. Consistent swatches make the picker readable; inconsistent ones make it a mess.
- **Shared secondaries and A+.** Much of your gallery and A+ can serve the whole family; the recipe's variations plan marked what is shared and what is per-child.

`/variations` handles the imagery AND explains this embedding for your specific product, so nothing gets uploaded to the wrong slot.

---

## MISSION 1: The Variations Room

```
/variations
```

Wonka confirms your real SKU list, reads the variations plan from your recipe, adapts the WINNING creative to each variant off the locked Mold, states the cost in one line, and waits for your go-ahead. Give it. Everything saves to `variations/`.

Review the family as a set, not one at a time:

```
Show me all the variation images together. Are they a matched set: same staging and light, only the variable changing?
```

If one is off, name it: `The 16oz shot is lit differently from the others. Regenerate it to match the set.`

**No variations?** Tell Wonka `This product has no variations` and he records it in `status.md`. Skipping a room that does not apply to your product is not skipping the line; it is the line correctly reading your product. Jump to Mission 4.

## MISSION 2: Inspect and fix the family

The quality loop, one last time:

```
/inspect scoped to the variation images: per-image scores plus the family-consistency check.
```

```
/fix
```

Same rules as always: one cost line, one go-ahead, `_fixN` beside originals, re-inspect to green. Then confirm the embedding plan:

```
For each variation image, tell me exactly where it embeds on Amazon: which child's main, which shared secondary, which swatch.
```

## MISSION 3: Extend the Golden Ticket

```
Update the golden ticket package: add the variation family to output/ with the embedding map, and note it in the experiments log.
```

Your ready-to-upload package now covers the entire family: twice-tested main, gate-passed secondaries and A+, and a matched variation set with an embedding map. If you already uploaded the base listing in Episode 11, upload the child galleries and swatches now, following the embedding map.

## MISSION 4: Confirm the family is done

One line, so the finale opens clean:

```
Give me a one-line status: variation family generated and gate-passed (or marked not-applicable), embedding map done, Golden Ticket extended?
```

If it all comes back yes (or a clean "no variations, recorded"), the first product's creative is complete. That is the last piece of tested creative this product needs.

**Share the WOW:** post your full variation family as one strip to the bootcamp group. A matched, consistent variation set is something most listings, including big brands, never achieve.

## MISSION 5: The Second Product Speed-Run

The multiplier is not just variations of THIS product; it is the next product entering the line while the first one heads for the finish. Pick your second product (a live ASIN or a pre-launch with photos) and open the gate for it right now:

```
/meet-my-product
```

Same gate, same shopping list (reviews, competitors, photos), and notice how much faster it goes the second time: the brand kit already exists, and you already know exactly what the gatekeeper will ask. Then, once the research digest is in, start its brief:

```
/creative-brief
```

You do not need to finish the brief this sitting; getting product two THROUGH the gate and INTO its brief is the mission. Two products on the line at once is what a factory looks like.

---

## Before the next episode (10 minutes)

The next episode is the finale: the two learning loops that make product two better than product one, the weekly heartbeat, and graduation. Leave product two mid-brief; that is exactly where it should be. When the finale opens with `/factory-report`, you will see what an owner sees: product one packaged and heading live, product two mid-brief, one line moving. Also jot down the next 1 to 3 products AFTER product two; Wonka will use that list to show you how much carries over.

## Definition of Done for Episode 12

- [ ] `/variations` ran (or variations consciously marked not-applicable in `status.md`)
- [ ] The variation family is a matched set: same staging, only the variable changing
- [ ] `/inspect` and `/fix` ran on the family: gate-passed, `_fixN` beside originals
- [ ] You know where each variation image embeds (child mains, shared assets, swatches)
- [ ] Golden Ticket package extended with the variation family and embedding map
- [ ] Product two through the Front Gate with `/meet-my-product`, and `/creative-brief` started on it
- [ ] `status.md` updated (both products)

## Troubleshooting note

If variation images look inconsistent (different light, angle, or staging across the set), the Mold was not held for all of them; tell Wonka `These variations aren't a matched set. Re-generate them against the locked Mold so only the variable changes.` If a variation is a genuinely different physical product, it needs its own Mold and smoke test; say so and Wonka will set it up. If you are unsure how your parent/child structure maps to the images, ask `Walk me through my variation family's structure on Amazon and where each image goes.` Everything else: `guides/troubleshooting.md`.

Next episode: the finale. The Factory learns twice, you set its weekly heartbeat, and you graduate. "Same factory, next candy. But first, let's teach it what it just learned."

# Graduation Checklist

Every item below is verifiable: a file that exists, a Tasting Round that ran, a habit that is set. Go top to bottom. Ask Wonka to help you verify any of it: `Run me through the graduation checklist and verify each file exists.`

The list comes in two parts. The **Guarantee checklist** is the refund condition, in the exact words of the guarantee: "Complete all 13 episodes and the graduation checklist, and you have a full, tested creative package ready to upload by the end of the bootcamp, or a full refund." The **Factory Owner extras** are what turn a completed bootcamp into a running factory; recommended, not required for the guarantee.

## Guarantee checklist (the refund condition)

**Factory Keys and wiring (Episode 1 to Episode 2):**

- [ ] Claude Pro (or Max) active; kit folder opens in the Code tab
- [ ] Wonka answers "Who are you?" in character
- [ ] Genrupt MCP connected and verified by Wonka with a test call (or the fallback path consciously chosen and recorded)
- [ ] OpenAI API key created, org verification done, key saved per `guides/mcp-setup-guide.md` (it powers the Fixing Room AND the Tasting Room)
- [ ] Pilot product chosen; real photos taken (all angles + hand-for-scale + label close-ups)
- [ ] First Candy printed (`output/first-candy.png`), proving the OpenAI pipeline end to end (or consciously declined)

**RESEARCH (Episode 3):**

- [ ] `/meet-my-product` ran: `factory/Products/[your-product]/` exists with all 8 subfolders
- [ ] `status.md` exists with the 5-station table and your owner intel recorded
- [ ] Niche phrase confirmed word for word

- [ ] Top positive + critical reviews saved in `research/`
- [ ] 3 to 5 same-niche competitors confirmed, their galleries (screenshots or URLs) in `research/`
- [ ] Research digest (the derived niche picture) + buyer persona + funnel diagnosis exist in `research/`
- [ ] Selling-points checklist exists; you corrected or confirmed it
- [ ] `research/competitors.md` exists with table stakes, strong frames, and whitespace

**REFERENCE ROOM and BRIEF (Episode 4 to Episode 5):**

- [ ] Product photos in `reference/`; Mold locked from your real photos (or explicit recorded fallback)
- [ ] Smoke test image generated, checked by your own eyes, approved BEFORE any batch
- [ ] `factory/Brand/brand-kit.md` filled: colors with hex, typography direction, tone, approved claims table
- [ ] `brief/creative-brief.md` exists covering the FULL package (main + secondaries + A+ + variations), one job and one message each, every selling point mapped or skipped in writing, zero placeholders
- [ ] Brief approved by you; `status.md` shows RESEARCH and BRIEF done

**The three generation loops (Episode 6 to Episode 8):**

- [ ] Episode 6: 4 main image concepts in `images/`, product-only, no people, no overlay text; inspected, fixed, gate-passed
- [ ] Episode 7: full secondary set in `images/`; set-level checks green (no message overlap, no repeated face, emotional frame present, selling points covered)
- [ ] Episode 8: A+ modules in `aplus/`; one dominant message each, real claims only; inspected and fixed
- [ ] Scorecards exist in `scorecards/` for all three asset classes, with the six-dimension scores, the separate compliance pass/fail gate, specific reasons, and rankings
- [ ] You saw at least one candidate at 160px squint size
- [ ] All fixes saved as `_fixN` files with originals intact; fixed assets re-inspected

**PROVE: two Tasting Rounds, two races each, and the Golden Ticket (Episode 9 to Episode 11):**

- [ ] You picked 2 main candidates (reason recorded if you overrode the ranking)
- [ ] Tasting Round 1 ran via `/tasting-room`, both races: the MAIN race with the live incumbent in the lineup, and the GALLERY race (your new secondary set vs the live Amazon gallery, set-level verdict + frame-by-frame); both Tasting Cards saved in `tests/`
- [ ] `/fix` MODE B ran: the main winner AND the weakest gallery frames refined from the tasters' notes, each edit tied to a note or objection, saved as `_fixN`
- [ ] Tasting Round 2 ran, both races again (the refined winner vs the incumbent benchmark, plus the OPTIONAL recommended data-born challenger if you built one, and the refined gallery vs the live gallery); its Tasting Cards saved and read
- [ ] `tests/upload-pack.md` exists: a full, tested creative package ready to upload, in `output/`; the experiments log has the entry
- [ ] A go-live path chosen (direct upload or Manage Your Experiments A/B), with the exact steps and the metric to watch recorded. Choosing the path is the requirement; actually uploading is your call and your timing

**The Variations Room (Episode 12):**

- [ ] `/variations` ran: the variation family is a matched set with an embedding map (or variations consciously marked not-applicable in `status.md`)
- [ ] The Golden Ticket package extended with the variation family

## Factory Owner extras (recommended, not required for the guarantee)

These are the finale (Episode 13) plus the post-bootcamp habits that turn a finished run into a running factory.

- [ ] Amazon A/B launched in Manage Your Experiments (or direct upload done, or consciously scheduled)
- [ ] Weekly `/factory-report` habit set: a scheduled task if your Claude setup supports one on this folder, or a 2-minute weekly calendar reminder to run the command yourself
- [ ] At least one factory report exists in `factory/Factory Log/`
- [ ] Recipe Book has its first real pattern entries from both Tasting Rounds, main race and gallery race (`factory/Recipe Book/`), written by `/improvement-loop`, and you have read them once as a review
- [ ] Wonka's Notebook has its first process entries (`factory/Wonka's Notebook/`), written by `/improvement-loop`, and you read his answer to "what will you do differently on product two?"
- [ ] Product two's run continued past the Episode 12 Speed-Run (brief approved, or the next station dated)
- [ ] All 5 stations in `status.md`: done

## All checked?

Guarantee checklist done by the end of the bootcamp: you are a graduate with a full, tested creative package ready to upload. Extras done too: you did not finish a course; you commissioned a factory.

---

# Your Factory After the Bootcamp

The operating rhythm that keeps it compounding:

**Weekly (one command + 10 minutes of you):**
- `/factory-report` runs weekly, by scheduled task or by your calendar reminder. Read it. Unblock whatever it says is blocked.
- If an Amazon A/B is running, glance at Manage Your Experiments. No decisions before the test matures (8 to 10 weeks); peeking is fine, flinching is not.

**Every week or two (one production run):**
- Put the next product through the full line, the same episode sequence you just learned. One product every week or two is a sustainable pace that most brands' entire creative calendars cannot match.
- Never skip stations to go faster. The line IS the speed; rework is what is slow.

**Monthly (30 minutes):**
- Review `factory/Recipe Book/`: which patterns are hardening into USE, which went MIXED, what should be pruned.
- Review `factory/Wonka's Notebook/`: the process lessons Wonka has recorded, so you know how he is getting better at his own job.
- Review the experiments log: any matured A/B results to record? Run `/improvement-loop` on each one.
- Ask Wonka: `Read the Recipe Book and tell me the three strongest patterns we've proven so far.` That answer is your creative strategy, written by your own customers.

**When a test result lands, always:**
- `/improvement-loop` the same day: what converted in your market (the Recipe Book) and how Wonka can work better next time (his Notebook), both from one command. An unrecorded result is a lesson the Factory never receives.

"Same factory, next candy. Bring a product worth inventing for."

# Graduation Checklist

This is the canonical checklist. If any other page in this kit, the portal, or an email lists
graduation items differently, this file wins.

Every item below is verifiable: a file that exists, a Tasting Round that ran, a habit that is set.
Go top to bottom. Ask Wonka to help you verify any of it:

```
Run me through the graduation checklist and verify each file exists.
```

The list comes in two parts. The **Guarantee checklist** is the refund condition, in the exact words
of the guarantee:

> **"Complete all 10 days and the graduation checklist, and you have a full, tested creative package ready to upload by the end of the bootcamp, or a full refund."**

The **Factory Owner extras** are what turn a completed bootcamp into a running factory. Recommended,
not required for the guarantee.

Each day's guide ends with its own Definition of Done. Those track the day. This list tracks the
package: it is the cross run check that everything the guarantee promises actually exists on disk.

**Four things people expect to find here and will not.** All four are deliberate:

- **Uploading is not required.** The promise is a package that is ready to upload. When it goes live
  is your call and your timing.
- **Posting in the group is not required.** Worth doing, never a condition, and not every ticket
  includes a group.
- **The Round 2 data born challenger is optional.** Recommended, never required.
- **Recipe Book and Notebook entries are extras.** They sit in the Factory Owner section on purpose.
  They make your next product better. They are not a refund condition.

The guarantee is a process promise, not a sales promise. Results vary by product and niche.

---

## Guarantee checklist (the refund condition)

### Day 1: The Front Gate

- [ ] Claude Pro (or Max) active; the kit folder opens in the Code tab
- [ ] Wonka answers "Who are you?" in character, and refuses when you push him to skip research
- [ ] Genrupt connected and verified by Wonka with a live read only call (or the fallback path
      consciously chosen and recorded)
- [ ] OpenAI API key created, funded, organization verification complete, key saved per
      `guides/mcp-setup-guide.md` (one key, two rooms: the Fixing Room AND the Tasting Room)
- [ ] Pilot product chosen; real photos taken (all angles, hand for scale, label close ups), or the
      listing gallery fallback consciously chosen and recorded
- [ ] First Candy printed at `output/first-candy.png`, proving the OpenAI pipeline end to end (or
      consciously declined)
- [ ] Inputs folder packed: reviews, competitors, photos, your owner intel, and your niche phrase
      decided word for word

### Day 2: Wonka, Meet My Product

- [ ] `/meet-my-product` ran: `factory/Products/[your-product]/` exists with all 8 subfolders
- [ ] The listing title was read back to you and confirmed, so the ASIN in your folder is the right
      product and not just the right format
- [ ] `status.md` exists with the station tracker and your owner intel recorded verbatim (or
      explicitly marked as none given)
- [ ] All five research files exist with real content: `insights.md`, `reviews.md`, `persona.md`,
      `competitors.md`, `selling-points.md`
- [ ] Reviews were collected while logged in, critical ones included (or the thin basket recorded as
      a waiver, in writing)
- [ ] 3 to 5 competitors confirmed as genuinely your niche, and the check is stated in
      `competitors.md`, with table stakes, their strong frames, and the whitespace
- [ ] Buyer persona and funnel diagnosis exist, each honestly labelled where it is estimated
- [ ] You read the selling points checklist and corrected or confirmed it
- [ ] You sent at least one correction and Wonka recorded it
- [ ] RESEARCH shows `done` in `status.md`

### Day 3: The Reference Room

- [ ] Your product photos are in `reference/`; the Mold is built from them (or from an explicit,
      recorded fallback)
- [ ] `reference-sheet.md` carries the line `Reference status: LOCKED`, and the spec is accurate:
      size, materials, parts, label text
- [ ] Smoke test image generated, checked with your own eyes, and PASSED before any batch
- [ ] `factory/Brand/brand-kit.md` filled: colors with hex, typography direction, tone, and the
      approved claims table, which you read yourself
- [ ] `status.md` records the passed smoke test and the brand kit

### Day 4: The Creative Brief

- [ ] `brief/creative-brief.md` exists covering the FULL package: main, secondaries, A+, variations
- [ ] Zero placeholders: every brand field filled from the brand kit, every product reference from
      the locked Mold
- [ ] Four main image variants, product only, each with a stated hypothesis, and the four ranked
- [ ] Every asset has one job and one dominant message, and no two assets share a message
- [ ] Every selling point mapped to an asset, or consciously skipped in writing with a real reason
- [ ] Casting specs present for every people bearing asset, each a distinct person
- [ ] Compliance decided in the brief, and no headline promising something your reviews do not
      support
- [ ] Variations planned from your real SKU list, or stated as none, in writing
- [ ] You pushed back on at least one slot and approved the result. `status.md` shows BRIEF done

### Day 5: The Main Image Room

- [ ] The line was confirmed ready (brief, brand kit, locked reference, passed smoke test) before any
      spending
- [ ] `/main-image` ran with your cost go ahead: four concepts in `images/`, batch log written
- [ ] Every concept is product only: no people, no hands, no overlay text or graphics
- [ ] `/inspect` ran: scorecard in `scorecards/` with the six dimension scores, the separate
      compliance pass or fail gate, specific reasons, and a ranking with its tie break
- [ ] `scorecards/squint/` holds a 160 pixel copy of every inspected image, and you personally opened
      one and looked at it
- [ ] `/fix` ran on everything flagged: each item routed, fixes saved as `_fixN`, regenerations saved
      as new files, every original intact, everything re inspected
- [ ] All four candidates gate passed. No winner picked yet, nothing uploaded

### Day 6: The Secondary Images Room

- [ ] `/secondary-images` ran with your cost approval: the full set is in `images/`, each frame
      filling its brief slot with one dominant message
- [ ] Your four main candidates and their scorecard are untouched
- [ ] A NEW secondary scorecard sits in `scorecards/` beside the main one, and `scorecards/squint/`
      holds a 160 pixel copy of every frame
- [ ] All four set level checks green: no message overlap, no repeated face, one emotional frame
      present, selling points covered
- [ ] Anything not covered is recorded as a conscious skip, in writing, with a reason
- [ ] `/fix` ran on everything flagged, originals kept beside the fixes, whole set re inspected clean

### Day 7: The A+ Room

- [ ] `/aplus` ran with your cost go ahead: modules exist in `aplus/`, plus `aplus/aplus-plan.md`
- [ ] Every module has one job and one dominant message, and no two share a headline
- [ ] If you built a comparison chart, every row is true, provable, and about your product. No named
      brands, no prices
- [ ] `/inspect` ran scoped to the A+, and you read the page level section
- [ ] `/fix` ran on the flagged modules: fixes saved as `_fixN`, originals intact, re inspected to
      green
- [ ] You viewed the complete page top to bottom
- [ ] Your live main image and live gallery are downloaded into `incumbent/`, and `tests/` is still
      empty
- [ ] `status.md` shows the full package built and gate passed, testing next

### Day 8: The Tasting Room (Round 1)

- [ ] You picked 2 main challengers, with the reason recorded in `status.md` if you overrode the
      ranking
- [ ] `/tasting-room` ran with your cost go ahead: Tasting Round 1 complete, BOTH races
- [ ] The live incumbent was in the main lineup, and the live gallery was the benchmark in the
      gallery race (set level verdict plus frame by frame)
- [ ] Two Tasting Cards exist under `tests/`, each with `tasting-card.html`, `tasting-card.md`,
      `results.json` and `config.json`
- [ ] You read each verdict line, its stability tier, and the versus incumbent result, and each was
      called honestly: Clear lead, Lean, or Toss up, in those words
- [ ] Both races logged in `factory/Recipe Book/experiments.md`, `status.md` updated

### Day 9: The Second Batch and Ship It

- [ ] Both Round 1 Tasting Cards mined: winners, margins, stability tiers, the weakest gallery frame,
      and the themed notes with counts
- [ ] An instruction list written BEFORE any image changed, every instruction tied to a note and a
      count, and any refused fix recorded with its reason
- [ ] `/fix` MODE B ran on the main winner AND the weakest gallery frame: refinements saved beside
      untouched originals, each change tied to a specific note, both re inspected and passing
- [ ] OPTIONAL and recommended: a data born challenger agreed, generated, inspected and gate passed,
      carrying its provenance line
- [ ] Tasting Round 2 ran, BOTH races again, with the incumbent in the main grid and the comparison
      wired back to Round 1
- [ ] Round 2 verdicts read with their stability tiers, the Round Comparison deltas read, and the
      round logged in the experiments log
- [ ] `/ready-to-upload` ran and the gate passed: `tests/upload-pack.md` exists and your complete
      package is in `output/`, with variations marked pending
- [ ] Your A+ cross checked against the winning angle, and realigned if it was arguing the losing
      case
- [ ] A go live path chosen (direct upload, or an A/B in Manage Your Experiments), with the exact
      steps and the metric to watch recorded. **Choosing the path is the requirement. Actually
      uploading is your call and your timing**

### Day 10: Variations and The Improvement Loop

Only the variations half of this day is a refund condition. The improvement loop, the second product
speed run and the weekly rhythm are Factory Owner extras, listed in the next section.

- [ ] `/variations` ran on your REAL children, or variations recorded as `n/a` in `status.md` with
      the reason. Nothing invented
- [ ] If you changed the plan from single SKU, the brief was amended with the date and the reason
      BEFORE generating
- [ ] The family is a matched set: same staging, same composition, only the variable changing, gate
      passed through `/inspect` and `/fix`
- [ ] You know exactly where each variation image embeds: per child mains, shared assets, swatches
- [ ] `tests/upload-pack.md` extended with the family and the embedding map, and the Variations line
      no longer reads pending

---

## Factory Owner extras (recommended, not required for the guarantee)

These are Day 10's closing missions plus the habits that turn a finished run into a running factory.

- [ ] Amazon A/B launched in Manage Your Experiments, or the direct upload done, or either one
      consciously scheduled
- [ ] Recipe Book has its first real pattern entries from both Tasting Rounds, main race and gallery
      race (`factory/Recipe Book/`), written by `/improvement-loop`, and you have read them once
- [ ] Wonka's Notebook has its first process entries (`factory/Wonka's Notebook/`), written by
      `/improvement-loop`, and you read his answer to "what will you do differently on product two?"
- [ ] Product two continued past the Day 10 speed run: its research approved, or its next station
      dated
- [ ] Weekly `/factory-report` habit set: a scheduled task if your Claude setup supports one on this
      folder, or a recurring reminder to run the command yourself
- [ ] At least one factory report exists in `factory/Factory Log/`
- [ ] All 5 stations in `status.md`: resolved

## All checked?

Guarantee checklist done by the end of the bootcamp: you are a graduate with a full, tested creative
package ready to upload. Extras done too: you did not finish a course, you commissioned a factory.

---

# Your Factory After the Bootcamp

The operating rhythm that keeps it compounding:

**Weekly (one command and 10 minutes of you):**
- `/factory-report` runs weekly, by scheduled task or by your own reminder. Read it. Unblock whatever
  it says is blocked.
- If an Amazon A/B is running, glance at Manage Your Experiments. No decisions before the test
  matures (8 to 10 weeks). Peeking is fine, flinching is not.

**Every week or two (one production run):**
- Put the next product through the full line, the same ten day sequence you just learned. One product
  every week or two is a sustainable pace that most brands' entire creative calendars cannot match.
- Never skip stations to go faster. The line IS the speed. Rework is what is slow.

**Monthly (30 minutes):**
- Review `factory/Recipe Book/`: which patterns are hardening into USE, which went MIXED, what should
  be pruned.
- Review `factory/Wonka's Notebook/`: the process lessons Wonka has recorded, so you know how he is
  getting better at his own job.
- Review the experiments log: any matured A/B results to record? Run `/improvement-loop` on each one.
- Ask Wonka: `Read the Recipe Book and tell me the three strongest patterns we've proven so far.`
  That answer is your creative strategy, written by your own customers.

**When a test result lands, always:**
- `/improvement-loop` the same day: what converted in your market (the Recipe Book) and how Wonka can
  work better next time (his Notebook), both from one command. An unrecorded result is a lesson the
  Factory never receives.

"Same factory, next candy. Bring a product worth inventing for."

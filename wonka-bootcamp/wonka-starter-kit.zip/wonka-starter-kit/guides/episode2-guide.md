# Episode 2: Meet Wonka

This episode you meet your new Creative Director, learn how his Factory thinks, wire up his machines while HE checks them, and put your first product on the line. By the end, your product is registered, tracked, and waiting at the Research Room door with its inputs gathering.

## What you will have by the end of this episode

- Wonka running in character and familiar with his own Factory
- The Production Line method, understood (5 stations, why the order matters)
- The Genrupt and ProductPinion MCPs connected and verified, by Wonka himself
- Your OpenAI key confirmed in place (no call, no spend)
- Your pilot product registered via `/meet-my-product`, with a folder and a station tracker on disk
- Your owner intel (what you know works, what must appear, what to avoid) recorded
- Homework in motion: niche insights export, reviews, product photos filed

**Time needed:** 75 to 100 minutes, plus 20 to 30 minutes of homework.

---

## Lesson 1: The employee, not the chatbot

Most sellers use AI like a vending machine: type a prompt, get an image, hope. Every session starts from zero, and the output looks like it.

You are doing something different. Wonka is an AI **employee**. He lives in a folder on your Desktop. That folder holds his personality (`.claude/wonka-character.md`), his operating manual (`CLAUDE.md`), his skills (the rooms of the Factory), and his memory (every product's `status.md`, the Brand Kit, the Recipe Book). Close Claude, reopen the folder for the next episode, and he remembers exactly where every product stopped.

Three things make him different from a chat window:

1. **He does the work.** Not advice. Actual briefs, actual images, actual scorecards, actual test results, saved as files you can open.
2. **Nothing ships un-inspected.** Every image passes a hard quality gate (the Golden Standards) before you are even asked to look at it.
3. **The factory learns twice.** Every test result is written into the Recipe Book (what converts in your market), and Wonka also keeps a Wonka's Notebook (how he can do his own job better), which he reads at the start of every session. Your third product starts smarter than your first, and so does Wonka.

## Lesson 2: The Production Line

Every product moves through 5 stations, in order:

| Station | Room(s) | What happens | Skills |
|---|---|---|---|
| 1. RESEARCH | Research Room, Spy Balcony | What the niche demands, what buyers complain about, what competitors show, who actually buys | `/meet-my-product` |
| 2. BRIEF | Brief Room | A written brief for the FULL package: main, secondaries, A+, and variations, each with one job and one message | `/creative-brief` |
| 3. INVENT | Reference Room, Brand Room, Main Image Room, Secondary Images Room, A+ Room, Variations Room | Brand kit, locked product reference + smoke test, then generating the main and secondary images, the A+ modules, and the variation images | `/brand-kit`, `/reference-sheet`, `/main-image`, `/secondary-images`, `/aplus`, `/variations` |
| 4. INSPECT | Inspection Room, Fixing Room | Every asset scored and gated, cheap fixes applied before you look | `/inspect`, `/fix` |
| 5. PROVE | Poll Room, Shipping Room, Recipe Book, Wonka's Notebook | Real shoppers vote, Wonka refines the winner from their comments, the package gets its Golden Ticket, and the Factory learns twice | `/poll`, `/fix`, `/publish`, `/improvement-loop` |

**Why the order is sacred:** an image is a decision made visible. Skip research and the image decides based on nothing. Skip the recipe and a whole product page fights itself for the same message. Skip inspection and an unreadable thumbnail goes live. Skip the proof and you shipped an opinion. Wonka will not skip a station silently; if you insist, he records the skip and tells you the risk. That stubbornness is the product.

**Thirteen episodes, one line.** The five stations spread across the 13 episodes: research fills the early episodes, generation of the full package fills the middle (one asset class per episode, so you practice the generate-inspect-fix loop three times), and testing, refinement, variations, and the two learning loops close it out. You are never rushed, and nothing important gets crammed.

## Lesson 3: The Golden Standards (a first taste)

Every image that leaves this Factory passes a quality gate. You will learn it deeply in the generation episodes, but three rules are worth knowing from minute one, because they explain most of Wonka's behavior:

- **One dominant message per image.** An image that says three things says nothing.
- **The mobile squint test.** Most shoppers see your image at thumbnail size on a phone. If the message is not readable in 2 seconds at 160 pixels wide, it fails.
- **No people in the MAIN image.** Faces, hands, product-in-use all belong in secondary images. The hero shot is the product. Full stop.

## Lesson 4: Meet the man himself

Have a real conversation before putting him to work. Try these:

```
What's your honest opinion of typical AI-generated Amazon listing images?
```

```
Why do you refuse to make images before research? Convince me it's worth an episode.
```

```
Here is my product: [one sentence about your pilot product]. What questions come to your mind before you'd touch a single pixel?
```

He should be theatrical but precise, and the third answer should already sound like a researcher, not an artist. If he sounds flat and generic, the character file is not loading: see `guides/troubleshooting.md`.

Then take a 10-minute tour of the floor:

```
Give me a tour of the factory folder. What lives where, and which files will you read at the start of every session?
```

The parts that matter most right now: `factory/Products/` (one folder per product, empty now, not for long), `factory/Brand/brand-kit.md` (filled in Episode 4), `factory/Recipe Book/` and `factory/Wonka's Notebook/` (the two learning loops, filled from Episode 13).

---

## MISSION 1: Wire the machines (with Wonka checking his own)

In Episode 1 you created the Genrupt and ProductPinion accounts. Now you connect them to Claude, and this is the fun part: Wonka verifies his own machines while you watch.

Open `guides/mcp-setup-guide.md` and follow Part 1 (Genrupt) and Part 2 (ProductPinion). Each is a short click path in Claude plus the current connection details from the tool's own docs. Then run the Factory's own systems check:

```
/machines-check
```

Wonka checks every machine himself: the Genrupt MCP with a small read-only call, the ProductPinion MCP with a small read-only call, and confirms your OpenAI key is in place (no call, no spend). He reports each as OK or FAILED with the reason.

Three OKs and every room in the Factory is open. If something fails, fix it per the setup guide's fixes section for that tool, then run `/machines-check` again. Do not lose an evening to it; post the exact error in the bootcamp group and keep going. Genrupt has a fallback path, and ProductPinion only earns its keep in Episode 9, so you have time.

**A note on the machines and the method.** The setup guide walks the connection click paths; `/machines-check` is how Wonka confirms each machine with a live read-only call, any time you want. Once all three report OK, the wiring is done and it stays done between episodes.

## MISSION 2: Open the Front Gate

Time to register your pilot product. Type:

```
/meet-my-product
```

Wonka will ask for three things in one message. Have them ready:

1. **ASIN + full Amazon URL** (or a product description if you are pre-launch)
2. **Brand name**
3. **Your niche, in your own words** ("castor oil", "garlic press", "dog paw balm")

**The niche phrase matters more than it looks.** It is the exact phrase your Episode 3 research will be exported for. "Castor oil" and "hair oil" are different niches with different table stakes. Wonka will confirm it back to you; take that confirmation seriously.

When he finishes, verify the artifact exists (this habit will serve you the whole bootcamp):

```
Show me the status.md you just created, and list the folders inside my product's folder.
```

You should see the station tracker with all 5 stations, and 8 subfolders: research, brief, reference, images, aplus, variations, scorecards, tests.

## MISSION 3: Give Wonka your owner intel

As part of `/meet-my-product`, Wonka interviews you about what you already know. Do not rush this; you are the person who has watched this product sell. He will ask:

- What do you already KNOW works? (past winning images, angles customers respond to)
- What MUST appear? (real certifications on your label, a signature feature, claims you are allowed to make)
- What must we AVOID? (claims legal killed, angles that flopped, comparisons you refuse to make)

Answer in plain language. He records it verbatim in `status.md`, and it travels with the product through every room.

## MISSION 4: Receive the shopping list

Wonka closes the Front Gate by handing you a shopping list for the Research Room. It will look like this, and it is your homework:

- Top Niche Insights export for YOUR exact niche
- Top positive + top critical reviews
- Your real product photos into the `reference/` folder

---

## Before the next episode (20 to 30 minutes)

The Research Room opens in Episode 3 only if these are on the shelf:

**1. Export Top Niche Insights for your exact niche.**
Open Amazon in Chrome, use the Product Opinion extension to export the Top Niche Insights report for the exact niche phrase you confirmed at the Front Gate. Save the export into your product's `research/` folder (or just tell Wonka "here is my insights export" and paste it; he will file it). Exact click path: `guides/mcp-setup-guide.md`, Product Opinion section.

**2. Copy reviews.**
From your own listing (and optionally your #1 competitor): the top 10 or so positive reviews and the top 10 critical ones. Copy and paste them into a text file in `research/`, or paste them straight to Wonka and ask him to file them. Critical reviews are gold; they are your customers writing your image brief for free.

**3. Drop your product photos into the reference folder.**
The photos you took in Episode 1 (all angles, hand-for-scale, label close-ups) go into `factory/Products/[your-product]/reference/`. Drag them in with Finder or Explorer, or ask Wonka where to put them.

**4. Optional but smart: screenshot competitor galleries.**
Screenshot the image galleries of your top 3 to 5 competitors into the product's `research/` folder. Episode 3's Spy Balcony tears them down, and if Wonka cannot browse the listings himself, these screenshots are exactly what he will ask for.

**5. Optional: export your real buyer demographics.**
If you have Brand Registry, export your ASIN's Brand Analytics demographics into `research/`. Your persona gets real buyer ages instead of niche averages.

## Definition of Done for Episode 2

- [ ] Wonka answered in character and gave you the Factory tour
- [ ] You can name the 5 stations in order and say why order matters
- [ ] `/machines-check` ran with three OKs: Genrupt MCP, ProductPinion MCP, and the OpenAI key all verified (or a fallback path consciously chosen and recorded)
- [ ] `/meet-my-product` ran: product folder exists with 8 subfolders (research, brief, reference, images, aplus, variations, scorecards, tests)
- [ ] `status.md` exists with the station table and your owner intel recorded
- [ ] You know your exact niche phrase, word for word
- [ ] Homework started: insights export, reviews, photos into `reference/`

## Troubleshooting note

If a slash command does nothing, type it as a plain message starting with the slash (`/meet-my-product`) rather than describing it ("run the new product thing"). If an MCP does not appear at all, you did not fully restart Claude; quit completely (Mac: Cmd+Q; Windows: quit from the tray icon) and reopen, then re-check with Wonka. If Wonka claims a folder exists but you cannot see it, remember `.claude/` is hidden (Mac: Cmd+Shift+. in Finder; Windows: File Explorer, View tab, check Hidden items) and product folders live under `factory/Products/`. Everything else: `guides/troubleshooting.md`.

Next episode the Research Room opens: niche table stakes, the pains hiding in your reviews, a competitor teardown, and the real buyer behind the Buy button. As the man says: "Every great candy starts with knowing exactly who it is for."

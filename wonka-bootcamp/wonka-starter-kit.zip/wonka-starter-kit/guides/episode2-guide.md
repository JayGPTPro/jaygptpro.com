# Episode 2: Meet Wonka

This episode you meet your new Creative Director, learn how his Factory thinks, and wire up his machines while HE checks them. The product itself stays outside the gate until the next episode; today's job is a live factory and full hands. By the end, both machines are warm, your First Candy is printed, and you know exactly what the gatekeeper will demand when your product walks in.

## What you will have by the end of this episode

- Wonka running in character and familiar with his own Factory
- The Production Line method, understood (5 stations, why the order matters)
- The Genrupt MCP connected and verified, by Wonka himself, fuel gauge (credit balance) read
- Your OpenAI key proven end to end with the First Candy: your factory's first print, a welcome card that costs a few cents and confirms the one-time org verification took; the key powers the Fixing Room AND the Tasting Room
- `/factory-report` met for the first time: the "what's the status?" command you will use all bootcamp
- The Front Gate shopping list, received in advance from Wonka himself, so you arrive at Episode 3 with everything he will demand
- Homework in motion: reviews file, competitor screenshots, product photos ready

**Time needed:** 60 to 80 minutes, plus 20 to 30 minutes of homework.

---

## Lesson 1: The employee, not the chatbot

Most sellers use AI like a vending machine: type a prompt, get an image, hope. Every session starts from zero, and the output looks like it.

You are doing something different. Wonka is an AI **employee**. He lives in a folder on your Desktop. That folder holds his personality (`.claude/wonka-character.md`), his operating manual (`CLAUDE.md`), his skills (the rooms of the Factory), and his memory (every product's `status.md`, the Brand Kit, the Recipe Book). Close Claude, reopen the folder for the next episode, and he remembers exactly where every product stopped.

Three things make him different from a chat window:

1. **He does the work.** Not advice. Actual briefs, actual images, actual scorecards, actual test results, saved as files you can open.
2. **Nothing ships un-inspected.** Every image passes a hard quality gate (the Golden Standards) before you are even asked to look at it.
3. **The factory learns twice.** Every test result is written into the Recipe Book (what converts in your market), and Wonka also keeps a Wonka's Notebook (how he can do his own job better), which he reads at the start of every session. Your third product starts smarter than your first, and so does Wonka.

## Lesson 2: The Production Line

Every product moves through 5 stations, in order:

| Station | Room(s) | What happens | Skills |
|---|---|---|---|
| 1. RESEARCH | Front Gate, Research Room | What the niche demands, what buyers complain about, what competitors show, who actually buys | `/meet-my-product` |
| 2. BRIEF | Brief Room | A written brief for the FULL package: main, secondaries, A+, and variations, each with one job and one message | `/creative-brief` |
| 3. INVENT | Reference Room, Brand Room, Main Image Room, Secondary Images Room, A+ Room, Variations Room | Brand kit, locked product reference + smoke test, then generating the main and secondary images, the A+ modules, and the variation images | `/brand-kit`, `/reference-sheet`, `/main-image`, `/secondary-images`, `/aplus`, `/variations` |
| 4. INSPECT | Inspection Room, Fixing Room | Every asset scored and gated, cheap fixes applied before you look | `/inspect`, `/fix` |
| 5. PROVE | Tasting Room, Shipping Room, Recipe Book, Wonka's Notebook | A panel of ~100 AI tasters, matched to your real buyer, votes instantly; Wonka refines the winner from their tasting notes, runs Round 2 the same sitting, the package gets its Golden Ticket, and the Factory learns twice | `/tasting-room`, `/fix`, `/ready-to-upload`, `/improvement-loop` |

**Why the order is sacred:** an image is a decision made visible. Skip research and the image decides based on nothing. Skip the recipe and a whole product page fights itself for the same message. Skip inspection and an unreadable thumbnail goes live. Skip the proof and you shipped an opinion. Wonka will not skip a station silently; if you insist, he records the skip and tells you the risk. That stubbornness is the product.

**Thirteen episodes, one line.** The five stations spread across the 13 episodes: research fills the early episodes, generation of the full package fills the middle (one asset class per episode, so you practice the generate-inspect-fix loop three times), and testing, refinement, variations, and the two learning loops close it out. You are never rushed, and nothing important gets crammed.

## Lesson 3: The Golden Standards (a first taste)

Every image that leaves this Factory passes a quality gate. You will learn it deeply in the generation episodes, but three rules are worth knowing from minute one, because they explain most of Wonka's behavior:

- **One dominant message per image.** An image that says three things says nothing.
- **The mobile squint test.** Most shoppers see your image at thumbnail size on a phone. If the message is not readable in 2 seconds at 160 pixels wide, it fails.
- **No people in the MAIN image.** Faces, hands, product-in-use all belong in secondary images. The hero shot is the product. Full stop.

## Lesson 4: Meet the man himself

Have a real conversation before putting him to work. Try these:

```
What's your honest opinion of typical AI-generated Amazon listing images?
```

```
Why do you refuse to make images before research? Convince me it's worth an episode.
```

```
Here is my product: [one sentence about your pilot product]. What questions come to your mind before you'd touch a single pixel?
```

He should be theatrical but precise, and the third answer should already sound like a researcher, not an artist. If he sounds flat and generic, the character file is not loading: see `guides/troubleshooting.md`.

Then take a 10-minute tour of the floor:

```
Give me a tour of the factory folder. What lives where, and which files will you read at the start of every session?
```

The parts that matter most right now: `factory/Products/` (one folder per product, empty now, not for long), `factory/Brand/brand-kit.md` (filled in Episode 4), `factory/Recipe Book/` and `factory/Wonka's Notebook/` (the two learning loops, filled from Episode 13).

---

## MISSION 1: Wire the machines (with Wonka checking his own)

In Episode 1 you created the Genrupt account and your OpenAI key. Now you connect Genrupt to Claude, and this is the fun part: Wonka verifies his own machines while you watch.

Open `guides/mcp-setup-guide.md` and follow Part 1 (Genrupt): a short click path in Claude plus the current connection details from Genrupt's own docs. Then run the Factory's own systems check:

```
/machines-check
```

Wonka checks both machines himself: the Genrupt MCP with free read-only calls, including your credit balance (the fuel gauge you will see before every production run), and your OpenAI key confirmed in place. That one key powers two rooms: the Fixing Room's surgical edits AND the Tasting Room's panel of AI tasters in Episode 9. He reports each machine as OK or FAILED with the reason.

**Then say yes to the First Candy.** Wonka offers to print one small welcome image on your OpenAI key: a golden-ticket card that reads "Welcome to the Bootcamp." It costs a few cents, and it proves the one thing no settings page can: that your key is actually allowed to GENERATE images (the one-time org verification from Episode 1). If verification is missing, you find out now, with the fix one click away, instead of in the middle of Episode 6. The print saves to `output/first-candy.png`. It is your factory's first candy; post it in the group.

Two OKs and every room in the Factory is open. If something fails, fix it per the setup guide's fixes section for that tool, then run `/machines-check` again. Do not lose an evening to it; post the exact error in your support channel (the group, or reply to any bootcamp email) and keep going. Genrupt has a fallback path, so nothing here blocks you.

**A note on the machines and the method.** The setup guide walks the connection click paths; `/machines-check` is how Wonka confirms each machine with a live check, any time you want. Once both report OK, the wiring is done and it stays done between episodes.

**One more command to meet today:**

```
/factory-report
```

This is the "what's the status?" command: which products are on the line, what is done, what is blocked, what happens next. Right now the report is charmingly empty (machines warm, no products yet), but from Episode 3 on, this is how you walk back into the factory after a day away. Free, any time, and in Episode 13 it becomes your ten-minute weekly habit.

## MISSION 2: Get the shopping list in advance

Your product walks through the Front Gate in Episode 3, with ONE command: `/meet-my-product`. It registers the product, interviews you for your owner intel, hands you a shopping list of inputs, and (once the list is full) runs the whole market analysis. The single best thing you can do today is find out what that list contains, so you show up with your hands full and the Research Room runs in one sitting.

Ask the gatekeeper himself:

```
Wonka, next session I'm bringing my product through the Front Gate with
/meet-my-product. What exactly will you need from me? Give me the
shopping list in advance so I come prepared.
```

He will preview the list in character: the ASIN and full Amazon listing URL (or a product description if you are pre-launch), your owner intel (what only you know: past winners, must-appear certifications, things to avoid), your top ~10 positive and ~10 critical reviews saved as a file, 3 to 5 competitor ASINs/URLs or full gallery screenshots, your real product photos, and two optional extras: your Brand Registry ASIN-level demographics export, and any search-term or keyword data you already have. Notice what is NOT on the list: no report export, no browser extension, no third-party tool. Everything runs on what you already have. He will also be honest about the rule behind it: he WAITS at the gate until the list is full, because research built on guesses is not research.

**The niche phrase matters more than it looks.** Your exact niche, in your own words ("kids karaoke machine", "garlic press", "dog paw balm"), defines which competitors count as the same niche. "Kids karaoke machine" and "professional karaoke system" are different niches with different table stakes, and one wrong-niche competitor poisons the whole analysis. Decide your phrase today; you will confirm it at the Gate.

While the list is fresh, jot down your **owner intel** somewhere handy: what you already KNOW works, what MUST appear on the images, and what to AVOID. Wonka collects it at the Gate next episode and it travels with the product through every room.

---

## Before the next episode (20 to 30 minutes)

The Research Room opens in Episode 3 only if these are on the shelf. Keep everything together in one folder on your Desktop (for example `[product]-inputs`); in Episode 3 the product gets its own factory folder and everything moves in.

**1. Copy reviews.**
From your own listing (and optionally your #1 competitor): the top 10 or so positive reviews and the top 10 critical ones. Copy and paste them into a text file in your inputs folder. Critical reviews are gold; they are your customers writing your image brief for free.

**2. Screenshot competitor galleries.**
Pick your top 3 to 5 competitors (the ones actually beating you on your main keyword, and genuinely in YOUR niche), screenshot their image galleries into the same folder, and keep their listing URLs handy. Episode 3's Spy Balcony tears them down, and the table stakes of your niche come straight out of these galleries, so this is a core input, not a nice-to-have.

**3. Confirm your product photos are ready.**
The photos you took in Episode 1 (all angles, hand-for-scale, label close-ups) sit in your inputs folder, ready to move into the product's `reference/` folder at the Gate.

**4. Optional: export your real buyer demographics.**
If you have Brand Registry, export your ASIN's Brand Analytics demographics into the folder. Your persona gets real buyer ages instead of niche averages.

## Definition of Done for Episode 2

- [ ] Wonka answered in character and gave you the Factory tour
- [ ] You can name the 5 stations in order and say why order matters
- [ ] `/machines-check` ran with two OKs: the Genrupt MCP (plus fuel gauge) and the OpenAI key both verified (or a fallback path consciously chosen and recorded)
- [ ] First Candy printed and admired: `output/first-candy.png` exists, org verification proven (or consciously declined, knowing the first generation episode will prove it instead)
- [ ] `/factory-report` run once on the empty floor, so the status habit exists before the factory gets busy
- [ ] The shopping-list preview received from Wonka, and your niche phrase decided, word for word
- [ ] Your owner intel jotted down (known winners, must-include, avoid), ready for the Gate
- [ ] Homework started: reviews file, competitor screenshots, photos in one inputs folder

## Troubleshooting note

If a slash command does nothing, type it as a plain message starting with the slash (`/meet-my-product`) rather than describing it ("run the new product thing"). If an MCP does not appear at all, you did not fully restart Claude; quit completely (Mac: Cmd+Q; Windows: quit from the tray icon) and reopen, then re-check with Wonka. If Wonka claims a folder exists but you cannot see it, remember `.claude/` is hidden (Mac: Cmd+Shift+. in Finder; Windows: File Explorer, View tab, check Hidden items) and product folders live under `factory/Products/`. Everything else: `guides/troubleshooting.md`.

Next episode the Research Room opens: niche table stakes, the pains hiding in your reviews, a competitor teardown, and the real buyer behind the Buy button. As the man says: "Every great candy starts with knowing exactly who it is for."

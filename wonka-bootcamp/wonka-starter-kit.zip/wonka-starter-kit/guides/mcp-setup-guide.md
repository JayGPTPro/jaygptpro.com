# Connections Setup Guide

The Factory has four external connections: the Genrupt MCP (the Inventing Room's machine), the ProductPinion MCP (the Poll Room's machine), the Product Opinion extension (the Research Room's data source), and your OpenAI API key (the Fixing Room's scalpel). This guide sets up all four and verifies each one. Nothing here requires coding; every step is a click path or a copy-paste.

Two of these connect the same way, through an MCP (Model Context Protocol): a direct line that lets Wonka drive an outside tool himself from inside Claude, with no external website for you to log into and build things on. Genrupt and ProductPinion are both MCPs, and **your first month of each is included with the bootcamp.**

---

## Part 1: Genrupt MCP

An MCP (Model Context Protocol) connection is how Claude talks to an outside tool directly. Once connected, Wonka can drive Genrupt himself: build product reference sheets, lock the Mold, and generate images, without you touching the Genrupt website.

**Important: Genrupt maintains the official, current connection instructions.** Tool setup screens change; this guide tells you where to click in CLAUDE, and Genrupt's docs tell you the current values to use. Find them at: your Genrupt account dashboard, under Settings or Integrations (look for "MCP", "Claude", or "API access"), or Genrupt's help/docs site. If the bootcamp portal has a pinned Genrupt setup post, that link is kept current too.

Product photos: Genrupt reference sheets are built from image URLs or Genrupt's own upload paths (app or CLI bridge). Follow Genrupt's current official docs for uploading your own photos; Wonka will walk you through it in the Reference Room.

### Option A: Claude Desktop (Connectors UI)

1. Open Claude Desktop.
2. Click **Settings** (gear icon, bottom left), then **Connectors** (on some versions: Settings, then Extensions or Integrations).
3. Click **"Add custom connector"**.
4. Genrupt's instructions will give you either a **remote server URL** (paste it in the URL field) or a **local command** (paste the command exactly as their docs show).
5. If Genrupt requires an API key or login, follow their prompt; keys come from your Genrupt account settings.
6. Click Save, then **quit Claude Desktop completely and reopen it** (Mac: Cmd+Q, not just closing the window; Windows: right-click the tray icon, Quit).

### Option B: Claude Code (.mcp.json file)

1. In your kit folder, there may already be a file named `.mcp.json` (remember: files starting with a dot are hidden; Mac: Cmd+Shift+. in Finder).
2. If not, ask Wonka to create it:
   ```
   Create a .mcp.json in this folder for the Genrupt MCP. Here are the connection details from Genrupt's docs: [paste them]
   ```
3. Restart Claude Code (type `exit`, then start `claude` again in the folder).
4. On first use, Claude will ask you to approve the new MCP server. Approve it.

### Verify Genrupt

In a fresh session, type:

```
/machines-check
```

Wonka runs a small read-only test call on each connected machine (like checking the account context or credit balance) and reports each as OK or FAILED. A working Genrupt connection returns real account details; Wonka will tell you plainly if it failed.

### If it fails

- **The MCP does not appear at all:** you did not fully restart Claude. Quit completely (Cmd+Q / tray Quit) and reopen. This fixes most cases.
- **"Unauthorized" or key errors:** the API key is wrong, expired, or pasted with a stray space. Generate a fresh key in Genrupt and re-enter it.
- **Connected but calls fail:** log in to genrupt.com in your browser once and retry; some setups need an active web session.
- **Still stuck:** post in the bootcamp group with a screenshot of the exact error. Do not lose an evening to it; the fallback path (below) keeps you moving.

**Fallback:** without Genrupt, Wonka generates using OpenAI's image model directly (Part 4 key required). Product-reference accuracy is lower and Wonka will mark it honestly in your files, but every episode of the bootcamp remains doable.

---

## Part 2: ProductPinion MCP

ProductPinion is the Poll Room's machine. It is where real shoppers vote on your images. The whole survey lives inside Claude: Wonka builds the survey, targets the audience, and runs it through the ProductPinion MCP, all without you opening an external website to design anything. **You approve the cost and click publish** (spending money is always a human's click), Wonka does the rest, and the results flow straight back into your files.

Your first month of ProductPinion is included with the bootcamp; activate it with the code or link in your welcome email.

**Important: ProductPinion maintains the official, current connection instructions.** Setup screens change, so this guide tells you where to click in CLAUDE, and ProductPinion's own docs tell you the current values to use. Find them at: your ProductPinion account dashboard, under Settings or Integrations (look for "MCP", "Claude", or "API access"), or ProductPinion's help/docs site. If the bootcamp portal has a pinned ProductPinion setup post, that link is kept current too.

### Option A: Claude Desktop (Connectors UI)

1. Open Claude Desktop.
2. Click **Settings** (gear icon, bottom left), then **Connectors** (on some versions: Settings, then Extensions or Integrations).
3. Click **"Add custom connector"**.
4. ProductPinion's instructions will give you either a **remote server URL** (paste it in the URL field) or a **local command** (paste the command exactly as their docs show).
5. If ProductPinion requires an API key or login, follow their prompt; keys come from your ProductPinion account settings.
6. Click Save, then **quit Claude Desktop completely and reopen it** (Mac: Cmd+Q, not just closing the window; Windows: right-click the tray icon, Quit).

### Option B: Claude Code (.mcp.json file)

1. In your kit folder there may already be a `.mcp.json` (files starting with a dot are hidden; Mac: Cmd+Shift+. in Finder). If Genrupt is already in it, ProductPinion is added as a second entry in the same file.
2. Ask Wonka to add it:
   ```
   Add the ProductPinion MCP to my .mcp.json alongside Genrupt. Here are the connection details from ProductPinion's docs: [paste them]
   ```
3. Restart Claude Code (type `exit`, then start `claude` again in the folder).
4. On first use, Claude will ask you to approve the new MCP server. Approve it.

### Verify ProductPinion

In a fresh session, type:

```
/machines-check
```

A working connection returns real account details. Wonka will tell you plainly if it failed. You do not need to run a survey to verify; the read-only check is enough.

### If it fails

- **The MCP does not appear at all:** you did not fully restart Claude. Quit completely (Cmd+Q / tray Quit) and reopen.
- **"Unauthorized" or key errors:** the API key is wrong, expired, or pasted with a stray space. Generate a fresh key in ProductPinion and re-enter it.
- **Connected but calls fail:** log in to productpinion.com in your browser once and retry; some setups need an active web session.
- **Still stuck:** post in the bootcamp group with a screenshot of the exact error. This connection only earns its keep in Episode 9, so you have time to sort it out.

---

## Part 3: Product Opinion extension

This browser extension exports Amazon's **Top Niche Insights** report, the Research Room's most important input.

### Install

1. Open **Chrome** (or Edge/Brave; any Chromium browser).
2. Go to the Chrome Web Store and search **"Product Opinion"** (or use the portal's direct link).
3. Click **"Add to Chrome"**, confirm.
4. Pin it: click the puzzle-piece icon right of the address bar, then the pin icon next to Product Opinion.

### Export your niche insights (Episode 2 homework)

1. Log in to Amazon in that browser (a Seller Central login gives the richest data; follow the extension's own guidance).
2. Navigate to the niche research area the extension points you to and search for **your exact niche phrase**, the one you confirmed with Wonka at the Front Gate, word for word.
3. Click the Product Opinion extension icon and use its **Export** action (the extension's own instructions are always current on its listing page or website).
4. Save the export (file, or copied text) into your product's `research/` folder, or paste it directly to Wonka: `Here is my Top Niche Insights export, file it.`

### Verify

```
Read the niche insights export in my research folder. What niche is it for, and does it match my product's registered niche?
```

If the phrases do not match, re-export for the right one. A neighboring niche's insights silently poison everything downstream; Wonka will refuse to build on the wrong export, and that stubbornness is protecting you.

### If it fails

- **The extension shows no export option:** you are usually on the wrong Amazon page or not logged in; follow the extension's own current instructions.
- **The niche does not exist in Amazon's data:** try the closest broader phrase ("castor oil" instead of "castor oil glass bottle 16oz") and tell Wonka which phrase you actually exported.

---

## Part 4: OpenAI API key (the Fixing Room)

Surgical image edits run directly on OpenAI's image model. Typical cost: cents per edit.

### Create the key

1. Go to **platform.openai.com** and log in (create an account if needed; this is separate from ChatGPT Plus).
2. Top-right profile menu, then **API keys** (direct: platform.openai.com/api-keys).
3. Click **"Create new secret key"**, name it `wonka-factory`, click Create.
4. **Copy it now.** It starts with `sk-` and is shown only once.
5. Go to **Settings, then Billing**, add a payment method, and load **$5 to $10** of credit. That is more than the whole bootcamp needs.
6. One-time organization verification: OpenAI may require you to verify your organization before image models work. Go to **platform.openai.com, Settings, Organization, Verify** and complete it now, during setup, not in the episode where you actually need the Fixing Room.

### Save the key for Wonka

The simple, recommended way: a `.env` file in the kit folder.

1. Tell Wonka:
   ```
   Create a .env file in this folder with my OpenAI key, and make sure the folder's setup keeps it private. The key is: sk-[paste your key]
   ```
2. Wonka creates the file. The `.env` file stays on your machine; it is not shared when you post screenshots (never screenshot the file itself).

Comfortable with system settings instead? You can set it as an environment variable named `OPENAI_API_KEY` (Mac: in `~/.zshrc`; Windows: System Properties, Environment Variables). Either method works; `.env` is easier.

### Verify

```
/machines-check
```

The check confirms the key is in place (no API call is made, nothing is spent) and reports the result.

### If it fails

- **"Invalid API key":** re-copy the key; stray spaces and truncated pastes are the usual crime. If lost, just create a new key and delete the old one.
- **"Insufficient quota":** billing has no credit. Load $5 to $10 at platform.openai.com under Billing.
- **403 / verification required:** your organization has not completed OpenAI's one-time verification. Go to platform.openai.com, Settings, Organization, Verify, complete it, then retry.
- **Edits fail with a content flag:** usually an instruction mentioning a third-party logo or brand; rephrase the edit without it. Wonka knows this rule and will route around it.

---

## Quick reference: verify everything at once

Type this any time you want a full systems check:

```
/machines-check
```

It checks all the machines in one pass: the Genrupt MCP with a small read-only call, the ProductPinion MCP with a small read-only call, and the OpenAI key's presence (no call, no spend), and reports each as OK or FAILED with the reason. To also confirm your niche insights export exists and matches your niche, add: `And confirm my niche insights export exists and matches my registered niche.` All OKs and every room in the Factory is open.

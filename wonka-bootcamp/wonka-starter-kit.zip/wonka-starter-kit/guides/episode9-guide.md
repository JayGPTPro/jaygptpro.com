# Day 9: The Second Batch and Ship It

Both Tasting Cards are sitting in your factory with the verdicts glanced at and the notes unread. Today you do the thing almost nobody in e-commerce does: you act on the WHY, in the same sitting. Wonka reads every tasting note on both Cards, you turn them into written instructions, `/fix` MODE B refines your winner and repairs your weakest gallery frame from the tasters' own words, an optional data born challenger gets built from what they praised, and Tasting Round 2 runs on both races before you stand up. Then `/ready-to-upload` packages the whole tested set into one folder.

One round of testing finds you a winner. A second round, built from the first round's notes, is how a good package becomes the best package you can currently make. And the last piece of the day is the practical one every course skips: exactly how you get this onto Amazon and how you prove it there.

## What you will have by the end of today

- Both Round 1 verdicts read properly: winners, margins, stability tiers, and the tasting notes from both Cards grouped into themes with counts
- **A written instruction list before you touch a single image**, every instruction traceable to a note and a number of tasters
- **A refined main winner and a repaired gallery frame**, each change answering a specific taster objection, originals untouched beside them
- A data born round 2 challenger, generated from the strongest praise theme (optional, recommended)
- **Tasting Round 2 complete, both races**, with the round over round comparison wired so you can see what your fix actually moved
- **`tests/upload-pack.md` and your complete tested package sitting in `output/`**, ready to upload
- The Amazon last mile as a procedure you can run on your own listing: uploading, the main image rules, and Manage Your Experiments

**Time needed:** 75 to 100 minutes, start to finish. Nothing fills overnight and nothing waits between rounds. That is the whole point of this room.

## What you will need at hand

- Both Round 1 Tasting Cards in `tests/`, unmined
- Your OpenAI key working. MODE B and the Round 2 panel both run on it
- **Genrupt with credits.** Today can regenerate two slots and generate one new candidate, and Day 10 needs credits again for your variation family. Check before you start, not halfway through
- Your Brand Registry status, if you know it. It changes nothing about your package, only whether the optional A/B is available to you

---

## Lesson 1: The why is worth more than the winner

The vote tells you which image won. The notes tell you WHY, in your market's own words: "I could actually see it working", "the third one looked cheap", "I could not tell how big it is". That why is the asset. It transfers to your next product, your A+ copy, even your ad headlines. The winner is one image. The why is a pattern.

Most people run a test, note the winner, and ship. The reasons, which are the most valuable part of what they paid for, go unread. You are going to mine them the same hour and act on them the same hour.

Two things to hold while you read.

**The stability tier is part of the verdict.** Clear lead means the winner held in at least 95 percent of the resamples, so act on it. Lean, 80 to 95 percent, is a real lean and a fine basis for choosing what to refine, not for shipping. Toss-up, under 80 percent or the models disagreeing, is a tie: keep the objections, ignore the shares. Say your tier out loud and believe it.

**A theme needs repetition.** One taster saying something is noise. Three or more saying the same thing is an instruction. Count before you act.

## Lesson 2: MODE B, and the two refusals

You know `/fix` in MODE A: cleaning the defects the Inspection Room flagged, before anybody voted. Today is the same room in MODE B: refining a proven winner from the tasters' notes.

The difference matters. MODE A removes flaws. MODE B chases conversion. If tasters said they could not tell the size, the fix strengthens a scale cue. If they said the text was busy, the message gets bigger by subtraction. If they praised something you did not plan for, that element gets protected and amplified. Every edit traces to a specific note. Nothing changes on a hunch.

MODE B works both Cards. The main Card's notes refine the winning main. The gallery Card's frame by frame notes name your weakest frame, and that frame gets the same treatment. A gallery race that flags your setup frame as the one tasters skipped is handing you the exact edit that lifts the whole set.

The routing rules do not change. Shorten, remove or swap a word is a surgical edit for cents. Enlarge, move, re-lay out, re-cast or fix the product itself is a regeneration with a tighter brief. Originals always kept beside the new file.

And two refusals you should expect and welcome:

**Wonka will refuse a fix that breaks a hard rule.** The commonest one: an objection raised about your MAIN image that can only be answered with text or a graphic. A main image carries no overlay text, no callouts, no badges, ever. That is Amazon's requirement and it is the house rule. The answer gets routed to the gallery, where it is allowed to live, and often your gallery already has the frame for it. That is a free instruction: not build something, move something earlier.

**Wonka will refuse a fix that fights your research.** This is the important one. Your panel is cheap and fast, which is exactly why it must never quietly overrule expensive real evidence like your reviews and your returns. If a taster objection points you at a change your reviews say is a lie, it gets recorded in the test file and it does not get executed. You can override him. Write down why if you do.

## Lesson 3: The last mile, taught rather than demonstrated

The demo product in this bootcamp is a live public listing that is not ours, so nothing gets uploaded to it and no A/B is run on it. The procedure below is identical on any listing, and it is yours to run.

**Uploading, in order.** Main image and gallery go into Seller Central under your inventory, edit the listing, images tab. Slot one is the main, and the rest fill the gallery slots in the order YOU choose. After the frame by frame dive on your gallery Card, you have a reason for that order.

Two rules on the main image slot that get listings suppressed: pure white background, and the product filling most of the frame. Nothing else. No text, no logos, no watermarks, no props, no borders. Amazon revises its image requirements periodically, so read the current requirements page in Seller Central help before you upload.

A+ goes in through A+ Content Manager, which needs Brand Registry. You build the modules, attach the ASINs, submit, and it enters a review queue that takes a few days. Rejections are usually about claims, so keep your comparison rows provable.

**The A/B, which is optional and which is where the real proof lives.** With Brand Registry you get Manage Your Experiments, under Brands. Create an experiment, choose the type, select the ASIN, and Amazon checks eligibility on the spot, because the ASIN needs enough traffic to reach significance. Your current live image is version A. Your tested winner is version B. Write a real hypothesis into the field: one sentence, causal, and something you could be wrong about.

Four rules that decide whether the test is worth anything:

1. **Metric.** A main image test watches click through rate, because the main image's job is winning the click on the search page. A gallery or A+ test watches conversion, because those assets work after the click.
2. **Duration.** Eight to ten weeks, run to significance, no peeking and no stopping early. Early leads flip and a stopped test proves nothing.
3. **Change one thing.** No title test, no price move, no new campaign in the middle of it.
4. **One experiment per ASIN at a time.** If one is running, yours queues.

**Without Brand Registry** the honest fallback is a swap with before and after monitoring: record a few weeks of baseline traffic in Business Reports, swap the image, then watch the same report for the same period after. Amazon does not hand a non registered seller a clean organic click through number, so you are reading sessions and unit session percentage, plus your ad reports as a proxy. Label it what it is. Weaker evidence, no control group, and seasonality, price, ads and competitors move the same numbers. It tells you whether things got better. It cannot tell you the image caused it.

Your package is finished and ready either way. The promise of this bootcamp is a tested package, never an experiment and never a result.

---

## MISSION 1: Mine both Tasting Cards

```
Open both Round 1 Tasting Cards. Analyse the votes AND mine every
tasting note, main race and gallery race: recurring themes with
counts, what drove the winner's votes, what the tasters said against
the losers, the weakest gallery frame's notes, and anything they
complained about even while voting FOR the winner.
```

Then make him show his work, and read them yourself:

```
Show me the strongest 10 tasting notes verbatim, from either Card,
and tell me which theme each one supports.
```

Reading a hundred strangers react to your own images is one of the quiet highlights of this bootcamp. Somewhere in yours is a sentence that changes how you brief creative forever. Do not skim this.

**What good looks like:** a praise theme with a count, a friction theme with a count, your weakest gallery frame named with the notes that sank it, and the losing candidates' notes reported without flattery. If a Card comes back with no recurring objections at all, raise an eyebrow and tell Wonka to dig into the notes column again.

## MISSION 2: Write the instructions before you change anything

```
Turn the mined themes into a written instruction list. For each
instruction: what changes, which asset it belongs to, and the exact
note plus the number of tasters that justify it. If an instruction
cannot legally or honestly be executed on the asset the objection was
raised about, say so and route it to the asset where it belongs.
```

Orders first, surgery second. Read the list like an owner and strike anything that reads like taste smuggled in as data. A good instruction looks like this: "Enlarge the label area. Justified by: four tasters said they could not read it." A bad one looks like: "Make it pop more."

Expect at least one instruction that costs nothing, and one refusal. Both are wins.

## MISSION 3: Refine the winner and your weakest gallery frame

```
/fix

MODE B, from the Round 1 Cards. Two jobs: the winning main image from
its friction theme, and the weakest gallery frame from the frame by
frame notes. Route each one honestly against the routing table, tie
every change to the note that justifies it, and give me one total cost
line before anything runs.
```

Review the routed list before you say yes. Check three things: every item names the note behind it, every item is routed edit or regenerate with a reason, and there is ONE cost line, not one per item.

When the work lands:

```
Show me the refined winner next to the original, and the refined
frame next to its original, and tell me which taster objection each
change answers. Then re-inspect both, including the set level checks.
```

**What good looks like:** the refinements saved beside untouched originals, the change visible at thumbnail size and not just at full size, and both files passing inspection mechanically rather than passing because you like them.

## MISSION 4: Build the data born challenger (optional, recommended)

The challenger is your call. Skipping it keeps Round 2 as a confirmation. Building it turns Round 2 into an experiment. Only build one if your notes actually handed you a thesis you have not tested.

```
From the Tasting Cards, what is the strongest creative hypothesis we
did NOT test in Round 1? Propose a challenger concept built on it.
```

Discuss it. Your product knowledge matters here. When you agree:

```
/main-image

ONE round 2 challenger only, built on the concept we just agreed, on
the locked reference, main image rules apply. State the cost first,
then inspect it.
```

No image enters the Tasting Room ungated, not even one born from data. And make sure it carries its provenance line, so in three months you still know where it came from.

**Different strategy, not different decoration.** If your refined winner is a dominant product shot, the challenger might lead with the material story or the proof of the thing your category never proves. Two shades of the same idea split votes and teach nothing.

## MISSION 5: Run Tasting Round 2, both races

```
/tasting-room

Tasting Round 2, both races, same panel spec as Round 1.
MAIN: the refined winner, my challenger if I built one, and the
incumbent again.
GALLERY: the refined set against the live gallery again.
Set compare_to on both races to Round 1's results.json and keep the
candidate ids stable. Quote the cost and stop.
```

Before you approve, check three things yourself:

1. **The incumbent is in the main grid.** Round 2 is still a fight with reality, not a private competition between your own drafts.
2. **`compare_to` is an absolute path** to the matching Round 1 `results.json`, one per race.
3. **The candidate ids are unchanged.** Your refined winner is a new FILE with the same NAME on the scoreboard. Rename it and you lose the only number that tells you whether your fix worked.

Approve, and the races run in minutes. Then read them:

```
Walk me through both Round 2 Cards: verdicts with their stability
tiers, the Round Comparison deltas, and what the notes add to Round 1.
Then log Round 2 in the experiments log and status.md.
```

The delta arrows are the point of this whole day. That is your fix, executed, and then graded by the same panel that asked for it.

## MISSION 6: Package it

```
/ready-to-upload

Package the winner and the full tested set. Check the gate against the
Round 2 main card before anything else, and tell me plainly if it does
not pass.
```

The gate is not a formality. The winner has to be one of YOUR candidates, not the incumbent, and the main race label has to be Clear lead. Anything less and the Shipping Room closes and sends you back to refine and taste again. That is correct behaviour, not a bug.

One last check before you stamp it:

```
Cross check my A+ against the winning angle. Does it carry the angle
the tasters rewarded, and is anything in it now out of step with what
won?
```

If your winning angle turned out to be something your A+ does not argue, realign the modules that are now arguing the losing case before the pack ships. A+ never goes through an A/B like a main image does, and that does not make it exempt from the verdict.

Then confirm what landed:

```
Confirm what is in output/ and what is still pending.
```

Variations will show as pending. That is expected, it is the next room's job, and the pack gets extended rather than rewritten.

**Share the WOW:** post one tasting note beside the exact change it produced, plus your Round Comparison section. "A taster said X, so we changed Y, and here is the delta" is the single most persuasive sentence in this business. And post loudly if YOUR pick lost. Losing your own argument to a hundred strangers is this bootcamp's graduation moment, and everybody who posts one makes the group braver.

---

## Before Day 10 (5 minutes)

Nothing has to fill and nothing has to wait. Two small things:

1. **Confirm your `output/` folder is real.** Open it. Main image, gallery, A+ modules, and `upload-pack.md` sitting together. If something is missing, ask Wonka to re-run the packaging step rather than discovering the gap in the next room.
2. **Decide your variation axis.** Day 10 turns your winner into a whole shelf. Look at your product and your competitors and form a view: is your variation story colour, size, scent, count, or a bundle? You do not have to be right, you just have to arrive with an opinion.

## Definition of Done for Day 9

- [ ] Both Round 1 Tasting Cards mined: winners, margins, stability tiers, weakest gallery frame, and themed notes with counts
- [ ] An instruction list written BEFORE any image changed, every instruction tied to a note and a count
- [ ] Any refused fix recorded with its reason (rule break, or contradicts your research)
- [ ] `/fix` MODE B ran on the main winner AND the weakest gallery frame: refinements saved beside untouched originals, each change tied to a specific note, both re-inspected and passing
- [ ] OPTIONAL and recommended: a data born challenger agreed, generated, inspected and gate passed, carrying its provenance line
- [ ] Tasting Round 2 ran, BOTH races, with the incumbent in the main grid, `compare_to` wired to Round 1, and candidate ids unchanged
- [ ] Round 2's verdicts read with their stability tiers, and the Round Comparison deltas read
- [ ] Round 2 logged in the experiments log, `status.md` updated
- [ ] `/ready-to-upload` ran and the gate passed: `tests/upload-pack.md` exists, and your complete package is in `output/` with variations marked pending
- [ ] Your A+ cross checked against the winning angle
- [ ] You know exactly how you would upload and A/B this on your own listing

## When it goes wrong

**Your Round 2 verdict is Lean or Toss-up, so the Shipping Room will not open.** Correct behaviour. Mine round 2's notes, refine again, and run round 3. It is minutes and a few dollars. Do not talk the label up in your own head, and do not package a coin flip because you are tired.

**The incumbent won.** You just avoided downgrading a working listing for the price of lunch, which is the most common unforced error in this industry. Mine the notes for WHY it holds, which is a free teardown of a proven image, keep that read in the test file so Day 10's improvement loop can bank it, and build your next candidates from those notes. The gate stays shut until one of yours wins, and that is the gate earning its keep.

**Your notes contain no theme with three or more mentions.** Then your winner has no documented flaw, and you skip MODE B rather than invent a fix. Changing a winner without a reason is how winners get broken. Run Round 2 as a confirmation against your challenger or your next best gate passed candidate.

**A MODE B change garbles the image.** It was regenerate territory and it got edited. `Route this refinement to regenerate with a tighter brief instead.` Your original is untouched, so nothing is lost except one attempt.

**Wonka wants to regenerate when you expected a two cent edit.** Trust the routing. Swapping a word is surgery. Enlarging, moving or re-laying out is a re-bake, because the edit endpoint re-renders the whole frame and spatial changes come back subtly wrong. This is exactly why your refined winner still looks like the winner.

**Your Round 2 Card has no Round Comparison section.** Either `compare_to` is not an absolute path to Round 1's `results.json`, or a candidate id changed between rounds. Fix it and run the same command again. It resumes from the checkpoint rather than double spending.

**A run stops midway.** Run the exact same command again. The checkpoint resumes it, nothing is lost and nothing is charged twice. Changing the config resets the checkpoint on purpose, adding `compare_to` does not.

**The Card shows a low parse rate.** Some taster responses could not be scored, so the shares are sitting on a smaller sample than they claim. Do not act on those percentages. Re-run before you decide anything.

**Round 2 disagreed with Round 1.** Read both Cards' tiers and notes. If Round 2 has a Clear lead and its notes explain the flip, trust Round 2, because it tested better images. If both are soft, the honest answer is that you have no verdict: pick by the notes and your own judgement, record your reason, and consider the optional real shopper poll before betting real money.

**Genrupt runs out of credits mid day.** Everything already generated is safe on disk and nothing gets overwritten. Top up and re-run only the slot that is missing.

**Everything else:** `guides/troubleshooting.md`.

---

Next: one winner becomes a whole shelf. `/variations` fills the last pending line in your upload pack, the gate opens on a second product so you can feel how much faster this goes the second time, and then the factory does the thing no tool does. It writes down what it learned, twice, so the next product starts smarter than this one did. "The tasters have spoken. I merely work here."

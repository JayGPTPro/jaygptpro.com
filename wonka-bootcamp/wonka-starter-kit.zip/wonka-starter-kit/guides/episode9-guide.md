# Episode 9: The Tasting Room

Everything until now was craft. This episode is verdicts, and Round 1 runs TWO races in the same sitting. The MAIN race: you pick 2 main image candidates, and a panel of ~100 AI tasters, each conditioned on your real buyer's demographics, looks at them next to your current live image and votes, with reasons. The GALLERY race: the same panel judges your new secondary set against your live Amazon gallery, a set-level verdict plus a frame-by-frame dive. The whole thing runs on your OpenAI key, costs a few dollars per race, and finishes in minutes. You start this episode with opinions; you end it holding two Tasting Cards with verdicts and a list of objections your buyers would raise.

## What you will have by the end of this episode

- Your 2 main candidates chosen (by YOU, with Wonka's ranking as an input)
- **Tasting Round 1 complete, two races in one sitting: the MAIN race (2 candidates + the live incumbent) and the GALLERY race (your new secondary set vs your live Amazon gallery), judged by ~100 demographic-matched tasters**
- Two Tasting Cards saved in the round folder, `tests/tasting-r[N]-[date]/` (`tasting-card.md` + `tasting-card.html` + `results.json` per race): verdicts, per-image tasting notes, and the recurring objections
- An understanding of what the panel can tell you (direction + objections) and what it cannot (real-shopper proof)

**Time needed:** 60 to 75 minutes, both races' results included. Nothing fills between episodes; the verdicts are in your hands before you stand up.

## What you will need at hand

- Your gate-passed main candidates from Episode 6 (fixed and re-inspected)
- Your gate-passed secondary set from Episode 7 (it races too)
- Your current LIVE Amazon main image AND live gallery, downloaded (the homework from last episode)
- `research/persona.md` fresh in your mind (the panel is conditioned on it)
- Your OpenAI key in place (run `/machines-check` if unsure)

---

## Lesson 1: Opinions are not data

You like candidate 2. Wonka ranked candidate 4 first. Your spouse likes the blue one. None of that is data. What you need is the reaction of people who resemble your actual buyers, seeing your image the way buyers see it: next to alternatives, at a glance.

That is what the Tasting Room stages. Each taster in the panel is conditioned on your real buyer persona (age, gender, the things your demographic export said), looks at the candidates together, picks the one they would choose, and writes WHY. The method behind it (called SSR) maps each taster's free-text reaction to a purchase-intent score, so you get both a vote count and a pile of written reasons. The vote crowns a leader; the reasons, you will learn in the next episode, are worth even more.

## Lesson 2: The incumbent rule (beat reality, not your drafts)

The iron rule of this Factory's testing: **the current live Amazon image is always in the lineup.** Your candidates do not compete against each other in a vacuum; they compete against the image that is actually earning clicks on your listing right now.

Why this is non-negotiable: a test between only new candidates tells you which draft is least weak. It cannot tell you whether ANY of them should replace what is live. If the incumbent wins your Tasting Round, that is not a failure; that is the panel saving you from replacing a working image with a worse one, for a few dollars instead of two months of lost sales.

The same rule powers the GALLERY race. Your new secondary set does not get graded in a vacuum; it races your live Amazon gallery, set against set. The panel gives a set-level verdict (which gallery would make them click Buy) and then dives frame by frame, so you learn not just whether your new set wins, but which specific frames carry it and which drag it.

## Lesson 3: What the panel is, honestly

This lesson is the integrity of the whole method, so read it twice.

The Tasting Room panel is ~100 AI tasters, not ~100 real shoppers. Conditioned on real demographics, reacting one at a time, scored by a published method, it is remarkably good at two things: **direction** (which candidate leads, and by roughly how much) and **objection mining** (the specific doubts your buyer profile would raise: "can't tell the size", "looks like plastic", "too much text"). Those objections are what Episode 10 turns into targeted improvements.

What it is NOT: proof from real shoppers. So Wonka applies two honesty rules to every Tasting Card, and you should hold him to them:

1. **A thin margin, or disagreement inside the panel, means NO CLEAR VERDICT.** The card says so in those words. You do not ship a coin flip; you refine and re-taste.
2. **For big-money decisions, real shoppers are the gold standard.** If a whole brand's packaging or a top seller's main image hangs on the answer, run an optional real-shopper poll (PickFu, ProductPinion, or any panel you like) on the finalists. That is a Pro Move, not a bootcamp requirement; Episode 11 points to it at the right moment.

Directional verdict + real objections, instantly, for a few dollars: that is a spectacular trade. Just never let anyone (including Wonka) dress it up as real-shopper data.

## Lesson 4: Why instant matters

The old way to test images was a survey that took days to fill. The practical cost was not the money; it was the momentum. You lost the thread, the "why" comments went unread, round 2 never happened.

The Tasting Room collapses that loop to minutes. Test, read, refine, re-test, all in one sitting, all inside Claude. Episode 10 exists precisely because the loop is now fast enough to run twice before dinner.

---

## MISSION 1: Pick your 2 candidates (the human moment)

Wonka's ranking is a recommendation; it measures craft and compliance, not "which would I click". Narrow the field:

```
Show me the gate-passed main candidates side by side, with your ranking and one line on each concept's strategy.
```

Pick 2 for the Tasting Round (with the incumbent, that makes a 3-way test). You may absolutely override Wonka's #1:

```
I'm taking candidates 2 and 4 to the Tasting Room. Candidate 2 over your #1 because [your reason]. Record that.
```

Your reason gets recorded in the product's status notes. If your pick later wins, that reason becomes learning material: your instincts, converted into data.

Why only 2 candidates? Votes split across too many options produce mush. Two strategies against the incumbent gives you a clean, readable verdict, and the next episode's Round 2 exists precisely so the losing angle's lessons are not wasted.

## MISSION 2: Convene the panel

```
/tasting-room
```

Wonka assembles Round 1 inside Claude, both races, one sitting:

- **The MAIN race:** your 2 chosen candidates PLUS the incumbent (he will ask for your downloaded live main image; it goes in the lineup as the control)
- **The GALLERY race:** your gate-passed secondary set vs your live Amazon gallery (he will ask for the downloaded live gallery), set-level verdict plus a frame-by-frame dive
- The panel conditioned on your real buyer persona from Episode 3 (the REAL buyer ages, not the aspirational casting ages; the skew is for what is IN the images, never for who judges them)
- A one-line cost estimate per race (a few dollars each, on your OpenAI key), and he waits for your go-ahead

Give the go-ahead and watch. The panel runs in minutes per race, and everything saves to your product's `tests/` folder: one Tasting Card per race.

## MISSION 3: Read the two Tasting Cards

The results land as Tasting Cards in a round folder, `tests/tasting-r[N]-[date]/`: `tasting-card.md` and a visual `tasting-card.html` per race, openable in your browser. Read them like an owner:

```
Walk me through both Tasting Cards: the main race verdict, the gallery race's set verdict and frame-by-frame notes, and the recurring objections on each. And tell me honestly: are these clear verdicts or thin ones?
```

Check four things yourself:

1. **The incumbent is in the main race lineup**, and you can see how each candidate did against it.
2. **The gallery race is set vs set**, your new gallery against the live one, with a frame-by-frame dive naming your strongest and weakest frames.
3. **The verdict lines are honest.** A clear leader is named as one; a thin margin or a split panel is named "no clear verdict", in those words.
4. **The objections are specific.** "Can't tell how big it is" is workable; a card with no recurring objections deserves a raised eyebrow, tell Wonka to dig into the notes again.

## MISSION 4: Log it and share it

Have Wonka close the round:

```
Log Tasting Round 1 in the experiments log and status.md: both races' lineups, both verdicts, and the top objections from each card.
```

That writes the experiment row (the Recipe Book learns from it in Episode 13) and updates your product's tracker.

**Share the WOW:** post your 3-image lineup and one recurring objection from the tasting notes in the bootcamp group. "A hundred tasters in four minutes" is the sentence that makes people sit up.

---

## Before the next episode

Almost nothing; the results are already in your hands. Two small tasks:

1. Re-read your two candidates' concept strategies (from Episode 6's lessons). The next episode you will find out which STRATEGY resonated, not just which image.
2. Skim the recurring objections on both Tasting Cards once more. In the next episode they become edits (in the same sitting, if you keep going).

## Definition of Done for Episode 9

- [ ] You picked 2 main candidates (reason recorded if you overrode the ranking)
- [ ] `/tasting-room` ran with your cost go-ahead: Tasting Round 1 complete, both races (main race with the incumbent in the lineup; gallery race vs the live gallery)
- [ ] Two Tasting Cards exist in `tests/tasting-r[N]-[date]/` (`tasting-card.md` + `tasting-card.html` per race)
- [ ] You read both verdicts, the per-image and per-frame tasting notes, and the recurring objections
- [ ] Both verdicts were called honestly (a clear winner, or "no clear verdict" if the margin was thin or the panel split)
- [ ] Tasting Round 1 (both races) logged in the experiments log; `status.md` updated

## Common Episode 9 questions

**"I'm pre-launch, I have no live image. What is my incumbent?"**
Use your best competitor's main image (and their gallery, for the gallery race) as the benchmark instead, and tell Wonka so it is labeled correctly on the Tasting Cards. You are entering their shelf; beating the images buyers currently choose from is the honest bar.

**"What about A+? Can I test that the same way?"**
Yes, and after the bootcamp you can; the Tasting Room is not limited to what Round 1 covers. The bootcamp races the main and the gallery because those are the two highest-leverage decisions: the main wins the click, the gallery wins the sale.

**"Are AI tasters really a substitute for real shoppers?"**
No, and the Factory never claims they are. They are a fast, cheap, surprisingly sharp DIRECTIONAL signal plus an objection-mining machine. For most image decisions that is exactly the evidence you need at the moment you need it. For a big-money decision, run the optional real-shopper poll on the finalists (see Episode 11's Pro Move).

**"The verdict came back 'no clear verdict'. Did I waste the round?"**
Not at all; you learned that neither candidate clearly beats reality yet, for a few dollars. The objections on the card tell you what to sharpen. Refine and re-taste; that is exactly what the next episode does.

## Troubleshooting note

If the tasting run stops midway (a network hiccup, a rate limit, you closed the laptop), run the same `/tasting-room` command again; it picks up where it left off rather than starting over or double-spending. If the Tasting Card reports a low parse rate (many taster responses could not be scored), treat the verdict as weaker and re-run the round before acting on it. If the run will not start at all, the OpenAI key is the usual suspect: run `/machines-check` and see `guides/mcp-setup-guide.md`, Part 2. Everything else: `guides/troubleshooting.md`.

Next episode, the tasters have spoken: you act on the WHY. Wonka mines both cards, refines the main winner and the weakest gallery frames from the tasting notes, an optional data-born challenger enters, and Tasting Round 2 re-runs both races in the same sitting. "The tasters have spoken. I merely work here." That sentence is the next episode's whole religion, and it is a genuinely great religion to run a business on.

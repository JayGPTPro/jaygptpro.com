# Episode 9: The Poll Room

Everything until now was craft. This episode is truth. You pick 2 main image candidates, Wonka builds a shopper survey around them plus your current live image, you approve the cost, and you PUBLISH. Real shoppers, matched to your real buyer, vote on which image wins the click, and the survey fills between episodes, so the next episode opens to real results. This is the moment your images stop being opinions.

## What you will have by the end of this episode

- Your 2 main candidates chosen (by YOU, with Wonka's ranking as an input)
- **A published ProductPinion survey: 2 candidates + the live incumbent, targeted to your real buyer, filling between episodes**
- The survey package saved in `tests/`, with the experiment logged as running
- An understanding of why testing against the incumbent is the only honest test

**Time needed:** 45 to 75 minutes. Then the shoppers take over.

## What you will need at hand

- Your gate-passed main candidates from Episode 6 (fixed and re-inspected)
- Your current LIVE Amazon main image, downloaded (the homework from last episode)
- `research/persona.md` fresh in your mind (the survey targets it)
- The ProductPinion MCP connected and verified

---

## Lesson 1: Opinions are not data

You like candidate 2. Wonka ranked candidate 4 first. Your spouse likes the blue one. None of that is data. The only vote that matters comes from people who resemble your actual buyers, seeing your image the way buyers see it: next to alternatives, at a glance.

That is exactly what the Poll Room stages. Shoppers screened to your persona see the candidates side by side, in random order, with nothing hinting which is "new" or "yours". They click the one they would choose, and they write WHY. The vote crowns a winner; the why-comments, you will learn in the next episode, are worth even more.

## Lesson 2: The incumbent rule (beat reality, not your drafts)

The iron rule of this Factory's testing: **the current live Amazon image is always in the grid.** Your candidates do not compete against each other in a vacuum; they compete against the image that is actually earning clicks on your listing right now.

Why this is non-negotiable: a survey between only new candidates tells you which draft is least weak. It cannot tell you whether ANY of them should replace what is live. If the incumbent wins your survey, that is not a failure, that is the survey saving you from replacing a working image with a worse one, for the price of one poll instead of two months of lost sales.

## Lesson 3: The whole survey lives inside Claude

There is no external survey builder to learn. Wonka builds and runs the entire survey through the ProductPinion MCP, from right here in the chat: the image grid, the neutral survey copy, the audience targeting matched to your persona, the cost estimate. Your job is judgment and the two clicks that must stay human: **approving the cost and publishing.** Spending money is always a human's click in this Factory.

## Lesson 4: Neutrality is the survey's integrity

A biased survey is worse than no survey; it launders your opinion into fake data. Three neutrality rules Wonka enforces, and you should verify:

1. **No hints of ownership.** Nothing in the copy or presentation says which image is new, old, or "ours".
2. **Random order, equal footing.** Same size, same treatment, no candidate gets a flattering position.
3. **Neutral question wording.** "Which would you choose?" not "Which of these fresh new designs do you prefer?"

---

## MISSION 1: Pick your 2 candidates (the human moment)

Wonka's ranking is a recommendation; it measures craft and compliance, not "which would I click". That second question belongs to humans, which is exactly what the survey measures at scale. Narrow the field:

```
Show me the gate-passed main candidates side by side, with your ranking and one line on each concept's strategy.
```

Pick 2 for the survey (with the incumbent, that makes a 3-way test). You may absolutely override Wonka's #1:

```
I'm taking candidates 2 and 4 to the poll. Candidate 2 over your #1 because [your reason]. Record that.
```

Your reason gets recorded in the product's status notes. If your pick later wins, that reason becomes learning material: your instincts, converted into data.

Why only 2 candidates? Votes split across too many options produce mush. Two strategies against the incumbent gives you a clean, readable verdict, and the next episode's round 2 exists precisely so the losing angle's lessons are not wasted.

## MISSION 2: Build the survey

```
/poll
```

Wonka builds the survey package inside Claude via the ProductPinion MCP:

- Your 2 chosen candidates PLUS the incumbent (he will ask for your downloaded live main image; it goes in the grid as the control)
- Survey copy written neutrally, so nothing biases the vote
- Audience targeting matched to your real buyer persona from Episode 3 (the REAL buyer ages, not the aspirational casting ages; the skew is for what is IN the images, never for who judges them)
- A one-line cost estimate

Everything saves to your product's `tests/` folder.

## MISSION 3: Review the package like an auditor

Before any money moves, check the three neutrality rules yourself:

```
Show me the survey exactly as a participant will see it: the images in grid order, the question wording, and the targeting. Confirm there is no hint of which image is new or mine.
```

Also confirm the incumbent is actually in the grid, the audience matches the persona (age range, gender split, relevant screening), and the cost line is what you expect. If anything is off, say it plainly; rebuilding a survey package is free, republishing credibility is not.

## MISSION 4: Approve the cost and PUBLISH

The human clicks:

```
The survey package looks right. Walk me through approving the cost and publishing it in ProductPinion.
```

Wonka gives you the exact confirm-and-publish steps through the MCP. Once it is live, tell him:

```
The survey is published and live.
```

That is his cue to log the running experiment in `tests/` and `status.md`. And now, the best part of the whole method: you stop. The survey fills between episodes. Real shoppers vote while you do anything else at all.

**Share the WOW:** post your 3-image grid (anonymized, just like the participants see it) in the bootcamp group and let people guess which is the incumbent. If they cannot tell, your survey is well built.

---

## Before the next episode

**Let the survey fill. Do not peek-and-panic.** Partial results wobble; early leads flip. The survey needs its full sample before it means anything. If you must look, look; just decide nothing.

Two small optional tasks:

1. If any voter comments are already visible, resist summarizing them yourself; the next episode Wonka mines ALL of them systematically.
2. Re-read your two candidates' concept strategies (from Episode 6's lessons). The next episode you will find out which STRATEGY resonated, not just which image.

## Definition of Done for Episode 9

- [ ] You picked 2 main candidates (reason recorded if you overrode the ranking)
- [ ] `/poll` ran: survey package in `tests/` with the incumbent in the grid
- [ ] You verified neutrality: no ownership hints, random order, neutral wording
- [ ] Audience targeting matches the REAL buyer persona
- [ ] Cost approved and survey PUBLISHED by you via ProductPinion
- [ ] Wonka logged the experiment as running; `status.md` updated
- [ ] You are leaving it alone while it fills

## Common Episode 9 questions

**"I'm pre-launch, I have no live image. What is my incumbent?"**
Use your best competitor's main image as the benchmark instead, and tell Wonka so it is labeled correctly in the analysis. You are entering their shelf; beating the image buyers currently choose from is the honest bar.

**"Can I test secondaries or A+ the same way?"**
Yes, and after the bootcamp you should; the Poll Room is not main-only. The bootcamp tests the main first because it is the highest-leverage single asset and the cleanest to survey (one grid, one click).

**"How many respondents do I need?"**
Wonka proposes a sample size with the cost estimate. Bigger samples cost more and wobble less; for a 3-way main image test, the default he proposes is a sensible floor. If the result comes back razor-thin, that is a finding too, and round 2 exists for exactly that.

## Troubleshooting note

If ProductPinion rejects the survey, it is usually an image with readable pricing, a policy-flagged claim, or identifying seller info; tell Wonka the rejection reason verbatim (`ProductPinion rejected the survey: [reason]. Fix the package.`) and he will strip the offending element and rebuild. If the MCP will not respond, restart Claude completely and re-verify per `guides/mcp-setup-guide.md`, Part 2. If the cost estimate looks wrong, check the audience size and screening; tighter targeting costs more per response and is usually worth it. Everything else: `guides/troubleshooting.md`.

Next episode, the shoppers have spoken: you read the votes AND the why-comments, Wonka refines the winner from what real buyers actually said, and a data-driven challenger enters round 2. "The shoppers have spoken. I merely work here." That sentence is the next episode's whole religion, and it is a genuinely great religion to run a business on.

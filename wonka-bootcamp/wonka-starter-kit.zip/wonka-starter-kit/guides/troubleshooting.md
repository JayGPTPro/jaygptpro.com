# Troubleshooting

The most likely failures, in the order people usually hit them. Each one: symptom, cause, fix.

## 1. Wonka sounds like a generic chatbot

**Symptom:** flat answers, no character, no mention of the Factory.
**Cause:** the kit folder is not actually loaded, so `CLAUDE.md` and the character file never reached Claude.
**Fix:** in Claude Desktop, confirm you are in the **Code** tab and the folder picker at the bottom shows `wonka-starter-kit`. Re-open the folder if not. Then start a NEW conversation (character loads at session start). If he drifts mid-session, say: `Reload .claude/wonka-character.md and stay in character.`

## 2. Slash commands do nothing

**Symptom:** you type `/creative-brief` and get a generic answer, or nothing skill-shaped happens.
**Fix:** type the command as its own message, starting with the slash, exactly as named: `/meet-my-product`, `/creative-brief`, `/main-image`. Describing it in prose ("run the recipe thing") sometimes works, the slash always works. If the command is not recognized at all, the `.claude/skills/` folder did not come along; re-download the kit and re-open it.

## 3. I cannot see the .claude folder

**Symptom:** the guides mention `.claude/` but your file browser does not show it.
**Cause:** folders starting with a dot are hidden by default.
**Fix:** Mac: in Finder, press **Cmd+Shift+.** (period). Windows: File Explorer, View tab, check "Hidden items". Or skip the file browser entirely: `Show me the contents of .claude/wonka-character.md`.

## 4. Genrupt or ProductPinion MCP is not listed / not responding

**Symptom:** Wonka says a connection (Genrupt or ProductPinion) is missing or calls fail.
**Fix, in order:** (1) Quit Claude COMPLETELY (Mac: Cmd+Q; Windows: quit from the tray icon) and reopen, then run `/machines-check`; a full restart fixes most MCP visibility issues. (2) Check the connector entry against the tool's current official instructions (see `mcp-setup-guide.md`, Part 1 for Genrupt, Part 2 for ProductPinion). (3) Re-generate the API key in that tool and re-enter it. (4) Log in to the tool's website in your browser once (genrupt.com or productpinion.com), then retry. Still stuck: post the exact error in the bootcamp group. Genrupt has a fallback (Wonka generates via OpenAI directly); ProductPinion only earns its keep in Episode 9, so you have time to sort it before then.

## 5. Generated images show the WRONG product

**Symptom:** wrong size, wrong cap, wrong label, glass that looks like plastic.
**Cause:** the Mold is not actually locked, or generation ran without it.
**Fix:** STOP generating (do not spend more credits on a broken lock). Say: `The mold isn't holding. Re-lock the product reference and give me a fresh smoke test.` Only continue batching after a smoke test image passes YOUR eyes. This is exactly why the smoke test is non-skippable.

## 6. Text in images is garbled or misspelled

**Symptom:** "Castoor Oil", broken letters, melted words.
**Cause:** image models redraw text unreliably, especially during heavy edits.
**Fix:** do not try to "edit the text into shape"; garbled text means regenerate. Say: `Route this image to regenerate with a tighter brief; the text is garbled.` For a single wrong word on an otherwise good image, a surgical text-swap edit usually works: `/fix` and describe the exact word change.

## 7. The image is too texty / fails the squint test repeatedly

**Symptom:** legibility keeps failing even after fixes.
**Cause:** too many labels competing; shrinking or nudging never fixes crowding.
**Fix:** subtraction, not adjustment. `Remove the two weakest labels and enlarge the headline.` One dominant message wins at 160px. Fewer words = bigger words = a passing image.

## 8. ProductPinion rejected my survey

**Symptom:** the survey comes back flagged or not approved.
**Cause:** usually a visible price on an image, a medical or policy-flagged claim, or identifying seller info.
**Fix:** tell Wonka the rejection reason verbatim: `ProductPinion rejected the survey: [reason]. Fix the package.` He will strip the offending element (or route the image through `/fix`) and rebuild the survey copy. Re-submit. Remember the survey is built and run inside Claude via the ProductPinion MCP; there is no external website for you to fix it on.

## 9. I do not have Brand Registry (no Manage Your Experiments)

**Symptom:** Episode 11's optional A/B step is unavailable for your account.
**Fix:** use the direct-swap path: upload the Taste-Test winner as your new main image, record the swap date plus your before metrics (sessions, unit session percentage) in `factory/Recipe Book/experiments.md`, and compare after 3 to 4 weeks. Less rigorous than a controlled A/B, but your survey already de-risked the change. Your Golden Ticket package is ready to upload either way. Consider starting Brand Registry enrollment in parallel; it unlocks the proper A/B for product two.

## 10. Costs anxiety: what should this actually cost?

Your first month of Genrupt and ProductPinion is included with the bootcamp. You only need your own Claude Pro or Max subscription and a few dollars of OpenAI credit for edits.

Typical spend for ONE product through the full line during the bootcamp:

| Item | Typical cost |
|---|---|
| Genrupt (generation, smoke test, full package) | $0 during the bootcamp (first month included, ~$99 value) |
| ProductPinion (one shopper survey) | $0 during the bootcamp (first month included, ~$97 value) |
| Surgical fixes via OpenAI (per edit) | ~$0.02 to $0.10, a few dollars total |
| Claude subscription | your own $20/month Pro or Max, separate from tool costs |

So during the bootcamp you only spend your existing Claude subscription plus a few dollars of OpenAI credit for edits. And the money rule: Wonka states a cost line and waits for one go-ahead before ANY paid run, edits included; if money moved without you approving it, that is a bug, tell him so.

## 11. Variation images look inconsistent

**Symptom:** your color/size/bundle images do not match each other: different light, angle, or staging across the set.
**Cause:** the Mold was not held for all of them, so the model re-staged each one independently.
**Fix:** the same fix that keeps your main image accurate keeps your variations consistent. Tell Wonka `These variations aren't a matched set. Re-generate them against the locked Mold so only the variable changes.` If a variation is a genuinely different physical product (a different bottle, not just a different color), it needs its own Mold and smoke test; say so and Wonka will set that up.

## 12. A+ module is cluttered or fails compliance

**Symptom:** an A+ module has competing messages, tiny text, or renders a badge/third-party logo as a graphic.
**Fix:** A+ follows the same laws as every other asset. For clutter: `Module [N] has too many messages. Cut it to one dominant message and enlarge the text.` For a rendered badge or logo (a compliance fail): `Remove the badge/logo graphic from module [N]; only real claims from the approved list.` A comparison module is fine and often high-converting; a wall of tiny icons is not.

## 13. Claude usage limits (Pro vs Max)

**Symptom:** "You've reached your usage limit" mid-session.
**Fix:** limits reset every few hours; note where the line stopped (`status.md` has it) and resume after the reset, Wonka picks up exactly where he left off. Hitting limits often? The generation episodes (6 to 8) are the heavy ones; run them in a fresh usage window, or upgrade to Max for more headroom. The bootcamp itself fits comfortably in Pro for most people.

## 14. Where are my files? / Wonka says a file exists but I cannot find it

**Fix:** everything lives inside the kit folder. Products: `factory/Products/[product-name]/` (images in `images/`, scorecards in `scorecards/`, tests in `tests/`). Brand kit: `factory/Brand/`. Reports: `factory/Factory Log/`. Ready-to-ship exports: `output/`. Fastest way: `Give me the full path to [the thing], and open its folder.` And remember issue 3: dot-folders are hidden.

## 15. Wonka refuses to do something (skip research, invent a badge, batch without a smoke test)

**Symptom:** he declines, charmingly but firmly.
**Cause:** not a bug. The refusals ARE the method: no recipe no candy, no fake claims, no un-smoke-tested batches, no people in the main image.
**Fix:** if you genuinely need an exception (e.g. no time for photos, use Amazon images), say it explicitly and he will proceed WITH the risk recorded in your files. If he refuses something that seems clearly wrong to refuse, ask: `Which rule are you applying here, and where is it written?` Either you will learn the reason, or you will find a real bug worth reporting.

## 16. A session starts and Wonka has "forgotten" my product

**Symptom:** new conversation, no memory of the last session.
**Cause:** the folder was not open in this session, or `status.md` was never updated.
**Fix:** confirm the folder is open (issue 1), then say: `Read factory/Products/ and each status.md, and tell me where every product stands.` If the tracker was not updated after the last episode's work, tell him what happened and have him update it now. The rule that prevents this: every station updates `status.md` when it finishes.

## 17. Everything is broken and I am behind

Breathe. The bootcamp is designed so a lost episode is recoverable: every station's output is a file on disk, so nothing you completed is ever lost. Post in the bootcamp group with (a) the episode you are on, (b) the exact error or symptom, (c) a screenshot. Then do the smallest next step: one product, one station, one artifact. The Factory does not care that you were late; it cares that the line moves.

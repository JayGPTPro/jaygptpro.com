# Day 8: The Tasting Room

Everything until now was craft. Today is verdicts.

You end this day holding two Tasting Cards. About 100 AI tasters, each one conditioned on your real buyer, look at your main image candidates next to the image that is live on your listing right now, pick one, and write why. The same panel judges your new secondary set against your live gallery, set against set, then frame by frame. Both races run in one sitting, on your own OpenAI key, for a few dollars, and they finish in minutes.

You walk in with opinions. You walk out with two verdicts and a pile of objections in your buyer's own language. You do not mine those objections today. That is the next room, and it is the best one.

## What you will have by the end of this day

- Your two main challengers chosen **by you**, with Wonka's ranking as an input and your reason on the record
- **Tasting Round 1 complete, two races in one sitting:** the MAIN race (your 2 candidates plus your live incumbent) and the GALLERY race (your new secondary set against your live Amazon gallery), judged by about 100 demographic matched tasters
- Two Tasting Cards saved under `tests/`, each with `tasting-card.html`, `tasting-card.md`, `results.json` and the `config.json` that ran: verdicts with a stability tier, per image and per frame notes, and the recurring objections
- Two rows in `factory/Recipe Book/experiments.md` and an updated `status.md`
- A clear understanding of what this panel can tell you (direction plus objections) and what it cannot (real shopper proof, and never a sales promise)

**Time needed:** 45 to 60 minutes, both races included. Nothing fills overnight. The verdicts are in your hands before you stand up.

## What you need at hand

- Your gate-passed MAIN candidates from Day 5, with Wonka's ranking in `scorecards/`
- Your gate-passed SECONDARY set from Day 6. It races too
- **Your CURRENT live Amazon main image and your CURRENT live gallery, downloaded into the `incumbent/` folder** you created at the end of Day 7. If you skipped it, do it now. It takes three minutes and the day does not work without it
- `research/persona.md` from Day 2. The panel is built from it
- Your OpenAI key working. Run `/machines-check` if there is any doubt
- Python packages, once: `python3 -m pip install openai numpy python-dotenv pillow`

Genrupt is not used today. Nothing is generated in this room.

---

## Lesson 1: Opinions are not data, and picking the challengers

### The thesis

You have a favorite. Wonka has a ranking. Your partner has a favorite. A designer with twenty years of awards would have one too. None of that is data.

Nobody can look at two good images and know which one a stranger will click. That is not modesty, it is a measured fact: experts land barely better than a coin flip. Taste is real. Taste is not prediction.

Most sellers resolve this by shipping their favorite, which means the listing runs on an untested guess, at full traffic, for months, and nobody ever finds out what the other image would have done. The factory does something else. It asks.

### What the Tasting Room is, honestly

Read this part twice, because it is the integrity of the whole method.

Wonka builds about 100 tasters. Each one is an AI shopper persona conditioned on YOUR real buyer from the Research Room: age, gender, income, the situation she is buying in. Each taster reacts to your candidates in her own words. The engine never asks a taster for a score, it reads the free text and maps the meaning to a purchase intent (the SSR method), because asking directly collapses every answer to a polite "3". Then every taster faces a blind forced choice: all options side by side, shuffled, no labels, pick one.

That buys you two things, and they are worth a lot:

1. **Direction.** Which candidate pulls ahead, and how stable that lead is.
2. **Objection mining.** The specific doubts your buyer profile raises, in her words: "cannot tell how big it is", "looks like plastic", "too much text", "how much does it take to fill that". Those sentences are the raw material of the next room.

What it is NOT: proof from real shoppers. These tasters are language models playing shoppers. So two honesty rules apply to every Card, and you should hold Wonka to both:

- **A thin margin or a split panel means no clear verdict, in those words.** You do not ship a coin flip. You refine and re-taste.
- **For a real money decision, real shoppers are the gold standard.** If a whole brand's packaging or your top seller's hero image hangs on the answer, run a real shopper poll on the finalists. That is the optional Pro Move bonus, not a bootcamp requirement.

A directional verdict plus real objections, instantly, for a few dollars, is a spectacular trade. Just never let anyone, including Wonka, dress it up as real shopper data. And nothing here promises a sales lift. Results vary by product and niche.

### The panel is only as good as the persona

The tasters are built from `research/persona.md`, using your buyer's REAL age. Not the aspirational casting age you used for the models inside your images. That skew belongs to who is shown, never to who judges.

If you have a Brand Registry demographics export for your ASIN, your persona is real and your panel is sharp. If you do not, Wonka works from an honest derived persona and labels it estimated. That is exactly what happens in the videos: the demo listing is not ours, so there is no export behind it, and the persona is derived from the reviews and the category. An estimate labeled as an estimate still beats your own reflection in the monitor. If `persona.md` is missing entirely, the engine falls back to a general shopper default and prints a note saying so.

### The incumbent rule

The iron rule of this factory's testing: **your current live Amazon image is always in the lineup.**

Your candidates do not compete in a vacuum. They compete against the image that is earning clicks on your listing right now. A test between only your own drafts tells you which draft is least weak. It cannot tell you whether ANY of them deserves to replace what is live.

And if the incumbent wins, that is not a failure. That is the panel stopping you from replacing a working image with a prettier, weaker one, for a few dollars instead of two months of lost sales.

The same rule powers the second race. Your new secondary set does not get graded alone, it races your live gallery, set against set.

---

## Lesson 2: /tasting-room, the panel and the run, both races

One command builds both races, quotes the cost, and stops. You approve, it runs, two Cards land. The rules baked into that config are the reason to trust the direction it points:

- **Blind and shuffled.** Every taster sees the options in a different order, and no label says new, ours, current or live. A taster who can smell which one you made is not a taster, it is a mirror.
- **A neutral question.** "Which product would you click." Six words, nothing leading. Leading questions produce flattering garbage even from AI tasters, and you would be paying for the flattery.
- **The incumbent mapped separately,** so reality is in the race without being announced.
- **Persona conditioned,** on the real buyer age.
- **One model by default.** If you also have a Gemini key in your `.env`, Wonka will suggest a two model mix and tell you why in one line: one model carries one private taste, and two model families disagreeing with each other is a better referee than one family agreeing with itself. Suggested, never required.
- **The cost is quoted before anything runs.** This factory shows you the number and waits, every time.

---

## MISSION 1: Pick your two challengers (the human moment)

Wonka's ranking is a recommendation. It scores craft and compliance, not "which one would I click".

```
Show me the gate-passed main candidates from the scorecard, ranked, with one line on each concept's strategy. I am picking the two challengers for Tasting Round 1, against the current live image.
```

Pick 2. With the incumbent that makes a clean three way test. You may absolutely override his number one:

```
I am taking candidates [X] and [Y] to the Tasting Room. [Y] over your rank-2 because [your reason, in your own words]. Record the pick and the reason in status.md.
```

Say the reason properly. It gets written into `status.md`, and when the Card lands, that sentence becomes learning material: your instinct, converted into evidence, in either direction. In the videos Jay overrides Wonka and loses on camera, which is the most useful thing that happens all day.

**Why only 2?** Votes split across too many options produce mush. Two strategies against reality give a readable verdict and readable notes. The losing angle is not wasted either. The next room turns its objections into a challenger.

**You cannot put a gate-FAILED image in the race.** A fail gets fixed first.

## MISSION 2: Convene the panel (both races)

```
/tasting-room

Round 1, two races, same sitting.
MAIN race: my two challengers plus the live main image in incumbent/ as the incumbent.
GALLERY race: my gate-passed secondary set against the live gallery in incumbent/. Set verdict plus frame by frame.
Panel conditioned on research/persona.md, about 100 tasters. Show me the config and the cost before anything runs.
```

He will ask you to confirm the EXACT files, by name. Confirm them properly, do not wave it through. If three versions of an image sit in that folder, which one runs is your call, never his guess. **Repaired files count double here:** a `_fixN` or a `-v2` sitting beside its original means the original is the broken one, and tasting it is the easiest few dollars you will ever waste, because the Card gives you no way to notice.

He will also point at your `incumbent/` folder for the live main image and the live gallery. This is the moment they are needed.

Then he shows you both configs, saves each as `config.json` in its round folder, quotes the cost, and stops.

## MISSION 3: Approve and run

Read the cost line. Then:

```
Approved. Run Tasting Round 1, both races.
```

A live progress page opens in your browser and refreshes itself while the panel works. A full run takes about 3 to 6 minutes per race.

**If it stops for any reason** (the laptop sleeps, the connection drops, you close the terminal), run the exact same command again. It resumes from its checkpoint. Nothing is lost and nothing is charged twice.

**A run that takes an hour is broken, not slow.** Stop it and run the same command again.

## MISSION 4: Read the verdict lines, then stop

Open each `tasting-card.html` in your browser. Look at exactly three things per Card, then close it:

1. **Who won,** named by filename.
2. **The stability tier.** The card resamples your recorded votes a thousand times and reports how often the winner held. **Clear lead** (95 percent or more): act on it. **Lean** (80 to 95 percent): a real lean, not proof, good enough to decide what to refine. **Toss-up** (under 80 percent, or the models disagreed): treat it as a tie, use the objections and ignore the shares.
3. **The vs incumbent line.** Did the winner beat reality, or only beat your other draft.

On the gallery Card the equivalent is the set level verdict line: which gallery would make them buy.

Then stop. Do not read the notes yet, and do not start fixing anything.

That is not ceremony. The verdict line is roughly half of what you just paid for. The other half is a few hundred tasting notes plus a frame by frame breakdown telling you which gallery frame carries the set and which one drags it, and mining that properly is a craft with its own room. Bring the Cards cold to the next room and you will get more out of them.

**One check worth doing now:** if a red data quality banner sits at the top of a Card (parse rates under 90 percent), some votes did not come back readable and the shares sit on a smaller sample. Re-run before trusting that percentage. It resumes and retries the gaps.

## MISSION 5: Log the round

```
Log Tasting Round 1 in the experiments log and status.md: both lineups, both verdicts with the stability tier, and where the Cards live. Do not summarize the tasting notes yet.
```

That writes the experiment rows (the Recipe Book learns from them on the last day) and updates your product tracker.

**Share it:** post "ROUND 1 TASTED" in the group with your three image lineup and your verdict line. Post it loudest if your own pick lost. "A hundred tasters in four minutes" is the sentence that makes people sit up, and the losses are the most useful posts in the group.

---

## What good looks like

- Three images in the main grid: two challengers and your live image. Not two, not five.
- Your override reason written into `status.md`, in a sentence you would defend out loud.
- A neutral question, shuffled order, unlabeled options in the config.
- The panel conditioned on your real buyer age, with the source of the persona named: real export, derived estimate, or the general default.
- Both Cards present, with the `config.json` that produced them sitting beside each one.
- A verdict presented WITH its tier, never a bare percentage.
- Objections that are specific. "Cannot tell how big it is" is workable. A Card with no recurring objections at all deserves a raised eyebrow, tell Wonka to dig into the notes again.
- Two experiment rows logged, `status.md` updated, and the notes still unmined.

## When it goes wrong

**"OPENAI_API_KEY is missing."** The key goes in the `.env` at the factory root, from Day 1. See `guides/mcp-setup-guide.md`, Part 2.

**The run stops part way.** Same command again, it resumes. Changing the images, the panel size, the models or the seed resets the checkpoint on purpose. Adding a comparison to a previous round does not.

**A red data quality banner, or a console warning about parse rates.** Some votes came back unreadable. Re-run before acting on the percentages, and treat that Card as weaker evidence until you do.

**"gemini models need GEMINI_API_KEY."** Either add that key to your `.env` or drop the model mix and run single model. Single model works fine, it is the default.

**Missing Python packages.** `python3 -m pip install openai numpy python-dotenv pillow`, once. On Windows use `python` instead of `python3`.

**The verdict came back Toss-up.** You did not waste the round. You learned that neither candidate clearly beats reality yet, for a few dollars, and the objections tell you what to sharpen. That is exactly what the next room does with it.

**The incumbent won.** Genuinely good news, and cheap news. You just avoided replacing a working image with a prettier weaker one. The next room refines your best candidate from the objections and races it again.

**Your own pick lost.** Welcome to the club, Jay is in it on camera. Read your losing candidate's "what hurt" chips before you feel anything about it. The loser's objections usually explain the winner.

**A taster objection contradicts your research.** Record it, do not act on it. A synthetic objection that fights real evidence goes into the test file as a note, never into a fix. That rule is what stops the panel from quietly overwriting the work you did in the Research Room.

Everything else: `guides/troubleshooting.md`.

## Definition of Done for Day 8

- [ ] Two main challengers picked by you, with the reason recorded in `status.md` if you overrode the ranking
- [ ] Your live main image and live gallery downloaded and used
- [ ] `/tasting-room` ran with your cost go-ahead: Tasting Round 1 complete, BOTH races
- [ ] The incumbent was in the main lineup, and the live gallery was in the second race
- [ ] Two Tasting Cards exist under `tests/`, each with `tasting-card.html`, `tasting-card.md`, `results.json` and `config.json`
- [ ] You read each verdict line, its stability tier, and the vs incumbent result, and you stopped there
- [ ] Each verdict was called honestly: Clear lead, Lean or Toss-up, in those words
- [ ] Both races logged in `factory/Recipe Book/experiments.md`, `status.md` updated
- [ ] The tasting notes are still unmined. You are bringing them cold to the next room

## Common questions

**"I am pre-launch, I have no live image. What is my incumbent?"**
Use the strongest thing reality currently offers: your supplier's shot, your own best photo, or, if you are entering someone else's shelf, the main image of the competitor buyers are actually choosing. Same for the gallery race. Tell Wonka it is a stand in so the Card labels it correctly, and accept that the verdict is a little weaker for it.

**"Can I put all four candidates in the race?"**
Two plus the incumbent is the format, deliberately. Three options produce clean votes and readable notes, six produce mush. If you truly cannot choose, that is what the ranking is for, or run another round later. It is minutes and a few dollars. Never drop the incumbent to make room.

**"How much does a round cost?"**
Wonka quotes the exact number before you approve. A full panel of about 100 tasters is a few dollars per race. A lite taste, about a quarter of the volume, is under a dollar and takes a minute or two. Lite mode is for eyeballing the machine or a rough look at a set. Any real decision gets the full panel.

**"Are AI tasters a substitute for real shoppers?"**
No, and the factory never claims they are. They are a fast, cheap, surprisingly sharp directional signal plus an objection mining machine. For most image decisions that is exactly the evidence you need at the moment you need it. For a big money decision, run the optional real shopper poll on the finalists.

**"Can I test my A+ this way?"**
After the bootcamp, yes, the room is not limited to what Round 1 covers. Inside the bootcamp we race the main and the gallery, because those are the two highest leverage decisions on the page: the main wins the click, the gallery wins the sale.

**"Does a win here mean my sales will go up?"**
No. Nothing in this bootcamp promises a sales lift, and results vary by product and niche. A win means your new image beat your current one in a directional test with a hundred conditioned tasters, which is a far better position than shipping a guess. Real behavior gets measured by an A/B test on your own listing, and that is covered in the next room.

**"Why not skip ahead and read everything at once?"**
You can, and if you have the energy, roll straight into the next room. The only thing you should not do is start fixing images off a verdict line before the notes have been mined properly. The order matters, not the calendar.

---

Next room: the tasters have spoken, and now you act on the WHY. Wonka mines both Cards, refines the winner and your weakest gallery frame from the tasters' own words, builds a challenger out of what they praised, and Tasting Round 2 re-runs both races in the same sitting. Bring both Cards, unread past the verdict line.

"The tasters have spoken. I merely work here." That is the next room's whole religion, and it is a genuinely good religion to run a business on.

# Episode 8: The A+ Room

Third and final run of the quality loop, this time on your A+ content: the rich modules below the fold that close the buyer your gallery got interested. By the end of this episode you hold a complete detail page: main candidates, secondary set, and A+ modules, all off the same locked Mold and the same brand kit, all gate-passed. You will also learn the A+ format landscape, including the options most sellers never use: carousel modules, video modules, and Premium A+.

## What you will have by the end of this episode

- **A+ content modules generated from the recipe's A+ plan: the deeper brand and product story, best-practice layout**
- A scorecard on the A+ modules, inspected and fixed with the same loop as the images
- A working map of the A+ options available to you: standard modules, comparison, carousel, video, Premium A+
- A complete page across `images/` and `aplus/`, ready for the Tasting Room

**Time needed:** 60 to 90 minutes, including generation waiting time.

## What you will need at hand

- The approved `brief/creative-brief.md` (the A+ plan lives in it)
- The gate-passed main concepts and secondary set from the last two episodes
- The same locked Mold and brand kit (still nothing new to prepare)
- Your Brand Registry / A+ eligibility status, if you know it

---

## Lesson 1: A+ content, and why it earns its own room

A+ content (also called Enhanced Brand Content) is the rich section below the fold on your listing: modules with images and copy that the plain bullet points cannot carry. It is where you tell the brand story, show the product in context, walk through how to use it, and compare it honestly against the alternatives a buyer is weighing.

A+ follows the same laws as the rest of the Factory: one dominant message per module, big legible text, real claims only, and a layout that leads with the strongest hook. A **comparison module is welcome** here: showing a buyer why your product beats the obvious alternatives is one of the highest-converting modules you can run. What is never welcome: icon soup, walls of tiny text, and badges or third-party logos drawn as graphics.

One more reason A+ matters more than most sellers think: much of A+ is indexed and read on mobile as a long scroll. Modules that fail the squint test fail exactly where most of your buyers are.

## Lesson 2: The A+ menu (standard, carousel, video, Premium)

Amazon's A+ system is a menu, and knowing it helps you brief better:

- **Standard A+ modules** (available with Brand Registry): image-plus-text banners, four-image grids, comparison charts, tech spec tables. This is where your recipe's plan lives, and where this episode generates.
- **The comparison module**: a chart comparing your product against alternatives (often your own other products). High-converting when the comparisons are true and specific.
- **Carousel modules**: swipeable image sequences inside a module. They exist, and this episode shows you the option; know that content hidden behind a swipe gets seen less than content in the scroll, so put nothing critical ONLY in a carousel.
- **Video modules and Premium A+ (A+ Premium)**: larger modules, video embeds, interactive hotspots. Premium A+ has eligibility requirements that change over time (historically tied to Brand Story plus approved A+ history; check your Seller Central for current status). If you have it, it is significant real estate; the same one-message-per-module law applies at a bigger size.

Ask Wonka to map your menu:

```
Based on what you know of my account and Brand Registry status, which A+ options are open to me: standard, comparison, carousel, video, Premium? What would you use and what would you skip for this product?
```

He will reason it through and mark anything he cannot verify from here as "check in Seller Central".

## Lesson 3: The same loop, the same laws

By now the rhythm is yours: generate against the recipe, inspect against the standards, fix the cheap flaws, re-inspect. A+ modules go through exactly the same loop as the images did, with the same non-negotiables: one dominant message per module, legible at mobile scroll size, claims only from the approved list, no rendered badges or third-party logos, and the product in every module poured from the same locked Mold, so the whole page reads as one thing.

This is the third time you run the loop. Notice how much faster you are at it. That speed IS the skill this bootcamp teaches.

---

## MISSION 1: The A+ Room

```
/aplus
```

Wonka reads the A+ plan from your recipe, generates the modules, states the batch cost in one line, and waits for your go-ahead. Give it. Modules save to `aplus/`.

Review each module as it lands:

```
Show me the A+ modules one at a time. For each, tell me its one message and confirm it follows best practice (one dominant message, legible text, real claims only).
```

Push back where a module tries to do too much:

```
Module 3 has four competing messages. Cut it to one and move the rest.
```

If your recipe included a comparison module, check it says something true and specific:

```
Show me the comparison module. Confirm every claim in it is on my approved-claims list.
```

## MISSION 2: Inspect the A+ (scoped run)

```
/inspect scoped to the A+ modules only.
```

Same six dimensions, same 160px squint test (yes, on A+ too, that is where the mobile scroll lives), same compliance gate, plus a page-level check: does the A+ repeat what the gallery already said, or does it EXTEND the story? A module that re-states secondary 2 is a wasted module.

```
Page-level check: which messages does the A+ add beyond the image gallery, and is anything duplicated?
```

## MISSION 3: The Fixing Room

```
/fix
```

Same drill as the last two episodes: full fix list, edit vs regenerate routing, one cost line, one go-ahead, `_fixN` files beside originals, then:

```
Re-inspect the fixed modules and update the scorecard.
```

Typical A+ fixes: `Module 2's icon row has 6 icons. Cut to 3 and enlarge.` and `Remove the badge graphic from module 4; only real claims from the approved list.`

## MISSION 4: See the whole page

You now have the complete page. Step back and look at it the way a buyer will:

```
Show me the complete page in order: main candidates, then the secondary set, then the A+ modules. Tell me which recipe slot each fills, and give me your honest read: does the page tell one story top to bottom?
```

This is the first time you see the full package as a buyer would experience it. Note anything that feels off; you have one more natural fix window before the survey.

**Share the WOW:** post your full page (or a collage of it) to the bootcamp group. A complete, coherent product page, main, gallery, and A+, is the whole promise of this bootcamp made visible.

---

## Before the next episode (15 minutes)

The next episode is the Poll Room: real shoppers vote on your main image candidates through ProductPinion, from inside Claude. To arrive ready:

1. **Identify and download your current LIVE Amazon main image.** It goes into the survey as the incumbent, the image your candidates must beat. Save it where you can find it, or drop it into the product's `tests/` folder.
2. **Verify the ProductPinion MCP is still connected:** run `/machines-check`. You wired it in Episode 2; confirm nothing drifted.
3. **Start thinking about your two.** The survey takes 2 main candidates plus the incumbent. Look at your gate-passed concepts and form an opinion; the next episode you choose, and you may override Wonka's ranking.

## Definition of Done for Episode 8

- [ ] You know which A+ options your account supports (or have a note to verify in Seller Central)
- [ ] `/aplus` ran with your cost go-ahead: modules exist in `aplus/`
- [ ] Each module reviewed: one dominant message, real claims only, no rendered badges/logos
- [ ] `/inspect` ran scoped to the A+: scorecard in `scorecards/`, page-level duplication check done
- [ ] `/fix` ran on flagged modules: fixes as `_fixN`, originals intact, re-inspected to green
- [ ] You viewed the complete page top to bottom
- [ ] `status.md` shows the full package generated and gate-passed (main, secondary, A+)

## Troubleshooting note

If an A+ module renders a badge or third-party logo as a graphic, that is a compliance fail; have Wonka strip it now, not after the survey. If module text keeps failing the squint test, subtraction again: fewer labels, bigger message. If the module images drift off the Mold (a different-looking bottle in module 3), stop and tell Wonka `The mold isn't holding in the A+ modules. Re-check the lock and regenerate that module.` If Genrupt is not responding, restart Claude completely and check `guides/mcp-setup-guide.md`. Everything else: `guides/troubleshooting.md`.

Next episode: the Poll Room. Your candidates, your live incumbent, and real shoppers voting, all run from inside Claude. Opinions end where the next episode begins. "The shoppers have spoken. I merely work here."

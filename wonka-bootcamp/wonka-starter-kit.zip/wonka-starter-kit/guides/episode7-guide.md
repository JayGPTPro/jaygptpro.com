# Episode 7: The Secondary Images Room

Last episode you ran the quality loop on one image. This episode you run it on a SET: the full secondary gallery, the 5 to 7 images that win the sale once the main image has won the click. People finally appear, every image carries a different message, and you learn the discipline that separates a professional gallery from a pile of pictures: set-level thinking.

## What you will have by the end of this episode

- **A full secondary set generated from the recipe: each image carrying a single message, one emotional frame included**
- A set-level scorecard: every image scored individually AND the set judged as a whole
- Flagged images repaired via surgical fixes, with originals kept
- A gate-passed secondary gallery, ready for the A+ Room and the Tasting Room

**Time needed:** 75 to 100 minutes, including generation waiting time.

## What you will need at hand

- The approved `brief/creative-brief.md` (the secondary set plan lives in it)
- The locked Mold and brand kit (nothing new to prepare; this is the payoff of Episode 4)
- Your OpenAI key working (the Fixing Room runs on it)

---

## Lesson 1: Secondaries have a different job than the main

The main image wins the click. The secondaries win the SALE. A shopper who clicked is asking a series of silent questions: Will it work for my problem? Is it the right size? Is it good quality? Do people like me use it? What is in it? The secondary gallery answers those questions, one image per question.

That "one image per question" is the anti-clutter law from your recipe applied to a whole gallery: each secondary carries ONE dominant message, a benefit, a use case, a size/scale shot, a trust signal, an emotional lifestyle frame. An image trying to answer three questions answers none.

## Lesson 2: Set-level thinking (the whole is the product)

Here is the shift this episode teaches. A gallery is not judged image by image; a buyer swipes through it as one experience. Set-level failures are invisible when you look at pictures one at a time:

- **Two images share a message.** Both are fine alone; together they waste a slot a real question needed.
- **The same face appears twice.** Each image is fine alone; together they read as stock photography, and trust drops.
- **No emotional frame.** Every image is a competent spec sheet; the gallery never makes anyone FEEL the after-state.
- **A selling point fell off the map.** Every image covers something; nobody covers the table stake, and the buyer silently disqualifies you.

This is why `/inspect` this episode runs set-level checks on top of the per-image scores. The recipe planned the set; the inspection verifies the set survived generation.

## Lesson 3: People, cast correctly

Secondaries are where people appear (never the main), and casting is where generated galleries usually embarrass themselves. Three rules, all baked into your recipe and enforced at inspection:

1. **Cast the real buyer**, not the imagined one. The persona from Episode 3 decides who appears.
2. **The aspirational skew.** From age 50, the displayed model looks about 5 years younger, scaling to about 10 years younger by 70. Vital and healthy, same life stage, still recognizably "me" to the buyer.
3. **A different person in every people-bearing image.** Image models love re-casting the same face; a gallery of one recurring model reads as fake. The recipe gave each slot a distinct casting note; the inspection fails a repeated face.

## Lesson 4: Legibility wins by subtraction

The most common defect this episode will be text: too many labels, too small to read. The counterintuitive fix is never "make the text bigger by shrinking other things". It is SUBTRACTION: fewer labels means bigger labels means a passing image. When an image fails the 160px squint test twice, the answer is `Remove the two weakest labels and enlarge the headline`, not another nudge. Fewer words win at thumbnail size, and mobile is where your buyers live.

---

## MISSION 1: Confirm the line, then invent the set

Quick check first:

```
Confirm we're clear to invent the secondary set: recipe approved, mold locked and smoke-tested, brand kit done, main concepts already gate-passed. Anything blocking?
```

Then the batch:

```
/secondary-images
```

The skill generates the full secondary set from the brief, one image per slot, and states the batch cost before spending.

Wonka states the one-line cost and waits. Give the go-ahead. Everything saves to `images/`. While the batch generates, re-read the recipe's secondary slots so you know each incoming image's job, and post your favorite gate-passed main concept from last episode to the bootcamp group if you have not yet.

## MISSION 2: Receive the set as a set

When the batch lands:

```
Show me the secondary set image by image, in gallery order. For each one, remind me which recipe slot it fills and what its one message is supposed to be.
```

Note your gut reactions but do not start fixing by hand; that is the Inspection Room's job, and it does it systematically.

## MISSION 3: Inspect the set (scoped run, set-level checks on)

```
/inspect scoped to the secondary set. Score each image on the six dimensions, and run the full set-level checks: message overlap, repeated faces, emotional frame present, selling-points coverage.
```

The scorecard saves to `scorecards/`. Read the set-level notes FIRST, then the per-image scores. The set-level section catches what no single image shows: two frames saying the same thing, the same face twice, the missing emotional frame, a selling point that fell off the map.

Interrogate anything vague:

```
Secondary 4 got "cluttered". What exactly fails the squint test, and what is the cheapest fix: subtract labels or regenerate?
```

And verify the coverage promise from the recipe survived:

```
Show me the selling-points coverage table against the generated set. Which points are covered, and did anything get lost in generation?
```

## MISSION 4: The Fixing Room

```
/fix
```

Wonka builds the full fix list across the set, routes each item (surgical edit vs regenerate; casting and layout problems are regenerate-territory, words and stray elements are edit-territory), and gives ONE total cost line. One go-ahead, then he runs the batch. Every fix saves as `_fixN` beside its original.

Typical fix requests this episode, so you see the range:

```
Shorten the headline on secondary 2 from 7 words to 4. Keep everything else.
```

```
Secondaries 3 and 5 have the same woman. Regenerate secondary 5 with the distinct casting from its recipe slot.
```

```
The scale shot doesn't read; the hand looks too large. Regenerate with a tighter brief on true proportions.
```

Then close the loop:

```
Re-inspect the fixed images and update the scorecard, including the set-level checks.
```

Repeat until the whole set is gate-passed. Two rounds is typical.

**Share the WOW:** post your full secondary set as one gallery strip to the bootcamp group. A coherent, message-per-image gallery is something most listings, including big brands, do not have.

---

## Before the next episode (10 minutes)

The next episode runs the same loop a third time, on your A+ content, and introduces the A+ format options (including carousel, video, and Premium A+). To arrive ready:

1. Re-read the recipe's A+ plan: the modules and each one's message.
2. Confirm this episode closed clean: `One-line status: is the full secondary set gate-passed in images/, with the set-level checks green?`
3. If you know your A+ eligibility (Brand Registry? Premium A+ available on your account?), note it; the next episode's options depend on it. Not sure? Wonka will help you check.

## Definition of Done for Episode 7

- [ ] `/secondary-images` ran with your cost go-ahead: full set in `images/`
- [ ] Every image fills its recipe slot with one dominant message
- [ ] `/inspect` ran scoped to the secondaries with set-level checks: scorecard in `scorecards/`
- [ ] Set-level checks pass: no message overlap, no repeated face, emotional frame present, selling points covered
- [ ] `/fix` ran on flagged images: fixes saved as `_fixN`, originals intact, re-inspected to green
- [ ] `status.md` updated with the secondary set done

## Troubleshooting note

If the same face keeps coming back across regenerations, the casting instruction needs to live in the specific image's brief, not the general request; tell Wonka `Put the distinct casting description inside the slot brief itself and regenerate.` If an image keeps failing legibility, subtract: `Remove the two weakest labels and enlarge the headline.` If the product drifts in any image (wrong size, plastic-looking glass), that is a Mold problem, not a fix problem: `The mold isn't holding on secondary N. Re-check the lock and regenerate.` Everything else: `guides/troubleshooting.md`.

Next episode: the A+ Room, the third and final run of the quality loop, on the rich content below the fold, where the deeper story closes the buyer. "The gallery gets them interested. The A+ gets them nodding."

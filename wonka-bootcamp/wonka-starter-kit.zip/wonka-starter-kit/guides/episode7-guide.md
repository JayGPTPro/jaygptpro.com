# Day 7: The A+ Room

Below the fold on every listing there is a second product page. Half your competitors left theirs empty. Today you build yours, and when it is done your product page is COMPLETE: main candidates, secondary gallery, and A+ modules, all poured from the same locked Reference Sheet and the same brand kit, all gate-passed.

This is the last building room. The loop runs one more time, and for the last time, because after today the work stops being craft and starts being proof.

## What you will have by the end of today

- **A full A+ module set, generated HANDS-OFF: Genrupt authors the page alone, on your locked reference and your branding preset. No content brief goes in**
- `aplus/aplus-plan.md`: the RUN record, the machine settings that were used, and a modules-as-generated table written AFTER export, describing what came out
- An A+ scorecard with the per-module verdicts AND the page-level read
- Flagged modules repaired with originals kept, and a gate-passed A+ set
- **A complete product page** across `images/` and `aplus/`, ready for the Tasting Room

**Time needed:** 50 to 75 minutes, including generation waiting time.

## What you will need at hand

- Your locked Reference Sheet with its passed smoke test, and your brand kit with its branding preset. The A+ is hands-off by house decision, so these two are the ONLY channels that shape it. Your brief carries one A+ line: which selling points are EXPECTED to land here, verified at inspection
- Your gate-passed main candidates and secondary set from the last two days, which stay untouched today
- Your OpenAI key working, because the Fixing Room runs on it
- Your Brand Registry and A+ eligibility status, if you know it. If you do not, it does not block anything today

---

## Lesson 1: What A+ does, and /aplus

A+ content, sometimes called Enhanced Brand Content, is the rich section below your bullets: image and copy modules that carry what a bullet point cannot.

Here is the strategic point, and it changes how you brief it. The shopper who scrolls that far is **interested and unsure**. She is looking for a reason to buy, or a reason to leave. A+ is where you answer her. If you do not answer her, she keeps scrolling into your reviews, and the answer she finds there was written by your angriest customer.

That is the whole argument. Your A+ exists to answer the objection before the reviews do.

And here is the house decision that changes how today runs: **the A+ is HANDS-OFF.** Wonka passes NO content direction into A+ generation: no module plan, no briefs, no headlines, no comparison rows. Genrupt decides the page alone, because A+ exists to be beautiful and impressive and Genrupt does that well, better than a page designed by committee through a prompt box. What you control are the machine settings (the reference lock, the branding preset, module count, concept count, mode, and the carousel switch, always off), and then the gate: **generate, inspect, fix.** Hands-off on the way in, ruthless on the way out.

So before you generate, go back to your research and ask one question anyway: **what is the number one thing buyers complain about in my category?** Not to brief it in, but because it is what you will look for at inspection: your brief marked which selling points are EXPECTED to land in the A+, and the inspection is where you verify they actually did.

### The six module jobs, and how to READ the generated page

A+ is a menu, and knowing the menu is how you judge what the machine ordered. Here is the story a strong A+ runs, hero to trust. Wonka sets the module count through the machine's own field: **6 by default** (the field accepts 6 or 7, and six is plenty).

1. **Hero or brand banner.** Your promise in one line, the product shown honestly. Not an "about us" paragraph.
2. **Benefit modules, two or three of them.** ONE benefit each. This is where most A+ falls apart: four benefits crammed into one module means none of them land.
3. **How it works, or what it is made of.** Shown accurately. For a lot of products this is the module that closes the sale.
4. **The comparison module.** Your product against the generic option or the old way, on the dimensions your buyer actually cares about. Its own rules below.
5. **Lifestyle or story.** The outcome your buyer is buying. People ARE allowed here, unlike your main image, and they should be different people from the ones in your gallery.
6. **Specs, trust or FAQ.** Real dimensions, real materials, real certifications, and the top genuine questions from your review research.

Judge each generated module against that menu: ONE job and ONE dominant message each, no two modules sharing a headline. Everything you learned about legibility applies unchanged, because A+ is read on a phone in a narrow column, and that is where it fails most. A module that misses the bar is not re-briefed; it is fixed or regenerated at the gate.

### The comparison module, and its rules

Genrupt may build a comparison chart on its own, and when it does, it is often the highest converting module on the page. What it really does is your shopper's homework. She is comparing you against something in her head right now. Your job is not to write it; your job is to hold whatever the machine wrote to these rules at inspection.

Four rules, none optional:

- **Real rows only.** Every row must be true and provable about YOUR product. "True" is not the bar, "provable" is. If your proof is "everyone knows", cut the row.
- **Never a named brand.** Compare against "the generic option", "typical alternatives", or "the old way". A named comparison invites a dispute even when you are completely right, and you gain nothing.
- **No prices, no discounts, no shipping claims.** Price and promotional claims do not belong in A+ content, and your modules stay up long after your price moves.
- **Do not invent losses for the other column.** A chart with one fabricated row poisons the whole chart.

### What we do not use

**No carousel modules.** Content hidden behind a swipe is seen by a fraction of the people who see content in the scroll. If a message is worth having, it belongs where she will actually see it. If it is not worth the scroll, it does not belong in your A+.

**Premium A+** is the same discipline at a bigger size, with its own eligibility rules on Amazon's side that change over time. If you have it, everything you build here translates upward. If you do not, standard A+ done well beats premium A+ done lazy every single time. Check Seller Central for your current status; nothing today depends on it.

## Lesson 2: The loop on a full page

You already know the loop. Generate, inspect, fix, re-inspect. You learned it properly on the main image and you stretched it over a whole set in the last room. It does not change today.

What changes is the OBJECT you are judging. A single image is judged alone. A set is judged as a team. A page is judged as a **scroll**, and that adds exactly four things:

1. **Order is now a variable.** Your gallery is swiped in any order. Your A+ is read top down and she stops somewhere. So your strongest module goes FIRST. Burying your best answer in module five is close to not having it.
2. **Every comparison row is a separate claim.** One image had one headline to check. Your chart has a dozen cells, and each cell is a public promise. The compliance sweep goes row by row.
3. **The duplication question flipped.** On the set you asked whether two images say the same thing. On the page you ask whether the A+ **extends** the gallery or just restates it. A module that repeats a secondary image is not a duplicate, it is a wasted module.
4. **A+ fails the squint test more than anything else you will make.** Because A+ feels like the place for MORE: more text, more icons, more explaining. Then it renders in a narrow phone column and turns into a grey smudge. Same 160px test, harder room.

That is all that is new. Everything else you already own.

---

## MISSION 1: Read the expectations, not a plan

Two minutes, and it sets up the inspection. There is no module plan to read, because nobody wrote one. What exists is the brief's A+ line:

```
Read me the A+ line from my brief: which selling points are EXPECTED to
land in the A+, and remind me the page itself is Genrupt's to design.
```

That list is your verification checklist for MISSION 4. If a point you care about is not on it, fix the brief's coverage map now, for free.

## MISSION 2: Generate the set, hands-off

```
/aplus
```

Wonka verifies the locked Reference Sheet and the branding preset, runs the free preflight, settles the machine settings with you (market analysis, mode, concept count, module count via the field, listing references), states the batch cost in one line, and waits. Give the go-ahead once. Modules save to `aplus/` with module-numbered filenames, and nothing overwrites anything.

**What good looks like in the read-back, before a credit is spent:**
- The hands-off line said plainly: no content direction goes in, Genrupt decides the page
- The reference lock and the branding preset named as the two channels that shape it
- The machine settings listed: 6 modules by default, 1 concept, desktop mode, carousel OFF
- Your listing images explicitly out of scope and untouched
- One cost line, one go-ahead

If the read-back contains a module plan, headlines, or any content direction, stop him there. Hands-off means hands-off, and prose smuggled into the machine makes the page worse, not safer.

## MISSION 3: Receive the page as a page

When the batch lands, look at it as a scroll first, not module by module.

```
Show me the A+ modules in page order, top to bottom. For each one,
tell me its apparent job and its one message, as generated. Then tell
me honestly: does this read as one story from hero to trust?
```

Note your gut reactions but do not start fixing by hand. That is the Inspection Room's job and it does it systematically.

## MISSION 4: Inspect the page

```
/inspect scoped to the A+ modules only. Standards per module,
mobile legibility first, compliance on every claim and every
comparison row, plus the page-level checks: module order, one
message each, whether the A+ extends my gallery or repeats it,
and whether the selling points the brief expected here actually
landed.
```

The scorecard saves to `scorecards/`. **Read the page-level section first**, then the per-module scores. The page-level section catches what no single module shows.

Interrogate anything vague:

```
Module 3 got flagged for density. Which exact words survive at
160px and which dissolve? Is the cheapest fix subtraction, or does
this module need regenerating?
```

And check your chart yourself, out loud, row by row:

```
Walk the comparison module row by row. For each row: what is the
claim, what is my proof, and would I be comfortable defending it
publicly? Cut anything I cannot prove.
```

## MISSION 5: The Fixing Room

```
/fix
```

Same drill you already know. Full fix list first, each item routed to edit or regenerate, ONE total cost line, one go-ahead, the round saved as a complete `edits/vN/` snapshot with your originals untouched.

The A+ fixes you will actually see, so you recognise them:

```
Cut module 2 from five benefits to three. Keep the strongest three
and enlarge them.
```

```
Remove the row I cannot prove from the comparison chart. Change
nothing else in the module.
```

```
Module 4 repeats what secondary 3 already said. Route it back to
the A+ Room as a structural defect: regenerate that concept, with
its own cost line.
```

Then close the loop:

```
Re-inspect the fixed modules and update the scorecard, including
the page-level checks.
```

Repeat until the A+ set is gate-passed. One round is typical here, two if your modules came out text-heavy.

## MISSION 6: See the whole page

This is the moment the building arc was for.

```
Show me the complete page in order: main candidates, then the
secondary set, then the A+ modules. For the listing images, tell me
which brief slot each fills; for the A+, what each module does as
generated. Does this page tell ONE story top to bottom, and is
there anything that fights the rest?
```

This is the first time you see the full package the way a buyer will experience it. Note anything that feels off, because you have one natural fix window left before the Tasting Room.

**Share the WOW:** post your full page to the group, main plus gallery plus A+ in one screenshot if you can manage it. A complete, coherent product page built off one brief and one locked reference is the entire promise of this bootcamp made visible, and most listings, including big brands, do not have one.

---

## Before Day 8 (10 minutes)

Day 8 opens the Tasting Room: about 100 synthetic tasters, AI shopper personas matched to your real buyer and not real customers, voting on your main image candidates against your live incumbent, and racing your new secondary set against your live gallery. To arrive ready:

1. **Download your CURRENT live Amazon main image and your live gallery.** The live main is the incumbent your candidates have to beat. The live gallery is the benchmark for the gallery race. Save them inside your product folder, in a new `incumbent/` subfolder, and leave `tests/` **empty**. `tests/` is where your Tasting Cards land, and Day 8 should open on an empty one. Wonka never guesses which files are in a race, so you point him at this folder when he asks.
2. **Run `/machines-check`.** The Tasting Room runs on your OpenAI key. Confirm nothing has drifted.
3. **Form an opinion about your two.** The round takes two main candidates plus the incumbent. Look at your gate-passed candidates and pick your favourite before anyone tells you the ranking. You are allowed to override Wonka, and knowing your own pick first is how you find out whether you should.

## Definition of Done for Day 7

- [ ] You read your brief's expected-in-A+ selling points before generating, and confirmed the run was HANDS-OFF: no content direction went in
- [ ] `/aplus` ran with your cost go-ahead: modules exist in `aplus/`, plus `aplus/aplus-plan.md` (the run record, with the modules-as-generated table)
- [ ] Every module, as inspected, has ONE job and ONE dominant message, and no two share a headline
- [ ] If the page carries a comparison chart, every row is true, provable, and about your product. No named brands, no prices
- [ ] `/inspect` ran scoped to the A+: scorecard in `scorecards/`, with the page-level section read
- [ ] `/fix` ran on the flagged modules: the round saved as a new `edits/vN/` snapshot, originals intact, re-inspected to green
- [ ] Your main candidates and secondary set are untouched
- [ ] You viewed the complete page top to bottom
- [ ] `status.md` shows the full package built and gate-passed, testing next: main, secondary, A+
- [ ] Live main image and live gallery downloaded into `incumbent/`, `tests/` still empty, `/machines-check` clean

## When it goes wrong

**A module renders a badge, an award, or a third-party logo as a graphic.** Compliance fail, and it comes out now, not after the Tasting Room. Real certifications are allowed only as they actually appear on your product's label.

**A module keeps failing the squint test after you shortened the text.** Keep subtracting, do not nudge. `Remove the two weakest labels and enlarge the remaining message.` Fewer words become bigger words become a passing module. If it still fails after two rounds, that module is doing two jobs and needs regenerating with one.

**The product looks wrong in a module** (wrong number of tiers, wrong material, wrong shape). That is a Reference Sheet problem, not a fix problem, and it is always a regeneration. `The reference is not holding in module 4. Re-check the lock and regenerate that module against the Reference Sheet.` Never try to edit a product correction in; product rendering is structural.

**Your A+ reads like your gallery again.** Ask directly: `Which messages does the A+ add beyond the gallery, and what is duplicated?` A duplicating module is a structural defect: route it back to the A+ Room for a regeneration of that concept, with its own cost line. The gallery says it in one glance; A+ gets to explain it.

**You want more modules.** The count is a machine setting, not a wish: 6 by default, and the field accepts 6 or 7. Module count is not the metric, and content never travels in prose. If the page is missing a message you care about, say so at inspection and let the regeneration carry it structurally.

**Genrupt stalls partway through the batch.** Modules save individually and nothing overwrites, so re-run only the module numbers that are missing. If Genrupt is not responding at all, restart Claude completely and check `guides/mcp-setup-guide.md`.

**Everything else:** `guides/troubleshooting.md`.

---

Next: the Tasting Room. Your candidates, your live incumbent, your gallery against the one that is running right now, and about a hundred synthetic AI tasters voting, all from inside Claude with a directional verdict in minutes. Everything you have built so far is craft. "The building is finished. Now we find out whether anybody likes the taste."

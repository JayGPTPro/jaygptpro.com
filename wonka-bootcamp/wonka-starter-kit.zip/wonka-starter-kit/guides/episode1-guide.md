# Day 1: The Front Gate

Today you cut five keys, hire your Creative Director, warm up his two machines, and pack the basket
your product walks in with. Nothing here is hard. A few things are easy to skip, and one of them
(the OpenAI organization verification) will cost you an evening later if you skip it, so it is first
in line.

By the time you close the laptop tonight, the factory is live and Day 2 opens with a single command.

## What you will have by the end of this day

- Claude installed, with the kit folder open, and Wonka answering in character
- A Genrupt account, activated (usage included with your ticket)
- An OpenAI API key created, funded, and its one time organization verification underway or done
- Your pilot product chosen and photographed properly
- Both machines connected and verified by Wonka himself, with your credit fuel gauge read out loud
- Your factory's First Candy printed: a welcome card that cost a few cents and proved your whole
  image pipeline works
- Your first `/factory-report`, run on an empty floor
- One inputs folder on your Desktop holding everything the Front Gate will demand on Day 2

**Time needed:** about two hours, and most of it is waiting for downloads and taking photos. The
video is 28 minutes across three lessons.

**A word on cost before you start.** Genrupt usage is included with your ticket. You bring your own
Claude Pro or Max subscription, which is separate, and your own OpenAI credit for the image edits and
the Tasting Rooms: cents per edit, a few dollars per race, and the bootcamp runs four races (two
Tasting Rounds, two races each). Ten to twenty dollars covers it. That is the entire bill. There is no survey tool to buy
and no research extension to install, because the Tasting Room runs inside the factory and the
Research Room runs on your own listing, reviews, and competitors.

---

# PART 1: Cut the five keys

About 45 minutes, most of it waiting.

## Key 1: Claude Pro or Max, plus the app

1. Go to [claude.ai/download](https://claude.ai/download) and install **Claude Desktop** (Mac or
   Windows). If you already live in **Claude Code** in the terminal, that works identically;
   everything in this bootcamp runs in either.
2. Open Claude Desktop, click your profile icon (bottom left), and confirm you are on **Pro ($20 per
   month) or higher**. The free plan does not include the Code tab or Skills, and the factory needs
   both.

**Pro or Max?** Pro is enough for the bootcamp. Max gives you more daily usage and fewer interruptions.
If you plan to run several products a week after this, Max earns its keep. Start with Pro if unsure.

## Key 2: The kit, on your Desktop

1. Download `wonka-starter-kit.zip` from the portal (link also in your welcome email).
2. Unzip it. Mac: double click. Windows: right click, "Extract All".
3. Drag the `wonka-starter-kit` folder to your **Desktop**, so you always know where it lives.
4. Open Claude Desktop, click the **Code** tab (top center), click the folder picker at the bottom of
   the chat input, choose **"Open folder..."**, and select `wonka-starter-kit`.
5. **Stop there. Do not type anything yet.** The first hello belongs to Part 2, and it doubles as
   your proof that the folder loaded.

**Take one minute to look inside `factory/` while you are here.** This is not decoration, it is the
whole employee:

| Folder | What lives there |
|---|---|
| `Products/` | One folder per product you run. Empty today. |
| `Brand/` | Your brand's wrapper: colors, fonts, tone, approved claims. |
| `Recipe Book/` | What actually converts in your market, learned from your own tests. |
| `Wonka's Notebook/` | How Wonka does his own job better. He reads it at the start of every session. |
| `Factory Log/` | Status reports. |

Wonka is not installed anywhere on your machine. He IS this folder. Copy it and you have copied your
Creative Director.

## Key 3: Your Genrupt account (signup only today)

Genrupt is the Inventing Room's main machine. It locks a reference of your real product and generates
listing images, A+ modules, and variations around it.

1. Create your account at [genrupt.com](https://genrupt.com) using the bootcamp signup link from the
   portal, and activate it with the code or link in your welcome email. **Genrupt usage for the
   bootcamp is included with your ticket.**
2. Confirm your account shows image generation credits.
3. That is all for today. The connection into Claude happens in Part 2, with Wonka checking his own
   machine while you watch.

**No Genrupt for some reason?** The factory still runs. Wonka falls back to generating directly on
the OpenAI image model. Product accuracy is weaker without the locked reference and he will mark that
honestly in your files, but every day of the bootcamp remains doable.

## Key 4: Your OpenAI API key, and the verification that bites later

One key, two rooms. Surgical image edits run on it (cents per edit), and so does the Tasting Room's
panel of about a hundred AI tasters (a few dollars per race, and each Tasting Round is two races).

1. Go to [platform.openai.com](https://platform.openai.com) and log in or sign up. This is separate
   from a ChatGPT subscription.
2. Profile menu (top right), then **API keys** (direct: platform.openai.com/api-keys).
3. Click **"Create new secret key"**, name it `wonka-factory`, click Create.
4. **Copy the key immediately.** It starts with `sk-` and you will never see it again. Park it in a
   password manager or a note for the next twenty minutes.
5. **Settings, then Billing.** Add a payment method and load **$10 to $20**. For most people that
   covers every edit and all four Tasting Room races of the whole bootcamp: cents per edit, a few
   dollars per race, two races in each of the two rounds.
6. **Settings, then Organization, then Verify.** This is the one time organization verification, and
   until it clears, your key can talk but it cannot draw. **Start it now, in your first ten minutes.**
   It can take a while to clear and it is the only item on today's list that can make you wait.

You wire the key into the kit in Part 2, and you prove it works in the same sitting.

**Never screenshot your key, never paste it in the group.** If it ever appears somewhere public,
revoke it on the API keys page and create a new one. That takes thirty seconds.

## Key 5: Your pilot product, and real photos of it

Pick **ONE** product for the bootcamp. Not three. One.

Good criteria, in order of preference:

1. **A live ASIN whose images you can change.** You own the listing and can upload new images. This
   unlocks the full journey including the optional Amazon A/B at the end.
2. **Any live ASIN of yours**, even if image changes are slow to roll out. You still get the full
   research, generation, testing, and a ready to upload set.
3. **A pre launch product you physically have.** No live listing yet. You skip the incumbent
   comparison, everything else works.

Avoid a product you plan to kill, one with an unresolved listing suppression, or a niche you are
about to exit. The factory works. Aim it at something that matters.

**Then photograph it. This is the step people skip and pay for later.**

Phone photos are fine. Natural light near a window, plain background, no filters.

- [ ] Front, straight on
- [ ] Back, with the full label readable
- [ ] Left side and right side
- [ ] Top down
- [ ] Close ups of the label: seals, certifications, ingredient text, brand mark
- [ ] **One shot of the product held in your hand**

That last one is not a nice to have. It is how the factory learns your product's true size, and size
is one of the most expensive things to get wrong in a listing image. Save everything in one folder
you can find again.

**If you genuinely cannot photograph it** (the unit is at a warehouse, or you are running a product
you do not physically hold), the fallback is the listing gallery plus customer review images. It is
legitimate, Wonka records the reference as built from scraped imagery, and product accuracy is
weaker. He will say so out loud rather than pretending. Shoot real photos the moment you can.

**What good looks like at the end of Part 1:** five ticked boxes, a kit folder open in Claude with
zero messages sent, and a photo folder that includes a hand.

---

# PART 2: Meet Wonka and wire the machines

About 25 minutes.

## Say hello (this is also your kit test)

In the Claude session with the kit folder open, type:

```
Hello! Who are you and what is this place?
```

You should get Willy Wonka, your AI Creative Director, with some theater, a mention of the factory
and its rooms, an accurate note that the factory is currently empty, and an offer of the next step.

**If the answer sounds like a normal chatbot, the folder did not load.** Confirm the Code tab's
folder picker shows `wonka-starter-kit`, re open it, and start a NEW conversation. The character
loads at session start, so an old session will not pick it up.

While you are here, ask him for the tour:

```
Give me a tour of the factory folder. What lives where, and which files
will you read at the start of every session?
```

## Try to skip the line

This is the two minutes of Day 1 that most people remember. Ask him for what every other AI tool on
the planet would happily give you:

```
Skip all the research stuff. Just make me 8 beautiful images for my
product right now.
```

He will refuse. Politely, with a joke, and completely. Something in the register of "no recipe, no
candy," followed by why: images built without research are guesses wearing makeup.

That refusal is the product. Any tool can generate. This one will not generate blind.

**The five stations, in order, so you know what he is defending:**

| Station | What happens |
|---|---|
| RESEARCH | What the niche demands, what buyers complain about, what nobody is showing |
| BRIEF | One brief for the whole package, every asset with one job |
| INVENT | Generation, from a locked reference of your real product |
| INSPECT | Nothing ships uninspected. Every image scored and squint tested at phone size |
| PROVE | About a hundred AI tasters vote, and the winner has to beat the image that is live right now |

Skip one and you get the shiny garbage the rest of the internet calls AI images.

## Wire machine 1: Genrupt

Open `guides/mcp-setup-guide.md` and follow Part 1. Short version:

1. Claude Desktop, **Settings**, then **Connectors**, then **"Add custom connector"**.
2. Paste the connection values from Genrupt's own current instructions (they keep them up to date in
   your Genrupt dashboard under Settings or Integrations, and the portal keeps a pinned link).
3. Save, then **quit Claude completely and reopen it.** Mac: Cmd+Q, not just closing the window.
   Windows: right click the tray icon and quit.

That last step is not optional. A connector that does not appear is almost always a Claude that was
never fully quit.

## Wire machine 2: your OpenAI key

Hand the key to Wonka rather than hunting for a settings page. In the chat:

```
Create a .env file in this folder with my OpenAI key, and make sure the
folder's setup keeps it private. The key is: sk-[paste your key]
```

The `.env` file stays on your machine. Never screenshot it.

Prefer system settings instead? Set an environment variable named `OPENAI_API_KEY`. Both work, the
`.env` is easier.

## Let him check his own machines

Now the part that makes this different from every setup guide you have followed before. Do not verify
the machines yourself. Ask the employee who uses them:

```
/machines-check
```

He runs a real, free handshake on each machine and reports back in a table:

- **Genrupt**: a live account call, plus your **credit balance**, reported as the factory's fuel
  gauge. You will see that number before every production run.
- **OpenAI**: the key confirmed present.

Every machine comes back PASS, FAIL, or SKIPPED with a reason, and every FAIL carries the exact fix
plus where in the setup guide to find it. Nothing is reported as working on hope.

**Remember this command.** Every "it is not working" problem you hit in this bootcamp starts here.
Run `/machines-check` first, then debug.

## The First Candy

A handshake cannot prove one thing: whether OpenAI will actually let your key MAKE an image. That is
the organization verification from Key 4, and there is exactly one way to know it took. Generate
something.

Wonka will offer, with the cost stated first. Say yes:

```
Yes, print the First Candy.
```

He prints one small welcome card reading "Welcome to the Bootcamp", saves it to
`output/first-candy.png`, and shows it to you. It costs a few cents and it proves the entire pipeline
end to end: key, billing, verification, generation.

**If it fails with a verification error, that is this step doing its job.** You found out on Day 1,
with the fix one click away, instead of on Day 5 in the middle of your main image batch. Finish the
verification at platform.openai.com under Settings, Organization, then run `/machines-check` again.
Nothing on Day 1 or Day 2 is blocked while you wait.

Post your first candy in the group. It is your factory's first print.

**What good looks like at the end of Part 2:** two machines reporting PASS, a credit number you have
seen with your own eyes, and a PNG on disk at `output/first-candy.png`.

---

# PART 3: Pack the basket for the Front Gate

About 30 minutes, and it decides how good Day 2 is for you.

## Walk the empty floor

```
/factory-report
```

This is the "what is the status" command. Which products are on the line, what is done, what is
blocked and on whom, and the single next action. Today the answer is charming and nearly empty:
machines warm, first candy printed, zero products on the line, next step the Front Gate.

From Day 2 on, this is how you walk back into the factory after a day away. It is free, it is
read only, and you can run it any time.

## Get the shopping list from the gatekeeper

Day 2 runs ONE command: `/meet-my-product`. Your product checks in, and then Wonka does something
most tools would never do. He hands you a shopping list of inputs and refuses to move until it is
full. So get the list a day early:

```
Wonka, next session I'm bringing my product through the Front Gate with
/meet-my-product. What exactly will you need from me? Give me the
shopping list in advance so I come prepared.
```

He will preview it in character. The shape of it:

| Slot | What he wants |
|---|---|
| Identity | Your ASIN and full listing URL, or a product description if you are pre launch |
| Reviews | Your top ten positive and ten critical reviews, saved as a file |
| Competitors | Three to five competitor ASINs or URLs, or full gallery screenshots |
| Photos | Your real product photos: all angles, hand for scale, label close ups |
| Owner intel | What only you know (see below) |
| Optional | Brand Registry ASIN level demographics, and any keyword or search term data you already have |

Look at that list again. Every item is something you already own. No report to buy, no extension to
install, no export to hunt down.

And notice the attitude behind it: he will WAIT at the gate rather than fake research he has no
inputs for. That is the Definition of Done culture in this factory. A station is not finished because
it feels finished. It is finished when the real files exist.

## Write down your owner intel

One slot on that list is not a file. It is you. Three questions, answered in your own words, jotted
anywhere you will find them on Day 2:

1. **What do you already KNOW works for this product?** Past winners, images that converted, angles
   customers respond to, things people say on the phone that never made it into the listing.
2. **What MUST appear in the images?** A certification on the label, a signature feature, a claim you
   are allowed to make.
3. **What must we AVOID?** A claim legal made you drop, an angle that flopped, a comparison you do
   not want to invite.

On your own product this is the richest input in the room, because no listing page contains it. If a
slot is genuinely empty for you, write "nothing" rather than inventing something. Wonka would rather
have an honest gap than a decorated one, and he labels anything he derives from thin input as
estimated.

## Decide your niche phrase, word for word

Your niche, in your own words. "Garlic press." "Dog paw balm." "Cast iron grill press." "Chocolate
fountain."

This matters more than it looks, because the phrase decides which competitors count, and the
competitors decide what counts as a table stake in your market. A forty five dollar four tier party
fountain and a nineteen inch, six pound machine that serves thirty to forty people at a hundred and
sixty five dollars are not the same shelf, even though the search results mix them together. One
wrong niche competitor poisons the whole analysis.

Write your phrase down. You confirm it at the gate on Day 2.

## Pack one folder

Everything in one place, on your Desktop, named something obvious like `[product]-inputs`. On Day 2
you hand Wonka this folder in one motion, and the product gets its own factory folder with all of
this moved in. Three things inside it:

```
[product]-inputs/
  reviews.txt
  competitors/
  photos/
```

**1. Your reviews, in `reviews.txt`.** Top ten positive and top ten critical, copied into one text
file.

One warning that will save you a weak analysis: the public listing page shows only a handful of
reviews and skews them positive. Copy them while **logged in** on Amazon, sorting by **most recent**
and by **critical**, or pull them from Seller Central for your own product. The critical ones are the
gold. They are your customers writing your image brief for free.

**2. Your competitors, in `competitors/`.** Three to five, genuinely in your niche, and genuinely the
ones taking your sales rather than the flattering ones. Screenshot their full image galleries in
there, and drop a plain text file of their listing URLs beside the screenshots so Wonka can open them
himself.

**3. Your product photos, in `photos/`.** The ones from Key 5, moved in.

**4. Optional: your demographics.** If you have Brand Registry, export your ASIN level Brand
Analytics demographics into the folder. Your persona gets real buyer ages instead of niche averages.
If you do not have it, skip it. Wonka estimates honestly and labels the estimate as an estimate.

**What good looks like at the end of Part 3:** a folder you could hand to a stranger, and they would
know what your product is, who complains about it, and who you are competing with.

---

## When it goes wrong

| Symptom | Cause | Fix |
|---|---|---|
| Wonka sounds like a generic chatbot | The kit folder is not really loaded | Code tab, folder picker shows `wonka-starter-kit`, re open it, start a NEW conversation |
| A slash command does nothing | It was described instead of typed | Type it as its own message, starting with the slash, exactly as named: `/machines-check` |
| The Genrupt machine does not appear at all | Claude was not fully quit | Cmd+Q on Mac, tray icon quit on Windows, reopen, run `/machines-check` again |
| Genrupt connects but calls fail | Session or key issue | Log in to genrupt.com in your browser once, retry. If it persists, regenerate the API key and re enter it |
| First Candy fails with a verification error | Organization verification has not cleared | platform.openai.com, Settings, Organization, Verify. Then `/machines-check` again. Nothing is blocked meanwhile |
| "No API key" | The key is not where Wonka looks | Re run the `.env` step in Part 2, then `/machines-check` |
| You cannot see the `.claude` folder | Dot folders are hidden | Mac: Cmd+Shift+. in Finder. Windows: File Explorer, View tab, Hidden items. Or just ask Wonka to show you what is in it |
| Your listing shows only about eight reviews | The public page hides most of them | Log in and sort by most recent and by critical, or pull from Seller Central |

The full list lives in `guides/troubleshooting.md`. And if something is genuinely stuck, post the
exact error in the group. Setup friction is the one thing worth interrupting anybody for.

---

## Definition of Done for Day 1

- [ ] Claude Desktop or Claude Code installed, Pro plan or higher active
- [ ] `wonka-starter-kit` on your Desktop and open in Claude's Code tab
- [ ] Wonka answered "who are you" in character, and refused to skip research when you pushed him
- [ ] Genrupt account created and activated
- [ ] OpenAI key created, $10 to $20 loaded, organization verification complete or underway
- [ ] Pilot product chosen
- [ ] Product photos taken: all angles, hand for scale, label close ups (or the fallback path taken
      knowingly)
- [ ] `/machines-check` run, with both machines reporting PASS and the credit fuel gauge read
- [ ] First Candy printed at `output/first-candy.png`, or consciously deferred until verification
      clears
- [ ] `/factory-report` run once on the empty floor
- [ ] Shopping list received from Wonka, owner intel written down, niche phrase decided word for word
- [ ] One inputs folder on your Desktop named `[product]-inputs`, holding `reviews.txt`,
      `competitors/` (galleries plus a URL file), `photos/`, and optional demographics

Tick all of those and Day 2 costs you one command and no hunting.

Every day has a list like this one, and together they are the graduation checklist behind the
guarantee. Complete all 10 days and the graduation checklist, and you have a full, tested creative
package ready to upload by the end of the bootcamp, or a full refund. No sales lift is promised.
Results vary by product and niche.

---

## What this bootcamp will cost

Genrupt usage is included with your ticket. You bring your own Claude subscription and your own
OpenAI credit.

| Item | When | Typical cost |
|---|---|---|
| Claude Pro or Max | ongoing | $20 per month and up. Your own subscription, separate from the bootcamp |
| Genrupt usage | included with your ticket | one month, 1,800 credits. On average that carries one product through the bootcamp, often with room to spare; top up at Genrupt if you burn through it |
| OpenAI credit | the fixing and tasting days | $10 to $20 loaded. Cents per edit, a few dollars per race, four races across the bootcamp |

For scale: one professionally designed listing image runs $50 to $200, and a full untested set runs
$500 to $1500. You are building the factory, not paying per candy.

A standing rule you will hear all bootcamp: Wonka never spends your money silently. Every batch,
every Tasting Round, every paid call gets a one line cost estimate and waits for your go ahead.

---

## Common questions

**"Where does Wonka actually live? Is he installed somewhere?"**
He is the folder. Personality, skills, and memory are all files inside `wonka-starter-kit`. Copy the
folder and you copy your Creative Director. Nothing else is installed.

**"Can I use Claude Code in the terminal instead of Claude Desktop?"**
Yes, fully. Open a terminal, `cd` into the kit folder, run `claude`. Every prompt in every guide works
identically. The guides describe Claude Desktop click paths because most participants use it.

**"I sell in a non US marketplace. Does this work?"**
Yes. The method is marketplace agnostic. Your reviews and competitors come from your marketplace, so
the research reflects your shelf, and the Tasting Room's panel is conditioned on your real buyer
whatever marketplace they shop in.

**"What if I have several products?"**
Pick ONE for the bootcamp. The factory happily runs a portfolio afterwards, and Day 10 shows you how
to multiply. Learning the line is a one product job.

**"Do I need Brand Registry?"**
No. It unlocks the demographics export and the optional Amazon A/B at the end. Without it, personas
are estimated and clearly labelled as estimated, and every room runs identically.

**"Why is there no survey tool to sign up for?"**
Because the Tasting Room runs inside the factory, on the same OpenAI key you already created. A few
dollars a round, results in minutes. To be straight with you about what it is: the tasters are
synthetic AI personas conditioned on your real buyer, so the verdict is directional and the real
value is the objections they hand you in their own words. It is not a panel of real shoppers, and
nowhere in this bootcamp will it be sold to you as one.

**"Can I use last week's product photos, or the ones from my listing?"**
You can, and Wonka will record the reference as built from scraped imagery rather than real photos.
Expect weaker product accuracy. If the product is within reach, spend the ten minutes.

---

## What Day 2 opens with

Exactly what you leave here holding: two warm machines, an empty product line, and a full basket.

Day 2 is the Front Gate and the Research Room, in one command. Your product checks into the factory,
Wonka takes your listing, your reviews, your competitors, and your own intel, and derives your market
picture himself: the table stakes, the pain points in buyers' own words, your real buyer, the
whitespace nobody in your niche is showing, and a diagnosis of where your listing is actually losing
sales.

As the man says: "Every great candy starts with knowing exactly who it is for."

# Episode 1: Factory Keys

Before the Factory can run, you collect the keys: the accounts, the apps, and the product you will run through the line. This is a real episode, not pre-work, and every step below has an exact click path. None of it is hard.

## What you will have by the end of this episode

- Claude installed with the kit folder open, and Wonka answering in character
- A Genrupt account created (Genrupt access is included with your ticket)
- An OpenAI API key created, with org verification done and a few dollars loaded
- Your pilot product chosen
- Real photos of your product, taken and saved

**Time needed:** 60 to 90 minutes, mostly waiting for downloads and taking photos.

**A word on cost before we start.** Genrupt access is included with your ticket. You only need your own Claude Pro or Max subscription and a few dollars of OpenAI credit, which covers both the image edits and the Tasting Room's test rounds. That is the whole bill for the bootcamp. No surprises hiding at the bottom of this guide.

One thing this episode does NOT do: connect the MCP. Creating the account is your job here; wiring it into Claude happens in Episode 2, together with Wonka, so he can check his own machines while you watch. Today you just get the keys cut.

---

## Step 1: Claude Pro or Max + the app

1. Go to [claude.ai/download](https://claude.ai/download) and install **Claude Desktop** (Mac or Windows). If you already use **Claude Code** in the terminal, that works too; everything in this bootcamp runs in either.
2. Open Claude Desktop, click your profile icon (bottom left), and make sure you are on **Pro ($20/month) or higher**. The free plan does not include the Code tab or Skills, and the Factory needs both.

**Pro or Max?** Pro is enough for the bootcamp. Max gives you more daily usage and fewer "may I?" prompts. If you plan to run several products per week after the bootcamp, Max earns its keep. Start with Pro if unsure.

## Step 2: Download and open the kit

1. Download `wonka-starter-kit.zip` from the bootcamp portal (link in your welcome email).
2. Unzip it. Mac: double-click. Windows: right-click, "Extract All".
3. Drag the `wonka-starter-kit` folder to your **Desktop**.
4. Open Claude Desktop, click the **Code** tab (top center), click the folder picker at the bottom of the chat input, choose **"Open folder..."**, and select the `wonka-starter-kit` folder.

**Verify:** type this in the chat:

```
Who are you, and what is this factory?
```

You should get Willy Wonka, your AI Creative Director, with a little theater. A generic chatbot answer means the folder did not load; re-open it. Full verification script is in `QUICK_START.md`.

## Step 3: Genrupt account (sign up only)

Genrupt is the Inventing Room's main machine: it locks a reference of your real product and generates listing images and A+ content around it.

1. Create your account at [genrupt.com](https://genrupt.com) (use the bootcamp signup link from the portal if one was provided). **Genrupt access is included with your ticket**, so activate it with the code or link in your welcome email.
2. Confirm your account has image generation credits. One product through the full bootcamp uses a modest batch of credits; the portal FAQ has current numbers.
3. That is it for now. The MCP connection to Claude happens in Episode 2, with Wonka checking his own machine. If you want to read ahead, the connection lives in `guides/mcp-setup-guide.md`.

**No Genrupt?** The Factory still runs. Wonka falls back to generating directly with OpenAI's image model. Product accuracy is weaker without the locked reference, and Wonka will say so honestly, but you can complete the bootcamp.

**And notice what is NOT on today's list.** No research tool, no browser extension, no third-party report account. The Research Room runs on what you already have: your listing, your reviews, your competitors' public galleries. One less signup is not a small thing; it is the whole philosophy of this Factory.

## Step 4: OpenAI API key (for the Fixing Room AND the Tasting Room)

One key, two jobs. Surgical image edits (shorten a headline, remove a stray element) run on OpenAI's image model directly; a typical edit costs a few cents. The same key also powers the Tasting Room in Episode 9: a panel of ~100 AI tasters, matched to your real buyer, that votes on your images instantly for a few dollars per round.

1. Go to [platform.openai.com](https://platform.openai.com) and sign up or log in.
2. Click your profile (top right), then **API keys** (or go to platform.openai.com/api-keys).
3. Click **"Create new secret key"**, name it `wonka-factory`, and click Create.
4. **Copy the key immediately** (it starts with `sk-`). You will not see it again.
5. Add a payment method under Settings, then Billing. Load $5 to $10. That covers the edits and the Tasting Rounds of the whole bootcamp for most people.
6. **Org verification, do it now:** OpenAI requires a one-time organization verification before image models work. Go to platform.openai.com, then Settings, then Organization, then Verify, and complete it during setup, not in the episode where you actually need the Fixing Room.
7. Keep the key somewhere safe and handy (a note or a password manager). You wire it into the kit in Episode 2; `guides/mcp-setup-guide.md`, Part 2, shows the exact one-line setup when you get there.

**Expected costs:** cents per edit, a few dollars per Tasting Round. Wonka always quotes a cost estimate before spending anything.

## Step 5: Choose your pilot product

Pick ONE product to run through the Factory during the bootcamp. Good criteria, in order of preference:

1. **A live ASIN you can change images for.** You own the listing, and you (or your account manager) can upload new images. This unlocks the full journey including the optional Amazon A/B.
2. **Any live ASIN of yours**, even if image changes are slow to roll out. You still get the full research, generation, testing, and a ready-to-upload set.
3. **A pre-launch product with real photos.** No live listing yet, but you have the physical product in hand. You skip the incumbent comparison, everything else works.

Avoid picking: a product you plan to kill, a product with an unresolved listing suppression, or a niche you are about to exit. The Factory works; aim it at something that matters.

## Step 6: Photograph your product (do not skip)

The Mold (Episode 4) is built from YOUR photos of the REAL product. Photos from your phone are fine. Natural light near a window, plain background, no filters. Take:

- [ ] Front, straight on
- [ ] Back (the full label)
- [ ] Left side and right side
- [ ] Top down
- [ ] **One shot of the product held in your hand** (this is how Wonka learns its true size)
- [ ] Close-ups of the label: any certification seals, ingredient text, brand mark

Save them all in one place; you will drop them into the product's `reference/` folder in Episode 3, at the Front Gate. Wonka can work from Amazon's existing images as a fallback, but molds made from guesses produce candy shaped like guesses.

---

## Definition of Done for Episode 1

- [ ] Claude Desktop (or Claude Code) installed, Pro plan or higher active
- [ ] `wonka-starter-kit` folder on your Desktop and open in Claude's Code tab
- [ ] Wonka answers "Who are you?" in character
- [ ] Genrupt account created and activated (access included with your ticket)
- [ ] OpenAI API key created, org verification completed, $5 to $10 loaded, key saved per the setup guide
- [ ] Pilot product chosen
- [ ] Product photos taken: all angles, hand-for-scale, label close-ups

## What this bootcamp will cost (full transparency)

Genrupt access is included with your ticket. You only need your own Claude Pro or Max subscription and a few dollars of OpenAI credit, which covers both the edits and the Tasting Rounds.

| Item | When | Typical cost |
|---|---|---|
| Claude Pro or Max | ongoing | $20/month and up (you likely have it; this is your own subscription) |
| Genrupt access | included with your ticket | $0 during the bootcamp |
| OpenAI credit | the fixing and tasting episodes | $5 to $10 loaded; cents per edit, a few dollars per Tasting Round |

For scale: a single professionally designed listing image runs $50 to $200, and a full set $500 to $1500. You are building the factory, not paying per candy. And a standing rule you will hear all bootcamp: Wonka never spends your money silently; every batch, Tasting Round, and paid call gets a one-line cost estimate and waits for your go-ahead.

## Common questions

**"Where does Wonka actually live? Is he installed somewhere?"**
He is the folder. Personality, skills, memory, all files inside `wonka-starter-kit`. Copy the folder and you copy your Creative Director. Nothing else is installed.

**"Can I use Claude Code in the terminal instead of Claude Desktop?"**
Yes, fully. Open a terminal, `cd` into the kit folder, run `claude`. Every guide's prompts work identically. The guides describe Claude Desktop click paths because most participants use it.

**"I sell in a non-US marketplace. Does this work?"**
Yes. The method is marketplace-agnostic. Your reviews and your competitors come from your marketplace, so the research reflects your shelf, and in Episode 9 the Tasting Room's panel is conditioned on your real buyer demographics, whatever marketplace they shop in.

**"What if I have several products?"**
Pick ONE for the bootcamp. The Factory happily runs a portfolio later (that is what the station trackers and the weekly report are for, and Episode 12 shows you how to multiply), but learning the line is a one-product job.

## Troubleshooting note

The three most common Episode 1 issues: Wonka sounds generic (the folder did not load, re-open it), an account activation code not working (check the welcome email for the current link, then ask in the bootcamp group), and the `.claude` folder seems missing (it is hidden; Mac: press Cmd+Shift+. in Finder; Windows: File Explorer, View tab, check Hidden items). The full list lives in `guides/troubleshooting.md`.

See you in Episode 2. The machines are warming.

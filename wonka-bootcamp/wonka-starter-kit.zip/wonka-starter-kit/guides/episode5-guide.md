# Episode 5: The Creative Brief

This is the bootcamp's first big WOW, and it is not an image. It is a plan. This episode Wonka takes everything from the Research Room, the locked Mold, and the brand kit, and writes a single creative brief for your ENTIRE product page: the main image, the full set of secondary images, your A+ content modules, and your variation images. One document, every asset accounted for, every selling point mapped to a home, and, because the Mold and the brand kit already exist, **zero placeholders**. This is the recipe, and no candy gets made without it.

## What you will have by the end of this episode

- **A full package brief (`brief/creative-brief.md`): main image + secondary set + A+ modules + variation plan, each asset with one job and one dominant message**
- Every selling point from your checklist mapped to a specific asset, or consciously skipped in writing with a reason
- Casting notes for people-bearing images, matching your REAL buyer
- Compliance notes baked in, so nothing gets briefed that would get rejected later

**Time needed:** 60 to 90 minutes, most of it reading and pushing back on the brief. This is the most valuable hour of the whole bootcamp; spend it awake.

## What you will need at hand

- Your `research/` folder: the digest, selling-points checklist, funnel diagnosis, and `competitors.md`
- Episode 4's locked Mold and finished brand kit (Wonka reads them; you just need them done)
- Your own opinions. You are the editor of this brief, not a spectator.

---

## Lesson 1: Why the whole page is one recipe

Most sellers treat listing images as a pile of separate pictures: a main shot, some feature graphics, maybe an A+ section a designer threw together months later. The result is a product page that repeats itself, contradicts itself, and leaves gaps.

A recipe fixes that by planning the page as ONE thing. The main image has a job. Each secondary has a DIFFERENT job. The A+ tells the story the images could not fit. The variations show the buyer their choices without confusing them. Nothing is duplicated, nothing important is missing, and every asset pulls in the same direction: toward your real buyer clicking Buy.

This is why the recipe comes before any generation. Decide the whole page on paper, cheaply, and the expensive part (generation) just executes a plan you already trust.

## Lesson 2: Why THIS recipe can be written with zero placeholders

Here is what the episode order bought you. Most briefs are full of holes: "brand colors TBD", "reference product photo needed", "claims pending legal". Every hole becomes a guess at generation time, and guesses cost credits.

Your recipe has no holes, because everything it needs already exists:

- **The research** (Episode 3) supplies the selling points, the persona, the whitespace, and the funnel diagnosis.
- **The Mold** (Episode 4) supplies the exact product: size, shape, label, material. The brief can reference the real thing.
- **The brand kit** (Episode 4) supplies the colors, fonts, tone, and the approved claims list. Nothing gets briefed that the brand would reject.

That is the WOW of this episode: a complete, executable, data-driven brief for your whole page, with nothing left "to be decided later".

## Lesson 3: One message per asset (the anti-clutter law)

The single most common mistake in Amazon creative is trying to say everything on every image. An image that says three things says nothing. The recipe enforces one dominant message per asset, and forces variety across the set: no two secondary images share a message, and at least one is a genuine emotional or lifestyle frame, not another spec sheet.

You will feel the discipline when you read the brief. If two images want the same job, one of them is wrong, and the recipe is where you catch it, for free, before a single credit is spent.

The funnel diagnosis from Episode 3 sets the emphasis. Main-image problem? The recipe leans hard on the hero and its candidates. Detail-page problem? The secondaries and A+ carry the weight.

## Lesson 4: Casting and compliance, decided now

The recipe bakes in two things that are expensive to fix later:

- **Casting.** People appear in secondary and A+ images only, never the main. They are cast to your REAL buyer, with an aspirational skew (from age 50, the displayed model looks about 5 years younger, scaling to about 10 years younger by 70), and a DIFFERENT person appears in each people-bearing image, so the set does not read as one stock model on repeat.
- **Compliance.** No medical claims, no invented percentages, no star ratings or review references, no fake badges, no third-party logos drawn as graphics, no flag graphics. Only the real certifications your product actually has, straight from the brand kit's approved claims table. Deciding this in the brief means Wonka never generates something that gets rejected by the survey tool or by Amazon later.

---

## MISSION 1: Write the recipe (the WOW)

Everything so far was ingredients. Now:

```
/creative-brief
```

Wonka writes the full package brief and saves it to `brief/creative-brief.md`. Read it slowly. You should see:

- A **main image** brief: product-only, no people, the one thing it must communicate at thumbnail size
- A **secondary set**: roughly 5 to 7 images, each with one job and one dominant message, casting notes where people appear
- An **A+ plan**: the modules, each with its message and a note on layout, following A+ best practice
- A **variations plan**: how each color/size/bundle is shown consistently (or a note that this product has no variations)
- Every selling point from the checklist mapped to a specific asset, or consciously skipped in writing with a reason
- At least one emotional/lifestyle frame, and no two assets repeating a message
- Compliance notes baked into each people-bearing or claim-bearing asset
- A "Built from:" line at the top showing exactly which research, mold, and brand kit fed it

## MISSION 2: Edit the brief like a boss

This is your hour. Push back:

```
Why did you give secondary image 3 that job instead of [the thing I care about]?
```

```
Swap the message on secondary 5 for [X] and tell me what we lose.
```

```
My A+ has room for a comparison module. Add one and tell me what it should compare.
```

He will defend with data or concede and update the file. Interrogate the coverage especially:

```
Show me the selling-points coverage table: which asset covers each point, and which points you consciously skipped and why.
```

Any point that is skipped should have a real reason (off-niche, not true of this product, a tested loser), not a silent omission. When you are happy:

```
The recipe is approved. Update status.md.
```

## MISSION 3: Note where people and variations land

Quickly confirm two structural things, so the generation episodes go smoothly:

```
List every asset in the recipe that will contain a person, and confirm each has a distinct casting note.
```

```
Confirm the variations plan matches my real SKUs. I sell in these variations: [list them, or say "no variations"].
```

Fixing casting and variation logic here is a free edit to a document. Fixing it after generation costs credits.

**Share the WOW:** post a screenshot of your favorite part of the brief (the secondary set list, or the coverage table) to the bootcamp group. Seeing dozens of full-package briefs for dozens of different products is a masterclass in listing strategy.

---

## Before the next episode (10 minutes)

The next episode the Factory finally produces: the Main Image Room generates your MAIN image candidates. To arrive ready:

1. **Re-read the recipe's main image brief.** The next episode generates 4 concepts against it, and you will judge them against exactly that brief.
2. Confirm the line is clear: `Give me a one-line status: recipe approved, mold locked, smoke test passed, brand kit done?` Four yeses and the Main Image Room opens without friction.
3. Block 60 to 90 minutes for the next episode when you can actually look at images. Not a phone-only session.

## Definition of Done for Episode 5

- [ ] `/creative-brief` ran: `brief/creative-brief.md` exists covering main + secondaries + A+ + variations
- [ ] The brief has zero placeholders: brand fields filled from the brand kit, product references from the Mold
- [ ] Every asset has one job and one dominant message; no two share a message
- [ ] Every selling point mapped to an asset or consciously skipped in writing
- [ ] Casting notes present for every people-bearing asset (distinct person each)
- [ ] Compliance notes baked into the brief
- [ ] You edited the brief at least once and approved it; `status.md` shows BRIEF done

## Troubleshooting note

If the brief feels thin or generic, the research underneath it was probably thin; go back and paste more critical reviews, then `Re-run the /meet-my-product analysis with these reviews, then /creative-brief`. If the recipe lists more images than you think you need, remember the scarce thing is messages, not pixels: ask `Which secondaries could we cut without dropping a selling point?` and let the coverage table answer. If a selling point you care about is missing, say so by name: `Glass bottle is a table stake and it's not in the recipe. Add it and tell me which asset carries it.` Everything else: `guides/troubleshooting.md`.

Next episode: the Main Image Room opens on the MAIN image. Four concepts, an inspection, and surgical fixes, the quality loop you will run three times in this bootcamp. "Come in, come in. We're inventing next."

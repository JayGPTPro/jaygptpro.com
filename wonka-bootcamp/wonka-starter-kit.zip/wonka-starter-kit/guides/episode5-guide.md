# Day 5: The Main Image Room

Today the Factory makes its most valuable single asset, and then teaches you the loop that everything else in this bootcamp passes through.

Your main image is the one picture that decides whether a shopper scrolling search results ever meets your product at all. You will generate four concepts against your brief, inspect them properly, fix what is broken, and put the repairs back through the gate. Learn the loop here, in one piece, because Day 6 runs it on a whole gallery and Day 7 runs it on a whole A+ page, and neither of them stops to explain it again.

## What you will have by the end of this day

- **Four main image concepts: product only, no people, each carrying a different bet about why somebody clicks**
- A scorecard: every candidate described literally, scored on six dimensions, squint tested at 160 pixels, gated for compliance, and ranked
- Flagged candidates repaired, by surgical edit or by regeneration, with every original still on disk
- **Four gate-passed candidates and no winner picked**, because that decision belongs to the Tasting Room on Day 8
- The quality loop, learned once, properly, and yours from here on

**Time needed:** 75 to 100 minutes, including generation waiting time.

## What you will need at hand

- Your approved `brief/creative-brief.md`, with its MAIN section fresh in your head
- Your locked Reference, with a **passed** smoke test (Day 3)
- Your `factory/Brand/brand-kit.md`
- Your OpenAI key working. The Fixing Room runs on it
- Your phone, for one honest look at a candidate at real thumbnail size

---

## Lesson 1: What makes a main image convert

Every other asset on your listing is seen by people who already clicked. Your main image is seen by everyone who did not, at the size of a postage stamp, in a row of competitors, for well under a second. That context sets five hard principles:

1. **Contrast wins the scroll.** The eye goes where the contrast is. Before beauty, before cleverness. If your product melts into the row, nothing else matters.
2. **Product size in frame.** At thumbnail size a product filling about 85 percent of the frame reads. At 50 percent it is a speck with expensive lighting.
3. **Product truth survives the shrink.** Correct shape, correct count of parts, correct material, correct colors, matching your Reference Sheet. A beautiful image of the wrong product is a failure, not a near miss.
4. **No overlay text or graphics. None.** Only what physically exists on the product and its label. No headlines, no callouts, no arrows, no floating seals. This is also where most "creative" mains die in Amazon review.
5. **Badges must be physical.** A seal belongs on your main only because it is really printed on the product or the box. Best seller flags, star ratings and review counts are never drawn in. Amazon puts those on the search tile itself, and a drawn one is a fake badge that fails the gate.

And the law: **no people in the main image. Ever.** No faces, no hands, no product in use. All of that sells beautifully, in your secondary images.

### The rule underneath all five

Here is the harder idea, and it is why today matters more than any other single day.

**Your main image is a promise.** Whatever it shows, your buyer expects to happen in their kitchen.

You met this on Day 2 as a research finding. Here is where it becomes a constraint on what you are about to generate. The demo product for this bootcamp is the number one best seller in its category, 1,352 ratings, and a 3.9 star average that splits like this: 58 percent five star, and 18 percent one star. Nearly one buyer in five is furious. The biggest complaint by a wide margin is that the chocolate does not flow. One reviewer explains the whole thing: the box says it holds 32 ounces, 2 pounds, and it does hold that amount, but if you want the flow you see in my video, you need about four pounds.

Nobody lied about the capacity. The capacity is real. But somewhere in that gallery is a cascade that a correctly filled machine does not produce, and a steady share of the shoppers who filled it to the number on the box left one star about it.

**The number one complaint about the category leader is a promise its images made.**

So before you generate, ask the same question about your own product: what is my main image about to promise, and can my product keep it? Then go read your one and two star reviews holding that question. There is a decent chance your current main image wrote some of them.

The truth does not disappear, it moves. What it really takes to get the best out of your product belongs in the secondaries and the A+, where there is room to say it properly. **The main image promises. The gallery explains.**

### So which concept is best?

Wrong question. Your brief did not pick one main image, it wrote four **test hypotheses**, and a hypothesis is a stated bet about why somebody clicks. Four different reasons, not four versions of one reason. You build all four, you gate them all for quality, and on Day 8 about a hundred tasters settle it, with your current live image in the lineup.

We do not guess in this factory. We test.

---

## Lesson 2: /main-image, four concepts on camera

Four bets, one command, one cost line. Your brief already did the strategy, so this lesson is execution, and it carries two disciplines worth naming.

**Money is never spent silently.** Wonka states the estimated batch cost in one line and waits for your go ahead. One approval for the batch, not one per image. Keep the comparison in your head while it runs: a photographer or a designer is 50 to 200 dollars per image and about a week.

**Your rules are not written into the image request.** This surprises people, so here is the reasoning. The main image slot is protected: the hero is shaped by the generation controls, by your locked reference, and by the smoke test that proved the reference holds. The big prohibitions are handled by the engine itself rather than by prose sitting in the brief. Rules pasted into a brief as text do not behave like rules, they behave like more creative direction, and they compete with your actual creative direction for the model's attention. Long rule lists make images worse. So every rule rides the channel that enforces it: product fidelity rides your reference photos, brand look rides your brand kit, prohibitions ride the engine.

**None of that makes a batch clean.** Routing a rule to the strongest channel improves the odds, it does not close them. A protected slot still leaks an invented seal now and then, and a locked reference still drifts. That gap, between where a rule is enforced and whether it actually held, is exactly what the next section exists to catch, and it is why nothing here is a candidate until it has been inspected.

While the batch runs, re-read your brief's MAIN section so you know what each incoming concept is supposed to prove.

---

## Lesson 3: The quality loop: /inspect and /fix, taught once, properly

**This is the section to bookmark.** It is taught once, here, in one piece. It runs again on Day 6 and again on Day 7, and both of those days assume you know it.

One sentence explains the whole room: **human review is for picking winners, not for finding defects.** Every generated batch contains defects. That is normal and it is priced in. The only question is who finds them. If it is you, you spend your judgment on debugging and have nothing left for the decision that is actually yours.

The loop has four steps, and the fourth one is the one people skip.

### 1. Generate

`/main-image` against the brief. Four concepts, one per hypothesis, on your locked reference. Batches contain defects. Expect them and plan for them.

### 2. Inspect

`/inspect` does four things to every image:

- **Looks, and describes literally.** A one or two line description of what is actually visible, written before any score. That description is the evidence. An image nobody can honestly describe was not looked at.
- **Scores six dimensions, one to five:** message clarity, legibility, product accuracy, brand fit, craft, and casting (null on a main, because mains have no people).
- **Runs the squint test mechanically.** Not a figure of speech. A real copy of the image, 160 pixels wide, is written to `scorecards/squint/` and THAT copy is what gets read. **If there is no squint folder on disk, the legibility scores were eyeballed at full size and they are worth nothing.** At full size everything is readable. That is exactly how bad images get shipped by smart people.
- **Applies the compliance gate.** Pass or fail, no partial credit, no score buys it back. On a main image that gate additionally fails any person, face or hand, and any overlay text or graphic that is not physically on the product.

Then it force ranks the candidates and writes down the tie break it used.

**It will finish by offering to fix the cheap fails itself, with one cost line.** That offer is real and from Day 6 onward you should take it. Decline it once, today, and run `/fix` yourself. You will never understand what you are approving when you say yes to that shortcut unless you have watched the Fixing Room work through a routing decision at least once.

**The house standard for text, stated once for the whole bootcamp:** one dominant message per image, and no text smaller than about **3.5 percent of the image's short edge**. Below that it is decoration, not communication. On a main image the standard applies to whatever is really printed on the product, since a main carries no other text. On Day 6 it decides your secondary headlines and on Day 7 your A+ modules, and on both of those days a failed squint test is a hard stop. Same standard, same 160 pixels, same folder on disk.

**How to read a scorecard:** the six scores are the diagnosis. The compliance gate is a separate pass or fail that no score can buy back, so an image can be gorgeous, high scoring, and still bottom of the pile. The ranking is an input to your decision, not the decision. And every failure must name a dimension, an element, and a fix. A verdict you cannot act on is not a verdict, and you should push on it until it is one.

### 3. Fix

`/fix` routes before it touches anything, and **the routing is the room**:

| Defect | Route |
|---|---|
| Shorten or remove text | **Safe as an edit** |
| Remove an element (badge, stray object) | **Safe as an edit** |
| Swap a word or a claim | **Safe as an edit** |
| Recolor an accent | **Safe as an edit** |
| Enlarge text | **Regenerate** |
| Move or resize anything | **Regenerate** |
| Change layout or composition | **Regenerate** |
| Fix a face or the casting | **Regenerate** |
| Fix the product itself (wrong count, wrong material, wrong label) | **Regenerate** |

The reason is mechanical: the edit endpoint re-renders the frame, so removal and substitution are reliable, and anything spatial comes back subtly wrong. Choosing the wrong route is how people garble good images.

Four rules travel with every edit:

1. **One change per call**, and the prompt ends by freezing everything else: "change nothing else in the image". An image needing three fixes is either three sequential edits or a sign it should be regenerated instead.
2. **The original is sacred.** The fix saves as `name_fix1.png` beside the untouched original. A regeneration saves as a new file too. Nothing is ever overwritten. You prune your own files.
3. **Verify side by side.** Both files open. Did the requested change happen? Does every other element read exactly as before? Is the product untouched? An edit re-renders the whole frame, so it can quietly break something on the far side of the image.
4. **It gets logged.** `images/fixes-log.md` records the mode, the defect, the route, the exact prompt, the result, the side by side check and the cost, including routing decisions where no edit ran at all.

Cost check: surgical edits are cents each, roughly two to ten cents. A regeneration is a full image. That gap is why the routing table matters in both directions: never regenerate what a two cent edit fixes, and never try to edit what only the ovens can fix.

### 4. Re-inspect

The step people skip. **Nothing is fixed because you feel good about it.** The fixed and regenerated files go back through the same gate, the same scores, a fresh 160 pixel copy, and the scorecard updates. It passes or it does not ship.

Then, and only then, you look at candidates.

---

## MISSION 1: Confirm the line is ready

Before spending anything:

```
Confirm we're clear to invent: brief approved, brand kit done, reference locked, smoke test passed. List anything blocking.
```

If Wonka names a gap, fix it first. Generating on an unverified reference is exactly the money waster the smoke test exists to prevent.

## MISSION 2: Generate the four bets

```
/main-image
```

The skill is scoped to the main image and nothing else. It reads the MAIN section of your brief, generates one concept per hypothesis, product only, no people, no overlay text, and it states the batch cost before spending.

Wonka checks the three preconditions, reads the four bets back, quotes the cost in one line, and waits. Give the go ahead:

```
Approved, go.
```

He generates into `images/` as `main-01.png` through `main-04.png` and writes `images/batch-log.md`. If your brief carries only three genuinely distinct strategies, he generates three and says so. He never pads to four with near duplicates, and neither should you.

## MISSION 3: Inspect

```
/inspect scoped to the main image candidates only. Literal description first, six dimensions, the squint test at 160 pixels, the compliance gate, then rank them.
```

The scorecard saves to `scorecards/` and the downscaled copies to `scorecards/squint/`.

Read the whole thing, not just the ranking. Then interrogate anything you cannot act on:

```
Concept 2's verdict says "weak composition". That's vague. Which dimension fails, what exactly fails on it, and what's the cheapest fix?
```

## MISSION 4: Do the squint test yourself, once

You should feel this standard in your own hands at least once in this bootcamp, and the main image is the place:

```
Show me the top ranked candidate at 160 pixels next to full size, and tell me which parts survive and which dissolve.
```

Then open the 160 pixel file yourself, from `scorecards/squint/`, in your file browser. Look at it the way a shopper does: two seconds, phone in one hand, coffee in the other. Can you tell what the product is, how big it is, what it is made of? Now you know why main images live or die at 160 pixels, and you will never judge one on a big monitor again.

## MISSION 5: The Fixing Room

```
/fix
```

Wonka builds the complete fix list first, routes every item to edit or regenerate, and puts ONE total cost line at the bottom. One go ahead from you, then he runs the whole list. He does not ping you item by item.

Typical requests, so you can see the range:

```
Remove the floating seal in the corner of concept 4. Change nothing else.
```

```
Concept 2 rendered the wrong product. Route it to regeneration with a tighter brief, and tell me the exact sentence that brief will carry.
```

When the fixes land, close the loop:

```
Re-inspect the fixed and regenerated mains and update the scorecard.
```

## MISSION 6: Get four candidates through the gate

Repeat fix and re-inspect until all four pass. Two rounds is typical. Not three passes and one that is nearly there. Four.

Then stop. **Do NOT pick a winner.** That choice belongs to the tasters on Day 8, and to you just before it. Uploading anything now would be guessing with your listing, which is the exact habit this bootcamp exists to kill.

**Share the WOW:** post two things in the bootcamp group. Your current live main image beside your top ranked new candidate, side by side. And your best CATCH: the flaw the squint test found that you had looked straight at and missed. The catches teach the group more than the wins do.

---

## Before the next day (10 minutes)

Day 6 runs the exact same loop on the secondary set, which is bigger, has people in it, and has to work as a team. To arrive ready:

1. Re-read your brief's secondary set: each slot's job, its single message, and its casting note.
2. Confirm this day closed clean: `One-line status: are four gate-passed main concepts saved in images/, with the scorecard in scorecards/ and the squint copies on disk?`
3. Nothing else. Do not generate ahead. Set thinking is Day 6's lesson, and it changes how you receive a batch.

## Definition of Done for Day 5

- [ ] The line was confirmed ready (brief, brand kit, reference, smoke test) before spending
- [ ] `/main-image` ran with your cost go ahead: four concepts in `images/`, batch log written
- [ ] Every concept is product only: no people, no hands, no overlay text or graphics
- [ ] `/inspect` ran: scorecard in `scorecards/` with literal descriptions, six scores, the compliance gate, specific reasons, and a ranking with its tie break
- [ ] `scorecards/squint/` exists and holds a 160 pixel copy of every inspected image
- [ ] You personally opened one 160 pixel copy and looked at it
- [ ] `/fix` ran on everything flagged: each item routed, one cost line approved once, fixes saved as `_fixN`, regenerations saved as new files, every original intact
- [ ] The fixed and regenerated images were re-inspected and the scorecard updated
- [ ] All four candidates gate-passed. No winner picked, nothing uploaded
- [ ] `status.md` updated

## When it goes wrong

**A generated main shows the wrong product** (wrong count of parts, wrong material, a label that never existed): the Reference is not holding. Stop, do not generate more, and say `The reference isn't holding. Re-lock it and give me a fresh smoke test.` If only one concept drifted, regenerate that one. Product problems are never edits.

**A "fixed" image comes back with something else broken:** that flaw was regenerate territory, not edit territory. Say `This fix broke something else. Route it to regeneration with a tighter brief.` Your original is still on disk, which is the entire reason it is kept.

**A concept sneaks in a person, a hand, or overlay text:** it is not a main image. Wonka reclassifies it to the secondary set and generates a replacement concept for that hypothesis.

**Every candidate passed with no flags at all:** possible with a strong reference and a sharp brief, but verify it in ten seconds by opening a 160 pixel copy yourself. If `scorecards/squint/` is empty, the pass is worthless. Say `Re-inspect as the ruthless inspector, at 160 pixels, and show me the downscaled copies.`

**All four concepts look like the same photo:** that is a brief problem, not a generation problem. Sharpen the MAIN section so each hypothesis is a different REASON to click, then regenerate. Rerolling one idea four times is a single guess with extra steps.

**No physical unit to photograph:** the demo product runs this way on purpose, with its reference built from listing gallery and customer review images and recorded honestly as such. It works, and it is weaker, so the fidelity check bites harder. On your own product, shoot it: every angle plus one shot with a hand beside it for scale. That hand shot never appears in a main image, since mains have no hands. It exists to teach the reference how big the thing really is, which is what stops the model inventing proportions.

**Running the fallback without Genrupt:** expect weaker product fidelity, so generate ONE concept first, look at it properly, and only spend on the other three if the product renders faithfully. Your inspection matters double on this path.

Everything else: `guides/troubleshooting.md`.

---

Next room: the same loop, wider. Your full secondary set, where people finally appear, where every image carries a different message, and where you learn to judge a SET instead of a picture. "One image is a note. A set is a song."

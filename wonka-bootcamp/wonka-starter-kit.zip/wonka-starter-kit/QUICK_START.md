# Quick Start . 5 Minutes to a Working Factory

Four steps. Then you have an AI Creative Director on your machine.

## 1. Unzip and place the folder

- Download `wonka-starter-kit.zip` from the portal.
- Mac: double-click the zip. Windows: right-click, "Extract All".
- Drag the `wonka-starter-kit` folder to your **Desktop** so you always know where it lives.

## 2. Open the folder in Claude

**Claude Desktop (recommended):**
1. Open Claude Desktop.
2. Click the **Code** tab (top center).
3. Click the folder picker at the bottom of the chat input.
4. Choose **"Open folder..."** and select `wonka-starter-kit` on your Desktop.

**Claude Code (terminal), if that is your thing:**
1. Open Terminal.
2. Type: `cd ~/Desktop/wonka-starter-kit` and press Enter.
3. Type: `claude` and press Enter.

## 3. Say hello to Wonka

Type these three sentences, one at a time. They verify he is alive, in character, and knows his own Factory:

```
Who are you, and what is this factory?
```
He should introduce himself as Willy Wonka, your AI Creative Director, with some theater. If the answer sounds like a generic chatbot, the folder did not load. Re-open it.

```
Walk me through the 5 stations of the Production Line in one line each.
```
He should name RESEARCH, BRIEF, INVENT, INSPECT, PROVE, in order.

```
What would you do if I asked you to skip research and just make me images?
```
He should refuse, charmingly. "No brief, no candy." If he agrees to skip, the character file is not loading: see `guides/troubleshooting.md`.

## 4. Put your first product on the line

```
/meet-my-product
```

Wonka will ask for your ASIN, brand, and niche, build the product's folder, and hand you a short shopping list of inputs to gather. (Run `/machines-check` first if you want Wonka to verify all his machines and connections are alive.) That is Episode 2 in motion (the Front Gate opens there).

## What next

- Full setup (Genrupt and ProductPinion accounts, the Product Opinion extension, your OpenAI key): `guides/episode1-guide.md`, Factory Keys. Your first month of Genrupt and ProductPinion is included with the bootcamp.
- The episode-by-episode journey (13 episodes): `guides/episode1-guide.md` through `guides/episode13-guide.md`
- Something broken: `guides/troubleshooting.md`

By the end of the bootcamp you have a full, tested creative package (main image, secondaries, A+, variations) ready to upload to Amazon or start an A/B test.

"Come in, come in. We're inventing today."

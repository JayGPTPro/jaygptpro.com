---
name: tasting-room
description: The Tasting Room. A synthetic consumer panel (SSR method, arXiv 2510.08338) tastes the candidate images before any real money moves. About 100 demographic-matched AI tasters react in free text, reactions map to purchase intent, a blind forced choice picks a winner, bootstrap resampling grades how stable that winner is, and the recurring objections become concrete fixes. The live Amazon incumbent is always in the race. Runs ONCE per product on Day 8: invoking it authorises the standard sitting, the MAIN race and the GALLERY race, within a $10 cap; then it reports and stops. Another comparison runs only when the owner asks for one to answer a concrete question. Triggers: /tasting-room, "run the tasting", "Tasting Room", "taste test the images", "which image wins", "run the panel", "test the candidates", "tasting round 2".
---

# The Tasting Room

| Meta | Value |
|------|-------|
| Room | The Tasting Room |
| Station | PROVE (step 1 of 3: taste, report, then the owner decides; another comparison only when the owner asks for one to answer a concrete question, never required). The owner's decision closes Day 8 as an `Owner decision:` line; Day 9 (variations) is next, and the Shipping Room runs only when the owner invokes it after that |
| Taught | Day 8, both races, ONE round. The proposals it produces become fixes the same day, once the owner names them; the real second opinion is Amazon's own A/B on the live listing, not another synthetic round |
| Needs | Gate-passed candidates the OWNER picked (`/inspect` done, `scorecards/` written), `research/persona.md`, `OPENAI_API_KEY` in the Factory root `.env`. This room fills `incumbent/` (the live main and gallery, or the strongest competitor's files pre-launch) itself at its opening, step 0b, before the scope plan in step 0c |
| Saves to | `factory/Products/[product]/tests/tasting-r[N]-[YYYY-MM-DD]-[race]/` (config.json, results.json, tasting-card.html, tasting-card.md) plus one row per race in `factory/Improvement Log.md` |
| Typical cost | Full tasting (~100 tasters): a few dollars and about 3 to 6 minutes, per race. Lite taste (~20 tasters): under a dollar, a minute or two. Invoking the room authorises the standard sitting; each race is priced before it runs and the sitting is capped by `spend_cap_usd` (default $10, both races together). |

## What this room does

**This room replaces asking an AI to score your images, and the difference is not small.**

The obvious move, once you have candidates, is to ask a model to look at them and rate them. That
gives you one opinion, from something with no demographics, no shopping history, and no reason to
prefer anything. It is a confident guess with a number attached.

Instead, this room builds a **panel**: about a hundred distinct AI shopper personas, each conditioned
on YOUR buyer from `research/persona.md` (age, gender, income, shopping habits), each shown the
candidates the way a shopper meets them, each reacting in free text rather than scoring. Those
reactions are then read for purchase intent, and a blind forced choice produces a result with a
stability tier.

**What it is for:** one more round of sharpening before the product goes to Amazon, or to a paid
real-shopper survey. It is a refinement step, not a verdict.

**What it does NOT replace:** paid surveys with real people. Those remain the gold standard when a
decision carries real money, and every participant should decide for themselves whether their
stakes justify one. This room never claims to be that.

**What it very much DOES replace:** "Claude, look at these five images and tell me which is best."

The room runs ONCE per product by default, and that sitting holds TWO races. Invoking `/tasting-room`
authorises that sitting: Wonka resolves the selection, prints the lineup and the estimate, and runs.
After the reports it stops. The proposals it produces become fixes the same day, once the owner names
them, and the genuine second opinion afterwards is Amazon's own A/B on live traffic, which is free and
which the owner already has.


## What this room never does

- **Never writes a Tasting Card by hand.** A card exists because the engine wrote it, or it does not exist. There is no prose version, no "here is roughly what a panel would say", no reconstructed card after a failed run.
- **Never quotes a taster who did not speak.** Every quote, theme and count is read out of `results.json`. Inventing one objection poisons every decision downstream of it.
- **Never presents the panel as real shoppers**, and never converts a vote count into a sales, ranking or conversion prediction. **Never reports the forced choice as a percentage**: a share reads as a market share and a forced binary choice cannot produce one. Always "preferred by N of M panelists".
- **Never picks the candidates.** The selection is the `Main pick:` and `Gallery pick:` rows in `status.md`, written by `/inspect`. Wonka reads them, prints the exact filenames, and never re-confirms a selection the rows already record.
- **Never spends above the sitting cap without asking, and never runs a race the owner did not select.**
- **Never edits, regenerates or starts another race by itself after the reports.** It lists the proposals with their evidence and stops; the owner names the changes.
- **Never tests a main image without the incumbent in the grid.**
- **Never tastes an image that has not passed `/inspect`.** No image enters this room ungated, not even one born from tasting data.
- **Never generates, edits, scores or ranks images.** That is `/main-image`, `/fix` and `/inspect`. This room asks the panel and reports what it said.

## The three test scenarios

Every tasting is one of these three. Name the scenario out loud before building any config.

### Scenario A. MAIN image: new vs current (the classic A/B)

**Answers:** "Is my new main image better than what is live on Amazon right now?" Two entries, your candidate and the live incumbent, with `incumbent_id` set.

```json
{
  "product": "Nostalgia 4 Tier Electric Chocolate Fondue Fountain",
  "product_context": "A 4 tier electric chocolate fondue fountain, 32 ounce capacity, 8 x 8 x 18 inches, stainless steel base, disassembles for cleaning",
  "round": 1,
  "images": [
    {"id": "main_01", "label": "chocolate moving over all four tiers", "path": "/abs/.../images/main-01.png"},
    {"id": "current_listing", "label": "current listing", "path": "/abs/.../incumbent/main-live.png"}
  ],
  "incumbent_id": "current_listing",
  "demographics": { "...copied from research/persona.md..." },
  "out_dir": "/abs/.../tests/tasting-r1-[YYYY-MM-DD]-main"
}
```
Pre-launch route (the `Live` row of `status.md` reads `no`): the incumbent entry is `incumbent/competitor-main.png` with label "strongest competitor", the same `incumbent_id` mechanism, and the config carries `"benchmark": "competitor [name]"` so the card names the opponent.

**What to read:** the verdict band. Winner, the COUNT that preferred it, the stability label, and the purchase-intent gap. A Clear lead for the challenger is a strong signal. Anything less means the notes matter more than the counts. Either way the owner decides what changes.

### Scenario B. MAIN image: multiple candidates, plus the incumbent, always

**Answers:** "Which of my candidates is strongest, and does the best one beat reality?" Same shape as A with 2 to 5 candidates PLUS the incumbent. The incumbent is never optional on a main race: a winner that only beat your other drafts has proved nothing except which draft is least weak. This is the Day 8 main race.

```json
{
  "images": [
    {"id": "main_01", "label": "chocolate moving over all four tiers", "path": "/abs/.../images/main-01.png"},
    {"id": "main_03", "label": "full height with fruit and pretzels at the base", "path": "/abs/.../images/main-03.png"},
    {"id": "current_listing", "label": "current listing", "path": "/abs/.../incumbent/main-live.png"}
  ],
  "incumbent_id": "current_listing"
}
```
Pre-launch route: the incumbent entry is `incumbent/competitor-main.png` with label "strongest competitor", the same `incumbent_id` mechanism, and the config carries `"benchmark": "competitor [name]"`.

**What to read:** the verdict band for the ranking AND the explicit vs-incumbent line. Then the losing cards' "What hurt" chips, because the loser's objections usually explain the winner.

### Scenario C. GALLERY: our secondary set vs the live Amazon set

**Answers:** "Does our whole image stack sell better than the stack that is live?" Each side gets `"paths": [...]` in gallery order, 2 to 12 frames. This is the Day 8 gallery race.

```json
{
  "images": [
    {"id": "set_new", "label": "proposed gallery", "paths": ["/abs/.../images/sec-01.png", "/abs/.../images/sec-02-v2.png", "/abs/.../images/sec-03.png"]},
    {"id": "set_live", "label": "live gallery", "paths": ["/abs/.../incumbent/live-01.png", "/abs/.../incumbent/live-02.png", "/abs/.../incumbent/live-03.png"]}
  ],
  "incumbent_id": "set_live"
}
```

**Unequal frame counts are allowed and normal, and the galleries are compared as they are.** New galleries are usually longer than the live one. Never drop frames to force parity. What Wonka does instead is describe the comparison: state both counts (the lineup block prints them side by side), name the content differences (a frame type one set has and the other lacks; another product model included in the live gallery), and say that count and content differences limit what can be attributed to the creative changes. The engine prints the same note before it spends anything, and the card prints both counts in the gallery race header. An owner note in `incumbent/notes.md` of the form `other model: live-04` is read and printed with it; nothing beyond that is automatic. Resolution and format parity are handled by the engine, which normalises every frame the same way at send time.

**What to read: TWO layers, never collapsed.** The SET verdict answers WHO WINS, because shoppers judge the whole hand and a set's score is not the average of its frames. The FRAME-BY-FRAME dive answers WHAT TO FIX: which frame carries the set, which one drags it, and each frame's works and hurts notes. When the layers disagree, the set verdict decides and the frame dive feeds `/fix`.

**Another comparison, when the owner asks for one:** the same shape with `"round": 2`, a fresh `out_dir`, and `"compare_to"` pointing at the matching Round 1 `results.json`. It exists to answer a concrete question, normally a meaningful revision or a new candidate; unchanged images are never re-raced to look for a better number.

## The path rule: race the CURRENT set, not `images/`

**Build every `path` and `paths` entry in the config from `scope.derive()["paths"]`. Never join a
filename to `images/`.**

`images/` holds the RAW generations, which are write-once and never edited. Every fix round writes a
complete set snapshot into `edits/v1/`, `edits/v2/` and so on, KEEPING THE SAME FILENAMES. So after
the Day 5 and Day 6 fixes, the current `main-01.png` lives in the highest `edits/` round, and the
copy still in `images/` is the version the owner already rejected. `scope` resolves this per file
and returns absolute paths; use them, and read the folder `cmd_plan` prints out loud to the owner.

Racing the superseded set produces a confident verdict about images nobody will upload. Nothing
downstream can catch it: the Shipping Room's own guard compares FILENAMES, and the two copies have
identical filenames by design, so they compare equal.

## Before you start

Check all six. Open the files; never take `status.md`'s word for the FILES, but do take its word for the SELECTION. A miss is either a named gap the run carries, or a hard block, per the table below. **Invocation is authorisation:** `/tasting-room` means run the standard sitting. Wonka pauses only for a genuinely missing owner decision (the one question in item 2), a technical blocker (no key, the engine cannot run, a candidate file missing on disk), or an estimate above the cap. An explicit request for a preview or for preparation only ("show me the lineup", "prepare but do not run") is honoured as asked. **A decision on a round already on disk is a record, never a sitting:** when `tests/tasting-r*` for this product already holds both cards and the owner states a decision in words ("I approve the Day 8 set", "ship it", "we go with main-13"), re-invoking `/tasting-room` records the `Owner decision:` line and the `Next stage:` line and runs NOTHING: no race, no estimate, no spend. The one thing that runs another race is the owner asking for a comparison to answer a concrete question.

1. **`/inspect` ran and the OWNER picked.** `scorecards/scorecard-[scope]-[date]-[run].md` (the latest run) exists and the candidates in front of you are gate-passed. The scorecard rank is a RECOMMENDATION and is never read as the selection. If the owner overrode it, that is legitimate and expected: the pick and the one-line reason are in the round notes and in `status.md`. An override with a reason is data. An override nobody wrote down is noise.
2. **The selected files, read from the record, never asked for again.** The selection is one canonical row in `status.md` under INVENT, written by `/inspect` at the Day 5 close and again whenever the owner changes their mind: `Main pick: main-13 (primary); alternatives: main-06, main-03; backup: vanilla-control.png`, and one for the gallery: `Gallery pick: edits/v2 (frames 02-07 in order)` (or `images/` when nothing was edited). `scope.py` resolves the main race in this order: (1) the `Main pick:` row; (2) if it is missing, a line that starts with `Main pick:` or `Owner pick:` in the latest `edits/vN/` round notes, and the config and the round notes then carry `selection_source:` naming that file. Scorecards are never a source: a scorecard rank is a recommendation, and a ranking sentence is not the owner's pick. (3) If still ambiguous, ONE focused question ("Which main is your primary, and which alternatives should race? I see main-03, main-06, main-13 on disk.") and the plan exits non-zero. It never falls back to every main in `images/`. Each selected file races as its ACCEPTED revision: the newest `edits/vN/` copy of that filename, or the `images/` original when it was never edited. `-rejected`, `-render`, `-boxes` and `-fixN` evidence, `-v2` regenerations the owner did not pick, and superseded copies never enter a race. A+ files never enter either race. The lineup printed in step 2 and the `config.json` written in step 4 list the same absolute paths in the same order, and `scope.py lineup` refuses a config that does not.
3. **The incumbent is in the race, and it is actually CURRENT.** Pull the live main image (and for the gallery race the live gallery, in order) from `incumbent/`, filled in step 0b. Map it only through `incumbent_id`. Then spend thirty seconds confirming the folder matches reality, because a listing can change under you:
   - Open the live listing and check the main image is still the one on disk, and that the live gallery has the same number of frames as the set in `incumbent/`.
   - Check the live images are not already ours. An owner who uploaded a candidate mid-bootcamp would be racing our image against itself, and the card would call it a win.
   - Record the answer in the round notes: `incumbent source: [confirmed live on YYYY-MM-DD / folder from YYYY-MM-DD, unverified / named competitor, pre-launch]`. A stale champion is the one flaw that makes every number on the card wrong in the flattering direction.
4. **`research/persona.md`, with the REAL buyer** (written by `/meet-my-product` on Day 2). Tasters are built from the buyer's real age, gender and income. Never the aspirational display age used for casting models INSIDE the images: that skew belongs to the people in the pictures, never to the people judging them. If the persona is derived rather than exported from Brand Registry, carry the word `estimated` into the demographics notes so it prints on the card.
5. **`OPENAI_API_KEY` is available.** The engine loads the `.env` from the Factory root automatically. No key means the room is closed.
6. **The engine can run.** `python3 -m pip install openai numpy python-dotenv pillow` once. Without Pillow the run still works, just heavier and slower.

**"I don't have it" is a real answer, and most of the time the run proceeds.** What blocks is a missing MACHINE or a missing DECISION, never missing convenience.

| The owner says | What happens |
|---|---|
| "The product is not launched, there is no live image" | ONE path: race the strongest competitor (step 4b). Wonka copies that competitor's main and gallery from `1-inputs/competitors/[name]/` into `incumbent/` and records `benchmark: competitor [name]` in the round notes and `"benchmark": "competitor [name]"` in the config. Say plainly which claim the card will make: beating a named rival, not beating your own live image. The run proceeds. Racing the drafts only against each other is not a route: it ranks them and proves nothing. |
| "I have no persona.md" | The engine falls back to its stated default (a general US Amazon shopper) and prints a note. Record `demographics: default general shopper` in the round notes. The run proceeds, blunter. |
| "The persona is derived, I have no Brand Registry export" | Normal, and it is the on-camera demo's own situation. Use the derived persona and put `estimated` in the demographics notes so the label rides on the card. The run proceeds. |
| "I have no OpenAI key" | The room is CLOSED. Say exactly what is missing, point to `guides/mcp-setup-guide.md`, record `blocked: no OpenAI key` in `status.md`, and stop. Never simulate a panel in prose. |
| "I have no Gemini key" | Single-FAMILY run, which is the default anyway (the default is still a MIX of two OpenAI models, and that mix stays; never drop to one model). Say the one-line caveat once: one model family carries one taste, so a thin margin deserves less trust. The run proceeds. |
| "I have no live gallery to race against" | Race the strongest competitor's gallery (step 4b): Wonka copies it from `1-inputs/competitors/[name]/` into `incumbent/` as `competitor-01..NN.png` and the gallery race runs against it, recorded as `benchmark: competitor [name]`. No competitor gallery on disk either: skip the gallery race and record it as a named skip. Silence is not an option. |
| "Just test everything in images/" | Not a selection, and `images/` is usually the wrong folder by Day 8 anyway (see the path rule below). The race is the `Main pick:` row; if the owner wants more candidates in it, they name them and `/inspect` rewrites the row. Never every main on disk. |
| "Show me the lineup first" or "prepare but do not run" | Honoured as asked: the lineup block and the estimate are printed and nothing runs until the owner says go. This is the one case where the room waits after the block. |
| "Skip the cost line, just run it" | The estimate gets said either way, because it is the cap check, not a question. One line per race, then the run. |
| "Can I decide off the lite run?" | No. Lite is for eyeballing a set or testing the machine. A lite card never fills a Status in `Improvement Log.md`, never closes a decision, and never opens `/ready-to-upload`. The card prints `lite` in its panel line, so a lite card presented as a verdict is visible to everybody later. |
| "Should I run a second round after the fixes?" | Only if it answers a concrete question, normally a meaningful revision or a new candidate. Unchanged images are never re-raced to look for a better number. Wonka may suggest one when it would answer something; he never launches it. The owner's request is the authorisation: state the estimate and run within the cap. No label (Lean, Toss-up, incumbent won, models disagree) makes a second round required; the owner may select a final set after any result, and the Shipping Room records that decision. |
| "This sitting estimates above the cap" | The one question this room asks about money: "This sitting estimates about $X, above the $10 cap. Run it anyway?" A yes runs it with `spend_cap_usd` raised for this sitting only. No answer means nothing runs; leave the station `in progress` with the Blocked on list naming the cap question. |
| No answer on the one selection question | Nothing runs. Leave the station `in progress` with the Blocked on list naming the missing decision (which main is primary, which alternatives race), say exactly what you need, and stop. |

## Process

0b. **Fill `incumbent/` before anything else, because this is the first room that needs it (moved here from Day 7 on 6 September 2026).** The live listing's images are the yardstick every main race is measured against. Get their URLs from the listing (the A+ preflight's `listingImages.candidates` list on Day 7, or the Day 2 research), download each ONCE at full size into `factory/Products/[product]/incumbent/` as `main-live.png` and `live-01.png` .. `live-NN.png` in gallery order, list the folder and read every file's pixel size back (under 1000px is a thumbnail grab, not the image). If a download is refused, stop after one try and ask the owner to save the images by hand from the listing page (full size, zoom view, gallery order) into that folder; never hammer the site. Pre-launch, or a listing the owner does not control: say so and use the 4b route, which fills this same folder with the competitor's files. Record the source line in the round notes.

0c. **Derive the scope before you author anything.** Run it against the product folder:

   ```
   python3 .claude/skills/tasting-room/scope.py plan "factory/Products/[product]"
   ```

   It resolves the selection (the `Main pick:` row, or the recovered record with its `selection_source:`) and the CURRENT revision of every selected file off the disk, and prints what each race owes, with any FAIL a scorecard already recorded attached to the frame it is about, the gallery count beside the live count, and any `other model:` line from `incumbent/notes.md`. When no selection is on record and nothing recovers it, it prints the one question and exits non-zero: stop there and put the question to the owner. When the owner answers, write the answer as the `Main pick:` row under INVENT in `status.md` (the same row `/inspect` writes: `Main pick: main-13 (primary); alternatives: main-06, main-03; backup: [file]`), re-run `scope.py plan`, and continue. The row is the record; the answer in chat alone is not. **Scope stops being a judgment call.** The failure this prevents: eight frames approved, one tested, seven never tested including one already known to be broken, and nothing anywhere saying so. "The approved candidates" in prose is a wish; two records that must agree with no code comparing them will drift, and the drift is invisible.

1. **Name the scenario, and name the RACES.** A sitting is TWO races: the MAIN race (Scenario B) and the GALLERY race (Scenario C). Two runs, two configs, two `out_dir` folders, two cards. Never merge them into one run: a main image and a gallery answer different questions and a merged grid answers neither. State the plan in one line, then reconcile at the end: races planned = races run + races skipped with a named reason. A quietly missing race is the failure this step exists to prevent.

2. **Resolve, print ONE block, then run.** Resolve the product, the selected image versions (Before you start, item 2), the buyer profile (`research/persona.md`) and the benchmark (`incumbent/`: reuse valid saved files, fetch only when missing or stale per step 0b). Open each candidate once with Read so you know which version it is. Then print ONE block: the main lineup by exact filename in row order, the gallery order by exact filename with its frame count next to the incumbent's count, the benchmark named (`main-live.png` from [date], or `competitor [name]`), and the estimated cost per race from step 5. Then run both races immediately. Never ask whether to proceed, and never re-confirm a selection that `status.md` already records. The block is a record the owner reads, not a question they answer.

3. **Assemble each config.** Wonka writes the JSON; the owner never does. Fields:

   | Key | Required | Notes |
   |---|---|---|
   | `product`, `product_context` | yes | `product_context` is ONE honest line: what it is plus its listed features. Every word of it comes from the Reference Sheet and the research, never from imagination. |
   | `images` | yes | 2 to 12 entries. Single image = `path`. A whole gallery = `paths` in gallery order. |
   | `incumbent_id` | yes on a main race | Must match one of the candidate ids exactly. |
   | `demographics` | recommended | Copied from `research/persona.md`, shaped `{"age_dist": {"35-44": 0.5, "45-54": 0.5}, "gender": {"female": 0.8, "male": 0.2}, "income": {"middle income": 1.0}, "notes": "one line on who this is, plus estimated when it is derived"}`. Omit the block entirely and the engine uses its stated default. |
   | `out_dir` | yes | Absolute path, one folder per race: `tests/tasting-r[N]-[YYYY-MM-DD]-main` and `...-gallery`. |
   | `round` | yes | 1, or N when the owner asked for another comparison. It prints on the card. |
   | `compare_to` | another comparison | Absolute path to the matching Round 1 `results.json`. |
   | `spend_cap_usd` | optional | Default 10.0, per SITTING (both races together). The engine estimates each race before the first request and refuses over the cap. Raise it in both configs only after the owner answered yes to the cap question, for that sitting only. |
   | `selection_source` | yes | Where the main lineup came from: `status.md Main pick row`, or the recovered record `scope.py plan` named. Copied into the round notes. |
   | `models` | optional | Default is a mix of two OpenAI models, `{"gpt-5.4-mini": 0.6, "gpt-5.4": 0.4}`, on the one key the Factory already has. Two models disagree where one model's private taste would quietly become "the verdict": a single-model panel once called a 75/25 that a mixed panel read as 45/55. Leave this key out; write it only when the owner explicitly asks for a specific model. |
   | `seed` | optional | Default 42. The run is seeded, so the same config replays the same panel and the same shuffles. |

   **BLIND rule.** No label may hint at outcome or ownership: no "new", "ours", "winner", "old", "improved". The engine already hides labels from the tasters and swaps them for neutral aliases before it synthesizes themes, so the leak this rule closes is the HUMAN one: labels print all over the card, and "our new design" tells the person reading the verdict what to think before they have read it. Incumbency travels only through `incumbent_id`.

   **Id stability across comparisons.** Keep candidate ids IDENTICAL across rounds. The refined winner is a new FILE (the same filename inside a new `edits/vN/` round folder, or a regenerated `main-01-v2.png`) that keeps its Round 1 id (`main_01`), which is the only thing that lets the card draw an arrow between the rounds instead of showing two unrelated bar charts. Rename a candidate id between rounds and the delta is gone.

4. **Save the config into its round folder as `config.json`.** The engine also writes it there if it is missing, and never overwrites one that already exists, so the reproducibility record cannot be forgotten and cannot be quietly rewritten.

4b. **If there is no incumbent, race the competitors instead.** A brand-new product with nothing live has no current image to beat, and racing your candidates only against each other answers a much weaker question. **Use the strongest competitor's main image, and their gallery, as the benchmark.** Wonka copies them, the owner files nothing: from `1-inputs/competitors/[name]/` into `incumbent/` as `competitor-main.png` and `competitor-01..NN.png` in that listing's gallery order, then reads each file's pixel size back. Those files take the `incumbent_id` slot in both races. Say out loud which competitor was used and why, and record `benchmark: competitor [name]` in the round notes and `"benchmark": "competitor [name]"` in the config, because "beat the category leader" and "beat my own previous image" are different claims and the Card should not blur them: the engine reads that key and the card prints `[BENCHMARK: competitor [name]]` and "beats the benchmark" in place of the live-image wording. Without the key the card calls the incumbent your live image.

4c. **Say how long it takes, and point at the live view.** A full sitting is not instant. Tell the owner plainly that it runs for a while, that `live.html` opens by itself in the browser and refreshes on its own, and that the honest thing to do is **go and do something else and come back.** Watching a progress bar is not participation. If the page does not open, `progress.json` in the round folder carries the same information, and `PANEL_OPEN_LIVE=0` suppresses the auto-open for anyone who does not want a browser tab appearing.

5. **Estimate, check the cap, run.** Price the sitting before the first request:

```bash
python3 .claude/skills/tasting-room/panel.py estimate [main config.json] [gallery config.json]
```

   It prints `Estimated: about $X for this race (cap $10 per sitting)` per race and the sitting total, from the tasters, the candidates and their frames, the per-image sample, the model mix and a dated list-price table (`PRICES_PER_1K_USD`, prices as of September 2026, kept conservative). `run.py` prints the same line again when each race starts, and the engine checks each race against the cap on its own before sending anything; `panel.py estimate cfg-main.json cfg-gallery.json` is the sitting check Wonka runs first. A standard sitting (three or four mains, a gallery of six to eight frames) lands under the cap, about $7 to $9; the largest lawful selection (five mains, a nine-frame gallery against nine live frames) estimates just over it and may ask once. Under the cap: say the two lines and run. Over the cap (exit 1): ask the owner ONCE, "This sitting estimates about $X, above the $10 cap. Run it anyway?", and a yes runs it with `spend_cap_usd` raised in both configs for this sitting only. That raise is the one lawful edit of a round folder's `config.json` before the race runs. A comparison the owner asks for later, or a re-run after a bad parse rate, gets its own estimate line the same way. If the API returns usage, the engine keeps a running total and writes it to the quality block of `results.json` as `spend_usd_estimated`; when it does not, the block says so. A race is never stopped mid-way on the running total; the cap is enforced on the estimate.

6. **Run it** from the kit root, once per race, after `scope.py lineup` has passed the config:

```bash
python3 .claude/skills/tasting-room/scope.py lineup "factory/Products/[product]" [config.json]   # same files, same order as the printed block
python3 .claude/skills/tasting-room/run.py [config.json]          # full tasting
python3 .claude/skills/tasting-room/run.py [config.json] lite     # quick taste, about a fifth of the tasters
```

   Windows uses `python` instead of `python3`. Before spending anything the engine refuses a broken config out loud (a file that does not exist, two candidates sharing an id, an `incumbent_id` matching no candidate, more than 12 candidates or 12 frames) and it checks that every provider in the model mix has its key. Let it check; it costs nothing and it is cheaper than finding out at minute four. A live progress page (`live.html`) opens and self-refreshes with a stall detector, so a minutes-long run is never a silent terminal. Set `PANEL_OPEN_LIVE=0` to skip the auto-open. **If it stops for any reason (sleep, a closed laptop, a dropped connection), run the SAME command again: it resumes from its checkpoint instead of restarting, and nothing is paid for twice.**

6b. **Record the race, then gate on the coverage.** After each race finishes:

   ```
   python3 .claude/skills/tasting-room/scope.py record "factory/Products/[product]" "<that race out_dir>"
   ```

   Coverage ACCUMULATES: recording the gallery race must never erase the main race, and a second round registers its own row instead of adopting round 1's. Then, before telling the owner the room is done:

   ```
   python3 .claude/skills/tasting-room/scope.py check "factory/Products/[product]"
   ```

   It BLOCKS while anything approved is neither tested nor waived. A deliberate skip stays possible (`scope.py waive <product> <file> "reason"`); a silent one does not. **Run the gate BEFORE asking the owner to decide anything: putting a partial round in front of them is the wrong question.**

7. **Verify the run actually landed, before reading anything.** List the round folder and confirm four files: `config.json`, `results.json`, `tasting-card.html`, `tasting-card.md`. Then open the quality block in `results.json` (or look for the red banner at the top of the card): if `choice_parse_rate` is under 0.9, the counts sit on a reduced sample. Say so, re-run (it resumes and retries the gaps), and do not present the result as solid until it clears. If the run failed, the room has no result. Say that plainly and stop; a described card is a fabricated card.

8. **Read the Tasting Card** (`tasting-card.html` in the round folder, `tasting-card.md` is the compact text twin). It reads top to bottom:

   1. **Header.** Product, round, date, panel size, models, mode. A red data-quality banner appears here when a parse rate fell under 90%. A card wearing that banner is weaker evidence, so re-run before acting on it.
   2. **Verdict card, the DECISION layer.** The winner by exact filename, the one-line verdict, the panel's first proposal, the read-and-decide line ("Read the objections, then tell Wonka which changes to make."), and the stability tier from bootstrap resampling the recorded votes (1,000 resamples; the card states in how many the winner held and how many flipped votes would change the result). **Clear lead** (holds in 95% or more AND purchase intent separates them by at least +0.25 of 5): act on it. **Lean** (80 to 95%, or stable-but-tiny): a real lean, not proof. **Toss-up** (under 80%, or the base models disagree): a tie.

      **Why a top tier needs two things.** The bootstrap answers "would resampling these same tasters flip the winner", which a near-unanimous vote never does. It says nothing about SIZE. A forced binary choice converts any consistent preference into a landslide however small it is, so a 76-4 vote can sit on a purchase-intent gap of +0.06 of 5, about 1% of the scale. Reported alone the count would claim a certainty the run never had. Direction is checked first and a big intent gap never rescues an unstable vote. The +0.25 bar is PROVISIONAL and gets refit as real results accumulate in the Improvement Log.
   3. **Candidate cards.** Image, the vote COUNT, purchase intent (which is also the magnitude gate, not decoration), then "What worked" and "What hurt" chips with mention counts (x6 = six tasters raised it), every raw reaction collapsed underneath. Set candidates show the filmstrip.
   4. **Frame by frame (Scenario C, the DIAGNOSIS layer).** Within-set votes per frame (most convincing, weakest), boosts / neutral / hurts, per-frame notes, and a one-line lead on which frame to lead with and which to fix or drop. This layer feeds `/fix`, never the verdict.
   5. **Segments.** Mean intent by age band, gender, and with a model mix per base model. Disagreement between base models is called out in red.
   6. **What the tasters keep saying.** The recurring objections ranked by mentions, tagged with the candidates they apply to. The most portable output of the whole room.
   7. **Suggested fixes.** Numbered and concrete: proposals, guarded by step 10.
   8. **Round comparison** (when `compare_to` is set, on a comparison the owner asked for). Previous votes, current votes, delta in votes.
   9. **Footer.** The honest framing and the method line.

9. **Present the verdict honestly, out loud, every time.**
   - These tasters are language models playing shoppers. Synthetic preference is not real-shopper behaviour or conversion evidence. Never present the numbers as real shopper results, to the owner or in any file.
   - Use the standardized labels: Clear lead, Lean, Toss-up. Anything under Clear lead is a lean, not proof.
   - Say the vs-incumbent result explicitly, win or lose.
   - A single-model panel carries one shared taste. If the per-model rows disagree on the winner, say "no reliable verdict", keep the objections and drop the counts.
   - The most reliable output is the relative ranking plus the recurring objections. Those travel. Exact counts do not.
   - For a real-money decision, a real shopper poll (the optional Pro Move bonus) is the gold standard, and an on-Amazon A/B outranks everything.

10. **List the candidate changes as proposals, then STOP.** After both races land: open both cards, summarise each race in a few lines (winner, count, label, the top two or three recurring objections), then list the CANDIDATE changes with their evidence. "Three mentions" is a reason to look, not an order: every proposal is checked against the actual image and the product research before it is offered. Each recurring objection ends in exactly one of three states, in writing, and all three are proposals, not actions:
    - **Proposed surgical edit.** Word swaps, removals, shortenings, for `/fix` MODE B, each citing the objection and its mention count.
    - **Proposed regeneration.** Layout, framing, size in frame, casting and anything spatial, for `/main-image` or `/secondary-images`, with the exact sentence the tighter brief would carry.
    - **Refused, with the reason.** A synthetic objection that contradicts the research (the selling points, the Reference Sheet, the Improvement Log) is listed as refused, with the evidence that outranks it, and never offered as a change. The panel is directional; the research is evidence.
    Then Wonka stops. He does not edit, regenerate, or start another race by himself. Once the owner names the changes, they run under the routine-fix policy (`CLAUDE.md`, `/fix`) without per-operation approval prompts, and every pre-fix original is kept so the on-Amazon A/B, or a comparison the owner asks for, can show whether a change helped. **If no theme reached three or more mentions, say so: the winner has no documented flaw and the list is empty.** Changing a winner without a reason is how winners get broken.

11. **Log the experiment, one row per race, in the same session.** Append to `factory/Improvement Log.md` in the canonical 8-column schema:

    `| Date | Product | Type | Candidates | Winner | Margin | Key why | Status |`

    Type `tasting-room`. Candidates names the race and includes "incumbent". Margin like "preferred by 54 of 100 synthetic tasters vs 31, intent +0.31 of 5, round 1, Clear lead". Key why is the top recurring objection in the tasters' words. Status is `won`, `lost` or `inconclusive`, and it is `inconclusive` whenever the label is not Clear lead OR the base models disagreed. A synthetic tasting does not wait for anything, so the row is written now. When the owner later selects a final set after an inconclusive or unfavourable result, the Status stays as it was and Key why gains the suffix `owner-shipped`; the 8-column schema is never widened. Never relabel a Lean or a Toss-up as a win.

12. **Hand off: the reports are on the table, the owner decides.**
    - **The owner names the changes.** They run under the routine-fix policy (`/fix` MODE B on the main winner and on the gallery frames named, everything back through `/inspect`), and the set is FINAL when the owner says so. **Accepting the set is the owner's Day 8 decision, and it is written as its own line**: `Owner decision: approve the Day 8 image set, [round folder], after [label] on round [N], [date]` (or `Owner decision: ship [files], after [label] on round [N], reason: ...` when the owner said ship). That line completes Day 8. This room owns writing it: when both cards are already on disk and the owner states the decision in words, `/tasting-room` (or the words "I approve the Day 8 set") records the `Owner decision:` line and the `Next stage:` line and runs NOTHING. It does not skip variations and it does not authorise packaging: the approval, the panel verdict, and a later stage's completion are three different records. `/ready-to-upload` becomes AVAILABLE on that line and runs only when the owner invokes it, after Day 9 (variations done, or skipped in writing); the pack labels a file revised after testing `revised after test`, citing this round's card. `python3 .claude/skills/ready-to-upload/stage_gate.py "factory/Products/[product]"` prints which stage is next; read it rather than deciding.
    - **Another comparison is optional and purposeful.** It answers a concrete question, normally a meaningful revision or a new candidate. Wonka may suggest one when it would answer something ("the size callout changed on the winner; a comparison against the incumbent would show whether that moved the vote"); he never launches it. If the owner asks, the request is the authorisation: state the estimate and run within the cap, with `compare_to` wired and ids kept stable. Unchanged images are never re-raced to look for a better number.
    - **The owner may select a final set after an inconclusive or unfavourable result.** The panel outcome is preserved as it was. The owner's decision is recorded on its own line in the round notes and in `status.md`: `Owner decision: ship [files], after [label] on round [N], reason: ...`. Never relabel a Lean or a Toss-up as a win, and never argue the owner out of their listing.
    - Either way `/improvement-loop` reads these rows on Day 10.

13. **Respect an explicit stop.** When the owner says to save and end the session ("we're stopping here", "mark Day 8 complete", "next is Day 9 in a new session", in any words), write everything to disk: the `Owner decision:` line, the Log lines for this sitting, and one `Next stage:` line as the LAST entry of `status.md`, `Next stage: Day 9, variations (session ended at the owner's word, [date])`. Then stop. Do not invoke `/variations`, `/ready-to-upload` or any other skill, and do not ask the next stage's questions. A new session reads the `Next stage:` line and resumes from it. Day 9 is variations: on resume, `/variations` reuses whatever `status.md` already records, and with nothing on record it asks its one question.

## When the result is not what you hoped

Decisive answers, so nobody has to improvise one under pressure.

| The card says | What it means | What happens |
|---|---|---|
| Clear lead, and it beats the incumbent | The strongest outcome available here | List the proposals, the owner names the changes, re-inspect, the set is final on the owner's word. A comparison afterwards is optional, for a change big enough to be a different image, and only when the owner asks. |
| Lean | Directionally useful, not proof | Fine for choosing what to refine. Say it as a hint. The owner decides whether to ship on it, and the decision line records that they did. |
| Toss-up | Treat it as a tie | Use the objections, ignore the counts. The owner decides; a decision to ship is recorded as theirs, never as a verdict. |
| The base models disagree | Model taste, not shopper signal | No reliable verdict. Keep the objections, drop the counts, say it in that order. |
| The incumbent won | The cheapest good news in the factory | Say it as a save: a working listing was not downgraded, for the price of lunch, instead of finding out over months of lost traffic. Then mine WHY the incumbent holds, which is a free teardown of a proven image, and list what a new candidate would need to carry. The owner decides whether to build one, keep the live set, or ship their pick with the decision line recorded. That is the system working. |
| The owner's override lost | Normal, and worth saying out loud | Record it honestly beside the reason they gave. A recorded losing instinct is exactly what makes the next pick better, and it is why the reason gets written down before the run, not after. |
| Parse rate under 90% (red banner) | The counts sit on a reduced sample | Re-run the same command (it resumes and retries the gaps) before trusting the result. A vote the engine cannot read is DROPPED rather than guessed, which is exactly why this number can fall: a falling parse rate is the guard working, not the guard failing. |
| No theme with three or more mentions | The winner has no documented flaw | The proposal list is empty; say so rather than inventing a fix. If the owner wants another comparison, the winner against a strongest unused gate-passed candidate plus the incumbent is a concrete question it can answer. |
| An objection contradicts the research | A synthetic hunch against real evidence | Record it as refused, with the evidence that outranks it. Never act on it. |

## Output format

```
tests/
  tasting-r1-[YYYY-MM-DD]-main/        the MAIN race
    config.json          the exact configuration that ran (reproducibility)
    results.json         every raw reaction, vote, score, theme count, and the quality block
    tasting-card.html    the full Tasting Card, self-contained, images embedded
    tasting-card.md      the compact text twin, same structure
  tasting-r1-[YYYY-MM-DD]-gallery/     the GALLERY race, same four files
  tasting-r2-[YYYY-MM-DD]-main/        a comparison the owner asked for, with compare_to wired
  tasting-r2-[YYYY-MM-DD]-gallery/
```

`tasting-card.md` carries the verdict table with the standardized label, the strongest-frame list, segments, ranked objections with counts, numbered fixes, the round comparison when `compare_to` is set, and the house rules. `live.html` and `progress.json` are run-time views and can be ignored afterwards.

## Golden Standards check

Before presenting, verify:
- [ ] The scenario was named, both races were planned, and races planned = races run + races skipped with a named reason.
- [ ] The lineup was resolved from the `Main pick:` and `Gallery pick:` rows (or a recovered record named by `selection_source:`), printed once as ONE block with both gallery counts and the estimate, never re-confirmed, and `scope.py lineup` passed every config; each file was opened once with Read.
- [ ] The incumbent is one of the candidates on every main race, or `pre-launch, no incumbent` is recorded in writing.
- [ ] The owner's picks are recorded, and any override of the scorecard rank carries its one-line reason.
- [ ] Demographics came from `research/persona.md` with the REAL buyer age, never the aspirational casting age, and a derived persona carries the word `estimated`. A default fallback is recorded as such.
- [ ] No candidate label hints at outcome or ownership; incumbency travels only through `incumbent_id`.
- [ ] The estimate line was printed for each race, the sitting stayed under `spend_cap_usd`, or the owner answered the one cap question before anything ran.
- [ ] `config.json`, `results.json`, `tasting-card.html` and `tasting-card.md` all exist in every round folder, and the folder was actually listed to confirm it.
- [ ] The parse rate was checked; anything under 90% was flagged and re-run rather than presented as solid.
- [ ] The verdict was presented with its standardized label, the vs-incumbent result, and the model-disagreement check, and the Pro Move line (a real poll is the gold standard) was said with it.
- [ ] Any further comparison was asked for by the owner, answers a concrete question, set `compare_to` to the matching earlier `results.json` and kept every candidate id stable.
- [ ] Every recurring objection is listed as a proposed edit, a proposed regeneration, or refused with the evidence that outranks it, and Wonka stopped after the list. Nothing ran that the owner did not name.
- [ ] One `Improvement Log.md` row per race, with Status `inconclusive` whenever the label is not Clear lead or the models disagreed.
- [ ] Nothing anywhere presents panel numbers as real shopper results, and no card, quote or count was written by hand.
- [ ] All outputs are in English with zero em or en dashes.

## Two rules learned from a round that did not move the number (27 August 2026)

**Decompose a compound objection before routing it.** A theme like "cannot judge tip quality or durability" is TWO objections wearing one label, and they route differently: fineness is provable by a picture, durability is a promise no frame may make. A fix was built for the provable half, the frame passed every gate, and the objection COUNT ROSE from 46 to 61 because the half that generates the mentions was never addressable. So: split every theme into its halves, say which half each fix answers, and say out loud when the other half is unanswerable by an image at all. That sentence is the honest finding, and it belongs in the card rather than in another round.

**Never re-race unchanged candidates.** The panel is seeded, so the same config plus the same images replays the same verdict exactly; a re-run on an untouched race buys zero information at full price. A second race is lawful only when the exhibit actually changed. And when the fixes landed on only part of a set, keep everything else identical (same seed, same panel, same untouched frames) so the round is a PAIRED comparison and any movement traces to the frames that changed. Measured on that design: the two replaced frames moved 17 weakest-votes between them and the rest of the set absorbed exactly 17, which is what proves the movement was real and not drift.

## Wonka lines

Openers:
- "To the Tasting Room. A hundred tasters are waiting, and not one of them is polite."
- "My opinion retires at this door. Let the panel chew on it."
- "Bring the incumbent too. In this room, reality always gets a seat at the table."
- "Read me the filenames. I have never once regretted spending ten seconds before spending ten dollars."

Closers:
- "The panel has spoken, directionally. main-01 takes the golden ticket, and the notes tell us exactly what to sharpen."
- "The tasters split by model, which means no verdict at all. We take the objections and leave the counts."
- "The incumbent held. Wonderful. It just saved you from shipping a prettier, weaker image, and it cost you pocket change."
- "They voted for the cascade and then asked how big the thing is. They gave us the winner and the next fix in the same breath."
- "Two cards, two races, one afternoon. Now we do the part that most sellers never do: we listen to them."

## Definition of Done

- Every planned race has its round folder on disk with all four files present, confirmed by listing the folder. A race that did not run is recorded as a named skip, never left silent.
- The verdict was presented with the honest framing: the standardized label, the vs-incumbent result, the model-disagreement check, and the Pro Move gold-standard line.
- The owner's picks, and any override with its reason, are on the record.
- `factory/Improvement Log.md` carries one row per race, Status filled.
- Every recurring objection is listed as a proposal (edit, regeneration) or refused with its reason, and the room stopped after the list.
- `status.md` updated per below, and the owner knows the exact next step: read the objections, name the changes, and the set is final on their word, written as the `Owner decision:` line; Day 9 (variations) is next, and `/ready-to-upload` runs only when they invoke it after that. Another comparison only when the owner asks for one.
- An explicit stop was honoured: the `Next stage:` line is the last entry in `status.md` and nothing else was invoked.
- If any line above is missing, the room is NOT done. Say which line, and never fill the gap with a written-out card.

## Update status.md

Set PROVE to `in progress` with the round folders as the artifact. This room never sets it `done`: that belongs to `/ready-to-upload` when the pack exists, or to `/improvement-loop` when the owner closes the cycle without packaging. When the owner accepts the set, write the `Owner decision:` row under INVENT sub-status (`approve the Day 8 image set, [round folder], after [label] on round [N], [date]`, or the `ship ...` form when they said ship) and the same as a Log line. On an explicit stop, the last Log line is `Next stage: Day 9, variations (session ended at the owner's word, [date])`. Add one Log line per race: `[date] Tasting Round [N] [main/gallery]: [winner] preferred by [N] of [M] tasters, intent +[G] of 5, vs incumbent [beaten/held], [n] tasters, [Clear lead / Lean / Toss-up]. Owner picked [files][, overriding rank [N] because "[reason]"]. Proposals listed: [N] (edits [n], regenerations [n], refused [n]) / none, no theme reached 3 mentions. Owner named: [changes, or pending]. See tests/tasting-r[N]-[date]-[race]/.`

## Troubleshooting

- **"OPENAI_API_KEY is missing"**: the key goes in the `.env` file at the Factory root (the Day 1 setup). `guides/mcp-setup-guide.md` walks through it.
- **"CONFIG PROBLEM(S). Nothing ran and nothing was spent"**: the preflight caught a broken config before the first call. It prints the exact lines to fix (a missing file, a duplicate id, an `incumbent_id` that matches no candidate, too many candidates or frames). Fix and run the same command again.
- **The run stopped mid-way** (sleep, network, a closed terminal): run the exact same command again. The checkpoint in the round folder resumes it, nothing is lost and nothing is charged twice.
- **The run stopped OUT OF CREDITS: top up and run the same command again.** It says so itself now, by name, and it stops the moment the balance is empty instead of grinding through retries that cannot work. Everything already answered is banked, and the re-run asks only the tasters who never answered. FIXED 26 August 2026, with a regression test (`test_resume.py`). What it used to do, because the shape is worth knowing: a dead balance came back as an error STRING rather than an exception, the engine filed those strings as finished reactions, the checkpoint saved them as done, and the resume after the top-up had nothing left to ask. The round came back with panels of 19 and 23 instead of ~100, no forced choice anybody had voted in, and a Toss-up verdict computed on the rubble. Nothing anywhere said the room had been almost empty. Two guards now stand where that happened: **a failed call is never written to the checkpoint** (so a resume always re-asks it), and **a panel under 70% refuses to produce a verdict at all** rather than warning about one. Changing images, counts, models or seed resets the checkpoint on purpose; adding `compare_to` does not.
- **A red data-quality banner, or a console warning about parse rates under 90%**: some votes did not come back readable, so the counts sit on a smaller sample. Usually a flaky connection. Re-run before trusting the result.
- **The Round Comparison section is missing**: `compare_to` must be an ABSOLUTE path to the previous round's `results.json`, and the candidate ids must match across rounds. The console prints a note when the file could not be read.
- **A run that takes an hour is broken, not slow.** Full tastings finish in minutes. Stop it and run the same command again.
- **"gemini-* taster models need GEMINI_API_KEY"**: a config explicitly asked for a Gemini taster model. Add that key to the `.env`, or remove the `"models"` block so the default OpenAI mix runs on the key the Factory already has.
- **Missing Python packages**: `python3 -m pip install openai numpy python-dotenv pillow`, once. Pillow also powers the automatic downscaling that keeps requests small and fast.

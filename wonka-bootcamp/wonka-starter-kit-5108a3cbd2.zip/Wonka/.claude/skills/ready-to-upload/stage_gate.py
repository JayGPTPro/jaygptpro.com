#!/usr/bin/env python3
"""The stage gate: which stage a product is at, read from status.md, in ONE place.

Written after 14 September 2026. The owner wrote "mark Day 8 complete", "We're stopping
here" and "Next is Day 9: product variations, in a new session." Wonka recorded the
approval, then invoked /ready-to-upload and started packaging. Three records had been
read as one: the owner's approval of the Day 8 images, the panel's verdict, and a
completion of the later stages. Nothing in code separated them, so prose in four skills
each drew its own line and the lines disagreed.

This module answers four questions from `status.md`, and every room that routes
between Day 8, Day 9 and Day 10 reads the answers here instead of deciding for itself:

  day8_decided                an `Owner decision:` line stands (approval of the image set,
                              or a ship decision), not a placeholder and not withdrawn
  variations_done_or_skipped  the Variations sub-part reads done / n/a / skipped / a family
  next_stage                  "day8" | "variations" | "ready-to-upload", derived from the
                              two records above, never from a label or a verdict
  stop_requested              the record ENDS on a `Next stage:` line that says the session
                              ended at the owner's word, so a new session resumes and asks
                              for nothing the owner already answered

Plus one predicate: `ship_gate(product_dir, invoked)`. The Shipping Room opens only when
the owner invoked it (or asked to package in words) AND Day 8 is decided AND variations
are done or skipped. A passed Tasting Room gate makes the room AVAILABLE; it never opens
it. The refusal names the missing record in one line.

Usage:
    python3 stage_gate.py <product folder>            print the four answers
    python3 stage_gate.py <product folder> --ship     exit 1 unless the Shipping Room may
                                                      run (pass --invoked when the owner
                                                      invoked it or asked in words)

Stdlib only, no network, reads one file.
"""
import re
import sys
from pathlib import Path

VARIATIONS_QUESTION = "Do you have any product variations you'd like to create images for?"

STAGE_NAMES = {
    "day8": "Day 8: the owner's decision on the tested set (an `Owner decision:` line)",
    "variations": "Day 9: variations (/variations, or an explicit skip recorded as "
                  "`Variations: skipped (owner, [date])`)",
    "ready-to-upload": "Day 10: /ready-to-upload, when the owner invokes it",
}

# A template value starts with "[" (and may carry a note after the bracket), or is
# a bare "none yet" / "tbd", or is a menu of choices separated by " | ".
_PLACEHOLDER = re.compile(r"^\s*(\[|(none yet|tbd)\s*$)", re.I)
_BULLET = r"^\s*(?:[-*]\s*)?(?:\d{4}-\d\d-\d\d\s+)?\**"


def entries(text):
    """Logical entries of a status.md: a list item, a table row, a heading or a
    non-indented line starts one; indented continuation lines belong to it.

    Log entries are hard-wrapped with indented continuations and no blank lines
    between them, so paragraphs are the wrong unit and physical lines are too."""
    out = []
    for raw in text.splitlines():
        if not raw.strip():
            continue
        if raw[:1] in " \t" and out:
            out[-1] += " " + raw.strip()
        else:
            out.append(raw.strip())
    return out


def _value_after(label, entry):
    """The text after `label:` in an entry, or None when the label is absent."""
    m = re.search(re.escape(label) + r"\s*:\s*(.*)$", entry, re.I)
    return m.group(1).strip().strip("*").strip() if m else None


def _is_placeholder(value):
    return value is None or not value.strip() or bool(_PLACEHOLDER.match(value)) or " | " in value


def _latest(label, ents):
    """The last entry carrying `label:`, with its value. Latest record wins."""
    for e in reversed(ents):
        v = _value_after(label, e)
        if v is not None:
            return e, v
    return None, None


_DATE = re.compile(r"\b(\d{4}-\d\d-\d\d)\b")
_DECISION_ROW = re.compile(_BULLET + r"Owner decision\s*:\s*(.*)$", re.I)
_SENTENCE_END = re.compile(r"\.(?:\*\*)?(?:\s|$)")


def _decision_value(entry):
    """The decision itself: the text after an entry-leading `Owner decision:` up to
    the end of its first sentence. An entry that only MENTIONS the label mid-line
    (a correction quoting the withdrawn line) is not a decision entry."""
    m = _DECISION_ROW.match(entry)
    if not m:
        return None
    v = m.group(1).strip()
    cut = _SENTENCE_END.search(v)
    if cut:
        v = v[:cut.start()]
    return v.strip().strip("*").strip()


def day8_decided(ents):
    """An `Owner decision:` line that is a real decision.

    `[none yet]` is the template. Only the decision VALUE is judged (the text after
    the label, to the end of its sentence): a re-approval that mentions an earlier
    withdrawal in a trailing remark ("the earlier ship line stays withdrawn") is a
    decision. A decision is withdrawn when its value starts with `withdrawn`, or
    when a LATER entry withdraws it (on 14 September 2026 the correction was
    written as a later entry quoting the withdrawn line)."""
    idx, value = None, None
    for i in range(len(ents) - 1, -1, -1):
        v = _decision_value(ents[i])
        if v is not None:
            idx, value = i, v
            break
    if idx is None or _is_placeholder(value):
        return False
    if re.match(r"^(withdrawn|pending|not yet|none)\b", value, re.I):
        return False
    for later in ents[idx + 1:]:
        if re.search(r"\bwithdrawn\b", later, re.I) and re.search(r"decision|ship line", later, re.I):
            return False
    return True


_VAR_ROW = re.compile(_BULLET + r"Variations(?:\s*\(/variations\))?\s*:\s*(.*)$", re.I)
_VAR_DONE = re.compile(r"^(done\b|n/a\b|n-a\b|skipped\b|none \(single SKU\)|family of \d+)", re.I)


def _entry_date(entry, value):
    """The date a record carries: the leading `YYYY-MM-DD` of a Log line, else the
    first date inside the value, else None (an undated sub-status row)."""
    m = re.match(r"^\s*(?:[-*]\s*)?(\d{4}-\d\d-\d\d)\b", entry)
    if m:
        return m.group(1)
    m = _DATE.search(value)
    return m.group(1) if m else None


def variations_state(ents):
    """'done' | 'pending' | 'unset', from the NEWEST Variations record.

    File position is not chronology: the sub-status row sits above the Log, and
    /variations rewrites it to `in progress` when a pilot starts, after a Log line
    that may already read `skipped (owner, [date])`. So records are ordered by the
    date they carry, and an undated real sub-status row (not `pending`) counts as
    the current word."""
    records = []  # (date or None, position, value)
    for i, e in enumerate(ents):
        m = _VAR_ROW.match(e)
        if not m:
            continue
        v = m.group(1).strip().strip("*").strip()
        if _is_placeholder(v):
            continue
        records.append((_entry_date(e, v), i, v))
    if not records:
        return "unset"
    undated_real = [r for r in records if r[0] is None and not re.match(r"^pending\b", r[2], re.I)]
    if undated_real:
        newest = undated_real[-1]
    else:
        newest = max(records, key=lambda r: (r[0] or "", r[1]))
    return "done" if _VAR_DONE.match(newest[2]) else "pending"


def variations_done_or_skipped(ents):
    return variations_state(ents) == "done"


# Anchored to the START of an entry (a sub-status row or a dated log line), so the
# TEMPLATE's own example text ("e.g. Variations: n/a ...") never reads as a record.
_VAR_INFO = re.compile(
    _BULLET + r"(Type\s*:\s*[AB]\b|Variation type\s*:|child list\s*:|children\s*:|variation theme\s*:|"
    r"Variations\s*:\s*(family of|skipped|none \(single SKU\)|n/a|child list|type [AB]))", re.I)


def variations_on_record(product_dir, ents):
    """True when status.md or the product folder already holds variation
    information (a child list, sources, Type A/B, a plan, child reference
    folders, or an explicit skip). Then the one question is never asked."""
    if variations_state(ents) == "done":
        return True
    if any(_VAR_INFO.match(e) for e in ents):
        return True
    p = Path(product_dir)
    if (p / "variations" / "variations-plan.md").exists():
        return True
    if (p / "variations-work" / "manifest.json").exists():
        return True
    refs = p / "2-reference" / "variations"
    if refs.is_dir() and any(d.is_dir() and not d.name.startswith("_") for d in refs.iterdir()):
        return True
    return False


def variations_question(product_dir, ents):
    """The ONE question Day 9 may ask, or None when the record already answers it."""
    if variations_on_record(product_dir, ents):
        return None
    return VARIATIONS_QUESTION


def stop_requested(ents):
    """True when the record ends on a `Next stage:` line with a real value.

    Any real value counts (`Day 9, variations` with or without the session-ended
    remark): the guides and the Tasting Room write the same line, and a reader
    that demanded extra words would miss the stop. Only the LAST entry counts: once a later session writes any log line, the
    stop is history and the answer is False again."""
    if not ents:
        return False
    v = _value_after("Next stage", ents[-1])
    return not (v is None or _is_placeholder(v))


def recorded_next_stage(ents):
    entry, value = _latest("Next stage", ents)
    return None if _is_placeholder(value) else value


def next_stage(ents):
    if not day8_decided(ents):
        return "day8"
    if not variations_done_or_skipped(ents):
        return "variations"
    return "ready-to-upload"


def read(product_dir):
    p = Path(product_dir) / "status.md"
    if not p.exists():
        sys.exit(f"no status.md in {product_dir}")
    return entries(p.read_text(encoding="utf-8", errors="replace"))


def ship_gate(product_dir, invoked, ents=None):
    """(open, reason). The Shipping Room runs only on all three; the reason names
    the ONE missing record, in the order it is owed."""
    ents = read(product_dir) if ents is None else ents
    if not day8_decided(ents):
        return False, ("REFUSED: no `Owner decision:` line stands in status.md. "
                       "Day 8 closes on the owner's decision; the Shipping Room waits for it.")
    if not variations_done_or_skipped(ents):
        return False, ("REFUSED: Variations are not done or skipped in status.md. Day 9 comes "
                       "first: run /variations, or record `Variations: skipped (owner, [date])` "
                       "on the owner's word.")
    if not invoked:
        return False, ("REFUSED: the owner has not invoked /ready-to-upload or asked to package "
                       "in words. A passed gate and an approval make this room available; "
                       "only the owner's ask opens it.")
    return True, "OPEN: Day 8 decided, variations done or skipped, invoked by the owner."


def report(product_dir):
    ents = read(product_dir)
    stage = next_stage(ents)
    q = variations_question(product_dir, ents)
    lines = [
        f"day8_decided: {day8_decided(ents)}",
        f"variations_done_or_skipped: {variations_done_or_skipped(ents)}",
        f"variations_on_record: {q is None}",
        f"stop_requested: {stop_requested(ents)}",
        f"next_stage: {stage}  ({STAGE_NAMES[stage]})",
    ]
    rec = recorded_next_stage(ents)
    if rec:
        lines.append(f"recorded Next stage line: {rec}")
    if stage == "variations" and q:
        lines.append(f"ask, once, and nothing else: {q}")
    return lines


def main(argv):
    args = [a for a in argv[1:] if not a.startswith("--")]
    flags = {a for a in argv[1:] if a.startswith("--")}
    if not args:
        sys.exit(__doc__)
    product = args[0]
    for line in report(product):
        print(line)
    if "--ship" in flags:
        ok, reason = ship_gate(product, "--invoked" in flags)
        print(reason)
        return 0 if ok else 1
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))

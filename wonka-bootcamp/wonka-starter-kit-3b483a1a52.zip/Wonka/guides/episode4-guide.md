# Day 4: The Reference Room and the Brand Room

Yesterday you made a plan out of words. Today the machines learn what your product actually looks
like, your brand gets a wrapper, and then your plan becomes pictures for the first time.

Nothing you make today is meant to be good. Today's job is to find out what is wrong while finding
out is still cheap.

**The sentence for the day: until you see it, you do not actually know.**

## What you will have by the end of today

- **The Mold**: a Product Reference Sheet, one picture that locks your product's front, back, sides,
  detail, material and true size, judged against five real criteria and revised until it is right
- **A Brand Kit** (`factory/Brand/brand-kit.md`): colors as hex codes, font direction, tone, logo
  rules and your approved claims table, plus a Genrupt branding preset **attached to your plan**
- **A passed smoke test**: one cheap image per slot, opened and read by you, twice
- **A brief you are actually happy with**, which is a different thing from a brief you approved on
  paper

**Time needed:** 60 to 90 minutes, including waiting for images to generate.

## What you will need at hand

- Your product photos in `2-reference/photos/`: every angle (front, back, both sides, top), **one
  hand-for-scale shot**, and label or texture close-ups
- Your logo file and brand colors, if you have them. **If you have neither, you are fine**, see
  lesson 2
- Your real certifications, awards and press mentions, each with proof. If you cannot prove it,
  leave it out

**Missing photos?** Take them before you start. Phone camera, plain background, daylight, twenty
minutes. It is the cheapest twenty minutes in this bootcamp and everything today depends on it.

---

## Lesson 1: The Mold

### Why the reference is a picture, not a document

Image models are enthusiastic liars about products. Ask for "a chocolate fountain" and you get A
fountain: the wrong number of tiers, a chrome tower where the real machine is steel and plastic, and
a size that belongs at a hotel wedding rather than on a kitchen counter. Charming, useless, and
genuinely dangerous if it ships, because an image that oversells is a returns problem and a
compliance problem at the same time.

So Genrupt builds a **Product Reference Sheet** from your photos: one image, with your product's
front, back, sides, detail, material and scale all locked into it. Every image this factory ever
makes for this product is poured from that one picture.

Two things people skip:

- **The back.** If you do not show it, the model invents it.
- **The hand-for-scale shot.** Scale is the single thing AI gets most wrong about products. A
  dimension in inches does not fix it. A hand in the frame does. There is an actual setting for
  this, and Wonka picks it deliberately rather than hoping.

### The five criteria, because "nice" is not one

This is where most people lose the day. They look at the sheet, think "nice", and approve it. Run
these five instead, every time:

1. **Is every angle actually here?** Front, back, both sides, top. Whatever is not in this picture,
   the machine gets to invent forever.
2. **Is there a scale cue?** Can you tell how big it really is without reading anything?
3. **Is every panel clear AND attractive?** This one surprises people. A blurred or ugly panel does
   not merely fail to help, it POISONS everything poured from this mold. If your product looks cheap
   here, it looks cheap in every image after.
4. **Are the materials honest?** Steel reads as metal, plastic as plastic, glass as translucent
   glass. If a mixed-material product renders as one gleaming metal object, every image after it is
   selling something that does not arrive in the box.
5. **Has anything been added?** No text, no captions, no arrows, no badges. This sheet locks
   identity and nothing else.

### Revising is normal, not a failure

A first draft that needs two rounds is the expected case. Two rules make the loop work:

- **Name the defect in NOUNS.** "The tower reads as chrome, the base is brushed stainless." Not "it
  looks off." A machine cannot act on a mood.
- **Revise the sheet you have, never start a new one.** Starting over throws away everything that
  was already right. It is the same mistake as re-planning instead of editing a brief: same disease,
  different room.

**If the same defect survives two rounds, stop rewording.** The problem is a missing photo, not a
missing adjective. Go take the photo.

### Approved is a status, not proof

When you approve, a tool writes a flag in a database. That is all it means. An approved reference
can still produce the wrong product, which is exactly why this day has a third lesson.

---

## Lesson 2: The wrapper

### Why brand consistency is a file and not a vibe

An image can pass every quality test and still be wrong, because it does not look like YOUR brand.
Fonts drift, colors drift, tone drifts, and three products later your storefront looks like three
different companies.

The fix is boring and powerful: the brand becomes a file, and the file becomes a **branding preset**
that Genrupt applies to every image. Nobody types a color into a brief, ever. Colors and fonts
written as text into an image request override the brand engine and flatten the output.

The kit lives at the brand level, not inside a product folder, so it wraps every product you ever
run through the factory. Fill it once, benefit forever.

### No brand files? That is the normal case, and it has a real answer

Most people arrive here with a logo and a feeling. Some arrive with neither.

Wonka does not hand you a blank form and he does not interrogate you. **He proposes a complete kit**,
reasoned from three places in this order:

1. **Your product**, its real materials, colors and finish. A palette that fights your product loses.
2. **What your category actually looks like on Amazon today**, so your listing reads as a credible
   member of its shelf before it tries to beat it.
3. **What would flatter this product and this buyer.**

Every decision comes with a one-line why. You accept it, change one thing, or throw it out. That is
a proposal, and it is a real path, not a consolation prize.

### The two things that are never proposed

Everything above is taste and can be argued about. Two things are not:

- **Claims.** The approved claims table is the only list of certifications, awards and press
  mentions allowed onto any image, and every row needs proof. A palette can be invented. A fact
  cannot.
- **Your logo.** If no logo file exists, the rule is simply: no logo is drawn, approximated or
  invented, and images carry no logo until a real file exists.

### The step people miss

Creating the preset is not the same as **attaching** it. Your plan was saved yesterday, before the
preset existed. A preset that is never attached dresses nothing, and it fails SILENTLY: your images
still generate, they just come out generic and you never find out why.

So ask for both, out loud: built, and attached.

**Optional:** one style image, a single picture that says "make it feel like this". Past creative you
love, the best frame on your current listing, a page from your brand book. Exactly one, never a pile.
"I do not have one" is a complete answer.

---

## Lesson 3: The proof, and the first look

### What the smoke test prevents

You lock the mold, you feel good, you fire off a real batch, you wait, and every image comes back
with a subtly wrong product. The lock LOOKED applied. It was not. The batch is garbage and the
credits are gone.

So before spending properly, you spend badly on purpose: **one image per slot**, at the cheapest
setting, straight off the plan you approved yesterday. The number of variants is the price dial, so
one is the floor.

### Two questions, and only two

**Read one: is this my product?** Check every frame, not just the good ones:

| Check | Passes when | Fails when |
|---|---|---|
| Parts and count | every part present, every countable thing counted right | a part is missing or invented, or the count is off by one |
| Materials | each part reads as its real material | premium reads cheap, cheap reads premium, or one material swallows the rest |
| Scale | reads as the size it really is | a counter-top product renders as catering equipment |
| Nothing invented | no badge, seal or award that is not physically on the product | the model decorated your product with a compliance problem |

**If ONE frame has the wrong product, the mold is loose and the others got lucky.** Go back to
lesson 1, revise the sheet, and run the round again. **Never fix a fidelity failure by rewriting a
slot brief.** A better sentence cannot repair a bad mold.

**Read two: is this the brief I actually wanted?** Yesterday you approved words. Some people cannot
judge a brief until it is pictures, and there is nothing wrong with that.

Now that you can see it, is there a frame you do not actually want? These are all WINS:

- "I do not want that frame at all" → drop the slot, re-map its selling points
- "That is not the job I meant" → the buyer question was ambiguous, sharpen it
- "Two of these say the same thing" → merge them

**Every one of these changes the BRIEF, never the image.** Re-rolling would just give you a nicer
picture of an idea you already said you do not want. That is the most common way people waste money
in this whole process: fixing the output when the input is the problem.

### What you are NOT judging today

**Fonts. Colors. Composition. Polish.**

Not because they do not matter, they matter enormously. But they get chosen tomorrow, from far more
options than you are looking at now. Judging them today makes you throw away a perfectly good frame
for a reason that has not been decided yet.

---

## MISSION 1: Build the Mold

```
/reference-sheet
```

Wonka inventories your photos and tells you what each gap COSTS, not just that it is missing. Fill
the gaps if you can. If your product is not in your hands, say so plainly and approve the weaker
path by name:

```
Build it from the listing gallery and the review photos. I have no unit.
```

He records `source: amazon_scraped` with the date, and the smoke test now matters double.

## MISSION 2: Judge it properly, then revise

Run all five criteria before you say anything nice. Then:

```
[the defect, in nouns] The [part] is reading as [wrong thing]. It is actually
[right thing]. And [second defect].
```

Compare v1 and v2 side by side. Repeat until it passes all five. Then, and only then:

```
Approved. Lock it.
```

## MISSION 3: The wrapper

```
/brand-kit
```

With brand files, he reads and confirms. Without them, he proposes, and **you should argue with the
proposal**. Then:

```
Approved. Build the preset and attach it to the plan.
```

Then check the step people miss:

```
Confirm the branding preset is attached to my saved plan, not just created.
```

## MISSION 4: The smoke test, read twice

```
Run the smoke test.
```

**Open every frame.** Then read one:

```
Check every frame against the reference: parts and count, materials, scale,
and anything invented. Tell me which frames fail and on what.
```

Then read two:

```
Walk each frame beside its slot's job in the brief, one line each. Then ask me
if there is a frame I do not actually want.
```

Answer honestly. If a frame is wrong for you, say so:

```
Drop slot [N] entirely, I do not want that frame. Re-map its selling points in
the coverage map and update the plan.
```

When both reads pass:

```
Both reads pass. Lock the reference.
```

**Share it:** post your sheet v1 beside your final version in the group. Seeing what other people's
revision notes fixed is the fastest way to get good at writing your own.

---

## What good looks like

- Every version of your sheet is still on disk. Nothing was overwritten
- The approved sheet passes all five criteria, and you can say why for each one
- Your brand kit has real hex codes, a font direction, and an approved claims table with proof or
  nothing in it
- The preset is created AND attached, and Wonka said both out loud
- Every smoke-test frame was opened and looked at, not just the good ones
- `reference-sheet.md` carries `Smoke test: PASS` and `Reference status: LOCKED`
- If read two changed something, the brief was updated and the reason is recorded in your words

## Common mistakes

- **Approving the first sheet out of politeness.** Two revision rounds is normal. Say what is wrong.
- **"It looks off."** Not an instruction. Name the defect in nouns or nothing changes.
- **Rewording the same note three times.** After two rounds it is a missing photo, not a missing
  adjective.
- **Judging fonts and colors in the smoke test.** Tomorrow, from many more options.
- **Fixing a wrong product by editing a brief.** The mold is loose. Fix the mold.
- **Fixing a wrong idea by re-rolling the image.** You will get a nicer picture of the wrong idea.
- **Assuming the preset attached itself.** It does not, and it fails silently.
- **Skipping the smoke test because the reference says approved.** Approved is a status a tool wrote.
  Your eyes on generated images are the evidence.

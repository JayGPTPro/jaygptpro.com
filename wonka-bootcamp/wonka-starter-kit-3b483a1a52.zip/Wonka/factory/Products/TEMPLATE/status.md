# [Product Name] . Station Tracker

| Field | Value |
|---|---|
| Product name | [name] |
| ASIN | [ASIN, or "not live yet"] |
| Amazon URL | [URL or n/a] |
| Marketplace | [amazon.com / amazon.co.uk / ...] |
| Brand | [brand name] |
| Brand kit | [factory/Brand/brand-kit.md, or brand-kit-[slug].md when the Factory holds more than one] |
| Niche | [exact niche phrase, word for word] |
| Title confirmed | [yes (fetched) / yes (user paste)] |
| Reference photos source | [seller_photos / amazon_scraped (fallback)] |
| Registered | [YYYY-MM-DD] |

## Stations

| Station | Status | Artifact | Date | Notes |
|---|---|---|---|---|
| RESEARCH | pending | research/ files | | |
| BRIEF | pending | brief/creative-brief.md | | |
| INVENT | pending | 2-reference/ + images/ + aplus/ + variations/ | | |
| INSPECT | pending | scorecards/ | | |
| PROVE | pending | tests/ | | |

Status values: pending / in progress / blocked / done.
A station is `done` only when its artifact exists on disk. Never before.

INVENT sub-status:
- Main image (/main-image): pending | in progress | done
- Secondary images (/secondary-images): pending | in progress | done
- A+ (/aplus): pending | in progress | done
- Variations (/variations): pending | in progress | done | n/a (product has no variations)

INVENT is `done` only when all four sub-parts are done, or a sub-part is consciously skipped with a reason (e.g. "Variations: n/a (product has no variations)"). "Variations: pending (Day 9)" is a lawful trailing marker, not a block: the rest of the package proceeds to INSPECT and PROVE, and /variations extends the pack later.

## Owner intel

### Known winners
- [what already works for this product: past winning images, angles customers respond to]

### Must include
- [real certifications on the label, signature features, approved claims]

### Avoid
- [claims to drop, angles that flopped, comparisons the seller does not want]

## Blocked on

- [nothing right now / exact missing input, e.g. "Reviews file: top ~10 positive + ~10 critical reviews" or "3 to 5 competitor ASINs/URLs or gallery screenshots"]

## Research gaps

Anything waived or missing, in the owner's own words, with what it costs the analysis. An honest
gap beats an invented input, and this is where `/factory-report` reads them from.

- [item waived, in the user's own words] . cost: [what the analysis loses] . upgrade when: [what would close it]

## Log

- [YYYY-MM-DD] Product registered at the Front Gate.

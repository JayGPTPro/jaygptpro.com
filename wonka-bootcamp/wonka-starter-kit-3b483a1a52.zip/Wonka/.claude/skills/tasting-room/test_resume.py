#!/usr/bin/env python3
"""The resume-after-a-dead-credit-balance bug, reproduced offline.

What happened for real on 26.8.2026: the OpenAI balance ran out part way
through a tasting. Every remaining call came back as an `__ERROR__` string
rather than an exception, so the reactions loop recorded them as FINISHED work
and wrote them into the checkpoint. The run then died for real at the
embeddings call, which is not wrapped. The owner topped up and re-ran, the
checkpoint said reactions were complete, and the panel came back as 19 and 23
tasters instead of ~100, with a forced choice nobody had voted in and a
Toss-up verdict that was pure arithmetic on rubble.

The failure is silent, which is what makes it expensive: a resume that looks
like it worked, a card that looks like a result.

Two scenarios, both free:
  A. crash mid-run, then a healthy resume -> the panel must come back WHOLE
  B. a crippled panel that never crashes -> must refuse to publish a verdict

Run: python3 test_resume.py
"""
import json
import random
import sys
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

from test_e2e import png  # the same real, decodable PNG the e2e test uses

FAILURES = []
TASTERS = 20          # lite mode: 100 / 5
CANDIDATES = 3


def check(name, cond, detail=""):
    print(("  PASS  " if cond else "  FAIL  ") + name + ("  " + str(detail) if not cond and detail else ""))
    if not cond:
        FAILURES.append(name)


# The real message, verbatim from the 26.8 run. `chat()` catches the exception
# and hands this string back as if it were a taster's opinion.
QUOTA = ("__ERROR__ Error code: 429 - {'error': {'message': 'You have no credits remaining. "
         "Add credits to continue using the API at https://platform.openai.com/settings/"
         "organization/billing/.', 'type': 'insufficient_quota', 'param': None, "
         "'code': 'credit_balance_exhausted'}}")

STATE = {"budget": None, "calls": 0, "embed_dead": False}
_rng = random.Random(11)


def fake_chat(messages, model, max_tokens=220, retries=3, json_mode=False):
    txt = json.dumps(messages)[-4000:]
    hay = (" ".join(str(m.get("content", "")) for m in messages if isinstance(m, dict)) + txt).lower()

    # persona building is free: it happens before the tasting and is not what
    # this test is about
    if "persona" in hay and json_mode:
        return json.dumps({"personas": [
            {"id": f"p{i}", "age": 30 + i % 30, "gender": "F" if i % 2 else "M",
             "income": "mid", "shopping": "price aware", "note": "n"} for i in range(TASTERS)]})

    STATE["calls"] += 1
    if STATE["budget"] is not None and STATE["calls"] > STATE["budget"]:
        return QUOTA

    if "photo a" in hay or "set a" in hay:
        return json.dumps({"choice": "B" if _rng.random() < 0.9 else "A", "why": "reads better"})
    if "most convincing" in hay or "weakest" in hay:
        return json.dumps({"best": "C", "worst": "A"})
    if "objections_ranked" in hay or "cross_takeaways" in hay:
        return json.dumps({"images": {"image_1": {"takeaway": "size is unclear"}},
                           "objections_ranked": [{"objection": "cannot tell the size", "count": 4}],
                           "suggested_edits": ["a hand in frame"],
                           "cross_takeaways": ["scale is the doubt"]})
    if json_mode:
        return json.dumps({"impact": "boosts", "reaction": "clean, but the size is unclear"})
    return _rng.choice(["Looks clean but I cannot tell how big it is.",
                        "Feels premium. I would probably buy it.",
                        "Not sure about the material."])


def fake_embed_all(texts, batch=256):
    if STATE["embed_dead"]:
        # unwrapped, exactly like the real one: this is what actually killed the
        # process and left the poisoned checkpoint on disk
        raise RuntimeError("Error code: 429 - insufficient_quota / credit_balance_exhausted")
    for t in texts:
        if not str(t).strip():
            raise ValueError("embeddings API would 400 here: empty input string")
    return [[((sum(ord(c) for c in t) >> k) % 100) / 100.0 for k in range(8)] for t in texts]


def drive(panel, cfg_path):
    old = sys.argv
    sys.argv = ["panel.py", str(cfg_path), "lite"]
    try:
        panel.main()
    finally:
        sys.argv = old


def build(tmp):
    prod = tmp / "factory" / "Products" / "fondue"
    (prod / "images").mkdir(parents=True)
    (prod / "incumbent").mkdir(parents=True)
    (prod / "tests").mkdir(parents=True)
    for i, n in enumerate(["main-01.png", "main-02.png"]):
        png(prod / "images" / n, shade=120 + i * 30)
    png(prod / "incumbent" / "main-live.png", shade=90)
    return prod


def cfg_for(prod, out_dir):
    return {
        "product": "fondue fountain", "asin": "B09BDGFKXB",
        "product_context": "A 4 tier electric chocolate fondue fountain",
        "niche": "chocolate fondue fountain",
        "demographics": {"notes": "US home entertainers 30-60"},
        "seed": 42, "round": 1, "race": "main", "incumbent_id": "current_listing",
        "out_dir": str(out_dir),
        "images": [
            {"id": "main_01", "label": "hero on white", "path": str(prod / "images" / "main-01.png")},
            {"id": "main_02", "label": "hero with tag", "path": str(prod / "images" / "main-02.png")},
            {"id": "current_listing", "label": "current listing",
             "path": str(prod / "incumbent" / "main-live.png")},
        ],
    }


def run():
    import os
    if not os.environ.get("OPENAI_API_KEY"):
        os.environ["OPENAI_API_KEY"] = "sk-test-offline-stub"
    os.environ["PANEL_OPEN_LIVE"] = "0"
    import panel
    panel.chat = fake_chat
    panel.embed_all = fake_embed_all

    tmp = Path(tempfile.mkdtemp())
    prod = build(tmp)

    print("\nA. the balance dies mid-tasting, the run crashes, the owner tops up and re-runs")
    d = prod / "tests" / "tasting-r1-main"
    d.mkdir()
    (d / "config.json").write_text(json.dumps(cfg_for(prod, d)))

    # 24 calls of credit, then nothing. 20 tasters x 3 candidates = 60 reactions,
    # so most of the panel comes back as an error string that is not an exception.
    STATE.update(budget=24, calls=0, embed_dead=True)
    crashed = False
    try:
        drive(panel, d / "config.json")
    except SystemExit as e:
        crashed = True
        print(f"     run 1 stopped: {str(e)[:90]}")
    except Exception as e:  # noqa: BLE001
        crashed = True
        print(f"     run 1 died: {type(e).__name__}: {str(e)[:80]}")
    check("run 1 does not pretend to finish", crashed)
    check("no card is written from a dead run", not (d / "tasting-card.md").exists())

    # the top-up: everything healthy again, same command, same folder
    print("\n     ... credits added, same command again ...")
    STATE.update(budget=None, calls=0, embed_dead=False)
    drive(panel, d / "config.json")

    res = json.loads((d / "results.json").read_text())
    agg = res["aggregate"]
    ns = {k: v["n"] for k, v in agg.items()}
    print(f"     panel sizes after the resume: {ns}")
    check("the resumed panel is WHOLE, not the survivors of the crash",
          all(v == TASTERS for v in ns.values()), ns)

    parsed = sum(1 for c in res["choices"] if c["chosen"])
    print(f"     forced choices parsed after the resume: {parsed}/{len(res['choices'])}")
    check("the forced choice is re-voted, not resumed from the dead calls",
          parsed >= TASTERS * 0.9, f"{parsed}/{TASTERS}")

    check("no error string survives into the reactions",
          not any(r["text"].startswith("__ERROR__") for r in res["reactions"]),
          sum(1 for r in res["reactions"] if r["text"].startswith("__ERROR__")))

    print("\nB. the balance dies but nothing crashes: a crippled panel must not publish a verdict")
    d2 = prod / "tests" / "tasting-r1b-main"
    d2.mkdir()
    (d2 / "config.json").write_text(json.dumps(cfg_for(prod, d2)))
    STATE.update(budget=24, calls=0, embed_dead=False)
    stopped = False
    try:
        drive(panel, d2 / "config.json")
    except SystemExit as e:
        stopped = True
        print(f"     stopped: {str(e)[:120]}")
    except Exception as e:  # noqa: BLE001
        stopped = True
        print(f"     stopped: {type(e).__name__}: {str(e)[:80]}")
    check("a panel this thin refuses to produce a verdict", stopped)
    check("and writes no card to be mistaken for a result",
          not (d2 / "tasting-card.md").exists())

    print()
    if FAILURES:
        print(f"FAILED ({len(FAILURES)}): " + ", ".join(FAILURES))
        return 1
    print("all resume checks pass")
    return 0


if __name__ == "__main__":
    sys.exit(run())

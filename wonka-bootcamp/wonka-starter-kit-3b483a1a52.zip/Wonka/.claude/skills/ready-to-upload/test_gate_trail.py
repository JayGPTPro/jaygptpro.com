#!/usr/bin/env python3
"""The gate-trail reconciler.

Written after the 26.8.2026 dry run shipped a 14-file A+ and a variation that
had never been inspected, under a pack that said nothing about it. The rule
was already in the room; only the counting was missing.

Run: python3 test_gate_trail.py
"""
import sys
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

FAILURES = []


def check(name, cond, detail=""):
    print(("  PASS  " if cond else "  FAIL  ") + name + ("  " + str(detail) if not cond and detail else ""))
    if not cond:
        FAILURES.append(name)


def build(tmp, cards):
    prod = Path(tmp)
    for cls, n in (("main", 1), ("gallery", 6), ("aplus", 14), ("variations", 2)):
        d = prod / "final" / cls
        d.mkdir(parents=True)
        for i in range(n):
            (d / f"f{i}.png").write_bytes(b"x")
    sc = prod / "scorecards"
    sc.mkdir()
    for name, head in cards:
        (sc / name).write_text(head)
    return prod


def run():
    import gate_trail

    # the dry run's actual shape: one listing scorecard, nothing else
    prod = build(tempfile.mkdtemp(), [("inspect-2026-08-26-listing.md", "# Inspection . listing scope\n")])
    ship, lines, ungated = gate_trail.report(prod)
    check("a listing scorecard gates main and gallery",
          "main" not in ungated and "gallery" not in ungated, ungated)
    check("and does NOT quietly gate the A+", "aplus" in ungated, ungated)
    check("nor the variations", "variations" in ungated, ungated)

    # the same pack once the missing rounds are run
    prod2 = build(tempfile.mkdtemp(), [
        ("inspect-2026-08-26-listing.md", "# Inspection . listing scope\n"),
        ("inspect-2026-08-26-aplus.md", "# Inspection . A+ scope\n"),
        ("inspect-2026-08-26-variations.md", "# Inspection . variations scope\n"),
    ])
    _, _, ungated2 = gate_trail.report(prod2)
    check("every class gated once its scorecard exists", ungated2 == [], ungated2)

    # a card that MENTIONS another class in its body must not gate that class
    prod2b = build(tempfile.mkdtemp(), [
        ("inspect-2026-08-26-listing.md", "# Inspection . listing scope\n"),
        ("inspect-2026-08-26-variations.md",
         "# Inspection . variations scope\n\nBuilt from: final/main/main-01.png, and the A+ card\n"
         "for aplus context. Compare against the gallery and the whole package.\n"),
    ])
    _, _, ungated2b = gate_trail.report(prod2b)
    check("a body mention does not gate a class the card never inspected",
          "aplus" in ungated2b, ungated2b)

    # a package-scope scorecard covers everything, which /inspect allows
    prod3 = build(tempfile.mkdtemp(), [("inspect-2026-08-26-package.md", "# Inspection . whole package\n")])
    _, _, ungated3 = gate_trail.report(prod3)
    check("a whole-package scorecard gates every class", ungated3 == [], ungated3)

    # the built A+ page views are reference copies, never counted as assets
    prod4 = build(tempfile.mkdtemp(), [("inspect-2026-08-26-package.md", "# package\n")])
    for n in ("aplus-page-desktop.jpg", "aplus-order-mobile.jpg"):
        (prod4 / "final" / "aplus" / n).write_bytes(b"x")
    ship4, _, _ = gate_trail.report(prod4)
    check("the stitched page views do not inflate the A+ count",
          len(ship4["aplus"]) == 14, len(ship4["aplus"]))

    # challengers live under main/ and DO ship, so they must be counted
    prod5 = build(tempfile.mkdtemp(), [("inspect-2026-08-26-listing.md", "# listing\n")])
    ch = prod5 / "final" / "main" / "challengers"
    ch.mkdir()
    for i in range(4):
        (ch / f"rank{i + 2}.png").write_bytes(b"x")
    ship5, _, _ = gate_trail.report(prod5)
    check("challengers are counted as shipped files", len(ship5["main"]) == 5, len(ship5["main"]))

    print()
    if FAILURES:
        print(f"FAILED ({len(FAILURES)}): " + ", ".join(FAILURES))
        return 1
    print("GATE TRAIL: all green")
    return 0


if __name__ == "__main__":
    sys.exit(run())

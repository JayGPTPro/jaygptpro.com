#!/usr/bin/env python3
"""The A+ page stitcher, offline.

The page view is the only surface a human can judge an A+ on, so the two
things it must never get wrong are ORDER and HEIGHT. Order, because the
modules are read top to bottom and m10 sorts before m2 as a string. Height,
because Genrupt cuts one continuous design into modules: a single inserted
pixel between them splits a headline in half and makes correct work look
broken, which is exactly what the first version of the order sheet did.

Run: python3 test_aplus_page.py
"""
import sys
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

FAILURES = []


def check(name, cond, detail=""):
    print(("  PASS  " if cond else "  FAIL  ") + name + ("  " + str(detail) if not cond and detail else ""))
    if not cond:
        FAILURES.append(name)


def run():
    from PIL import Image
    import aplus_page

    tmp = Path(tempfile.mkdtemp())

    # 11 modules, so the string sort trap (m10, m11 before m2) is live, each a
    # flat unique shade so the stacking order is readable straight off the page
    shades = {}
    for n in range(1, 12):
        shade = (n * 20, 40, 200 - n * 10)
        shades[n] = shade
        Image.new("RGB", (100, 30), shade).save(tmp / f"m{n}-desktop.png")
    Image.new("RGB", (60, 20), (7, 7, 7)).save(tmp / "m1-mobile.png")
    # a re-generated module lands BESIDE the original after an edit round
    Image.new("RGB", (100, 30), (255, 255, 255)).save(tmp / "m4-desktop-v2.png")
    # noise that must be ignored
    Image.new("RGB", (50, 50), (1, 2, 3)).save(tmp / "reference.png")
    (tmp / "aplus-plan.md").write_text("not an image")

    written = aplus_page.build(tmp)
    names = {p.name for p, _, _ in written}
    check("both modes produce a page and an order sheet",
          names == {"aplus-page-desktop.jpg", "aplus-order-desktop.jpg",
                    "aplus-page-mobile.jpg", "aplus-order-mobile.jpg"}, sorted(names))

    files = aplus_page.modules(tmp, "desktop")
    check("11 modules, one per number, not 12", len(files) == 11, [f.name for f in files])
    check("numeric order, so m10 does not sort between m1 and m2",
          [f.stem.split("-")[0] for f in files] == [f"m{n}" for n in range(1, 12)],
          [f.name for f in files])
    check("the re-generated module replaces the original it superseded",
          files[3].name == "m4-desktop-v2.png", files[3].name)
    check("non-module files are ignored",
          not any("reference" in f.name for f in files))

    page = Image.open(tmp / "aplus-page-desktop.jpg")
    check("the page is exactly as tall as its modules, no inserted air",
          page.height == 11 * 30, page.height)
    check("and as wide as the widest module", page.width == 100, page.width)

    # read the middle of each band back: the page must be in page order
    got = [page.getpixel((50, n * 30 + 15))[2] for n in range(11)]
    want = [shades[n][2] for n in range(1, 12)]
    want[3] = 255  # the v2 module is white
    check("the bands come back in page order",
          all(abs(a - b) < 12 for a, b in zip(got, want)), f"got {got} want {want}")

    order = Image.open(tmp / "aplus-order-desktop.jpg")
    check("the order sheet is the SAME height as the page (badges overlay, never insert)",
          order.height == page.height, f"{order.height} vs {page.height}")

    # the badge must sit ON the module, so a pixel far from it is untouched
    check("the badge does not repaint the module it labels",
          abs(order.getpixel((90, 25))[2] - page.getpixel((90, 25))[2]) < 12,
          (order.getpixel((90, 25)), page.getpixel((90, 25))))

    mob = Image.open(tmp / "aplus-page-mobile.jpg")
    check("mobile stacks only mobile files", (mob.width, mob.height) == (60, 20), mob.size)

    empty = Path(tempfile.mkdtemp())
    check("a folder with no modules writes nothing rather than an empty page",
          aplus_page.build(empty) == [])

    print()
    if FAILURES:
        print(f"FAILED ({len(FAILURES)}): " + ", ".join(FAILURES))
        return 1
    print("A+ PAGE: all green")
    return 0


if __name__ == "__main__":
    sys.exit(run())

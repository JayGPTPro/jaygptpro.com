#!/usr/bin/env python3
"""The Face Clinic's engine: replace AI-looking people with real-looking ones,
without letting the model touch anything else.

Why this exists as code rather than as one API call. The obvious approach,
one whole-frame images.edit pass, was measured failing on 26.8.2026: the
model does not EDIT a frame, it re-renders it. On one A+ module it fixed the
people beautifully and added a fifth tier to a four-tier product; on another
it moved the subject's face and aged her a decade. A repair that can break
the product is not a repair.

So the contract here is different:
  1. The FULL frame still goes to the model (context: lighting, palette,
     what the scene is), with a prompt that asks for new real faces.
  2. The result is resized back onto the original's grid.
  3. Only the PEOPLE BOXES are taken from it, through a feathered mask.
     Every pixel outside those boxes is the original file, by construction.
     Headlines, product, layout cannot drift because they are never replaced.

The boxes come from the agent LOOKING at the image, not from a detector: the
kit has no face-detection dependency, and the operator drawing two rectangles
is more reliable than a model guessing. Draw them TIGHT: the head and its
hair, nothing more. Everything inside a box is surrendered to the re-render,
and the first run proved what a generous box costs: one that reached into the
layout composited back a ghost microphone and a floating letter, because the
re-render had moved those things and the box carried the moved copies home.
Never let a box touch on-image text or the product. The feather plus the
ring-based tone match below handle the seam; margin does not need to.

Usage:
    python3 face_fix.py <image> --boxes "x1,y1,x2,y2;x1,y1,x2,y2" [--quality low]
                                [--out <path>] [--prompt-file <txt>]

Writes <name>-faces-fixed.png beside the source (or to --out). Never touches
the source. Cost: one images.edit call, quality low by default, cents.
"""
import base64
import os
import sys
from pathlib import Path

try:
    from PIL import Image, ImageDraw, ImageFilter
except ImportError:
    sys.exit("this needs Pillow: python3 -m pip install pillow")

# Replacement, not restoration. Asking the model to "make the same face
# realistic" keeps the doll geometry and adds texture ON it, which reads as a
# skin disease at low quality (measured). Asking for a NEW person of the same
# casting in the same pose lets it draw a face it actually knows how to draw.
PROMPT = (
    "This is a product marketing photo. Keep the composition, the product, all on-image text, "
    "the clothing, the poses, the framing and the lighting direction exactly as they are. "
    "Replace each person's face with a DIFFERENT real human face: same gender, same approximate "
    "age, same hairstyle and hair color, a natural candid version of the same expression. "
    "Every person must stay in EXACTLY the same position, size and crop as in the original "
    "image; do not move, rescale or duplicate anyone. "
    "The new faces must look like real photographed people, not AI renders: natural skin with "
    "faint pores and small imperfections, slight facial asymmetry, normal teeth that are not "
    "uniform veneers, realistic eyes with catchlights, individual hair strands. "
    "No beauty-filter glow, no airbrushed skin, no orange tan, no added makeup. Neutral, "
    "believable skin tones with natural variation between regions of the face. "
    "The result should read as a candid lifestyle photograph shot on a professional camera."
)

FEATHER = 40   # px of Gaussian falloff on the mask edge; hides the seam


def _tone_match(orig, edit, box, pad=60):
    """Align the edited box's tone to the original, spatially.

    Version 1 applied ONE per-channel offset per box, computed on the ring
    around it. Measured result: the box still printed as a faint bright
    rectangle, because the render's exposure shift is not constant across the
    box, so a single number under-corrects one edge and over-corrects the
    other. This version builds an offset MAP instead: wherever the two images
    still agree (background the render left alone, within 30 levels), the
    difference is trusted; where they disagree (the new face), it is not; the
    trusted differences are blurred into a smooth field and added. The
    correction therefore follows the background's own gradient and fades to
    the interpolated value under the face."""
    import numpy as np
    from PIL import ImageFilter
    w, h = orig.size
    x1, y1 = max(0, box[0] - pad), max(0, box[1] - pad)
    x2, y2 = min(w, box[2] + pad), min(h, box[3] + pad)
    o = np.asarray(orig.crop((x1, y1, x2, y2)), dtype=np.float64)
    e = np.asarray(edit.crop((x1, y1, x2, y2)), dtype=np.float64)
    d = o - e
    agree = (np.abs(d).max(axis=2) < 30).astype(np.float64)
    if agree.sum() < 500:
        return edit          # nothing trustworthy to anchor on; leave it be
    blur = lambda a, r: np.asarray(
        Image.fromarray(np.clip(a + 128, 0, 255).astype("uint8")).filter(
            ImageFilter.GaussianBlur(r)), dtype=np.float64) - 128
    field = np.stack([
        blur(d[..., c] * agree, 40) / np.maximum(blur(agree * 255, 40) / 255, 1e-3)
        for c in range(3)], axis=2)
    # The field repairs EXPOSURE seams; it must never repaint a face. Uncapped,
    # a green foliage ring bled a visible green tint onto a cheek (measured on
    # the roast-together frame). +-18 is plenty for a seam and too little to
    # recolor skin.
    field = np.clip(field, -18, 18)
    fixed = np.clip(e + field, 0, 255).astype("uint8")
    out = edit.copy()
    out.paste(Image.fromarray(fixed), (x1, y1))
    return out


def parse_boxes(spec: str):
    out = []
    for part in spec.split(";"):
        part = part.strip()
        if not part:
            continue
        nums = [int(v) for v in part.replace(" ", "").split(",")]
        if len(nums) != 4 or nums[0] >= nums[2] or nums[1] >= nums[3]:
            sys.exit(f"bad box '{part}': need x1,y1,x2,y2 with x1<x2 and y1<y2")
        out.append(tuple(nums))
    if not out:
        sys.exit("no boxes given. The clinic edits people; with no people boxes there is no edit.")
    return out


# size is ALWAYS "auto". Forcing a fixed size looked harmless and was not:
# a 1.86-ratio banner pushed through 1536x1024 (ratio 1.5) re-composed at the
# wrong aspect, and squashing it back moved every head out of its box, so the
# composite printed bright off-register rectangles. "auto" renders at the
# source's own aspect (measured: a 1464x600 input came back 1958x803, ratio
# preserved), which keeps the geometry aligned with the boxes.


def run(src: Path, boxes, quality="low", out: Path | None = None, prompt: str = PROMPT):
    from openai import OpenAI
    client = OpenAI()
    im = Image.open(src).convert("RGB")
    w, h = im.size
    for (x1, y1, x2, y2) in boxes:
        if x2 > w or y2 > h:
            sys.exit(f"box ({x1},{y1},{x2},{y2}) falls outside the {w}x{h} image")

    r = client.images.edit(model="gpt-image-2", image=[open(src, "rb")],
                           prompt=prompt, size="auto", quality=quality, n=1)
    edited = Image.open(__import__("io").BytesIO(base64.b64decode(r.data[0].b64_json)))
    edited = edited.convert("RGB").resize((w, h), Image.LANCZOS)
    for b in boxes:
        edited = _tone_match(im, edited, b)

    # the mask IS the contract: white = the edit may land, black = original pixels
    mask = Image.new("L", (w, h), 0)
    d = ImageDraw.Draw(mask)
    for b in boxes:
        d.rounded_rectangle(b, radius=min(30, (b[2] - b[0]) // 4), fill=255)
    mask = mask.filter(ImageFilter.GaussianBlur(FEATHER / 2))

    result = Image.composite(edited, im, mask)
    dst = out or src.with_name(src.stem + "-faces-fixed.png")
    n = 2
    while dst.exists():
        dst = src.with_name(f"{src.stem}-faces-fixed-v{n}.png")
        n += 1
    result.save(dst)
    return dst


def main():
    args = sys.argv[1:]
    if not args or "--boxes" not in args:
        sys.exit(__doc__)
    src = Path(args[0])
    if not src.is_file():
        sys.exit(f"no such image: {src}")
    boxes = parse_boxes(args[args.index("--boxes") + 1])
    quality = args[args.index("--quality") + 1] if "--quality" in args else "low"
    out = Path(args[args.index("--out") + 1]) if "--out" in args else None
    prompt = PROMPT
    if "--prompt-file" in args:
        prompt = Path(args[args.index("--prompt-file") + 1]).read_text()
    if not os.environ.get("OPENAI_API_KEY"):
        sys.exit("OPENAI_API_KEY is not set. The clinic runs on Machine 2; add the key to the .env.")
    dst = run(src, boxes, quality, out, prompt)
    print(f"wrote {dst}")


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
"""The Face Clinic engine, offline. The API call is stubbed; everything our
side owns is real: box parsing, the composite contract (outside pixels are the
original, byte for byte), the tone-match field and its cap.

Each check encodes a failure measured on 26.8.2026 before it was fixed.

Run: python3 test_face_fix.py
"""
import sys
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

FAILURES = []


def check(name, cond, detail=""):
    cond = bool(cond)
    detail = str(detail)          # a numpy array as detail must not crash the harness
    print(("  PASS  " if cond else "  FAIL  ") + name + ("  " + detail if not cond and detail else ""))
    if not cond:
        FAILURES.append(name)


def run():
    import numpy as np
    from PIL import Image
    import face_fix

    # -------- box parsing refuses nonsense before any spend
    ok = face_fix.parse_boxes("10,10,50,60; 70,10,120,80")
    check("boxes parse", ok == [(10, 10, 50, 60), (70, 10, 120, 80)], ok)
    for bad in ("50,60,10,10", "1,2,3", ""):
        try:
            face_fix.parse_boxes(bad)
            check(f"bad box '{bad}' refused", False)
        except SystemExit:
            check(f"bad box '{bad}' refused", True)

    # -------- the composite contract, with the API stubbed out
    tmp = Path(tempfile.mkdtemp())
    rng = np.random.default_rng(5)
    base = rng.integers(60, 200, (300, 400, 3)).astype("uint8")
    src = tmp / "scene.png"
    Image.fromarray(base).save(src)

    # the "render": globally +25 brighter (the exposure shift that printed
    # rectangles), a new face painted in the box, and a GHOST far outside it
    render = np.clip(base.astype(int) + 25, 0, 255).astype("uint8")
    render[80:180, 60:160] = (200, 150, 120)        # the new face, inside the box
    render[40:80, 300:360] = (10, 10, 10)           # ghost the model invented elsewhere

    class FakeData:
        def __init__(self, png):
            import base64 as b64
            self.b64_json = b64.b64encode(png).decode()

    class FakeClient:
        class images:
            @staticmethod
            def edit(**kw):
                import io
                buf = io.BytesIO()
                Image.fromarray(render).save(buf, format="PNG")
                return type("R", (), {"data": [FakeData(buf.getvalue())]})

    import openai
    real = openai.OpenAI
    openai.OpenAI = lambda *a, **k: FakeClient
    try:
        dst = face_fix.run(src, [(60, 80, 160, 180)], quality="low")
    finally:
        openai.OpenAI = real

    out = np.asarray(Image.open(dst).convert("RGB")).astype(int)
    check("output lands beside the original", dst.name == "scene-faces-fixed.png", dst.name)

    # far outside the box: byte-identical to the source, so the ghost died
    check("the model's ghost OUTSIDE the box never reaches the result",
          np.abs(out[40:80, 300:360] - base[40:80, 300:360].astype(int)).max() == 0)

    # inside the box: the new face arrived (near its painted color, tone-matched)
    face = out[110:150, 90:130].mean(axis=(0, 1))
    check("the new face DID arrive inside the box",
          abs(face[0] - 200) < 30 and abs(face[2] - 120) < 30, face.round())

    # -------- the tone field is capped, so a ring can shade a seam but not recolor a face
    # The shift must sit INSIDE the trust window (under 30, over the 18 cap):
    # a +60 shift fails the agree test everywhere and the field never engages,
    # which made the first version of this check pass on uncapped code.
    o = Image.fromarray(base)
    shifted = np.clip(base.astype(int) + 25, 0, 255).astype("uint8")
    e = Image.fromarray(shifted)
    matched = np.asarray(face_fix._tone_match(o, e, (100, 100, 200, 200)), dtype=int)
    inner = np.abs(matched[130:170, 130:170] - shifted[130:170, 130:170].astype(int))
    applied = inner.max()
    check("the field engages on a trusted shift", applied >= 10, applied)
    check("and is capped at 18 per channel", applied <= 19, applied)

    print()
    if FAILURES:
        print(f"FAILED ({len(FAILURES)}): " + ", ".join(FAILURES))
        return 1
    print("FACE CLINIC: all green")
    return 0


if __name__ == "__main__":
    sys.exit(run())

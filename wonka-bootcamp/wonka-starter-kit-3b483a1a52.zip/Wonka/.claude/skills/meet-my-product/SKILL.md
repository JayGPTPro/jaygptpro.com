---
name: meet-my-product
description: Register a product in the Factory and research it fully, in three phases. Phase A (end of Day 1) registers the product, creates its folder, starts the owner interview and hands over the shopping list, then stops. Phase B (Day 2) is the interview, the owner points at what landed in the folders, Wonka reads it, confirms it, asks back, and closes the interview himself. Phase C is the deep analysis across six cross-referenced sources, ending in research/product-report.md, the unified report the Day 3 brief is built from. Also handles corrections and later top-ups. Use when the user wants to start on a product, add a product, research their market, or upgrade research they already have. Triggers: /meet-my-product, "meet my product", "new product", "start with my ASIN", "research my product", "analyze my niche", "analyze my competitors", "update my research", "I got my Brand Registry data", pasting an Amazon URL or ASIN with intent to begin.
---

# The Research Room

| Meta | Value |
|------|-------|
| Room | The Research Room. Your product's own Front Gate |
| Station | RESEARCH (opens the line) |
| Needs | Phase A: ASIN + full Amazon URL + marketplace (or a product description for pre-launch), brand, exact niche phrase, and the owner intel answers. Phase B: whatever the owner has put into `1-inputs/` and `2-reference/` (reviews, competitors, notes, demographics, product photos, brand files), plus their answers to Wonka's follow-up questions |
| Saves to | factory/Products/[product-slug]/ (created from TEMPLATE) + status.md + research/ (insights.md, reviews.md, persona.md, competitors.md, selling-points.md, and product-report.md on top). Owner inputs live in `1-inputs/`, product photos in `2-reference/photos/`, brand files in `2-reference/brand/` |
| Typical cost | Free, with one exception: source 5 of the analysis is the Genrupt market analysis, which spends included machine credits and is ALWAYS cost-consented before it runs. Everything else is registration, reading and analysis only |

## What this room does

Every product enters the Factory through this gate, and no product leaves this floor a stranger. The room runs in three phases across two days:

- **Phase A, the last stop of Day 1**: register the product, create its folder, start the interview with the owner-intel questions, hand over the shopping list that points at the folders, and STOP.
- **Phase B, Day 2**: the interview. The owner points at what they put in the folders and says what it is. Wonka reads it, confirms what he received, then asks back. The interview ends when Wonka himself declares, explicitly, that he has enough.
- **Phase C, same day, right after the interview closes**: the deep analysis. Six sources, cross-referenced, ending in the five research files plus `research/product-report.md`, the one unified report every later room reads and the Day 3 brief is built from.

One rule governs the whole floor: **an honest gap beats an invented fact, every time.** A missing input gets named, recorded and costed out loud. It never gets filled with a plausible sentence.

The same room runs again on Day 10 for the second-product speed run, with every gate still in place. The second run is faster because `factory/Improvement Log.md` is no longer empty, and for no other reason. A speed run never skips a step.

## Before you start

- If `factory/Products/TEMPLATE/` is missing, create it first with the full standard structure (see Phase A, step 4), then continue.
- **If a folder for this product already exists in `factory/Products/`, do NOT overwrite it.** Read its `status.md`, say which station it is at, and offer the lawful paths:
  1. **Continue where the room stopped.** RESEARCH is still `in progress` because Phase A registered the product and stopped, which is exactly the designed Day 1 to Day 2 handoff. Pick up at Phase B (the interview), or at Phase C if the interview was already closed. This is the normal Day 2 entrance, not an edge case.
  2. **Status only.** Report where the product stands and stop.
  3. **Top up the research.** New inputs have arrived (a Brand Registry export, more critical reviews, owner intel that did not exist before, a replacement competitor). Run Phase D, step 25.
  A genuinely different product gets its own slug and its own folder.
- Phase C is BLOCKED until Wonka has explicitly closed the interview in Phase B. Never improvise a market picture from memory, never write a section you cannot source, and never analyze a competitor whose images you have not actually looked at.

## Process

### PHASE A . REGISTRATION (the last stop of Day 1)

1. **Collect the product identity.** Ask for all of it in ONE message:
   - The ASIN and the full Amazon URL. If the product is not live yet, accept a product description instead (what it is, size, key features) and record `live: no`.
   - **The marketplace** (amazon.com, amazon.co.uk, amazon.de, and so on). It decides which reviews, which competitors and which prices count, whether the page is even visible from here, and what language the review mining runs in. A missing marketplace is the quiet cause of a research pack built on the wrong country's shoppers.
   - The brand name.
   - The niche, in the seller's own words (for example "chocolate fountain", "garlic press", "dog paw balm"). Confirm it back word for word: this exact phrase is what every competitor must genuinely belong to, so it must be right.

2. **Create the product slug.** Lowercase, hyphens, short: "Nostalgia 4 Tier Electric Chocolate Fondue Fountain Machine" becomes `chocolate-fondue-fountain`. Confirm the slug with the user before creating folders. That name follows the product through every room.

3. **Verify the ASIN resolves to the RIGHT product, not just the right format.** Format check first (10 characters, usually starting with B0), then the read-back: fetch the listing and read its TITLE back to the user. A transposed character passes every format check on earth and registers a stranger's product into the factory; a human reading a title is the only thing that catches it. Three outcomes, and only these three:
   - **Title fetched and confirmed by the user** . proceed, record `title_confirmed: yes (fetched)`.
   - **The page cannot be opened** (browsing unavailable, a geo-blocked marketplace, a login wall) . say so plainly and ask the user to paste the exact listing title from their own screen. Record `title_confirmed: yes (user paste)`.
   - **The title does not match what the user expected** . stop. Do not create a folder. Ask for the correct ASIN or URL.
   Never create a folder on an unread title.

4. **Create the product folder** by copying `factory/Products/TEMPLATE/` to `factory/Products/[product-slug]/`, then LIST the folder back and confirm the full structure exists on disk (create anything missing):
   - `1-inputs/` (the owner drops reviews, competitors, notes, demographics here)
   - `2-reference/photos/` (the owner's product photos)
   - `2-reference/brand/` (logo and brand files; `/brand-kit` reads them)
   - `research/` (Wonka writes: the five research files + product-report.md)
   - `brief/` (the Day 3 brief)
   - `images/` (raw generation output, write-once)
   - `edits/` (each edit round becomes a complete `v1/`, `v2/`... snapshot later)
   - `final/` (the approved package)
   - `incumbent/` (the owner downloads the LIVE Amazon main + gallery here at the end of Day 7; `/inspect` and `/tasting-room` read it)
   - `aplus/`, `variations/`, `scorecards/`, `tests/`
   The Reference Room later writes `2-reference/reference-sheet.md` next to the photos. There is no flat `reference/` folder in this factory and no Desktop inputs folder; everything lives inside the product folder.

5. **Write `status.md`** in the product folder using the Output format below (it mirrors `factory/Products/TEMPLATE/status.md`). All stations start as `pending` except RESEARCH, which is set to `in progress`.

6. **Start the interview with the owner intel.** Three questions, in one message:
   - What do you already KNOW works for this product? (past winners, images that converted, angles customers respond to)
   - What MUST appear in the images? (a certification really printed on the label, a signature feature, a claim you are allowed to make)
   - What must we AVOID? (claims legal told you to drop, angles that flopped, comparisons you do not want)
   Record the answers **verbatim** in the `Owner intel` section of `status.md`. This is the one input no research on earth can replace, and it travels with the product through every room.
   - **Truth gate on "must include":** only what is genuinely printed on the product or documented in the seller's account. An invented certification here becomes an invented badge in an image later, which is a suppression risk rather than a style problem. If the user is unsure a claim is real, mark it `unverified` and it does not enter the selling-points checklist until they confirm.
   - **"I have none" is a first-class answer.** Record it verbatim as `none given` with the user's reason (a new product with no history, a public listing the user does not own), name in one line what that costs ("the checklist will lean entirely on public evidence"), and PROCEED. Owner intel never blocks the run, and it is never invented to fill the slot. When real intel appears later, Phase D tops it up.

7. **Hand over the shopping list in ONE message, pointing at the folders.** Everything comes from what the seller already has. No new tools, no new signups. Each item names its destination folder, because on Day 2 the owner will point at what they dropped there:
   - **Reviews** into `1-inputs/reviews.txt` (or any file in `1-inputs/`): the top ~10 positive and ~10 critical reviews for this product. Give the warning every time, because it decides the quality of the whole day: the public listing page shows only a handful of reviews (usually about 8, skewed positive) and buries the critical ones. Copy reviews while LOGGED IN on the marketplace (sort by Most recent, then filter to Critical), or take the lot from Seller Central for your own product. Critical reviews are the gold. Two lawful substitutes, each recorded as what it is:
     - New listing with almost no reviews of its own: use the competitors' reviews for pain mining, recorded as `review_source: competitor reviews`.
     - Pre-launch product: same, competitor reviews only.
     - **No manual copy at all is also lawful**: the Day 2 market analysis runs a review deep dive on Genrupt (hundreds of reviews across the top products, mined into pain points, themes and use cases), and that mining can stand in for `reviews.txt`, recorded as `review_source: genrupt deep dive ([N] reviews)`. The file is still worth having when it is cheap to get (own product via Seller Central); it is never worth an hour of hand-copying.
   - **Competitors** into `1-inputs/competitors/`: 3 to 5 competitor ASINs or URLs (a text file is fine), OR screenshots of their full image galleries. How to pick them: search the niche phrase and expect most of the page to be off-niche noise (accessories, different formats, adjacent products). The test is one question. *Would a shopper typing my exact niche phrase see this listing and consider it instead of mine?* Choose the sellers stealing the sales, never the ones flattering to compare against.
   - **Anything else the owner knows** into `1-inputs/notes.txt`: past test results, angles that worked in ads, things customers say in messages.
   - **Real product photos** into `2-reference/photos/`: all angles (front, back, both sides, top), one hand-for-scale shot, and label or detail close-ups. **Drop the files into the folder; do not paste them into the chat.** A pasted photo is visible to Wonka but never lands on disk, and the Reference Room reads the disk. The Reference Room reads them, and they are collected now while the camera is out. If the seller genuinely cannot hold the product (a listing they do not own, stock not arrived), the fallback is the listing gallery plus customer review images, recorded as `reference_photos_source: amazon_scraped` and said out loud as **the fallback, not the standard**: it makes the machines guess at size and back panels. Anyone who owns the product shoots it properly.
   - **Logo and brand files** into `2-reference/brand/`: the logo file, any brand colors or fonts, an existing brand guide if one exists. `/brand-kit` builds the branding preset and the one style image from these.
   - **OPTIONAL: Brand Registry ASIN-level demographics export** (real buyer age and gender) into `1-inputs/`.
   - **OPTIONAL: Search Query Performance export, return reasons, or any keyword and search-term data** the seller already has, into `1-inputs/`. These sharpen the funnel diagnosis from a guess into a reading.

8. **STOP. Day 1 ends here.** Say it plainly: "The folder is open, the list is in your hands. Fill the basket, and tomorrow we talk. Day 2 is an interview, not a lecture: you point at what you brought, I read it, and then I ask my questions." Do not begin reading inputs, do not begin analysis, do not peek ahead.

### PHASE B . THE INTERVIEW (Day 2)

9. **The owner points, Wonka reads.** The owner says what they put where ("reviews are in, I pasted 22 of them", "there are four competitor screenshots", "the logo is in the brand folder"). For each pointed-at item: READ the actual file or folder, then confirm back what was received in concrete terms ("22 reviews, 9 of them critical, received", "4 gallery screenshots covering C1 to C4, received", "logo as SVG plus a hex list, received"). Never confirm an item you have not opened.

   - **Text pasted into the chat gets filed** into its right place (`1-inputs/` or `2-reference/`) as it lands.
   - **A PHOTO pasted into the chat does NOT.** Wonka can look at it; it never reaches the disk, and the Reference Room on Day 4 reads the disk. So never record a pasted image as received: ask the owner to drop the actual files into `2-reference/photos/` (Finder or File Explorer), then LIST the folder and confirm the filenames you actually see. This is the quiet one. It looks like it worked, and the cost surfaces two days later as an empty photos folder.
   - **Check the content, not just the count.** After reading reviews, notes or any keyword export, sanity-check that it describes THIS product's niche phrase. If the reviews talk about a garlic press and the product is a fondue fountain, say so and STOP: the owner copied from the wrong tab, and every file downstream (persona, selling points, brief, the panel's demographics) would inherit it silently. A wrong ASIN is caught by the title read-back in Phase A; this is the same guard for everything the owner drops by hand.

10. **Then Wonka asks back.** This is what makes it an interview rather than a checklist. After reading, ask the follow-up questions, always including these three, plus anything the reading itself raised:
    - **What should a buyer FEEL when they see this product?** (the emotional target the images must hit)
    - **What can you NOT claim?** (legal lines, unverified certifications, promises the product cannot keep)
    - **What do buyers ask you REPEATEDLY?** (the questions that reach the seller again and again are the questions the gallery is failing to answer)
    Targeted follow-ups from the reading belong here too: "review 7 complains about the drip tray, is that fixed in the current version?", "competitor C3 shows a warranty badge, do you have one?". Record every answer verbatim in `1-inputs/notes.txt` (append, dated) and the load-bearing ones in `status.md` under Owner intel.

11. **"I don't have that" is a first-class answer.** For any missing item, record the owner's words verbatim, name in one line what it costs the analysis, and PROCEED. A required item (reviews, competitors, product photos) that stays missing is released only by that **named waiver in plain words** ("I have no critical reviews, proceed without them"), recorded verbatim in `## Research gaps` in `status.md` plus the header of the file it weakens. The two OPTIONAL groups never block; absent, they are recorded as `not provided`. Never nag an item the owner has already waived.

12. **Wonka closes the interview, explicitly.** The interview continues, read and ask, read and ask, until WONKA declares he has enough. The declaration is his, it is explicit, and it is said in so many words: "I have what I need. The interview is closed, the analysis begins." Silence is not a close, the owner saying "continue" is not a close, and a generic "everything is in" from the owner is an invitation to verify, not a trigger. Before declaring, read the basket back as a checklist, one line per item: `received` / `waived: [the user's words]` / `not provided (optional)`, and clear delivered items from `Blocked on` in `status.md`. If required items are still missing and unwaived, say exactly what is missing and hold the station BLOCKED instead of closing.

### PHASE C . DEEP ANALYSIS (six sources, cross-referenced)

13. **Name the six sources out loud before analyzing.** Every conclusion in this room traces to at least one of them, and the strongest conclusions to several:
    1. **What the owner taught** (the interview + owner intel).
    2. **The owner's OWN listing, torn down** (title, bullets, current gallery, current A+).
    3. **The reviews, mined.**
    4. **The competitors, gallery by gallery.**
    5. **The Genrupt market analysis** (`run_market_analysis_and_wait_for_report`), cost-consented.
    6. **`factory/Improvement Log.md`**, the factory's own accumulated lessons. On product one it is empty, and that is said out loud ("the Log is empty, this product will be the one that fills it"), never papered over.

14. **Confirm competitor relevance and visibility. HARD RULE.** Before analyzing anything, check every competitor twice:
    - **Same niche?** It must genuinely sell in the exact niche phrase confirmed in Phase A. A neighbouring niche is not close enough: a chocolate fondue POT cannot serve a "chocolate fountain" product, even though both say fondue. A pot has no tiers, no auger and no cascade, so its table stakes are not our table stakes, and one impostor tilts every conclusion after it. Name the off-niche one, say why, drop it, and ask for a replacement before analyzing.
    - **Actually seen?** Record per competitor how its images were viewed: `seen via: live fetch` / `seen via: screenshots [filenames]` / `NOT SEEN`. A competitor marked NOT SEEN gets no teardown lines at all. Ask for gallery screenshots instead of guessing; browsing is not always available and a remembered gallery is confident fiction.
    - Fewer than 3 confirmed same-niche competitors whose galleries were actually seen = the station stays **BLOCKED**, and say exactly what would unblock it.

15. **Tear down the owner's OWN listing** (source 2), into a `## Our own listing today` section of `research/competitors.md`. The current listing is the incumbent we have to beat, and it gets the same honest eyes a competitor would:
    - **Title and bullets**: what they promise, in whose language (product units or shopper units), what they bury.
    - **Current gallery, image by image**: the job each image does, the ORDER, what survives a thumbnail squint, what is missing.
    - **Current A+**, when one exists and can be seen: what story it tells, one line per module.
    - Close with one line: **the single biggest gap between what this listing promises and what the shopper needs to see.** This teardown feeds the expectation-gap scan directly: a complaint the listing's own images caused is the cheapest fix in the whole factory.
    A pre-launch product has no listing to tear down; write `pre-launch: no live listing` and move on.

16. **Mine the reviews** (source 3) into `research/reviews.md`:
    - **Pain points**: what buyers complain about, ranked by frequency, with the count behind each rank.
    - **Objections**: what makes shoppers hesitate before buying (doubts about size, authenticity, durability, results).
    - **Delight moments**: what surprised buyers positively. Delight is secondary-image gold.
    - **Customer language worth stealing**: exact short phrases customers use, quoted verbatim, that could become on-image copy. Real words beat marketing words.
    - **The expectation gap scan (do not skip).** Read the critical reviews once more with one question: does any top complaint trace back to something the LISTING promised, an image, a number, a hero shot, rather than to the product itself? Cross-reference the own-listing teardown from step 15. Record it under `## The expectation gap` with the verbatim quote, what the listing states, what the buyer expected, and the one-line creative job it creates. If the sample genuinely shows none, write `No expectation gap found in this sample` rather than manufacturing one.
      **HARD RULE on how it may be used:** a review finding is what buyers REPORT. It never becomes a brand claim, a spec, or on-image copy that reads like one. We close expectation gaps, we never open new ones.
    - **Also flag the quiet gold**: a spec the product already has that answers a live complaint and appears in no image anywhere. It costs nothing and it is usually sitting in the product information table.
    - Record the header honestly: source (`seller's own listing` / `competitor reviews`), the counts, and `reviews_confidence: high` (8 or more critical) / `medium` (4 to 7) / `low` (under 4 critical, or under 10 reviews in total). A thin sample gets said out loud, never smoothed over.

17. **Tear down the competitors** (source 4) into `research/competitors.md`. Actually LOOK at every image (fetch the galleries when browsing is available, or read the screenshots with vision). For each competitor (C1 to C5), open with its `seen via` line, then record:
    - **Main image composition**: product angle, packaging shown, props, background, on-product badges or seals, frame fill.
    - **Secondary image jobs**: image by image, name the job each one does (benefit hero, feature or material proof, how-to, lifestyle, comparison, scale, trust). Note the ORDER: position 2 is their bet on the strongest message.
    - **Callouts and copy**: headlines, word counts, whether the text survives a thumbnail squint.
    - **Trust markers** and **tone** (one line each).
    Then build the cross-competitor matrix (rows = jobs and features, columns = C1 to C5, cells = yes/no/partial) and sort into the three piles:
    - **TABLE STAKES**: shown by most or all. We must show these too. Cross-reference the review demands: a feature most competitors show AND reviews ask about is a table stake by double confirmation, which makes it non-negotiable.
    - **WHITESPACE**: relevant to buyers (per the reviews) but shown by nobody. Each item gets one line on why it matters and which pain point or customer phrase it maps to. Specific only: "nobody answers whether it actually flows, and that is the number one complaint" is whitespace, "better branding" is not.
    - **THEIR BEST FRAME**: exactly ONE, the single strongest image across all galleries, with the competitor, the position, WHY it works, and our concrete match-then-beat move. Look at what the copy is doing, not only at the photography; the strongest frame in a set is often one line of text expressed in the shopper's units instead of the product's.
    Finish with a **"seen but banned"** list: competitor tactics that violate the Golden Standards (fake badges, star ratings baked into images, medical claims, invented percentages, text walls). Prevalence is not permission, and half of it is a suppression risk.

18. **Run the Genrupt market analysis** (source 5). This is included machine usage on the Genrupt subscription the course sets up, NOT a third-party signup, and it is expected in every run. It is also the one step on this floor that spends anything, so it is **cost-consented, every time**:
    - Say what it is and what it costs in one line, with a REAL number from a live `get_credit_balance_and_costs` preview, quoting its `finalCreditsCost` ("Genrupt will run its own market analysis on your ASIN, about [N] credits against your balance of [Y], shall I run it?") and WAIT for a yes. A consent with no figure teaches the owner to approve unpriced spends.
    - On yes: call `run_market_analysis_and_wait_for_report` for the ASIN and marketplace, then read the completed report and fold its findings into the cross-referencing: where Genrupt's read AGREES with the reviews and teardown, mark the point double-confirmed; where it DISAGREES, record the conflict rather than picking a side silently. Note the analysis id in `insights.md`; the Brief Room's planner reuses it on Day 3, so planning never pays for it twice. **On the deep-dive review path** (no manual reviews.txt), run THIS step before the review mining, then mine the deep dive's pain points and themes as the review source, recorded as `review_source: genrupt deep dive ([N] reviews)`.
    - **The report reads over MCP (bug fixed by Genrupt, verified 22 August 2026).** `get_market_analysis_report` now returns the full summary payload: avatars with market percentages, positive and negative themes with counts, pain points, use cases, and pricing segmentation. Read it directly and fold it into the cross-referencing; record `report read: via MCP` in insights.md. The app link remains the richer visual read for the owner. (If the summary ever comes back null again, that is the old regression: report it and fall back to reading it together in the owner's browser.)
    - **If the analysis FAILS after the deep dive, retry ONCE with one parameter changed.** A failed analysis gets caught by Genrupt's dedupe: re-invoking with identical parameters returns the SAME failed analysis rather than starting fresh. Nudge one harmless parameter (for example `maxOrganicResults` from 20 to 18) to break the dedupe key, and say what you changed and why. One retry; a second failure is recorded and the run proceeds on five sources.
    - On no, or if the tool is unavailable or fails twice: record it (`genrupt_analysis: declined` / `unavailable: [error]`) in `## Research gaps` with its one-line cost ("the niche picture rests on five sources instead of six") and PROCEED. Never retry a failed paid call through another paid path.

19. **Read the Improvement Log** (source 6): open `factory/Improvement Log.md` and apply any lesson that touches research (a niche read that was wrong before, a competitor type that fooled a past run, a persona correction that keeps recurring). On product one the Log is empty; say so out loud and move on. Never skip the read because you expect it to be empty.

20. **Derive the niche picture** into `research/insights.md`. This is Wonka's own synthesis, cross-referencing all six sources:
    - **Table stakes**: features most competitors show AND reviews demand. Every line states its confirmation: `double` (two or more independent sources) or `single-source` (name the one). A set that hides a double-confirmed table stake loses by default, and a shopper does not deduct points for it, they silently disqualify you.
    - **Customer language and search words**: mined from the reviews and the listing (plus any keyword data provided and the Genrupt report), especially modifier words (feature, audience, format words like "for parties" or "4 tier"). Modifiers are image copy waiting to happen.
    - **Pricing landscape**: the price bands read off the competitor listings and where this product sits (value, mid, premium). This shapes how premium the images must look. If prices are not visible (a geo-blocked marketplace shows "cannot be shipped to your location" and hides them), ask the user for the prices on their screen, or record the band as `estimated` and say so. Never leave the section silently empty.
    - **Customer demographics**: the Brand Registry export when provided (`source: brand_registry_export`). Otherwise Wonka's honest estimate from the reviews, listing, competitor picture and Genrupt report, with every line labelled `estimated` and upgraded the day real data arrives.
    - **Where the sources disagree**, record the conflict under `## Conflicts between sources` and surface it to the user rather than picking a side. Where the evidence is thin, write `estimated` or `not enough data`. A guess presented as a fact is the one output this room may never produce.

21. **Build the REAL buyer persona** into `research/persona.md`:
    - With the ASIN-level Brand Registry demographics: build from the REAL buyer age and gender, `source: brand_registry_export`.
    - Without: build Wonka's honest estimate from the reviews, the listing, the competitor picture and the Genrupt report. Record `source: estimated` plus one caution line: an estimated persona is a starting point, upgrade it when the seller can export the real data.
    - The persona includes: age band, gender split, what they are buying this FOR (the job to be done, from the reviews), their top fear (from the objections), and their dream outcome (from the delight moments). Anchor the fear and the dream to review lines you can point at. "Adults 25 to 45" is not a persona.
    - **Panel demographics block (required).** The Tasting Room reads this file to build its taster panel, and it needs distributions rather than prose. Write the block exactly as shown in the Output format: `age_dist`, `gender`, `income`, one `notes` line, and the source label. Each set of shares sums to 1.0. Leave it out and the panel silently falls back to a generic shopper, which quietly wastes the whole test.
    - Add the **display-age note** for later casting: people shown in images follow the aspirational skew (from age 50, show about 5 years younger, scaling to about 10 years younger by 70). The persona records the REAL age; the Brief Room applies the skew when it translates this persona into the 1 to 2 structured `customAvatars` that Genrupt casts from (casting is a structured field, never prose in a brief), and the taster panel always uses the real age.

22. **Diagnose the funnel (CTR vs CVR)** into `research/insights.md` under a `## Funnel diagnosis` heading. State what evidence is MISSING before stating the conclusion; a diagnosis that hides its own evidence is how sellers confidently rebuild the wrong asset. Work down this ladder and stop at the first rung that has data:
    1. **Search Query Performance export** (Brand Registry): low click share against impressions = a click problem, and the lever is the MAIN image. Healthy click share with weak purchase share = a close problem, and the lever is the secondary gallery and the A+.
    2. **Public signals only**, marked `estimated`: category rank and best-seller status, the "N bought in the past month" line, the star split, what the review themes blame, and the price position against the set. A product ranking at the top of its category with strong recent velocity is winning clicks, so the leak sits after the click.
    3. **Nothing to reason from**: say so plainly and default to testing the MAIN first.
    Name ONE primary lever. Whatever the diagnosis, the MAIN image still goes to the Tasting Room, because the live image is always the control we have to beat.
    - **Return reasons, when provided**: map each to a creative fix ("smaller than expected" = a scale and dimensions frame, "not as described" = an image that over-promised). Sort out the ones that are NOT creative jobs (arrived cracked is packaging, wrong item shipped is operations) and say so, so nobody briefs an image against a warehouse problem.

23. **Produce the selling-points checklist** into `research/selling-points.md`. List EVERY:
    - Must-have from the derived niche picture (double confirmation first, single-source marked as such).
    - Top differentiator this product actually has (cross-check owner intel and the listing).
    - Material and quality signal (true-to-product colors, real materials, sturdy build, premium finish: whatever signals quality in this niche). This is the most commonly missed category.
    - High-frequency pain point the product genuinely solves.
    - Whitespace opening worth claiming.
    Each item gets an ID (SP1, SP2...), a source (insights / reviews / teardown / own listing / Genrupt analysis / owner intel), and an empty "Mapped to" column that the Brief Room fills on Day 3. Every point must be specific enough to photograph: "high quality" is not a selling point, "the front legs adjust so it sits level" is. The rule this list enforces: every point is later mapped to an asset or consciously skipped IN WRITING. Nothing disappears silently.

24. **Cross-check against owner intel, then run the trace audit and verify the artifacts. Do this before writing the report.**
    - **Owner intel cross-check**: if the seller's "must include" items are not on the checklist, add them. If owner intel contradicts the data, flag the conflict in `selling-points.md` under `## Conflicts flagged` rather than picking a side silently. Unverified claims stay out until confirmed.
    - **Trace audit**: walk the five files and check that every claim traces to one of the six sources: the interview, the own-listing teardown, the reviews, a competitor gallery actually seen, the Genrupt report, the Improvement Log, or a labelled estimate. Anything untraceable gets DELETED, never softened into a vaguer sentence. Zero invented statistics, zero remembered market facts, zero competitor lines from memory.
    - **Artifact verification**: list `research/` on disk and confirm the five files exist and carry their required sections with real content. An empty heading is a missing artifact wearing a hat. If a section is genuinely empty because an input was waived, it says `WAIVED: [the user's words]` plus what it costs, and the waiver is in `status.md`.

25. **Write `research/product-report.md`, The Product Report.** The unified, readable report built ON TOP of the five files, the one document a person actually reads and the one the Day 3 brief is built from. It cites the five files rather than replacing them; every line in it already passed the trace audit. Its sections, in this order:
    - **The Must-Haves** (call them that, with "table stakes" in parentheses once, on first use): what this niche does not forgive missing, double-confirmed first.
    - **The pains, ranked**: the top buyer complaints with the count behind each.
    - **The expectation gap**: the complaint the listing itself caused, or "none found in this sample".
    - **The whitespace**: what nobody shows and buyers care about, each item tied to its pain or phrase.
    - **The persona**: the real buyer in a few sentences, WITH the panel demographics block copied in (the Tasting Room reads distributions, not prose).
    - **The funnel diagnosis**: the one lever, its evidence and its confidence.
    - **Customer language worth stealing**: the verbatim phrases that could become on-image copy.
    Write it to be read: short sections, plain sentences, counts and quotes over adjectives. This is the document Wonka hands the owner and the document the Brief Room opens first.

26. **Present the summary and invite the correction.** 8 to 10 lines drawn from the report: the biggest must-have, the sharpest pain point, the expectation gap if there is one, the persona in one sentence, the whitespace shot, the best frame to beat, the funnel diagnosis with its confidence, and the checklist count. Then two things that make this a conversation rather than a lecture:
    - Point to `research/product-report.md` for the readable whole and the five files for the full detail.
    - Name the two or three lines you are LEAST sure about and ask the user to correct them. They know things the data cannot see, and a wrong assumption is cheapest to kill here.

### PHASE D . CORRECTIONS AND TOP-UPS

27. **Handle a correction properly.** When the user pushes back on anything ("our buyers are repeat gift buyers in their fifties", "that claim is not true of our product"):
    - Revise the affected file in place, and revise `product-report.md` wherever it repeats the corrected line. The report and its source files never disagree.
    - Append to a `## Corrections` section in the source file: the date, what changed, what it replaced, and the source (`owner correction: "[their words]"`).
    - Say what it changes downstream in one line (who the customAvatars cast, which fear the images answer first, how the taster panel is built, which selling point dies).
    - Add a Log line in `status.md`.
    Never argue a correction away, and never lose the record of what the file said before.

28. **Handle a later top-up.** New inputs arrive after the station is done (a Brand Registry export, the critical reviews that were missing, owner intel that did not exist, a replacement competitor). Do NOT re-run the whole room:
    - Collect only the named new items, filed into `1-inputs/` or `2-reference/` where they belong.
    - Re-run only the analysis steps they touch (a demographics export touches steps 20 and 21, new critical reviews touch 16, 20, 22 and 23, a replaced competitor touches 14, 17 and 20), then refresh the affected sections of `product-report.md`.
    - Upgrade the source labels (`estimated` becomes `brand_registry_export`) and clear the matching line from `## Research gaps`.
    - Log it: `[date] Research topped up: [what arrived], [which files changed].`

## Output format

`factory/Products/[product-slug]/status.md` (mirrors `factory/Products/TEMPLATE/status.md`):

```markdown
# [Product Name] . Station Tracker

| Field | Value |
|---|---|
| Product name | [name] |
| ASIN | [ASIN, or "not live yet"] |
| Amazon URL | [URL or n/a] |
| Marketplace | [amazon.com / amazon.co.uk / ...] |
| Brand | [brand name] |
| Brand kit | [factory/Brand/brand-kit.md, or brand-kit-[slug].md when the Factory holds more than one] |
| Niche | [exact niche phrase, word for word] |
| Title confirmed | [yes (fetched) / yes (user paste)] |
| Reference photos source | [seller_photos / amazon_scraped (fallback)] |
| Registered | [YYYY-MM-DD] |

## Stations

| Station | Status | Artifact | Date | Notes |
|---|---|---|---|---|
| RESEARCH | in progress | research/ files + product-report.md | [date] | |
| BRIEF | pending | brief/creative-brief.md | | |
| INVENT | pending | 2-reference/ + images/ + aplus/ + variations/ | | |
| INSPECT | pending | scorecards/ | | |
| PROVE | pending | tests/ | | |

Status values: pending / in progress / blocked / done.
A station is `done` only when its artifact exists on disk. Never before.

INVENT sub-status:
- Main image (/main-image): pending
- Secondary images (/secondary-images): pending
- A+ (/aplus): pending
- Variations (/variations): pending

INVENT is `done` only when all four sub-parts are done, or a sub-part is consciously skipped with a
reason (e.g. "Variations: n/a, single SKU"). "Variations: pending (Day 9)" is a lawful trailing
marker, not a block.

## Owner intel

### Known winners
- [verbatim from the user, or "none given: [their reason]"]

### Must include
- [verbatim from the user, or "none given: [their reason]"]

### Avoid
- [verbatim from the user, or "none given: [their reason]"]

### From the interview
- Buyers should feel: [verbatim]
- Cannot claim: [verbatim]
- Buyers ask repeatedly: [verbatim]

## Blocked on

- Reviews: top ~10 positive + ~10 critical (into 1-inputs/)
- 3 to 5 same-niche competitor ASINs/URLs or full gallery screenshots (into 1-inputs/competitors/)
- Real product photos: all angles + hand-for-scale + label close-ups (into 2-reference/photos/)
- Logo + brand files (into 2-reference/brand/)
- OPTIONAL: Brand Registry ASIN-level demographics export (into 1-inputs/)
- OPTIONAL: Search Query Performance export, return reasons, keyword data (into 1-inputs/)

## Research gaps

- [item waived, in the user's own words] . cost: [what the analysis loses] . upgrade when: [what would close it]

## Log

- [YYYY-MM-DD] Product registered at the Front Gate. Interview started, shopping list handed over.
```

The five research files:

```markdown
# research/insights.md
Derived by Wonka from the six sources: interview + own listing + reviews.md + competitors.md +
Genrupt market analysis [id, or "declined/unavailable"] + Improvement Log, [YYYY-MM-DD]
## Must-haves (table stakes)
- [feature] . confirmation: [double: which two or more sources | single-source: which one]
## Customer language and search words
- [word/phrase] (source: review quote / listing / seller keyword data / Genrupt report) . modifier note: [what it implies for images]
## Pricing landscape
[price bands from the competitor listings; where this product sits: value, mid, premium. Mark `estimated` if prices were not visible]
## Customer demographics
source: brand_registry_export | estimated
[age bands, gender split; if estimated, every line labelled `estimated`, upgrade when real data arrives]
## Funnel diagnosis
Evidence available: [SQP export / public signals only / none]
[CTR leak = MAIN lever | CVR leak = gallery and A+ lever | no data, default MAIN first] . confidence: [measured / estimated]
Reasoning: [rank, velocity, star split, review themes, price position]
Return reasons mapped: [reason -> creative fix] | not creative: [reason -> packaging / operations]
## Conflicts between sources
- [what source A says vs source B, surfaced, not resolved silently]
## Corrections
- [YYYY-MM-DD] [what changed, what it replaced] (source: owner correction: "[their words]")
```

```markdown
# research/reviews.md
Built from: [N positive, M critical], review_source: [seller's own listing | competitor reviews | genrupt deep dive (N reviews)],
reviews_confidence: [high | medium | low], [YYYY-MM-DD]
## Pain points (ranked)
- [pain] . [count] mentions
## Objections
## Delight moments
## Customer language worth using
- "[verbatim phrase]" (context)
## The expectation gap
[the complaint the listing's own images or numbers caused: verbatim quote, what the listing states,
what the buyer expected, the creative job it creates. Or: "No expectation gap found in this sample"]
RULE: review finding, never restated as a brand claim or on-image spec.
## Quiet gold
[a spec the product already has that answers a live complaint and appears in no image]
```

```markdown
# research/persona.md
source: brand_registry_export | estimated
## The buyer
[age band, gender split, buying this FOR (job to be done), top fear (from objections),
dream outcome (from delight moments). Fear and dream each anchored to a review line]
## Panel demographics (read by the Tasting Room)
age_dist: {"35-44": 0.5, "45-54": 0.3, "55-64": 0.2}
gender: {"female": 0.8, "male": 0.2}
income: {"middle income": 1.0}
notes: [one line on who this is]
(each set of shares sums to 1.0; label estimated where estimated)
## Display-age note for casting
Real age band: [X]. Aspirational display age for images: [computed per the skew].
The Brief Room translates this persona into 1 to 2 customAvatars (structured casting, never prose).
The panel and the screener always use the REAL age.
## Corrections
- [YYYY-MM-DD] [what changed] (source: owner correction: "[their words]")
```

```markdown
# research/competitors.md
Built from: [C1..C5 ASINs/URLs or screenshot filenames], analyzed [YYYY-MM-DD]
## Our own listing today
[title + bullets read, gallery image by image with jobs and order, current A+ one line per module,
the single biggest promise-vs-need gap. Or: "pre-launch: no live listing"]
## Roster
| # | Competitor | Same niche? | Seen via |
|---|---|---|---|
| C1 | [name/ASIN] | yes | live fetch / screenshots: [files] |
(dropped competitors listed with the reason; NOT SEEN gets no teardown)
## Per-competitor teardown
## Cross-competitor matrix
## MUST-HAVES (table stakes we must show too)
## WHITESPACE (nobody shows, our shot)
## THEIR BEST FRAME (exactly one: competitor, position, why it works, our match-then-beat move)
## Seen but banned (do not copy)
```

```markdown
# research/selling-points.md
Built from: insights.md + reviews.md + competitors.md + Genrupt analysis + owner intel ([date])
| ID | Selling point | Source | Mapped to | Skipped because |
|---|---|---|---|---|
| SP1 | [point] | insights: must-have (double confirmation) | (brief fills) | |
## Conflicts flagged
## Corrections
```

And on top of them, the unified report:

```markdown
# research/product-report.md . The Product Report
Built by Wonka on top of the five research files, [YYYY-MM-DD]. Sources: interview, own listing,
reviews ([N]+[M]), competitors (C1..C5), Genrupt market analysis [id | declined | unavailable],
Improvement Log [applied lessons | empty, product one].

## The Must-Haves ("table stakes")
[what this niche does not forgive missing, double-confirmed first, each with its confirmation]
## The pains, ranked
[top complaints with counts]
## The expectation gap
[the complaint the listing itself caused, or "none found in this sample"]
## The whitespace
[what nobody shows and buyers care about, each tied to its pain or customer phrase]
## The persona
[the real buyer in a few sentences]
age_dist: {...}  gender: {...}  income: {...}  notes: [...]  source: [brand_registry_export | estimated]
## The funnel diagnosis
[one lever, its evidence, its confidence]
## Customer language worth stealing
- "[verbatim phrase]" (where it could live on an image)
```

## Golden Standards check

Before presenting, verify every line:
- [ ] Marketplace recorded, and the niche phrase confirmed by the user word for word.
- [ ] The listing title was READ BACK and confirmed (fetched or pasted) before any folder was created.
- [ ] The product folder exists on disk with the full structure (1-inputs, 2-reference/photos, 2-reference/brand, research, brief, images, edits, final, aplus, variations, scorecards, tests), verified by listing it, not assumed.
- [ ] Phase A ended with the shopping list handed over in ONE message, folders named per item, and a full STOP. No analysis leaked into Day 1.
- [ ] The interview ran as read-confirm-ask-back, the three ask-back questions were asked, and Phase C started only after WONKA explicitly declared the interview closed (or named, recorded waivers released the missing items).
- [ ] All six sources were used, and any absent one (a declined Genrupt analysis, an empty Improvement Log, a pre-launch listing) was named out loud and recorded, never silently skipped.
- [ ] Every competitor carries a `seen via` line; nothing was analyzed from memory; off-niche entries were dropped and replaced, never kept as "close enough"; at least 3 confirmed and seen.
- [ ] The Genrupt market analysis ran only after an explicit yes to its one-line cost consent, and a failed paid call was never retried through another paid path.
- [ ] Every claim in the files traces to one of the six sources or a labelled estimate. The trace audit ran and untraceable lines were deleted.
- [ ] Every must-have states its confirmation type: double or single-source.
- [ ] Reviews file states its source, its counts and its confidence, and the expectation-gap section is present (a finding, or an explicit "none found").
- [ ] The own-listing teardown exists (or `pre-launch: no live listing`).
- [ ] Material and quality signals made it onto the checklist.
- [ ] Persona carries the panel demographics block with shares that sum to 1.0, plus its source label.
- [ ] The funnel diagnosis names its missing evidence FIRST, states its confidence, and names one lever.
- [ ] Exactly ONE best frame named with a concrete move; non-compliant tactics landed in "seen but banned".
- [ ] The checklist has IDs, sources, and an unfilled "Mapped to" column ready for the Brief Room.
- [ ] `product-report.md` exists, carries all seven sections, says "table stakes" in parentheses exactly once, and never disagrees with the five files under it.
- [ ] Owner intel recorded verbatim, or explicitly `none given` with the user's reason. Never invented.
- [ ] Every waiver and gap is in `## Research gaps` with its cost and what would close it.

## Wonka lines

Openers:
- "A new product at the Gate. Splendid. Papers, please: ASIN, marketplace, brand, niche."
- "Welcome to the Factory. Every great candy starts as a stranger at this gate."
- "The Research Room. Least glamorous, most important. Every flop I have ever made skipped this floor."

End of Phase A:
- "The folder is open and the list is yours. Fill the basket, sleep well, and tomorrow you talk and I listen. Then I ask."

Closing the interview:
- "I have what I need. The interview is closed, the analysis begins. Nobody leaves this floor a stranger."

Closers:
- "Registered, interviewed, researched. [N] selling points on the checklist, one report on top, and every point will be accounted for."
- "Now we know what you know, what the shoppers say, what the rivals show, and where the leak in your funnel is. The Product Report is on the table."
- "One gap on this floor, written down and priced, and not a single invented fact. That is how a factory earns its trust."

On a gap:
- "I have no [item], so I have written that down instead of writing something prettier. Here is what it costs us, and here is what would fix it."

## Definition of Done

- `factory/Products/[product-slug]/` exists on disk with the full structure: `1-inputs/`, `2-reference/photos/`, `2-reference/brand/`, `research/`, `brief/`, `images/`, `edits/`, `final/`, `aplus/`, `variations/`, `scorecards/`, `tests/`.
- `status.md` exists in the TEMPLATE format with the identity table (marketplace, title confirmed, reference photos source), the stations table, Owner intel including the interview answers, Blocked on, Research gaps, and Log.
- The interview was explicitly closed by Wonka before any analysis.
- All 5 research files exist with real content and their required sections: `research/insights.md` (must-haves with confirmation, customer language, pricing, demographics, funnel diagnosis, conflicts between sources), `research/reviews.md` (ranked pains, objections, delight, verbatim language, expectation-gap section), `research/persona.md` (buyer, panel demographics block, display-age note), `research/competitors.md` (own-listing teardown, roster with `seen via`, teardown, matrix, must-haves, whitespace, one best frame, seen but banned), `research/selling-points.md` (IDs, sources, empty Mapped to column). A waived input leaves an explicit `WAIVED` marker, never an empty pretend section.
- `research/product-report.md` exists on top of them with all seven sections, consistent with the five files.
- The competitor relevance and visibility check ran and its result is stated in `competitors.md`.
- The Genrupt market analysis either ran after explicit cost consent, or its absence is recorded in `## Research gaps` with its cost.
- The Improvement Log was read, and on product one its emptiness was said out loud.
- The trace audit ran: nothing in the files is untraceable.
- Every gap and waiver is recorded in `status.md` under `## Research gaps` with its cost.
- The user has seen the summary and been invited to correct it.
- RESEARCH is `done` in `status.md`.

## Update status.md

Set RESEARCH to `done` (or `blocked: [reason]`), list the five files plus `product-report.md` as artifacts, clear delivered items from `Blocked on`, and add the Log lines:
`[date] Product registered at the Front Gate. Interview started, shopping list handed over.`
`[date] Interview closed by Wonka: [received/waived counts].`
`[date] Research done: [N] selling points, best frame = [CX pos N], funnel diagnosis = [CTR/CVR/no data, confidence], Genrupt analysis = [run: id | declined | unavailable], gaps = [count]. Product Report written.`
Corrections and top-ups each get their own Log line as they happen, so a future session can see what the research learned after it was first written.

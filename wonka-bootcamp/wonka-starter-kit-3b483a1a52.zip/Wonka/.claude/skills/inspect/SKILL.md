---
name: inspect
description: The mandatory QA gate between image generation and the human's pick. Runs on a stated SCOPE (main, secondary, listing, A+, variations, or the whole package), opens every in-scope image with vision, scores 6 dimensions, runs the mechanical mobile squint test at 160 pixels, applies the compliance gate, ranks variants on execution quality, and offers to auto-fix the cheap fails before the user ever sees the set. Use after /main-image, /secondary-images, /aplus, /variations, or /fix, or when the user asks to review, score, QA, grade, or rank images. Triggers: /inspect, "inspect the images", "inspect the secondary set", "inspect scoped to the A+", "QA these", "score the set", "which image is best", "review what we generated".
---

# The Inspection Room

| Meta | Value |
|------|-------|
| Room | The Inspection Room |
| Station | INSPECT |
| Taught | Day 5, in one piece. Re-run on Day 6 (a whole set), Day 7 (a whole page), Day 8 (fixes and challengers), Day 9 (the variation family) |
| Needs | The in-scope images, plus `brief/creative-brief.md`, `2-reference/reference-sheet.md`, `factory/Brand/brand-kit.md`, `research/persona.md`, `research/selling-points.md` |
| Saves to | factory/Products/[product]/scorecards/scorecard-[scope]-[YYYY-MM-DD].md + scorecards/squint/[scope]-[YYYY-MM-DD]/ (one folder per run) |
| Writes | ONLY inside `scorecards/`. Never renames, moves, overwrites or deletes an image, a batch log, or an earlier scorecard |
| Typical cost | Free to inspect. The optional auto-fix runs through /fix at cents per edit, quoted and approved first |

## What this room does

Nothing leaves the Factory without passing this room. Every in-scope image is opened with vision, described literally, scored, checked against the compliance avoid-list, and force-ranked against its sibling variants. Cheap defects are offered up for repair BEFORE the user sees anything, so the human's job is to pick winners, never to discover defects.

Two things this room is not. It does not pick the winner: the ranking is EXECUTION QUALITY, the tasters decide conversion in the Tasting Room. And it does not generate or edit: it names the defect and the route, then the generation rooms or the Fixing Room do the work.

Different asset classes are judged differently. Do NOT apply the listing-image set rules (no people in a main, one emotional frame, no repeated face) blindly to A+ or variations. Each class has its own checklist in step 8.

## Step 0. State the SCOPE, out loud, before anything else

A run always covers ONE scope. Naming it is what stops this room flagging an empty A+ folder as a defect on Day 5 and what stops the Day 6 scorecard landing on top of the Day 5 one.

| Scope | Folders read (ALWAYS resolved per class through the highest `edits/vN/` first, per step 1; the folders below are the originals when no round exists) | Set-level checklist | Usually |
|---|---|---|---|
| `main` | `images/` main-* plus `vanilla-control.png` when it exists (opened and read for drift, marked `diagnostic, not a candidate`, never ranked or gated as one) | listing-set (mains only: no duplicate bets) | Day 5 |
| `secondary` | `images/` sec-* only | listing-set, full | Day 6 |
| `listing` | `images/` all | listing-set, full | after both are built |
| `aplus` | `aplus/` | A+ page checks | Day 7 |
| `variations` | `variations/` | variation family checks | Day 9 |
| `package` | all three folders | all three checklists, kept separate | a full sweep |

1. Take the scope from what the user asked ("inspect the secondary set", "scoped to the A+ modules"). If they did not say, infer it from the INVENT sub-status in `status.md`: the sub-part that just went to `done` and has no scorecard yet. If two are equally plausible, ASK in one line rather than guessing wide.
2. ECHO it back before spending any effort: "Scope: the secondary set, 7 files in images/. The mains, their scorecard and the A+ are out of scope and stay untouched."
3. Folders outside the scope are NOT gaps and are NOT flagged. Write them as `out of scope this run`.
4. Inside the scope, an empty folder IS reported: either as a recorded conscious skip in the INVENT sub-status (`Variations: n/a (single SKU)`), or as the lawful trailing marker `Variations: pending (Day 9)`, which blocks nothing, or as a real gap that needs the generation room first.

If the scope holds no image files at all, the room is closed: name the generation room that fills it (`/main-image`, `/secondary-images`, `/aplus`, `/variations`) and stop. That is the only hard block in this room.

## Before you start. Inputs, and what happens when one is missing

Ask for every input once. **"I don't have it" is a real answer and the run PROCEEDS**, in DEGRADED mode with the gap written into the scorecard header. What never happens is a dimension being invented to fill a hole, or a degraded run being called `done`.

| Input | If present | If missing or "I don't have it" |
|---|---|---|
| `brief/creative-brief.md` | Every image is judged against the JOB its slot, module or child was assigned | Say what it costs, offer `/creative-brief`, then proceed DEGRADED: **message clarity and selling-points coverage are recorded `UNSCORED (no brief)`**, never guessed. Craft, legibility, product accuracy, brand fit and the compliance gate all still run |
| `2-reference/reference-sheet.md` + the photos in `2-reference/photos/` | Product accuracy is judged against it, never against memory. Note whether it records `source: manual` or `source: amazon_scraped` | Fall back, in order: the reference photos on disk, then the listing gallery images. Nothing at all means product accuracy is `UNVERIFIED (no reference)` and the run is DEGRADED. Never score fidelity from memory of the category |
| `factory/Brand/brand-kit.md` | Brand fit scored against its colors, fonts and tone | Score brand fit as `no kit on file`. Not a deduction, not an invented standard |
| `research/persona.md` | Casting judged against the real buyer age plus the aspirational display skew | Casting judged on authenticity and craft only; the age-skew check is recorded `unverifiable (no persona)` |
| `research/selling-points.md` | The coverage walk in step 8 uses its IDs | Fall back to the brief's coverage map. Neither on file means coverage is `UNSCORED`, stated plainly |
| `incumbent/` (the live main and gallery, saved at the end of Day 7) | The distinctiveness read in step 6 runs | Record `no incumbent on file` and remind the user that the Tasting Room needs it on Day 8. Not a blocker here |
| A downscaling tool (`sips`, ImageMagick, or Python Pillow) | The squint test runs mechanically | See step 4. Legibility becomes `UNVERIFIED` for every image and the run is DEGRADED. It is never eyeballed at full size instead |

A DEGRADED run still produces a full scorecard, still gates compliance, and still ranks. It just carries a header banner naming every gap, and INSPECT stays `in progress` in `status.md` until the gap is filled.

## Process

1. **Inventory the scope.** List the actual files on disk in the in-scope folders (run the listing, do not recall it), including `-vN` regenerations. Then check `edits/`: if any round folder `edits/vN/` exists, the HIGHEST one holds the CURRENT version of every fixed file (surgical edits keep the filename; the round lives in the folder name), so inventory the current copies from there alongside the originals. **Resolve PER CLASS, the Fixing Room's own rule:** main and gallery files sit at the top of `edits/vN/`; A+ modules sit in `edits/vN/aplus/` and variation imagery in `edits/vN/variations/`, in the highest round that CONTAINS that subfolder (a fix round does not touch every class). Looking for an A+ module at `edits/vN/m3.png` finds nothing and silently scores the superseded original in `aplus/`. Group each file by ASSET CLASS:
   - **Main image**: `images/main-*.png`. Product-only hero.
   - **Secondary image**: `images/sec-*.png`. Benefit, proof, lifestyle, scale.
   - **A+ module**: `aplus/m*.png`. One Enhanced Brand Content module.
   - **Variation main**: `variations/main-[child].png`. A per-child hero.
   - **Variation swatch**: `variations/swatch-[child].png`. The tiny variation-picker chip.
   - **Variation propagated frame**: `variations/[slot]-[child].png` (e.g. `pt03-round-10in.png`). A gallery frame the frame table marked variant-carrying, edited for this child. Judge it as a secondary image AND against this child's truth-table row in `variations/variations-plan.md`: the printed count, size and claims must be this child's, not the source's.
   Always write the file path folder-first (`images/main-01.png`, `variations/main-amber.png`); the two `main-*` families live in different folders and must never be confused. Group variants of one slot, module or child together using the filenames plus `images/batch-log.md`, `aplus/aplus-plan.md` and `variations/variations-plan.md`.

2. **Resolve the LINEAGES.** For each slot, module or child, order its files by version: original, then `-v2` regenerations, then the same filename's copy in the highest `edits/vN/` round folder that carries its class (top level for main and gallery, `edits/vN/aplus/` for A+ modules, `edits/vN/variations/` for variation imagery; the Fixing Room's surgical edits keep the name; the round lives in the folder). **Only the LATEST file in a lineage is a rankable candidate.** Score every file you opened, but mark superseded parents `superseded by [file]` and never put one on the candidate list. This is what keeps the room aligned with the Fixing Room, where a passing fix replaces its parent in the ranking.

3. **Open EVERY in-scope image with vision.** Use Read on each file. No image is scored unseen. For each one, write a 1 to 2 line LITERAL description first: product, text you can actually read, people, props, background. That description is the evidence. If you cannot honestly describe it, you have not looked at it, and a score written without it is a fabrication.

4. **Run the mechanical squint test on every in-scope image.** Full-size eyeballing is forbidden; small text always looks fine at full size. Write a real 160 pixel copy to disk and READ THAT COPY. Resample by WIDTH, from the kit root:
   ```bash
   mkdir -p "factory/Products/[product]/scorecards/squint/[scope]-[YYYY-MM-DD]"
   # macOS
   sips --resampleWidth 160 "factory/Products/[product]/images/main-01.png" --out "factory/Products/[product]/scorecards/squint/[scope]-[YYYY-MM-DD]/main-01-160.png"
   # Windows or Linux, ImageMagick
   magick "factory/Products/[product]/images/main-01.png" -resize 160x "factory/Products/[product]/scorecards/squint/[scope]-[YYYY-MM-DD]/main-01-160.png"
   # last resort, Python with Pillow
   python3 -c "from PIL import Image; i=Image.open('IN'); i.resize((160,round(i.height*160/i.width))).save('OUT')"
   ```
   **While you have the file open, record its REAL pixel size on the card too**, in the `Size:` line of that image's verdict block. One command reads the whole scope at once:
   ```bash
   python3 -c "
import pathlib,sys
from PIL import Image
for p in sorted(pathlib.Path(sys.argv[1]).rglob('*')):
    if p.suffix.lower() in {'.png','.jpg','.jpeg','.webp'}:
        w,h=Image.open(p).size
        print(f'{p.name:34} {w}x{h}' + ('  <-- under 1000' if max(w,h)<1000 else ''))
" "factory/Products/[product]/images"
   ```
   No Pillow and no other tool: write `size: UNMEASURED` on each card rather than guessing from the file size, and say so once in the run status.
 One line per image, it costs nothing, and it is the only early warning for a defect no eye catches: Amazon opens zoom at 1000 pixels on the longest side and rewards 1600 and up, while a surgical edit returns the endpoint's working size rather than the source's. So an edited file is usually the smallest in an otherwise full-resolution set. Note anything under 1000 as a flag on the card, and note plainly when one image in a set is markedly smaller than its neighbours. This is a REPORT, not a FAIL: resolution is fixed at packaging, where the Shipping Room measures again and offers the upscale. Silence here is what lets a 1024 hero reach a listing beside a 2000 gallery.

   Then open the 160 pixel copy with Read and record VERBATIM which words survive and which dissolve.
   - Pass on a text-bearing image: the one dominant message reads in under 2 seconds at that size. The ~3.5%-of-short-edge size floor and a real ink-to-background contrast are BOTH necessary, and neither is sufficient: measured on real tags, a 3.9% dark-brown-on-kraft line dissolved at 160px while a 3.2% white-on-black line read cleanly, so contrast decides as often as size does. **The actual 160px read outranks both numbers**: what you can read on the squint copy is the verdict, and the size and contrast notes explain WHY it passed or failed, never overturn what the read showed.
   - Pass on a MAIN or a variation main (no overlay text by law): at 160 pixels you can still tell WHAT the product is, HOW BIG it is, and WHAT IT IS MADE OF. If the product reads as an unidentifiable shape, legibility fails even with zero text on it.
   - Pass on a swatch: the chip reads as its intended color, size or scent at thumbnail scale. A swatch that fails this has failed its entire job.
   - **If none of the three tools exists**, say so in one line, tell the user what to install, mark legibility `UNVERIFIED` on every card, and run the rest of the inspection. Never substitute a full-size judgment and never claim a squint test that did not happen.

5. **Verify the squint copies exist, mechanically.** Count THIS run's folder, never the whole squint tree:
   ```bash
   ls "factory/Products/[product]/scorecards/squint/[scope]-[YYYY-MM-DD]/" | wc -l
   ```
   **The per-run folder is what makes this check survive a second inspection.** Squint copies accumulate: a flat folder holding five copies from an earlier run can never equal the two images in scope when `/fix` sends two back today, so the gate would be unsatisfiable from the second run onward and the only way to "pass" would be to stop believing it. One folder per run, counted on its own.
   The count must equal the number of in-scope images. If it does not, the missing images were not squint tested: go back and do them. A legibility score with no file behind it is worth nothing, and this line is the proof that it happened.

6. **Score 6 dimensions, 1 to 5 each, asset-class-aware.**
   - **Message clarity**: one dominant message, and it matches the JOB the brief assigned this image. Two competing headlines, or an off-brief message, caps this at 2. On a MAIN or a variation main there is no overlay message by law, so this scores the CATEGORY READ instead: at thumbnail size, does a shopper instantly know what this product is.
   - **Legibility**: from the step 4 result ONLY. If the dominant message failed at 160 pixels, this is 1 or 2 no matter how it looked at full size.
   - **Product accuracy**: matches the Reference Sheet. Correct size, shape, label, colors, material and PART COUNT, every part the spec lists present and countable (a four tier fountain shows all FOUR tiers; a stainless base reads as brushed metal and not grey plastic; glass reads as translucent glass and not opaque plastic). A beautiful image of the wrong product scores 1. **The accuracy check covers EVERY depiction of the product in the frame, not just the hero**: an inset, a corner panel, a before/after thumbnail, a product shown in use behind the main subject. A wrong form ANYWHERE in the frame is a blocking flag, never a minor note because the wrong bit is small. Small is where this defect hides, and "it is only the inset" is exactly the reasoning that ships it. On variations, the product also has to stay consistent with its siblings; only the varying attribute may differ.
   - **Brand fit**: colors, fonts and tone against `brand-kit.md`. A font that fights the brand look is a real deduction, not a nitpick.
   - **Craft**: no AI artifacts, no garbled or misspelled text, no wrong hands or melted objects, clean edges, believable lighting.
   - **Casting** (people-bearing images only, otherwise `null`). TWO mechanical steps come BEFORE the judgement, and both exist because a careful look failed twice on the same set:

     **(a) Run the cast screen on the whole scope first**, before opening anything:
     `python3 .claude/skills/inspect/cast_check.py <folder>`. Read the `neutral` column. A frame
     under 5 percent neutral has no white anywhere in it, so there is nothing for skin to be
     anchored against and skin drifts to whatever the grade says. Measured on 26.8.2026: the A+
     hero came back at 1 percent neutral with a ONE degree hue spread across forehead, cheek, nose
     and jaw, its subject's teeth were not white, and a bride's dress in another module was not
     white either. The owner described it as fake tan and bad makeup and he was right; two passes
     by eye had called it clean, because an eye adapts to a grade within seconds and then reads it
     as lighting. **When the screen says CAST, the defect is the GRADE and the fix is the grade.
     Never send a cast frame to a face pass:** correcting people inside an orange room leaves them
     not matching their own room, which looks worse than the original.

     **(b) Then open each face at 3x or better**, cropped to the face alone. A face inside a 1464px
     module is 250px; viewing the module, even at native resolution, is not viewing the face. The
     first pass on that same A+ zoomed the module and missed a specular sheen on forehead, nose and
     cheekbone plus a uniform skin tone with no variation between regions.

     Only then judge: the displayed person matches the persona's aspirational display age and looks like a real human being. In the LISTING set the person must also be a DIFFERENT person from every other people-bearing listing image. A+ people are judged on authenticity and age-fit only; the different-person rule is scoped to the listing set.
     **The people-realism check, conditional and named.** Most generated people pass; this check exists for the ones that do not, and it names WHICH of three failure signatures it sees, because each routes differently:
     - **Signature A, doll face** (geometry and expression): too-perfect symmetric features, uniform flawless teeth, glassy eyes, everyone in frame at identical peak expression. Shows up even when lighting and color are believable.
     - **Signature B, waxy skin + uniform tone**: zero micro-texture (no pores, one smooth gradient), and every person the same peach-orange tone matching the design palette instead of varying per person.
     - **Signature C, the filter layer**: a diffusion/bloom glow like a beauty filter, highlights smearing on forehead and cheekbones, warm light patches painted on with no single consistent light direction.
     A clean image is left alone. A flagged one records its signature letters in the verdict and routes to `/fix`'s people-rescue pass (any signature; one cheap edit pass fixes all three) or to regeneration when the composition itself is also wrong. Faces are never "enhanced" speculatively; no signature, no touch.

   **Asset-class notes:**
   - **Main image**: product-only. Weight product accuracy, craft and the category read. If `incumbent/` holds the live main, open it once and add a one-line DISTINCTIVENESS read per candidate at 160 pixels: does this stand apart from the incumbent, or is it the same picture in a new coat. If every candidate reads as a near-copy of the incumbent, flag the SET, because no panel can rescue four versions of what is already live. This read is diagnostic and feeds Day 8. **It is never a winner call.**
   - **Secondary image**: full 6-dimension scoring.
   - **A+ module**: NO incumbent exists (A+ is not A/B tested), so never down-score a module for lacking one. People ARE allowed in A+; it sits below the gallery. Judge module clarity, legibility, compliance, brand fit, craft and product accuracy.
   - **Variation main**: product-only, exactly like any main. No people.
   - **Variation swatch**: tiny-size legibility plus consistency with the Reference Sheet and its siblings. A swatch legitimately REPEATS the product; that is its job. Never flag a swatch for repetition or for matching its siblings.

7. **Apply the COMPLIANCE GATE. Pass or fail, no partial credit, no score buys it back.**
   The gate reads THREE lists, and the second and third are the ones this step used to skip:
   1. **The house avoid-list** (below).
   2. **This product's own must-avoid list**, from `status.md` and the brief's compliance section. An image that depicts or implies exactly what the owner's research forbade (an over-promising flow, a use the reviews punish) is flagged even when every house rule passes. A must-avoid hit is recorded as an **OWNER-AVOID FLAG**, surfaced and carried forward on the card rather than an automatic pull, because the owner may knowingly keep one (a like-for-like challenger against an over-promising incumbent is the legitimate case). The flag rides into the Tasting Room notes so the verdict is read with the question already in view.
   3. **The brand kit's approved-claims table.** Every claim rendered ON an image (a benefit lockup, a callout, a badge-shaped promise) must trace to a row in `factory/Brand/brand-kit.md`'s approved-claims table or to text physically on the real label. A claim with no row is flagged and routed to a surgical removal or to the OWNER as a claims decision (approve it into the table, or strip it), never waved through because it is small or plausibly true. This catches the case the house list structurally cannot: a slot brief that authored a stronger claim than the brand approved, which then renders as a confident lockup nobody signed.
   EVERY image, every class, FAILS on the house list if it contains any of: medical or disease claims, invented percentages or statistics, star ratings or review references, fake badges or awards, third-party logos rendered as graphics, flag graphics. Real certifications the product genuinely carries, as they appear on the real label, are allowed. **An invented certification, approval seal or award emblem is a FAIL at ANY size, including one rendered small onto the packaging inside the shot.** It is routed to a surgical-edit removal, never downgraded to a minor note for being tiny: Amazon reads the pixels, not the intent, and a fabricated seal is a suppression risk rather than a style problem.
   **MAIN-only gate** (listing mains and variation mains): additionally FAILS on any FACE, always; on a hand or person UNLESS the owner enabled the human-contact tactic in the brief (then hands are lawful and are judged for realism under Craft and Casting instead); and on ANY overlay text or graphic, meaning anything not physically printed on the product, its label, or the approved hang-tag. Variation mains stay strictly product-only. This does NOT apply to secondaries, A+ modules (people and overlay copy are welcome) or swatches.
   A FAIL sinks the image to the bottom of its group regardless of scores, names the exact violation, and may not be presented as a candidate until it is fixed.

8. **Run the set-level checks, PER asset class.** Never pool the classes; a swatch repeating the product and an A+ module reusing a face are not defects.

   **LISTING set** (`images/`):
   - Duplicate messages: no two listing images carry the same headline or make the same point. Name any pair. On a `main`-only scope this reads as: no two concepts are the same BET in different decoration.
   - Emotional frame: at least one emotional or lifestyle frame exists in the secondary set. Flag if missing.
   - Repeated face: the same person may not appear twice. A repeat routes UPSTREAM to a distinct custom avatar with an explicit age and gender, then a re-run of that one slot through `/secondary-images`. Never a brief paragraph, never an edit.
   - Selling-points coverage: walk `research/selling-points.md` (or the brief's coverage map) ID by ID. Each is covered by a named image or was consciously skipped IN WRITING. A point that simply vanished is a flag.

   **A+ page** (`aplus/`). A page is judged as a scroll, not a grid:
   - Module ORDER: the page reads hero to trust, in a deliberate order, and no module is stranded.
   - One message each: no two modules share a headline; each has a single dominant job.
   - Extends, does not repeat: the A+ adds to the gallery rather than re-serving it. Say which modules earn their place.
   - Comparison honest: every comparison row is true, provable and about our own product. No named competitor brands, no prices, no invented wins.

   **Variation family** (`variations/`):
   - Reads as siblings: shared angle, lighting and background family, consistent with the Reference Sheet. Only the target attribute varies.
   - True counts per child: the part count and proportions are right in every child, not just the first one.
   - Correct labeling: each main and swatch is tagged to a REAL child, and the swatch reads as that child's attribute at tiny size.

9. **Rank each group 1..N on EXECUTION QUALITY, where a group HAS more than one candidate.** In practice that is the `main` scope: secondaries, A+ modules and variation children carry exactly ONE candidate per slot by their own rooms' rules, so those scopes record the scores and write `one candidate per slot, nothing to rank` instead of inventing a cross-slot ranking of six different jobs. Per listing slot, per A+ module, per variation child, over the rankable candidates from step 2. Compliance passes always rank above compliance fails. Among passes, rank by total score, tie-broken in this order: legibility, then product accuracy, then message clarity. Write the tie-break down whenever it was used.
   **What the ranking is not:** it is not a prediction of what converts, and it never eliminates anything. Four main concepts are four different BETS. A bet does not lose because its execution ranked third; it loses in the Tasting Room, to the tasters, on Day 8. Every gate-passed candidate advances. If a bet is genuinely unbuildable, say that in words instead of quietly dropping it off the list.

10. **Escalate the two failures that no single edit can fix.**
    - **Fidelity:** if MORE THAN ONE image in a batch scores 2 or below on product accuracy, stop routing them one at a time. That is a reference problem wearing an image problem's clothes: send the user to `/reference-sheet` for a re-lock and a fresh smoke test BEFORE any regeneration is paid for.
    - **Repetition:** if a defect survives TWO fix rounds on the same image, stop editing it. Route it to regeneration, or upstream to the brief or the casting, and say which. A third attempt at the same edit is money burning quietly.

11. **Write the scorecard to disk NOW, before any money is discussed.** Save to `scorecards/scorecard-[scope]-[YYYY-MM-DD].md` using the Output format. If that filename already exists, append `-2` (then `-3`); **never overwrite an existing scorecard and never edit an earlier one.** The Day 5 main scorecard and its ranking must still be there, untouched, on Day 10. The only file this run may rewrite is its own, in step 13.

12. **Offer the auto-fix, and take no for an answer.** Build the list of cheap, safe fixes: remove a stray element or a fake badge, shorten an over-long label, swap a non-compliant word or claim. Present it with a one-line total cost estimate (roughly $0.02 to $0.10 per edit, so N edits at about $X). Then ONE go-ahead covers the whole list; never ping item by item, never spend silently.
    Things that need a new bake are NOT on that list: tiny text that must be enlarged, anything moved or resized, layout, casting, or the product itself. Those are written up as "regenerate with a tighter brief", each with the EXACT sentence the new brief must carry.
    - **Yes:** route the whole list to `/fix` (MODE A), then continue to step 13.
    - **No, or "I will run /fix myself":** that is a normal answer and Day 5 explicitly asks for it once. The scorecard already exists from step 11; hand over the routed fix list as it stands, mark the affected images `flagged, fix not yet run`, and leave INSPECT `in progress`. Never present a known-defective image as a candidate just because the fix was declined.

13. **Re-inspect what came back, then update this run's scorecard.** Every fixed or regenerated file goes through steps 3 to 9 again: a fresh 160 pixel copy, the six scores, the compliance gate. Nothing is fixed because it feels fixed. Update the scores, the ranking and the Fixes section in the scorecard file written in step 11, in place.

14. **Present.** Show only gate-passed, ranked candidates, and say in one line what the human's decision actually is: which candidates enter the Tasting Room, not which one wins. Then name the next room: `/tasting-room` when the package is gated, or the generation room that owes a regeneration.

## Output format

`scorecards/scorecard-[scope]-[YYYY-MM-DD].md`:

```markdown
# Inspection Scorecard . [Product Name] . scope: [main/secondary/listing/aplus/variations/package] . [YYYY-MM-DD]

Built from: [folder]/ ([N] files in scope), brief/creative-brief.md, 2-reference/reference-sheet.md (source: [manual/amazon_scraped]), factory/Brand/brand-kit.md, research/persona.md, research/selling-points.md
Out of scope this run: [folders not inspected, and why]
Squint copies verified on disk: [N] of [N] in-scope images, in scorecards/squint/[scope]-[YYYY-MM-DD]/ ([tool used])
Run status: [CLEAN / DEGRADED: [gap, and what it made UNSCORED]]

## Verdicts

### [images/main-01.png] . slot: [main concept 1, bet: "..."] . version: [original / edits/v1 fixed copy, supersedes images/main-01.png]
- What I see: [1-2 line literal description]
- Squint test (160px): [PASS/FAIL] . survives: "[words or: product reads as a 4 tier fountain, size unclear]" . lost: "[words]"
- Size: [WxH] [flag when under 1000 on the longest side, or markedly smaller than its neighbours in the set. Report only; resolution is settled at packaging]
- Scores: message [x]/5, legibility [x]/5, product accuracy [x]/5, brand fit [x]/5, craft [x]/5, casting [x/5 or null]
- Compliance gate: [PASS / FAIL: exact violation]
- Distinctiveness vs incumbent: [stands apart on X / near-copy of the live main / no incumbent on file] (mains only, diagnostic)
- Verdict: [SHIP / FIX: what and how / REGENERATE: the exact sentence the tighter brief must carry]

[...repeat per in-scope image. A+ modules and variation children use the same card, with module or child in place of slot...]

## Set-level summary

### Listing set [omit any section whose class is out of scope]
- Duplicate messages: [none / files X and Y both say "..."]
- Emotional frame: [present in X / MISSING]
- Repeated face: [none / X and Y share a model . route: distinct avatar, re-run that slot]
- Selling points: [n]/[total] covered. Missing: [ID . proposed home, or "consciously skipped, see brief"]

### A+ page
- Module order: [hero to trust, reads as a scroll / issue]
- One message each: [yes / M2 and M4 share a headline]
- Extends the gallery: [yes, M3 and M5 add what the gallery cannot / repeats the gallery at M2]
- Comparison honest: [yes / no comparison module / issue]

### Variation family
- Reads as siblings: [yes / [child] drifts on background or lighting]
- True counts per child: [all correct / [child] shows 3 tiers]
- Labeling: [all children correctly tagged / issue]

## Rankings (execution quality, per group. Not a prediction of what converts)
- MAIN: 1. images/main-03.png ([score]) 2. ... [tie-break used: legibility]
- SECONDARY [n]: ...
- A+ [module]: ...
- VARIATION [child]: ...
All gate-passed candidates advance. No bet was eliminated by rank.

## Escalations
- [Fidelity: [n] images at product accuracy <= 2 . re-lock the reference and re-run the smoke test before regenerating / none]
- [Repetition: [file] failed the same defect twice . routed to regeneration / none]

## Fixes this run
- [file] -> edits/v[N]/[file]: [what changed] . re-scored [old] -> [new]
- [or: fix list handed to the owner, not yet run. Affected: [files]]

## Needs regeneration
- [file] . [defect] . the brief must add: "[exact sentence]" . goes back to [/main-image | /secondary-images | /aplus | /variations]

## Recommendation
[One sentence per group. The candidates that passed the gate, and the decision that is the human's: which of them enter the Tasting Room.]
```

## Golden Standards check

Before presenting, verify:
- [ ] The scope was stated out loud and echoed back, and no out-of-scope folder was inspected, touched, or reported as a gap.
- [ ] Every in-scope file was opened with Read and has a literal description. No image scored unseen.
- [ ] `scorecards/squint/[scope]-[date]/` holds a 160 pixel copy of every in-scope image, the count was verified with an actual directory listing of THAT folder (never the whole squint tree, which accumulates across runs), and both numbers are in the header. No full-size legibility judgments anywhere. Swatches were read at tiny size specifically.
- [ ] Missing inputs were asked for once, "I don't have it" was accepted, and every resulting gap is named in the header with the affected dimension marked UNSCORED or UNVERIFIED rather than guessed.
- [ ] Product accuracy was judged against the Reference Sheet, never memory, and the part count was actually counted.
- [ ] Every compliance FAIL names the exact violation and sits at the bottom of its group. The MAIN-only gate was applied to listing mains and variation mains only.
- [ ] Set-level checks ran per class: the four listing checks; the four A+ page checks including module order and extends-not-repeats; the three variation family checks. No swatch was false-flagged for repeating the product, no A+ module for reusing a face.
- [ ] Only the latest file in each lineage is on the candidate list; superseded parents are marked, not ranked.
- [ ] The ranking states its tie-breaks, and no hypothesis was dropped because it ranked last.
- [ ] The fix list carried one total cost line and one go-ahead, and a declined offer left the scorecard on disk with the images honestly marked flagged.
- [ ] The scorecard file exists on disk under a scope-and-date name, and no earlier scorecard was overwritten or edited.

## Wonka lines

Openers:
- "The Inspection Room. Charm stays at the door; only the candy speaks here."
- "Let's see what the machines made. I warn you, I am impossible to flatter."
- "Every piece on the belt, please. Nothing skips the light."

Closers:
- "Now THAT is a piece of candy. Ship the gate-passed ones to the Tasting Room."
- "Inspected, ranked, and repaired. Your only job now is to say which ones face the tasters."
- "Wrong, sir, wrong, on two of them. But the Fixing Room already earned its keep. The rest gleam."
- "You'd rather hold the scalpel yourself? Good. The list is routed and the scorecard is on disk. I will be here when they come back."
- "No shrinking machine on this bench, so the legibility scores are marked unproven. I will not pretend I squinted."

## Definition of Done

- `scorecards/scorecard-[scope]-[date].md` exists on disk, under a name that did not already exist, with: the scope, the built-from line, the squint count verified by listing, a verdict card for every in-scope image, the per-class set-level summary, per-group rankings with tie-breaks, escalations, fixes, regeneration items with their exact brief sentences, and a recommendation.
- `scorecards/squint/[scope]-[date]/` holds one 160 pixel copy per in-scope image and its count matches, or the header states which tool was missing and legibility is marked UNVERIFIED throughout.
- Every gap from a missing input is written in the header, and no dimension was invented to cover one.
- The fix list was quoted with one cost line and either run and re-inspected, or handed over intact with the images marked flagged.
- The user was shown only gate-passed candidates, and was asked which enter the Tasting Room, never which one wins.
- No image, batch log, or earlier scorecard was renamed, moved, overwritten, or deleted.

## Update status.md

Set INSPECT to `done` only when the scope's candidates are gate-passed and the run was CLEAN. Leave it `in progress` while regenerations are pending, while a declined fix list is outstanding, or while the run is DEGRADED, and name the reason. Use `blocked` only when the scope held no images at all. Artifact: the scorecard filename.

Log line: `[date] Inspection ([scope]): [n] images scored, [n] squint copies on disk, [n] compliance fails, [n] auto-fixed, [n] sent back for regeneration. [CLEAN / DEGRADED: gap]. Scorecard: scorecard-[scope]-[date].md`

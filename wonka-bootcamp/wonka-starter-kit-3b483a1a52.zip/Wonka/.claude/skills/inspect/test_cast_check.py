#!/usr/bin/env python3
"""The colour-cast screen.

Calibrated on the 26.8.2026 dry run, where an eyeball passed the A+ twice and
the owner was right anyway. The numbers below are MEASURED from those files,
not chosen: the graded A+ hero sat at 98 percent band30 with 1 percent neutral,
and the white-background main image that shipped clean sat at 61 / 83.

Run: python3 test_cast_check.py
"""
import sys, tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
FAILURES = []


def check(name, cond, detail=""):
    print(("  PASS  " if cond else "  FAIL  ") + name + ("  " + str(detail) if not cond and detail else ""))
    if not cond:
        FAILURES.append(name)


def run():
    import numpy as np
    from PIL import Image
    import cast_check

    tmp = Path(tempfile.mkdtemp())
    rng = np.random.default_rng(3)

    # a graded frame: every pixel inside one orange band, nothing neutral
    orange = np.zeros((320, 320, 3), np.uint8)
    v = rng.integers(60, 235, (320, 320))
    orange[..., 0] = v
    orange[..., 1] = (v * 0.62).astype(np.uint8)
    orange[..., 2] = (v * 0.35).astype(np.uint8)
    Image.fromarray(orange).save(tmp / "graded.png")

    # a white-background product shot: mostly neutral
    white = np.full((320, 320, 3), 244, np.uint8)
    white[120:220, 120:220] = [130, 92, 60]
    Image.fromarray(white).save(tmp / "on-white.png")

    # a derived page view that must never be measured
    Image.fromarray(orange).save(tmp / "aplus-page-desktop.jpg")

    b, n, _ = cast_check.measure(tmp / "graded.png")
    check("a single-hue frame with no neutral is called CAST",
          cast_check.verdict(b, n) == "CAST", f"band={b} neutral={n}")

    b2, n2, _ = cast_check.measure(tmp / "on-white.png")
    check("a white-background product shot is ok",
          cast_check.verdict(b2, n2) == "ok", f"band={b2} neutral={n2}")
    check("and it reads as mostly neutral", n2 > 50, n2)

    got = {f.name for f in cast_check.files_from([str(tmp)])}
    check("the built page views are not measured as if they were assets",
          got == {"graded.png", "on-white.png"}, sorted(got))

    # the boundary the thresholds encode, stated so a later edit has to face it
    check("a heavily banded frame that still HAS a neutral anchor is not a cast",
          cast_check.verdict(96, 22) == "ok", cast_check.verdict(96, 22))
    check("and a banded frame with no anchor is",
          cast_check.verdict(96, 2) == "CAST", cast_check.verdict(96, 2))

    print()
    if FAILURES:
        print(f"FAILED ({len(FAILURES)}): " + ", ".join(FAILURES))
        return 1
    print("CAST CHECK: all green")
    return 0


if __name__ == "__main__":
    sys.exit(run())

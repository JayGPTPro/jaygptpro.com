# The Front Gate Shopping List

**What your product needs in its hands before it walks through the gate on Day 2.**

Wonka will ask for all of this in one go, then he will refuse to move until it is there. That
refusal is deliberate. Research done on thin inputs produces a confident brief built on
nothing, and you will not find out until the images are already wrong.

**Everything goes straight into your product folder**, which Wonka opens for you at the end of
Day 1. There is no Desktop folder and nothing gets dragged anywhere. Each item below says exactly
which folder it belongs in, and Wonka's shopping list on Day 1 will say the same.

---

## 1. Your listing

Just the URL, or the ASIN. Wonka pulls the rest.

```
[ ] Product URL or ASIN, ready to paste when Wonka asks
```

**Read the title back when Wonka repeats it.** A single wrong character in an ASIN still
passes a format check and sends the whole factory off to research somebody else's product.
This has happened. Ten seconds of reading now saves a day.

---

## 2. Reviews. The most important file in the folder

```
into 1-inputs/
[ ] reviews.txt  . about 10 positive and about 10 critical
```

**How to copy them properly, because this is where people lose the day:**

1. **Be logged in on amazon.com.** Logged out, the page shows a handful of reviews and skews
   positive. The whole value of Day 2 lives in the critical ones.
2. Sort by **Most recent** and copy about ten.
3. Then filter to **Critical** and copy about ten more.
4. Paste all of it into one plain text file. Formatting does not matter. Do not summarise, do
   not tidy, do not drop the angry ones. The angry ones are the material.

If you own the listing, Seller Central gives you the full set and is better than the public
page.

**Why this file matters more than the rest:** your buyers already wrote down what your images
should say. Nobody reads it. That is the whole opportunity.

---

## 3. Competitors. Three to five, same niche

```
into 1-inputs/
[ ] competitors/  . a folder
    [ ] their listing URLs in a text file
    [ ] screenshots of each one's FULL image gallery
```

**Same niche, not same keyword.** A search for your product will return roughly 85 percent
noise: accessories, adjacent categories, and things that merely share a word with you. Pick
the ones a real buyer would genuinely compare against yours, side by side, before choosing.

Best place to find them: the comparison strip on your own listing, and the "customers also
viewed" row. Amazon already did this work for you.

**Screenshot the whole gallery, not just the main image.** The whole point is seeing what
every competitor shows and, more valuable, what none of them show.

---

## 4. Your product photos, AND your packaging

```
into 2-reference/photos/
[ ] the eight product shots
[ ] box-front.jpg, box-back.jpg, label-panel.jpg   . your packaging
```

See the Product Photo Shot List one pager for the eight shots.

**The packaging is a separate job and people skip it.** Photograph the box, pouch, sleeve or tin
front, back, and its label panel. Packaging travels in its own channel inside the machine and it
unlocks a real hero-image strategy: a main image built around your actual retail box. That option
is simply unavailable to you if the box is not in the folder. Name the files so they read as
packaging, because they get routed separately.

If your product genuinely has no packaging a buyer ever sees, skip it on purpose rather than by
forgetting.

If you do not have the product in hand, put your listing gallery images and customer review photos
here instead, and tell Wonka that is what they are. He records the limitation rather than
pretending the reference is complete.

---

## 4b. Your brand files

```
into 2-reference/brand/
[ ] logo file, brand colors or fonts, an existing brand guide
```

**Empty is a real answer.** If you have no brand files at all, Wonka proposes a complete kit from
your product, your category and your buyer on Day 4. You argue with the proposal rather than
filling in a blank form.

---

## 5. Owner intel. The slot only you can fill

```
into 1-inputs/notes.txt
[ ] What you know that no page shows
```

Not a form, just talk to him. Things worth saying:

- What customers email or message you about, over and over
- What comes back in returns, and the reason they give
- What you tried before that failed, and what you think went wrong
- Your margin room, if it affects what you can promise
- Anything you are legally not allowed to claim
- What you privately believe your product is actually best at

**"I don't have that" is a real answer.** If you are new to the product, or it is not yours,
say so. Wonka records it as none given and proceeds. He never invents it, and he never
quietly pretends he had it.

---

## 6. Optional, if you have it

```
[ ] Brand Registry demographics export  . real buyer age and gender, if you own the brand
[ ] Search term or funnel data          . if you have it in Seller Central
[ ] Returns reasons                     . the single most underused input in ecommerce
```

Skip all three without guilt if you do not have them. Wonka derives an estimated buyer
picture from reviews and competitors and labels it `estimated`, which is honest and good
enough to work from.

---

## The whole thing, in one box

Wonka creates this on Day 1. You fill it.

```
factory/Products/[your-product]/
├── 1-inputs/
│   ├── reviews.txt       ~10 positive, ~10 critical, copied logged in
│   ├── competitors/      3 to 5 URLs plus full gallery screenshots
│   └── notes.txt         owner intel, or a note that there is none
└── 2-reference/
    ├── photos/           the eight product shots + your packaging shots
    └── brand/            logo and brand files, or empty
```

Twenty to thirty minutes of gathering. It is the difference between a factory that guesses
and a factory that knows.

---

*The Wonka Creative Bootcamp. Prepare on Day 1, walk through the gate on Day 2.*

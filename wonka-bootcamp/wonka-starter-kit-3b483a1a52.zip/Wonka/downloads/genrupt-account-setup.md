# Genrupt Account Setup

**Machine 1. The one that makes every image your product.**

Genrupt is the image engine Wonka drives. What makes it worth having a dedicated machine for
is one thing: **it locks your real product.** Generic image models will happily draw a
product that looks a lot like yours, which is the failure that ruins Amazon creative. Genrupt
holds your actual item, so every image the factory makes is your item, not a cousin of it.

**Your Genrupt access is included with your ticket.** You are not buying it separately.

Wonka drives it through an **MCP**, a direct line that lets him operate an outside tool
himself from inside Claude. In practice that means you almost never open the Genrupt website.
You talk to Wonka, and he does it.

---

## Part 1: Create the account

**1.** Use the bootcamp signup link from your welcome email or the portal. **Use that link,
not a general signup**, because it is what attaches your included access to your account.

**2.** Create the account with the email you want the factory tied to.

**3.** Confirm your email.

**4.** Sign in and land on the dashboard. You do not need to build anything here. Look
around for thirty seconds and leave.

---

## Part 2: Connect it to Claude

**Genrupt keeps the official, current connection instructions, and they win over anything
written here.** Tool setup screens change, and a printed value in a PDF goes stale in a way a
click path does not. This page tells you where to click in **Claude**. Genrupt's own docs tell
you the current values to paste.

**Find the current values in one of these places:**
- Your Genrupt dashboard, under **Settings** or **Integrations**, looking for **MCP**,
  **Claude**, or **API access**
- Genrupt's help site
- The pinned Genrupt setup post in the bootcamp portal, which is kept current

**Then, in Claude Desktop:**

**1.** Open **Settings**.

**2.** Find **Connectors** (in some versions, **Extensions** or **MCP**).

**3.** Add a connector and paste in the values from Genrupt's docs.

**4.** Restart Claude Desktop. This step gets skipped constantly and it is usually the reason
a correct setup looks broken.

**5.** Reopen your kit and ask Wonka to run `/machines-check`.

---

## Part 3: Let Wonka verify it

Do not verify by eye. Ask for it:

```
/machines-check
```

Wonka does three things, all free:

1. **A handshake with Genrupt**, confirming the line is actually live rather than merely
   configured
2. **A credit fuel gauge**, reading your Genrupt balance so you always know where you stand
3. **A handshake with OpenAI**, the other machine

A connector that appears in a settings list is not the same as a connector that answers. The
handshake is the proof.

---

## When something goes wrong

| What you see | What to do |
|---|---|
| Connector added, Wonka cannot see it | Restart Claude Desktop. This is the answer most of the time |
| Handshake fails | Reload the Genrupt site in your browser, then retry. The bridge can go stale |
| Says connected, tools do nothing | Check Genrupt's current docs. A required value may have changed |
| Credits show zero | Contact support with your ticket. Access is included, so a zero balance is a mismatch, not a purchase decision |
| Generations come out as the wrong product | Not a connection problem. That is the reference lock, which is Day 4 |

---

## If Genrupt is down or unavailable

The bootcamp does not stop. Wonka has a fallback: he generates directly on OpenAI's image
model using the key you already set up in Part 2 of the other guide.

**What it costs you:** product reference accuracy is meaningfully lower. Without the lock,
the model works from description rather than from your actual item, and the look alike
problem comes back.

**What Wonka does about it:** he marks it honestly in your files rather than quietly
producing weaker images and calling them the same thing. Every day except Day 7 remains doable on the fallback path. The A+ Room has no fallback:
A+ is hands-off by design, Genrupt authors the page, and there is no second engine to hand that
to. If Genrupt is out on Day 7, that room stays shut until it is back.

---

## The checklist

```
[ ] Account created using the bootcamp link
[ ] Email confirmed
[ ] Connector added in Claude, values from Genrupt's current docs
[ ] Claude Desktop restarted
[ ] /machines-check run
[ ] Genrupt handshake passed
[ ] Credit balance visible
```

Two machines, both green, and the factory is open.

---

*The Wonka Creative Bootcamp. Day 1, The Front Gate.*

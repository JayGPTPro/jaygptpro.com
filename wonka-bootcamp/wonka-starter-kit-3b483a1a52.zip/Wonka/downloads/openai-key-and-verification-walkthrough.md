# The OpenAI Key and Organization Verification

**Every click, in order.**

This is one of the two machines your factory runs on. One key powers four rooms: the Main Image Room's OpenAI Blast on Day 5, the Variations Room's edits on Day 9, the Fixing
Room, where surgical image edits cost cents, and the Tasting Room, where a panel of about 100
AI tasters judges your images for a few dollars a race.

**Do this on Day 1, not later.** One step in here can make you wait, and if you skip it you
find out on Day 5 in the middle of your main image batch. That is the single most common way
a bootcamp week gets derailed.

---

## Part 1: Create the account and the key

**1.** Go to **platform.openai.com** and sign in, or create an account.

This is the API platform. It is a different thing from a ChatGPT Plus subscription, and
paying for ChatGPT does not give you API access. If you already have ChatGPT, you still need
this.

**2.** Click your profile icon, top right, then **View API keys**. Or go straight to
**platform.openai.com/api-keys**.

**3.** Click **Create new secret key**.

**4.** Name it something you will recognise later. `wonka-factory` works.

**5.** Click **Create secret key**.

**6.** **Copy it now.** It starts with `sk-` and it is shown exactly once. Close that box
without copying and the key is gone forever, and you make a new one.

**7.** Paste it somewhere safe immediately. A password manager is right. A sticky note on
your monitor is not.

> **The one rule that matters.** Never paste your key into a chat window, never put it in a
> screenshot, and never read it out loud on a recording. If you ever think a key leaked, go
> back to the API keys page, revoke it, and make a new one. It takes thirty seconds and costs
> nothing.

---

## Part 2: Organization verification. The step that makes you wait

**This is the step people skip, and it is the expensive one.** OpenAI requires a one time
identity verification before its image models will work for you. Your key can talk to text
models immediately, but it cannot draw until this clears.

**1.** Go to **platform.openai.com/settings/organization/general**.

**2.** Look for **Verify Organization** and start it.

**3.** You will be asked for a government ID and a live selfie check. It runs through a
verification provider and takes a few minutes of your time.

**4.** Approval is usually quick, sometimes minutes. It is not always instant, which is
exactly why this happens on Day 1 and not on Day 5.

**5.** When it clears, image models unlock on your key automatically. Nothing else to do.

> **How you know it worked:** Day 1 ends with First Candy, a deliberately tiny print that
> costs about one cent and exists for exactly one reason: to prove, on camera, on Day 1, that
> your key can actually generate an image. If First Candy prints, your setup is real. If it
> errors, you found out on the cheapest possible day.

---

## Part 3: Add credit

**1.** Go to **platform.openai.com/settings/organization/billing**.

**2.** Add a payment method.

**3.** Load **$10 to $20** to start.

**Why that number.** The bootcamp runs **two Tasting Room races**, both on Day 8 in one sitting: your main
images face the panel, then your gallery does. An optional second round runs the same day, and
only when a change was big enough to be a different image.
Add the image edits across Days 5 to 7 and $10 to $20 covers a full product comfortably. It
is usage based, so whatever you do not spend stays yours.

**4.** Optional but sensible: set a **usage limit** on the same page. It is a hard ceiling
that protects you from a runaway loop. $30 is a reasonable place to put it.

---

## Part 4: Give the key to Wonka

Put the key where the kit expects it. Wonka walks you through this on Day 1, and
`/machines-check` confirms it.

Wonka will never print your key back to you. When he checks it, he reports only that it is
present, how many characters it is, and its last four. That is deliberate: Day 1 is a lesson
you may well be screen recording yourself, and a key on screen is a key in the world.

---

## When something goes wrong

| What you see | What it means | What to do |
|---|---|---|
| `401 Incorrect API key` | The key is wrong, or has a stray space or line break | Re-copy it. Check for a trailing space |
| `403` or a model access error on an image call | Organization verification has not cleared | Go back to Part 2. This is the usual answer |
| `429 insufficient_quota` | No credit on the account | Part 3. Note this is different from a rate limit |
| `429 rate limit` | Too many calls too fast | Wait a minute and retry. Nothing is broken |
| First Candy fails on Day 1 | Almost always verification, occasionally credit | Work through Part 2, then Part 3 |
| The key works for text but not images | Verification. Every time | Part 2 |

---

## The checklist

```
[ ] Account created at platform.openai.com
[ ] Secret key created and saved somewhere safe
[ ] Organization verification STARTED on Day 1
[ ] Verification cleared
[ ] $10 to $20 of credit loaded
[ ] Optional: usage limit set
[ ] Key handed to Wonka
[ ] /machines-check passed
[ ] First Candy printed
```

When First Candy prints, this machine is done and you never think about it again.

---

*The Wonka Creative Bootcamp. Day 1, The Front Gate.*

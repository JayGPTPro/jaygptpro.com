---
name: inspect
description: The mandatory QA gate between image generation and the human's pick. Runs on a stated SCOPE (main, secondary, listing, A+, variations, or the whole package), opens every in-scope image with vision, scores 6 dimensions including a structure-and-assembly read of every product instance at full size and magnified, runs the mechanical mobile squint test at 160 pixels, applies the compliance gate, ranks variants on execution quality, and runs the routine fixes through /fix under the routine-fix policy before the user ever sees the set. Use after /main-image, /secondary-images, /aplus, /variations, or /fix, or when the user asks to review, score, QA, grade, or rank images. Triggers: /inspect, "inspect only my shortlist", "inspect the images", "inspect the secondary set", "inspect scoped to the A+", "QA these", "score the set", "which image is best", "review what we generated".
---

# The Inspection Room

| Meta | Value |
|------|-------|
| Room | The Inspection Room |
| Station | INSPECT |
| Taught | Day 5, in one piece. Re-run on Day 6 (a whole set), Day 7 (a whole page), Day 8 (fixes and challengers), Day 9 (the variation family) |
| Needs | The in-scope images, plus `brief/creative-brief.md`, `2-reference/reference-sheet.md`, `status.md` (the brand and logo rows), `factory/Brand/brand-kit.md` when one exists, `research/persona.md`, `research/selling-points.md` |
| Saves to | factory/Products/[product]/scorecards/scorecard-[scope]-[YYYY-MM-DD]-[run].md + scorecards/squint/[scope]-[YYYY-MM-DD]-[run]/ (one folder per run) + scorecards/magnify/[scope]-[YYYY-MM-DD]-[run]/ (the 2x and 3x crops the structure read was made on) |
| Run id | `[run]` is a per-run counter (`r1`, `r2`...), the next unused one for that scope and day; two inspections on one day never share a folder, a scorecard or a squint count |
| Writes | ONLY inside `scorecards/`. Never renames, moves, overwrites or deletes an image, a batch log, or an earlier scorecard |
| Typical cost | Free to inspect. Routine fixes run through /fix at cents per edit on a report, inside the limits of CLAUDE.md's routine-fix policy |

## What this room does

Nothing leaves the Factory without passing this room. Every in-scope image is opened with vision, described literally, scored, checked against the compliance avoid-list, and force-ranked against its sibling variants. Verified, fixable defects are REPAIRED before the user sees anything (the routine-fix policy in CLAUDE.md is the one source for the route, the spend and the stops), so the human's job is to pick winners, never to discover defects. A defect the owner finds anyway enters the same route, and the answer is never a different image.

Two things this room is not. It does not pick the winner: the ranking is EXECUTION QUALITY, the tasters decide conversion in the Tasting Room. And it does not generate or edit: it names the defect and the route, then the generation rooms or the Fixing Room do the work.

Different asset classes are judged differently. Do NOT apply the listing-image set rules (no people in a main, one emotional frame, no repeated face) blindly to A+ or variations. Each class has its own checklist in step 8.

## Step 0. State the SCOPE, out loud, before anything else

A run always covers ONE scope. Naming it is what stops this room flagging an empty A+ folder as a defect on Day 5 and what stops the Day 6 scorecard landing on top of the Day 5 one.

| Scope | Folders read (ALWAYS resolved per class through the highest `edits/vN/` first, per step 1; the folders below are the originals when no round exists) | Set-level checklist | Usually |
|---|---|---|---|
| `shortlist` | ONLY the candidates the owner shortlisted: the files in `images/pick/shortlist/` (the numbers they named, copied there by `/main-image` step 8; `images/pick/INDEX.md` maps each number to its source), resolved to their `images/` originals or their latest `edits/vN/` copy | listing-set (mains only) | **Day 5, the default whenever a pick folder exists.** The owner never pays for a verdict on candidates they already passed over (Jay, 6 September 2026) |
| `main` | `images/` main-* plus `vanilla-control.png` when it exists (opened and read for drift, marked `diagnostic, not a candidate`, never ranked or gated as one) | listing-set (mains only: no duplicate bets) | only when the owner asks for every main on disk |
| `secondary` | `images/` sec-* only | listing-set, full | Day 6 |
| `listing` | `images/` all | listing-set, full | after both are built |
| `aplus` | the EXPORTED modules in `aplus/export/[mode]/` (the files that go to Amazon, landed at the pick by `/aplus` step 7), resolved to their adopted copies in `edits/vN/aplus/` when a fix round exists, plus the stacked page `aplus_page.py` built on that folder; `aplus/m*.png` are the same modules as generated, never a second set to score | A+ page checks | Day 7 |
| `variations` | `variations/` | variation family checks | Day 9 |
| `package` | all three folders | all three checklists, kept separate | a full sweep |

1. Take the scope from what the user asked ("inspect only my shortlisted candidates" is `shortlist`; "inspect the secondary set", "scoped to the A+ modules"). On Day 5, when `images/pick/` exists, the scope is `shortlist` unless the owner asks for more; with no pick folder, ask for the numbers in one line. If they did not say, infer it from the INVENT sub-status in `status.md`: the sub-part that just went to `done` and has no scorecard yet. If two are equally plausible, ASK in one line rather than guessing wide.
2. ECHO it back before spending any effort: "Scope: the secondary set, 7 files in images/. The mains, their scorecard and the A+ are out of scope and stay untouched."
3. Folders outside the scope are NOT gaps and are NOT flagged. Write them as `out of scope this run`.
4. Inside the scope, an empty folder IS reported: either as a recorded conscious skip in the INVENT sub-status (`Variations: n/a (single SKU)`), or as the lawful trailing marker `Variations: pending (Day 9)`, which blocks nothing here (the Shipping Room is the one room it holds), or as a real gap that needs the generation room first.

If the scope holds no image files at all, the room is closed: name the generation room that fills it (`/main-image`, `/secondary-images`, `/aplus`, `/variations`) and stop. That is the only hard block in this room.

## Before you start. Inputs, and what happens when one is missing

Ask for every input once. **"I don't have it" is a real answer and the run PROCEEDS**, in DEGRADED mode with the gap written into the scorecard header. What never happens is a dimension being invented to fill a hole, or a degraded run being called `done`.

| Input | If present | If missing or "I don't have it" |
|---|---|---|
| `brief/creative-brief.md` | Every image is judged against the JOB its slot, module or child was assigned | Say what it costs, offer `/creative-brief`, then proceed DEGRADED: **message clarity and selling-points coverage are recorded `UNSCORED (no brief)`**, never guessed. Craft, legibility, product accuracy, brand fit and the compliance gate all still run |
| `2-reference/reference-sheet.md` + the photos in `2-reference/photos/` | Product accuracy is judged against it, never against memory. Note whether it records `source: manual` or `source: amazon_scraped` | Fall back, in order: the reference photos on disk, then the listing gallery images. Nothing at all means product accuracy is `UNVERIFIED (no reference)` and the run is DEGRADED. Never score fidelity from memory of the category |
| `factory/Brand/brand-kit.md` | Brand fit scored against its colors, fonts and tone | Score brand fit by what the product actually has, from `status.md` (see the three states below). Not a deduction, not an invented standard |
| `status.md` (`Logo source`, `Genrupt preset ID`, `Logo in preset`) | Tells you which brand-fit state applies, and whether a real logo asset exists to compare a rendered logo against | No logo and no styling: brand fit is scored as `no brand system`, at no penalty |
| `research/persona.md` | Casting judged against the real buyer age plus the aspirational display skew | Casting judged on authenticity and craft only; the age-skew check is recorded `unverifiable (no persona)` |
| `research/selling-points.md` | The coverage walk in step 8 uses its IDs | Fall back to the brief's coverage map. Neither on file means coverage is `UNSCORED`, stated plainly |
| `incumbent/` (the live main and gallery; `/tasting-room` fills it at the opening of Day 8) | The distinctiveness read in step 6 runs | Record `no incumbent on file`, silently on Days 5 to 7: it is nobody's gap before Day 8 |
| A downscaling tool (`sips`, ImageMagick, or Python Pillow) | The squint test runs mechanically | See step 4. Legibility becomes `UNVERIFIED` for every image and the run is DEGRADED. It is never eyeballed at full size instead |

A DEGRADED run still produces a full scorecard, still gates compliance, and still ranks. It just carries a header banner naming every gap, and INSPECT stays `in progress` in `status.md` until the gap is filled.

## Process

1. **Inventory the scope.** List the actual files on disk in the in-scope folders (run the listing, do not recall it), including `-vN` regenerations. Then check `edits/`: a file's CURRENT version is its ADOPTED copy, the same filename in the newest round that holds it (surgical edits keep the filename; the round lives in the folder name; the round's `round.md` lists where each copy came from). A file no round holds is current in its originals folder, which is normal for anything generated after the last round. `-rejected` and `-render` files inside a round are evidence, never candidates. Inventory the adopted copies alongside the originals. **Resolve PER CLASS, the Fixing Room's own rule:** main and gallery files sit at the top of `edits/vN/`; A+ modules sit in `edits/vN/aplus/` and variation imagery in `edits/vN/variations/`, in the highest round that CONTAINS that subfolder (a fix round does not touch every class). Looking for an A+ module at `edits/vN/m3.png` finds nothing and silently scores the superseded original in `aplus/`. Group each file by ASSET CLASS:
   - **Main image**: `images/main-*.png`. Product-only hero.
   - **Secondary image**: `images/sec-*.png`. Benefit, proof, lifestyle, scale.
   - **A+ module**: `aplus/export/[mode]/` (the exported, upload-ready cut), or its adopted copy in `edits/vN/aplus/`. One Enhanced Brand Content module. `aplus/m*.png` is the same module as generated; score the export, because that is the file `/fix` edits and Amazon receives.
   - **Variation main**: `variations/main-[child].png`. A per-child hero.
   - **Variation swatch**: `variations/swatch-[child].png`. The tiny variation-picker chip.
   - **Variation propagated frame**: `variations/[slot]-[child].png` (e.g. `pt03-round-10in.png`). A gallery frame the frame table marked variant-carrying, edited for this child. Judge it as a secondary image AND against this child's truth-table row in `variations/variations-plan.md`: the printed count, size and claims must be this child's, not the source's.
   Always write the file path folder-first (`images/main-01.png`, `variations/main-amber.png`); the two `main-*` families live in different folders and must never be confused. Group variants of one slot, module or child together using the filenames plus `images/batch-log.md`, `aplus/aplus-plan.md` and `variations/variations-plan.md`.

2. **Resolve the LINEAGES.** For each slot, module or child, order its files by version: original, then `-v2` regenerations, then the same filename's adopted copy, in the newest `edits/vN/` round folder that holds that file (for an A+ module: the round `aplus-plan.md`'s chosen line names, else the newest round whose `edits/vN/aplus/lineage.md` matches the export on disk, else the export; a round with no lineage record is never current, and `face_fix.aplus_adopted_set()` is the rule in code) (top level for main and gallery, `edits/vN/aplus/` for A+ modules, `edits/vN/variations/` for variation imagery; the Fixing Room's surgical edits keep the name, `-v2` included, so `sec-03-v2.png` and its fixed copy are one lineage; the round lives in the folder). **Only the LATEST file in a lineage is a rankable candidate.** Score every file you opened, but mark superseded parents `superseded by [file]` and never put one on the candidate list. This is what keeps the room aligned with the Fixing Room, where a passing fix replaces its parent in the ranking.

3. **Open EVERY in-scope image with vision, at full size AND magnified.** Use Read on each file. No image is scored unseen. For each one, write a 1 to 2 line LITERAL description first: product, text you can actually read, people, props, background, and HOW THE PRODUCT IS BUILT in this frame (which parts sit where, on what, how many instances of the product the frame holds). Then write the magnified crops and open them: `python3 .claude/skills/inspect/magnify.py [file] scorecards/magnify/[scope]-[YYYY-MM-DD]-[run]/` gives four quadrant crops at 2x with no boxes; with one box per product instance (`x,y,w,h` in source pixels) it gives each instance at 3x plus a side-by-side strip of the instances at the same scale, which is the file the structure read in step 6 is made on. A frame with two products in it gets two boxes. The description and the crops are the evidence. If you cannot honestly describe it, you have not looked at it, and a score written without it is a fabrication.

4. **Run the mechanical squint test on every in-scope image, and read it at the class's REAL display size too.** The squint copy answers ONE question, legibility: full-size eyeballing is forbidden for legibility because small text always looks fine at full size. It answers nothing about accuracy: a column an eighth of a bowl off its axis is invisible at 160 pixels and plain at 3x, so the squint read is never evidence for a product-accuracy score (measured 7 September 2026). **But 160 pixels is calibrated for a LISTING image**, which a shopper meets as a thumbnail in a row of rivals. **Nobody ever sees an A+ module at 160 pixels**: it renders at Amazon's column width on desktop and at phone width on mobile. Run mechanically on an A+, the 160 test marks every bullet on every desktop module "dissolved", which is true and useless (measured 27 August 2026). So on A+ and variation swatches, run BOTH and say which one decides: the 160 copy stays, because it is an excellent read of the HEADLINE hierarchy and it is what made a duplicated headline jump out of a page, and the verdict on body text comes from a second copy at the class's real display width (a swatch is judged at picker size, about 60 pixels). Name the deciding read in the scorecard. Write a real 160 pixel copy to disk and READ THAT COPY. Resample by WIDTH, from the kit root:
   ```bash
   mkdir -p "factory/Products/[product]/scorecards/squint/[scope]-[YYYY-MM-DD]-[run]"
   # macOS
   sips --resampleWidth 160 "factory/Products/[product]/images/main-01.png" --out "factory/Products/[product]/scorecards/squint/[scope]-[YYYY-MM-DD]-[run]/main-01-160.png"
   # Windows or Linux, ImageMagick
   magick "factory/Products/[product]/images/main-01.png" -resize 160x "factory/Products/[product]/scorecards/squint/[scope]-[YYYY-MM-DD]-[run]/main-01-160.png"
   # last resort, Python with Pillow
   python3 -c "from PIL import Image; i=Image.open('IN'); i.resize((160,round(i.height*160/i.width))).save('OUT')"
   ```
   **While you have the file open, record its REAL pixel size on the card too**, in the `Size:` line of that image's verdict block. One command reads the whole scope at once:
   ```bash
   python3 -c "
import pathlib,sys
from PIL import Image
for p in sorted(pathlib.Path(sys.argv[1]).rglob('*')):
    if p.suffix.lower() in {'.png','.jpg','.jpeg','.webp'}:
        w,h=Image.open(p).size
        print(f'{p.name:34} {w}x{h}' + ('  <-- under 1000' if max(w,h)<1000 else ''))
" "factory/Products/[product]/images"
   ```
   No Pillow and no other tool: write `size: UNMEASURED` on each card rather than guessing from the file size, and say so once in the run status.
 One line per image, it costs nothing, and it is the only early warning for a defect no eye catches: Amazon opens zoom at 1000 pixels on the longest side and rewards 1600 and up, while a surgical edit returns the endpoint's working size rather than the source's. So an edited file is usually the smallest in an otherwise full-resolution set. Note anything under 1000 as a flag on the card, and note plainly when one image in a set is markedly smaller than its neighbours. This is a REPORT, not a FAIL: resolution is fixed at packaging, where the Shipping Room measures again and offers the upscale. Silence here is what lets a 1024 hero reach a listing beside a 2000 gallery.

   Then open the 160 pixel copy with Read and record VERBATIM which words survive and which dissolve.
   - Pass on a text-bearing image: the one dominant message reads in under 2 seconds at that size. The ~3.5%-of-short-edge size floor and a real ink-to-background contrast are BOTH necessary, and neither is sufficient: measured on real tags, a 3.9% dark-brown-on-kraft line dissolved at 160px while a 3.2% white-on-black line read cleanly, so contrast decides as often as size does. **The actual 160px read outranks both numbers**: what you can read on the squint copy is the verdict, and the size and contrast notes explain WHY it passed or failed, never overturn what the read showed.
   - Pass on a MAIN or a variation main (no overlay text by law): at 160 pixels you can still tell WHAT the product is, HOW BIG it is, and WHAT IT IS MADE OF. If the product reads as an unidentifiable shape, legibility fails even with zero text on it.
   - Pass on a swatch: the chip reads as its intended color, size or scent at thumbnail scale. A swatch that fails this has failed its entire job.
   - **If none of the three tools exists**, say so in one line, tell the user what to install, mark legibility `UNVERIFIED` on every card, and run the rest of the inspection. Never substitute a full-size judgment and never claim a squint test that did not happen.

5. **Verify the squint copies exist, mechanically.** Count THIS run's folder, never the whole squint tree:
   ```bash
   ls "factory/Products/[product]/scorecards/squint/[scope]-[YYYY-MM-DD]-[run]/" | wc -l
   ```
   **The per-run folder is what makes this check survive a second inspection.** Squint copies accumulate: a flat folder holding five copies from an earlier run can never equal the two images in scope when `/fix` sends two back today, so the gate would be unsatisfiable from the second run onward and the only way to "pass" would be to stop believing it. One folder per run, counted on its own.
   The count must equal the number of in-scope images. If it does not, the missing images were not squint tested: go back and do them. A legibility score with no file behind it is worth nothing, and this line is the proof that it happened.

6. **Score 6 dimensions, 1 to 5 each, asset-class-aware.**
   - **Message clarity**: one dominant message, and it matches the JOB the brief assigned this image. Two competing headlines, or an off-brief message, caps this at 2. On a MAIN or a variation main there is no overlay message by law, so this scores the CATEGORY READ instead: at thumbnail size, does a shopper instantly know what this product is.
   - **Legibility**: from the step 4 result ONLY. If the dominant message failed at 160 pixels, this is 1 or 2 no matter how it looked at full size.
   - **Product accuracy**: matches the Reference Sheet. Correct size, shape, label, colors, material and PART COUNT, every part the spec lists present and countable (a four tier fountain shows all FOUR tiers; a stainless base reads as brushed metal and not grey plastic; glass reads as translucent glass and not opaque plastic). A beautiful image of the wrong product scores 1. **And every NUMBER rendered on the image is product accuracy too**: a printed dimension, capacity, count, weight, voltage or percentage is transcribed off the frame and checked against the Reference Sheet's spec table, the approved brief and the owner's own listing; the card's `Facts:` line names each value and its source, or `UNSOURCED`. A number no source of ours states caps product accuracy at 2 and routes to `/fix` as a word swap once the true figure is sourced (never to a guess), whatever the rest of the frame looks like. Measured 7 September 2026: a clean, legible dimensions frame printed `8.5" BASE` on a product whose own listing table says 8 inches, and the number had come from a competitor's frame. A beautiful wrong number is a product-accuracy failure, not a marketing note, and this check does not wait for the compliance gate. **And STRUCTURE AND ASSEMBLY, read on the magnified crops from step 3, never on the squint copy**: where each part sits relative to the others, the joints where they meet, the proportions between them, the alignment of parts that share an axis on the real product, and the continuity of a part that passes behind or through another. On a fountain: the column rises from the centre of the bowl and the base on one axis, every tier is centred on that column, and the column is one continuous piece through the tiers it passes. A part the real product has in one place that this frame has in another is a structure defect, a blocking flag, and it is written on the card as what the real product has versus what the frame shows. This is not a symmetry rule: a product that is asymmetric by design is checked against the references, not against a mirror. **And it is triggered by the product's anatomy, not run on every product in the universe**: the relational read (a shared axis, coaxial parts, attachment points, part-to-part alignment, the symmetry the real product has) is done wherever the Reference Sheet shows parts that stack, nest, hinge, screw or align on a line, a fountain, a lamp, a stacked container, a tool with a handle and a head; a flat pouch or a single moulded object gets the ordinary part-and-material read and no centreline measurement. **Every INSTANCE of the product in the frame is read on its own, and the instances are then compared on the side-by-side strip**: two machines in one frame must agree on structure, allowing for angle and working state (one running, one loaded). Measured 7 September 2026: a two-machine frame scored 5/5 while the left column ran off the axis of its bowl and base, because the read stopped at the part count and never compared the two. **A score is written only for what was verified, with the evidence named** (`verified: 3x crops, both instances compared`); a dimension that could not be verified says `not verified: [why]` rather than carrying a 5. **The evidence bar is the same for a pass and a fail**: a 5 needs the magnified read as much as a 1 does. The list above is a floor, not a checklist of past defects; a defect of a kind never seen before is still a defect. **Counting is done by EYE at zoom; an automated count that disagrees with the zoom look is discarded, with the reason named** (measured 27 August 2026, twice in one day: a glossy finish puts a highlight strip down each handle and a pixel counter reads every handle as two, returning 14 and 17 on a true 12). **The accuracy check covers EVERY depiction of the product in the frame, not just the hero**: an inset, a corner panel, a before/after thumbnail, a product shown in use behind the main subject. A wrong form ANYWHERE in the frame is a blocking flag, never a minor note because the wrong bit is small. Small is where this defect hides, and "it is only the inset" is exactly the reasoning that ships it. On variations, the product also has to stay consistent with its siblings; only the varying attribute may differ.
   - **Brand fit**: score it against what this product actually has, read from `status.md`. Three states, and they are not the same standard:
     1. **A full Brand Book or Style Guide on file** (`Brand kit` names a kit): score colors, fonts and tone against it. A font that fights the brand look is a real deduction, not a nitpick.
     2. **A logo-only preset** (`Genrupt preset ID` set, `Brand kit: none`): there is no palette or typography to be judged against. Score only logo handling and overall coherence. **A logo-only product is never penalized for lacking a brand system**, because it does not have one and was never asked to.
     3. **No styling and no logo** (`Genrupt preset ID: none`): score brand fit as `no brand system`. Not a deduction, and never an invented standard.
   - **Any logo actually rendered in an image is verified against the supplied asset** at `Logo source`. Open both and compare. FAIL a logo that is distorted, misspelled, invented, duplicated, or placed where the rules do not allow it. **And a graphic logo added to the Amazon MAIN image is an automatic fail on the house list, whatever it looks like.** A logo physically printed on the real product is product truth: it belongs there, and it is checked for accuracy, not removed. If `Logo source` reads `none provided` and a graphic logo appears that is NOT on the real product in the reference photos and the sheet, the machine invented it: automatic fail. A logo that the product photos show printed on the product is product truth even when no separate logo file was supplied: check it for accuracy against the photos, never remove it.
   - **Craft**: no AI artifacts, no garbled or misspelled text, no wrong hands or melted objects, clean edges, believable lighting.
   - **Source honesty**: an image generated from a Genrupt `alternateCreativeBrief` (the machine's own unreviewed scene text) is flagged `source: unbriefed alternate` and its every written or implied claim gets the promise check an A+ module gets, because no human reviewed the text it grew from. The brief's slots are the only pre-reviewed sources.
   - **Casting** (people-bearing images only, otherwise `null`). TWO mechanical steps come BEFORE the judgement, and both exist because a careful look failed twice on the same set:

     **(a) Run the cast screen on the whole scope first**, before opening anything:
     `python3 .claude/skills/inspect/cast_check.py <folder>`. Read the `neutral` column. A frame
     under 5 percent neutral has no white anywhere in it, so there is nothing for skin to be
     anchored against and skin drifts to whatever the grade says. Measured on a real A+ page: the
     hero module came back at 1 percent neutral with a ONE degree hue spread across forehead,
     cheek, nose and jaw, its subject's teeth were not white, and a bride's dress in another
     module was not white either. It reads to a viewer as fake tan and heavy makeup. Two passes
     by eye had called that page clean, because an eye adapts to a grade within seconds and then
     reads it as lighting. **When the screen says CAST, the defect is the GRADE and the fix is the grade.
     Never send a cast frame to a face pass:** correcting people inside an orange room leaves them
     not matching their own room, which looks worse than the original.

     **(b) Then open each face at 3x or better**, cropped to the face alone. A face inside a 1464px
     module is 250px; viewing the module, even at native resolution, is not viewing the face. The
     first pass on that same A+ zoomed the module and missed a specular sheen on forehead, nose and
     cheekbone plus a uniform skin tone with no variation between regions.

     Only then judge: the displayed person matches the persona's aspirational display age and looks like a real human being. In the LISTING set the person must also be a DIFFERENT person from every other people-bearing listing image. A+ people are judged on authenticity and age-fit only; the different-person rule is scoped to the listing set.
     **The people-realism check, conditional and named.** Most generated people pass; this check exists for the ones that do not, and it names WHICH of three failure signatures it sees, because each routes differently:
     - **Signature A, doll face** (geometry and expression): too-perfect symmetric features, uniform flawless teeth, glassy eyes, everyone in frame at identical peak expression. Shows up even when lighting and color are believable.
     - **Signature B, waxy skin + uniform tone**: zero micro-texture (no pores, one smooth gradient), and every person the same peach-orange tone matching the design palette instead of varying per person.
     - **Signature C, the filter layer**: a diffusion/bloom glow like a beauty filter, highlights smearing on forehead and cheekbones, warm light patches painted on with no single consistent light direction.
     A clean image is left alone. A flagged one records its signature letters in the verdict and routes to the Face Clinic engine (`/fix-faces`, run inside the fix round at `high`: faces replaced, head boxes composited back, one pass covers all three signatures) or to regeneration when the composition itself is also wrong. Faces are never "enhanced" speculatively; no signature, no touch.

   **Asset-class notes:**
   - **Main image**: product-only. Weight product accuracy, craft and the category read. If `incumbent/` holds the live main, open it once and add a one-line DISTINCTIVENESS read per candidate at 160 pixels: does this stand apart from the incumbent, or is it the same picture in a new coat. If every candidate reads as a near-copy of the incumbent, flag the SET, because no panel can rescue four versions of what is already live. This read is diagnostic and feeds Day 8. **It is never a winner call.**
   - **Secondary image**: full 6-dimension scoring.
   - **A+ module**: NO incumbent exists (A+ is not A/B tested), so never down-score a module for lacking one. People ARE allowed in A+; it sits below the gallery. Judge module clarity, legibility, compliance, brand fit, craft and product accuracy.
   - **Variation main**: judged exactly like the parent main, including its tactic (hands under human-contact stay).
   - **Variation swatch**: tiny-size legibility plus consistency with the Reference Sheet and its siblings. A swatch legitimately REPEATS the product; that is its job. Never flag a swatch for repetition or for matching its siblings.

7. **Apply the COMPLIANCE GATE. Pass or fail, no partial credit, no score buys it back.**
   The gate reads THREE lists, and the second and third are the ones this step used to skip:
   1. **The house avoid-list** (below).
   2. **This product's own must-avoid list**, from `status.md` and the brief's compliance section. An image that depicts or implies exactly what the owner's research forbade (an over-promising flow, a use the reviews punish) is flagged even when every house rule passes. A must-avoid hit is recorded as an **OWNER-AVOID FLAG**, surfaced and carried forward on the card rather than an automatic pull, because the owner may knowingly keep one (a like-for-like challenger against an over-promising incumbent is the legitimate case). The flag rides into the Tasting Room notes so the verdict is read with the question already in view.
   3. **The brand kit's approved-claims table.** Every claim rendered ON an image (a benefit lockup, a callout, a badge-shaped promise) must trace to a row in `factory/Brand/brand-kit.md`'s approved-claims table when a brand kit exists, to text physically on the real label, or to a fact verified in the reference record or the product listing and carried in the approved brief. A product without a Brand Book is judged on those verified sources; the absence of a kit never strips a true fact or reopens an approval the owner already gave. A claim with no row is flagged and routed to a surgical removal or to the OWNER as a claims decision (approve it into the table, or strip it), never waved through because it is small or plausibly true. This catches the case the house list structurally cannot: a slot brief that authored a stronger claim than the brand approved, which then renders as a confident lockup nobody signed.
   EVERY image, every class, FAILS on the house list if it contains any of: medical or disease claims, invented percentages or statistics, star ratings or review references, fake badges or awards, third-party logos rendered as graphics, flag graphics, **and any third-party intellectual property the product itself does not carry** (a recognisable character, costume, franchise figure or trademarked design; measured 27 August 2026 on a main-image blast that rendered a figure reading as a well-known armoured game character). Real certifications the product genuinely carries, as they appear on the real label, are allowed. **An invented certification, approval seal or award emblem is a FAIL at ANY size, including one rendered small onto the packaging inside the shot.** It is routed to a surgical-edit removal, never downgraded to a minor note for being tiny: Amazon reads the pixels, not the intent, and a fabricated seal is a suppression risk rather than a style problem.
   **MAIN-only gate** (listing mains and variation mains): additionally FAILS on a hand, a person or a face UNLESS the owner enabled the human-contact tactic in the brief (then people are lawful and are judged for realism under Craft and Casting instead; a face on the main is the brief's recommendation against, never a gate); and on ANY overlay text or graphic, meaning anything not physically printed on the product, its label, or the approved hang-tag. Variation mains are judged under the same tactic as the parent main, no stricter and no looser. This does NOT apply to secondaries, A+ modules (people and overlay copy are welcome) or swatches. **Props, contents, ingredients, accessories, a physical tag and the real box are lawful on a main and are never flagged.** And the gate is Wonka's machinery: a violation is named on the card and pulled; the owner is never lectured about Amazon's policy, never told a tactic is risky, and never steered toward the safest candidate (house doctrine: the tactics are the strategy, and the backup on disk covers the downside).
   A FAIL sinks the image to the bottom of its group regardless of scores, names the exact violation, and may not be presented as a candidate until it is fixed.

8. **Run the set-level checks, PER asset class.** Never pool the classes; a swatch repeating the product and an A+ module reusing a face are not defects.

   **LISTING set** (`images/`):
   - Duplicate messages: no two listing images carry the same headline or make the same point. Name any pair. On a `main`-only scope this reads as: no two concepts are the same BET in different decoration.
   - Emotional frame: at least one emotional or lifestyle frame exists in the secondary set. Flag if missing.
   - Repeated face: the same person may not appear twice. A repeat routes UPSTREAM to a distinct custom avatar with an explicit age and gender, then a re-run of that one slot through `/secondary-images`. Never a brief paragraph, never an edit.
   - Selling-points coverage, walked through FOUR stages, not two: `research/selling-points.md` ID by ID, then the brief's coverage map (which slot the brief gave it), then the SAVED PLAN (the latest `brief/plan-parity-[date].md` from `/secondary-images`, or a fresh plan read-back: which plan slot actually carries that job), then the files on disk (which file is that slot's). Each point is covered by a named image or was consciously skipped IN WRITING. A point that vanished at ANY stage is a flag, and the stage names the route: missing from the brief goes to `/creative-brief`; present in the brief and missing from the plan is the parity failure, a plan repair and a regeneration through `/secondary-images`; present in the plan and missing on disk is a download owed. Measured 7 September 2026: a two-stage walk (selling point to image) read a set of eight good files as complete while the brief's S4 job had never reached the plan; the middle stage is what would have caught it before the set looked finished.

   **A+ page** (`aplus/`). A page is judged as a scroll, not a grid:
   - Module ORDER: the page reads hero to trust, in a deliberate order, and no module is stranded.
   - One message each: no two modules share a headline; each has a single dominant job.
   - Extends, does not repeat: the A+ adds to the gallery rather than re-serving it. Say which modules earn their place.
   - Comparison honest: every comparison row is true, provable and about our own product. No named competitor brands, no prices, no invented wins.

   **Variation family** (`variations/`):
   - Reads as siblings: shared angle, lighting and background family, consistent with the Reference Sheet. Only the target attribute varies.
   - True counts per child: the part count and proportions are right in every child, not just the first one.
   - Correct labeling: each main and swatch is tagged to a REAL child, and the swatch reads as that child's attribute at tiny size.

9. **Rank each group 1..N on EXECUTION QUALITY, where a group HAS more than one candidate.** In practice that is the `shortlist` and `main` scopes: secondaries, A+ modules and variation children carry exactly ONE candidate per slot by their own rooms' rules, so those scopes record the scores and write `one candidate per slot, nothing to rank` instead of inventing a cross-slot ranking of six different jobs. Per listing slot, per A+ module, per variation child, over the rankable candidates from step 2. Compliance passes always rank above compliance fails. Among passes, rank by total score, tie-broken in this order: legibility, then product accuracy, then message clarity. Write the tie-break down whenever it was used.
   **What the ranking is not:** it is not a prediction of what converts, and it never eliminates anything. Four main concepts are four different BETS. A bet does not lose because its execution ranked third; it loses in the Tasting Room, to the tasters, on Day 8. Every gate-passed candidate advances. If a bet is genuinely unbuildable, say that in words instead of quietly dropping it off the list.

10. **Escalate the two failures that no single edit can fix.**
    - **Fidelity:** if MORE THAN ONE image in a batch scores 2 or below on product accuracy **AND the failures span more than one CONCEPT or generation source**, stop routing them one at a time. That is a reference problem wearing an image problem's clothes: send the user to `/reference-sheet` for a re-lock and a fresh smoke test BEFORE any regeneration is paid for. **Failures confined to ONE concept are that concept drifting, not the mold**, and a session that escalates on them pays for a re-lock that could not have fixed anything (measured 27 August 2026: four mobile modules scored 2 on wrong metal while the SAME sheet, same id, same call rendered correct metal on all seven desktop modules).
    - **Repetition:** if a defect survives TWO fix rounds on the same image, stop editing it. Route it to regeneration, or upstream to the brief or the casting, and say which. A third attempt at the same edit, unless the owner asks for it with a bound, is money burning quietly.

11. **Write the scorecard to disk NOW, before any money is discussed.** Save to `scorecards/scorecard-[scope]-[YYYY-MM-DD]-[run].md` using the Output format. `[run]` is the next unused counter for that scope and day, so the name is new by construction; **never overwrite an existing scorecard and never edit an earlier one.** The Day 5 main scorecard and its ranking must still be there, untouched, on Day 10. The only file this run may rewrite is its own, in step 13. **Corrections, the whole law in three lines:** (1) the CURRENT run updates its own scorecard in place, in step 13, after fixes and after a verified owner challenge (the sec-03 card went from 5/5 to 2/5 with the measurement written in, inside the same day's run). (2) An earlier run's scorecard is history and is never rewritten, not even to fix a wrong score. (3) A later correction to an earlier run is a NEW dated card, `scorecard-[scope]-[YYYY-MM-DD]-[run]-correction.md`, that names the card it corrects, the file (by md5), the old score, the new score and the evidence; the old card stays as it was. That is how the Day 5 main card and the Day 6 sec-03 correction are both right at once.

12. **Run the routine fixes, then say what ran. No "found problems, fix?" stop.** The routine-fix policy in `CLAUDE.md` is the one source: a VERIFIED, fixable defect on an in-scope candidate is fixed through `/fix` (MODE A) on a REPORT, inside the policy's limits (calls per round, estimated cost per round, attempts per defect), and re-inspected in step 13. The fix list is announced in one line with its estimate ("three fixes, about $0.30, running now") and runs; the only stops are the policy's own (a limit crossed, a paid regeneration route, an owner preference on file that says ask first, or an owner who said "just check" or "do not fix yet"). A+ local defects follow the same routine-fix policy, using the accepted copies of the exported module files. Route text, product, and layout-detail repairs to `/fix`, and artificial-looking people to `/fix-faces`. Review the repaired modules in the assembled page. Page-level changes follow `/aplus`'s separate routing (another concept or a new round; Genrupt's edit only when the owner asks in words). A+ body text is never sent anywhere because it fails at 160 pixels: on an A+ the 160 copy reads the headline hierarchy and body text is judged at the class's real display width (step 4).
    What is on the list: anything the policy calls an edit. A fake badge or an element the owner asked to lose (a prop is never on this list unasked), an over-long label, a wrong word or claim, AND a structure defect on the product (a part off its axis, a marking missing, an object misshapen), which is a focused edit on the chosen file with the references, composited back by region. What is written up as REGENERATE, with the EXACT sentence the new brief must carry and THIS file named as the base: a broad change (recast, new scene, new layout, most of the frame wrong) or a defect that already failed two edits.
    - **A defect the owner reports** ("the column is not centred on the left one") enters this same route, at once, as a fix order: verify it on the pixels, fix it on the file they chose, re-inspect, report found / fixed / before-after. Wonka never answers a reported defect by offering a different image; an alternative comes up only when the owner asks for one or the route has failed twice.
    - **The owner challenge protocol: a PASS never overrules the owner.** When the owner says "something is wrong here" or names a suspected defect on a frame this run passed, the card is REOPENED, not defended: go back to the file at full size and at 3x, measure where measuring applies (a centreline through the base and bowl against a centreline through the column, a count, a transcription), compare against the references, and write down what was found either way. If the defect is real, correct this run's card in place with the evidence and the root cause (which check the rubric lacked), then fix it under the route above. If it is not real, say what was looked at and what was seen, once, without a lecture. The score is never an argument; the pixels are. Measured 7 September 2026: sec-03 passed 5/5, the owner saw the tower leaning, the measurement showed about ten percent of the bowl width off the axis, and the card was corrected to 2/5 with the missing check named.
    - **"I will run /fix myself", "just check", "do not fix yet":** normal answers. The scorecard already exists from step 11; hand over the routed fix list as it stands, mark the affected images `flagged, fix not yet run`, and leave INSPECT `in progress`. Never present a known-defective image as a candidate just because the fix was held.

13. **Re-inspect what came back, then update this run's scorecard.** Every fixed or regenerated file goes through steps 3 to 9 again: a fresh 160 pixel copy, the six scores, the compliance gate. Nothing is fixed because it feels fixed. **A card covers exactly the file it inspected and nothing else:** its md5 (first ten characters) is written on the card, and a new version, a combined candidate from `/main-image` step 8b, or a fixed file is a NEW inspection that no earlier card covers. After a fix, also read the regions that were supposed to stay untouched against the parent; the Fixing Room's byte check catches a no-op, not a drift. Never close a run on "everything was fixed" or on a card written for a previous version. Update the scores, the ranking and the Fixes section in the scorecard file written in step 11, in place.

14. **Present with the NUMBERED sheet, then name the next room BY SCOPE.** First build the contact sheet: `python3 .claude/skills/inspect/contact_sheet.py sheet scorecards/contact-[scope]-[YYYY-MM-DD]-[run].jpg [the ranked files]` lays every gate-passed candidate out as a tile with its NUMBER in large print (06 for `main-06`, 130 for `main-130`; on a mixed scope the family rides in front, `sec 03`), in rank order on `shortlist` and `main` and in slot order elsewhere, and Wonka opens it (Read) and shows it BEFORE the ranking table, so the table's numbers mean something. The tool never overwrites an earlier sheet (a second run the same day lands as `-2`). Measured 6 September 2026: an owner handed a table of filenames had to ask "what is main-06?" before he could choose. Then the full-size FILES, one per candidate, never only a described ranking; a judgement the owner cannot see is not a judgement they made. The ranking table names candidates by the same numbers, one line each.
    **On the `shortlist` and `main` scopes this is the Day 5 close, and Wonka records it.** Ask the owner for ONE primary, the alternatives they want to keep (up to four) when there are any, and confirm the backup on disk. Three to five in all is the target when that many passed the gate; ONE is a lawful answer when the owner is sure, said once with what it trades away (nothing to race on Day 8), never argued. Read the answer back and write it into `status.md` under INVENT: `Main pick: main-13 (primary); alternatives: main-06, main-03; backup: vanilla-control.png`. The primary and the alternates are what the Tasting Room races on Day 8; the backup is the swap-in if a bolder main ever comes down, and that sentence is all the owner hears about risk.
    **Both selection rows are ALWAYS written at the close of their scope, unasked (kit v38, 12 September 2026).** The close of a `shortlist` or `main` scope writes the `Main pick:` row; the close of a `secondary` scope (the gallery set) writes the gallery row: `Gallery pick: edits/v2 (frames 02-07 in order)`, or `Gallery pick: images/ (frames 01-08 in order)` when nothing was edited. Whenever the owner changes their mind later, the same row is rewritten, never a second one added. The scorecard rank stays a recommendation and is never read as the selection: the Tasting Room reads these two rows and asks for nothing that they already record. A Day 8 with the `Main pick:` row missing once raced fourteen mains; the row is what stops that.
    Then the next room, by scope, never from memory of another day: `shortlist` and `main` go to Day 6, `/secondary-images`; `secondary` to Day 7, `/aplus`; `aplus` to Day 8, `/tasting-room` (which fills `incumbent/` itself at its opening); `variations` to `/ready-to-upload`, which extends the pack; `package` to `/tasting-room`. A regeneration owed goes to its generation room first. The Tasting Room is never the next room on Day 5 (measured 6 September 2026: an owner was sent there straight from the mains).

## Output format

`scorecards/scorecard-[scope]-[YYYY-MM-DD]-[run].md`:

```markdown
# Inspection Scorecard . [Product Name] . scope: [main/secondary/listing/aplus/variations/package] . [YYYY-MM-DD]

Built from: [folder]/ ([N] files in scope), brief/creative-brief.md, 2-reference/reference-sheet.md (source: [manual/amazon_scraped]), factory/Brand/brand-kit.md, research/persona.md, research/selling-points.md
Out of scope this run: [folders not inspected, and why]
Squint copies verified on disk: [N] of [N] in-scope images, in scorecards/squint/[scope]-[YYYY-MM-DD]-[run]/ ([tool used])
Run status: [CLEAN / DEGRADED: [gap, and what it made UNSCORED]]

## Verdicts

### [images/main-01.png] . slot: [main concept 1, bet: "..."] . version: [original / edits/v1 fixed copy, supersedes images/main-01.png]
- What I see: [1-2 line literal description]
- Squint test (160px): [PASS/FAIL] . survives: "[words or: product reads as a 4 tier fountain, size unclear]" . lost: "[words]"
- Structure: [verified on scorecards/magnify/[...]/[file]-box1-3x.png (and box2): column on the bowl and base axis, tiers centred, joints clean / DEFECT: the real product has [X], this frame shows [Y] at [where]] 
- Instances: [one / two, compared on the -compare-3x strip: agree on structure allowing for angle and state / DIFFER: [what]]
- Facts: [every number printed on the frame, transcribed: `18 in tall` (reference sheet spec table), `32 oz` (listing title) / `8.5 in` UNSOURCED, listing table says 8 in / no numbers on this frame]
- Size: [WxH] [flag when under 1000 on the longest side, or markedly smaller than its neighbours in the set. Report only; resolution is settled at packaging]
- Inspected file: [md5, first ten characters. This card covers this exact file and no later version]
- Scores: message [x]/5, legibility [x]/5, product accuracy [x]/5, brand fit [x]/5, craft [x]/5, casting [x/5 or null]
- Compliance gate: [PASS / FAIL: exact violation]
- Distinctiveness vs incumbent: [stands apart on X / near-copy of the live main / no incumbent on file] (mains only, diagnostic)
- Verdict: [SHIP / FIX: what and how (runs under the routine-fix policy, this run) / REGENERATE: the exact sentence the tighter brief must carry, built from this file as the base]

[...repeat per in-scope image. A+ modules and variation children use the same card, with module or child in place of slot...]

## Set-level summary

### Listing set [omit any section whose class is out of scope]
- Duplicate messages: [none / files X and Y both say "..."]
- Emotional frame: [present in X / MISSING]
- Repeated face: [none / X and Y share a model . route: distinct avatar, re-run that slot]
- Selling points: [n]/[total] covered. Missing: [ID . proposed home, or "consciously skipped, see brief"]

### A+ page
- Module order: [hero to trust, reads as a scroll / issue]
- One message each: [yes / M2 and M4 share a headline]
- Extends the gallery: [yes, M3 and M5 add what the gallery cannot / repeats the gallery at M2]
- Comparison honest: [yes / no comparison module / issue]

### Variation family
- Reads as siblings: [yes / [child] drifts on background or lighting]
- True counts per child: [all correct / [child] shows 3 tiers]
- Labeling: [all children correctly tagged / issue]

## Rankings (execution quality, per group. Not a prediction of what converts)
- MAIN: 1. images/main-03.png ([score]) 2. ... [tie-break used: legibility]
- SECONDARY [n]: ...
- A+ [module]: ...
- VARIATION [child]: ...
All gate-passed candidates advance. No bet was eliminated by rank.

## Escalations
- [Fidelity: [n] images at product accuracy <= 2, spanning [n] concepts/sources . re-lock the reference and re-run the smoke test before regenerating / one concept only, that concept drifted, no re-lock / none]
- [Repetition: [file] failed the same defect twice . routed to regeneration / none]

## Fixes this run
- [file] -> edits/v[N]/[file]: [what changed] . re-scored [old] -> [new]
- [or: fix list handed to the owner, not yet run. Affected: [files]]

## Needs regeneration
- [file] . [defect] . the brief must add: "[exact sentence]" . goes back to [/main-image | /secondary-images | /aplus | /variations]

## Recommendation
[One sentence per group. The candidates that passed the gate, and the decision that is the human's: on the main scope, which is the primary and which are the alternatives; on any other scope, what advances to the next room.]
```

## Golden Standards check

Before presenting, verify:
- [ ] The scope was stated out loud and echoed back, and no out-of-scope folder was inspected, touched, or reported as a gap.
- [ ] Every in-scope file was opened with Read and has a literal description. No image scored unseen.
- [ ] `scorecards/squint/[scope]-[date]-[run]/` holds a 160 pixel copy of every in-scope image, the count was verified with an actual directory listing of THAT folder (never the whole squint tree, which accumulates across runs), and both numbers are in the header. No full-size legibility judgments anywhere. Swatches were read at tiny size specifically.
- [ ] Missing inputs were asked for once, "I don't have it" was accepted, and every resulting gap is named in the header with the affected dimension marked UNSCORED or UNVERIFIED rather than guessed.
- [ ] Product accuracy was judged against the Reference Sheet, never memory, the part count was actually counted, and the STRUCTURE was read on the magnified crops in `scorecards/magnify/[scope]-[date]-[run]/`, every instance on its own and the instances compared; every score names its evidence or says `not verified`.
- [ ] Every number printed on a frame was transcribed and sourced on the card's `Facts:` line; an unsourced number capped product accuracy and was routed to a sourced word swap, never waved through for being small or plausible.
- [ ] A frame the owner questioned after a PASS was reopened, measured and either corrected on this run's card or answered with what was seen; no score was defended because it existed. An earlier run's card was never edited; a correction to one is a new dated correction card.
- [ ] The coverage walk ran through all four stages (selling points, brief map, saved plan, files) and every gap named its stage and its route.
- [ ] Every compliance FAIL names the exact violation and sits at the bottom of its group. The MAIN-only gate was applied to listing mains and variation mains only.
- [ ] Set-level checks ran per class: the four listing checks; the four A+ page checks including module order and extends-not-repeats; the three variation family checks. No swatch was false-flagged for repeating the product, no A+ module for reusing a face.
- [ ] Only the latest file in each lineage is on the candidate list; superseded parents are marked, not ranked.
- [ ] The ranking states its tie-breaks, and no hypothesis was dropped because it ranked last.
- [ ] The numbered contact sheet exists in `scorecards/` and was shown before the ranking table; candidates were named by number.
- [ ] On the `shortlist` or `main` scope the Day 5 close (primary, alternatives, backup) was written into `status.md` as the `Main pick:` row, and on the `secondary` scope the `Gallery pick:` row was written, both unasked; a single primary accepted when the owner was sure; the next room was named by scope, and `/tasting-room` was not named on Day 5.
- [ ] No prop was flagged, and the owner heard no policy lecture.
- [ ] Routine fixes ran under the routine-fix policy on a report with their estimate, re-inspected in step 13; a held fix left the scorecard on disk with the images honestly marked flagged; no owner-reported defect was answered with an offer of a different image; and no run closed as FINAL with a factual defect open on any in-scope file.
- [ ] The scorecard file exists on disk under a scope-and-date name, and no earlier scorecard was overwritten or edited.

## Wonka lines

Openers:
- "The Inspection Room. Charm stays at the door; only the candy speaks here."
- "Let's see what the machines made. I warn you, I am impossible to flatter."
- "Every piece on the belt, please. Nothing skips the light."

Closers:
- "Now THAT is a piece of candy. Name your primary and your challengers; the next room is waiting."
- "Inspected, ranked, and repaired. Your only job now is to name the primary and the challengers."
- "Wrong, sir, wrong, on two of them. But the Fixing Room already earned its keep. The rest gleam."
- "Found it, fixed it on your pick, and here are before and after. The right-hand machine and the headline did not move a pixel."
- "You'd rather hold the scalpel yourself? Good. The list is routed and the scorecard is on disk. I will be here when they come back."
- "No shrinking machine on this bench, so the legibility scores are marked unproven. I will not pretend I squinted."

## Definition of Done

- `scorecards/scorecard-[scope]-[date]-[run].md` exists on disk, under a name that did not already exist, with: the scope, the built-from line, the squint count verified by listing, a verdict card for every in-scope image, the per-class set-level summary, per-group rankings with tie-breaks, escalations, fixes, regeneration items with their exact brief sentences, and a recommendation.
- `scorecards/squint/[scope]-[date]-[run]/` holds one 160 pixel copy per in-scope image and its count matches, or the header states which tool was missing and legibility is marked UNVERIFIED throughout.
- Every gap from a missing input is written in the header, and no dimension was invented to cover one.
- Routine fixes were run on a report inside the policy's limits and re-inspected, or handed over intact with the images marked flagged; the report says found, fixed and open, per file.
- The user was shown the numbered sheet and only gate-passed candidates; on the `shortlist` or `main` scope they named the primary, the alternatives and the backup and it was written into `status.md` as the `Main pick:` row; on the `secondary` scope the `Gallery pick:` row was written; the next room was named by scope.
- No image, batch log, or earlier scorecard was renamed, moved, overwritten, or deleted.

## Update status.md

Set INSPECT to `done` only when the scope's candidates are gate-passed and the run was CLEAN. Leave it `in progress` while regenerations are pending, while a declined fix list is outstanding, or while the run is DEGRADED, and name the reason. Use `blocked` only when the scope held no images at all. Artifact: the scorecard filename.

Log line: `[date] Inspection ([scope]): [n] images scored, [n] squint copies on disk, [n] magnified reads, [n] compliance fails, [n] fixed under the routine-fix policy, [n] open, [n] sent back for regeneration. [CLEAN / DEGRADED: gap]. Scorecard: scorecard-[scope]-[date].md`

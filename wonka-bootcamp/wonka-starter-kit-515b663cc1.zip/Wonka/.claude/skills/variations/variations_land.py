#!/usr/bin/env python3
"""Land approved variation frames into `variations/` with the naming rules in code.

The names used to live in prose only, and prose is memory. This helper is the rule:

  real child     variations/main-[child].png, [slot]-[child].png, swatch-[child].png
                 (the suffix is the source's: a .jpg lands as .jpg)
  concept child  variations/concepts/[child]/main-[child]-concept.png, ... plus a
                 CONCEPT.md one-liner in the folder

A concept is a picture of a POSSIBLE product (a colour or finish the reference set
never showed, generated from the owner's sentence). It is labelled everywhere and it
is never a product claim. A real child is a saleable SKU with its own source.

Write-once: a name that already exists is never overwritten; the new file lands as
`-v2`, `-v3` beside it. Originals in `images/` and `edits/vN/` are never touched;
this copies OUT of `variations-work/working/[child]/`, nothing more.

Usage (from the kit root):
  python3 variations_land.py <product_dir> <child> real|concept SLOT=<path> [SLOT=<path> ...]
  python3 variations_land.py <product_dir> --plan        # every landed path with its status

`SLOT` is the frame name (MAIN, PT03, SWATCH); it is lowercased in the landed name.
"""
from __future__ import annotations
import json
import re
import shutil
import sys
from pathlib import Path

STATUSES = ("real", "concept")
IMG_EXT = (".png", ".jpg", ".jpeg", ".webp")
CONCEPT_LINE = ("This folder holds a CONCEPT: a picture of a possible product, generated from "
                "the owner's description. It is not a product the listing sells and it is "
                "never a product claim.\n")


def _slug(text: str) -> str:
    s = re.sub(r"[^a-z0-9]+", "-", text.lower()).strip("-")
    return s or "child"


def landed_name(slot: str, child: str, status: str, suffix: str = ".png") -> str:
    """`main-[child].png` for a real child, `main-[child]-concept.png` for a concept.
    The suffix is the SOURCE's: a .jpg lands as .jpg, nothing is re-encoded."""
    if status not in STATUSES:
        raise ValueError(f"status must be one of {STATUSES}, got {status!r}")
    tag = "-concept" if status == "concept" else ""
    suffix = (suffix or ".png").lower()
    if suffix == ".jpeg":
        suffix = ".jpg"
    return f"{slot.lower()}-{_slug(child)}{tag}{suffix}"


def target_dir(product_dir, child: str, status: str) -> Path:
    base = Path(product_dir) / "variations"
    return base / "concepts" / _slug(child) if status == "concept" else base


def _free(path: Path) -> Path:
    """Never overwrite: the second landing of a name is -v2 beside the first."""
    if not path.exists():
        return path
    n = 2
    while True:
        cand = path.with_name(f"{path.stem}-v{n}{path.suffix}")
        if not cand.exists():
            return cand
        n += 1


def recorded_status(product_dir, child: str):
    """The child's `status` in variations-work/manifest.json, or None when there is no
    manifest, no such child, or no status on its row."""
    man = Path(product_dir) / "variations-work" / "manifest.json"
    if not man.is_file():
        return None
    try:
        data = json.loads(man.read_text())
    except (OSError, ValueError):
        return None
    for row in data.get("children", []) or []:
        if isinstance(row, dict) and row.get("child") == child:
            return row.get("status") or None
    return None


def land(product_dir, child: str, status: str, frames: dict) -> list:
    """Copy `frames` ({SLOT: source path}) into their landed names. Returns the
    landed paths in the order given. A concept folder gets its CONCEPT.md. The
    manifest's recorded `status` is the record: a hand-typed `real` for a concept
    (or the reverse) is refused, because a concept in variations/ counts as a shipped
    child downstream."""
    if status not in STATUSES:
        raise ValueError(f"status must be one of {STATUSES}, got {status!r}")
    on_record = recorded_status(product_dir, child)
    if on_record and on_record != status:
        raise ValueError(f"{child} is recorded as `{on_record}` in variations-work/manifest.json, "
                         f"not `{status}`; land it as {on_record}, or fix the manifest first. Nothing landed.")
    out_dir = target_dir(product_dir, child, status)
    out_dir.mkdir(parents=True, exist_ok=True)
    if status == "concept":
        note = out_dir / "CONCEPT.md"
        if not note.exists():
            note.write_text(f"# {child}: concept\n\n{CONCEPT_LINE}")
    landed = []
    for slot, src in frames.items():
        src = Path(src)
        if not src.is_file():
            raise FileNotFoundError(f"{slot} for {child}: {src} is not on disk")
        dst = _free(out_dir / landed_name(slot, child, status, src.suffix))
        shutil.copy2(src, dst)
        landed.append(dst)
    return landed


def plan_lines(product_dir) -> list:
    """One line per landed file, path first, status last: the rows for
    `variations-plan.md`'s Outputs section."""
    base = Path(product_dir) / "variations"
    lines = []
    if not base.is_dir():
        return lines
    for p in sorted(x for x in base.rglob("*") if x.suffix.lower() in IMG_EXT):
        rel = p.relative_to(Path(product_dir)).as_posix()
        status = "concept" if "concepts" in p.relative_to(base).parts else "real"
        lines.append(f"- `{rel}`: {status}")
    return lines


def main(argv):
    if len(argv) < 2 or argv[1] in ("-h", "--help"):
        sys.exit(__doc__)
    product_dir = Path(argv[1])
    if "--plan" in argv:
        for ln in plan_lines(product_dir):
            print(ln)
        return 0
    if len(argv) < 5:
        sys.exit(__doc__)
    child, status = argv[2], argv[3]
    frames = {}
    for item in argv[4:]:
        if "=" not in item:
            sys.exit(f"expected SLOT=<path>, got {item!r}. Nothing landed.")
        slot, path = item.split("=", 1)
        frames[slot] = Path(path)
    try:
        landed = land(product_dir, child, status, frames)
    except (ValueError, FileNotFoundError) as e:
        sys.exit(str(e))
    for p in landed:
        print(f"landed {p.relative_to(product_dir).as_posix()} ({status})")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))

# The Main Image Doctrine

**The main image is the only asset that competes in search.** The other six sell to somebody who
already clicked. The main earns the click in the first place.

## Why this one image

Rating, review count, badges, price, rank, ad spend, images. Cross off everything you cannot change
this afternoon. What is left is the images, and one of them works alone in search. One image, fully
in your control, changeable in an afternoon. Most sellers treat it as something they did once at
launch.

## The snowball

Improve conversion by nought point one percent, and watch what it feeds: more conversion, more
sales; more sales, better rank; better rank, more sessions; more sessions, more reviews; more
reviews, more conversion. A small push on a loop is not a small result, it is a permanent change in
the direction the whole thing rolls.

**Which is why you should have an A/B test running on your main image at all times.** That is also
why the bootcamp puts several mains in your hands rather than one: you cannot run a test with a
single image.

## The four ways to build a hero

Enable several. Not one.

| Tactic | What it is | When it earns its place |
|---|---|---|
| **Hang tag** | A physical tag on the product with your words, 28 characters | How a claim gets onto a main legally: a real object, not an overlay |
| **Avatar interaction** | A person's hands or presence | Scale and warmth. Forbidden in some categories, so know yours |
| **Packaging** | The real retail box in frame | Strong when your box is good; answers "what actually arrives" |
| **Genrupt's choice** | The planner decides | It has seen more listings in your category than you have |

A hundred drafts spread across four strategies is a real experiment. A hundred drafts of one
strategy is a hundred versions of a single opinion.

## The hard rules

No overlay text or graphics, ever: only what physically exists on the product and label. No faces.
Hands only when you enabled the avatar tactic. And one candidate in every batch stays safely
compliant, the swap-in for the day a category reviewer knocks.

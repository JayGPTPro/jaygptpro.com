# The Five Point Sheet Check

**"Nice" is not one of the five.** The Reference Sheet is the mold every image is poured from, so
judge it like a mold, not like a picture. Run these five, every time:

1. **Is every angle actually here?** Front, back, both sides, top. Whatever is not in this picture,
   the machine gets to invent forever.
2. **Is there a scale cue?** Can you tell how big it really is without reading anything?
3. **Is every panel clear AND attractive?** A blurred or ugly panel does not merely fail to help,
   it POISONS everything poured from this mold. If your product looks cheap here, it looks cheap in
   every image after.
4. **Are the materials honest?** Steel reads as metal, plastic as plastic, glass as translucent
   glass. If a mixed-material product renders as one gleaming metal object, every image after it is
   selling something that does not arrive in the box.
5. **Has anything been added?** No text, no captions, no arrows, no badges. This sheet locks
   identity and nothing else.

## When it fails

- **Name the defect in NOUNS.** "The tower reads as chrome, the base is brushed stainless." Not
  "it looks off." A machine cannot act on a mood.
- **Revise the sheet you have, never start a new one.** Starting over throws away everything that
  was already right.
- **If the same defect survives two rounds, stop rewording.** The problem is a missing photo, not
  a missing adjective. Go take the photo.

And remember the order of the day: pass all five, run the smoke test, and only then say the words
**"Approved. Lock it."** A sheet locked on a look rather than a passed smoke test is the one
failure Day 4 exists to prevent.

# Reading a Tasting Card

**A hundred synthetic tasters leaning a handful of votes is not a fact about the world. It is a
nudge.** Here is how to read one like an adult.

## The three tiers

| Tier | What it means | What it licenses |
|---|---|---|
| **Clear lead** | The panel agreed on a direction AND purchase intent separates them by at least +0.25 of 5 | Act on it |
| **Lean** | Ahead but not by enough, OR stable with a difference too small to act on ("Consistent, not decisive") | A hint. Hold it loosely |
| **Toss-up** | Nothing separated them | **A real answer:** that decision does not matter. Spend the attention elsewhere |

Two more honesty rules the card enforces on itself: if the two base models disagree on the winner,
there is NO verdict, whatever the counts say; and everything is counted in VOTES, never percentages,
because a forced choice between images cannot produce a market share.

## The part worth more than the score

Every taster says WHY, in their own words, unprompted. A result tells you candidate three won. The
objections tell you eleven tasters could not tell how big it is, four thought it was plastic, and
two assumed it needs assembly. **Those are the questions your listing is failing to answer, handed
to you in a list, before you spent a cent on advertising.**

The score decides what to ship this week. The objections decide what to build next.

## What a card never is

Proof. The panel is synthetic, matched to your buyer demographics, and DIRECTIONAL. For a
big-money decision, a real-shopper poll is the gold standard, and an A/B on Amazon itself outranks
everything.

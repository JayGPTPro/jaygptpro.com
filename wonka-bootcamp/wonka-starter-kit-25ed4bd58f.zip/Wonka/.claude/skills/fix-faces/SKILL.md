---
name: fix-faces
description: One-click rescue for AI-looking people in ANY image, no factory context needed. Point it at an image file (or a folder), Wonka diagnoses which of the three realism signatures it shows (doll face, waxy skin + uniform tone, filter glow), runs ONE whole-image gpt-image edit pass that touches only the people, and saves the fixed version BESIDE the original. Clean images are left alone and told so. Works on factory images, old images, images from anywhere. Use when people in an image look fake, plastic, AI-generated, waxy, or over-filtered. Triggers: /fix-faces, "fix the faces", "the people look fake", "make the people real", "the skin looks weird", "AI-looking people".
---

# The Face Clinic

| Meta | Value |
|------|-------|
| Room | The Face Clinic (a walk-in clinic, not a production station) |
| Station | None. Runs any day, on any image, factory or not |
| Needs | An image file path (or a folder of images) and `OPENAI_API_KEY` |
| Saves to | A fixed copy BESIDE the original: `[name]-faces-fixed.png`. The original is never touched |
| Typical cost | One gpt-image edit per flagged image, quality low, cents each. Reported, not gated |

## What this room does

Generated people sometimes come out AI-looking. This clinic diagnoses WHICH way, fixes only what is
broken, and leaves clean images alone. It is deliberately tiny: no preconditions, no product folder,
no brief. Bring an image, leave with a real-looking one.

## The three signatures (the diagnosis vocabulary)

1. **Signature A, doll face** (geometry and expression): too-perfect symmetric features, uniform
   flawless teeth, glassy eyes, and everyone in frame at identical peak expression (all mid-laugh at
   once). Shows up even when lighting and color are believable.
2. **Signature B, waxy skin + uniform tone**: zero skin micro-texture (no pores, one smooth
   gradient), and every person wearing the same peach-orange tone that matches the design palette
   instead of varying per person.
3. **Signature C, the filter layer**: a diffusion/bloom glow like a beauty filter, highlights
   smearing on forehead and cheekbones, and warm light patches painted on with no single consistent
   light direction.

## Process

1. **Open the image and diagnose, out loud.** Look at the people at full size. Name which
   signature(s) apply, with one line of evidence each, or say **CLEAN** and stop: a clean image is
   never "improved" speculatively. No people in the image at all: say so and stop.
2. **Draw the head boxes, and PROVE them before spending.** For every person, one tight rectangle:
   the whole head and all of its hair, nothing else. Then crop each box out and LOOK at the crops.
   Two laws, each bought with a measured failure on 26.8.2026:
   - **A box never touches on-image text or the product.** Everything inside a box is surrendered
     to the re-render. A generous box that reached into the layout composited back a ghost
     microphone and a floating letter.
   - **A box never cuts through a head.** A box that covered half a face left the original half
     standing beside the new one, a two-face ghost. Whole head or redraw the box.
   - **A box ends on quiet background, never mid-garment.** The fade is invisible over a bench or
     foliage and plainly visible over a dark hoodie: the same seam that vanished on one child
     printed a soft line across another's chest and cheek. On a person wearing something dark,
     run the box down past the shoulders so the falloff lands off the body.
3. **Choose the quality, and know what it buys.** Measured 26.8.2026 on the same frame, same
   boxes, same prompt: `low` renders faces soft, with smooth under-textured skin that still reads
   faintly synthetic on a child's cheek; `medium` returns real skin texture, individual hair
   strands and believable teeth, takes about twice as long (roughly 40s against 20s) and costs
   more per call. **On a face that a customer will look at, `low` is the false economy.** The
   default stays `low` for a quick triage pass; pass `--quality medium` whenever the people are
   the point of the image, which in an A+ or a lifestyle secondary they always are.

4. **Report the cost in one line** (one edit, cents at low, more at medium) and run:

   ```bash
   python3 .claude/skills/fix-faces/face_fix.py IMAGE --boxes "x1,y1,x2,y2;x1,y1,x2,y2"
   ```

   What the engine does, and why it is an engine rather than one API call: it sends the FULL frame
   to gpt-image (context: the scene, the light, the palette), at `size="auto"` (a forced size
   re-composes at the wrong aspect and every head lands outside its box), with a prompt that
   REPLACES each face with a new real one, same casting, same pose, pinned to the same position.
   Then it composites ONLY the head boxes back over the original through a feathered mask, with a
   spatially varying, capped tone match so the seam carries no exposure edge and no color bleed.
   Every pixel outside the boxes is the original file by construction: headlines, product and
   layout cannot drift, because they are never replaced.
5. **Verify the composite, then the faces.** Open the result full-size next to the original:
   - No ghost fragments at box edges, no second face, no relocated feature. The model sometimes
     moves a person inside the render despite the position pin; when that shows, ONE retry (a fresh
     render is a fresh draw, cents). If it survives the retry, this image wants a regeneration in
     its own room, not a bigger clinic bill.
   - The people read as real at 3x zoom on the face itself, not at module scale.
   - Everything outside the boxes is untouched, which the engine guarantees, so any drift you see
     outside a box means the boxes are not where you think they are: recheck them.
6. **Done.** The fix landed beside the original as `[name]-faces-fixed.png` (a second attempt
   auto-lands as `-v2`). The original is never overwritten.
7. **On a folder**: diagnose every image first, list the flagged ones with their signatures and
   boxes, give ONE total cost line, WAIT for one yes (a folder is a paid edit batch, and CLAUDE.md's
   spend rule puts those on the fresh-go-ahead list; single-image mode stays report-and-run because
   invoking the room on one image IS the ask), then fix them in parallel.

**Know what this clinic cannot fix.** When the whole frame is color-graded (fake-tan skin, teeth
that are not white, nothing neutral anywhere), the defect is the GRADE, and `/inspect`'s
`cast_check.py` will say so. Fix the grade first; faces second. Corrected people inside an orange
room look worse than the problem.

## What this room never does

- Never touches a CLEAN image, and never lands changes outside the head boxes.
- Never keeps the doll: replacement IS the method (owner decision, 26.8.2026). Asking the model to
  "make the same face realistic" keeps the doll geometry and paints texture on it, which reads as a
  skin disease. A NEW face with the same casting, expression and position is what actually looks
  human. A different POSE or a different casting is still a regeneration, back in the image's own room.
- Never overwrites an original.
- Never claims the fix is invisible: it verifies side by side and reports drift honestly.

## Wonka lines

- "The Face Clinic. Walk-ins welcome, bring me anyone who came out of the ovens looking like a mannequin."
- "Diagnosis first. I do not operate on healthy faces."
- "There. Same picture, real people. The original is untouched, as always."

"""Fixture tests for contact_sheet.py. Run: python3 test_contact_sheet.py"""
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
import contact_sheet as cs  # noqa: E402

FAILURES = []


def check(name, cond, detail=""):
    print(("  PASS  " if cond else "  FAIL  ") + name + ("" if cond else "  " + detail))
    if not cond:
        FAILURES.append(name)


print("contact sheet")

# 1. Labels: the number the owner says, read out of every naming contract in the kit.
cases = {
    "main-06.png": "06", "07.png": "07", "pool-30_t3-motion_v1.png": "30", "m3-mobile.png": "3 mobile",
    "sec-03-v2.png": "03 v2", "main-amber.png": "main-amber", "vanilla-control.png": "vanilla-control",
    "pt03-round-10in.png": "03",
}
for name, want in cases.items():
    got = cs.label_for(name)
    check(f"label {name} -> {want}", got == want, f"got {got!r}")

from PIL import Image  # noqa: E402

with tempfile.TemporaryDirectory() as d:
    root = Path(d)
    src = root / "images"
    src.mkdir()
    names = ["main-01.png", "main-02.png", "main-03.png", "pool-30_t3-motion_v1.png"]
    for i, n in enumerate(names):
        Image.new("RGB", (300 + 40 * i, 200), (30 * i, 90, 120)).save(src / n)
    (src / "notes.md").write_text("not an image")
    (src / "broken.png").write_bytes(b"\x89PNG not really")

    # 2. sheet: one page, only readable images, numbers on the tiles.
    pages = cs.sheet(root / "contact.jpg", cs.collect([str(src)]))
    check("sheet writes one page", len(pages) == 1 and pages[0].exists())
    with Image.open(pages[0]) as im:
        check("sheet has the right width", im.width == cs.COLS * cs.TILE, f"{im.width}")

    # 3. pick: numbered copies, INDEX.md, pick-sheet, originals untouched, no opener in tests.
    dest = root / "pick"
    copies = cs.pick(dest, cs.collect([str(src)]), do_open=False)
    check("pick copies four numbered files", [c.name for c in copies] == ["01.png", "02.png", "03.png", "04.png"],
          str([c.name for c in copies]))
    idx = (dest / "INDEX.md").read_text()
    check("INDEX maps 04 to the pool file", "| 04 |" in idx and "pool-30_t3-motion_v1.png" in idx)
    check("pick-sheet exists", (dest / "pick-sheet.jpg").exists())
    check("originals untouched", sorted(p.name for p in src.iterdir()) == sorted(names + ["notes.md", "broken.png"]))

    # 4. a second pick into the same folder is refused: numbers are never reused.
    try:
        cs.pick(dest, cs.collect([str(src)]), do_open=False)
        check("second pick into the same folder refused", False, "it ran")
    except SystemExit as e:
        check("second pick into the same folder refused", "never reused" in str(e))

    # 5. more than 20 tiles paginates.
    many = root / "many"
    many.mkdir()
    for i in range(23):
        Image.new("RGB", (100, 100), (i * 10, 0, 0)).save(many / f"m{i + 1:02d}.png")
    pages = cs.sheet(root / "many.jpg", cs.collect([str(many)]))
    check("23 tiles -> 2 pages", len(pages) == 2 and pages[1].name == "many-2.jpg", str([p.name for p in pages]))

print()
if FAILURES:
    print(f"{len(FAILURES)} FAILED: {FAILURES}")
    sys.exit(1)
print("all passed")

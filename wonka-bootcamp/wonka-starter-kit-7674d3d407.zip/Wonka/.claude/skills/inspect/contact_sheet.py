#!/usr/bin/env python3
"""
The numbered contact sheet, for every moment the owner has to choose between images.

The owner picks by NUMBER. A file called pool-30_t3-motion_v1.png or main-06.png is a
name Wonka reads and the owner does not; a big "30" or "06" printed on the tile is what
they say back. Measured 6 September 2026 on a real Day 5 run: the owner was handed a
ranking table of filenames and had to ask "what is main-06?" before he could choose.

Two commands:

    python3 .claude/skills/inspect/contact_sheet.py sheet OUT.jpg FILE_OR_DIR [...]
        One or more pages of labeled tiles (20 per page: OUT.jpg, OUT-2.jpg, ...).
        The big label is the NUMBER found in the filename (main-06 -> 06, 07.png -> 07,
        pool-30_t3-motion_v1 -> 30, m3-mobile -> 3, sec-03-v2 -> 03 v2); the filename
        sits under it in small print. A directory argument means every image in it.

    python3 .claude/skills/inspect/contact_sheet.py pick DEST_DIR FILE_OR_DIR [...]
        Builds a PICK FOLDER: copies every image into DEST_DIR as 01.png, 02.png, ...
        (the original untouched), writes INDEX.md (number -> source path), builds
        DEST_DIR/pick-sheet.jpg with the same numbers, and OPENS the folder for the
        owner (macOS `open`, Windows `explorer`, Linux `xdg-open`; --no-open skips it).
        The owner says "7, 3 and 6"; INDEX.md says which file that is.

Pillow only. No network, no key, no decisions.
"""
import os
import re
import shutil
import subprocess
import sys
from pathlib import Path

IMAGE_EXT = {".png", ".jpg", ".jpeg", ".webp"}
COLS, ROWS, TILE, LABEL = 4, 5, 420, 64


def _pillow():
    try:
        from PIL import Image, ImageDraw, ImageFont
    except ImportError:
        raise SystemExit(
            "Pillow is not installed, so no contact sheet can be built. Run: "
            "python3 -m pip install pillow"
        )
    return Image, ImageDraw, ImageFont


def _font(ImageFont, size):
    for name in ("DejaVuSans-Bold.ttf", "Arial Bold.ttf", "Arial.ttf", "Helvetica.ttc",
                 "/System/Library/Fonts/Supplemental/Arial Bold.ttf",
                 "/System/Library/Fonts/Helvetica.ttc",
                 "C:/Windows/Fonts/arialbd.ttf", "C:/Windows/Fonts/arial.ttf"):
        try:
            return ImageFont.truetype(name, size)
        except Exception:
            continue
    try:
        return ImageFont.load_default(size=size)
    except TypeError:
        return ImageFont.load_default()


def label_for(path):
    """The number the owner says, read out of the filename. Falls back to the stem."""
    stem = Path(path).stem
    m = re.search(r"(\d+)", stem)
    if not m:
        return stem
    num = m.group(1)
    tail = stem[m.end():]
    v = re.search(r"-v(\d+)", tail)
    mode = re.search(r"-(mobile|desktop)", tail)
    out = num
    if v:
        out += f" v{v.group(1)}"
    if mode:
        out += f" {mode.group(1)}"
    return out


def collect(args):
    files = []
    for a in args:
        p = Path(a)
        if p.is_dir():
            files += sorted(q for q in p.iterdir() if q.suffix.lower() in IMAGE_EXT
                            and not q.name.startswith("pick-sheet"))
        elif p.suffix.lower() in IMAGE_EXT and p.exists():
            files.append(p)
        else:
            print(f"  skipped (not an image or missing): {a}")
    seen, out = set(), []
    for f in files:
        r = f.resolve()
        if r not in seen:
            seen.add(r)
            out.append(f)
    return out


def _readable(files, Image):
    ok = []
    for f in files:
        try:
            with Image.open(f) as im:
                im.load()
            ok.append(f)
        except Exception:
            print(f"  SKIPPED unreadable image: {f.name}")
    return ok


def sheet(out_path, files, labels=None):
    """Write labeled pages. Returns the list of page paths."""
    Image, ImageDraw, ImageFont = _pillow()
    files = _readable(files, Image)
    if not files:
        sys.exit("no readable images to lay out")
    labels = labels or [label_for(f) for f in files]
    big, small = _font(ImageFont, 40), _font(ImageFont, 16)
    out = Path(out_path)
    per = COLS * ROWS
    pages = []
    for p, start in enumerate(range(0, len(files), per), 1):
        chunk = files[start:start + per]
        rows = (len(chunk) + COLS - 1) // COLS
        page = Image.new("RGB", (COLS * TILE, rows * (TILE + LABEL)), "white")
        d = ImageDraw.Draw(page)
        for i, f in enumerate(chunk):
            x, y = (i % COLS) * TILE, (i // COLS) * (TILE + LABEL)
            d.rectangle([x, y, x + TILE - 1, y + LABEL - 1], fill="black")
            d.text((x + 12, y + 6), labels[start + i], fill="white", font=big)
            d.text((x + 12, y + LABEL - 20), f.name[:40], fill=(200, 200, 200), font=small)
            with Image.open(f) as im:
                im = im.convert("RGB")
                im.thumbnail((TILE, TILE))
                page.paste(im, (x + (TILE - im.width) // 2, y + LABEL + (TILE - im.height) // 2))
            d.rectangle([x, y + LABEL, x + TILE - 1, y + LABEL + TILE - 1], outline=(220, 220, 220))
        name = out if p == 1 else out.with_name(f"{out.stem}-{p}{out.suffix}")
        page.save(name, quality=88)
        pages.append(name)
        print(f"{name} ({len(chunk)} tiles)")
    return pages


def open_folder(path):
    path = str(path)
    try:
        if sys.platform == "darwin":
            subprocess.run(["open", path], check=False)
        elif os.name == "nt":
            os.startfile(path)  # type: ignore[attr-defined]
        else:
            subprocess.run(["xdg-open", path], check=False)
    except Exception as e:  # never let the opener kill the pick
        print(f"  could not open the folder automatically ({e}); it is at {path}")


def pick(dest_dir, files, do_open=True):
    Image, _, _ = _pillow()
    files = _readable(files, Image)
    if not files:
        sys.exit("no readable images to pick from")
    dest = Path(dest_dir)
    dest.mkdir(parents=True, exist_ok=True)
    existing = [p for p in dest.iterdir() if re.fullmatch(r"\d+\.[a-z]+", p.name)]
    if existing:
        sys.exit(f"{dest} already holds a numbered pick set ({len(existing)} files). "
                 f"Use a fresh folder; numbers are a promise and are never reused.")
    width = max(2, len(str(len(files))))
    lines = ["# Pick folder", "", "The owner names a pick by NUMBER. This table says which file each number is.", "",
             "| # | Source | Tile label |", "|---|---|---|"]
    copies, labels = [], []
    for i, f in enumerate(files, 1):
        num = str(i).zfill(width)
        target = dest / f"{num}{f.suffix.lower()}"
        shutil.copy2(f, target)
        copies.append(target)
        labels.append(num)
        lines.append(f"| {num} | {f.as_posix()} | {label_for(f)} |")
    (dest / "INDEX.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    pages = sheet(dest / "pick-sheet.jpg", copies, labels)
    print(f"{len(copies)} numbered files in {dest}, INDEX.md written, {len(pages)} sheet page(s).")
    if do_open:
        open_folder(dest)
    return copies


def main(argv):
    if len(argv) < 3:
        sys.exit(__doc__)
    cmd, rest = argv[1], argv[2:]
    do_open = "--no-open" not in rest
    rest = [a for a in rest if a != "--no-open"]
    if cmd == "sheet":
        if len(rest) < 2:
            sys.exit(__doc__)
        sheet(rest[0], collect(rest[1:]))
    elif cmd == "pick":
        if len(rest) < 2:
            sys.exit(__doc__)
        pick(rest[0], collect(rest[1:]), do_open)
    else:
        sys.exit(__doc__)


if __name__ == "__main__":
    main(sys.argv)

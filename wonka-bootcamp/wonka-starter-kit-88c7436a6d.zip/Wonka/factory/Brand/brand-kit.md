# Brand Kit . The Wrapper

> This file is the single source of truth for how your brand looks and sounds in every image.
> The `/brand-kit` skill interviews you and fills the sections marked **[filled by /brand-kit]**.
> You can also edit anything here by hand. Wonka reads this file before every generation.

## Brand identity

| Field | Value |
|---|---|
| Brand name | [your brand name] |
| One-line positioning | [filled by /brand-kit] |
| Website / storefront | [URL or n/a] |
| Kit basis | [filled by /brand-kit] |

## Colors **[filled by /brand-kit]**

| Role | Hex | Notes |
|---|---|---|
| Primary | #______ | [main brand color] |
| Secondary | #______ | |
| Accent | #______ | [highlights and real on-product seals only, never an invented badge] |
| Background | #______ | [typical backdrop tone] |
| Text on light | #______ | |

Text-safe pairs: [filled by /brand-kit]

## Fonts and typography direction **[filled by /brand-kit]**

- Headline style: [editorial serif | clean sans | bold display]
- Supporting text style: [editorial serif | clean sans | bold display]
- Overall look in one sentence: [e.g. "editorial wellness, premium and calm, never loud"]
- Licensed font on file: [name, human design work only] or n/a

Image models cannot load font files, so this section describes the LOOK the text should have. It reaches Genrupt through the branding preset below, never as prose in a brief.

## Tone words **[filled by /brand-kit]**

- Sounds like: [3 to 5 words, e.g. warm, expert, unhurried]
- Never sounds like: [3 to 5 words, e.g. shouty, clinical, gimmicky]

## Logo rules

- Logo file: save your logo into this folder (`factory/Brand/`) as a PNG with a transparent background if you have one.
- Placement: [e.g. small, one corner, never over the product]
- One logo per image maximum. A logo repeated across an image is visual noise, not branding.

## Style engine **[filled by /brand-kit]**

How this brand reaches Genrupt. Style travels ONLY through these two carriers; hex codes, font names and style prose never go into brief text.

| Field | Value |
|---|---|
| Branding preset | [filled by /brand-kit: the id Genrupt returned, with the date. PENDING if Genrupt was unavailable] |
| Style image | [filled by /brand-kit: factory/Brand/style-image.[ext] plus a one-line why, or "none chosen"] |

## APPROVED CLAIMS . the only claims allowed on images

List ONLY things that are actually true and provable. Real certifications as they appear on your real label, real press mentions with the outlet name, real awards.

| Claim | Applies to | Proof | Where it may appear |
|---|---|---|---|
| [e.g. USDA Organic] | brand-wide | [on the physical label] | [as it appears on the label, or as an on-product seal] |
| [e.g. featured in (outlet)] | brand-wide | [link] | [as plain printed text or a physical hang-tag, never as the outlet's logo graphic] |
| [e.g. 4 tiers] | [product name] | [the listing spec and the packaging shot] | [as plain printed text] |

If it is not in this table, it does not go on an image. Ever.

**`Applies to` is not bookkeeping.** `brand-wide` means every product this brand sells. A product name means that product ALONE. Attributes are the trap here: dimensions, capacity, part count, material and warranty are almost always product-scoped, and a claim verified for one product is never licensed for another. A new product may use `brand-wide` rows plus rows carrying its own name, and nothing else, until its own proof exists.

## Avoid list

Brand-specific things to never show, on top of the Golden Standards compliance list:
- [e.g. a competitor's trade dress, an old discontinued label, a claim legal asked you to drop]
- [add your own]

---
Sources used: [filled by /brand-kit]. Not available: [filled by /brand-kit].
Owner approval: [filled by /brand-kit: APPROVED or PENDING]
Last updated: [date] by [you / /brand-kit]

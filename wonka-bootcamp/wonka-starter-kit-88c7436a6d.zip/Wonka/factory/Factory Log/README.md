# Factory Log

Factory reports land here as `YYYY-MM-DD-report.md`, written by `/factory-report`: every product on the line, its station, what is finished, what is blocked and on whom, one next action each, and a single priority. A second walk on the same day is saved beside the first as `-2`, never over it. The machines log (`machines-log.md`, written by `/machines-check`) also lives here.

You meet this report on Day 1, on an empty floor. From Day 10 it becomes the weekly habit: a scheduled task on this folder if your Claude setup supports one, otherwise a recurring reminder and one command. Be clear eyed about which one you have, because a reminder does not run while your machine is off.

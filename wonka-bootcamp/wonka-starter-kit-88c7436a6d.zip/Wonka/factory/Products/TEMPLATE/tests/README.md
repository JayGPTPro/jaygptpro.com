# tests/

Proof lives here. Opinions do not.

What lives in this folder:
- `tasting-r[N]-[date]-[race]/`, one folder per race per Tasting Round (`-main` and `-gallery`, so a Round is two folders). Each round holds TWO races: the MAIN race (candidates, always including the current live Amazon image) and the GALLERY race (the new secondary set vs the live Amazon gallery). Each race folder holds `config.json` (the exact lineup that raced), its Tasting Card (`tasting-card.html` + `tasting-card.md`), and `results.json`. Written by `/tasting-room`.
- `upload-pack.md`, the ready-to-upload package and Amazon A/B handoff for the winner. Written by `/ready-to-upload`.

Every result in this folder also feeds `factory/Improvement Log.md` via `/improvement-loop`, so the Factory gets smarter.

# 1-inputs/

Everything YOU bring to the Factory for this product goes here. Wonka reads this folder; he never writes your inputs for you.

What lives in this folder:
- `reviews.txt`: the top ~10 positive and ~10 critical reviews, copied while logged in.
- `competitors/`: 3 to 5 same-niche competitor ASINs/URLs (a text file is fine), or screenshots of their full image galleries.
- `notes.txt`: your owner intel. What customers ask, what comes back in returns, what you tried before, what you may not claim.
- Optional extras when you have them: the Brand Registry ASIN-level demographics export, Search Query Performance export, return reasons, keyword data.

Product photos go to `2-reference/photos/` and brand files to `2-reference/brand/`, not here.

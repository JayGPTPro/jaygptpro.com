# edits/

Every edit round from the Fixing Room lands here as its own complete snapshot: `v1/`, `v2/`, and so on.

The rule: each `vN/` folder holds the FULL current set, the changed files changed, the untouched files copied in as-is. So the latest `vN/` folder is always the whole package as it stands right now, and no earlier version is ever touched. Raw generations stay untouched in `images/`.

Written by `/fix`. Nothing here is final until the Inspection Room signs it.

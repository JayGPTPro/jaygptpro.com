# research/

Everything the Research Room learns about this product lands here. Wonka writes this folder; your own inputs (reviews, competitors, notes, demographics) go into `1-inputs/`, where the Research Room reads them.

What lives in this folder:
- `insights.md` (the niche picture Wonka DERIVES from your reviews, your listing, and the competitor teardown: table stakes, customer language, pricing, demographics), `reviews.md`, `persona.md`, `selling-points.md`, and `competitors.md` (the competitor teardown).
- `product-report.md`, the unified Product Report built on top of the five files.

All written by `/meet-my-product`. The Brief Room reads this folder before writing a single line of brief. Empty folder = closed Brief Room.

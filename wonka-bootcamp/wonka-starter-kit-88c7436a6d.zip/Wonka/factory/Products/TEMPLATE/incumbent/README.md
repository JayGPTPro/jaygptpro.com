# incumbent/

The reigning champion lives here: the images your listing shows on Amazon RIGHT NOW.

What lives in this folder:
- `main-live.png` (or .jpg), your current live MAIN image, downloaded from your own listing.
- `live-01.png`, `live-02.png`, and so on: your current live GALLERY, in the exact order Amazon shows it.

Downloaded by YOU at the end of Day 7, before the Tasting Room. `/inspect` uses the live main for its distinctiveness read, and `/tasting-room` puts these files in both races, because a winner only counts if it beats reality.

No live listing yet (pre-launch)? Save your strongest competitor's main image here instead, name it clearly (`competitor-main.png`), and tell Wonka. Beating a named rival is a different claim than beating your own live image, and the Tasting Card will say which one was made.

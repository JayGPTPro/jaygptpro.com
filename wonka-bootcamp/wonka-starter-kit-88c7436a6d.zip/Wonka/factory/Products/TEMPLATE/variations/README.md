# variations/

The variation imagery for this product lands here, for products sold in multiple colors, sizes, shapes, scents, flavors, or bundles.

What lives in this folder:
- A per-child main image and a swatch for each real child (`main-round-10in.png`, `swatch-round-10in.png`, and so on), plus every gallery frame that carries the varying attribute, child-tagged (`pt03-round-10in.png`), plus `variations-plan.md` with the frame table, the truth table, and the Amazon parent/child embedding notes. Written by `/variations`.
- The machinery (manifest, source set, shape references, drafts, QA sheets) lives next door in `variations-work/`, never here.

Frames that carry nothing variant-specific are REUSED across the family, never regenerated. Every child is kept visually consistent with the tested winner and the locked Reference Sheet. Nothing here is final until the Inspection Room signs it.

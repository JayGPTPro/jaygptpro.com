# 2-reference/

The Reference Sheet is the locked reference of your REAL product. It is what stops the AI from inventing a bottle you do not sell.

What lives in this folder:
- `photos/`: your real product photos. All angles (front, back, both sides, top), one hand-for-scale shot, label close-ups. You drop them here.
- `brand/`: your logo and brand files (brand colors, fonts, an existing brand guide if one exists). `/brand-kit` reads them.
- `reference-sheet.md`, the lock record ("Reference status: LOCKED" plus the smoke test result) and the smoke test control image. Written by `/reference-sheet`.

No generation batch runs before the smoke test image in this folder has been looked at and approved.

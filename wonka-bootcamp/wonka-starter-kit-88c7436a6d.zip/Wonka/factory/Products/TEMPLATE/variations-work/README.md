# variations-work/

The Variations Room's workbench. Draft frames, rejected pilot attempts, drift measurements and
in-progress children live here while the room works. Only frames that PASS the truth table and the
gates get promoted into `variations/`, which is the folder the Shipping Room reads.

Safe to be messy. Never packaged, never uploaded, never read by any other room.

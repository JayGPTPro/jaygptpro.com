# images/

Every generated image for this product lands here, and this folder is **write-once**: raw generation output only, never edited, never overwritten.

What lives in this folder:
- The main image candidates. Written by `/main-image`.
- The secondary set. Written by `/secondary-images`.

Fixes never land here. The Fixing Room writes each edit round as a complete set snapshot into `edits/v1/`, `edits/v2/`, and so on: the changed files changed, the untouched files copied in as-is, so the latest `edits/vN/` folder always holds the full current set. The originals here are never deleted or overwritten.

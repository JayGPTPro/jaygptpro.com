# final/

The approved package lives here: the tested winner set that passed the gates and earned its Golden Ticket.

Written by `/ready-to-upload`, which also copies the package and `upload-pack.md` to the kit-level `output/` folder for delivery. Everything before this folder is work in progress; everything in it is ready to upload.

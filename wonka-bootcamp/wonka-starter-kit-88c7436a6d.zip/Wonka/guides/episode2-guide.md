# Day 2: Wonka, Meet My Product

Today your product walks through the Front Gate, and your new employee earns his salary before touching a single pixel. One command registers it, opens its folder inside the factory, asks you the three things only you know, and hands you a shopping list pointing at those folders. Then he stops and you go and collect. That collecting is the real work of this day. When you come back, same day or the next, he interviews you about what you brought, then digests your listing, your reviews and your competitors and derives the picture of your niche himself. No research subscription, no export, no browser extension. Everything he needs you already own, including the one thing that spends anything today: a Genrupt market analysis that runs on your included credits. It costs single-digit credits, so he tells you the exact number as he runs it rather than stopping to ask; the factory saves its permission questions for spends that deserve them.

**The day has a gap in the middle, on purpose.** Register, take the list, leave. Fill the basket properly. Come back and the room picks up at the interview. Nothing is lost by putting an evening between the two halves, and a lot is lost by rushing the collecting.

No images today. This is the foundation everything else stands on, and it is the day a lot of sellers discover that a complaint sitting in their reviews was caused by their own images.

**The sentence for the day: you are not showing him a product, you are teaching him one.**

## What you will have by the end of today

- A product folder on disk with all its rooms inside it and a station tracker
- `research/insights.md`: the derived niche picture. Table stakes, customer language, the pricing landscape, demographics, and your funnel diagnosis
- `research/reviews.md`: pain points ranked, objections, delight moments, and the exact customer phrases worth putting on an image
- `research/persona.md`: the real buyer, not the imagined one
- `research/competitors.md`: what every rival shows, which of their frames is genuinely strong, and the whitespace nobody is covering
- `research/selling-points.md`: the checklist that follows you for the rest of the bootcamp

**Time needed:** about two hours, and it does not have to be one sitting. 30 minutes of video, an hour or so out collecting, and the rest reading what comes back, which is the enjoyable part.

## What you will need to START

Only this, and it is five answers:

- Your ASIN, your full Amazon listing URL, your marketplace, your brand name, and your exact niche phrase in your own words
- Your owner intel, roughly thought through. He interviews you for it at the Gate, in the first few minutes
- Optional, and only if you have Brand Registry: your ASIN level demographics export, and your Search Query Performance export

**Everything else you collect AFTER he asks for it,** which is the point of the pause in the middle of today. He opens the folders first, then tells you what goes in each one, so nothing gets gathered into the wrong place or gathered twice. What you will be sent out for: competitor gallery screenshots with their listing URLs, your product and packaging photos, your logo and brand files, and your own notes. Not your reviews, he reads those by machine.

If your product photos are already shot from Day 1, half the basket is done before you start. If not, that is what the pause is for.

---

---

## Lesson 1: Walk your product through the gate

*Registration, the title read-back, the owner intel, the list, and a full stop.*

### Why the gate comes before the research

Nothing gets researched until the product has a home and a name. That sounds like paperwork and it is, but three of the four minutes it takes are load bearing.

**The title read-back.** He fetches your listing and reads its title back to you before he creates anything. One transposed character in an ASIN passes every format check ever written and quietly registers a stranger's product into your factory, and a human reading a title is the only thing that catches it. Read it properly, do not skim past it.

**The niche phrase, in your words.** He asks for it and repeats it back word for word. That phrase decides which listings count as genuine competitors for the rest of the bootcamp, and every table stake in your analysis stands on it.

**The owner intel.** Three questions, before he has read anything, because your answers are the one input no research on earth can replace. See Mission 1 for how to answer them and the one rule you may not break.

Then the shopping list, then the stop. He will not research, guess, or start early while you gather. That refusal is the same refusal you saw on Day 1 when he would not make images without a brief, and it is worth the same to you.

---

## Lesson 2: Teach Wonka

*The interview. He keeps asking until he has what he needs.*

### Research is ammunition, not homework

The most expensive image you will ever pay for is a beautiful one that answers a question nobody asked. It looks superb in your folder and it moves nothing, because it was never connected to what buyers in your niche actually care about.

Wonka needs four answers before he touches a pixel:

1. What does this niche treat as mandatory?
2. What do buyers complain about, and what actually triggers the purchase?
3. What is every competitor showing, and what is nobody showing?
4. Who is the real buyer?

He derives all four from six sources, cross referenced: what you taught him in the interview, your own listing torn down, your reviews, your competitors, Genrupt's market analysis (the one credit spend on this floor, reported with its exact cost as it runs), and the factory's own Improvement Log. The two that will teach you the most: **Competitors** give you the visual landscape. **Reviews** give you the emotional truth. A critical review is a buyer writing your image brief for free.

---

## Lesson 3: The analysis, and The Product Report

*He goes away and works, then hands back one readable report.*

### Table stakes and whitespace

Two words you will use for the rest of your selling career.

**Table stakes**: what most competitors show AND reviews demand. That double confirmation is what makes a feature non negotiable. You get no points for showing one, you get eliminated for missing one. A feature only competitors show, or only reviews mention, is single source, and Wonka labels it that way so you can weigh it instead of guessing.

**Whitespace**: what nobody in your niche shows, even though the reviews prove buyers care. That is where a new image set wins, because it is the only place you are not competing on execution.

The competitor teardown exists to sort every visual idea into one of those two piles, and to name their single best frame so you can match it and then beat it.

### The reviews trap, and why it decides your whole day

Your product page shows you a handful of reviews, usually about eight, and they skew positive, because a product page is a sales page. Read only those and you have collected marketing, not research.

**With Genrupt connected, the machine walks past the trap for you:** the deep dive mines hundreds of reviews across the top products in the niche, critical ones included, for a few credits. That is the default, and you copy nothing. Your one worthwhile manual add is your OWN product's reviews from Seller Central, a single export, because that set is complete and yours. Hand-copying is the fallback route for a run without Genrupt: log in on amazon.com, sort by Most recent, then filter to Critical and copy those too.

The demo product this bootcamp runs on shows exactly why. It is the number one best seller in its category, sitting at 3.9 stars, and the split is 58% five star and **18% one star**. Nearly one in five buyers is angry. Take the eight reviews the page offers and you meet none of them.

### The expectation gap

Here is what those critical reviews turned out to say on the demo product, a four tier electric chocolate fondue fountain.

The number one complaint, by a distance, is that the chocolate does not flow. Buyers describe following the instructions precisely, adding oil, adding more oil, and still getting a thick trickle instead of a cascade. Then one buyer explains the whole thing in a single line: the box says it holds 32 oz, two pounds, and it does hold that amount, but for the flow you see in the pictures you need about four pounds.

Read that again. The listing sells 32 ounces. The buyer fills it to 32 ounces, because that is the number on the box. She gets a trickle instead of the waterfall she saw in the photograph, at her daughter's baby shower, in front of the guests.

The gap is between the gallery and the box. The hero shot shows a perfect cascade. The stated 32 ounce fill does not produce it. Buyers followed the number on the box, got the trickle, and left one star, months later.

Now the reverse, which is why you are here. If images can open that gap, images can close it. Look at the rest of that competitive set: 3.5, 3.5, 3.7, 3.7, and one premium machine at 4.1 that costs more than three times as much. Every gallery on the page shows the same fantasy cascade, and nobody answers the question every buyer is actually asking, which is: will it flow for ME, and what does it take. The first seller who answers that inside the gallery owns the category.

Two things to carry into your own product:

1. Go and look for your version. Somewhere in your critical reviews is a complaint your own creative caused. Almost every product has one. Finding it is worth more than any lighting decision you will make in this bootcamp.
2. A finding from reviews is a **review finding**. It is what buyers report. It never goes onto an image as if it were a claim on your box. We close expectation gaps, we do not open new ones. Truth is the entire advantage here.

### The real buyer, not the imagined one

Most listings are art directed for a customer who does not exist, often 25 years younger than the person actually clicking Buy. Wonka builds the persona from the evidence: the voice in your reviews, your listing, and your competitors'.

If you have Brand Registry and export your ASIN level demographics, he builds it from your ACTUAL buyers and records `source: brand_registry_export`. If you do not, he builds an honest estimate, labels every line `estimated`, and upgrades it the moment real data arrives.

This persona decides real things later: who appears in your lifestyle images, which fear the images answer first, what language goes into headlines, and how the panel of tasters in the Tasting Room is screened. A wrong persona here is inherited by every room that follows.

### Click problem or close problem

There are only two ways an Amazon listing loses money, and they need opposite fixes.

- **Low click share.** Shoppers see you in search and scroll past. That is a click problem, and the lever is the MAIN image.
- **Healthy click share, weak purchase share.** Shoppers click, land on your page, and leave. That is a close problem, and the lever is the secondary gallery and the A plus content.

Fix the wrong one and a beautiful new set changes nothing. That is how most sellers waste a redesign.

If you have Brand Registry, Search Query Performance answers this for you. If you do not, say so, and Wonka reasons from public signals and marks the diagnosis `estimated`. Either way, the answer steers how much weight your brief puts on the main image versus the gallery.

### One rule that runs through the whole factory

Every selling point gets mapped to an asset, or gets skipped in writing, with a reason. Nothing important disappears silently. That rule starts today, in `selling-points.md`, and it is enforced in every room after this one.

---

---

## MISSION 1: Walk through the Front Gate

The day opens on one command, and the same command finishes it after the pause:

```
/meet-my-product
```

Give him the identity in the first message: ASIN, full Amazon URL, product name, brand, and your **exact niche phrase** in your own words. Confirm that phrase carefully. It defines which competitors count as the same niche, and every table stake in your analysis depends on it being right.

Three things happen before anything is created, and all three are deliberate.

1. **He proposes a folder slug and asks you to confirm it.** That name follows this product for the rest of the bootcamp.
2. **He reads the listing title back to you.** Confirm it is genuinely your product. A single transposed character in an ASIN passes every format check on earth and quietly registers a stranger's product into your factory. A human reading a title is the only thing that catches it.
3. **He interviews you for owner intel.** Three questions, in one message: what do you already know works, what MUST appear, what must we avoid.

Answer question three properly. This is the one input no research on earth can replace, it is recorded word for word, and it travels with your product through every room. Plain sentences are perfect:

```
Known winners: the lifestyle shot with the product in use outperformed the
white background shot the last time we swapped them.
Must include: the certification that is really printed on our label, and
the one feature buyers never notice until support explains it to them.
Avoid: any medical or health claim, our lawyer killed those, and no
comparison to [competitor] by name.
```

Write yours the way you would say it to a new employee, with the real words off your real label. Only claim what is genuinely printed on your product or documented in your account. An invented certification here becomes an invented badge in an image later, and that is a suppression risk, not a stylistic one.

If an item genuinely does not exist for you, say so plainly. "None, this is a new product and I have no past results" is a real answer and he records it as given. He will never invent intel to fill a gap.

Then the product folder is created from the TEMPLATE and `status.md` is written with RESEARCH set to in progress.

## MISSION 2: Go and fill the basket

He hands you the entire list in one message and then he parks. He will not research, guess, or move on until the basket is full. That is the integrity rule, and it is the reason you can trust anything downstream.

**So leave.** This is the middle of the day and it is meant to be spent away from the screen: screenshotting galleries, photographing your product and its box, digging out your logo. An hour is normal, an evening is fine, tomorrow morning is fine. Everything Wonka says for the next nine days is built out of what lands in these folders, and a thin basket produces a thin brief and a thin set of images that you will not be able to spot from the inside. Then you come back, tell him the basket is full, and the room picks up at the interview.

The list:

- **Listing URL.** Or a product description if you are pre launch, and he records `live: no`.
- **Not your reviews.** He reads those himself, hundreds of them, with the deep dive. Your one worthwhile add is a Seller Central export of your OWN reviews if you can make one in a minute. The hand-copied file, about 10 positive and 10 critical into `1-inputs/reviews.txt`, is the fallback route for a run without Genrupt only. Take the critical ones properly, see above.
- **Competitors.** 3 to 5 ASINs or URLs, or full gallery screenshots dropped into `1-inputs/competitors/`. The ones stealing your sales, not the ones flattering to compare against.
- **Real product photos.** All angles, one hand for scale shot, and label close ups, into `2-reference/photos/`. They are used in the next room, so collect them now while the camera is out. If you genuinely cannot hold the product, the fallback is the listing gallery plus customer review images, recorded as exactly that. It is what the demo run uses, because that listing is not ours and there is no unit on the desk, and you will hear it said plainly on camera. It is the fallback, not the standard. Yours is in your house, so shoot it.
- **Your packaging shots**, in the same folder, named so they read as packaging (`box-front.jpg`, `box-back.jpg`, `label-panel.jpg`). Packaging travels its own channel inside the machine and it drives one of the ways your main image can be built, so clear names matter. If a buyer will never see a box, skip it on purpose rather than by forgetting.
- **Logo and brand files** into `2-reference/brand/`: your logo, your brand colors or fonts, an existing brand guide if one exists. `/brand-kit` builds from these on Day 4.
- **`1-inputs/notes.txt` with anything else you know:** what customers ask you over and over, what comes back in returns and why, what you tried before that failed, anything you are not allowed to claim. If the product is new to you, or not yours, write that.
- **Optional: Brand Registry demographics export.**
- **Optional: any search term or keyword data you already have.**

The two optional items never block. If you do not have them, say so and he records them as not provided.

Then say it explicitly:

```
Everything is in.
```

That phrase is not a magic trigger, on purpose: it invites Wonka to read the basket back to you as a checklist and verify what he received. He closes the interview himself, in so many words, once he truly has enough. A generic "continue" does even less.

**Picking competitors, when you are unsure.** Search your exact niche phrase and expect most of page one to be noise: accessories, different formats, adjacent products. The test is simple. Would a shopper typing my niche phrase see this listing and consider it instead of mine? A fondue pot is not a chocolate fountain even though both say fondue, and its table stakes are not yours. One off niche competitor tilts every conclusion after it. Wonka runs this check himself before analysing and will drop one and ask for a replacement. Fewer than three genuinely relevant competitors and the station stays blocked, which is correct.

Then verify the artifact exists. Start this habit now, because you will use it in every room:

```
Show me the status.md you just created, and list the folders inside my
product's folder.
```

You should see the station tracker with five stations, your owner intel recorded, and the full set of subfolders: 1-inputs, 2-reference, research, brief, images, edits, final, aplus, variations, incumbent, scorecards, tests.

## MISSION 3: Read the analysis, and push back

The analysis lands as a summary on screen and six files on disk: five research files plus `research/product-report.md`, the one unified report every later room reads and the Day 3 brief is built from. Read all six. This is the enjoyable part and it is also where you earn your money, because you know things the data cannot see.

Read in this order:

1. `reviews.md`, for the pain points and the exact customer language
2. `competitors.md`, for the whitespace and their best frame
3. `insights.md`, for the table stakes and the funnel diagnosis
4. `persona.md`, for who you are actually talking to
5. `selling-points.md`, last, because it summarises all four

React out loud. This is a conversation, not a report you file:

```
Correction: [what he got wrong, or what the data cannot see. For example:
"our buyers are mostly repeat gift buyers in their fifties, the persona
skews far too young"]
```

He revises the file, records the correction and its source, and tells you what it changes downstream.

Read the whitespace section twice. That is where your set finds its unfair advantage. And do not only collect their weaknesses. Note their STRONGEST frame too, because a rival's best image is a benchmark you brief your set to match and then beat, rather than something you discover halfway through the bootcamp when somebody pastes it into the group.

**Share the whitespace:** post yours to the bootcamp group. Watching a room full of sellers each find the gap nobody in their niche is filling is half the education here.

## MISSION 4: Interrogate the selling points checklist

This is the most important artifact of the day. Every table stake, every real differentiator, every quality signal, every pain point your product genuinely solves, every whitespace opening. Each with an ID, each with a source, and two empty columns at the end, Mapped to and Skipped because, that the brief fills on Day 3.

```
Show me the selling-points checklist. For each point, tell me where it came
from: competitors, reviews, the listing, or my owner intel. Flag anything
you inferred rather than sourced.
```

Then check three things yourself:

1. **Is anything missing that YOU know matters?** Especially from your owner intel. Make sure it survived into the checklist.
2. **Is anything on it that is not actually true of your product?** Kill it now, loudly. A false selling point becomes a false image, then a return, then a one star review.
3. **Is anything vague?** "High quality" is not a selling point. "The front legs adjust so it sits level and the chocolate does not pool to one side" is.

And look for the quiet gold: a spec your product already has that answers a complaint buyers are making, and that nobody has ever put in an image. Those exist on most listings and they are free.

## MISSION 5: Get your funnel diagnosis

```
Give me the funnel diagnosis in one line: is my problem the click (main
image) or the close (gallery and A plus), and what is the evidence?
```

If you have Brand Registry, hand over the real thing first:

```
Here is my Search Query Performance export and my return reasons.
[attach the exports]
Diagnose the funnel from this, and turn the return reasons into creative
fixes.
```

If you do not, say so plainly and let him reason from public signals with the result marked `estimated`. That is what the demo run does, and it is what most sellers will do.

One trap inside return reasons: not every complaint is a creative job. "Arrived cracked" is packaging, and no image will save it. "Not as described" and "smaller than I expected" are yours entirely, and each maps to a specific frame. Sort them, and fix the ones that are actually yours.

---

## What a good Product Report looks like

- **Table stakes name their confirmation type.** Double confirmed items say so, single source items say so. If everything is presented with equal confidence, push back.
- **Every claim traces to a source.** Reviews, the listing, a competitor gallery he actually looked at, or your owner intel. Nothing else.
- **The customer language section quotes real phrases**, verbatim, in buyers' words. Those phrases are future image copy. Marketing language in that section means the reviews input was thin.
- **The whitespace list is specific and mapped.** "Nobody shows how to get a full cascade, and the top complaint is that it does not flow" is whitespace. "Better branding" is not.
- **One best frame is named**, with a concrete move to beat it.
- **The persona has a fear and a dream outcome**, both traceable to review lines.
- **The diagnosis states its evidence and its confidence.** If it is estimated, the file says estimated.
- **The checklist has IDs, sources, and two unfilled columns: Mapped to and Skipped because.**

## What a weak run looks like, and what caused it

| What you see | What actually went wrong |
|---|---|
| The digest reads like a generic category article | Thin reviews input. Paste 10 more critical reviews and say `Re-run the analysis with these reviews.` |
| Table stakes feel wrong or oddly broad | An off niche competitor got in. Ask `List the competitors you analysed. Are they all genuinely [my niche phrase]?` and swap the impostor |
| No real pain points, everything is positive | You copied the reviews from the product page. Log in, sort by Critical, take those |
| The persona could be anyone | No demographics and thin reviews. Push back with what you know, or export ASIN level demographics if you have Brand Registry |
| The whitespace list is vague | He did not actually see the galleries. Drop the gallery screenshots into `1-inputs/competitors/` and ask him to redo the teardown from the images |
| A confident claim you cannot place | Ask `Where did that come from?` Anything untraceable gets deleted, not softened |

## Common mistakes

**He registered my product and then stopped dead.** That is the design, not a bug. He hands you the list and parks until the basket is full. Go and collect, then come back and tell him what you brought. Coming back in a new conversation is fine: he reads the floor at session start, sees RESEARCH in progress, and picks up at the interview.

**He is stuck waiting and will not move.** Working as designed. Name the missing item in plain words: "I have no critical reviews, proceed without them." That is a waiver, he records it and continues. A generic "just go" is not a waiver.

**He cannot open your competitor listings.** Browsing is not always available. Screenshot their full image galleries into `1-inputs/` and tell him they are there. Everything YOU bring lives in `1-inputs/`; `research/` is where WONKA writes his six analysis files, and mixing the two makes it impossible to tell later what was evidence and what was his reading of it. He reads images with vision. He must never analyse a competitor from memory, and if he offers to, stop him.

**Your product is new and has almost no reviews.** Mine your competitors' reviews instead. Copy their top and critical reviews into the file and tell him plainly: my listing is new, these are competitor reviews, use them for pain point mining. Buyer pain in the niche is buyer pain in the niche.

**Your product is not live yet.** Give a product description instead of an ASIN. He records `live: no` and everything else runs the same way.

**You have no Brand Registry.** That is a first class answer, not a failure. The persona and the demographics get labelled `estimated`, the diagnosis is made from public signals, and both upgrade the day real data exists.

Anything else: `guides/troubleshooting.md`.

---

## Before the next room, 10 to 15 minutes

The Brief Room is next: tomorrow Wonka takes everything the Research Room learned and writes the creative brief for your whole package. The Reference Room and your brand kit come the day after, on Day 4. Both days go faster if you do three things now.

1. **Confirm your photos are in `2-reference/photos/`.** All angles, the hand for scale shot, and label close ups. Ask him:
   ```
   Check my 2-reference/photos folder. Do you have everything you need to
   build the reference sheet on Day 4?
   ```
   If a shot is missing, take it now. It is twenty minutes of your life and it sets the quality of every image after it.
2. **Gather your brand assets.** Logo file, transparent background if you have one. Your brand colours, hex codes if you know them, though "the green on our label" also works. Any real certifications or press mentions, with proof.
3. **Re read your whitespace section and your checklist.** Come to the next rooms with an opinion. You will be a far better editor for having slept on the research.

## What good looks like, on disk

- [ ] `/meet-my-product` ran to completion and your product folder exists with all its subfolders (1-inputs through tests)
- [ ] `status.md` exists with the station tracker, your owner intel recorded verbatim (or explicitly marked none given), and an empty Blocked on list
- [ ] The basket landed in the right folders: `competitors/` (galleries plus a URL file) and `notes.txt` in `1-inputs/`, your product and packaging photos in `2-reference/photos/`, your logo and brand files in `2-reference/brand/`. No hand-copied reviews unless you are running without Genrupt
- [ ] All five research files exist on disk with real content: `insights.md`, `reviews.md`, `persona.md`, `competitors.md`, `selling-points.md`
- [ ] `research/product-report.md` exists, the unified report the Day 3 brief is built from
- [ ] Every competitor was confirmed as genuinely your niche, and the check is stated in `competitors.md`
- [ ] You sent at least one correction and he recorded it
- [ ] You read the selling points checklist and checked it for missing, untrue, and vague
- [ ] You have a funnel diagnosis, honestly labelled, and you agree with it
- [ ] You know your whitespace, and you have named their best frame and your move to beat it
- [ ] RESEARCH shows `done` in `status.md`
- [ ] Homework: product photos confirmed complete in `2-reference/photos/`, brand assets gathered

Next: the Brief Room. Wonka turns today's research into one creative brief for your whole package, and you edit it like the owner you are. The Reference Room and your brand kit follow on Day 4. Measure twice, invent once.

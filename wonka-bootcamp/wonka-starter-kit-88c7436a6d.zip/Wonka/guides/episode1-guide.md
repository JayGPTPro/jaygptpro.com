# Day 1: The Front Gate

Today you meet your Creative Director, tour the factory he runs, cut five keys, warm up his two
machines, and print the first thing that comes off the line.

**Do the first two lessons before you install anything.** They ask nothing of you. You watch, you
meet Wonka, you see all ten rooms, and then the setup in Lessons 4 and 5 has a point. Lesson 3
is the five-minute bridge: the the connector and the key (a connector you plug once, a key you guard),
so nothing in the setup feels like jargon. Nothing here is hard.
One thing is easy to skip and expensive later, the OpenAI organization verification, so it is
flagged everywhere.

By the time you close the laptop tonight, the factory is live and standing empty, waiting for the
product that walks in tomorrow.

**The sentence for the day: you are not learning a tool today, you are hiring somebody.**

## What you will have by the end of today

- A clear picture of who Wonka is, where he lives, and what he does without asking you
- Claude installed, with the kit folder open, and Wonka answering in character
- A Genrupt account, activated (first month covered by your ticket, claimed with a coupon)
- An OpenAI API key created, funded, and its one time organization verification underway or done
- Your pilot product chosen and photographed properly
- Both machines connected and verified by Wonka himself, with your credit fuel gauge read out loud
- Your factory's First Candy printed: a welcome card that cost a few cents and proved your whole
  image pipeline works
- Your ASIN, your full listing URL, your brand and your niche phrase written down, ready for the
  morning. Day 2 opens by registering your product, and those four answers are the first thing it
  asks for

**Time needed:** about ninety minutes, and most of it is waiting for downloads and taking photos.
The video is 33 minutes across five lessons.

**A word on cost before you start.** Your ticket covers your first month of Genrupt: 1,000 credits, claimed with a coupon at signup. It is a monthly plan, so you enter a card and
month one is free; cancel during that month and it will not renew, or keep it at $49 against $99 on
open sale. You bring your own
Claude Pro or Max subscription, which is separate, and your own OpenAI credit for the image edits
and the Tasting Rooms: cents per edit, a few dollars per race, and the bootcamp runs two races (one
Tasting Round: the main race and the gallery race). Ten to twenty dollars covers it. That is the entire bill. There is
no survey tool to buy and no research extension to install, because the Tasting Room runs inside the
factory and the Research Room runs on your own listing, reviews, and competitors.

---

---

## Lessons 1 and 2: Meet Wonka, and meet the factory

*Watch only, about 13 minutes. Nothing to do yet.*

**Do not install anything yet.** Lessons 1 and 2 are the two lessons where you sit back.

### Who you just hired

The single most useful idea in the whole bootcamp, and the one that confuses everybody at first:

> **Your employee is a folder.**

Not a metaphor. It is a folder on your Desktop. Inside it there is a character file that says who he
is, a set of skills that are things he knows how to do, and a factory of folders where his work
lives. **The folder you open in Claude Code is the employee you are talking to.** Open the Wonka
folder, you are talking to Wonka. That is the whole trick.

No app to log into. No dashboard, no website, no seat to buy. Copy the folder and you copy your
Creative Director.

The other thing to take from Lesson 1 is the working relationship, because it decides how this feels
all week:

| He does this on his own | He stops and waits for you |
|---|---|
| Research and analysis | Anything that spends money, with the cost shown first |
| Generating from an approved brief | Approving the brief itself |
| Quality checks on everything he makes | Choosing which candidates go to testing |
| Fixing small defects | Picking the final winner |
| The paperwork and the provenance | Anything that touches your live listing |

You talk to him the way you talk to your photographer and your graphic designer. **He does the work.
You approve it.**

### The building you now own part of

Ten rooms, one per day. Underneath them, five stations that are the actual method: **Research,
Brief, Invent, Inspect, Prove.**

| Day | Room | What comes out |
|---|---|---|
| 1 | The Front Gate | A live factory, both machines warm |
| 2 | The Research Room | What your buyers actually complain about |
| 3 | The Creative Brief | Your whole product page, planned |
| 4 | The Reference Room | The machines know YOUR product, proved by a test |
| 5 | The Main Image Room | A tray of candidates, your pick, and the quality loop |
| 6 | The Secondary Images Room | The gallery, built as a team |
| 7 | The A Plus Room | The second page under your bullets |
| 8 | The Tasting Room | A hundred tasters vote, twice |
| 9 | The Variations Room | One winner becomes a shelf |
| 10 | The Improvement Loop | Ship, and the factory gets smarter |

Two things repeat through the whole building. **The quality loop**, learned properly on Day 5 and
then running every day after. And **the learning loop**, which is why your second product costs a
fraction of your first.

---

## Lesson 3: The connector and the key

You are about to plug two machines into Wonka. They do not use the same socket, and knowing the
difference is the whole trick. Five minutes here and nothing in the next two lessons feels like
jargon.

**Socket one: the connector.** Genrupt plugs in as a CONNECTOR, on the Connectors screen inside
Claude. You add it once, approve it, and from that moment Wonka operates the machine himself: you
never visit Genrupt to make an image, Wonka reaches through the connector and drives it for you.
The technical name for this kind of plug is **MCP**. Every time a guide says MCP it means exactly
this, a connector on the Connectors screen. That is the whole mystery.

**Socket two: the API key.** OpenAI plugs in as a KEY, and it is a different animal. ChatGPT, the
thing you may already pay for, is a chat for PEOPLE. An API key is a door for SOFTWARE: it lets a
program, Wonka in our case, use the same machines directly, with no chat window. Three things
follow from that, and they explain everything odd about the next lesson:

- **It has its own balance**, separate from any ChatGPT subscription, loaded in dollars and spent
  in cents. Paying for ChatGPT gives the key nothing.
- **It is a password.** Anyone holding the key can spend your balance, which is why Wonka stores it
  in a local file and never prints it back at you.
- **It is made once and shown once**, at platform.openai.com. You copy it into the kit and forget
  it; Wonka does the remembering.

| | Connector (Genrupt) | API key (OpenAI) |
|---|---|---|
| Where it lives | The Connectors screen in Claude | A `.env` file inside the kit |
| How often you touch it | Once, then never | Once, then never |
| What it feels like | Plugging in an appliance | Handing over a spare key |
| What Wonka does with it | Drives the image factory | Runs edits and the Tasting Room |

That is the entire lesson. Two sockets, one of each. Now the keys.

---

## Lesson 4: The five keys

*About 45 minutes, most of it waiting.*

### Key 1: Claude Pro or Max, plus the app

The room your employee lives in. The free plan does not give you what this bootcamp needs, so
upgrade before going further. Install Claude Desktop.

Claude Code in the terminal works identically if you prefer it.

### Key 2: The kit, on your Desktop

1. Download `wonka-starter-kit.zip` from today's room
2. Unzip it to your **Desktop**, not Downloads
3. Open Claude Desktop, go to the **Code** tab, and open the `Wonka` folder
4. **Do not chat yet.** That is Lesson 5

Have a look inside while you are there. `.claude/` holds his character and his sixteen skills.
`factory/` is where all his work will live. `guides/` is this. That folder is the employee.

### Key 3: Your Genrupt account (signup only today)

Genrupt is the image machine, and the reason it gets a dedicated machine instead of any generic
image AI is one thing: **it locks your real product.** Generic models will happily draw something
that resembles your item. On Amazon that is worthless.

Use the bootcamp link from your welcome email or today's room, because that is what attaches your
included access. Confirm your email, sign in once, and leave. You connect it in Lesson 5.

Click by click: `downloads/genrupt-account-setup.md`.

### Key 4: Your OpenAI API key, and the verification that bites later

One key, four rooms: the Main Image Room, where the OpenAI Blast runs beside Genrupt's on Day 5;
the Variations Room's edit path on Day 9; the Fixing Room where edits cost cents; and the Tasting
Room where about a
hundred tasters cost a few dollars.

1. Go to **platform.openai.com** and sign in. This is a different thing from a ChatGPT subscription
2. **API keys**, then **Create new secret key**. Copy it immediately, it is shown once
3. Save it somewhere safe. Never paste it into a chat, a screenshot, or a screen recording
4. **Start organization verification NOW.** Settings, Organization, Verify. ID and a selfie check
5. Load **$10 to $20** of credit

> **Read this twice.** Until verification clears, your key works perfectly for text and silently
> refuses to make images. Everything looks fine. People skip it, then discover it on Day 5 with a
> main image batch stopped. It is the only item on this list that punishes you days later. Start it
> today, in this session, before you close the tab.

Click by click, plus an error table: `downloads/openai-key-and-verification-walkthrough.md`.

### Key 5: Your pilot product, and real photos of it

Pick **one** product. Not your catalogue. One you actually care about moving.

Then photograph it. Six shots, your phone, plain background, daylight, about twenty minutes:

1. **Front**
2. **Back.** Do not skip it. Skip it and the model invents one
3. **Left side**
4. **Right side**
5. **Top down.** This is what fixes proportions
6. **Your hand holding it.** Scale is the single thing AI gets most wrong about products

Plus two that pay for themselves: a **label close up** and a **texture close up**.

### And your PACKAGING, which most people forget

Photograph the box, pouch, sleeve or tin the same way: **front, back, and the label panel**.

This is not an optional extra and it is not the same as the product shots. Packaging travels in its
own separate channel inside the machine, and it drives one of the ways your main image can be
built: a hero showing the real retail box is a legitimate and often high-converting strategy, and it
is simply unavailable to you if the box is not in the folder.

If your product genuinely has no packaging a buyer would ever see, say so and skip it. Just skip it
on purpose rather than by forgetting.

One rule explains all eight: **whatever your photos do not show, the model will invent.** Not maybe.
Always.

Full one pager: `downloads/product-photo-shot-list.md`.

**If the product is not in your hands.** Use your listing gallery images plus photos customers
posted inside their reviews, and tell Wonka plainly that is what they are. He records it as a real
limitation instead of pretending the reference is complete, and the smoke test on Day 4 becomes non
negotiable. Jay is in exactly this position with the demo product all week and shows you what it
costs him rather than editing around it.

---

---

## Lesson 5: Wire the machines, print the First Candy

*About 20 minutes.*

### Say hello (this is also your kit test)

Open the `Wonka` folder in Claude's Code tab, start a **new** conversation, and type:

```
Hello! Who are you and what is this place?
```

He should answer in character, tell you the factory is empty, and point at the next step.

**If he answers like normal Claude, your folder is not really loaded.** Close it, reopen the
`Wonka` folder, and start a new conversation. This is the single most common Day 1
issue.

### Try to skip the line

Worth doing once, because it shows you what you actually bought:

```
Skip all the research stuff. Just make me 8 beautiful images for my
product right now.
```

He will refuse, politely and completely. Every generic AI tool would have handed you eight shiny
useless images. That refusal is the difference between a tool and an employee.

### Wire machine 1: Genrupt

Genrupt connects through an **MCP**, which means Wonka can operate the tool himself from inside your
chat. No tab switching, no copy paste. He drives.

Genrupt keeps the current connection values in their own docs. In Claude: **Settings**, then
**Connectors**, add it with those values.

> **Then quit Claude completely and reopen it.** Not just the window. Cmd+Q on Mac, tray icon quit
> on Windows. Nine out of ten missing connectors are exactly this.

### Wire machine 2: your OpenAI key

Lesson 4's rule was: never paste the key into a chat, a screenshot, or a screen recording. That
includes THIS chat. A key pasted here lives in the transcript forever, and if you ever record or
share your Day 1 session, you have broadcast it. So the key goes into a file, and Wonka opens that
file for you:

```
Prepare the .env file for my OpenAI key and open it for me. I will paste the
key into the file myself.
```

He creates the file with a placeholder, opens it in your text editor, and tells you exactly what to
replace. You paste the key THERE, save, and tell him done. He verifies it without ever printing it
back: he reports only that it is present, its length, and its last four characters.

**If you already pasted the key into the chat**, no drama, one fix: let Wonka store it, then go to
platform.openai.com, API keys, revoke that key and make a new one, and wire the new one through the
file. Thirty seconds, and the transcript now holds a dead key.

### Third machine: Python

Three of the factory's rooms run real code on your own computer. The Main Image Room runs the
OpenAI Blast on Day 5, the Tasting Room scores a hundred tasters on Day 8, and the Variations Room
measures drift on Day 9. All three are Python. **A Mac already has it**, so for most people this is
a thirty second check and nothing to install. Paste this and read the answer:

```
python3 -c "import sys,importlib.util; v=sys.version_info; print('python','.'.join(map(str,v[:3])),'OK' if v>=(3,9) else 'TOO OLD, need 3.9+'); [print(m, 'ok' if importlib.util.find_spec(m) else 'MISSING') for m in ('openai','numpy','PIL','dotenv')]"
```

On Windows, type `python` instead of `python3`.

- **`python 3.9` or higher, and four `ok` lines.** Nothing to do. Carry on.
- **Anything says MISSING.** One line fixes all four:
  `python3 -m pip install openai numpy pillow python-dotenv`
- **TOO OLD, or the command is not found at all.** Install Python from python.org. On Windows, tick
  **"Add Python to PATH"** in the installer, or the command stays not-found afterwards.

You do not need to understand any of it. You need it to answer, and Wonka checks it again in a
moment anyway.

### Let him check his own machines

The settings say connected. This factory has a rule you will hear all week: **we do not trust
labels, we verify.**

```
/machines-check
```

He runs a real handshake against Genrupt, reads your credit balance as a fuel gauge, checks the
OpenAI key is present, and gives a verdict per machine: PASS, FAIL, or SKIPPED, with the exact fix
attached to any failure.

**Every "it is not working" problem this bootcamp will ever hand you starts here.**
`/machines-check` first, then debug.

### The First Candy

A handshake cannot prove OpenAI will let your key actually make an image. Only generating can. So
when he offers it:

```
Yes, print the First Candy.
```

A few cents, one small welcome card, saved to `output/first-candy.png`. It proves the whole pipeline
end to end: key, billing, verification, generation.

**If it fails here, that is the good outcome.** Day 1, with the fix one click away, instead of Day 5
with a batch stopped. Almost always it is verification. Wonka names which machine is cold and what
to check.

That is the day. Machines verified by the employee who uses them, one print on the tray, and a
factory standing empty. Nothing is registered today, and nothing needs to be: your product walks
through the gate tomorrow, first thing, and the first thing Wonka does is tell you exactly what to
go and collect for it.

**Have five answers ready in the morning:** your ASIN, your full Amazon listing URL, your
marketplace, your brand name, and your niche in your own words ("chocolate fountain", "garlic
press"). That is the whole of what Day 2 asks for before it opens your product's folder.

---

## Common mistakes, and what they look like

| Symptom | Cause | Fix |
|---|---|---|
| Wonka sounds like a generic chatbot | The kit folder is not really loaded | Code tab, folder picker shows `Wonka`, re open it, start a NEW conversation |
| A slash command does nothing | It was described instead of typed | Type it as its own message, starting with the slash, exactly as named: `/machines-check` |
| The Genrupt machine does not appear at all | Claude was not fully quit | Cmd+Q on Mac, tray icon quit on Windows, reopen, run `/machines-check` again |
| Genrupt connects but calls fail | Session or key issue | Log in to genrupt.com in your browser once, retry. If it persists, regenerate the API key and re enter it |
| First Candy fails with a verification error | Organization verification has not cleared | platform.openai.com, Settings, Organization, Verify. Then `/machines-check` again. Your work is not blocked: the First Candy is the proof, and it waits. It has to clear before Day 5 |
| "No API key" | The key is not where Wonka looks | Redo Key 4 (Lesson 4) and its wiring (Lesson 5), then `/machines-check` |
| You cannot see the `.claude` folder | Dot folders are hidden | Mac: Cmd+Shift+. in Finder. Windows: File Explorer, View tab, Hidden items. Or just ask Wonka to show you what is in it |
| Your listing shows only about eight reviews | You are logged out | Log in and sort by most recent and by critical, or pull from Seller Central |

The full list lives in `guides/troubleshooting.md`. And if something is genuinely stuck, post the
exact error in the group. Setup friction is the one thing worth interrupting anybody for.

---

## What good looks like

- [ ] Watched Lessons 1 and 2 before installing anything
- [ ] Claude Desktop or Claude Code installed, Pro plan or higher active
- [ ] `Wonka` on your Desktop and open in Claude's Code tab
- [ ] Wonka answered "who are you" in character, and refused to skip research when you pushed him
- [ ] Genrupt account created and activated
- [ ] OpenAI key created, $10 to $20 loaded, organization verification complete or underway
- [ ] Pilot product chosen
- [ ] Product photos taken: all angles, hand for scale, label close ups (or the fallback path taken
      knowingly)
- [ ] `/machines-check` run, with both machines reporting PASS and the credit fuel gauge read
- [ ] First Candy printed at `output/first-candy.png`, or consciously deferred until verification
      clears
- [ ] Your ASIN, full listing URL, marketplace, brand and niche phrase written down for the morning

**One habit worth forming today: tell Wonka where you are in the lessons.** He will ask once which
day you have watched up to, and from then on he paces the factory with you: finish a day's work and
he points you to the next lesson before the next room, because each lesson teaches the decision
that room will ask you to make. Watched several days ahead? Say so, and he will happily run several
days of work in one sitting. This is a recommendation system, never a lock: "let's just continue"
always continues.

**Do not open Day 2 until `/machines-check` passes.** Not because anyone is strict, because tomorrow
spends real credits and a cold machine wastes them.

Every day has a list like this one, and together they are the graduation checklist. Walk all ten
and you finish with a full, tested creative package ready to upload. No sales lift is promised.
Results vary by product and niche.

---

## What this bootcamp will cost

Your ticket covers your first month of Genrupt: 1,000 credits, claimed with a coupon at signup. You bring your own Claude subscription and your own
OpenAI credit.

| Item | When | Typical cost |
|---|---|---|
| Claude Pro or Max | ongoing | $20 per month and up. Your own subscription, separate from the bootcamp |
| Genrupt | first month covered by your ticket, with the coupon | 1,000 credits, then $49 a month if you keep it ($99 on open sale), and nothing if you cancel inside the free month. On average 1,000 credits is enough for 2 to 3 products; On average that is enough for 2 to 3 products; top up at Genrupt if you burn through it |
| OpenAI credit | the fixing and tasting days | $10 to $20 loaded. Cents per edit, a few dollars per race, two races across the bootcamp |

For scale: one professionally designed listing image runs $50 to $200, and a full untested set runs
$500 to $1500. You are building the factory, not paying per candy.

A standing rule you will hear all bootcamp: Wonka never spends your money silently, and he also
never stalls the line asking you the same question twice. There is ONE pre-authorisation point,
your approval of the creative brief on Day 3. It covers the planned flow that follows it: the
reference sheet, the smoke test, and the planned generation batches. Those are REPORTED as they
run, with the cost line, not gated.

A short named list still waits for a fresh yes every single time: a 100-credit Draft Blast, any
re-spend on a slot that already produced candidates, a Tasting Round, a paid edit batch, and
anything at all when your balance will not cover it. Silence is never a yes.

---

## Common questions

**"Where does Wonka actually live? Is he installed somewhere?"**
He is the folder. Personality, skills, and memory are all files inside `Wonka`. Copy the
folder and you copy your Creative Director. Nothing else is installed.

**"Why do I watch two lessons before doing anything?"**
Because setup is boring and meaningless until you know what it is for. Meet the employee, see the
building, then cut the keys. It is fifteen minutes and it makes the rest of the day make sense.

**"Can I use Claude Code in the terminal instead of Claude Desktop?"**
Yes, fully. Open a terminal, `cd` into the kit folder, run `claude`. Every prompt in every guide
works identically. The guides describe Claude Desktop click paths because most participants use it.

**"I sell in a non US marketplace. Does this work?"**
Yes. The method is marketplace agnostic. Your reviews and competitors come from your marketplace, so
the research reflects your shelf, and the Tasting Room's panel is conditioned on your real buyer
whatever marketplace they shop in.

**"What if I have several products?"**
Pick ONE for the bootcamp. The factory happily runs a portfolio afterwards, and Day 9 shows you how
to multiply. Learning the line is a one product job.

**"Do I need Brand Registry?"**
No. It unlocks the demographics export and the optional Amazon A/B at the end. Without it, personas
are estimated and clearly labelled as estimated, and every room runs identically.

**"Why is there no survey tool to sign up for?"**
Because the Tasting Room runs inside the factory, on the same OpenAI key you already created. A few
dollars a round, results in minutes. To be straight with you about what it is: the tasters are
synthetic AI personas conditioned on your real buyer, so the verdict is directional and the real
value is the objections they hand you in their own words. It is not a panel of real shoppers, and
nowhere in this bootcamp will it be sold to you as one.

**"Can I use last week's product photos, or the ones from my listing?"**
You can, and Wonka will record the reference as built from listing imagery rather than real photos.
Expect weaker product accuracy. If the product is within reach, spend the twenty minutes.

---

## What Day 2 opens with

Exactly what you leave here holding: two warm machines and an empty floor.

Day 2 is the Research Room, and it starts at the gate. One command registers your product, reads
your listing title back to you, opens its folder inside the factory, asks you the three things only
you know, and hands you a shopping list pointing at those folders. Then he stops, and you go and
fill the basket. That collecting is the real work of Day 2 and it takes as long as it takes, an
hour or an evening.

When you come back, same day or the next, the room picks up as an interview, not a lecture. You
point at what landed in `1-inputs/` and `2-reference/`, Wonka reads every file and confirms what he
received, asks his own questions back, and then derives your market picture himself: the table
stakes, the pain points in buyers' own words, your real buyer, the whitespace nobody in your niche
is showing, and a diagnosis of where your listing is actually losing sales.

As the man says: "Every great candy starts with knowing exactly who it is for."

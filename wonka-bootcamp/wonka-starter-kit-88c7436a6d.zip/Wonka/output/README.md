# output/

Anything meant to leave the Factory lands here: your First Candy from the Machine Room, exported image sets ready for Seller Central upload, zips for your designer or VA, and shareable before/after boards. `/ready-to-upload` copies the winning tested package and `upload-pack.md` here as its final step. Working files stay in each product's folder under `factory/Products/`; this folder is only for finished, ready-to-send deliverables.

# The Frame Table, and the Three Prompt Rules

## The frame table: what each frame actually carries

Before any variant work, every frame of the tested set is classified:

- **SHAPE frames** carry the varying attribute's look. They get edited.
- **VALUE frames** print a count, a size, a fit claim. They get edited too, from the child's truth
  table.
- **Everything else is REUSED**: copied into every child untouched, because nothing in it changed.

While classifying, **count the product instances in every frame**. A four-panel grid holds four
products, and that number goes into the instruction later. Count by EYE, at zoom: a glossy finish
puts a highlight strip down each item and an automated counter reads every one as two, so a machine
count that disagrees with the zoom look is discarded, with the reason named. Then say the
arithmetic out loud: this child touches three frames, that one six, the family is this many edits
at cents each.

Shape and printed text are **two separate edit layers, never one prompt**. A frame needing both
gets them chained; ask for both in one breath and both drift.

## The three prompt rules, learned from the three repeat failures

1. **Name what it IS before what it becomes.** The hero that refuses to change shape: "The hero is
   a stack of SQUARE plates. Redraw it as perfectly circular."
2. **Count, out loud.** The group photo where only one item changed: "Replace every plate" reads as
   satisfied after one. "This is a FOUR-PANEL grid, redraw ALL FOUR."
3. **Declare the label a RIGID OBJECT.** Ask for a new shape and the model happily melts the label
   card to match: same shape, same size, same position, only the product behind it changes.

**Try two or three genuinely DIFFERENT phrasings rather than five nudges of one.** And if three
different phrasings fail the same way, stop: the problem is upstream, a missing shape reference or
a variant that is genuinely a different product.

# downloads/

The Day 1 one-pagers, the four you need before anything in the Factory can run.

- `genrupt-account-setup.md`, the image machine, click by click
- `openai-key-and-verification-walkthrough.md`, the key, the verification, and the error table
- `product-photo-shot-list.md`, the six shots, on your phone, in twenty minutes
- `front-gate-shopping-list.md`, everything your product needs in hand before Day 2

They ship inside the kit on purpose: setup has to be possible from the folder alone, before you
have opened a single portal room.

The other WORKSHEETS (reading a Tasting Card, edit versus regenerate, the approved-claims
worksheet, and the rest) arrive in their own day's room, on the day each is useful. That pacing
applies to worksheets and day materials only. The INSTRUCTIONS are different: all ten day guides
ship in the kit's `guides/` folder from day one, so Wonka can read any of them on demand whenever
you ask.

# The Three Review Questions

**They work on every creative brief, from any source, forever.** A plan review is not an approval
ritual: it is the one moment your knowledge of the product outranks the machine's research.

## Question 1: does every image have a different job?

Ask for the buyer questions alone, in order, nothing else. Listen for two that are secretly the
same question. Amazon gives you six or seven gallery slots, not twenty, so one job wearing two hats
costs you a whole frame.

## Question 2: why is this in, and that out?

Open the skipped column and make him defend every drop. When you disagree, you win: he read a
thousand reviews, but you have used the product and talked to the people who bought it.

The best version of this move is not reversing his reason, it is finding the honest version he
missed. "You dropped cleanup because the reviews split on it, and you were right that I cannot
promise easy. Bring it back as the mechanism: show the machine coming apart, promise nothing."

## Question 3: can we prove it?

Ask for every headline beside its source: a listing spec, the label, a real review, or something
you told him. **Anything sourced to nothing comes out.** Not because Amazon is scary, though it is,
but because an unprovable headline is a one star review with a two week delay.

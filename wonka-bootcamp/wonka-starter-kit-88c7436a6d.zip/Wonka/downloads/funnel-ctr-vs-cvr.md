# Reading Your Funnel: Traffic, CTR, CVR

**One question decides where your creative budget goes: is your problem being seen, the click, or
the close?**

Every listing has three doors, in order. BEING SEEN (traffic): does the product appear where
shoppers actually search? The CLICK (CTR): of the people who saw your main image in search, how
many chose it. The CLOSE (CVR): of the people who landed on your page, how many bought.

## Door zero: are you even on the shelf?

Search your primary niche phrase on Amazon and look for your product in roughly the first 20
organic results (your view carries your geography and personalization, so treat it as a signal,
not a measurement). A well-reviewed product that is nowhere in its own primary search has a
TRAFFIC problem, and **no image fixes rank**. The creative package still matters, it converts the
traffic you win back, but the first dollar goes to visibility: keywords, indexing, PPC. Build the
package so it is ready when the shoppers arrive; never buy it as the fix for absence.

## The diagnosis, once you are on the shelf

- **Low CTR, decent CVR.** People who arrive, buy. Not enough arrive. Your problem is the MAIN
  IMAGE, the only asset that competes in search. Days 5 and 8 are where your money is.
- **Decent CTR, low CVR.** People click and walk away. The page is not closing. Your problem is the
  GALLERY and the A+, the assets that sell after the click. Days 6 and 7 are where your money is.
- **Both low.** Start with the click anyway. Nobody can close a visitor who never arrived.

## Where the numbers come from

With **Brand Registry**: Seller Central, Brands, Search Query Performance. Export it, hand it to
Wonka, and add your return reasons; returns are your CVR problem written in the customer's own words.

Without it: say so plainly. Wonka reasons from public signals (rank, review count, category norms)
and marks the diagnosis `estimated`. An estimated diagnosis is a starting point, not a verdict.

## The one-line ask

```
Give me the funnel diagnosis in one line: is my problem the click (main
image) or the close (gallery and A plus), and what is the evidence?
```

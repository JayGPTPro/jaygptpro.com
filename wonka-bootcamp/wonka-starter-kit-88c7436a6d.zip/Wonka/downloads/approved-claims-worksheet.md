# The Approved Claims Worksheet

**A palette can be invented. A fact cannot.** The approved claims table is the ONLY list of
certifications, awards, spec claims and press mentions allowed onto any image the factory makes,
and every row needs proof you could show a stranger.

## Fill one row per claim

| The claim, word for word | Where it may appear | The proof |
|---|---|---|
| e.g. "USDA Organic" | Anywhere the real label shows | The certificate / the printed label |
| e.g. "10,000+ happy customers" | NOWHERE until sourced | Order history export, dated |
|  |  |  |
|  |  |  |
|  |  |  |

## The rules the table enforces

- **Proof means a document**: the label itself, a certificate, a lab report, a spec sheet, a real
  review you can point to. "Everyone knows" is not a source.
- **A claim without a row does not exist.** If it is not in the table, no image carries it, however
  good it would look.
- **Real certifications appear as they appear on the label**, never redrawn, never upgraded into a
  badge the certifier did not issue.
- **Never**: invented percentages, star ratings, review counts you cannot export, awards you did
  not win, third-party logos, flags.
- **Your logo**: if no real logo file exists, no logo is drawn, approximated or invented. Images
  carry no logo until a real file does.

One honest table beats ten beautiful lies. The compliance gate on every image reads THIS table.

# Edit versus Regenerate

**The routing that saves you the most money.** Two commands, two different jobs: `/inspect` judges
and touches nothing; `/fix` changes and judges nothing. Keeping them apart is what stops you
quietly editing an image until you like it and calling that quality control.

## Edit (cents, on your OpenAI key)

When the change is **subtraction or substitution**: remove a stray element, shorten a label, swap a
word, swap a colour. The image is right and one thing on it is wrong.

One measured exception on counts: REMOVING one surplus item from a row of identical items works as
an edit, so try it for cents before regenerating. ADDING a missing item stays a regeneration.

## Regenerate (credits, back in the image's own room)

When the change is **structural**: make the text bigger, move or resize elements, change the
layout, change who is in the picture. An edit fights the whole composition; a regeneration with a
tighter brief replaces it.

## The two lines to remember

- **"Shorten, remove, swap: edit. Bigger, move, layout, casting: regenerate."**
- **A+ modules are the one exception**: their fixes route back through the A+ Room (`/aplus`), and
  an A+ edit is not surgical, it re-renders the WHOLE concept as a new version. So all of a
  concept's fixes go in ONE call, every module gets re-read afterwards (an edit can break a module
  nobody named), and rounds cap at two per concept. Its cost is variable and unquotable in advance;
  the balance read before and after is the only truth.

## Where fixes live

`images/` holds the raw generations, write-once, never touched. Every fix round writes a COMPLETE
copy of the current set into `edits/v1/`, then `edits/v2/`, same filenames. The current set is
always the highest round; the copy in `images/` is the version you already rejected. When in doubt,
ask Wonka which folder is current, and he will name it.

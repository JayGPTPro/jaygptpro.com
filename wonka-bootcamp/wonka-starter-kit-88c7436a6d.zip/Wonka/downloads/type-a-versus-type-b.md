# Type A versus Type B

**Today's real decision, made before anything runs.** Deciding afterwards means doing the family
twice.

## The two types

**TYPE A: identical, except the variant.** A red shirt becomes a blue shirt on the same person in
the same light. Propagated as cheap surgical edits of your TESTED set, cents per frame.

**TYPE B: regenerated on the same brief.** Each child gets its own shoot: same brand, same brief,
fresh compositions.

| | Strength | Cost of the strength |
|---|---|---|
| **Type A** | A family that reads as one product in several colours. Obviously related | Can feel repetitive across many variants |
| **Type B** | Variety. The gallery feels alive | Can start to feel like different products wearing the same brand |

## Pick out loud, with a reason

The reason goes in the file. Six months from now, that line is the only thing that explains why the
family looks the way it does.

## The law either way

Before either type runs, **measure each child against ITS OWN photos**. A child is not always the
parent in another colour: one can be missing a part the parent's laws are written about, and a
parent law propagated onto it renders it wrong, confidently. A structural difference is a different
MOLD, not a variation layer, and a different mold may need its own reference.

And every printed value on every child's frame comes from THAT child's own listing (the truth
table), never carried across from the source. A 24 oz child wearing the parent's 64 oz claim is not
a style problem, it is a refund.

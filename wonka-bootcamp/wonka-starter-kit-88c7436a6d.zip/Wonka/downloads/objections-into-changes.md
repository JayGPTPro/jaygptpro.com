# Turning Objections into Changes

**Read all of them. Verbatim. Sort as you go into three piles.**

One move before sorting: split compound objections. "Cannot judge tip quality or durability" is
two objections that land in different piles, and a fix that answers only one half leaves the other
half still generating mentions.

## Pile 1: creative can fix it

They could not tell the size. They thought it was plastic. They did not see it comes apart for
cleaning. These are images that failed to communicate, and you fix them today: a hand for scale, a
material close-up, an exploded view. This pile goes straight into `/fix` MODE B.

## Pile 2: the listing can fix it, but not with an image

A question about what is in the box. A spec nobody could find. A compatibility doubt. That belongs
in your bullets or your A+, not in the gallery. Write it down and route it there.

## Pile 3: nobody can fix it

"Too expensive." "I would not use it often enough." Real, and no photograph answers it. Let it go;
a gallery that argues with this pile wastes frames the first two piles needed.

## Two weighting rules

- **Comprehension objections are the gold. Preference verdicts are the nudge.** "I could not tell
  how big it is" outranks "I liked the other one more", every time.
- **The cross-read:** the same objection appearing in BOTH races (main and gallery) is not about
  one image. It is a gap in your LISTING that your creative has not closed anywhere. Those go to
  the top of the list.

# Set Level Faults

**A gallery is judged as a TEAM, not as seven solo performers.** Seven images can each pass alone
and still fail together. After any set generation, check the set itself for these three:

## 1. Repeated messages

No two frames may argue the same point. Amazon gives you six or seven slots; one message wearing
two frames costs you a whole slot. Read the headlines aloud in order: any echo is a fault.

## 2. Repeated faces

Never the same face twice across the people-bearing frames. One person everywhere reads as a
brochure; different real people read as a product with customers.

## 3. No emotional frame

At least one frame sells the FEELING: the moment the product earns, not the spec it carries. A
gallery of seven diagrams is a manual, and nobody clicks buy on a manual.

## And the coverage map

Beyond the three faults, close the loop against the brief: every selling point from the creative
brief's checklist is either covered by a frame or consciously skipped IN WRITING. A selling point
that silently fell out of the set is how the gallery ships with a hole nobody chose.

Run `/inspect the set` for the scored version; check these three yourself as well, because they are
exactly the faults that hide between per-image scores.

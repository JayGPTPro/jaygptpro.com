# Module Count, and the Carousel

**Two deliberate decisions, made before generation, each with a recorded reason.**

## How many modules

Seven is the default and fills the page. Six or five leaves room on purpose, and the reason to
leave room is a module only YOU can build: a comparison table against the products you actually
compete with, or an FAQ carrying the questions your customers really ask. Genrupt cannot write
either, because they carry information only you have.

Generate seven, then discover there is no room for the comparison you wanted, and you are
rebuilding. **One question up front prevents it: am I adding a module of my own?**

(At five modules, the premium carousel and dense layouts are off the table; the machine downgrades
them automatically and says so.)

## The premium carousel

A distinct module type, not a fancier version of the standard ones, and it spends one of the same
module slots.

- **It earns its slot** when you have a real sequence: a before and after, steps, a range of
  variants. Something where the ORDER carries meaning.
- **It costs you** when your shopper is skimming. A static module gives everything at once to
  somebody moving fast; a carousel gives them frame one and asks for a click, and on a phone that
  click often does not come. Whatever sits in frame three may as well not exist.

The default for most products is **static**. Carousels work beautifully on things with a real
sequence to show.

## Record the reason

The reason matters more than the decision. In four months, on your third product, when you cannot
remember why this page is static, that one line is the only thing that explains it.

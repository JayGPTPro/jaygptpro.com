#!/usr/bin/env python3
from __future__ import annotations   # PEP 604 annotations must stay lazy on Python 3.9

"""One contact sheet from a folder of gallery images.

Why this exists as a named tool: reading a competitor's gallery one file at a
time is slow and costly enough that sessions quietly degrade to "the main
image plus a glance", and a teardown built on main images alone is a polite
guess. One labeled sheet per competitor keeps the whole gallery in a single
read, at about a sixth of the cost, and set-level patterns (repeated
messaging, one shared palette) only become visible when the frames sit side
by side anyway.

Usage:
    python3 contact_sheet.py <folder-of-images> [--out sheet.jpg] [--cols 4] [--tile 480]

Reads every image in the folder (not recursive), lays them out row-major in
filename order with the filename printed under each tile, writes one JPEG.
"""
import re
import sys
from pathlib import Path

try:
    from PIL import Image, ImageDraw
except ImportError:
    sys.exit("this needs Pillow: python3 -m pip install pillow")

EXT = (".jpg", ".jpeg", ".png", ".webp")
LABEL_H = 26


def natural(p: Path):
    return [int(t) if t.isdigit() else t.lower() for t in re.split(r"(\d+)", p.name)]


def build(folder: Path, out: Path, cols: int = 4, tile: int = 480) -> Path:
    files = sorted((f for f in folder.iterdir() if f.suffix.lower() in EXT and f.is_file()),
                   key=natural)
    if not files:
        sys.exit(f"no images in {folder}")
    rows = (len(files) + cols - 1) // cols
    sheet = Image.new("RGB", (cols * tile, rows * (tile + LABEL_H)), "white")
    draw = ImageDraw.Draw(sheet)
    for i, f in enumerate(files):
        im = Image.open(f).convert("RGB")
        im.thumbnail((tile - 8, tile - 8), Image.LANCZOS)
        x = (i % cols) * tile
        y = (i // cols) * (tile + LABEL_H)
        sheet.paste(im, (x + (tile - im.width) // 2, y + (tile - im.height) // 2))
        draw.text((x + 6, y + tile + 5), f.name[:52], fill=(60, 60, 60))
    out.parent.mkdir(parents=True, exist_ok=True)
    sheet.save(out, "JPEG", quality=85)
    return out


def main():
    args = sys.argv[1:]
    if not args:
        sys.exit(__doc__)
    folder = Path(args[0])
    if not folder.is_dir():
        sys.exit(f"not a folder: {folder}")
    out = Path(args[args.index("--out") + 1]) if "--out" in args else folder / "contact-sheet.jpg"
    cols = int(args[args.index("--cols") + 1]) if "--cols" in args else 4
    tile = int(args[args.index("--tile") + 1]) if "--tile" in args else 480
    p = build(folder, out, cols, tile)
    print(f"wrote {p}")


if __name__ == "__main__":
    main()

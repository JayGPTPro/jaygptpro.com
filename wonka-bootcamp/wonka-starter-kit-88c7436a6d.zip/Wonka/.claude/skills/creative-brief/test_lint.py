"""Regression tests for the two lint rules that fired on the wrong text.

The linter reads a brief and refuses to pass one that breaks a house rule. Its
own message says "Fix the BRIEF, never the linter", so a rule that fires on
COMPLIANT text is worse than no rule: it teaches the owner to ignore the gate,
or to delete the correct avoid list to satisfy it.

A brief is REQUIRED to restate its avoid list and to say the main image is
product only with no people. Both of those name the forbidden thing in order
to forbid it. Before the fix, a brief written exactly to the skill's own output
template failed with six errors, every one of them on its own guardrail text.

Both directions are asserted here, because a fix that only silences the false
positives would also stop catching real violations. Every test was watched to
fail against the pre-fix linter before it was kept.

Run: python3 test_lint.py
"""
import subprocess
import sys
import tempfile
from pathlib import Path

LINT = Path(__file__).parent / "brief_lint.py"
FAILURES = []


def lint(md):
    """Run the linter on a brief and return (exit_code, error_lines)."""
    with tempfile.TemporaryDirectory() as d:
        p = Path(d) / "brief.md"
        p.write_text(md, encoding="utf-8")
        r = subprocess.run([sys.executable, str(LINT), str(p)],
                           capture_output=True, text=True)
    errors = [ln.strip() for ln in r.stdout.splitlines() if "ERROR" in ln]
    return r.returncode, errors


def check(name, cond, detail=""):
    if cond:
        print(f"  PASS  {name}")
    else:
        print(f"  FAIL  {name}  {detail}")
        FAILURES.append(name)


HEAD = ("# Creative Brief . Test Product\n"
        "Built from: research/insights.md (2026-01-01). Written 2026-01-01.\n"
        "Owner review: PENDING\n\n")

# A brief written exactly per the skill's output template: the main section
# carries the mandated "product only, no people, zero overlay text" line, and
# the avoid list restates the standing compliance items by naming them.
COMPLIANT = HEAD + """## Main image
Tactic: product-only hero. Hang-tag text: none. Packaging preference: unboxed.
Product only, no people, zero overlay text.

## Avoid list (restated)
- No star rating graphics and no five-star badges of any kind.
- Never render "clinically proven" or "FDA-approved" as text.
- No "as seen on" banners, no verified buyer callouts.
"""

# The real thing the rules exist to catch: the brief ASSERTING these.
VIOLATING = HEAD + """## Main image
Tactic: hero with a woman holding the product, smiling.
Headline overlay: clinically proven to last longer.

## Secondary slots
### Slot 2
Message: 4.8 out of 5 from verified buyer reviews.
Composition: badge reading "as seen on" television.
"""

# The coverage map exactly as the skill's output template writes it. The
# skipped row carries a reason and a bare dot in "Mapped to", and it never
# uses the word "skipped", which is why a keyword scan used to find nothing
# and the rule silently did not exist.
MAP = """## Selling-points coverage map (full package)
| ID | Selling point | Mapped to (MAIN criterion / S# / A+ / Variation) | Skipped because |
|---|---|---|---|
| SP1 | dishwasher safe basket | S2 | |
| SP7 | replacement filters arrive cracked | . | creative cannot fix it: packaging owns it |
"""

# A slot claiming the point the map consciously dropped.
RESURFACED = HEAD + MAP + """
## Secondary slots
### Slot 2
Message: "Filters arrive safe"
Composition: the replacement filters shown intact in their sleeve.
"""

CLEAN_MAP = HEAD + MAP + """
## Secondary slots
### Slot 2
Message: "Basket lifts out"
Composition: the basket held clear of the body.
"""

# People in a slot, with and without an avatar pinned to a real age + gender.
PEOPLE_UNPINNED = HEAD + """## Set structure
| Slot | Job | Message (max 6 words) | People |
|---|---|---|---|
| S1 | in use | "Ready in minutes" | yes |

## Genrupt handoff

### Cast (customAvatars, 1 to 2)
- Avatar 1: label "home cook", description "weeknight cook",
  age "[DISPLAYED age, aspirational skew applied]", gender "[...]"
"""

PEOPLE_PINNED = HEAD + """## Set structure
| Slot | Job | Message (max 6 words) | People |
|---|---|---|---|
| S1 | in use | "Ready in minutes" | yes |

## Genrupt handoff

### Cast (customAvatars, 1 to 2)
- Avatar 1: label "home cook", description "weeknight cook",
  age "52", gender "female"
"""

# Audit 23.8, item 5, both halves. A banned claim ASSERTED inside a plain
# "## Notes" section (the old GUARDRAIL_SECTION regex matched the bare word
# "note" and exempted the whole section); and a MAPPED row whose fourth cell
# carries an annotation (the old column reader treated any reason text as a
# conscious skip, so the mapped slot then "revived" its own point).
NOTES_ASSERTS = HEAD + """## Notes
The product is clinically proven to melt chocolate faster.

## Main image
Tactic: product-only hero.
Product only, no people, zero overlay text.
"""

MAPPED_WITH_ANNOTATION = HEAD + """## Secondary slots

### Slot 1. Capacity
Shows the large capacity party bowl feeding four tiers.

## Coverage map
| ID | Selling point | Mapped to | Skipped because |
|---|---|---|---|
| 1 | Large capacity party bowl | Slot 1 | see styling note |
"""

print("brief_lint regression")

code, errs = lint(COMPLIANT)
check("a template-faithful brief passes", code == 0 and not errs,
      f"got {len(errs)} error(s): {errs}")

code, errs = lint(VIOLATING)
check("a brief asserting banned claims still fails", code == 1 and errs,
      "the violating brief passed, the rule is now toothless")
blob = " ".join(errs).lower()
check("  ... and still names the person in the main", "no-people-in-main" in blob, blob)
check("  ... and still names the banned claims", blob.count("compliance-avoid") >= 3, blob)

code, errs = lint(RESURFACED)
blob = " ".join(errs).lower()
check("a slot reviving a consciously skipped point fails",
      "skipped-is-a-negative-constraint" in blob, blob or "no error raised")

code, errs = lint(CLEAN_MAP)
blob = " ".join(errs).lower()
check("  ... and a slot on a MAPPED point does not",
      "skipped-is-a-negative-constraint" not in blob, blob)

code, errs = lint(PEOPLE_UNPINNED)
blob = " ".join(errs).lower()
check("a people slot with an unpinned avatar fails",
      "casting-is-structured" in blob, blob or "no error raised")

code, errs = lint(PEOPLE_PINNED)
blob = " ".join(errs).lower()
check("  ... and an explicit age plus gender passes",
      "casting-is-structured" not in blob, blob)

code, errs = lint(NOTES_ASSERTS)
blob = " ".join(errs).lower()
check("a banned claim inside a plain Notes section fails",
      "compliance-avoid" in blob, blob or "no error raised")

# The controls subsection MUST name every tactic with a reason, so a line that
# forbids people ("a hand in a main is a compliance risk") is exactly what
# belongs there. The first linter scanned it and punished a correct brief for
# stating the rule it enforces (measured live); a person in the BRIEF half
# must still fail.
CONTROLS_COMPLIANT = HEAD + """## Main image
### The brief
The hero: the full set fanned on white, product only, zero overlay text.

### The controls
Enabled: hang_tag. human_contact stays OFF for this category: a hand in a
main image is a live compliance risk in fine-art tools. packaging_expansion
OFF: the box is generic. genrupt_choice ON.

## Avoid list (restated)
- No star rating graphics and no five-star badges of any kind.
"""

CONTROLS_BUT_BRIEF_VIOLATES = HEAD + """## Main image
### The brief
The hero: a woman holding the brush set, smiling at the camera.

### The controls
Enabled: hang_tag. human_contact stays OFF: a hand in a main is a compliance risk.

## Avoid list (restated)
- No star rating graphics and no five-star badges of any kind.
"""

code, errs = lint(CONTROLS_COMPLIANT)
blob = " ".join(errs).lower()
check("naming human_contact with its reason in The controls is NOT a people hit",
      "no-people-in-main" not in blob, blob or "clean")

code, errs = lint(CONTROLS_BUT_BRIEF_VIOLATES)
blob = " ".join(errs).lower()
check("a person in the BRIEF half still fails, controls or no controls",
      "no-people-in-main" in blob, blob or "no error raised")

code, errs = lint(MAPPED_WITH_ANNOTATION)
blob = " ".join(errs).lower()
check("a mapped row with a fourth-cell annotation is not a skip",
      "skipped-is-a-negative-constraint" not in blob, blob)

print()
if FAILURES:
    print(f"{len(FAILURES)} FAILED: {', '.join(FAILURES)}")
    sys.exit(1)
print("all passed")

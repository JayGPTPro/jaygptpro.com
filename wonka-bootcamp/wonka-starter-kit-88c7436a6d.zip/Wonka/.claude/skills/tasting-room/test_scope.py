#!/usr/bin/env python3
"""Which files a Tasting Round actually races.

The Fixing Room writes each round as a complete set snapshot into `edits/vN/`
and surgical edits KEEP the filename, so the same name exists in `images/` and
in every round. Before this was fixed, `scope.derive()` returned bare names,
every caller joined them to `images/`, and a round run after a fix round raced
the SUPERSEDED files while the pack shipped the fixed ones.

Nothing caught it in review, and no name-based guard ever could: the two sets
have identical filenames by design, so comparing names compares equal. That is
why this test compares FILE CONTENT.

Run: python3 test_scope.py
"""
import sys
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

FAILURES = []


def check(name, cond, detail=""):
    print(("  PASS  " if cond else "  FAIL  ") + name + ("  " + str(detail) if not cond and detail else ""))
    if not cond:
        FAILURES.append(name)


def build(rounds_spec):
    """A product folder whose every file carries its own origin as content."""
    tmp = (Path(tempfile.mkdtemp()) / "fondue").resolve()
    (tmp / "images").mkdir(parents=True)
    (tmp / "incumbent").mkdir(parents=True)
    for n in ("main-01.png", "sec-01.png", "sec-02.png"):
        (tmp / "images" / n).write_bytes(b"OLD")
    (tmp / "incumbent" / "main-live.png").write_bytes(b"x")
    for rnd, names in rounds_spec.items():
        d = tmp / "edits" / rnd
        d.mkdir(parents=True)
        for n in names:
            (d / n).write_bytes(rnd.encode())
    return tmp


def run():
    import scope

    def origin(s, name):
        return Path(s["paths"][name]).read_bytes().decode()

    t = build({"v1": ["main-01.png", "sec-01.png", "sec-02.png"]})
    s = scope.derive(t)
    check("after a fix round, the race reads edits/v1 and not images",
          origin(s, "main-01.png") == "v1", origin(s, "main-01.png"))

    t = build({"v2": ["main-01.png"], "v10": ["main-01.png"]})
    check("v10 beats v2, so rounds are ordered numerically and not as strings",
          origin(scope.derive(t), "main-01.png") == "v10",
          origin(scope.derive(t), "main-01.png"))

    t = build({"v1": ["sec-01.png"]})
    s = scope.derive(t)
    got = (origin(s, "main-01.png"), origin(s, "sec-01.png"), origin(s, "sec-02.png"))
    check("a round that touched one frame moves ONLY that frame",
          got == ("OLD", "v1", "OLD"), got)

    t = build({})
    check("a product with no edits/ still resolves to images/",
          origin(scope.derive(t), "main-01.png") == "OLD")

    t = build({"v1": ["main-01.png"]})
    s = scope.derive(t)
    check("every raced name carries a resolved path",
          set(s["paths"]) == set(s["main"]) | set(s["gallery"]), sorted(s["paths"]))

    print()
    # --- a main is whatever is not the gallery ------------------------------
    # Draft Blast winners arrive carrying the short pick id they won under
    # (m26, m51). Filtering FOR names starting with "main" dropped the entire
    # main race and printed "MAIN RACE owes nothing" over four gate-passed
    # candidates. Measured 27 August 2026 on the live student run.
    import tempfile as _tf
    from pathlib import Path as _P
    t2 = (_P(_tf.mkdtemp()) / "brushes").resolve()
    (t2 / "images").mkdir(parents=True)
    (t2 / "incumbent").mkdir(parents=True)
    for n in ("m26.png", "m51.png", "sec-01.png", "sec-02.png"):
        (t2 / "images" / n).write_bytes(b"x")
    (t2 / "incumbent" / "main-live.png").write_bytes(b"x")
    sc2 = scope.derive(t2)
    check("pick-id mains are raced, not dropped",
          sorted(sc2["main"]) == ["m26.png", "m51.png"], sc2["main"])
    check("and the gallery is still exactly the sec files",
          sorted(sc2["gallery"]) == ["sec-01.png", "sec-02.png"], sc2["gallery"])

    # Mains still sitting in the pick folder are found rather than reported absent.
    t3 = (_P(_tf.mkdtemp()) / "brushes2").resolve()
    (t3 / "images" / "pick" / "shortlist").mkdir(parents=True)
    (t3 / "incumbent").mkdir(parents=True)
    (t3 / "images" / "sec-01.png").write_bytes(b"x")
    (t3 / "images" / "pick" / "shortlist" / "m37.png").write_bytes(b"x")
    (t3 / "incumbent" / "main-live.png").write_bytes(b"x")
    sc3 = scope.derive(t3)
    check("a main left in the pick folder is still raced",
          sc3["main"] == ["m37.png"], sc3["main"])

    if FAILURES:
        print(f"FAILED ({len(FAILURES)}): " + ", ".join(FAILURES))
        return 1
    print("SCOPE: all green")
    return 0


if __name__ == "__main__":
    sys.exit(run())

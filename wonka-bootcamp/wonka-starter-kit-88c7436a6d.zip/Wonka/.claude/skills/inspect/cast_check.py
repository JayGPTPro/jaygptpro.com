#!/usr/bin/env python3
"""Screen a set for a global colour cast, the defect an eyeball keeps passing.

A+ faces can come out looking like fake tan and bad makeup while two careful
inspections by eye pass them, including one that zooms to the face. That is not
carelessness: an eye adapts to a colour grade within seconds and then reads it
as lighting. The measurement settles it immediately:
98 percent of that module sat inside a single 30 degree hue band, and 1 percent
of the frame was near-neutral. The woman's teeth were not white. The bride's
dress in another module was not white. Nothing in the frame was.

That is the tell, and it is why the skin looked tanned: the skin was not
separately filtered, the whole world was. It also explains why the Face Clinic
would not have rescued it. That room repairs PEOPLE. Repairing the people in a
frame with no neutral anywhere leaves corrected faces inside an orange room,
which looks worse than what you started with.

This prints numbers. It does not fail a build, because a warm palette can be a
brand decision (this is a chocolate brand) and a screen that cries wolf gets
turned off. What it removes is the part humans are bad at: noticing a cast at
all, once your eye has adapted to it.

    band30    share of the frame inside its single widest 30 degree hue window
    neutral   share that is genuinely near-grey, sat < 0.12. THE number to read.
              A frame with people and no neutral anchor has no white to
              anchor skin against, so skin drifts to whatever the grade says.

Usage:
    python3 cast_check.py <file-or-folder> [more...]
"""
import sys
from pathlib import Path

try:
    import numpy as np
    from PIL import Image
except ImportError:
    sys.exit("this needs Pillow and numpy: python3 -m pip install pillow numpy")

IMG = (".png", ".jpg", ".jpeg", ".webp")
# the stitched A+ page views are built FROM the modules; measuring them again
# double counts the same pixels and buries the module rows in the output
DERIVED = ("aplus-page-", "aplus-order-", "squint-")
BAND_FAIL, NEUTRAL_FAIL = 90, 5
BAND_WARN = 80


def measure(path: Path):
    """Returns (band30 %, neutral %, mean saturation). Sampled at 320x320:
    a colour cast is a property of the whole frame, so full resolution buys
    nothing here and costs seconds on a 14-file set."""
    im = Image.open(path).convert("RGB").resize((320, 320))
    a = np.asarray(im).astype(np.float64) / 255
    mx, mn = a.max(axis=2), a.min(axis=2)
    keep = mx > 0.12                      # near-black carries no usable hue
    if not keep.any():
        return 0, 0, 0.0
    sat = np.where(mx > 0, (mx - mn) / np.maximum(mx, 1e-9), 0)[keep]
    r, g, b = a[..., 0], a[..., 1], a[..., 2]
    d = np.maximum(mx - mn, 1e-9)
    hue = np.select([mx == r, mx == g], [((g - b) / d) % 6, (b - r) / d + 2], (r - g) / d + 4) * 60
    hist, _ = np.histogram(hue[keep], bins=36, range=(0, 360))
    total = max(1, hist.sum())
    band = max(sum(hist[(i + k) % 36] for k in range(3)) for i in range(36))
    return (round(100 * band / total), round(100 * float((sat < 0.12).mean())),
            round(float(sat.mean()), 2))


def verdict(band, neutral):
    if band >= BAND_FAIL and neutral < NEUTRAL_FAIL:
        return "CAST"
    if band >= BAND_WARN and neutral < NEUTRAL_FAIL:
        return "watch"
    return "ok"


def files_from(args):
    out = []
    for a in args:
        p = Path(a)
        if p.is_dir():
            out += [f for f in sorted(p.rglob("*")) if f.suffix.lower() in IMG and f.is_file()
                    and not f.name.startswith(DERIVED)]
        elif p.is_file():
            out.append(p)
    return out


def main():
    args = sys.argv[1:]
    if not args:
        sys.exit(__doc__)
    files = files_from(args)
    if not files:
        sys.exit("no images found in " + ", ".join(args))
    print(f"{'file':<44} {'band30':>7} {'neutral':>8} {'sat':>5}  verdict")
    flagged = []
    for f in files:
        band, neutral, sat = measure(f)
        v = verdict(band, neutral)
        if v == "CAST":
            flagged.append(f)
        print(f"{f.name[:44]:<44} {band:>6}% {neutral:>7}% {sat:>5}  {v}")
    if flagged:
        print()
        print(f"{len(flagged)} of {len(files)} frames have a global colour cast and no neutral anchor.")
        print("If any of them contain PEOPLE, open the face at 3x before you call it a pass: this is")
        print("what fake tan and plastic makeup look like from the inside. The fix is the GRADE, not")
        print("the faces. A face pass alone leaves corrected people in an orange room.")
    return 0


if __name__ == "__main__":
    sys.exit(main())

"""Regression tests for the edge-contact clip check (audit 23.8, item 3).

edge_contact() measures how much of each frame edge is covered by non-background
pixels, and edit() retries "draw it smaller" when an edge crosses the tolerance.
The old code ran that check on EVERY frame. On a lifestyle scene there is no flat
background, every edge reads as product, and the check shrank a frame that was
placed right, on a second paid call. Its own docstring says a false CLIPPED is
worse than none.

The fix gates the check on _corners_agree(): four matching corner pixels mean
there IS a flat background to measure against. These tests pin both directions:
the gate stands down on a scene, and a real clip on a flat background still
flags. Watched to fail against the pre-fix module (no _corners_agree existed).

Run: python3 test_edge_contact.py   (no API key needed, pure pixel math)
"""
import importlib.util
import sys
from pathlib import Path

try:
    from PIL import Image, ImageDraw
except ImportError:
    raise SystemExit("Pillow is not installed. Run: python3 -m pip install pillow")

spec = importlib.util.spec_from_file_location(
    "vr", Path(__file__).parent / "variations_run.py")
vr = importlib.util.module_from_spec(spec)
spec.loader.exec_module(vr)

FAILURES = []


def check(name, cond, detail=""):
    if cond:
        print(f"  PASS  {name}")
    else:
        print(f"  FAIL  {name}  {detail}")
        FAILURES.append(name)


def flat(product_box=None):
    im = Image.new("RGB", (400, 400), (250, 250, 250))
    if product_box:
        ImageDraw.Draw(im).rectangle(product_box, fill=(60, 40, 30))
    return im


def scene():
    """A gradient standing in for a lifestyle background: no flat colour anywhere."""
    im = Image.new("RGB", (400, 400))
    for y in range(400):
        for x in range(400):
            im.putpixel((x, y), (140 + y // 8, 110 + y // 10, 80 + x // 20))
    ImageDraw.Draw(im).rectangle([150, 150, 250, 250], fill=(20, 20, 20))
    return im


print("edge-contact regression")

check("the gate exists", hasattr(vr, "_corners_agree"),
      "no _corners_agree in variations_run.py, the clip check is ungated")

check("a flat background passes the gate", vr._corners_agree(flat([150, 150, 250, 250])))
check("a lifestyle scene fails the gate", not vr._corners_agree(scene()),
      "a scene read as flat, the false-CLIPPED path is open again")
check("a product touching an edge does not break the gate",
      vr._corners_agree(flat([0, 100, 80, 300])))

hit = vr.edge_contact(flat([0, 100, 80, 300]))
check("a real clip on a flat background still measures over tolerance",
      hit["left"] > vr.EDGE_TOLERANCE, f"left={hit['left']}")

hit = vr.edge_contact(flat([150, 150, 250, 250]))
check("a centered product on a flat background measures clean",
      all(v <= vr.EDGE_TOLERANCE for v in hit.values()), str(hit))

print()
if FAILURES:
    print(f"{len(FAILURES)} FAILED: {', '.join(FAILURES)}")
    sys.exit(1)
print("all passed")

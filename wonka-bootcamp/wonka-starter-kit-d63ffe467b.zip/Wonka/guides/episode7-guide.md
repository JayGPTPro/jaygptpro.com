# Day 7: The A+ Room

Below the fold on every listing there is a second product page. Half your competitors left theirs
empty. Today you build yours, and when it is done your product page is COMPLETE.

Today is also the odd day out. For four days you have been told to control every field. Today you
deliberately hand one asset over, and the reasoning is the lesson.

**The sentence for the day: here the job is not to say everything, it is to look like somebody who
knows what they are doing.**

## What you will have by the end of today

- **Four A+ concepts on desktop and four on mobile**, one of them chosen
- A deliberate decision on **how many modules**, and on the **premium carousel**, both with reasons
  recorded
- The A+ gate-passed: inspected as hard as everything else, and repaired **inside Genrupt**
- **An export that is already cut to Amazon's dimensions and ready to upload.** The first thing in
  this bootcamp that is finished rather than approved
- Your whole page read top to bottom as one thing, and your coverage map fully closed

**Time needed:** 60 to 90 minutes.

## What you will need at hand

- Your finished gallery from Day 6, and the style you sent to Refine. **Today's A+ inherits it**
- Your brand kit and its approved claims table, if you have one
- **A decision waiting:** are you adding a module of your own, like a comparison chart or an FAQ?
  Lesson 1 explains why this has to be answered before anything generates
- Genrupt open. Three of today's five lessons happen there

---

## Lesson 1: What the A+ is actually for

Lesson 1 is the idea; the terminal starts in lesson 2.

### Who actually reads this

Most shoppers never scroll below the fold. That sounds like a reason to ignore the A+ and it is the
opposite.

The people who DO scroll that far are seriously considering buying and are hunting for a reason to
say yes, or a reason to leave. **They are the most valuable readers you have** and they are already
deep in.

Your hero earns the click. Your gallery answers the fears. **Your A+ closes the person who is already
leaning in.**

### And here the goal is genuinely different

This is what makes this room strange, and it is worth sitting with.

Everywhere else in this factory the job is making sure every message lands. The coverage map. The
buyer question per slot. Nothing dying in silence.

**Here that matters much less.**

What you want from an A+ is that somebody scrolling it feels they are in good hands. That this is a
real brand, that these people know what they are doing, that this is not a drop-shipped thing with a
logo on it.

**The primary job of the A+ is to be beautiful and impressive.**

That is not softness. That feeling converts, and it converts on the most engaged reader on your page.
**A module that ticks a coverage box and looks mediocre does more harm than a module that says less
and looks expensive.**

So if you find yourself fighting the machine to cram a fourth message into module three: stop. You
are optimising for the wrong thing, in the one room where that is genuinely wrong.

### Which is why we do not brief it

Open your brief and look at the A+ section. Three lines. On purpose.

**One. It is a design-heavy asset and the planner is better at it.** Multi-module layout, typography,
rhythm. A different craft from one frame carrying one message.

**Two. It is not what gets tested.** Your hero gets raced on Day 8, and A/B tested on Amazon after you upload. The A+ does not. The return
on controlling every field here is much lower, and the time costs the same.

**Three, and this is the real one. Deciding what NOT to control is a skill.** Anyone can want control
of everything. What actually happens to sellers is that they run out of hours, and the ones who ship
decided in advance where their attention was worth the most.

**What you do NOT give up is the check.** It gets judged hard. Hands-off in the planning is not
hands-off in the gate.

And if you disagree, brief yours. You have every tool you need. Just make it a decision rather than a
habit, in either direction.

### How many modules, and why it is a real question

Amazon caps what your page can carry. **Every module the machine generates is a slot you cannot use
for something else.**

**Seven is the normal answer** when the machine is building the whole thing.

**Six is the answer if you are adding your own module.** Usually that is a comparison chart or an
FAQ, and those two are worth building yourself because they carry information only you have: what you
compare against, and what your customers keep asking.

Generate seven, then discover there is no room for the comparison you wanted, and you are rebuilding.
**One question up front prevents it: am I adding a module of my own?**

### And one more format

There is also a **premium image carousel**, a distinct module type rather than a fancier version of
the standard ones. You will look at a real one in lesson 3 and decide then.

What matters now: it counts against the same module budget, so it is part of this decision rather
than separate from it.

---

## Lesson 2: Generate

### Confirm what it inherits

```
/aplus
```

Wonka confirms the inherited pieces one line each. Read them back with him, because **this is what
makes hands-off safe rather than reckless:**

- The **locked reference**, so it is your real product
- The **style you sent to Refine on Day 6**, so this looks like your gallery rather than a different
  company
- Your **branding preset**
- Your **approved claims table**, so it cannot say something you have not proved

The planner picks the modules and writes the copy. **Identity, look and truthfulness were all decided
by you, days ago.** That is the whole trick.

### Then he asks three questions, and waits

Before anything is generated Wonka asks, in one message, the three machine settings that are yours:

1. **Where will it be read?** Desktop, mobile, or both.
2. **How many concepts per mode?** One to eight.
3. **How many modules?** Seven, or six if you are adding your own, or five for a short page.

He waits for the three answers. He does not run on defaults while you are away, and he does not ask
about anything creative, because there is nothing creative to ask: dense or minimal, layout, colour
direction are not settings the machine offers, and the look was locked yesterday.

```
Both. Four per mode. Seven.
```

**Both modes.** Not desktop first and convert later. Most people who read your A+ read it on a phone,
and a desktop layout converted afterwards is a layout that was never designed for the screen it ends
up on.

**Four per mode**, the same arithmetic as every other room: the best of four beats the only one, and
this asset's entire job is to look impressive. That is eight sets of modules, and this is the page
that decides whether someone thinks you are a real brand.

**Seven**, unless you are keeping a slot for your own comparison chart or FAQ, in which case six, and
the reason goes in the record. If you later ask for "another four", he restates the same three
answers in one line and runs; he never asks them twice.

### It writes the record before it spends

With the three answers on record, Wonka writes the run record to disk BEFORE generating, then says
the price as a report: the live preview beside the measured number (on this workflow the preview has
run twelve credits under the real charge every time it was measured, 60 quoted, 72 billed), and runs.
The three answers were the yes; he does not ask for a second one. That is not bureaucracy: if the run dies
halfway, there is still a file saying what was attempted and with which settings. A batch that fails
and leaves nothing behind is one you reconstruct from memory, badly, a week later.

### One honest read

Scroll a concept top to bottom as a shopper, not as an inspector, and ask the only question that
matters today: **do I look like I know what I am doing?**

Judgment comes in lesson 4. Right now your gut is the closest thing in this room to your buyer's, and
it is the only uncontaminated reading of this page you will ever get.

---

## Lesson 3: The premium carousel

### When it earns its slot, and when it does not

**It earns its slot** when you have a sequence: a before and after, a set of steps, a range of
variants. Something where the ORDER carries meaning. Motion suits a story.

**It costs you** when your shopper is skimming. A static module gives everything at once to somebody
moving fast. A carousel gives them the first frame and asks for a click, and on a phone, from someone
half-deciding, that click often does not come. Whatever you put in frame three may as well not exist.

**And it uses a module slot**, so it competes with the seven-versus-six decision from lesson 1.

The default for most products is static. But carousels work beautifully on things with a real sequence
to show, which is why you look at one rather than being told.

### Decide, and record the reason

The reason matters more than the decision. In four months, on your third product, when you cannot
remember why this page is static, that line is the only thing that explains it.

**A carousel that appeared because nobody discussed it is exactly the same defect as one that never
appeared for the same reason.**

---

## Lesson 4: Judge it, and fix it in the right place

### Pick the concept first

Four concepts, and you ship one. Choose before you inspect: inspecting all four is four times the
work to reach the same place.

Judge them on lesson 1's question. Not which covers the most. **Which one looks like a brand I would
buy from.**

### The gate, and what bites hardest here

```
/inspect the A+
```

Same loop as Day 5, no new rules. Two things bite harder on an A+ than anywhere else:

**Text size.** A+ modules are where walls of small text go to die. There is more room, so more words
appear, and then nobody reads any of them on a phone. The squint test is unforgiving here and it
should be.

**Claims.** More copy means more surface area for a sentence nobody can prove. Every claim goes
against your approved claims table. **The machine wrote this copy. It is not the one whose account is
on the line.**

This is what hands-off in the planning, hard in the gate, actually means.

### Where an A+ fix runs depends on the defect

**A page problem goes back into Genrupt. A local problem on one module is fixed on the exported
file, for cents.** That is the whole rule, and it replaces an older one that sent every A+ edit into
Genrupt.

The Genrupt A+ edit is a page tool. It takes plain-language instructions for a whole concept and
re-renders **every module**, as a new version, at a variable price (five credits one afternoon, over
a hundred another). Give it page work: copy that is wrong across modules, a layout that needs
changing, a module doing the wrong job, several things wrong at once. Put the concept's whole fix
list in ONE instruction, because two fixes in one call cost what one fix costs.

A typo, a badge, a stray element, one part off its axis, one wrong label, one AI-looking face: that is
a local defect on one module, and Genrupt's page tool is the wrong instrument for it. On my own page a
one-word typo cost five credits inside Genrupt, re-rolled all seven modules, and came back with the
typo untouched. The same word on the exported module through `/fix` cost cents and changed nothing
outside its box.

**Why the export is not the problem it sounds like.** Genrupt exports flat image files already cut to
Amazon's module size. A local edit on that file, with the changed box composited back, keeps the
exact size and every pixel outside the box, so the file is still upload-ready. The one thing an A+
module has that a gallery frame does not is neighbours: the page is one canvas sliced into strips, so
after a local fix near a module's top or bottom edge, Wonka reads the seam to make sure it still meets
the strip above or below.

**One order of operations follows from this:** Genrupt fixes first, then export the chosen concept,
then local fixes on the exported files. A later Genrupt round on that concept starts from Genrupt's
version, not from your local file, so the local fixes are re-applied after it.

Either way **the original survives**: the export stays untouched in `aplus/export/`, and every fixed
round saves as a complete snapshot beside it.

---

## Lesson 5: Export, and read the page

### Export

```
Export the A+.
```

Then LIST the folder rather than trusting the success message: does the module count match, are both
modes there, is anything zero bytes?

Look at what you have. **Cut to Amazon's module dimensions. Named. Ready.** These go straight into
Seller Central. No resizing, no cropping, no renaming, no afternoon in an image editor.

That is what the export gives you, and it is also why local fixes run on these files rather than before them.

### Now read the whole page as one thing

Everything you made since Day 5 was judged in pieces. The hero alone. The gallery as a team. The A+
module by module. **Nobody has read it as a shopper does**, which is top to bottom, in one go, in
about forty seconds.

So do that. Scroll it like a stranger, and ask three questions that are page questions rather than
image questions:

**Does the story hold?** The hero makes a promise, the gallery expands it, the A+ closes it. Or the
hero says one thing and the A+ says something else, and neither is wrong on its own.

**Does anything contradict?** This is where a claim you removed from a gallery frame on Day 6 quietly
reappears in an A+ module written on Day 7. They were written days apart by different processes and
nobody has seen them side by side until now.

**Does it repeat itself?** If the A+ is your gallery again in a longer format, your most engaged
reader learned nothing for the trouble of scrolling that far.

### Close the map

Your coverage map has had an A+ column open since Day 3: the selling points you EXPECTED to land
here rather than in the gallery. This is the moment it closes.

Anything expected here that did not arrive gets **named**, not quietly forgotten.

---

## MISSION 1: Answer the two questions before generating

Are you adding a module of your own? Seven or six?

Then:

```
/aplus
```

```
Four concepts, desktop and mobile.
```

## MISSION 2: The carousel

Look at a real one. Decide. Say your reason out loud so it lands in the run record, whichever way you
go.

## MISSION 3: Choose, judge, fix

Pick your concept on beauty rather than coverage. Then:

```
/inspect the A+
```

```
/aplus, fix these modules: [the defect list from the inspection]
```

**Sort the list before you run it:** page-wide problems go back to the A+ Room and into Genrupt's
edit, as one instruction per concept; a local defect on one module (a typo, a badge, one part, one
face) goes to `/fix` or `/fix-faces` on the EXPORTED module file, after Mission 4's export. Lesson 4
taught this; the command above is the Genrupt half of it.

## MISSION 4: Export and read

```
Export the A+.
```

Then list the folder and check it. Then read your whole page top to bottom, like a stranger, and
answer all three page questions honestly.

**Share it:** send Jay your assembled page, top to bottom, as one screenshot. This is the first time
anybody but you sees a whole page rather than a piece of one.

---

## Day 7 closes on the export

That is the day. Nothing else is owed tonight. Day 8 opens by fetching your live main image and
gallery into `incumbent/` itself, at the first step of `/tasting-room`, so the races run against
what is on your listing right now.

---

## What good looks like

- The module count was decided before generating, not discovered afterwards
- The A+ inherits your locked reference, the Day 6 style, your preset if you made one, and your approved claims
- Four concepts on each mode, and you picked on beauty rather than coverage
- The carousel decision is recorded WITH a reason, whichever way it went
- Every claim traced to your approved claims table
- Every fix done inside Genrupt, with originals untouched
- An export you could upload right now, verified by listing the folder
- All three page questions answered, and the A+ column of your coverage map closed

## Common mistakes

- **Generating seven modules when you wanted a comparison chart.** One question up front prevents a
  rebuild.
- **Fighting to cram messages in.** Wrong goal, in the one room where it is genuinely wrong.
- **Editing the A+ with the API.** It breaks the assembly and costs you the export.
- **Desktop only.** Most of your A+ readers are on a phone.
- **Picking the concept that covers the most.** Pick the one that looks like a brand.
- **Trusting the export message.** List the folder. Count, both modes, nothing empty.
- **Skipping the page read.** It is the only check that catches the story falling apart between the
  hero and the fold.

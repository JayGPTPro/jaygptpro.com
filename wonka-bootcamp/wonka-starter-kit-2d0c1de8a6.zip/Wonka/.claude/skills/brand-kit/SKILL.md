---
name: brand-kit
description: Build the brand kit, colors, fonts, tone, approved claims, and avoid list, that every generated image must follow, plus the two carriers Genrupt actually reads, the branding preset and the single styleImage. Run once per brand, reused by every product. Owner approval is written into the file, and PENDING is a lawful recorded state. Use when the user wants to set up their brand, define brand colors and fonts, create or update the Genrupt branding preset, choose a style image, or when a generation needs a brand kit that does not exist yet. Triggers: /brand-kit, "brand kit", "set up my brand", "brand colors", "branding preset", "style image", "define my brand style", "approved claims", "avoid list".
---

# The Brand Room

| Meta | Value |
|------|-------|
| Room | The Brand Room |
| Station | INVENT prerequisite. Built once per brand, taught on Day 4 between the Reference Sheets' approval and the smoke test, so the smoke test runs with the brand attached |
| Needs | Whatever the owner dropped into the product's `2-reference/brand/` folder: logo, brand guidelines, label or packaging photos, past creative. **Nothing is required.** With brand files this room reads and confirms; with none it PROPOSES a full kit from the product, the category and the buyer (step 0). A website or listing URL helps either way |
| Saves to | factory/Brand/brand-kit.md, master logo and style image copied into factory/Brand/, and the Genrupt branding preset, its brandingPresetId recorded in the kit file |
| Typical cost | Free. Interview, analysis, and preset creation cost no credits. Only the preset step touches the Genrupt machine at all |

## What this room does

Every candy leaves this factory in the same wrapper. The Brand Room captures the brand's identity into three artifacts that work as one: the **kit file** (colors with real hex codes, font direction, tone, approved claims, an explicit avoid list), the **Genrupt branding preset** that carries the colors and font direction into every generation, and exactly **one styleImage**, the single aesthetic north star. Built once per brand; every product of that brand reuses all three.

Two things this room is quietly responsible for. It is the **compliance firewall**: the approved claims table is the only list of claims allowed onto an image, decided once while calm instead of forty times in a hurry. And it is the **room that almost never closes**: the interview, the file, and the claims work need no machine and no credits, so when Genrupt is down this is the work that still moves. Only the preset push waits for the machine, and it is recorded as waiting rather than skipped.

**The style contract (house decision 4, and it is absolute):** style travels ONLY through the branding preset and the styleImage. Generation rooms pass `brandingPresetId` inside `projectSetup` and the styleImage URL in `projectSetup.references.styleImage`, and that is the whole delivery. Hex codes, font names, and style prose never appear in a brief, a header phrase, or a custom instruction. Design-dictating text overrides the brand engine and flattens the output, and a hex code in a text field is the classic symptom. The approved claims and avoid list travel a different road: they gate what `/creative-brief` may put into on-image text, they are compliance, not style.

## Before you start

- Open `factory/Brand/brand-kit.md`. The kit SHIPS with this file as an unfilled template (placeholders like `[filled by /brand-kit]` and `#______`), so its existence alone means nothing.
  - **Still unfilled**: this is a FIRST RUN. Interview, then fill the template's sections IN PLACE, keeping its `##` headers exactly. Do not invent new sections. Every extra field below lives inside an existing table or in the footer.
  - **Already filled with real values**: do NOT rebuild from scratch. Show the current kit, ask what changes, edit only those fields, and follow step 13.
- `factory/Brand/brand-kit.md` is the single canonical path. Multiple brands: name additional kits `brand-kit-[brand-slug].md`, one brand per file, never merged, each with its OWN branding preset id and its own style image (`style-image-[brand-slug].[ext]`), and record which kit applies in the **`Brand kit` row of each product's `status.md` identity table**, which is the one place every generation room reads it from.
- **When more than one `brand-kit*.md` exists, no room may assume the default.** Every room that reads a brand kit resolves it from the product's own `status.md` first. If that product has no kit recorded, STOP and ask which brand it belongs to; never fall back to `factory/Brand/brand-kit.md` just to have something. The failure this prevents is silent and expensive: the second brand's product generated in the first brand's colors, carrying the first brand's approved claims, with no error anywhere.
- **Nothing hard-blocks this room, and "I don't have that" is a complete answer to every source question.** Sources improve the kit; with none at all, step 0's proposal mode still produces a complete, reasoned v1. What is missing is recorded as missing and the run continues. **"I have nothing" never yields an empty kit and never yields a long interrogation.**
- Look in the current product's `factory/Products/[product]/2-reference/brand/` folder BEFORE the interview. That folder is where the owner drops brand files (logo, brand guidelines, label and packaging shots, past creative), so read what is there and pre-fill answers for confirmation. Same for a website or listing URL the user gives, if reading it is possible. Asking an owner to dictate hex codes they never memorized is bad hospitality.
- **Never write "sampled" for a value you did not actually see.** If a source cannot be opened (no browsing, a dead link, a document you cannot read), say so in one line, ask for a screenshot or pasted text, and if none arrives, propose values from the description and label them `owner approved proposal`. A guessed hex code wearing a "sampled from the site" label is a faked artifact, and every future session will trust it.

## Process

0. **Decide which of three modes this run is in, and say which, out loud.**
   - **OWNER-SUPPLIED.** Brand files exist: a logo, a brand book, label photos, past creative the owner likes. Read them, sample from them, and the owner confirms. The steps below assume this mode.
   - **WONKA PROPOSES.** There are no brand files, or the owner says they have no brand identity yet. **Do NOT run a long interview to fill the hole, and do NOT leave the kit empty.** Build a complete, reasoned proposal instead, from three sources in this order: (a) the product itself, its real materials, colors and finish from `2-reference/`, because a kit that fights the product loses; (b) what the category actually looks like on Amazon today, from `research/competitors.md`, so the listing reads as a credible member of its shelf and then beats it; (c) what would flatter this product and this buyer, from `research/persona.md`. Present it as a proposal with a one-line WHY per decision, and let the owner accept, change one thing, or reject. **Every field is still filled**, and the `Kit basis` row records `wonka proposal ([what it was reasoned from])`.
   - **OWNER DECLINES BRANDING for this product.** A complete and lawful answer, not a gap: some products are sold unbranded, and some owners simply do not want a look imposed on this one. Do NOT argue, do NOT propose anyway, and do NOT leave the decision implied. Write `none (owner declined branding for this product) [date]` into the product's `status.md` `Brand kit` row, which is the value that tells every later room to attach no preset and no styleImage and to never fall back to a kit file. Detach any preset already attached (one free call), read the plan back, and confirm the cast and the approval survived. Then say the one thing the owner is actually trading away: a preset is the only carrier that reaches EVERY generation regardless of what a slot's own text says, so material truth ("brass and copper-brown, never chrome") now rests entirely on the slot briefs and the reference sheets, and those are where a drift will have to be caught. Measured 27 August 2026: with no preset at all, nine smoke-test frames still came back sharing one coherent look that Genrupt's own enhancer drew from the product, so unbranded is a real choice and not a degraded one. The room ends here, recorded, and nothing downstream is blocked. A decline is reversible: run `/brand-kit` again later and the room attaches the preset and style image to the saved plan and rewrites the row. The lesson's advice, generate with branding attached and then without and keep the stronger set, is exactly that pair of runs.
   - The two rules that survive both building modes, because they are compliance and not taste: **no logo is ever drawn, approximated or invented** (step 8), and **no claim enters the approved-claims table without proof** (step 10). A proposal may invent a palette. It may never invent a fact.

1. **Gather the sources, and accept "I don't have it" per item.** Start with the product's `2-reference/brand/` folder, that is the owner's drop zone: logo, brand guidelines document, label and packaging photos, past creative they like. Then ask for what the folder does not hold, as one list: website or storefront, the live listing, anything else. Read whatever exists. Copy the master logo (and later the chosen style image) into `factory/Brand/`, the brand-level home; product folders come and go, the brand does not. Record the outcome item by item; the footer carries one line, `Sources used: [list]. Not available: [list].` A kit built from a logo and a conversation is a real kit, as long as the file says that is what it is.

2. **Establish the KIT BASIS and write it as a row in `## Brand identity`.** One of `owner brand (owner-supplied assets)`, `derived from public brand presence (no brand book available)`, or `wonka proposal ([what it was reasoned from])` when step 0 put this run in proposal mode. The second is common and legitimate: a seller whose brand book is a logo and a feeling, or a training run on a brand that is not the owner's. It changes nothing about the method and everything about how much authority the values carry, so it gets stated rather than assumed.

3. **COLORS. Five roles, real hex codes.** Primary, secondary, accent, background, text on light.
   - From a source: sample the actual value. From a description ("deep navy, like an ink bottle"): propose specific hex codes for approval. In proposal mode: propose the full five from the product, the category and the buyer, each with a one-line why, and never say "you decide" to an owner who already said they have nothing.
   - Every row's Notes column names the source: `sampled from logo` / `sampled from label photo` / `owner approved proposal` / `from brand book` / `wonka proposal: [why]`.
   - Accent is for highlights and for real on-product seals. It is never permission to invent a badge.
   - **Name the text-safe pairs.** Add one Notes line saying which colors may carry text and which may never ("headline text on background or primary only; never white text on the accent"). A palette that produces unreadable overlays fails the mobile squint test later, and the cheapest place to catch it is here, in words, before a single image exists.

4. **FONTS. A direction, not a file.** Lock one of exactly three tokens, written literally, once for headlines and once for supporting text: `editorial serif` (premium, wellness, heritage), `clean sans` (modern, tech, minimal), `bold display` (value, energy, impulse). Add the one-sentence overall look. If the brand owns a licensed font, record its name and note that it serves human design work only. Image models cannot load font files; they follow a described look reliably. These two tokens later become the preset's header and supporting font direction (step 12), so they are decided here once and typed into prose nowhere, ever.

5. **TONE.** Three to five words for `Sounds like`, each with a sentence of what it means for imagery ("warm: natural light, soft shadows, no clinical white sweep"), and three to five for `Never sounds like`.

6. **APPROVED CLAIMS. Two tests, and a claim must pass both.** This is the compliance backbone and the most valuable table in the file.
   - **Test 1, TRUE.** Certifications actually printed on the label (name the certifying body), documented press mentions or awards, and factual product attributes the owner confirms: dimensions, capacity, material, part count, warranty, country of manufacture. Every row needs a proof entry. No proof, no row.
   - **Test 1b, WHOSE.** Every row also records `Applies to`: `brand-wide`, or the name of the ONE product it was verified for. The attributes in Test 1 are the reason this column exists: capacity, part count, material and warranty belong to a product, not to a brand, and this kit is reused by every product the brand sells. Day 9's second product is where an unscoped table shows up as product one's "4 tiers" printed on product two. A claim verified for one product is never licensed for another; a new product uses `brand-wide` rows plus its own, and earns the rest with its own proof. The same scoping applies to the avoid list: a promise the reviews of ONE product disputed is recorded against that product, not against the brand.
   - **Test 2, ALLOWED.** True is not enough. Sales rank, Best Seller status, star ratings, review counts, "thousands of happy customers", and anything else pointing at reviews or rank is TRUE and still barred from images. Move it to the avoid list marked `true, not allowed on images`, and tell the owner why in one line: this is the category that gets listings pulled, and rank changes week to week anyway. Sell the reason for the rank instead.
   - **Disputed promises go to the avoid list too.** If the product has research on disk, read `factory/Products/*/research/product-report.md` (and the raw `1-inputs/reviews.txt` where it exists) and move any promise buyers routinely dispute into the avoid list, naming the review evidence. Example from the bootcamp's demo product, a chocolate fondue fountain: buyers report the flow is weak at the capacity the listing states, so no image may promise a cascading flow. A promise the images made is the cheapest complaint to prevent and the most expensive to inherit.
   - For every approved row, record HOW it may appear: as it appears on the physical label, as plain printed text, as a physical hang tag. Never as an invented graphic badge, never as a third-party logo rendered by the model.
   - **An empty table is a lawful outcome.** If nothing passes both tests, write the literal line `No claims approved. Images carry only what is physically printed on the product.` and move on. Never pad this table to make it look finished. An invented certification is the single most expensive thing this skill could produce.

7. **AVOID LIST.** Restate the full Golden Standards compliance set: no medical or disease claims, no invented percentages or statistics, no star ratings or review references, no fake badges or awards, no third-party logos rendered as graphics, no flag graphics. Then add, each with a one-line reason: brand-specific avoids (colors that clash, styles the owner rejects, competitor names, a discontinued label), every item moved here by test 2, and every disputed promise from the reviews.

8. **LOGO RULES.** Which file is the master, where the logo may appear (typically small, one corner, secondary images only), minimum clear space, one logo per image maximum. **If no logo file exists**, write `Logo file: none provided` plus the standing rule `No logo is drawn, approximated or invented. Images carry no logo until a real file exists.` A missing logo is a gap to record, never a gap for the model to fill.

9. **STYLE IMAGE. Exactly one, chosen with the owner.** The styleImage is the single aesthetic north star handed to Genrupt as `projectSetup.references.styleImage`, the one image that says "make it feel like this". Candidates: past creative the owner loves, the best-looking frame from their current listing, a mood page from the brand guidelines, anything sitting in `2-reference/brand/`. It sets mood, light, and finish; it is NOT a product reference (real product photos belong to the Reference Room, in `2-reference/photos/`) and NOT a competitor image to copy wholesale. Pick the single best together, copy it to `factory/Brand/style-image.[ext]`, and record the choice with a one-line why. The kit records this local master; the generation room uploads it at setup time and passes the completed HTTPS asset URL, because the MCP rejects local paths, UNLESS a saved plan is already waiting, in which case step 12 uploads and attaches it now, in this room. Exactly one, per the intake guide; never rotate several. "I don't have one" is a complete answer: record `Style image: none chosen` and generations run on the preset alone until one exists.

10. **Write the file, then self-check before showing it.** Fill in place, then verify mechanically that none of these survive anywhere in the file: `#______`, `[filled by /brand-kit]`, `[e.g. `, `[add your own]`, `[your brand name]`, `[date]`. Every `[URL or n/a]` reads as a real URL or the literal `n/a`. A file with a placeholder left in it is not a kit, it is the template with extra steps.

11. **Present, then get the verdict.** Show a compact summary: each color described in words with its hex and source, the two font tokens, the tone words, the claim count, the avoid count, the logo rule, the chosen style image. Then ask plainly for "yes, that's my brand". Three lawful outcomes, and the footer records which one happened:
    - **Yes** to `Owner approval: APPROVED [YYYY-MM-DD] by [name]`.
    - **Changes** to edit exactly what they named, state the change in words, ask again. Never mark approved off a "looks fine" or a silence.
    - **Owner not in the session** (an assistant run, a rehearsal, a team member without authority) to `Owner approval: PENDING . built [YYYY-MM-DD] from [sources], awaiting owner confirmation`. See the PENDING contract below. The kit is usable and the line does not stop.

12. **Push the kit into the Genrupt branding preset, and record the id.** The preset is how the colors and font direction actually reach a generation; a kit that lives only in markdown styles nothing. One preset per brand.
    - Find the branding tools (list, create, update, apply branding preset). If they are not directly visible, discover them with `search_capabilities` and call them with `execute_capability`.
    - List existing presets FIRST. A preset for this brand already exists: UPDATE it, never spawn a twin.
    - Map the kit in: primary, secondary, accent, and background hex into the preset's color fields; the two font tokens as the header and supporting font direction; the style notes field carries the one-sentence look, the text-safe pairs, and the text-on-light hex. Hex codes live HERE and only here. They never travel in brief text.
    - Record the id the tool returns in the kit's `## Style engine` section: `Branding preset: [id], updated [YYYY-MM-DD]`. Never write an id the tool did not return.
    - Genrupt down or MCP not connected: do not fake it, do not stall the kit. Write `Branding preset: PENDING . Genrupt unavailable [YYYY-MM-DD]` and say plainly that no generation for this brand should run until the preset exists. The kit file is done; the wiring is a recorded gap, filled next session the machine is up.
    - A kit whose approval is PENDING may still get its preset (the kit is usable); downstream provenance carries the pending state either way.
    - **Then attach it to any plan that is already waiting.** The brief is written and sent BEFORE this room runs (Day 3 sends, Day 4 dresses), so a saved listing-builder plan usually already exists with `brandingPresetId` left empty on purpose. Check the product's `brief/creative-brief.md` `## Send log`: if it records a saved plan, apply this preset to that set (the apply-branding-preset capability, targeting the listing builder set; discover it with `search_capabilities` if it is not directly visible) and record `applied to [product] plan [YYYY-MM-DD]` under `## Style engine`. Same for the styleImage: upload the local master and attach the completed HTTPS URL. A preset that exists but was never attached dresses nothing, and the failure is silent because the images generate anyway, just generic.
    - **READ THE PLAN BACK AFTER THE ATTACH, every time.** Attaching a preset or styleImage is a setup-level write. On the current server a setup write preserves a saved approval (measured 26 August 2026), but earlier builds silently reset it to `approved: false` with nothing in the response saying so (CLAUDE.md, Genrupt contract rule 6). The free read-back is correct either way: confirm the preset shows attached AND `approved: true`, and re-save the approval if it dropped.

13. **Updating an existing kit.** Change only what was named. Any change to a color, a font token, a claim or the avoid list RESETS approval: write a fresh `Owner approval:` line and one note under `Last updated` naming what changed and the old value ("Primary was #1E3D34, now #14332B, owner approved"). A new claim faces the same two tests. A kit approved once does not grandfather anything in. And any change to a color or font token is pushed to the branding preset in the SAME session (step 12), with a fresh date on the `Branding preset:` line. A kit and preset that disagree is drift, and the preset is the one the images obey. Swapping the style image is a named change like any other: one in, old one noted, never two at once.

14. **Backfill.** Search every product artifact under `factory/Products/*/` (briefs, A+ plans, variation plans) for the marker `pending brand kit`. Fill each field from the finished kit and list the files updated. If a marker cannot be resolved from the kit, because it needs a value the kit does not hold, name the file and the field and LEAVE the marker in place. Never delete a marker you did not resolve.

## Output format

Fill the SHIPPED template `factory/Brand/brand-kit.md` in place. Keep its exact section headers: `## Brand identity`, `## Colors`, `## Fonts and typography direction`, `## Tone words`, `## Logo rules`, `## Style engine`, `## APPROVED CLAIMS . the only claims allowed on images`, `## Avoid list`. Replace every placeholder with a real value, add the `Kit basis` row, and stamp the full footer.

```markdown
## Brand identity
| Field | Value |
|---|---|
| Brand name | [real name] |
| One-line positioning | [real line] |
| Website / storefront | [URL or n/a] |
| Kit basis | owner brand (owner-supplied assets) OR derived from public brand presence (no brand book available) |

## Colors
| Role | Hex | Notes |
|---|---|---|
| Primary | #XXXXXX | [description. Source: sampled from logo / owner approved proposal] |
| Secondary | #XXXXXX | |
| Accent | #XXXXXX | [highlights and real on-product seals only] |
| Background | #XXXXXX | [typical backdrop tone] |
| Text on light | #XXXXXX | |

Text-safe pairs: [which colors may carry text, which may never]

## Fonts and typography direction
- Headline style: editorial serif | clean sans | bold display
- Supporting text style: [same three tokens]
- Overall look in one sentence: [summary]
- Licensed font on file: [name, human design work only] or n/a
(plus the template's standing note: image models cannot load font files; this describes the LOOK)

## Tone words
- Sounds like: [3 to 5 words, each with what it means for imagery]
- Never sounds like: [3 to 5 words]

## Logo rules
- Logo file: factory/Brand/[filename], or "none provided. No logo is drawn, approximated or invented."
- Placement: [placement, size, clear space]
- One logo per image maximum.

## Style engine
How this brand reaches Genrupt. Style travels ONLY through these two; hex codes, font names and style prose never go into brief text.
| Field | Value |
|---|---|
| Branding preset | [id], updated [YYYY-MM-DD] . or PENDING with the reason |
| Style image | factory/Brand/style-image.[ext] . [one-line why this image] . or "none chosen" |

## APPROVED CLAIMS . the only claims allowed on images
| Claim | Proof | Where it may appear |
|---|---|---|
| [e.g. 4 tiers] | [product spec and listing] | [as plain printed text] |
(or the literal line: No claims approved. Images carry only what is physically printed on the product.)

## Avoid list
- [full Golden Standards compliance set, restated]
- [true, not allowed on images: rank, star ratings, review references] . reason
- [disputed promise from reviews] . reason
- [brand-specific avoids] . reason

---
Sources used: [list]. Not available: [list].
Owner approval: APPROVED [YYYY-MM-DD] by [name]   |   PENDING . built [YYYY-MM-DD] from [sources], awaiting owner confirmation
Last updated: [YYYY-MM-DD] by /brand-kit. [on an update, one line naming what changed and the old value]
```

## Owner approval, and the PENDING contract

A kit may legitimately be built while the owner is not in the room. In that case fill everything honestly from the available sources, mark every proposed value as a proposal, and write the `Owner approval: PENDING` footer line instead of blocking. That line is the contract:

- The kit is USABLE. Briefs and generations may proceed on it.
- Every downstream room that reads the kit names the pending state in its own `Built from:` provenance line (`factory/Brand/brand-kit.md, owner approval PENDING`), so nobody downstream mistakes a proposal for a decision.
- The approved-claims table carries the pending state hardest. A PENDING kit's claims are proposals about what is provable, so anything unverified stays out of images until the owner confirms.
- Clearing it takes one sentence from the owner. Then rewrite the line to APPROVED with the date and the name, and say which rooms were waiting.

Never write APPROVED because the kit looks correct. Correct and approved are different states, and only the owner can move between them.

## Golden Standards check

Before presenting, verify:
- [ ] Five colors, every one a concrete hex code with a recorded source. No "greenish". No value labeled `sampled` that was not actually seen.
- [ ] Text-safe pairs named: which colors may carry text and which may not.
- [ ] Both font tokens locked, from the three allowed, written literally.
- [ ] Every approved claim passed BOTH tests and has a proof entry. Anything true-but-barred sits on the avoid list, marked, not quietly kept. An empty table carries the literal no-claims line.
- [ ] The avoid list holds the full Golden Standards compliance set, plus brand specifics, plus every true-but-barred item and disputed promise, each with a reason.
- [ ] Logo file saved in `factory/Brand/`, or `none provided` with the no-invented-logo rule.
- [ ] `## Style engine` carries a branding preset id that a tool actually returned (with its date), or an honest `PENDING . Genrupt unavailable` line. Never an invented id, never blank.
- [ ] Exactly ONE style image chosen and copied to `factory/Brand/`, with a one-line why, or the literal `none chosen`. Never two.
- [ ] Nothing in this kit is destined for brief text: no hex code, font name, or style sentence is queued for any `contentBrief`, header phrase, or custom instruction. Style ships by preset and styleImage only.
- [ ] No placeholder survives anywhere in the file (the step 10 check ran and passed).
- [ ] Footer carries `Sources used` / `Not available` and an `Owner approval:` line reading APPROVED or PENDING. Never blank, never absent.

## Wonka lines

Openers:
- "The Brand Room. The candy may be perfect, but the wrapper is what they see first on the shelf."
- "Every factory has its colors. Show me yours, hex codes and all."
- "No brand book? Splendid. Most great wrappers began as a logo and a strong opinion."

On the claims table:
- "True and allowed are two different tests, and only one of them keeps your listing standing."
- "No proof, no claim. I have never met a regulator who enjoyed theater."

On the preset and the style image:
- "The wrapper is not a memo, it is a machine setting. We set it once and every image comes out wearing it."
- "One north star. Two north stars is how ships end up on rocks."

Closers:
- "Wrapped, approved, and wired into the machine. Every image from here on wears these colors or it doesn't leave the building."
- "One kit, one preset, one style image, every product. That's the economy of a good wrapper."
- "Your brand now fits in one file and one preset id. The generation rooms pass the id, Genrupt does the dressing."

## Definition of Done

- `factory/Brand/brand-kit.md` is filled IN PLACE with: five hex colors each carrying a source, the text-safe pairs named, two font tokens, tone words both ways, logo rules, a `## Style engine` section, an approved-claims table where every row has proof (or the literal no-claims line), and an avoid list.
- Zero placeholders remain. The step 10 self-check ran.
- The Genrupt branding preset is created or updated with the kit's colors and font direction, and its returned id is recorded in `## Style engine` with a date. If Genrupt was unreachable, the line reads `PENDING . Genrupt unavailable [date]` instead. **Both are recorded states; a silent skip is neither.**
- Exactly one style image is chosen and copied into `factory/Brand/` with a one-line why, or `Style image: none chosen` is recorded. "I don't have one" is a done state.
- The `Kit basis` row is set, and the footer carries `Sources used` / `Not available` plus an `Owner approval:` line reading APPROVED with a date and a name, or PENDING with what it awaits. **Both are done states. A missing, blank or assumed approval line is not.**
- Logo files copied into `factory/Brand/` if any exist.
- Every `pending brand kit` marker under `factory/Products/*/` is either resolved or reported by file and field.

## Update status.md

Brand kit is brand-level, not product-level. If a product folder exists, add a Log line to the current product's `status.md`: `[YYYY-MM-DD] Brand kit built/updated at factory/Brand/brand-kit.md. Branding preset: [id] | PENDING. Style image: [file] | none chosen. Owner approval: APPROVED | PENDING.` If the BRIEF or INVENT station was waiting on the kit, say that this unblocks it, and repeat any pending state (approval or preset) so the next session sees it.

If no product exists yet, because the kit was built before the first product, there is nothing to log. Say so and let `/meet-my-product` pick it up at the Front Gate. Never create a product folder just to have somewhere to write.

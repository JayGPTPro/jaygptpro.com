# Day 4: The Reference Room and the Brand Room

Yesterday you approved a plan made of words. Today the machines learn what your product actually
looks like, the brand gets its wrapper, and then, for the first time, the plan becomes pictures.

Three lessons, in this order: lock the product, connect the brand, run the smoke test. The order is
deliberate. The smoke test runs last so it proves the product and the brief under the same settings
production will use tomorrow.

**The sentence for the day: an approved sheet is a status. A generated image that shows your
product is the evidence.**

## What you will have by the end of today

- **Approved Product Reference Sheets**: one to five images, each with a clear role, that lock your
  product's angles, scale, materials, proportions and details. Every image the factory makes from
  now on inherits the product from them
- **A Brand Kit** (`factory/Brand/brand-kit.md`) carried into Genrupt by a branding preset and one
  style image, both attached to the plan you saved on Day 3. Or a recorded decision to run this
  product without branding, which is a lawful choice
- **A passed smoke test**: one cheap image per planned gallery slot, opened and read by you, twice
- **A locked product**: `2-reference/reference-sheet.md` carrying `Reference status: LOCKED` and
  `Smoke test: PASS`, the two lines Day 5 reads before it generates anything

Costs today are small, and Wonka reports each one as it runs. Your brief approval yesterday covers
the sheets and the smoke test, so he does not stop to ask.

---

## Lesson 1: Lock the Product

### The mold, and why you do not rush it

The Product Reference Sheets are the most important output in this entire bootcamp. Every main
image, secondary image and A+ module you make later inherits the product from them. Think of a sheet
as the mold the factory pours from. If the mold is accurate, every room begins from an accurate
product. If the mold is wrong, the same mistake spreads into everything that follows.

So this is not a step to rush. Stay here as long as you need. Do not approve the sheets until you
are genuinely confident they represent your product correctly.

### What Wonka does before the first sheet

```
/reference-sheet
```

Wonka starts with the real product photos you prepared on Day 2, in `2-reference/photos/`. He
identifies the available angles, the visible materials, every countable part, the dimensions you can
confirm, and any detail the model must not invent. For products with small or precise parts, he
zooms into the source photos and describes those parts individually. This specification is the
standard the sheets are judged against.

**Scale matters more than people expect.** A number in inches helps. A visual cue is much stronger:
a hand holding the product, a forearm beside it, a familiar object in the same frame, or, for a
countertop product, objects whose size people already know. Make sure at least one sheet gives
Genrupt a clear visual understanding of scale. There is a real setting for this, and Wonka chooses
it deliberately.

### Inspect it zoomed in, beside the source photos

Wonka combines the real photographs into a Product Reference Sheet: an image, not a written
document, showing the product from enough angles to lock its shape, materials, proportions, details
and scale. It carries no text, captions, arrows or badges. It locks identity and nothing else.

Do not judge it only as a full image. A sheet judged at full size gets approved with the wrong metal
color, the wrong proportions and a misspelled label. Put the sheet beside the source photos, zoom
into the matching areas, and run five checks, every time:

1. **Angles.** Can Genrupt clearly understand the front, back, sides, top, and any part that changes
   position or opens? Whatever is not in this picture, the model gets to invent forever.
2. **Scale.** Is there a hand or another visual cue that makes the real size obvious?
3. **Panel quality.** Is every important view clear, useful, and attractive enough to serve as a
   reference? An ugly panel does not just fail to help. It poisons everything poured from this mold.
4. **Material truth.** Do metal, plastic, glass, fabric, texture, gloss and color look like the real
   product? A mixed-material product rendered as one gleaming metal object sells something that does
   not arrive in the box.
5. **Product integrity.** Has anything been added, removed, duplicated, reshaped or invented? Count
   the parts. Check the labels. Check the proportions.

If anything is wrong, do not approve it because most of the sheet looks good. Every later image will
inherit this mold. `downloads/five-point-sheet-check.md` is the same five checks on one page.

### Correcting it: revise, never restart

Tell Wonka exactly what needs to change:

```
The reference sheet is close, but please fix these details: [describe the exact issues]. Keep everything else unchanged and create a revised version.
```

Name the defect in nouns ("the tower reads as chrome, it is brushed steel"), because a machine
cannot act on "it looks off". Give a proportion a number measured from a real photo, because "too
short" just buys another guess.

Wonka uses the current sheet as the base and corrects only the named problems. He does not rebuild
from zero because one detail is wrong, and every version stays on disk as `sheet-v[N].png`, so you
can put old beside new. Then you inspect again, all five checks. Two or three revision rounds are
not a failure. They are the normal way to build the most important reference in the factory.

**If the same defect survives two rounds, stop rewording.** Two suspects: a missing source photo
(take it and drop it in the folder), or an instruction that contradicts the product's real geometry
(re-check the claim against the zoomed source). Wonka checks both before buying a third round of the
same words.

### Up to five sheets, each with a job

You can have up to five sheets. If your product is a set, has several separate components, changes
between states, or contains an important part that needs more coverage, ask Wonka for additional
sheets; on a complex product he proposes the set himself, with one line of reason per sheet. Each
sheet has a clear role: one locks the complete product, another the accessories or the parts
inventory, another a critical mechanism or state. Do not create extra sheets merely to use all five.
When more than one sheet exists, Wonka checks that shared facts agree across all of them, settles a
conflict by re-measuring the source photo, and approves the complete-product sheet last so it stays
the primary reference.

### Packaging stays out of the main sheet

Normally the packaging is not included in the main sheet. Wonka keeps the packaging photos in a
separate place inside Genrupt, so they stay available for the packaging tactics on Day 5 without
bleeding into every generated image. Leaving them out does not throw them away. Only if the
packaging must appear consistently across the image set does it get treated as part of the product
or receive its own additional sheet. For most products, keep it separate.

### Approve, and stop before the smoke test

When you are satisfied with every sheet:

```
I approve these reference sheets. Stop before the smoke test.
```

Wonka records the approval, sweeps the wording of your saved plan against what the sheets
established (a slot that still describes a part the way Day 3 guessed it would fight the sheet in
every render), and writes `Reference status: APPROVED (smoke test pending)`.

The sheets are approved. **The product is not fully locked yet.** An approved sheet still has to
prove it produces the correct product inside a real generated image. That proof is lesson 3. First,
the brand.

---

## Lesson 2: Connect the Brand

### One kit, one file

Next you decide how much of the brand identity Genrupt carries into the images. Wonka stores the
brand rules in one Brand Kit, `factory/Brand/brand-kit.md`: logo rules, color roles, typography
direction, tone, approved claims, things the brand must avoid, and one style image that shows the
overall visual feeling. It lives at the brand level, so it wraps every product you run through the
factory. Fill it once.

```
/brand-kit
```

If you have a logo, brand guidelines, packaging, or existing creative you love, give those files to
Wonka. The drop zone is `2-reference/brand/`, and the Day 2 ZIP may already have put them there. If
you do not have a complete brand system, that is also fine. Wonka proposes a direction from the
product, the category and the buyer, with a one-line why per decision, and you accept it, change one
thing, or throw it out.

Two things he never proposes, because they are facts and not taste. No logo file means no logo is
drawn, approximated or invented. And he will not invent a certification, an award or a product claim
you did not provide and prove. The approved claims table is the only list of claims allowed onto any
image, every row needs proof, and an empty table is a lawful outcome.
`downloads/approved-claims-worksheet.md` is that table on one page.

### How the brand reaches Genrupt

Wonka turns the material into a practical kit, then creates or updates a branding preset inside
Genrupt and picks one style image with you. The brand does not reach Genrupt through long design
instructions inside every image brief. It travels through two things only: the preset, which
carries the reusable brand settings, and one style image, the visual north star for mood, lighting
and finish. Nobody types a color into a brief, ever. Colors and fonts written as text into an image
request override the brand engine and flatten the output.

The Reference Sheets define what the product is. The brief defines what each image needs to
communicate. The preset and the style image influence how the images feel. Genrupt still plans the
composition and the visual execution.

### The instructor's honest note

He does not necessarily recommend beginning with branding turned on. The way he sees Amazon, it
matters more that every image is beautiful and improves the chance of conversion than that every
image uses the exact same brand colors. Many people will disagree, and that is fine. It is a choice
every brand should make for itself.

Branding in Genrupt creates strong visual consistency, but at the moment it can come with a
tradeoff: results may feel a little less creative, or the AI may feel more restricted. He is working
on it with the Genrupt team and hopes it is temporary. So know what to test if you are unhappy with
the results: generate with the branding attached, then try without it and compare. Choose the
version that creates the stronger Amazon images for your product.

Declining branding for a product is a real choice, and the kit records it as one. Tell Wonka you want
this product to run unbranded. He writes `none (owner declined branding for this product)` into the
product's status, detaches any preset already on the plan, and says what you are trading away: a
preset is the only carrier that reaches every generation regardless of a slot's own text, so
material truth now rests on the sheets and the slot briefs alone.

### Approve, and apply it to the plan

```
I approve this brand kit. Apply it to the saved Genrupt plan.
```

Wonka applies the preset and the style image to the plan you saved yesterday, then reads the plan
back to confirm the brand settings are attached and the approved plan is still intact. The read-back
is the step people miss. A preset that exists but was never attached dresses nothing, and it fails
silently, because the images still generate, just generic.

The product is represented. The strategy is approved. The brand direction is connected. Now the final
test before production.

---

## Lesson 3: The Smoke Test

### Two questions, and only two

Before producing real candidates, run one small test. The smoke test creates one image for every
planned gallery slot, at the cheapest setting, straight off the plan. It is not trying to make the
final gallery. It tests two things, as cheaply and quickly as possible: did we lock the correct
product, and did we approve the correct brief.

```
Continue with the smoke test.
```

Wonka runs one low-count generation per slot, saves the round in `2-reference/smoke-test-v[N]/`,
and sends you every frame as its own full-size file. Open every one, not just the good ones.

**Before you look:** every image may come back with different colors, different fonts, and a
different visual style. Ignore that. You are not judging the typography, the colors, the final
composition, or the polish. Those get chosen later, from far more options, and judging them now
makes you throw away a good frame for a reason that has not been decided yet.

### Read one: is this my product?

Open each image at full size and inspect the product, on every frame:

| Ask | It fails when |
|---|---|
| Does it have the correct number of parts? | a part is missing or invented, or the count is wrong |
| Are the materials correct? | premium reads cheap, cheap reads premium, or one material swallows the rest |
| Are the shape and proportions correct? | a part is reshaped, stretched or shrunk |
| Does the scale feel believable? | a countertop product renders as catering equipment |
| Did the model add, remove, duplicate or invent anything? | a badge, seal or award appears that is not physically on the product |

Compare the result with the real photographs and with the approved sheets. If the product itself is
wrong, this is a Reference Sheet problem. Do not rewrite the creative idea to hide an inaccurate
product. Return to the sheets, correct the mold, approve the new version, and run the test again. If
one frame has the wrong product, the mold is loose and the other frames got lucky.

### Read two: is this the brief I wanted?

You can read a written brief many times and still find it hard to imagine what it will look like. It
is cheaper to make strategic corrections while reviewing the written brief on Day 3, but if you need
to see the idea with your own eyes, this is the place to catch what the written brief did not
reveal. Review every image in gallery order and ask:

- Is the intended message immediately clear?
- Does this image answer the buyer question assigned to it?
- Does it feel useful inside this gallery?
- Does it repeat another image?
- Is an important message still missing?

Do not comment on fonts, colors or layout. Comment on the job and the message. If a slot is
strategically wrong, tell Wonka exactly what needs to change:

```
Revise the brief for [slot number]. The current message is [describe the problem]. Change it to [the corrected message or job], update the saved plan, and rerun that smoke-test image.
```

Wonka updates the brief, updates the saved plan, and reruns only that slot. You correct the
instruction first, then test the corrected instruction, instead of generating the same wrong idea
again and hoping. "I do not want that frame at all" is also a legitimate answer: the slot is dropped
and its selling points re-mapped in the brief.

### The diagnosis

- Wrong product: back to the Reference Sheets.
- Wrong message: back to the brief.
- Different fonts, colors or layouts: they mean nothing at this stage.

### Pass, and lock

When every image passes both reads:

```
The smoke test passes. Lock the reference and mark the smoke test as passed.
```

Wonka writes `Reference status: LOCKED` and `Smoke test: PASS` together in `reference-sheet.md`
and records the passed test in the product status. Both lines have to be there before Day 5 will
generate anything. Now the product is truly locked, because you used the sheets to generate real
images and confirmed the product survived, and that the approved brief produces the messages you
actually wanted.

The pass is your word, never Wonka's. Silence, "ok" or "next" is not a verdict. He asks again,
naming both reads.

---

## Common mistakes, and what they look like

| Symptom | Cause | Fix |
|---|---|---|
| You approved the first sheet because most of it looked good | Politeness, or judging at full size | Zoom in beside the source photos and run all five checks. Two or three rounds is normal |
| The same defect survives two rounds | A missing photo, or an instruction that contradicts the real geometry | Take the photo, or re-check your own claim against the zoomed source. Stop rewording |
| The box shows up in every smoke-test frame | Packaging was put inside the main sheet | Keep packaging out of the main sheet. Give it its own sheet only if a slot stars it |
| Smoke-test frames come out generic, no brand feel | The preset was created but never attached to the plan | Have Wonka read the plan back and confirm the preset and style image are on it |
| The product is wrong in one frame and you rewrote that slot's brief | Fixing the mold with a sentence | A wrong product is a sheet problem. Revise the sheet, approve, rerun |
| A slot's message is wrong and you asked for another image | Fixing the input with the output | Revise the brief for that slot, update the plan, rerun that one image |
| One slot keeps failing read one while the others pass | That slot's brief text describes the product differently from the sheets | Have Wonka fix that slot's wording in the plan, then rerun it |
| Day 5 refuses to generate | `reference-sheet.md` is missing `LOCKED` or `PASS` | Finish the smoke test and give the pass line in your own words |

## What good looks like

- [ ] Every version of every sheet is still on disk as `sheet-v[N].png`. Nothing was overwritten
- [ ] The approved sheets pass all five checks, zoomed in, and at least one carries a visual scale cue
- [ ] Each additional sheet has a stated role, and packaging is out of the main sheet unless you decided otherwise
- [ ] `brand-kit.md` has real hex codes, a font direction, tone, logo rules, and a claims table with proof or the no-claims line
- [ ] The preset and the style image are attached to the saved plan and Wonka read it back with the approval intact. Or the product's status says branding was declined, in your words
- [ ] Every smoke-test frame was opened at full size; read one passed on every frame; read two changed the brief where it needed changing, and only that slot was rerun
- [ ] You said the pass line yourself, and `reference-sheet.md` carries `Smoke test: PASS` and `Reference status: LOCKED`

## Common questions

**The product is not in my hands. Can I still build the sheets?**
Yes, on a weaker path you approve by name: Wonka builds from your own listing gallery and customer
review photos, records the source, and warns that scale and the back of the product are the parts
most likely to drift. The smoke test then matters double. Never a competitor's photo, and never an
AI-generated image, because a reference built from a generation locks that generation's mistakes.

**Can I run the smoke test before the brand step?**
You can, and Wonka allows it. He says once that whatever `/brand-kit` attaches later will not have
been smoke-tested, then continues. The taught order puts the brand first so the test proves the
product and the brief under the settings production will use.

**Can I skip branding entirely?**
Yes. Declining branding for a product is a recorded choice, not a gap. Wonka records it, detaches any
preset, and every later room runs unbranded without stopping to ask.

**Can I change a sheet after the lock?**
Yes. A new version supersedes the old one, and the product goes back through this room. If Day 5's
inspection fails product fidelity on more than one image, that is a reference problem wearing an
image problem's clothes, and the fix is here, not in the Fixing Room.

## What Day 5 opens with

The Main Image Room. The strategy is ready, the product is locked, and the visual direction is
connected if you chose to use it. Tomorrow Wonka reads `Reference status: LOCKED` and
`Smoke test: PASS` before he generates a single candidate. The machines can no longer hallucinate
your product.

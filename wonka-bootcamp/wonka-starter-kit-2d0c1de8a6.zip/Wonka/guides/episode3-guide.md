# Day 3: The Creative Brief

Yesterday you gave Wonka your product and he researched it in depth. Today that research becomes
a clear plan for your images. The plan is called a brief, and it is the first big WOW of the
bootcamp even though it is not an image. It is a document that explains what every image needs
to achieve: which buyer question it answers, which message it communicates, which product details
it must show, and what it must never promise.

Instead of opening an empty prompt and trying to invent an image, you will have a clear reason for
every image in the gallery. You run one skill, answer a few short questions about the main image,
and let Wonka do the work. Then you review his decisions, correct what you know better, approve,
and watch the strategy go into Genrupt.

**The sentence for the day: Wonka decides what each image must communicate. Genrupt decides how
to show it.**

Everything you need is already on disk: yesterday's research sits inside the product folder. Bring
your own opinions. You are the editor of this document, not a spectator.

## What you will have by the end of today

- **`brief/creative-brief.md`**, the working document that follows the product through the rest
  of the Factory: the strategy summary, the gallery structure with one job per image, the
  selling-point coverage map, and the claims check
- **`brief/owner-review.md`**, the short decision page you actually review
- Your corrections, made as focused requests and recorded in the file in your own words
- **The brief approved in words**, and the strategy saved inside Genrupt with your question, your
  message and your product facts in every secondary slot
- The three review questions you will use on every creative brief from now on
- No images. Today decides what every image needs to achieve

---

## Lesson 1: Wonka Builds the Brief

### One command

Open the Product Report from Day 2 so it is fresh in your mind. Then start a new conversation with
the Wonka folder open and type:

```
/creative-brief
```

Before writing a word, Wonka checks which sources are available. Yesterday's research is already
stored inside the product folder, so he reads it from there.

### The line about the Improvement Log

On your first product, Wonka will also mention that the Improvement Log is still empty. Remember
that line.

The Improvement Log is where Wonka stores what he learns over time from working with you: which
messages worked, which directions failed, what you prefer, and which mistakes should not be
repeated. It is empty because this is your first product, so this brief relies on the research and
on the working methods built into Wonka. By your fifth product, he also brings what he learned from
you during the previous four. The Factory does not start from zero every time.

### A few short questions about the main image

Wonka now asks about the main image. These are decisions only the product owner can make: which
directions you are willing to test, whether there is anything you do not want to see in the main
image, and whether there are specific options you want to include.

On screen those questions arrive as his structured controls, and you will see these names:

- **Which tactics are enabled**, out of four: `hang_tag` (a physical tag on the product),
  `human_contact` (a person's hands or presence), `packaging_expansion` (the real retail box in
  frame), and `genrupt_choice` (Genrupt's planner decides). Several at once is normal. Each one you
  leave out gets one line of why
- **Mix and match**, whether one run spreads across the enabled tactics
- **Hang-tag text**, the exact words, up to 28 characters. Too long? Shorten it with him now
- **Use actual packaging**, whether your real packaging photos are used

Answer according to your product and your preferences. Do not search for a perfect answer here.
Later, several main-image options get generated and you choose between actual results.

### What he built: `creative-brief.md`

When he finishes, open the full file. This is the working document that follows the product through
the rest of the Factory. Read it in this order.

**The strategy summary.** At the top, Wonka summarizes what the complete image set needs to prove
in order to convince the buyer. He does not settle for a list of features. He connects what the
product does, what the buyer wants, what worries the buyer, and what the competitors fail to
explain clearly.

**The gallery structure.** Every image has a different job. One may answer the size question.
Another may explain how to use the product. Another may address an objection that appeared
repeatedly in the reviews. Another may show the result of using it. The principle is simple: one
image, one job, one message. If two images are essentially saying the same thing, one of them is
wasting valuable space in the gallery.

**Each slot.** Open two or three secondary slots. For every image, Wonka defines the buyer
question, the central message, and the product details that must appear for that message to stay
credible and accurate. He also records what the image must not promise. All of it comes from
yesterday's research, which is why the research came before any image.

**The coverage map.** Wonka takes every selling point he found and checks where it will appear:
the gallery, the main image, the A+, or nowhere. When he leaves something out, he records the
reason. The goal is not to force everything into every image. The goal is to make sure an
important message was not lost by accident.

**The claims check.** (In the file the section is headed "Promise check".) Can we truly support
everything we are about to say? If a message sounds powerful but the research does not support it,
he softens it, rewrites it, or leaves it out. A strong image should not only sell. It should create
an expectation the product can genuinely meet.

Before the brief reaches you, a mechanical checker runs over the file as well, so your review is
about judgement rather than proofreading.

### The decision page: `owner-review.md`

The full brief can be very long, because every production room will use it later. So Wonka also
writes a shorter file beside it, `owner-review.md`. It is not a second version of the brief. It is a
short decision page that shows only what the product owner actually needs to review: the job of
each image, the selling points that were left out, and the messages that changed during the claims
check, plus the main-image controls you answered, with his reasons.

At this stage you do not correct anything. Look at the result and make sure there is no major
misunderstanding about the product. Corrections and approval are the next lesson.

---

## Lesson 2: Review, Approve, and Send the Strategy to Genrupt

Wonka has already done most of the work. Your job now is not to read hundreds of lines and edit
every sentence. Your job is to review the important decisions, and you do it on `owner-review.md`
with three questions.

### Question 1: does every image have a different job?

Read the buyer questions in gallery order. If two images answer the same question, one of them can
probably do a more valuable job.

### Question 2: why did this message go in, and why was another left out?

Open the selling points left outside the brief and the recorded reasons. This is where your
knowledge as the product owner matters most. Wonka may have removed a point that looked weak in
the research, and you may know from experience that it is one of the main reasons people buy. If
that happens, tell him.

### Question 3: can we truly support what we are saying?

Pay close attention to claims about materials, dimensions, quantities, performance, or results. If
anything is inaccurate, this is the time to correct it, while it is still a line in a document.

### One focused correction at a time

If you want to change something, you do not rewrite the brief. Explain what concerns you and what
you want changed, one request per concern:

```
Revise only [the slot or decision]. My concern is [the specific reason]. Keep the original job, but change [the message or coverage decision] to [the requested correction]. Then confirm that it does not duplicate another image and that the selling point is still covered.
```

Wonka updates only what you requested. Then he checks that the change did not create duplication
and that the selling point did not disappear from the rest of the gallery. He records the change
under Revisions in the file, with your reason in your words, and shows you the corrected section
rather than the whole document.

You can, of course, spend a long time reviewing every line. But the goal is not to turn every
product into a project that takes dozens of hours. Invest your time in the decisions where your
knowledge genuinely changes the result. On your first products, review the decision page more
carefully. After several products, as Wonka learns you and the brand, you will probably focus
mainly on the final decisions and the exceptions.

### Approve, in words

When the corrections are complete, type:

```
The brief is approved.
```

Wonka needs those words, or words that mean the same. "Looks good" is a comment, and silence is
never a yes.

### How Wonka and Genrupt divide the work

Once the brief is approved, Wonka transfers the strategy to Genrupt. To understand what you are
watching, you need to understand how they divide the work.

Genrupt has a planner of its own. It understands patterns that work in different categories and
knows how to plan image types, composition, hierarchy, and visual language. So Genrupt creates its
own initial plan first. But it did not perform the research Wonka completed yesterday. It does not
know all the reviews, all the owner notes, or the decisions you just approved.

So Wonka reads Genrupt's initial plan as a second opinion. If Genrupt found an important idea the
brief missed, Wonka surfaces it and preserves it. Then he updates the strategic part of every image
according to the brief you approved: which question the image must answer, which message it must
communicate, and which product facts it must preserve.

Here is the part that matters most. The brief is not supposed to design the image instead of
Genrupt. If it dictated where every element goes, which color to use, how to build the layout, and
what visual hierarchy to create, it would limit Genrupt and override part of its ability. Wonka
knows not to do that.

| Wonka decides | Genrupt decides |
|---|---|
| What the image must communicate | The best visual way to show it |
| Which buyer question it answers | Composition and layout |
| Which product facts must stay accurate | Colors, hierarchy, visual language |

For example, Wonka may decide that an image must show that the fountain tower comes apart for
easier cleaning. He does not decide whether the parts appear on the right or the left, what color
the background should be, or how the composition is built. Genrupt knows how to make those. The
brand's visual language comes tomorrow, from the branding settings and the style image, never from
long design descriptions inside every image brief.

### The read-back

Wonka reads the saved plan back. He checks every slot to make sure the question, the message and
the product facts reached the correct place, and reports it slot by slot. The main image remains on
its own production path. A+ will be planned later, directly by Genrupt.

You have not generated a single image. Today you decided what every image needs to achieve, and you
connected those decisions to the machine that will create them.

---

## Common mistakes, and what they look like

| Symptom | Cause | Fix |
|---|---|---|
| Wonka refuses to start and names a research file | Day 2 did not finish; `product-report.md` or one of the research files is missing | Run `/meet-my-product` to finish it. The block clears with one command |
| "The Improvement Log is empty" | First product. Expected | Nothing. It starts filling after your first Tasting Round |
| The brief says `pending brand kit` | The brand kit is built tomorrow, on purpose | Nothing. The preset attaches to the saved plan on Day 4 |
| A point you know sells is in the skipped column | The research read it as weak or split | One focused correction with the template. Wonka brings it back and re-maps it |
| You typed "looks good" and Wonka waited | Approval must be explicit | Type `The brief is approved.` |
| Wonka pushes back on your correction | It collides with a factory rule: people in the main image, a claim without evidence | Take the closest lawful version he offers, or drop the request. He never complies silently and never refuses silently |
| Nothing was sent after approval and Wonka points at `/machines-check` | Genrupt is not connected | The approved brief is safe on disk. Connect the machine, then ask him to send. A brief that was never sent is never recorded as sent |
| The saved plan has fewer slots than the brief has jobs | Genrupt's planner set the count | Wonka says which jobs merged or dropped and re-maps their selling points. Read the send log |
| You wrote layout, colors or a person into a correction | Design belongs to Genrupt, the look to tomorrow's preset, casting to its own field | Rewrite the correction as a question, a message or a product fact |

The full list lives in `guides/troubleshooting.md`.

---

## What good looks like

- [ ] Wonka reported the Improvement Log state before writing a word
- [ ] The main-image controls carry your answers: tactics in and out with a reason each, mix and
      match, hang-tag text counted to 28 characters or left to Genrupt on purpose, packaging on or
      off
- [ ] `brief/creative-brief.md` on disk with the strategy summary, the gallery structure, the
      coverage map and the claims check
- [ ] Every image has a different job, and you checked the buyer questions in order yourself
- [ ] Every selling point is placed in the gallery, the main image or the A+, or skipped with a
      recorded reason
- [ ] Every claim about materials, dimensions, quantities and performance is one you can support
- [ ] Corrections typed with the template and recorded under Revisions in your own words
- [ ] `Owner review: approved` in the file, said by you in words
- [ ] The send log shows the plan saved, your text in every secondary slot, slot 1 untouched, and
      anything Genrupt's planner caught that the brief missed
- [ ] Zero images generated

Every day has a list like this one, and together they are the graduation checklist. No sales lift
is promised. Results vary by product and niche.

---

## Common questions

**"The brief has a cast section and a variations section the lesson did not mention. What are they?"**
The cast is one or two custom avatars built from the buyer persona in your research. It travels to
Genrupt as a structured field so the people in your images match your real buyer. The variations
section lists the real sizes, colors or counts your product sells in, or says in writing that there
are none. If the cast is the wrong buyer or the variations are not your real SKUs, that is a
correction, and the template works for it.

**"Wonka rewrote my strongest message in the claims check. Can I have it back?"**
If you can support it, yes: tell him what supports it, a spec, the label, or something you know
about the product, and revise only that message. If the research genuinely cannot support it, he
keeps the job and drops the promise, so the image still does the work without creating an
expectation the product cannot meet.

**"Does anything cost credits today?"**
Writing the brief costs nothing, and re-rolling it costs nothing. The send at the end runs Genrupt's
planner, and Wonka reports its cost from a live preview as he sends. Your approval of the brief is
also the factory's one pre-authorisation point: it covers the reference sheet, the smoke test and
the planned generation batches that follow, which are reported as they run rather than gated again.

---

## What Day 4 opens with

Exactly what you leave here holding: an approved brief on disk, a saved plan in Genrupt, and no
images.

Day 4 is the Reference Room and the Brand Room, in three lessons. First, `/reference-sheet` builds
the Product Reference Sheets from your photos, the collage that locks front, side, back, detail,
scale and material. You approve them, and the room STOPS before the smoke test. Second, the brand
decision: `/brand-kit` builds the branding preset and the style image and attaches them to the plan
you saved today, or you decline branding for this product. Third, the smoke test: one image per
slot, read twice, is this my product, and is this the brief I wanted. Only then is the reference
locked and the first real batch allowed.

The recipe is written and the machine has read it. Tomorrow, the mold.

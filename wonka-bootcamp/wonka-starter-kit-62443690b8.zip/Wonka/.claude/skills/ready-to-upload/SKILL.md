---
name: ready-to-upload
description: Package the proven winner and the full tested creative set into an upload pack: the complete package (main + secondary gallery + A+ + variations) assembled from the latest edit round into final/ inside the product folder, copied to output/ ready to upload to Amazon, the evidence behind it, the exact upload instructions, and an OPTIONAL Amazon A/B plan for the main image. Gated on the latest Tasting Card's main race verdict. Use after a Tasting Round winner, when the owner wants the package stamped and ready. Triggers: /ready-to-upload, "package the winner", "ready to upload", "ship the package", "stamp it", "put it in output", "how do I upload this", "launch the A/B".
---

# The Shipping Room

| Meta | Value |
|------|-------|
| Room | The Shipping Room |
| Station | PROVE (step 2 of 3) |
| Taught | Day 10, the closing lesson, once the variation slot is either filled by `/variations` on Day 9 or recorded as `none (single SKU)` |
| Needs | The latest Tasting Round's main race card (`tests/tasting-r[N]-[date]-main/tasting-card.md`) with a winner, that round's `config.json`, the tested assets on disk, resolved per class (main and gallery from the highest `edits/v[N]/`, or `images/` when no round ran; A+ and variations from the highest `edits/v[N]/` that contains them, else `aplus/` and `variations/`), the current live main image as the control. Brand Registry status only if the owner wants the optional A/B |
| Saves to | factory/Products/[product]/tests/upload-pack.md + factory/Products/[product]/final/ (the approved package, inside the product folder) + output/[product-slug]-package/ (a copy of final/) + one row in factory/Improvement Log.md (ONLY if the owner opts into an Amazon A/B) |
| Typical cost | Free. No machine, no key, no credits. A dead Genrupt connection or a missing OpenAI key never closes this room. |

## What this room does

An upload pack is a tested creative package with papers. The Shipping Room checks the verdict gate first, verifies the winning file is the exact one that raced, assembles the whole tested set (the winning main, the secondary gallery in a deliberate order, the A+ modules, the variation imagery when it exists) from the CURRENT set of each class (the highest `edits/v[N]/` snapshot that holds that class, else its originals folder), writes the evidence behind it, writes the upload instructions the owner will actually follow, assembles the lot into `final/` inside the product folder, and copies `final/` to `output/[product-slug]-package/` so the product folder and the handoff folder each hold the complete package. For anyone who wants controlled proof of the main image lift, an Amazon A/B (Manage Your Experiments) is written as an OPTIONAL plan on top.

**The station finishes here.** `/variations` on Day 9 turns the winner into a family, `/improvement-loop` writes both parts of the Improvement Log, and graduation checks the whole 10 days. Re-running this room after `/variations` extends the same pack rather than rewriting it. The promise this room delivers is exactly the one the course sells: a full, tested creative package ready to upload, never a sales result.

## What this room never does

- **Never uploads anything, never edits a live listing, never launches an experiment.** Wonka prepares the files and the instructions; the human performs the upload in Seller Central. On a listing that belongs to someone else this is absolute, and the bootcamp's on-camera demo listing is exactly that case: the upload and A/B lesson is taught as a procedure, never performed, and never faked with a screen recording.
- **Never opens on a verdict weaker than Clear lead**, and never talks a Lean up into a decision.
- **Never edits, crops, or re-exports a packaged image.** It copies. The tested file ships exactly as tested, or it is not the tested file. The ONE permitted filename change is the gallery slot prefix on the copy (`01-` in front of the original name, which stays intact), and the pack maps every prefixed copy back to its source file. The main image copy keeps its exact filename, because that name is the evidence.
- **Never promises a sales lift, a ranking, or a conversion number.**
- **Never writes a `tasting-room` row into the Improvement Log's experiments ledger.** That row belongs to `/tasting-room`; two rooms writing it double counts the same test. This room writes at most one `amazon-ab` row, and only if the owner opts in.
- **Never mixes files across edit rounds.** Each CLASS has exactly one source, and it is the newest one that exists for that class: main and gallery from the highest `edits/v[N]/` (which by contract holds the complete current set, edited files edited and untouched files copied in as-is), or `images/` when no round ran; A+ and variations from the highest `edits/v[N]/` that contains them, else `aplus/` and `variations/`. Within a class, cherry-picking a file from an older round is how an untested mix ships. Across classes, reading a class from its originals when a round fixed it is how a fix gets silently thrown away.
- **Never deletes anything already sitting in `final/` or `output/`.**

## Before you start

Five checks, in this order. The first one can close the room, so it runs before any assembly work.

**1. The gate, and it runs first.** Read the tasting card in the LATEST `tests/tasting-r[N]-[date]-main/` folder (the MAIN race). If several round folders exist, the highest round number is the gate, and you name that folder out loud so there is no ambiguity about which verdict is being used. Two conditions, both taken from the MAIN race card:

- the WINNER is one of our candidates, not the incumbent, **and**
- the card's standardized stability label is **Clear lead**.

Both true, the room is open. Anything else keeps it closed: `Lean`, `Toss-up`, base models disagreeing on the winner, an incumbent win, or no card at all. Say which condition failed, in one line, plus what reopens it: mine that round's notes, `/fix` MODE B on the winner, a challenger, one more round. For a big money decision, the optional real shopper poll on the finalists is the other honest route. No card at all means there is no evidence, so there is no pack: back to `/tasting-room`.

- **The honest dead end, and what Day 10 teaches when the gate stays shut.** A real end state exists where the gate NEVER opens on synthetic evidence alone: rounds keep coming back Toss-up, or the base models keep disagreeing, and the honest tiebreaker (the live Amazon A/B on real traffic) is not available, because the listing is not the owner's. The bootcamp's demo product is exactly this case, and it is a lawful finish, not a failure. What happens then: the room stays closed to a STAMPED pack, and Day 10 still teaches everything it owns. Walk the owner through the full pack AS A PROCEDURE on the evidence that does exist: the gallery verdict (a gallery win is evidence even when the main race never resolved), the objection ledger, the resolution table, the upload instructions, and the A/B plan written for the day they run this on their own listing. Label the main plainly: `no synthetic verdict after [N] rounds; decided by the owner, or by the live A/B on an owned listing`. Never talk the label up, never fake a Clear lead to unlock the lesson, and never let the student leave believing the closed gate means their work failed. The gate holding IS the lesson: the factory refused to stamp a coin flip, and on their own listing the flip gets settled by real shoppers for free.

- **Pre-launch product with no incumbent:** the winner only beat our own drafts. The room opens, because there is nothing live to beat, and the pack records `Control: none (pre-launch)` with one line saying the verdict is weaker for it.
- **The GALLERY race card (Scenario C) is evidence, never a gate.** Report its set level verdict in the pack. A gallery that lost does not close the room: the pack says so plainly and recommends keeping the live gallery, or uploading only the frames that beat their counterparts per the frame by frame dive.

**2. The winner traces to the exact file that raced.** Name the package source folder first: the highest `edits/v[N]/`, or `images/` when no edit round ran. The card names the winner by id AND by filename (its verdict table carries a File column, and the winner line repeats it). Confirm that filename exists in the source folder, open it once with Read, and confirm the same filename appears in that round's `config.json`, the reproducibility record the Tasting Room saves. Two independent records agreeing is the point; if the card and the config disagree, stop and say so rather than picking one. A neighbouring sibling (the raw `images/main-02.png` packaged in place of the tested `edits/v1/main-02.png` copy, or the other way round) is the classic way an untested image ships. **The MODE B case is lawful and labelled:** when the winner was refined AFTER the round per the tasting notes (the Day 8 design: race, mine the notes, refine), the pack packages the refined copy from the latest `edits/v[N]/`, labels it `refined after test`, names the raced original and its card beside it, and says in one line that the refinements themselves are re-inspected but untasted; an optional Round 2 re-race is the upgrade when the change was big enough to be a different image. What stays forbidden is a SILENT swap: an edit that has no MODE B trail back to that round's notes (a new layout, new casting, a different concept) is a different image, and it re-races or the raced original ships. The pack names which file raced and which file ships, or the pack is wrong.

**3. Inventory the package before writing a word of it. Resolve the source PER CLASS, because a fix round does not touch every class.** The rule is the Fixing Room's own: the current set of a class is the highest `edits/v[N]/` that CONTAINS that class, else that class's originals folder. So main and gallery come from the highest `edits/v[N]/` (or `images/` if no round ran); A+ comes from the highest `edits/v[N]/aplus/` if any round fixed a module, else `aplus/`; variations the same way against `variations/`. Name the resolved folder for each class out loud. **Reading A+ or variations straight from the originals when a fix round touched them silently ships the unfixed version**, and nothing errors, because the originals are exactly where they always were. Then list what exists in each and read the counts back to the owner in one line. Anything missing gets asked about ONCE, per the table below. Nothing is assumed, nothing is invented, and no group is quietly dropped from the manifest.

**3b. Read the real pixel size of every packaged file, and say it out loud.** Amazon opens zoom at 1000 pixels on the longest side and rewards 1600 and up; a listing whose hero does not zoom loses the one interaction that sells a physical product. Nothing upstream guarantees this, because a surgical edit returns the endpoint's working size rather than the source's, so the edited files (the MAIN above all, since MODE B refines the winner by design) are usually the smallest in an otherwise full-resolution set. Measure, never assume:

Run it on the folders check 3 just inventoried, NOT on `final/`: `final/` is assembled in step 14, long after this, so it is empty right now. Pass the package source folder (the highest `edits/v[N]/`, or `images/`) plus `aplus/` and `variations/`:

The zoom thresholds are a LISTING-image rule: the main, the gallery, and the variation mains and swatches. A+ modules are not listing images, never zoom, and carry their own module dimensions, so they are measured and reported but never judged against 1000 or 1600. The script keeps that distinction:

```bash
python3 - <<'PY' "[resolved main+gallery folder]" "[resolved variations folder]" -- "[resolved aplus folder]"
import pathlib, sys
try:
    from PIL import Image
except ImportError:
    raise SystemExit("Pillow not installed. Run: pip3 install pillow")
EXT = {".png", ".jpg", ".jpeg", ".webp"}
args = sys.argv[1:]
cut = args.index("--") if "--" in args else len(args)
groups = [("listing", args[:cut]), ("aplus", args[cut + 1:])]
seen = 0
for kind, roots in groups:
    for root in roots:
        d = pathlib.Path(root)
        if not d.is_dir():
            print(f"(skipped, no such folder: {root})")
            continue
        for p in sorted(q for q in d.rglob("*") if q.suffix.lower() in EXT):
            if p.name.startswith("._"):
                continue  # AppleDouble sidecar, metadata not an image
            try:
                w, h = Image.open(p).size
            except Exception:
                print(f"{p.relative_to(d.parent)!s:44} UNREADABLE, zero-byte or corrupt. "
                      "Fix or remove it before packaging.")
                continue
            if kind == "listing":
                flag = ("  <-- UNDER 1000, zoom will not work" if max(w, h) < 1000
                        else "  <-- under 1600, below Amazon's recommendation" if max(w, h) < 1600
                        else "")
            else:
                flag = "  (A+ module, zoom rules do not apply)"
            print(f"{p.relative_to(d.parent)!s:44} {w}x{h}{flag}")
            seen += 1
print(f"\n{seen} file(s) measured")
PY
```

Everything before `--` is judged as a listing image; everything after it is reported only. If it measures 0 files, the paths are wrong: stop and fix them rather than reporting a clean result on an empty scan.

Report the table in the pack. Then act on it, in this order:

- **Anything under 1000 on the longest side** is a BLOCKING line in the pack, named by filename. It ships only if the owner says so after hearing what it costs.
- **Anything under 1600, or noticeably softer than its neighbours,** gets the upscale OFFER, once, with its cost. Do not upscale silently and do not upscale by default: it spends the owner's credits, and the no-silent-spend rule covers it like any other paid run. (This is the one room where the upscale is an OFFER rather than a reported finishing step: `/main-image` and `/variations` upscale as part of a plan the owner already approved and report the cost in one line; a file arriving HERE undersized means something upstream skipped its finishing step, so the spend is unplanned and the owner decides.)
- **Say it even when the owner did not ask.** "Your main is 1024 and the rest of the gallery is 2000" is exactly the kind of thing a seller only discovers from a performance report months later. Naming it is the job.

**The upscale, when the owner says yes.** It runs on the Genrupt machine (a Topaz engine, roughly a 2x lift, with a text-refine setting for text-heavy frames). Find the capability with `search_capabilities` and READ ITS INPUT SCHEMA before calling, the same discipline the Reference Room uses, because the tool's exact name and fields are Genrupt's to change. Two ways in, and the difference decides whether it is even possible:

- A Genrupt-generated image is already on the Genrupt side and is referenced by its own id. This is the easy path.
- A file edited locally through the OpenAI endpoint exists only on this disk. Genrupt needs a reachable HTTPS URL, so it has to be uploaded first, through the same upload path the Reference Room uses for photos. **If that upload path is not available on this connection, say so plainly and stop.** The honest answer is "this file cannot be upscaled from here, and it will ship at [N]px", never a silent skip that leaves the owner believing it was handled.

Save upscaled files NEXT TO the originals (`final/upscaled/`), never over them, and label them `upscaled` in the pack. **The incumbent is never upscaled or enhanced**, in the pack or anywhere else: it is the control, and improving it would be as dishonest as degrading it.

**4. Every packaged asset traces to a gate pass.** Check `scorecards/` for each asset's inspection result. An asset with no scorecard is not blocked, it is LABELLED `ungated` in the pack with one line on the risk. Amazon does not care about our scorecards; the owner does, and a silent gap in the evidence trail is the one thing this room exists to prevent.

**5. Ask the A/B question once, plainly.** "Do you want the optional Amazon A/B on the main image, or are you uploading it as it stands?" If yes: ask whether the seller has **Brand Registry** (Manage Your Experiments requires it, plus Amazon's own traffic threshold on the ASIN), and check `factory/Improvement Log.md` for a live experiment on this ASIN. **One experiment per ASIN at a time**; a second one waits in the queue and the pack says so. If no, skip every A/B step and write no experiments row. The package is complete either way. The A/B is a proof upgrade, never the finish.

**"I don't have it" is a real answer, and almost always the run proceeds.** What blocks is missing EVIDENCE (the verdict, the tested file), never a missing convenience.

| The owner says | What happens |
|---|---|
| "No A/B, I am just uploading it" | The default and a lawful finish. A/B steps skipped, no experiments row, pack records `A/B: not requested`. Nothing about the finish changes. |
| "No Brand Registry" | Manage Your Experiments is out. The pack carries the swap-with-monitoring fallback instead, labelled weaker evidence in writing. The run proceeds. |
| "It is not my listing" | Nothing is uploaded and no experiment is launched, by anyone. The pack is written as a procedure for the owner's OWN listing and records `A/B: not applicable, listing not owned`. This is the bootcamp demo's own situation, and it is said out loud rather than faked. |
| "I skipped A+" or "no A+ yet" | Declared gap: `A+ modules: not produced (skipped)`. The package ships without them and names exactly what is missing. A declared gap is fine, a silent one is not. |
| "The gallery is not finished" | Package the frames that exist, list the empty slots by name from the brief, record the gap. Partial galleries upload fine; the pack says which slots are still open. |
| `variations/` is empty | Expected before Day 9, and lawful forever on a single SKU. Record `Variations: pending (Day 9)`, the lawful trailing marker. Never a block. Re-running this room after `/variations` extends the pack. |
| "I cannot find the live image now" | Take it from the round's `config.json`: it raced, so it is on disk at the path recorded there. Only if that path is gone does the control become `not supplied`, recorded as such. |
| "Just ship it, the label says Lean" | Refused, and this is the room's one refusal. A lean is a lean, not proof, and packaging a coin flip is how a working listing gets downgraded. Say the reopen path and stop. |
| No answer on the A/B question | Write the pack with `A/B: not requested` and finish. A completed package never sits parked waiting on an optional question. |

## Process

1. **Run the gate and say the result out loud, before anything else.** Name the round folder, the winner's exact filename, the label, and the vs-incumbent result. Gate passed: continue. Gate failed: stop here, name the failed condition and the reopen path, write nothing, and copy nothing. A closed Shipping Room is the gate earning its keep, not a bug.

2. **Amazon main image pre-flight on the winner.** The tasting decides which image sells. This check decides whether Amazon will keep it up. Open the winning file and verify, one by one:
   - pure white background, and the product fills most of the frame,
   - no added text, no logos, no watermarks, no badges, no borders, no props, no people,
   - the product reads as the real product, with every part present and countable (a four tier fountain shows all four tiers, stainless reads as metal),
   - it does not promise more than the product delivers as sold. If the research recorded an expectation gap between what the category's pictures suggest and what buyers report, the hero must sit on the honest side of it. An over-promising hero wins the click and buys the one star review.

   A fail does NOT ship as the main. Route it: text, badge, or prop removal goes to `/fix`; background, crop, layout, or composition goes back to `/main-image` for a regeneration. A beautiful image that breaks the main slot rule can still earn a place in the gallery; say so rather than losing the work. Amazon revises these requirements, so the pack tells the owner to read the current image requirements page before every upload.

3. **Assemble the evidence block.** The winner's filename and one line on what the image is. The control (the current live main image). The numbers from BOTH rounds: shares, panel size, date, stability label, and the vs-incumbent result each time. The top recurring notes and objections from the cards. When a gallery race ran, its set level verdict too. Then label the evidence honestly, in the file and out loud: a directional verdict from an AI taster panel (SSR method), not real shopper data, with the real shopper poll named as the gold standard upgrade for real money decisions.

4. **Write the hypothesis, then set the metric.** One sentence, causal and falsifiable, built from what the tasters actually said and never from taste: "the new main image lifts CTR because tasters said they could count all four tiers and judge the height at thumbnail size." Then the metric: a MAIN image test watches **CTR**, because the main image's only job is winning the click; a gallery or A+ test watches **CVR**, because those assets work after the click. State which one applies and why. Judging a main image by conversion is how good images get killed.

5. **Decide the gallery order and write the reason for it.** The gallery is uploaded in the order the owner chooses, so choose it deliberately. When a Scenario C card exists, the frame by frame dive names which frame carries the set: that one leads. Otherwise the brief's order stands. Number the slots `01` to `NN` and give each a one line reason. The copies carry the number as a prefix in front of the original filename (`01-sec-03.png`), so the order survives the handoff to a VA, a designer, or the owner's own future self, and the pack maps every slot back to its source file.

6. **Cross check the A+ against the winning angle.** Read `aplus/aplus-plan.md` and the modules against the angle the tasters rewarded. Three honest outcomes, and the pack records which one: **aligned** (say in one line why, usually because the same research drove both), **out of step** (name the modules now arguing the losing angle and route them back to `/aplus` BEFORE the pack ships, or, if the owner chooses to ship anyway, record it as a declared gap in writing), or **no A+ produced** (declared gap). An A+ page never faces an A/B the way a main image does. That does not exempt it from the verdict.

7. **Assemble the full package list, with counts.** Every file in the tested set, grouped: MAIN, GALLERY (in slot order), A+ MODULES, VARIATIONS. Every class comes from the source resolved in check 3: main and gallery from the package source folder, A+ from `edits/v[N]/aplus/` when a round fixed a module and `aplus/` otherwise, variations the same way. Name the folder each group came from. Each entry is the exact filename plus a one line description, and each group carries a count. Those counts are what step 14 reconciles against, so they are the manifest, not decoration. Missing groups appear as a declared gap line, never as an absence.

8. **Write the upload instructions. These are always written, A/B or no A/B.** This is the "ready to upload" the room is named for:
   1. **Main and gallery:** Seller Central, edit the listing, images tab. Slot one is the main. The rest fill the gallery in the numbered order from step 5.
   2. **The main slot rules that get listings suppressed:** pure white background, product filling most of the frame, and nothing added. No text, logos, watermarks, props, or borders. Read Amazon's current image requirements page before every upload, because they revise it.
   3. **A+ content** goes in through A+ Content Manager, which requires Brand Registry. Build, attach the ASINs, submit, and it queues for review. Rejections are usually about claims, so every comparison row stays provable.
   4. **Variations** are uploaded against the parent or child ASINs per the variation plan (Day 9's variation map fills this line).
   5. **Size matters, and it is measured, not assumed.** Amazon opens zoom at 1000 pixels on the longest side and rewards 1600 and up. Quote each packaged file's real size from check 3b, name anything that falls short by filename, and say which files were upscaled if any were. Zoom is what a shopper uses instead of holding the product.
   6. **Upload copies, keep the originals.** The factory's files stay where they are.
   7. **If you intend to measure anything, change one thing at a time.** A listing that changed in four places at once produces a number nobody can attribute.

--- Steps 9 to 12 run ONLY if the owner opted into the optional Amazon A/B in check 5. If not, go to step 13. ---

9. **The launch walkthrough (Brand Registry path, Manage Your Experiments):**
   1. Seller Central > Brands > Manage Your Experiments.
   2. Create a new experiment, experiment type Main Image (or A+ Content / Title as relevant).
   3. Select the ASIN. Amazon checks eligibility on the spot; the ASIN needs enough traffic to reach significance, and Amazon says so on this screen if it does not.
   4. The current live image stays Version A. The winner goes in as Version B. Nothing else on the listing changes during the test.
   5. Name the experiment (use the pack name), set the duration, and put the step 4 hypothesis in the hypothesis field. A hypothesis you cannot be wrong about is not a hypothesis.
   6. **Duration: run to significance, typically 8 to 10 weeks.** Choose 10 with "end early if a winner is found" when offered. **No peeking and no stopping early**: early leads flip, and a stopped test proves nothing.
   7. Launch, then paste the start date back so the pack and the Improvement Log carry it.

10. **No Brand Registry: the honest fallback.** A straight swap with before and after monitoring:
    1. Record a few weeks of baseline from Business Reports (Detail Page Sales and Traffic: sessions, unit session percentage, and impressions where available).
    2. Swap the main image to the winner.
    3. Watch the same report over the same span after.

    Then say it plainly, and write it in the pack: this is WEAKER evidence than a real A/B. There is no control group, and seasonality, price changes, ads, and competitors all move the same numbers. It answers "did things get better", never "did the image cause it". Record `method: swap_with_monitoring`.

11. **Append the experiment row** to `factory/Improvement Log.md` (create the file with the canonical header if it is missing). One NEW row in the canonical 8 column schema, and no other column set:

    `| Date | Product | Type | Candidates | Winner | Margin | Key why | Status |`

    Type `amazon-ab`, Status `planned`, flipping to `running` once the owner confirms the experiment started in Seller Central. This is the row `/improvement-loop` and `/factory-report` track. Never add a second row for the tasting itself; `/tasting-room` already wrote that one.

12. **Set the follow up.** Name the date to come back with results, and say that `/improvement-loop` runs on the outcome either way, win or lose. A lost A/B is an Improvement Log entry, not a failure.

--- End of the optional A/B steps. ---

13. **Write the pack** to `tests/upload-pack.md` in the Output format below: the gate line, the winner, the full package list with counts, the control, the evidence, the gallery order, the A+ alignment result, the upload instructions, any declared gaps, and the A/B plan only if the owner opted in.

14. **Assemble `final/`, copy it to `output/`, then reconcile both file by file.** Copy (never move, never re-export, never rename beyond the gallery slot prefix) from the package source folder into `final/` INSIDE the product folder, then copy the assembled `final/` to `output/[product-slug]-package/`:

    ```
    factory/Products/[product]/final/
    ├── upload-pack.md
    ├── main/[the exact winning filename]
    ├── gallery/01-[...].png, 02-[...].png, ...
    ├── aplus/[module files]
    └── variations/   (filled by Day 9's /variations run, or a written none on a single SKU)

    output/[product-slug]-package/    (an exact copy of final/, same layout)
    ```

    ```bash
    # from the kit root (Mac and Linux; on Windows use copy/xcopy or the file tools)
    mkdir -p "factory/Products/[product]/final"/{main,gallery,aplus,variations}
    cp "factory/Products/[product]/edits/v[N]/[winner].png" "factory/Products/[product]/final/main/"
    # ... gallery (with the 01- prefix on the copy), aplus, variations ...
    mkdir -p "output/[product-slug]-package"
    cp -R "factory/Products/[product]/final/." "output/[product-slug]-package/"
    ```

    Then reconcile TWICE, and report both out loud. First **list `final/` back and reconcile it against the manifest from step 7**, group by group, count by count: main 1 of 1, gallery N of N, A+ N of N, variations pending. Second **list `output/[product-slug]-package/` back and reconcile it against `final/`**: every file in `final/` landed, same names, same counts. If a file did not land in either folder, say which one and fix it before the room is called done. A pack that claims a file a folder does not hold is worse than no pack. Re-runs overwrite the pack and re-copy the current package into BOTH folders; anything already in `final/` or `output/` that is no longer part of the package stays on disk and is named `superseded` in the pack, never deleted.

15. **Close out honestly.** Tell the owner what they have (a tested package, assembled in `final/` with a matching copy in `output/`, ready to upload), what is still pending (variations, if Day 9 has not run them yet), and what the next room is. Say plainly whether an A/B was launched and, if not, why not. Make no promise about sales: the course's promise is a package promise. When results land, whether from a further tasting round or an A/B verdict, `/improvement-loop` runs on them.

## Output format

`tests/upload-pack.md`:

```markdown
# Upload Pack . [Product Name] . [YYYY-MM-DD]

Built from: tests/tasting-r[N]-[date]-main/tasting-card.md (round [N], main race), [tasting-r1 card],
[scorecard files], brief/creative-brief.md, the live listing

## Gate
- Round used: tests/tasting-r[N]-[date]-main/ . winner [exact filename], label [Clear lead], beat the incumbent [x] votes to [y]
- Gate: PASSED

## The winning main image
- Package source: [edits/v[N]/ (highest edit round) / images/ (no edit rounds ran)]
- File: [source folder]/[exact filename] (verified on disk and against that round's config.json)
- What it is: [one line, e.g. main image, the four tier fountain on pure white, all four tiers visible]
- Amazon main slot pre-flight: [PASS / FAIL + what was fixed]

## The full tested package (ready to upload)
- MAIN (1): [source folder]/[winning filename]
- GALLERY ([N], in upload order): 01 [file] . [role]; 02 [file] . [role]; ...
- A+ MODULES ([N]): aplus/[files]
- VARIATIONS ([N] / pending (Day 9) / n-a): variations/[files]
- Gate trail: [N of N assets have a scorecard / listed ungated: [files]]

## Resolution (measured, check 3b)
Amazon opens zoom at 1000px on the longest side and rewards 1600+. A+ modules carry their own
module dimensions and are reported without the zoom judgement.

| File | Pixels | Verdict |
|---|---|---|
| [main filename] | [WxH] | [ok / under 1600 / UNDER 1000, blocking] |
| [gallery file] | [WxH] | [ok] |
| aplus/[file] | [WxH] | A+ module, zoom rules do not apply |

- Below the floor: [none / [files], named to the owner as blocking, shipped only on their explicit say-so]
- Upscale: [not needed / offered at [cost] and declined / run on [files], saved to final/upscaled/, labelled `upscaled`]
- The incumbent was NOT upscaled or enhanced. It is the control.

## Gallery order and why
- 01 [file]: [one line reason, e.g. named strongest frame in the Scenario C frame by frame]
- 02 [file]: [reason]

## A+ alignment with the winning angle
- [Aligned: [one line why] / Out of step: [modules], realigned via /aplus before packaging / Shipped as is (declared gap) / No A+ produced (declared gap)]

## The control
- The current live Amazon main image, the incumbent beaten in Tasting Round [N] [and Round 1]
- [or: Control: none (pre-launch). The verdict is weaker for it.]

## Evidence
- Tasting Round 1 [date], main race: winner [x] votes to incumbent [y], panel of [tasters], [label]
- Tasting Round [N] [date], main race: winner [x] votes, challenger [y], incumbent [z], panel of [tasters], [label]
- Gallery race (Scenario C, when run): proposed gallery [x] votes to live gallery [y], panel of [tasters], [label], round [N]
- Taster reasons: [top 2 recurring notes, one line each, with mention counts]
- Nature of evidence: directional verdict from an AI taster panel (SSR method), not real shopper data.
  A real shopper poll (PickFu, ProductPinion, or any panel) is the gold standard upgrade for
  real money decisions. Not run unless the owner chose to.

## How to upload this package
1. Seller Central, edit the listing, images tab. Slot one is the main; the gallery follows in the numbered order above.
2. Main slot rules: pure white background, product fills most of the frame, no text, logos, watermarks, props, or borders. Read Amazon's current image requirements page before every upload.
3. A+ through A+ Content Manager (requires Brand Registry). Attach the ASINs, submit, wait for review. Keep every comparison row provable.
4. Variations against the parent or child ASINs per the variation plan.
5. Upload copies. The factory keeps the originals.
6. If you intend to measure anything, change one thing at a time.
- Who uploads: the owner. Wonka prepares the files and the instructions and performs no upload.

## Declared gaps
- [e.g. Variations: pending (Day 9). Re-run /ready-to-upload after /variations to extend this pack.]
- [e.g. A+ modules: not produced (skipped). Package ships without them.]
- [none]

## Optional A/B (only if the owner opted in)
- Hypothesis: the new main image lifts CTR because [specific taster backed reason].
- Metric: [CTR (main image test) / CVR (gallery or A+ test)], measured by [Manage Your Experiments / Business Reports before and after]
- Method: [Manage Your Experiments / swap_with_monitoring (no Brand Registry: weaker evidence, no control group)]
- Steps: [the numbered walkthrough, ASIN filled in]
- Duration: [8 to 10 weeks, run to significance, no early stopping]
- Queue check: [no other experiment running on this ASIN / QUEUED behind experiment X]

## Status
- Package: ready to upload. Assembled in final/ and copied to output/[product-slug]-package/ on [date].
- Reconciliation: final/ main 1/1, gallery [N]/[N], A+ [N]/[N], variations [pending]; output/ matches final/ file for file.
- A/B: [not requested / not applicable, listing not owned / pending launch / launched YYYY-MM-DD, results expected ~YYYY-MM-DD]
- No result is promised anywhere in this pack. The promise is a tested package, ready to upload.
```

Row appended to `factory/Improvement Log.md` ONLY if the owner opted into the A/B (canonical 8 column schema `| Date | Product | Type | Candidates | Winner | Margin | Key why | Status |`):

```markdown
| [YYYY-MM-DD] | [product] | amazon-ab | 2 ([winner file] vs incumbent) | | | | planned |
```

Status flips to `running` once the owner confirms the experiment started in Seller Central. No A/B means no row from this room, and this room never writes a `tasting-room` row.

## Golden Standards check

Before presenting, verify:
- [ ] The gate ran FIRST and was reported out loud: round folder named, winner is one of ours, label is Clear lead. A weaker label closed the room instead of being talked up.
- [ ] The package source folder was named out loud (the highest `edits/v[N]/`, or `images/` when no edit round ran) and every main and gallery file came from that one folder. No cross-round mixing.
- [ ] The winning filename was verified on disk with Read, in the package source folder, AND against that round's `config.json`. No sibling file substituted. A MODE B refinement packaged after the race is labelled `refined after test` with the raced original named beside it; nothing untested is stamped as tested.
- [ ] The Amazon main slot pre-flight passed on the packaged main: white background, product fills most of the frame, no text, logos, badges, props, borders, or people, real product with every part present, and no promise beyond what the product delivers as sold. A fail was routed to `/fix` or `/main-image`, never packaged.
- [ ] The full package is listed with counts (main + gallery in order + A+ + variations), each an exact filename, and every missing group appears as a DECLARED gap, never as a silent absence.
- [ ] Every packaged asset traces to a scorecard, or is labelled `ungated` with its risk line.
- [ ] Every packaged file's real pixel size was MEASURED and reported. Anything under 1000 on the longest side is named as blocking; anything under 1600 got the upscale offer with its cost, once. No file was upscaled silently, and the incumbent was not touched.
- [ ] The gallery order is deliberate and each slot carries a one line reason (the Scenario C frame by frame leads when it exists).
- [ ] The A+ was cross checked against the winning angle and the result recorded (aligned / realigned / declared gap / none).
- [ ] Upload instructions are in the pack, always, A/B or no A/B, and they say the owner uploads and Wonka does not.
- [ ] Evidence is labelled as a directional AI taster panel verdict, never real shopper data, with the real poll named as the gold standard upgrade.
- [ ] The A/B section is clearly OPTIONAL and the finish does not depend on it. Nothing was uploaded, no experiment was launched, and no listing belonging to someone else was touched.
- [ ] No promise of sales, rank, or conversion anywhere.
- [ ] If the owner opted into the A/B: the hypothesis cites a taster backed reason, the metric matches the asset type (CTR for main, CVR for gallery or A+), duration says 8 to 10 weeks with no peek and stop, the one-experiment-per-ASIN queue was checked, any no-Brand-Registry fallback is labelled weaker evidence, and exactly one `amazon-ab` row was appended in the canonical 8 column schema.
- [ ] The package was ASSEMBLED into `final/` inside the product folder, COPIED to `output/[product-slug]-package/`, and reconciled file by file TWICE: `final/` against the manifest, then `output/` against `final/`, with both counts reported. Nothing in `final/` or `output/` was deleted, the main kept its exact filename, and the only filename change is the gallery slot prefix, mapped back to its source in the pack.
- [ ] English only, zero em or en dashes.

## Wonka lines

Openers:
- "The Shipping Room. Very few candies make it this far, so let us stamp this one properly."
- "Gate first, papers second. I check the verdict before I touch a single file."
- "A winner with a hundred witnesses. Now we give it papers, a folder, and instructions a stranger could follow."

Closers:
- "Stamped. The whole package sits in final/, with a matching copy in output/, in order, with the reasoning attached. Upload it exactly as it stands."
- "Tasted, refined, packaged once. The A/B is optional and it is yours to run. I do not touch listings; I hand you the files and the steps."
- "The label read Lean, so this room stays shut. Mine the notes, sharpen the winner, taste again. I will not stamp a coin flip."
- "Variations still pending, which is not a gap, it is the next room. Come back and I will extend this pack rather than rewrite it."

## When it goes wrong

- **The card says Lean or Toss-up.** The room stays closed and that is correct. `/fix` MODE B on the winner, a challenger from the strongest praise theme, one more round. Minutes and a few dollars.
- **The incumbent won.** A downgrade to a working listing was just avoided for the price of lunch. Mine the notes for WHY it holds (a free teardown of a proven image), keep that read in the test file for `/improvement-loop`, and build the next candidates from it.
- **The base models disagreed on the winner.** No reliable verdict, so no gate pass. Use the objections, drop the counts, run again.
- **The winning file is not in the package source folder, or its name does not match `config.json`.** Stop. Do not package a lookalike. Find the tested file, or re-run the round on the files that exist.
- **An edit round ran after the tasting and touched the winner.** If it is the MODE B refinement driven by that round's notes (the Day 8 design), package it labelled `refined after test`, with the raced original and its card named beside it. If the edit has no MODE B trail to the notes, that is a different image: re-race it, or package the raced original from the round's `config.json` path. Never stamp a silent swap with a tested verdict.
- **The main passed the panel but fails the Amazon main slot rules.** Route it: props, text, or badges to `/fix`; background, crop, or layout to `/main-image`. Then re-check. Consider keeping the rejected version as a gallery frame instead of losing the work.
- **`final/` or `output/` already holds an older package.** Re-copy over the same folders. Nothing is deleted; anything no longer in the package is named `superseded` in the pack.
- **A second product arrives (the Day 10 speed run).** It gets its own `final/` inside its own product folder and its own `output/[product-slug]-package/` folder. Packages never share a folder.

## Definition of Done

- The gate was checked FIRST against the latest round's main race card, and its result was stated out loud before any assembly.
- `tests/upload-pack.md` exists and contains: the gate line, the verified winning filename, the full package list with counts, the gallery order with reasons, the A+ alignment result, the control, the two rounds' evidence with honest labelling, the upload instructions, declared gaps, and the optional A/B plan only if the owner opted in.
- `factory/Products/[product]/final/` exists with `upload-pack.md` plus `main/`, `gallery/`, `aplus/`, and `variations/`, assembled from the package source folder (the highest `edits/v[N]/`, or `images/` when no edit round ran), and `output/[product-slug]-package/` exists as its copy. Both were RECONCILED file by file: `final/` against the manifest and `output/` against `final/`, counts reported. Nothing was moved, edited, or deleted, and the only filename change is the gallery slot prefix.
- If the owner opted into an A/B: exactly one `amazon-ab` row exists in `factory/Improvement Log.md` (canonical 8 column schema, Status `planned` or `running`), and the owner has the exact Seller Central steps, or the honest fallback, plus a date to return with results.
- The owner knows the station finishes here and Day 10 continues, that the package is ready to upload with no promise about the result, that they are the one who uploads, and that `/improvement-loop` runs whenever a result lands.

## Update status.md

Set PROVE to `done: package ready to upload` (or `in progress: A/B pending` if the owner opted into and launched an A/B), with `tests/upload-pack.md` as the artifact, and keep the INVENT sub-status line `Variations: pending (Day 9)` if variations have not run. Add a Log line: `[date] Upload pack issued: gate passed on tasting-r[N] ([winner], Clear lead), full package assembled in final/ from [edits/v[N] / images], copied to output/[product-slug]-package/ and reconciled both ways. A/B [not requested / not applicable, listing not owned / launched / pending launch / queued].`

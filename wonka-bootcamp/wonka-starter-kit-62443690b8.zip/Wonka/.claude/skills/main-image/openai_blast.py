#!/usr/bin/env python3
"""
The OpenAI Blast engine for the Main Image Room (Path B of the dual blast).

Wonka authors prompts.json; this script runs the pool and builds the pick sheets.
It is deliberately dumb: no retries beyond one attempt, no prompt editing, no
decisions. Resume is free: re-running skips every pool file already on disk.

Usage:
    python3 openai_blast.py run   prompts.json OUT_DIR   # generate the pool
    python3 openai_blast.py sheet OUT_DIR                # build pick sheets (20 tiles each)

prompts.json:
    {"product": "...", "refs": ["path1.jpg", ...], "images": [
        {"number": 1, "tier": "t1-pure", "variation": 1, "prompt": "..."}, ...]}

Pool filename contract (canonical, never improvise a different one):
    pool-NN_TIER_vV.png            e.g. pool-07_t2-tag_v3.png
The printed id on the sheet is "NN" and that is how the owner names a pick.

Env: OPENAI_API_KEY (loaded from ./.env if unset), QUALITY (default low),
WORKERS (default 6), SIZE (default 1024x1024).
"""
import base64
import json
import os
import sys
from pathlib import Path


def load_key():
    if os.environ.get("OPENAI_API_KEY"):
        return
    env = Path(".env")
    if env.exists():
        for line in env.read_text().splitlines():
            if line.startswith("OPENAI_API_KEY="):
                os.environ["OPENAI_API_KEY"] = line.split("=", 1)[1].strip().strip('"').strip("'")
                return
    sys.exit("OPENAI_API_KEY not set and no .env found. The Machine Room (guides/mcp-setup-guide.md, Part 2) covers this.")


def run(prompts_file, out_dir):
    load_key()
    from concurrent.futures import ThreadPoolExecutor, as_completed
    try:
        from openai import OpenAI
    except ImportError:
        raise SystemExit(
            "The openai package is not installed. Run: "
            "python3 -m pip install openai pillow"
        )

    client = OpenAI()
    quality = os.getenv("QUALITY", "low")
    size = os.getenv("SIZE", "1024x1024")
    workers = int(os.getenv("WORKERS", "6"))
    data = json.loads(Path(prompts_file).read_text())
    base = Path(prompts_file).parent
    refs = [str(p) if os.path.isabs(p) else str(base / p) for p in data["refs"]]
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    images = data["images"]
    print(f"OpenAI Blast: {len(images)} prompts | quality={quality} | {len(refs)} refs | model gpt-image-2")

    def one(img):
        name = f"pool-{img['number']:02d}_{img['tier']}_v{img['variation']}.png"
        path = out / name
        if path.exists() and path.stat().st_size > 10000:
            return (img["number"], "skipped (exists)")
        handles = []
        try:
            handles = [open(p, "rb") for p in refs]
            r = client.images.edit(model="gpt-image-2", image=handles, prompt=img["prompt"],
                                   size=size, quality=quality, n=1)
            path.write_bytes(base64.b64decode(r.data[0].b64_json))
            return (img["number"], "generated")
        except Exception as e:
            return (img["number"], f"FAILED: {str(e)[:180]}")
        finally:
            for h in handles:
                try:
                    h.close()
                except Exception:
                    pass

    results = []
    with ThreadPoolExecutor(max_workers=workers) as ex:
        for f in as_completed([ex.submit(one, i) for i in images]):
            n, status = f.result()
            print(f"  pool-{n:02d}: {status}", flush=True)
            results.append((n, status))
    gen = sum(1 for _, s in results if s == "generated")
    skip = sum(1 for _, s in results if s.startswith("skipped"))
    fail = [(n, s) for n, s in results if s.startswith("FAILED")]
    print(f"reconciliation: planned {len(images)} = generated {gen} + skipped {skip} + failed {len(fail)}")
    for n, s in fail:
        print(f"  pool-{n:02d} {s}")


def sheet(out_dir):
    try:
        from PIL import Image, ImageDraw
    except ImportError:
        raise SystemExit(
            "Pillow is not installed, so the pick sheet cannot be built. Run: "
            "python3 -m pip install pillow"
        )

    out = Path(out_dir)
    files = sorted(out.glob("pool-*.png"))
    if not files:
        sys.exit(f"no pool-*.png files in {out}")
    # An interrupted run leaves zero-byte or truncated pool files behind. One bad
    # tile must not kill the whole sheet: name it, skip it, and let the rerun of
    # `run` regenerate it (resume skips only files that open cleanly here too).
    readable = []
    for f in files:
        try:
            with Image.open(f) as im:
                im.load()
            readable.append(f)
        except Exception:
            print(f"  SKIPPED unreadable pool file (interrupted run?): {f.name}. "
                  f"Delete it and re-run `run` to regenerate that tile.")
    files = readable
    if not files:
        sys.exit(f"no READABLE pool files in {out}; delete the broken ones and re-run `run`")
    COLS, ROWS, TH, LABEL = 4, 5, 420, 26
    per = COLS * ROWS
    pages = [files[i:i + per] for i in range(0, len(files), per)]
    for p, chunk in enumerate(pages, 1):
        sheet_im = Image.new("RGB", (COLS * TH, ROWS * (TH + LABEL)), "white")
        d = ImageDraw.Draw(sheet_im)
        for i, f in enumerate(chunk):
            x, y = (i % COLS) * TH, (i // COLS) * (TH + LABEL)
            d.rectangle([x + 2, y + 2, x + 250, y + LABEL - 4], fill="black")
            d.text((x + 8, y + 6), f.stem.replace("pool-", ""), fill="white")
            sheet_im.paste(Image.open(f).resize((TH, TH)), (x, y + LABEL))
        name = out / f"pick-sheet-{p}.jpg"
        sheet_im.save(name, quality=86)
        print(f"{name} ({len(chunk)} tiles)")
    print(f"{len(pages)} sheet(s). The owner names a pick by the printed id (e.g. \"07\").")


if __name__ == "__main__":
    if len(sys.argv) < 3:
        sys.exit(__doc__)
    cmd = sys.argv[1]
    if cmd == "run":
        run(sys.argv[2], sys.argv[3] if len(sys.argv) > 3 else "openai-blast")
    elif cmd == "sheet":
        sheet(sys.argv[2])
    else:
        sys.exit(__doc__)

# downloads/

The Day 1 one-pagers, the four you need before anything in the Factory can run.

- `genrupt-account-setup.md`, the image machine, click by click
- `openai-key-and-verification-walkthrough.md`, the key, the verification, and the error table
- `product-photo-shot-list.md`, the six shots, on your phone, in twenty minutes
- `front-gate-shopping-list.md`, everything your product needs in hand before Day 2

They ship inside the kit on purpose: setup has to be possible from the folder alone, before you
have opened a single portal room.

Every other one-pager (reading a Tasting Card, edit versus regenerate, the approved-claims
worksheet, and the rest) arrives in its own day's room, on the day it is useful. That is pacing,
not an omission.

# Method Update: July 2026: "Distill, Don't Forward"

If you learned an earlier version of this bootcamp (or built products with an earlier starter
kit), one core technique CHANGED. Read this once; the skills in this kit already follow the new
way.

## What changed

**Old way:** write everything into each image's brief text, the casting ("CASTING IS
MANDATORY: woman in her mid-50s..."), the full avoid-list, the brand colors and fonts, the
legibility rules, all of it, verbatim, in every slot.

**New way:** the brief text stays SHORT (2-5 sentences of pure visual direction), and every
rule is ROUTED to the channel that actually enforces it:

| What | Where it goes now |
|---|---|
| The headline | Its own header-phrase field, as finished on-image copy |
| Casting (who appears) | Custom AVATARS with an explicit age + gender, set at planning (leave ethnicity blank or "varied", that is what turns on per-image variety; a named ethnicity is held identically in every image) |
| Product accuracy (material, shape, size) | Your reference PHOTOS, the fidelity authority |
| Brand look (colors, fonts) | The branding preset. Never text |
| Compliance | 2-3 short sentences, only what the engine doesn't already block |

## Why it changed (the honest story)

We used to write casting into brief text because the avatar age field seemed to get ignored.
The real cause turned out to be different: the default market-analysis avatars often ship with
BLANK age and gender, and blank fields pin nothing. An avatar with EXPLICIT values holds, and
it holds better than brief text ever did, because the avatar's casting guidance is injected
into the final prompt AFTER everything else is compiled, with protection brief text never had.

Meanwhile, long rule-lists inside briefs were actively hurting: your rules compete with your
creative direction for the model's attention. Less text, better images.

## If you built products on the old method

They still work, nothing breaks retroactively. New products simply use the new routing (the
skills in this kit already do it for you). If a gallery keeps repeating the same face, the fix
is now: "check the custom avatars, explicit age and gender on each, add a distinct second
avatar", not a casting paragraph in the brief.

#!/usr/bin/env python3
"""Stitch the A+ modules into the page a shopper actually sees.

Genrupt hands back one file per module, cut to Amazon's upload dimensions.
That is exactly right for uploading and exactly wrong for LOOKING: nobody
reads an A+ page as seven separate crops, and a folder of m1..m7 says nothing
about which module goes first. So this builds two things beside them:

  aplus-page-<mode>.jpg   the modules stacked in page order, no gaps, no
                          labels. This is the page. Open it and you are
                          reading what the shopper reads.
  aplus-order-<mode>.jpg  the same page with a small badge on each module
                          and a rule at every seam, so the upload order is a
                          picture rather than a sentence somebody has to
                          follow correctly.

The badge is an OVERLAY and the seam rule is one pixel row, so the order
sheet is the same height as the page. That matters more than it sounds:
Genrupt cuts one continuous design into modules, so the seams fall mid
sentence and mid image. Inserting a numbered strip between them pushed the
halves apart and made a correct page look broken.

Neither is uploaded to Amazon. The cut module files are what gets uploaded;
these two are how a human checks the work and follows the order.

Usage:
    python3 aplus_page.py <folder> [--out <folder>]

Reads m<N>-desktop.* / m<N>-mobile.* (and plain m<N>.*) from <folder>,
writes the page and the order sheet per mode found. Module number comes from
the filename, so a re-generated module landed as m5-desktop-v2.jpg replaces
m5 in the page: the highest version of each number wins, which matches the
"land the new module beside the old one" rule in the room.
"""
import re
import sys
from pathlib import Path

try:
    from PIL import Image, ImageDraw
except ImportError:
    sys.exit("this needs Pillow: python3 -m pip install pillow")

EXT = (".jpg", ".jpeg", ".png", ".webp")
GAP = 0            # Amazon stacks modules flush; the page must not invent air
BADGE_H = 34       # the order sheet's overlaid badge, in pixels
MAX_PAGE_PX = 24000  # a JPEG taller than this is unopenable in most viewers
# Names that are evidence beside a module, never a module: a rejected render, a
# raw render copy, a fix attempt, the Face Clinic's output tags, its seam crops
# and the drawn-box copies. ONE rule, owned by fix-faces/face_fix.py and
# imported here; kit v35 kept two copies and they disagreed on `-boxes`
# (reproduced 10 September 2026: the Face Clinic adopted a drawn-box copy as a
# module). The regex below is the fallback for a kit with the clinic removed,
# and test_aplus_page.py checks the two agree name for name.
EVIDENCE = re.compile(r"(?:.+[-_](?:rejected(?:-\d+)?|render|boxes|fix\d+|faces-fixed(?:-v\d+)?)|seam-\d+-\d+-\d+x)$", re.I)
try:
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "fix-faces"))
    from face_fix import is_evidence
except Exception:                       # the clinic is not installed: the local copy of the rule
    def is_evidence(name: str) -> bool:
        return bool(EVIDENCE.match(Path(name).stem))


def accepted_names(folder: Path) -> set:
    """The filenames the round's manifest (edits/vN/round.md, written when the
    round opened) lists as adopted, found by walking up from `folder`; empty
    when no manifest is in reach. This is the accepted file list a tie is
    resolved against."""
    folder = Path(folder).resolve()
    for a in [folder] + list(folder.parents)[:3]:
        md = a / "round.md"
        if md.is_file():
            names = set()
            for line in md.read_text(errors="ignore").splitlines():
                m = re.match(r"\|\s*([^|]+?)\s*\|", line)
                if m and m.group(1) not in ("file", "---"):
                    names.add(Path(m.group(1).strip()).name)
            return names
    return set()


def modules(folder: Path, mode: str, accepted=None) -> list:
    """Every module file for one mode, in page order, one file per number.

    A module regenerated after an edit lands as m5-desktop-v2.jpg beside the
    original, so the same number can appear twice. The higher version wins:
    the page must show the module that is going to be uploaded, not the one
    that was sent back. Two files claiming the same number AND version are
    resolved against `accepted` (the round manifest's names; read from
    round.md when None) and otherwise STOP the build: kit v35 warned and kept
    the first, so the page proved assembly from whatever sorted first, never
    that the intended file was chosen."""
    # Two naming worlds land in this folder, and reading only one of them made
    # the stitcher blind to the files /aplus's OWN export produces (measured
    # 27 August 2026): the room lands modules as m01-desktop.jpg at the top
    # level, while Genrupt's export writes export/<mode>/amz-module-NN-slug-
    # <mode>.jpg. Read both, and look one level down for the mode folders.
    candidates = [f for f in sorted(folder.iterdir()) if f.is_file()]
    for sub in ("export/" + mode, mode, "export"):
        d = folder / sub
        if d.is_dir():
            candidates += [f for f in sorted(d.iterdir()) if f.is_file()]
    entries = []
    for f in candidates:
        if f.suffix.lower() not in EXT:
            continue
        # Evidence files are never modules. A rejected render is renamed
        # `<name>-rejected.jpg` beside its parent (the Fixing Room, step 8), and
        # "-desktop-rejected" sorts BEFORE "-desktop." (0x2d < 0x2e), so a page
        # stitched from the folder showed the render the owner had already
        # thrown out (measured 10 September 2026 on the desktop hero: the page's
        # module 1 matched the rejected file, not the adopted one). Same for
        # the clinic's seam crops, the drawn-box copies and a render copy.
        if is_evidence(f.name):
            continue
        # The version comes off FIRST. Matching it inside one pattern looks
        # tidy and is wrong: the optional free-text slug happily swallows
        # "-v2", so m4-desktop-v2 parsed as version 1 and LOST the tie to the
        # m4 it was generated to replace. The page then showed the module the
        # Inspection Room had already sent back.
        stem = f.stem
        ver = 1
        vm = re.search(r"-v(\d+)$", stem, re.I)
        if vm:
            ver, stem = int(vm.group(1)), stem[: vm.start()]
        m = re.match(r"m(\d+)(?:-(.*))?$", stem, re.I)
        if not m:
            # Genrupt's export naming: amz-module-04-hero-image-desktop
            m = re.match(r"(?:amz-)?module-(\d+)(?:-(.*))?$", stem, re.I)
            if not m:
                continue
        num, rest = int(m.group(1)), (m.group(2) or "").lower()
        # The mode may sit ANYWHERE after the number (m1-desktop, m1-hero-mobile,
        # amz-module-01-hero-image-desktop). Reading it only right after the
        # number let m1-hero-mobile.png into the DESKTOP page (reproduced 6
        # September 2026 on a name fixture).
        mm = re.search(r"(?:^|-)(desktop|mobile)(?:-|$)", rest)
        f_mode = mm.group(1) if mm else ""
        if not f_mode:
            parent = f.parent.name.lower()
            f_mode = parent if parent in ("desktop", "mobile") else ""
        entries.append((num, f_mode, ver, f))
    tagged = any(e[1] for e in entries)
    if accepted is None:
        accepted = accepted_names(folder)
    found = {}
    for num, f_mode, ver, f in entries:
        # an unsuffixed m1.jpg belongs to whichever mode is the only one present;
        # in a folder that carries mode tags it belongs to NEITHER page rather
        # than silently to both
        if f_mode != mode and (f_mode or tagged):
            continue
        if num not in found or ver > found[num][0]:
            found[num] = (ver, f)
        elif ver == found[num][0]:
            first = found[num][1]
            a, b = first.name in accepted, f.name in accepted
            if a != b:
                found[num] = (ver, first if a else f)
                print(f"  note: two files claim module {num} version {ver} on {mode} ({first.name}, {f.name}); "
                      f"round.md names {found[num][1].name}, using it")
            else:
                sys.exit(f"AMBIGUOUS: two files claim module {num} version {ver} on {mode} ({first.name}, {f.name}) "
                         f"and no manifest names the one that ships. Nothing built. Point the builder at the "
                         f"chosen version's folder (aplus/export/{mode} or edits/vN/aplus), or list the file "
                         f"that ships in that round's round.md.")
    return [found[n][1] for n in sorted(found)]


def stack(files: list, numbered: bool) -> "Image.Image":
    ims = []
    for f in files:
        im = Image.open(f)
        ims.append(im.convert("RGB") if im.mode != "RGB" else im)
    width = max(i.width for i in ims)
    scaled = [i if i.width == width
              else i.resize((width, max(1, round(i.height * width / i.width))), Image.LANCZOS)
              for i in ims]
    total = sum(i.height for i in scaled) + GAP * (len(scaled) - 1)
    if total > MAX_PAGE_PX:
        s = MAX_PAGE_PX / total
        width = max(1, round(width * s))
        scaled = [i.resize((width, max(1, round(i.height * s))), Image.LANCZOS) for i in scaled]
        total = sum(i.height for i in scaled) + GAP * (len(scaled) - 1)
    page = Image.new("RGB", (width, total), "white")
    y = 0
    seams = []
    for im in scaled:
        page.paste(im, (0, y))
        y += im.height + GAP
        seams.append(y)
    if numbered:
        d = ImageDraw.Draw(page, "RGBA")
        y = 0
        for n, im in enumerate(scaled, 1):
            label = f" {n}  upload position {n} of {len(scaled)}  .  {files[n - 1].name} "
            # A badge is a label, never a lid. On a narrow module an unclamped
            # one covered the whole frame, which turns the order sheet into a
            # sheet of black bars.
            w = min(9 + int(d.textlength(label)), max(24, int(width * 0.55)))
            d.rectangle([0, y, w, y + BADGE_H], fill=(24, 20, 28, 232))
            d.text((10, y + BADGE_H // 2 - 6), label, fill=(240, 226, 200, 255))
            y += im.height + GAP
            if n < len(scaled):      # a seam, drawn ON the page rather than between
                d.rectangle([0, y - 2, width, y], fill=(216, 122, 46, 235))
    return page


def build(folder, out=None) -> list:
    folder = Path(folder)
    out = Path(out) if out else folder
    out.mkdir(parents=True, exist_ok=True)
    written = []
    # Resolve BOTH modes before writing anything: a tie on the mobile set stops
    # the build, and its "Nothing built" is only true when the desktop page was
    # not already on disk (reproduced 10 September 2026).
    sets = [(mode, modules(folder, mode)) for mode in ("desktop", "mobile")]
    for mode, files in sets:
        if not files:
            continue
        for numbered, name in ((False, f"aplus-page-{mode}.jpg"), (True, f"aplus-order-{mode}.jpg")):
            img = stack(files, numbered)
            p = out / name
            img.save(p, "JPEG", quality=88)
            written.append((p, len(files), img.size))
        # The manifest: which file each strip came from, said out loud, so a
        # page is never trusted by eye. Then the read-back: every strip of the
        # saved page against its source file, mean absolute difference per
        # module; JPEG re-encoding sits around 1 level, a wrong file sits far
        # above it.
        print(f"  {mode}: " + ", ".join(f"{n + 1}={f.name}" for n, f in enumerate(files)))
        for n, diff in enumerate(verify(out / f"aplus-page-{mode}.jpg", files), 1):
            if diff > VERIFY_MAX:
                print(f"  WARNING: {mode} strip {n} differs from {files[n - 1].name} by {diff:.1f} levels; the page is not built from that file")
    return written


VERIFY_MAX = 6.0   # mean absolute difference, 0-255; re-encode noise is about 1


def verify(page_path, files) -> list:
    """Per-module mean absolute difference between the saved page's strips and
    the module files they were built from. The check /fix's round log asks for
    (Jay, 10 September 2026): a rebuilt page is compared to its adopted modules
    by pixel diff, never by eye."""
    try:
        import numpy as np
    except ImportError:
        return []
    page = np.asarray(Image.open(page_path).convert("RGB"), dtype=int)
    width = page.shape[1]
    diffs, y = [], 0
    for f in files:
        im = Image.open(f).convert("RGB")
        if im.width != width:
            im = im.resize((width, max(1, round(im.height * width / im.width))), Image.LANCZOS)
        a = np.asarray(im, dtype=int)
        h = min(a.shape[0], page.shape[0] - y)
        diffs.append(float(np.abs(page[y:y + h] - a[:h]).mean()) if h > 0 else 255.0)
        y += a.shape[0]
    return diffs


def main():
    args = [a for a in sys.argv[1:]]
    if not args:
        sys.exit(__doc__)
    folder = args[0]
    out = None
    if "--out" in args:
        out = args[args.index("--out") + 1]
    written = build(folder, out)
    if not written:
        sys.exit(f"no module files (m1..mN) found in {folder}. Nothing to stitch.")
    for p, n, size in written:
        print(f"wrote {p}  ({n} modules, {size[0]}x{size[1]})")


if __name__ == "__main__":
    main()

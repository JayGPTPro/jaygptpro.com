#!/usr/bin/env python3
"""The Tasting Room engine: a synthetic consumer panel for listing images.

Implements the semantic-similarity-rating (SSR) approach from arXiv:2510.08338:
demographic-conditioned LLM "tasters" react to each candidate image in FREE
TEXT; each reaction is mapped to a 1-5 purchase-intent score by embedding
similarity against Likert anchor statements (never by asking the model for a
number directly; direct rating elicitation collapses to "3" and loses signal).
Adds a forced-choice pass (all candidates side by side, pick one) for
head-to-head discrimination, and a within-set vote for per-image ranking.

Tasters MUST be built from the real buyer demographics (the persona from the
Research Room). The paper shows correlation attainment drops from ~90% to ~50%
without demographic conditioning. Use the buyer's REAL age, never the
aspirational display age used for casting models in images.

Usage: python3 panel.py config.json [lite]
Better: use run.py (cross-platform wrapper, keeps the machine awake on macOS
and renders the Tasting Card at the end).

Keys: OPENAI_API_KEY, loaded from the nearest .env (this folder upward to the
Factory root). Optional: GEMINI_API_KEY / ANTHROPIC_API_KEY for model mixing.
Outputs in config.out_dir: results.json, tasting-card.md (English).
"""

import base64
import io
import json
import mimetypes
import os
import random
import re
import sys
import time
from collections import Counter, defaultdict
from concurrent.futures import ThreadPoolExecutor, as_completed
from functools import lru_cache
from pathlib import Path

import numpy as np
from dotenv import load_dotenv
from openai import OpenAI


def _load_env():
    """Load .env from the current folder upward (so the Factory root .env is
    found no matter which subfolder the run starts in), and then from this
    file's own tree (so a run launched from OUTSIDE the Factory still finds the
    key sitting at the Factory root). Exported environment variables always
    win, and the first file found wins over the second."""
    home = Path.home()
    for start in (Path.cwd(), Path(__file__).resolve().parent):
        for d in [start, *start.parents]:
            if d == home.parent:
                # past the home folder the nearest .env belongs to another
                # project or to the system; borrowing a key from there bills
                # the wrong account silently
                break
            f = d / ".env"
            if f.exists():
                load_dotenv(dotenv_path=f, override=False)
                break


_load_env()

# ---------------------------------------------------------------------------
# Clients. Built lazily so a missing optional key only fails if actually used.
# The per-request timeout is LOAD-BEARING: without it one hung connection
# blocks a worker thread forever, and once all workers hang the whole run
# stalls silently. 90s timeout + our own retries.
_clients = {}


def _openai_client():
    if "openai" not in _clients:
        key = os.environ.get("OPENAI_API_KEY")
        if not key:
            raise RuntimeError(
                "OPENAI_API_KEY is missing. Put it in the .env file at your Factory root "
                "(the same key you set up on Day 1). The Tasting Room cannot open without it."
            )
        _clients["openai"] = OpenAI(api_key=key, timeout=90.0, max_retries=0)
    return _clients["openai"]


def client_for(model: str):
    """MODEL MIXING: tasters can be split across different base models (and
    even different PROVIDERS) to soften the shared-base-model taste. All
    tasters on ONE model share one latent aesthetic preference that persona
    profiles alone cannot remove. Gemini rides the same OpenAI SDK via
    Google's OpenAI-compatible endpoint; Claude needs ANTHROPIC_API_KEY.
    Embeddings (the SSR scoring) always stay OpenAI, because changing the
    embedder changes the anchor geometry."""
    if model.startswith("gemini"):
        if "gemini" not in _clients:
            key = os.environ.get("GEMINI_API_KEY")
            if not key:
                raise RuntimeError(
                    "gemini-* taster models need GEMINI_API_KEY in your Factory root .env. "
                    "Either add the key or remove the gemini entry from \"models\" in the config."
                )
            _clients["gemini"] = OpenAI(
                api_key=key,
                base_url="https://generativelanguage.googleapis.com/v1beta/openai/",
                timeout=90.0,
                max_retries=0,
            )
        return _clients["gemini"]
    if model.startswith("claude"):
        if "anthropic" not in _clients:
            key = os.environ.get("ANTHROPIC_API_KEY")
            if not key:
                raise RuntimeError(
                    "claude-* taster models need ANTHROPIC_API_KEY in your Factory root .env "
                    "(from console.anthropic.com). Either add the key or remove the claude "
                    "entry from \"models\" in the config."
                )
            _clients["anthropic"] = OpenAI(
                api_key=key, base_url="https://api.anthropic.com/v1/", timeout=90.0, max_retries=0
            )
        return _clients["anthropic"]
    return _openai_client()


# ---------------------------------------------------------------------------
# Fallback demographics: a general US Amazon shopper. Used ONLY when the
# config carries no demographics (e.g. no persona.md yet). A real persona from
# the Research Room always beats this default.
DEFAULT_DEMOGRAPHICS = {
    "age_dist": {"18-24": 0.10, "25-34": 0.25, "35-44": 0.25, "45-54": 0.20, "55-64": 0.12, "65+": 0.08},
    "gender": {"female": 0.5, "male": 0.5},
    "income": {"lower-middle income": 0.3, "middle income": 0.5, "upper-middle income": 0.2},
    "notes": "DEFAULT general US Amazon shopper (no buyer persona supplied)",
}

# SSR anchors: 5 Likert points x 3 paraphrases (averaged per point, as in the
# paper's multi-set design, to stabilize the mapping).
ANCHORS = {
    1: [
        "I would definitely not buy this product.",
        "There is no way I would purchase this.",
        "I'm not interested in buying this at all.",
    ],
    2: [
        "I probably wouldn't buy this.",
        "It's rather unlikely that I'd purchase this.",
        "I don't think this product is for me.",
    ],
    3: [
        "I might or might not buy this.",
        "I'm on the fence about buying it.",
        "Not sure - I could go either way on this.",
    ],
    4: [
        "I would probably buy this.",
        "I'm fairly likely to purchase this.",
        "This looks good - I'd likely give it a try.",
    ],
    5: [
        "I would definitely buy this product.",
        "I'm certain I would purchase this.",
        "I'd buy this right away.",
    ],
}

TRAITS = {
    "shopping_style": [("bargain hunter", 0.3), ("value-for-money shopper", 0.45), ("premium buyer", 0.25)],
    "skepticism": [("takes claims at face value", 0.3), ("moderately skeptical of marketing", 0.5), ("highly skeptical of marketing claims", 0.2)],
    "attention": [("skims images quickly on a phone", 0.55), ("reads product images carefully", 0.45)],
    "familiarity": [("uses this kind of product regularly", 0.35), ("tried it before but lapsed", 0.25), ("curious first-time buyer", 0.4)],
}


def wpick(rng: random.Random, dist):
    """Weighted pick from [(value, weight)] or {value: weight}."""
    items = list(dist.items()) if isinstance(dist, dict) else dist
    total = sum(w for _, w in items)
    r = rng.random() * total
    for v, w in items:
        r -= w
        if r <= 0:
            return v
    return items[-1][0]


def age_from_band(rng: random.Random, band: str) -> int:
    band = band.strip().replace(" ", "")
    if band.endswith("+"):
        lo = int(band[:-1])
        return rng.randint(lo, lo + 12)
    lo, hi = (int(x) for x in band.split("-"))
    return rng.randint(lo, hi)


DEFAULT_MODEL_MIX = {"gpt-5.4-mini": 0.6, "gpt-5.4": 0.4}


def model_mix(cfg: dict) -> dict:
    """The taster model mix, {"model-name": weight}.
    An explicit "models" block wins; a single "model" runs deliberately
    single-model. The DEFAULT is a mix of two OpenAI models on the one key
    every Factory already has: one model = one shared taste, and a
    single-model panel has called a 75/25 that a mixed panel read as 45/55."""
    if cfg.get("models"):
        return cfg["models"]
    if cfg.get("model"):
        return {cfg["model"]: 1.0}
    return dict(DEFAULT_MODEL_MIX)


# ---------------------------------------------------------------------------
# The spend cap (kit v38, 12 September 2026). Invoking the room authorises the
# standard sitting, so the cost line is no longer a question. It is a GATE on
# an estimate made before the first request: above the cap the engine stops
# and the owner is asked once; below it the line is printed and the race runs.
# The cap is per SITTING (both races together) and is never enforced on a
# running total, because a half race is worthless.
SPEND_CAP_DEFAULT_USD = 10.0

# List prices per 1K tokens, prices as of September 2026. Deliberately the
# published rate with no discount, so the estimate errs high. An unknown model
# is priced at the dearest row rather than guessed low.
PRICES_PER_1K_USD = {
    "_as_of": "prices as of September 2026",
    "gpt-5.4-mini": {"in": 0.00075, "out": 0.0045},
    "gpt-5.4": {"in": 0.0025, "out": 0.015},
    "text-embedding-3-small": {"in": 0.00002, "out": 0.0},
}
_DEAREST = "gpt-5.4"
EMBED_MODEL = "text-embedding-3-small"

# Token assumptions per call, rounded UP from what the phases send. An image
# at `auto` detail on a 1024 edge is about 765 tokens; at `low` about 85.
TOK_IMG_AUTO = 1100
TOK_IMG_LOW = 100
TOK_TEXT_IN = 250          # system persona + the ask
TOK_REACTION_OUT = 220     # react(): max_tokens
TOK_CHOICE_OUT = 120       # choose(): max_tokens
TOK_PER_IMAGE_OUT = 260    # react_image(): max_tokens
TOK_WITHIN_OUT = 60        # rank_within_set(): max_tokens
TOK_REACTION_TEXT = 80     # one reaction, when it is fed back into a synthesis
TOK_SYNTH_OUT = 3000       # synthesize_themes(): max_tokens, two calls
TOK_TAKEAWAY_OUT = 2400    # synthesize_image_takeaways(): max_tokens, one per stack
ESTIMATE_MARGIN = 1.25     # keep the estimate conservative


def _price(model: str) -> dict:
    return PRICES_PER_1K_USD.get(model) or PRICES_PER_1K_USD[_DEAREST]


def _mix_price(mix: dict) -> dict:
    """The weighted per-1K price of the taster calls across the model mix."""
    total = sum(mix.values()) or 1.0
    return {
        "in": sum(w / total * _price(m)["in"] for m, w in mix.items()),
        "out": sum(w / total * _price(m)["out"] for m, w in mix.items()),
    }


def estimate_cost(cfg: dict) -> dict:
    """Price ONE race before it runs, from what the engine already knows: the
    tasters, the candidates and their frames, the per-image sample, the model
    mix, and the price table above. Deterministic for a given config; the same
    config always prints the same number. Returns {"usd", "calls", "models"}."""
    n = int(cfg.get("n_personas", 100))
    sample_n = int(cfg.get("per_image_sample", 40))
    images = cfg.get("images") or []
    frames = [len(paths_of(i)) for i in images if isinstance(i, dict) and (i.get("paths") or i.get("path"))]
    stacks = [f for f in frames if f > 1]
    stacks_mode = bool(stacks)
    total_frames = sum(frames)
    mix = model_mix(cfg)
    tp = _mix_price(mix)
    synth_model = cfg.get("model", "gpt-5.4-mini")
    sp = _price(synth_model)
    usd = 0.0
    calls = {"reactions": 0, "forced_choice": 0, "per_image": 0, "within_set": 0, "synthesis": 0}

    # 1) reactions: every taster x every candidate; a stack is sent at low detail
    calls["reactions"] = n * len(frames)
    for f in frames:
        tok_in = f * (TOK_IMG_LOW if f > 1 else TOK_IMG_AUTO) + TOK_TEXT_IN
        usd += n * (tok_in * tp["in"] + TOK_REACTION_OUT * tp["out"]) / 1000
    # 2) forced choice: every taster sees every candidate side by side
    calls["forced_choice"] = n
    tok_in = total_frames * (TOK_IMG_LOW if stacks_mode else TOK_IMG_AUTO) + TOK_TEXT_IN
    usd += n * (tok_in * tp["in"] + TOK_CHOICE_OUT * tp["out"]) / 1000
    if stacks_mode and cfg.get("per_image", True):
        # 2b) per-image notes: a sample of tasters x every frame of every stack
        sample = min(n, sample_n)
        calls["per_image"] = sample * total_frames
        usd += calls["per_image"] * ((TOK_IMG_AUTO + TOK_TEXT_IN) * tp["in"] + TOK_PER_IMAGE_OUT * tp["out"]) / 1000
        # 2c) within-set votes: every taster x every stack
        calls["within_set"] = n * len(stacks)
        for f in stacks:
            usd += n * ((f * TOK_IMG_LOW + TOK_TEXT_IN) * tp["in"] + TOK_WITHIN_OUT * tp["out"]) / 1000
        # takeaways: one synthesis per stack over the sampled notes
        calls["synthesis"] += len(stacks)
        for f in stacks:
            usd += ((sample * f * TOK_REACTION_TEXT) * sp["in"] + TOK_TAKEAWAY_OUT * sp["out"]) / 1000
    # 3) theme synthesis: two calls over up to 40 reactions per candidate
    calls["synthesis"] += 2
    synth_in = min(n, 40) * len(frames) * TOK_REACTION_TEXT
    usd += 2 * (synth_in * sp["in"] + TOK_SYNTH_OUT * sp["out"]) / 1000
    # 4) embeddings: every reaction and every per-image note, plus the anchors
    embed_texts = calls["reactions"] + calls["per_image"] + 15
    usd += embed_texts * TOK_REACTION_TEXT * _price(EMBED_MODEL)["in"] / 1000

    usd = round(usd * ESTIMATE_MARGIN, 2)
    return {"usd": usd, "calls": calls, "models": sorted(set(mix) | {synth_model, EMBED_MODEL})}


def format_estimate(usd: float, cap: float) -> str:
    return f"Estimated: about ${usd:.2f} for this race (cap ${cap:g} per sitting)"


def cap_check(usd: float, cap: float):
    """(ok, line). The cap is a ceiling: at or under it runs. Over it, the line
    is the ONE question the skill puts to the owner."""
    if usd <= cap:
        return True, format_estimate(usd, cap)
    return False, (f"This sitting estimates about ${usd:.2f}, above the ${cap:g} cap. Run it anyway? "
                   f"(a yes runs it with spend_cap_usd raised for this sitting only)")


# Running total of what the API REPORTED spending, when responses carry usage.
# Informational only: printed into results.json as spend_usd_estimated. Never a
# stop condition.
import threading as _threading  # noqa: E402

_SPEND = {"usd": 0.0, "calls_with_usage": 0, "calls": 0}
_SPEND_LOCK = _threading.Lock()


def _record_usage(model: str, usage) -> None:
    with _SPEND_LOCK:
        _SPEND["calls"] += 1
        if not usage:
            return
        pin = getattr(usage, "prompt_tokens", None) or 0
        pout = getattr(usage, "completion_tokens", None) or 0
        if not pin and not pout:
            return
        pr = _price(model)
        _SPEND["usd"] += (pin * pr["in"] + pout * pr["out"]) / 1000
        _SPEND["calls_with_usage"] += 1


def spend_report() -> dict:
    """What lands in results.json's quality block."""
    with _SPEND_LOCK:
        if _SPEND["calls_with_usage"] == 0:
            return {"spend_usd_estimated": None,
                    "spend_note": "the API returned no usage in its responses, so no running total is available"}
        return {"spend_usd_estimated": round(_SPEND["usd"], 2),
                "spend_note": (f"from usage reported on {_SPEND['calls_with_usage']} of {_SPEND['calls']} calls, "
                               f"at {PRICES_PER_1K_USD['_as_of']}")}


def build_tasters(cfg: dict, rng: random.Random):
    demo = cfg.get("demographics") or DEFAULT_DEMOGRAPHICS
    # A partial persona block is a normal authoring outcome, so every key falls
    # back on its own. age_dist used to be the one required key, and a persona
    # written without it crashed the run with a bare KeyError.
    age_dist = demo.get("age_dist") or DEFAULT_DEMOGRAPHICS["age_dist"]
    mix = model_mix(cfg)
    tasters = []
    for i in range(cfg.get("n_personas", 100)):
        band = wpick(rng, age_dist)
        p = {
            "id": i + 1,
            "age": age_from_band(rng, band),
            "age_band": band,
            "gender": wpick(rng, demo.get("gender", {"female": 0.5, "male": 0.5})),
            "income": wpick(rng, demo.get("income", {"middle income": 1.0})),
            "model": wpick(rng, mix),
            **{k: wpick(rng, v) for k, v in TRAITS.items()},
        }
        tasters.append(p)
    return tasters


def taster_model(p: dict, cfg: dict) -> str:
    return p.get("model") or cfg.get("model", "gpt-5.4-mini")


def taster_system(p: dict, cfg: dict) -> str:
    # "niche" is optional in the config; fall back to the product context so a
    # minimal config still produces grounded tasters.
    niche = cfg.get("niche") or cfg.get("product_context") or "this kind of"
    return (
        f"You are a {p['age']}-year-old {p['gender']} shopper in the US, {p['income']}. "
        f"You are a {p['shopping_style']}, you {p['skepticism']}, and you {p['attention']}. "
        f"You are a {p['familiarity']} of {niche} products. "
        "You are browsing Amazon. Speak in first person, plainly, like a real shopper - "
        "not a marketer, not an assistant. Be honest, including negative reactions."
    )


@lru_cache(maxsize=512)
def _encode_image(path: str, max_edge: int) -> tuple:
    """Downscale + JPEG-encode ONCE per (path, size), cached.

    LOAD-BEARING for reliability, not just cost: the NETWORK payload (not only
    the token `detail`) must be small. A full-res 2000px PNG is ~1.5MB; a
    7-image gallery sent per taster is then a ~13MB request, and on a home
    uplink with many concurrent workers every call blows past the 90s timeout,
    retries, and the run grinds for an hour producing __ERROR__ reactions.
    At `detail:"low"` the model only ever sees a ~512px thumbnail, so shipping
    the original is pure waste. Caching also collapses 100-tasters x N-images
    re-encodes of the SAME file down to one."""
    try:
        from PIL import Image
        im = Image.open(path)
        if im.mode not in ("RGB", "L"):
            im = im.convert("RGB")
        w, h = im.size
        if max(w, h) > max_edge:
            s = max_edge / max(w, h)
            im = im.resize((max(1, round(w * s)), max(1, round(h * s))), Image.LANCZOS)
        buf = io.BytesIO()
        im.save(buf, format="JPEG", quality=82)
        return "image/jpeg", base64.b64encode(buf.getvalue()).decode()
    except Exception:
        # Pillow missing or a decode failure: fall back to the raw bytes so a
        # run still works (just heavier) rather than crashing.
        mime = mimetypes.guess_type(path)[0] or "image/png"
        return mime, base64.b64encode(Path(path).read_bytes()).decode()


def img_part(path: str, detail: str = "auto") -> dict:
    # detail "low" -> the model downsamples to ~512px, so 768 longest-edge is
    # ample; give full-detail single images a bigger cap.
    max_edge = 768 if detail == "low" else 1024
    mime, b64 = _encode_image(path, max_edge)
    return {"type": "image_url", "image_url": {"url": f"data:{mime};base64,{b64}", "detail": detail}}


def paths_of(image: dict) -> list:
    """A candidate is a single image ({path}) or a STACK ({paths: [...]}),
    e.g. a whole secondary gallery tested against the live Amazon gallery."""
    return image.get("paths") or [image["path"]]


def _clean(text: str) -> str:
    """House style: no em or en dashes in any output, ever."""
    return text.replace(" \u2014 ", ", ").replace("\u2014", ", ").replace("\u2013", "-")


class OutOfCredit(RuntimeError):
    """The provider's balance is empty. NOT a rate limit, so retrying cannot
    help and every further call is a wasted second.

    This is its own exception rather than an `__ERROR__` string because of what
    the string did on 26 August 2026: `chat()` returned it, the reactions loop
    recorded it as a FINISHED reaction, the checkpoint saved it as done, and the
    resume after the top-up never retried those tasters. The panel came back at
    19 and 23 instead of ~100 and the card printed a verdict on the rubble. An
    exception cannot be mistaken for an opinion."""


_DEAD_BALANCE = ("insufficient_quota", "credit_balance_exhausted",
                 "no credits remaining", "billing_hard_limit_reached")


def is_dead_balance(msg: str) -> bool:
    m = str(msg).lower()
    return any(k in m for k in _DEAD_BALANCE)


def usable(text) -> bool:
    """Is this a real answer from the provider, or a failure wearing an answer's
    clothes? Only real answers are allowed into a checkpoint. A blank string
    counts as real: the call was made and paid for, the model simply said
    nothing, and re-asking would spend again for the same silence."""
    return isinstance(text, str) and not text.startswith("__ERROR__")


def out_of_credit(err, saved: str):
    """Stop the run the way an empty balance deserves: loudly, with the work so
    far banked, and with the one instruction that actually helps."""
    sys.exit(
        f"OUT OF CREDIT on the tasting key. {saved}, and the checkpoint keeps them.\n"
        "This is an empty balance, not a rate limit, so waiting and retrying cannot help. "
        "Top up at https://platform.openai.com/settings/organization/billing/ and run the "
        "SAME command again: it picks up exactly where it stopped and re-asks only the "
        "tasters who never answered.\n"
        f"provider said: {str(err)[:200]}"
    )


def chat(messages, model, max_tokens=220, retries=3, json_mode=False):
    c = client_for(model)
    # OpenAI's newer models want max_completion_tokens; the compat endpoints
    # (Gemini/Anthropic) speak classic max_tokens.
    is_compat = model.startswith(("gemini", "claude"))
    tok_key = "max_tokens" if is_compat else "max_completion_tokens"
    use_rf = json_mode
    use_re = model.startswith("gemini")  # disable Gemini "thinking"
    if model.startswith("gemini"):
        # Gemini spends "thinking" tokens INSIDE the budget; a small budget
        # gets eaten before the answer arrives, so raise the floor.
        max_tokens = max(max_tokens, 512)
    for attempt in range(retries):
        try:
            kwargs = {"model": model, "messages": messages, tok_key: max_tokens}
            if use_rf:
                kwargs["response_format"] = {"type": "json_object"}
            if use_re:
                kwargs["reasoning_effort"] = "none"
            r = c.chat.completions.create(**kwargs)
            _record_usage(model, getattr(r, "usage", None))
            return _clean((r.choices[0].message.content or "").strip())
        except Exception as e:  # noqa: BLE001 - retry then surface
            # a provider that rejects an optional param gets a retry without it
            # (callers all have lenient parsers)
            msg = str(e)
            # An empty balance is not traffic control. Retrying it burns the
            # sleep budget on every remaining job and, worse, ends with an
            # __ERROR__ string that the checkpoint will store as finished work.
            if is_dead_balance(msg):
                raise OutOfCredit(msg) from e
            if use_rf and "response_format" in msg:
                use_rf = False
                continue
            if use_re and "reasoning" in msg:
                use_re = False
                continue
            if attempt == retries - 1:
                return f"__ERROR__ {e}"
            time.sleep(2 * (attempt + 1))
    return "__ERROR__"


def react(p, image, cfg):
    """One taster reacts to one candidate (single image OR a whole stack)."""
    ps = paths_of(image)
    stack = len(ps) > 1
    ask = (
        f"These are the product photos on an Amazon listing for: {cfg['product_context']}. "
        "React honestly in 2-4 sentences: after flipping through them, what do you think and feel about the "
        "product? What works for you, what puts you off? Finish with how likely you'd be to buy."
        if stack
        else f"This is one of the photos on an Amazon listing for: {cfg['product_context']}. "
        "React honestly in 2-4 sentences: what does this photo make you think or feel about the "
        "product? What works for you, what puts you off? Finish with how likely you'd be to buy "
        "after seeing it."
    )
    content = [img_part(pp, "low" if stack else "auto") for pp in ps]
    content.append({"type": "text", "text": ask})
    msg = [{"role": "system", "content": taster_system(p, cfg)}, {"role": "user", "content": content}]
    return chat(msg, taster_model(p, cfg))


def react_image(p, set_img, cfg):
    """Per-image structured tasting note: one taster, ONE image out of a set,
    strict-JSON verdict. Powers the per-image cards on the Tasting Card."""
    msg = [
        {"role": "system", "content": taster_system(p, cfg)},
        {
            "role": "user",
            "content": [
                img_part(set_img["path"]),
                {
                    "type": "text",
                    "text": (
                        f"This is ONE image from an Amazon listing for: {cfg['product_context']}. "
                        "Judge THIS image's effect on whether YOU would buy - be decisive, most images are not neutral. "
                        "Respond in strict JSON only: "
                        '{"reaction": "2-3 honest first-person sentences about what this image makes you think/feel", '
                        '"works": "the single strongest thing this image does for you (empty string if nothing)", '
                        '"doesnt": "the single biggest problem with this image for you (empty string if nothing)", '
                        '"impact": "boosts" (this image makes me MORE likely to buy) | "neutral" (no real effect) '
                        '| "hurts" (this image makes me LESS likely to buy / I would distrust or skip it)}'
                    ),
                },
            ],
        },
    ]
    out = chat(msg, taster_model(p, cfg), max_tokens=260, json_mode=True)
    try:
        d = json.loads(out)
        v = str(d.get("impact", d.get("verdict", ""))).lower()
        return {
            "reaction": str(d.get("reaction", ""))[:600],
            "works": str(d.get("works", ""))[:300],
            "doesnt": str(d.get("doesnt", ""))[:300],
            "impact": v if v in ("boosts", "neutral", "hurts") else "neutral",
        }
    except Exception:  # noqa: BLE001
        return {"reaction": out[:600], "works": "", "doesnt": "", "impact": "neutral", "_raw": True}


def synthesize_image_takeaways(cfg, set_id, per_image_rows, model):
    """One call per SET: per-image top works/doesn't + a one-line takeaway."""
    blocks = []
    for row in per_image_rows:
        works = [f["works"] for f in row["feedback"] if f.get("works")][:15]
        doesnt = [f["doesnt"] for f in row["feedback"] if f.get("doesnt")][:15]
        blocks.append(
            f"### image_{row['idx']}\nWORKS:\n" + "\n".join(f"- {w}" for w in works)
            + "\nDOESN'T:\n" + "\n".join(f"- {x}" for x in doesnt)
        )
    prompt = (
        f"Synthetic shoppers reviewed each image of an Amazon listing set for: {cfg['product_context']}.\n\n"
        + "\n\n".join(blocks)
        + '\n\nReturn STRICT JSON: {"images": {"image_<idx>": {"top_works": [{"text": "short theme", "count": <int>}] (max 3), '
        '"top_doesnt": [{"text": "short theme", "count": <int>}] (max 3), '
        '"takeaway": "one imperative sentence: keep as-is / fix X / drop because Y"}}}. '
        "COUNT RULE: count = how many DISTINCT lines above raise that theme (honest tally, never a guess). "
        "Only recurring themes. JSON only."
    )
    out = chat([{"role": "user", "content": prompt}], model, max_tokens=2400, json_mode=True)
    try:
        return json.loads(out).get("images", {})
    except Exception:  # noqa: BLE001
        return {}


LETTERS = "ABCDEFGHIJKL"  # supports up to 12 candidates / images per set


def choose(p, images, cfg, rng: random.Random):
    """Forced choice: all candidates side by side (shuffled per taster).
    THE decision metric. Parsed via strict JSON (a free-text reply like
    "Sure, B..." used to risk grabbing a wrong letter from an unrelated word)."""
    order = list(range(len(images)))
    rng.shuffle(order)
    stacks = any(len(paths_of(i)) > 1 for i in images)
    unit = "Set" if stacks else "Photo"
    content = []
    for pos, idx in enumerate(order):
        content.append({"type": "text", "text": f"{unit} {LETTERS[pos]}:"})
        for pp in paths_of(images[idx]):
            content.append(img_part(pp, "low" if stacks else "auto"))
    content.append(
        {
            "type": "text",
            "text": (
                f"These are alternative image {unit.lower()}s for the SAME Amazon listing: {cfg['product_context']}. "
                f"Which ONE {unit.lower()} makes you most likely to buy? "
                'Reply as strict JSON only: {"choice":"<letter>","why":"one short sentence"}.'
            ),
        }
    )
    msg = [{"role": "system", "content": taster_system(p, cfg)}, {"role": "user", "content": content}]
    out = chat(msg, taster_model(p, cfg), max_tokens=120, json_mode=True)
    valid = LETTERS[: len(images)]
    if out.startswith("__ERROR__"):  # an API failure is NOT a vote. The lenient
        return None, out             # letter-scan would find one in "ERROR"/"RATE"
    letter = None
    try:
        letter = str(json.loads(out).get("choice", "")).strip().upper()[:1]
    except Exception:  # noqa: BLE001
        pass
    if not letter or letter not in valid:
        # Salvage from the VALUE side only, never by scanning the whole reply.
        # The reply is JSON, so the raw text starts {"choice": ... and the word
        # CHOICE contains a C. A blanket scan therefore returned "C" for any
        # race with three or more candidates, mined straight out of the key
        # name: a truncated reply that plainly said B was recorded as a vote
        # for whatever sat at shuffled position C. And because `chosen` came
        # back non-empty, choice_parse_rate counted it as PARSED, so the rate
        # read 1.0, the sub-90% warning never printed and the card's red
        # banner never rendered. Silently wrong votes on the one metric this
        # room calls the decision, under a gate reporting perfect health.
        m = re.search(r'"choice"\s*:\s*"?\s*([A-Za-z])', out)
        letter = m.group(1).upper() if m else None
        if letter is None or letter not in valid:
            letter = None
    # A dropped vote is the correct outcome, exactly as it is for __ERROR__
    # above: it lowers choice_parse_rate, which is what the gate exists to see.
    chosen = images[order[LETTERS.index(letter)]]["id"] if letter else None
    return chosen, out


def rank_within_set(p, set_img, cfg, rng: random.Random):
    """WITHIN-SET vote (the "strongest image" metric): one taster sees ALL
    images of ONE set (shuffled) and picks the MOST convincing and the
    WEAKEST. Comparative judgment discriminates far better than absolute 1-5
    scoring. Returns (best_idx, worst_idx) as 1-based image numbers in the
    set, or (None, None)."""
    ps = paths_of(set_img)
    if len(ps) < 2:
        return (1, None)
    if len(ps) > len(LETTERS):
        raise ValueError(f"set {set_img.get('id')} has {len(ps)} images; max {len(LETTERS)} supported")
    order = list(range(len(ps)))
    rng.shuffle(order)
    letters = LETTERS
    content = []
    for pos, idx in enumerate(order):
        content.append({"type": "text", "text": f"Image {letters[pos]}:"})
        content.append(img_part(ps[idx], "low"))
    content.append(
        {
            "type": "text",
            "text": (
                f"These are the images on ONE Amazon listing for: {cfg['product_context']}. "
                "As a shopper flipping through them, which ONE image is the MOST convincing "
                "(makes you most likely to buy) and which ONE is the WEAKEST? "
                'Reply as strict JSON only: {"best":"<letter>","worst":"<letter>"}.'
            ),
        }
    )
    msg = [{"role": "system", "content": taster_system(p, cfg)}, {"role": "user", "content": content}]
    out = chat(msg, taster_model(p, cfg), max_tokens=60, json_mode=True)
    valid = letters[: len(ps)]
    if out.startswith("__ERROR__"):  # an API failure must not become a phantom vote
        return (None, None)

    def to_idx(letter):
        return order[letters.index(letter)] + 1 if letter and letter in valid else None

    # primary: strict JSON
    try:
        d = json.loads(out)
        bl = str(d.get("best", "")).strip().upper()[:1]
        wl = str(d.get("worst", "")).strip().upper()[:1]
        if bl in valid:
            return (to_idx(bl), to_idx(wl))
    except Exception:  # noqa: BLE001
        pass
    # Salvage from the VALUE side only. Scanning from `up.find("BEST")` starts
    # ON the B of the key name, so the first valid letter was ALWAYS B and
    # every unparsed reply became a phantom "strongest frame" vote for
    # whatever sat at shuffled position B. Even honest free text saying "the
    # best is C" resolved to B. This one was fully deterministic, and it
    # inflated within_vote_parse_rate the same way the forced choice did.
    def _val(key):
        m = re.search(r'"%s"\s*:\s*"?\s*([A-Za-z])' % key, out, re.I)
        c = m.group(1).upper() if m else None
        return c if (c is not None and c in valid) else None
    bl, wl = _val("best"), _val("worst")
    return (to_idx(bl), to_idx(wl))


def embed_all(texts, batch=256):
    vecs = []
    for i in range(0, len(texts), batch):
        try:
            r = _openai_client().embeddings.create(model=EMBED_MODEL, input=texts[i : i + batch])
            _record_usage(EMBED_MODEL, getattr(r, "usage", None))
        except Exception as e:  # noqa: BLE001
            # The embeddings call is the one the 26.8 crash actually died on:
            # it sits after every paid taster call, it is not wrapped in the
            # retry helper, and a dead balance surfaced here as a raw traceback.
            if is_dead_balance(e):
                raise OutOfCredit(str(e)) from e
            raise
        vecs.extend(d.embedding for d in r.data)
    a = np.array(vecs, dtype=np.float64)
    return a / np.linalg.norm(a, axis=1, keepdims=True)


def ssr_scores(reaction_vecs, anchor_vecs_by_point, temp):
    """Map each reaction embedding to a pmf over 1..5 (softmax of mean cosine
    similarity per Likert point / temp), return expected scores + pmfs."""
    sims = np.stack(
        [np.mean(reaction_vecs @ np.stack(anchor_vecs_by_point[pt]).T, axis=1) for pt in range(1, 6)],
        axis=1,
    )  # (n, 5)
    logits = sims / temp
    logits -= logits.max(axis=1, keepdims=True)
    pmf = np.exp(logits)
    pmf /= pmf.sum(axis=1, keepdims=True)
    scores = pmf @ np.arange(1, 6)
    return scores, pmf


def synthesize_themes(cfg, images, reactions):
    """One aggregation call: per-candidate strengths/objections (WITH COUNTS),
    a cross-candidate ranked objection list, and suggested fixes.
    BLIND / ANTI-LEAK: candidates are referred to by NEUTRAL aliases (set_1,
    set_2...), never by their human labels. A label like "our new design" or
    "live on Amazon" would tell the judge the answer. Aliases are mapped back
    to ids after the call, so nothing about incumbency reaches the model."""
    alias = {img["id"]: f"set_{i + 1}" for i, img in enumerate(images)}
    back = {v: k for k, v in alias.items()}
    blocks = []
    for img in images:
        sample, seen = [], set()
        for r in reactions:
            if r["image_id"] != img["id"] or r["text"].startswith("__ERROR__"):
                continue
            t = r["text"].strip()
            if t in seen:  # dedupe identical reactions so a repeat can't inflate a theme
                continue
            seen.add(t)
            sample.append(t)
        joined = "\n".join(f"- {t}" for t in sample[:40])
        blocks.append(f"### {alias[img['id']]} ({min(len(sample), 40)} reactions)\n{joined}")
    prompt = (
        f"Below are reactions from a synthetic consumer panel to {len(images)} alternative Amazon listing images "
        f"for: {cfg['product_context']}.\n\n" + "\n\n".join(blocks) + "\n\n"
        "Return ONE strict JSON object with EXACTLY these four top-level keys, ALL REQUIRED: "
        '"images", "objections_ranked", "suggested_edits", "cross_takeaways". Never omit a key; use [] when empty.\n'
        '- "images": {"<set_alias>": {"strengths": [{"text": "short theme", "count": <int>}] (max 3), '
        '"objections": [{"text": "short theme", "count": <int>}] (max 3)}}\n'
        '- "objections_ranked": [{"text": "short theme", "count": <int>, "applies_to": ["<set_alias>", ...]}] '
        "(max 6, across ALL candidates, sorted by count descending)\n"
        '- "suggested_edits": [max 6 strings, each one concrete, surgical image edit that addresses a '
        "recurring objection - phrased as an instruction]\n"
        '- "cross_takeaways": [3-5 short strings - what this panel teaches about what converts for THIS '
        "audience, phrased as reusable creative rules]\n"
        "COUNT RULE: count = how many DISTINCT reactions above raise that theme (an honest tally, "
        "never a guess above the listed reactions). Only include themes that recur in 2 or more "
        "reactions. No markdown, JSON only."
    )
    def _parse(raw):
        try:
            return json.loads(raw[raw.index("{") : raw.rindex("}") + 1])
        except Exception:  # noqa: BLE001
            return None

    model = cfg.get("model", "gpt-5.4-mini")
    cross_keys = ("objections_ranked", "suggested_edits", "cross_takeaways")
    parsed, out = None, ""
    for _ in range(2):  # one retry: the model sometimes drops required keys anyway
        out = chat([{"role": "user", "content": prompt}], model, max_tokens=3000, json_mode=True)
        parsed = _parse(out)
        if parsed and parsed.get("images") and all(parsed.get(k) for k in cross_keys):
            break
    if not parsed:
        return {"images": {}, "objections_ranked": [], "suggested_edits": [], "cross_takeaways": [], "_raw": out}
    parsed.setdefault("images", {})
    # The model regularly returns ONLY "images" and drops the cross-candidate
    # keys. A short focused follow-up (tiny output, still in ALIAS space, no
    # image re-send) fills exactly what is missing far more reliably than
    # another full retry.
    missing = [k for k in cross_keys if not parsed.get(k)]
    if missing and parsed["images"]:
        f_prompt = (
            "Per-image recurring themes from a synthetic shopper panel (JSON):\n"
            + json.dumps(parsed["images"]) + "\n\n"
            "Return STRICT JSON with exactly these three keys: "
            '{"objections_ranked": [{"text": "short theme", "count": <int>, "applies_to": ["<set_alias>", ...]}] '
            "(max 6, across ALL candidates, sorted by count descending), "
            '"suggested_edits": [max 6 concrete, surgical image-edit instructions addressing recurring objections], '
            '"cross_takeaways": [3-5 short reusable creative rules for this audience]}. JSON only.'
        )
        extra = _parse(chat([{"role": "user", "content": f_prompt}], model, max_tokens=1200, json_mode=True)) or {}
        for k in missing:
            if extra.get(k):
                parsed[k] = extra[k]
    # map neutral aliases back to real image ids, and NORMALIZE shapes at the
    # source so no downstream renderer ever meets a bare list / bare string
    # (the model occasionally emits both; results.json must carry clean dicts)
    parsed["images"] = {
        back.get(k, k): (v if isinstance(v, dict)
                         else {"strengths": [], "objections": v if isinstance(v, list) else []})
        for k, v in parsed.get("images", {}).items()
    }
    parsed["objections_ranked"] = [
        (o if isinstance(o, dict) else {"text": str(o), "count": None, "applies_to": []})
        for o in (parsed.get("objections_ranked") or [])
    ]
    for o in parsed["objections_ranked"]:
        o["applies_to"] = [back.get(a, a) for a in (o.get("applies_to") or [])]
    parsed.setdefault("suggested_edits", [])
    parsed.setdefault("cross_takeaways", [])
    if not parsed.get("objections_ranked"):
        # deterministic fallback: aggregate the per-image objections by count so
        # the ranked list can never silently vanish from the report
        merged = {}
        for iid, tt in parsed["images"].items():
            # lenient: a malformed entry may be a bare list instead of the dict
            objs = tt.get("objections") if isinstance(tt, dict) else (tt if isinstance(tt, list) else None)
            for txt, cnt in theme_items(objs):
                m = merged.setdefault(txt.lower(), {"text": txt, "count": 0, "applies_to": []})
                m["count"] += cnt or 1
                m["applies_to"].append(iid)
        parsed["objections_ranked"] = sorted(merged.values(), key=lambda o: -o["count"])[:6]
    return parsed


def theme_items(lst):
    """Normalize a strengths/objections/top_works list to [(text, count)].
    Accepts both the new {"text","count"} dicts and legacy plain strings, so
    older results.json files still render."""
    out = []
    for t in lst or []:
        if isinstance(t, dict):
            txt = str(t.get("text", "")).strip()
            cnt = t.get("count")
            if txt:
                out.append((txt, int(cnt) if isinstance(cnt, (int, float)) and cnt else None))
        elif str(t).strip():
            out.append((str(t).strip(), None))
    return out


TIER_LABEL = {"clear": "Clear lead", "lean": "Lean", "tossup": "Toss-up"}
TIER_MEANING = {
    "clear": "safe to act on this alone",
    "lean": "directionally useful; a hint, not proof, and the owner decides",
    "tossup": "treat as a tie; use the objections, ignore the counts",
}

# Minimum purchase-intent gap, on the raw 1-5 scale, for a top tier.
# 0.25 of 5 is about 6% of the usable range.
#
# PROVISIONAL. Refit it once enough panel-versus-real results have accumulated
# in the Improvement Log to compare against: that is the trigger, not a hunch.
#
# Deliberately NOT standardised (no Cohen's d). Persona-to-persona SD is tiny
# because same-model personas rate alike, so dividing by it inflates a trivial
# gap into a respectable-looking effect size. The compressed variance IS the
# bias; using it as the denominator launders the bias into a credible number.
# The raw delta on its natural scale is the honest one.
MIN_INTENT_GAP = 0.25


def intent_magnitude(agg, ranked_ids):
    """The winner's purchase-intent lead over the runner-up, on the raw 1-5 scale.

    This is the SECOND thing a top tier needs. Bootstrap stability answers
    "would resampling these same tasters flip the winner", which a near-unanimous
    vote never does. It says nothing about whether the difference is large enough
    to be worth acting on. A forced binary choice turns any consistent preference
    into a landslide however small it is, so direction and magnitude have to be
    measured separately or the report claims certainty it never had.

    Returns (gap, decisive, w_mean, r_mean); gap is None when intent is missing.
    """
    if len(ranked_ids) < 2:
        return None, False, None, None
    w = agg[ranked_ids[0]].get("ssr_mean")
    r = agg[ranked_ids[1]].get("ssr_mean")
    if w is None or r is None:
        return None, False, w, r
    gap = round(w - r, 3)
    return gap, gap >= MIN_INTENT_GAP, w, r



def magnitude_sentence(verdict):
    """The magnitude line that sits beside the vote count.

    Pure and separately testable on purpose. The count answers "how reliably did
    they agree on the direction" and cannot answer "by how much", so this sentence
    has to stay honest about BOTH the sign of the gap and whether it cleared the
    bar. It used to print a hardcoded "+" and claim "at or above" on any run where
    the clear-tier downgrade had not fired, which on a toss-up with a negative gap
    read "+-0.057 of 5, at or above the +0.25 bar" on a run that failed the bar.
    """
    if verdict.get("intent_gap") is None:
        return None
    g = verdict["intent_gap"]
    if verdict.get("tier_downgraded_for_magnitude"):
        return (
            f"**Consistent, not decisive.** The direction is stable, but purchase intent "
            f"differs by only +{g} of 5 ({round(g / 5 * 100, 1)}% of the scale), under the "
            f"+{MIN_INTENT_GAP} needed to act on this alone. A forced choice turns any "
            f"consistent preference into a landslide however small it is, which is why the "
            f"vote count alone is not the verdict. Downgraded to {verdict['label']}."
        )
    if g < 0:
        return (
            f"**The vote leader is behind on intent.** They chose it more often, but "
            f"purchase intent runs {abs(g)} of 5 LOWER than the runner-up. The count and "
            f"the intent disagree, so this is not a result to act on."
        )
    if verdict.get("intent_gap_decisive"):
        return (
            f"Purchase intent separates them by +{g} of 5, at or above the "
            f"+{MIN_INTENT_GAP} bar, so the size of the difference supports the direction."
        )
    return (
        f"Purchase intent separates them by only +{g} of 5, under the "
        f"+{MIN_INTENT_GAP} bar, so the size of the difference does not support acting "
        f"on this alone."
    )

def bootstrap_stability(vote_counts, seed=42, resamples=1000):
    """vote_counts: [(id, votes)]. Bootstrap resample the recorded forced-choice
    votes and report the share of resamples where the winner stays strictly
    first, plus the minimum number of flipped votes that would erase rank 1.
    This is THE decision label, the same math the Tasting Card renders:
    clear (>= 95% of resamples), lean (80-95%), tossup (< 80%)."""
    pool = []
    for k, v in vote_counts:
        pool += [k] * v
    n = len(pool)
    ordered = sorted(vote_counts, key=lambda kv: -kv[1])
    winner = ordered[0][0]
    if n == 0 or len(ordered) < 2:
        return {"tier": "tossup", "holds": 0, "of": resamples, "flip_votes": 0, "winner": winner}
    rng = random.Random(seed)
    holds = 0
    for _ in range(resamples):
        c = Counter(pool[rng.randrange(n)] for _ in range(n))
        top = c.most_common(2)
        if top[0][0] == winner and (len(top) == 1 or top[0][1] > top[1][1]):
            holds += 1
    gap = ordered[0][1] - ordered[1][1]
    flip = gap // 2 + 1
    share = holds / resamples
    tier = "clear" if share >= 0.95 else ("lean" if share >= 0.80 else "tossup")
    return {"tier": tier, "holds": holds, "of": resamples, "flip_votes": flip, "winner": winner}


def model_agreement(tasters, choices):
    """Per-base-model forced-choice winners, computed from the recorded votes.
    With a model mix, a DISAGREEMENT between the base models means the "winner"
    is a model-taste artifact, not shopper signal - the caller downgrades the
    verdict to tossup (the card does the same)."""
    vote_of = {c["persona_id"]: c.get("chosen") for c in choices}
    model_names = sorted({p.get("model") for p in tasters if p.get("model")})
    if len(model_names) < 2:
        return None, {}
    winners = {}
    for m in model_names:
        cnt = Counter(vote_of.get(p["id"]) for p in tasters if p.get("model") == m and vote_of.get(p["id"]))
        if cnt:
            winners[m] = cnt.most_common(1)[0][0]
    return (len(set(winners.values())) <= 1 if winners else None), winners


def load_comparison(cfg, agg):
    """Optional round-over-round comparison. When the config has
    "compare_to": "/abs/path/to/previous/results.json", load that prior run
    and compute choice-share deltas for candidates sharing ids. Powers the
    Round Comparison section (Round 2 vs Round 1). Never required; a missing
    or unreadable file just skips the section with a console note."""
    prev_path = cfg.get("compare_to")
    if not prev_path:
        return None
    try:
        prev = json.loads(Path(prev_path).read_text())
        prev_agg = prev["aggregate"]
    except Exception as e:  # noqa: BLE001
        print(f"  note: compare_to could not be read ({e}); skipping the round comparison")
        return None
    prev_round = prev.get("config", {}).get("round")
    rows = []
    for iid, a in agg.items():
        row = {"id": iid, "label": a["label"], "share": a["choice_share"], "votes": a["choice_votes"]}
        pa = prev_agg.get(iid)
        if pa:
            row["prev_share"] = pa.get("choice_share")
            row["prev_votes"] = pa.get("choice_votes")
            # Deltas are in VOTES. Points of share invite the market-share reading
            # a forced choice can never support.
            row["delta_votes"] = a["choice_votes"] - pa.get("choice_votes", 0)
        rows.append(row)
    return {
        "prev_path": str(prev_path),
        "prev_round": prev_round,
        "rows": rows,
        "new_ids": [i for i in agg if i not in prev_agg],
        "dropped_ids": [i for i in prev_agg if i not in agg],
    }


def cfg_sig(cfg):
    """Fingerprint of the inputs that determine the LLM calls. A checkpoint
    only resumes when these are unchanged."""
    key = {
        "images": [(i["id"], paths_of(i)) for i in cfg["images"]],
        "n": cfg.get("n_personas", 100),
        "model": cfg.get("model", "gpt-5.4-mini"),
        # The EFFECTIVE mix, not the raw config keys: a change to the built-in
        # default mix must also reset checkpoints, or a resume would mislabel
        # reactions already recorded under the old models.
        "models": model_mix(cfg),
        "seed": cfg.get("seed", 42),
        "pis": cfg.get("per_image_sample", 40),
        "ctx": cfg.get("product_context", ""),
    }
    import hashlib

    return hashlib.sha256(json.dumps(key, sort_keys=True).encode()).hexdigest()[:16]


def preflight_keys(cfg):
    """Every provider in the model mix must have its key BEFORE any spend.
    A missing key stops the run loudly and immediately; silently dropping a
    provider would quietly turn a mixed panel back into a single-model panel
    with one shared taste, and failing mid-run wastes the calls already made."""
    mix = model_mix(cfg)
    need = {"OPENAI_API_KEY"}  # tasters by default + embeddings/SSR are always OpenAI
    for m in mix:
        if m.startswith("gemini"):
            need.add("GEMINI_API_KEY")
        elif m.startswith("claude"):
            need.add("ANTHROPIC_API_KEY")
    missing = sorted(k for k in need if not os.environ.get(k))
    if missing:
        sys.exit(
            f"MISSING API KEY(S): {', '.join(missing)}. Add them to the .env file at your "
            f"Factory root. Refusing to start: the config's model mix {list(mix)} needs every "
            "provider's key, and dropping one would bias the tasting toward a single model's taste. "
            "Either add the key(s) or remove those entries from \"models\" in the config."
        )


def preflight_config(cfg):
    """Validate the config BEFORE any spend. Every failure listed here used to
    cost real money and surface late: a typo'd path crashed a worker thread
    mid-run (after the other reactions were already paid for), an
    `incumbent_id` matching no candidate silently dropped the vs-incumbent
    verdict from the card, two candidates sharing an id silently merged their
    votes, and a 13th candidate or a 13th frame in a set ran off the end of the
    letter alphabet the forced choice uses. All of it is knowable at zero cost,
    so it fails here, loudly, before the first call."""
    problems = []
    images = cfg.get("images")
    for key in ("images", "out_dir", "product_context"):
        if not cfg.get(key):
            problems.append(f'missing required config key "{key}"')
    if images is not None and not isinstance(images, list):
        problems.append('"images" must be a LIST of candidates')
        images = None
    if isinstance(images, list):
        if len(images) < 2:
            problems.append(
                f"only {len(images)} candidate in the config. The forced choice needs at least two: "
                "your candidates plus the incumbent, or plus the strongest competitor's file "
                "when nothing is live yet."
            )
        if len(images) > len(LETTERS):
            problems.append(
                f"{len(images)} candidates; the forced choice supports at most {len(LETTERS)}"
            )
        seen = set()
        for i, img in enumerate(images, 1):
            if not isinstance(img, dict):
                problems.append(f"candidate #{i} is not an object")
                continue
            iid = img.get("id")
            if not iid:
                problems.append(f'candidate #{i} has no "id"')
                continue
            if iid in seen:
                problems.append(f'duplicate candidate id "{iid}"; ids must be unique or their votes merge')
            seen.add(iid)
            paths = img.get("paths") or ([img["path"]] if img.get("path") else [])
            if not paths:
                problems.append(f'candidate "{iid}" has neither "path" nor "paths"')
                continue
            if len(paths) > len(LETTERS):
                problems.append(
                    f'set "{iid}" has {len(paths)} frames; at most {len(LETTERS)} are supported'
                )
            for pth in paths:
                if not Path(pth).is_file():
                    problems.append(f'candidate "{iid}": file not found: {pth}')
        inc = cfg.get("incumbent_id")
        if inc and inc not in seen:
            problems.append(
                f'incumbent_id "{inc}" matches no candidate id ({", ".join(sorted(seen)) or "none"}). '
                "The incumbent must BE one of the candidates, or the vs-incumbent verdict "
                "silently vanishes from the card."
            )
    if problems:
        sys.exit(
            "CONFIG PROBLEM(S). Nothing ran and nothing was spent:\n  - "
            + "\n  - ".join(problems)
            + "\nFix the config and run the same command again."
        )

    # Unequal frame counts in a set-vs-set race are allowed and normal: a live
    # gallery is often shorter than the set we propose, and the sets are
    # compared as they are, no frames dropped. What the note does is DESCRIBE
    # the comparison, before the spend: both counts, and the fact that count
    # and content differences (a frame type one set has and the other lacks,
    # another product model in the live gallery) limit what can be attributed
    # to the creative changes. Kit v38, 12 September 2026.
    if isinstance(images, list):
        sets = [(i.get("id"), len(i.get("paths") or [])) for i in images
                if isinstance(i, dict) and len(i.get("paths") or []) > 1]
        if len({n for _, n in sets}) > 1:
            desc = ", ".join(f'"{i}" has {n}' for i, n in sets)
            print(f"  NOTE: the galleries are compared as they are ({desc} frames). Count and "
                  "content differences between the sets limit what can be attributed to the "
                  "creative changes; say both counts and any content difference when you report "
                  "the result.")
        for line in incumbent_notes(cfg):
            print(f"  NOTE from incumbent/notes.md: {line}")


def incumbent_notes(cfg) -> list:
    """Lines the owner wrote about the live gallery in `incumbent/notes.md`
    (`other model: live-04`), read from the folder the incumbent's files sit
    in. Config-free: nothing automatic beyond reading and printing them."""
    images = cfg.get("images") or []
    inc = cfg.get("incumbent_id")
    entry = next((i for i in images if isinstance(i, dict) and i.get("id") == inc), None)
    if not entry:
        return []
    paths = entry.get("paths") or ([entry["path"]] if entry.get("path") else [])
    if not paths:
        return []
    f = Path(paths[0]).parent / "notes.md"
    if not f.is_file():
        return []
    return [ln.strip() for ln in f.read_text(errors="ignore").splitlines()
            if ln.strip().lower().startswith("other model")]


def apply_mode(cfg):
    """LITE mode = the same process at reduced volume: a quick taste (about 20
    tasters at the defaults), for eyeballing a set or testing the machine.
    Set `"mode": "lite"` in the config OR pass `lite` as the 2nd CLI arg.
    Runs at about a fifth of the configured tasters (minimum 8).
    Use the FULL tasting for anything that feeds a real decision."""
    mode = (cfg.get("mode") or "").lower()
    if len(sys.argv) > 2 and sys.argv[2].lower() == "lite":
        mode = "lite"
    if mode == "lite":
        cfg.setdefault("n_personas", 100)
        cfg.setdefault("per_image_sample", 40)
        cfg["n_personas"] = max(8, round(cfg["n_personas"] / 5))
        cfg["per_image_sample"] = max(6, round(cfg["per_image_sample"] / 4))
        cfg["_mode"] = "lite"
    return cfg


def main():
    raw_cfg_text = Path(sys.argv[1]).read_text()
    cfg = apply_mode(json.loads(raw_cfg_text))
    preflight_keys(cfg)
    preflight_config(cfg)
    # The spend cap, on the ESTIMATE, before any request is sent. A race over
    # the cap on its own is over the sitting cap; the sitting total (both races)
    # is checked by `panel.py estimate cfg1 cfg2` before either runs.
    cap = float(cfg.get("spend_cap_usd", SPEND_CAP_DEFAULT_USD))
    est = estimate_cost(cfg)
    ok, line = cap_check(est["usd"], cap)
    if not ok:
        sys.exit(f"SPEND CAP. Nothing ran and nothing was spent. {line}")
    print(line)
    out_dir = Path(cfg["out_dir"])
    out_dir.mkdir(parents=True, exist_ok=True)
    # Reproducibility artifact, written here so it can never be forgotten: the
    # exact config that ran, beside its own results. NEVER overwritten, so a
    # config that already lives in the round folder stays byte-for-byte as the
    # owner wrote it (and a lite re-run can never re-divide its own counts).
    saved_cfg = out_dir / "config.json"
    if not saved_cfg.exists():
        saved_cfg.write_text(raw_cfg_text)
    rng = random.Random(cfg.get("seed", 42))
    images = cfg["images"]
    for img in images:
        img.setdefault("label", img["id"])
    if not cfg.get("demographics"):
        cfg["demographics"] = DEFAULT_DEMOGRAPHICS
        print("note: no demographics in the config, using the DEFAULT general US Amazon shopper. "
              "A real buyer persona (Research Room, Day 2) makes the tasting sharper.")
    elif not cfg["demographics"].get("age_dist"):
        print("note: the demographics block carries no age_dist, so the default age spread is used. "
              "Copy the age bands from research/persona.md to sharpen the panel.")
    tasters = build_tasters(cfg, rng)
    workers = cfg.get("workers", 32)
    tag = " [LITE]" if cfg.get("_mode") == "lite" else ""
    mix = model_mix(cfg)
    print(f"tasting{tag}: {len(tasters)} tasters x {len(images)} candidates, models {', '.join(mix)}")

    # Live progress: writes out_dir/live.html (auto-opens, self-refreshing,
    # with a stall detector) so a minutes-long run is never a silent terminal.
    from progress import Progress
    product_name = cfg.get("product") or cfg.get("asin") or cfg.get("niche", "")
    prog = Progress(out_dir, title=f"Tasting Room{tag} - {product_name}",
                    subtitle=f"{len(tasters)} tasters x {len(images)} candidates")
    prog.update("tasters built", len(tasters), len(tasters))

    # Checkpoint: the expensive LLM phases are saved as they finish, so a run
    # killed by sleep / a closed laptop / a dropped connection RESUMES instead
    # of restarting from zero. Just run the same command again.
    ckpt_path = out_dir / ".panel_ckpt.json"
    sig = cfg_sig(cfg)
    ckpt = {}
    if ckpt_path.exists():
        try:
            loaded = json.loads(ckpt_path.read_text())
            if loaded.get("sig") == sig:
                ckpt = loaded
                print(f"  resuming from checkpoint: {[k for k in ('reactions', 'choices', 'image_feedback') if k in ckpt]}")
        except Exception:  # noqa: BLE001
            ckpt = {}

    def save_ckpt(**kv):
        ckpt.update(kv)
        ckpt["sig"] = sig
        ckpt_path.write_text(json.dumps(ckpt))

    # 1) reactions (tasters x candidates, parallel).
    #
    # ONE store, `reactions_partial`, and a failed call never enters it. The
    # remaining work is derived from which (taster, candidate) PAIRS are
    # present, so "finished" is a property of the data rather than a flag
    # somebody has to set correctly. The old code kept a second `reactions`
    # key meaning "all done" and wrote every result into it including the
    # `__ERROR__` strings, which is how a dead balance froze a 100-taster
    # panel at 19 (26 August 2026): the errors counted as done, the resume had
    # nothing left to do, and the card printed a verdict on the survivors.
    # An old checkpoint from that era is read here and re-filtered, so a
    # poisoned one heals itself on the next run instead of repeating.
    stored = ckpt.get("reactions_partial", []) + ckpt.get("reactions", [])
    partial = {(r["persona_id"], r["image_id"]): r for r in stored if usable(r["text"])}
    reactions = list(partial.values())
    jobs = [(p, img) for p in tasters for img in images if (p["id"], img["id"]) not in partial]
    if partial and jobs:
        print(f"  reactions resume: {len(partial)} done, {len(jobs)} left")
    elif partial and not jobs:
        print(f"  reactions (cached): {len(reactions)}")
    if jobs:
        try:
            with ThreadPoolExecutor(max_workers=workers) as ex:
                futs = {ex.submit(react, p, img, cfg): (p, img) for p, img in jobs}
                for n, fut in enumerate(as_completed(futs), 1):
                    p, img = futs[fut]
                    text = fut.result()
                    if usable(text):
                        reactions.append({"persona_id": p["id"], "image_id": img["id"], "text": text})
                    prog.update("taster reactions", len(reactions), len(tasters) * len(images))
                    if n % 40 == 0:
                        print(f"  reactions {len(reactions)}/{len(tasters) * len(images)}")
                        save_ckpt(reactions_partial=reactions)
        except OutOfCredit as e:
            save_ckpt(reactions_partial=reactions)
            out_of_credit(e, f"{len(reactions)}/{len(tasters) * len(images)} reactions were saved")
        save_ckpt(reactions_partial=reactions)
    # A blank reaction is not an __ERROR__ (a model can return empty content and
    # still "succeed"), but the embeddings API 400s on empty input, which would
    # crash SSR scoring AFTER every paid taster call. A blank is real, paid work,
    # so it stays in the checkpoint and is not re-asked; it is simply dropped
    # from scoring here, once, with a count.
    ok = [r for r in reactions
          if not r["text"].startswith("__ERROR__") and r["text"].strip()]
    blanks = len([r for r in reactions
                  if not r["text"].startswith("__ERROR__") and not r["text"].strip()])
    print(f"  reactions done: {len(ok)}/{len(reactions)} ok"
          + (f" ({blanks} blank, dropped)" if blanks else ""))

    # 2) forced choice (one per taster, shuffled order). Same rule as reactions:
    # a taster whose call FAILED is not a taster who abstained, so the failure
    # is not stored and the next run asks them again. A taster who answered in
    # a way we could not parse IS stored: re-asking would cost money to be
    # refused the same way, and a dropped vote is the honest outcome there.
    done_choices = {c["persona_id"]: c for c in ckpt.get("choices", []) if usable(c.get("raw", ""))}
    choices = list(done_choices.values())
    todo = [p for p in tasters if p["id"] not in done_choices]
    if done_choices and todo:
        print(f"  choices resume: {len(done_choices)} done, {len(todo)} left")
    elif done_choices and not todo:
        print(f"  choices (cached): {len(choices)}")
    if todo:
        try:
            with ThreadPoolExecutor(max_workers=workers) as ex:
                futs = {ex.submit(choose, p, images, cfg, random.Random(cfg.get("seed", 42) * 1000 + p["id"])): p for p in todo}
                for fut in as_completed(futs):
                    p = futs[fut]
                    chosen, raw = fut.result()
                    if usable(raw):
                        choices.append({"persona_id": p["id"], "chosen": chosen, "raw": raw})
                    prog.update("forced choice", len(choices), len(tasters))
        except OutOfCredit as e:
            save_ckpt(choices=choices)
            out_of_credit(e, f"{len(choices)}/{len(tasters)} forced choices were saved")
        save_ckpt(choices=choices)
    choice_parse_rate = sum(1 for c in choices if c["chosen"]) / max(1, len(choices))
    print(f"  choices done: {sum(1 for c in choices if c['chosen'])}/{len(choices)} parsed")
    if choice_parse_rate < 0.9:
        print(f"  WARNING: only {round(choice_parse_rate * 100)}% of forced choices parsed. "
              "The counts are on a reduced sample; check API health and consider re-running.")

    # 2b) per-image structured tasting notes. Runs when any candidate is a
    # stack; for single-image candidates the set-level pass already IS
    # per-image. Sampled tasters per image to control cost.
    image_agg = {}
    stacks_mode = any(len(paths_of(i)) > 1 for i in images)
    if "image_feedback" in ckpt:
        image_feedback = ckpt["image_feedback"]
        print(f"  per-image (cached): {len(image_feedback)}")
    elif stacks_mode and cfg.get("per_image", True):
        image_feedback = []
        sample_n = int(cfg.get("per_image_sample", 40))
        rng_pi = random.Random(cfg.get("seed", 42) + 999)
        sample = tasters if len(tasters) <= sample_n else rng_pi.sample(tasters, sample_n)
        pi_jobs = []
        for img in images:
            for idx, path in enumerate(paths_of(img), 1):
                for p in sample:
                    pi_jobs.append((p, {"set_id": img["id"], "idx": idx, "path": path}))
        print(f"  per-image pass: {len(pi_jobs)} structured tasting notes")
        try:
            with ThreadPoolExecutor(max_workers=workers) as ex:
                futs = {ex.submit(react_image, p, si, cfg): (p, si) for p, si in pi_jobs}
                for n, fut in enumerate(as_completed(futs), 1):
                    p, si = futs[fut]
                    d = fut.result()
                    if usable(d.get("reaction", "")):
                        image_feedback.append({"persona_id": p["id"], **si, **d})
                    prog.update("per-image tasting notes", n, len(pi_jobs))
                    if n % 100 == 0:
                        print(f"    per-image {n}/{len(pi_jobs)}")
        except OutOfCredit as e:
            save_ckpt(image_feedback=image_feedback)
            out_of_credit(e, f"{len(image_feedback)}/{len(pi_jobs)} per-image notes were saved")
        save_ckpt(image_feedback=image_feedback)
    else:
        image_feedback = []

    # 2c) WITHIN-SET vote (the "strongest image" metric): every taster picks
    # the most convincing + weakest image inside each stack. This comparative
    # vote is the PRIMARY per-image ranking; the isolation intent / net-impact
    # above stay as diagnostics. All tasters vote (better stats).
    if "within_votes" in ckpt:
        within_votes = ckpt["within_votes"]
        print(f"  within-set votes (cached): {len(within_votes)}")
    elif stacks_mode:
        within_votes = []
        wv_jobs = [(p, img) for img in images if len(paths_of(img)) > 1 for p in tasters]
        print(f"  within-set vote pass: {len(wv_jobs)} votes")
        try:
            with ThreadPoolExecutor(max_workers=workers) as ex:
                futs = {
                    ex.submit(rank_within_set, p, img, cfg, random.Random(cfg.get("seed", 42) * 7 + p["id"])): (p, img)
                    for p, img in wv_jobs
                }
                for n, fut in enumerate(as_completed(futs), 1):
                    p, img = futs[fut]
                    try:
                        best, worst = fut.result()
                    except OutOfCredit:
                        raise  # an empty balance is not "one bad vote"
                    except Exception as e:  # noqa: BLE001 - one bad vote must not kill the pass
                        print(f"    within-vote error (skipped): {str(e)[:80]}")
                        best, worst = None, None
                    within_votes.append({"persona_id": p["id"], "set_id": img["id"], "best": best, "worst": worst})
                    prog.update("within-set votes", n, len(wv_jobs))
                    if n % 60 == 0:
                        print(f"    within-vote {n}/{len(wv_jobs)}")
        except OutOfCredit as e:
            save_ckpt(within_votes=within_votes)
            out_of_credit(e, f"{len(within_votes)}/{len(wv_jobs)} within-set votes were saved")
        save_ckpt(within_votes=within_votes)
    else:
        within_votes = []
    if within_votes:
        wv_rate = sum(1 for v in within_votes if v.get("best")) / len(within_votes)
        if wv_rate < 0.9:
            print(f"  WARNING: only {round(wv_rate * 100)}% of within-set votes parsed. "
                  "Per-image ranking is on a reduced sample.")

    # 3) SSR scoring
    prog.update("SSR scoring + theme synthesis")
    if not ok:
        sys.exit("Every reaction failed (__ERROR__) or came back blank. The provider is down, "
                 "the key is rate-limited, or the model returned empty content. Nothing was "
                 "scored; fix the connection and run the same command again (the checkpoint "
                 "resumes).")

    # COVERAGE GATE. A verdict is arithmetic on a panel, so a panel that is not
    # there is not a weaker verdict, it is no verdict. This runs BEFORE the
    # embeddings spend and it refuses rather than warns.
    #
    # It exists because of what a thin panel looks like from the outside: on
    # 26 August 2026 a crashed race resumed into 19 and 23 tasters with zero forced
    # choices parsed, and every downstream surface did its job perfectly. The
    # card rendered, the stability tier computed, the verdict read "Toss-up",
    # and nothing anywhere said the room had been almost empty. The only tell
    # was the n column, and a number that small reads as a detail rather than
    # an alarm. Warnings are for a panel that is nearly whole; a panel missing
    # a third of its tasters gets a stop.
    floor = float(cfg.get("coverage_floor", 0.7))
    thin = {i["id"]: sum(1 for r in ok if r["image_id"] == i["id"]) for i in images}
    short = {k: v for k, v in thin.items() if v < floor * len(tasters)}
    voted = sum(1 for c in choices if c["chosen"])
    if short or voted < floor * len(tasters):
        detail = ", ".join(f"{k}: {v}/{len(tasters)} tasters" for k, v in short.items())
        sys.exit(
            "PANEL TOO THIN TO JUDGE. Refusing to write a verdict.\n"
            + (f"  candidates under the floor: {detail}\n" if short else "")
            + f"  forced choices parsed: {voted}/{len(tasters)}\n"
            + f"  the floor is {round(floor * 100)}% of the panel (set \"coverage_floor\" in the config to change it).\n"
            "Calls failed, so those tasters were never recorded and the checkpoint kept only the "
            "real answers. Run the SAME command again and it asks exactly the missing tasters. "
            "If it keeps landing here, the provider or the key is the problem, not the panel."
        )
    anchor_texts = [t for pt in range(1, 6) for t in ANCHORS[pt]]
    anchor_vecs = embed_all(anchor_texts)
    anchor_by_point = {pt: [anchor_vecs[(pt - 1) * 3 + j] for j in range(3)] for pt in range(1, 6)}
    reaction_vecs = embed_all([r["text"] for r in ok])
    scores, pmfs = ssr_scores(reaction_vecs, anchor_by_point, cfg.get("temp", 0.075))
    for r, s, pmf in zip(ok, scores, pmfs):
        r["ssr"] = round(float(s), 3)
        r["pmf"] = [round(float(x), 3) for x in pmf]

    # per-image SSR + aggregation (needs the anchors from above)
    if stacks_mode and cfg.get("per_image", True):
        pi_ok = [f for f in image_feedback
                 if f["reaction"] and f["reaction"].strip()
                 and not f["reaction"].startswith("__ERROR__")]
        if pi_ok:
            pi_vecs = embed_all([f["reaction"] for f in pi_ok])
            pi_scores, _ = ssr_scores(pi_vecs, anchor_by_point, cfg.get("temp", 0.075))
            for f, s in zip(pi_ok, pi_scores):
                f["ssr"] = round(float(s), 3)
        for img in images:
            votes = [v for v in within_votes if v["set_id"] == img["id"]]
            vote_total = sum(1 for v in votes if v.get("best"))
            rows = []
            for idx, path in enumerate(paths_of(img), 1):
                fb = [f for f in image_feedback if f["set_id"] == img["id"] and f["idx"] == idx]
                good = [f for f in fb if f.get("ssr") is not None]
                boosts = sum(1 for f in fb if f["impact"] == "boosts")
                hurts = sum(1 for f in fb if f["impact"] == "hurts")
                strongest = sum(1 for v in votes if v.get("best") == idx)
                weakest = sum(1 for v in votes if v.get("worst") == idx)
                rows.append(
                    {
                        "idx": idx,
                        "path": path,
                        "n": len(fb),
                        "ssr_mean": round(float(np.mean([f["ssr"] for f in good])), 3) if good else None,
                        "boosts": boosts,
                        "neutral": sum(1 for f in fb if f["impact"] == "neutral"),
                        "hurts": hurts,
                        "net_impact": boosts - hurts,  # >0 helps the listing, <0 drags it
                        # PRIMARY per-image ranking metric (comparative vote):
                        "strongest_votes": strongest,
                        "weakest_votes": weakest,
                        "strongest_pct": round(strongest / vote_total * 100) if vote_total else None,
                        "vote_total": vote_total,
                        "feedback": fb,
                    }
                )
            takeaways = synthesize_image_takeaways(cfg, img["id"], rows, cfg.get("model", "gpt-5.4-mini"))
            for row in rows:
                t = takeaways.get(f"image_{row['idx']}", {})
                row["top_works"] = t.get("top_works", [])
                row["top_doesnt"] = t.get("top_doesnt", [])
                row["takeaway"] = t.get("takeaway", "")
                row["feedback"] = [{k: v for k, v in f.items() if k not in ("set_id", "idx", "path")} for f in row["feedback"]]
            image_agg[img["id"]] = rows

    # 4) aggregate
    by_img = defaultdict(list)
    taster_by_id = {p["id"]: p for p in tasters}
    for r in ok:
        by_img[r["image_id"]].append(r)
    agg = {}
    total_choices = max(1, sum(1 for c in choices if c["chosen"]))
    for img in images:
        rs = by_img[img["id"]]
        vals = np.array([r["ssr"] for r in rs])
        seg = defaultdict(list)
        for r in rs:
            p = taster_by_id[r["persona_id"]]
            seg[p["age_band"]].append(r["ssr"])
            seg[p["gender"]].append(r["ssr"])
            # per-model segment: shows when the base models DISAGREE (the whole
            # point of mixing). A candidate that wins on one model and loses on
            # another is a model-taste artifact, not a real audience signal.
            if p.get("model"):
                seg[p["model"]].append(r["ssr"])
        agg[img["id"]] = {
            "label": img["label"],
            "n": len(rs),
            "ssr_mean": round(float(vals.mean()), 3) if len(rs) else None,
            "ssr_std": round(float(vals.std()), 3) if len(rs) else None,
            "choice_votes": sum(1 for c in choices if c["chosen"] == img["id"]),
            "choice_share": round(sum(1 for c in choices if c["chosen"] == img["id"]) / total_choices, 3),
            "segments": {k: round(float(np.mean(v)), 3) for k, v in sorted(seg.items())},
        }
    # Verdict: BOOTSTRAP STABILITY of the forced choice is the decision label
    # (Clear lead / Lean / Toss-up) - the exact same math the Tasting Card
    # renders, so the markdown twin and the card can never disagree. The
    # z-approx stays in results for continuity. A per-model disagreement
    # forces Toss-up: the "winner" is model taste, not shopper signal.
    ranked_ids = sorted(agg, key=lambda i: -agg[i]["choice_votes"])
    c1, c2 = agg[ranked_ids[0]]["choice_votes"], agg[ranked_ids[1]]["choice_votes"] if len(ranked_ids) > 1 else 0
    z = (c1 - c2) / max(1e-9, (c1 + c2) ** 0.5)
    stab = bootstrap_stability(
        [(i["id"], agg[i["id"]]["choice_votes"]) for i in images], seed=cfg.get("seed", 42)
    )
    models_agree, model_winners = model_agreement(tasters, choices)
    if models_agree is False:
        stab["tier"] = "tossup"

    # A top tier needs BOTH a stable direction and a magnitude worth acting on.
    # Order matters: direction first, then size. An unstable vote is never
    # rescued by a large intent gap, so the downgrade only ever applies to a
    # tier the bootstrap already earned.
    gap, decisive, w_mean, r_mean = intent_magnitude(agg, ranked_ids)
    downgraded = False
    if stab["tier"] == "clear" and gap is not None and not decisive:
        stab["tier"] = "lean"
        downgraded = True

    verdict = {
        "winner_id": ranked_ids[0],
        "winner_vs_runner_up_z": round(float(z), 2),
        "significant": bool(z >= 1.96),
        "stability": stab,
        "label": TIER_LABEL[stab["tier"]],
        "models_agree": models_agree,
        "model_winners": model_winners,
        "intent_gap": gap,
        "intent_gap_decisive": decisive,
        "intent_gap_threshold": MIN_INTENT_GAP,
        "intent_winner_mean": w_mean,
        "intent_runner_up_mean": r_mean,
        "tier_downgraded_for_magnitude": downgraded,
    }
    incumbent_id = cfg.get("incumbent_id")
    if incumbent_id and incumbent_id in agg:
        inc = agg[incumbent_id]
        verdict["incumbent_id"] = incumbent_id
        verdict["winner_beats_incumbent"] = ranked_ids[0] != incumbent_id
        verdict["winner_vs_incumbent_votes"] = (
            agg[ranked_ids[0]]["choice_votes"] - inc["choice_votes"]
        )
    themes = synthesize_themes(cfg, images, ok)
    comparison = load_comparison(cfg, agg)

    # 5) write results + Tasting Card (markdown)
    results = {
        "run_date": time.strftime("%Y-%m-%d"),
        "config": {k: v for k, v in cfg.items() if k != "images"},
        "images": [{"id": i["id"], "label": i["label"], "paths": paths_of(i)} for i in images],
        "personas": tasters,
        "aggregate": agg,
        "verdict": verdict,
        "quality": {
            "reactions_ok": len(ok),
            "reactions_total": len(reactions),
            "choice_parse_rate": round(choice_parse_rate, 3),
            "within_vote_parse_rate": round(
                sum(1 for v in within_votes if v.get("best")) / len(within_votes), 3
            ) if within_votes else None,
            "spend_cap_usd": cap,
            "spend_usd_estimated_before_run": est["usd"],
            **spend_report(),
        },
        "themes": themes,
        "comparison": comparison,
        "image_agg": image_agg,
        "within_votes": within_votes,
        "reactions": reactions,
        "choices": choices,
    }
    (out_dir / "results.json").write_text(json.dumps(results, indent=1))

    # Ranking doctrine: the forced CHOICE decides, SSR intent is diagnostic.
    ranked = sorted(images, key=lambda i: -agg[i["id"]]["choice_votes"])
    product = cfg.get("product") or cfg.get("asin") or cfg.get("niche", "product")
    round_no = cfg.get("round", 1)
    def fmt_theme(lst):
        return "; ".join(f"{t}{f' (x{c})' if c else ''}" for t, c in theme_items(lst)) or "-"

    lines = [
        f"# Tasting Room Results - {product} (Round {round_no})",
        "",
        f"**Product:** {cfg['product_context']}",
        f"**Panel:** {len(tasters)} synthetic tasters matched to the buyer "
        f"({cfg['demographics'].get('notes', '')}), models: {', '.join(mix)}, "
        f"{'lite' if cfg.get('_mode') == 'lite' else 'full'} mode, {time.strftime('%Y-%m-%d')}. "
        "Free-text reactions scored via SSR (arXiv 2510.08338).",
        "",
    ]
    if choice_parse_rate < 0.9:
        lines += [
            f"**QUALITY WARNING: only {round(choice_parse_rate * 100)}% of forced-choice votes parsed.** "
            "The counts below sit on a reduced sample; re-run (it resumes) before trusting the verdict.",
            "",
        ]
    lines += [
        "## Verdict",
        "",
        # The FILE column is not decoration. The Shipping Room verifies that the
        # file it packages is the one that actually raced, and the Fixing Room
        # refines "the winner" by name. Both were told to read a filename off
        # this card, and for a long time the card only carried ids and labels,
        # so the check had to be done from config.json or guessed. It is written
        # here as well now: same source, one less hop, and the card stays
        # readable on its own months later.
        "| # | Candidate | File | Chosen by | Purchase intent 1-5 | n |",
        "|---|-----------|------|-----------|---------------------|---|",
    ]
    for rank, img in enumerate(ranked, 1):
        a = agg[img["id"]]
        tag2 = " [WINNER]" if img["id"] == verdict["winner_id"] else ""
        # Pre-launch route: the incumbent_id slot holds the strongest competitor's
        # file and the config carries "benchmark": "competitor [name]". The card
        # names which claim was made; beating a named rival is not beating your
        # own live image. Without the key the live wording is unchanged.
        bench = cfg.get("benchmark")
        inc_tag = f" [BENCHMARK: {bench}]" if bench else " [CURRENT LISTING]"
        tag2 += inc_tag if img["id"] == cfg.get("incumbent_id") else ""
        _paths = paths_of(img)
        _file = (Path(_paths[0]).name if len(_paths) == 1
                 else f"{len(_paths)} frames: " + ", ".join(Path(x).name for x in _paths))
        lines.append(
            f"| {rank} | {img['id']} ({img['label']}){tag2} "
            f"| {_file} "
            f"| {a['choice_votes']} of {total_choices} "
            f"| {a['ssr_mean']} +/- {a['ssr_std']} | {a['n']} |"
        )
    lines.append("")
    lines.append(
        f"**{verdict['label']}.** Winner: {verdict['winner_id']} "
        f"(`{', '.join(Path(x).name for x in paths_of(next(i for i in ranked if i['id'] == verdict['winner_id'])))}`), preferred by "
        f"{agg[verdict['winner_id']]['choice_votes']} of {total_choices} panelists. "
        f"Holds first place in {stab['holds']:,} of {stab['of']:,} bootstrap resamples; "
        f"the lead flips if {stab['flip_votes']} votes change sides. "
        f"({TIER_MEANING[stab['tier']]})"
    )
    # The count answers "how reliably did they agree on the direction". It cannot
    # answer "by how much", so the magnitude is stated next to it, never instead.
    sentence = magnitude_sentence(verdict)
    if sentence:
        lines.append(sentence)
    lines.append(
        "*How to read this: the count is how RELIABLY the panel agreed on a direction. "
        "Purchase intent is how BIG the difference is. A top tier needs both. "
        f"The +{MIN_INTENT_GAP} bar is provisional and gets refit as real results accumulate.*"
    )
    if models_agree is False:
        lines.append(
            "**THE BASE MODELS DISAGREE on the winner** ("
            + "; ".join(f"{m}: {w}" for m, w in model_winners.items())
            + ") - that is model taste, not shopper signal. NO reliable verdict: keep the objections, drop the counts."
        )
    if "incumbent_id" in verdict:
        bench = cfg.get("benchmark")
        if bench:
            rel = (
                f"BEATS the benchmark ({bench}) by {verdict['winner_vs_incumbent_votes']} votes"
                if verdict["winner_beats_incumbent"]
                else f"does NOT beat the benchmark ({bench}). The benchmark held."
            )
        else:
            rel = (
                f"BEATS the live Amazon image by {verdict['winner_vs_incumbent_votes']} votes"
                if verdict["winner_beats_incumbent"]
                else "does NOT beat the live Amazon image. The incumbent held."
            )
        lines.append(f"**Vs current listing ({verdict['incumbent_id']}):** the top candidate {rel}.")
    # Per-image within-set vote ranking (the strongest / weakest frame story).
    if image_agg:
        lines += ["", "## Strongest frame in each set (within-set vote)", ""]
        for img in ranked:
            rows = image_agg.get(img["id"]) or []
            if not rows:
                continue
            rr = sorted(rows, key=lambda r: (-(r.get("strongest_votes") or 0), (r.get("weakest_votes") or 0)))
            lines.append(f"### {img['id']} ({img['label']})")
            for i, r in enumerate(rr):
                tag2 = "STRONGEST" if i == 0 else ("WEAKEST" if i == len(rr) - 1 else f"#{i + 1}")
                lines.append(
                    # The within-set vote is a forced choice too, so it gets the
                    # same treatment as the main one: a count, never a share.
                    f"- [{tag2}] frame {r['idx']}: picked most convincing by "
                    f"{r.get('strongest_votes', 0)} of {r.get('vote_total', 0)}, "
                    f"{r.get('weakest_votes', 0)} called it weakest"
                    + (f". {r['takeaway']}" if r.get("takeaway") else "")
                )
            lines.append("")

    lines += ["", "## Segments (mean purchase intent)", ""]
    for img in ranked:
        a = agg[img["id"]]
        segs = " | ".join(f"{k}: {v}" for k, v in a["segments"].items())
        lines.append(f"- **{img['id']}**: {segs}")
    lines += ["", "## What the tasters keep saying (ranked objections)", ""]
    for o in themes.get("objections_ranked", []):
        cnt = o.get("count")
        applies = ", ".join(o.get("applies_to") or [])
        lines.append(
            f"- {'(x' + str(cnt) + ') ' if cnt else ''}{o.get('text', '')}"
            + (f" [applies to: {applies}]" if applies else "")
        )
    lines += ["", "### Per-candidate themes", ""]
    for img in ranked:
        t = themes.get("images", {}).get(img["id"], {})
        lines.append(f"**{img['id']}** ({img['label']})")
        lines.append(f"- What worked: {fmt_theme(t.get('strengths'))}")
        lines.append(f"- What hurt: {fmt_theme(t.get('objections'))}")
        lines.append("")
    lines += [
        "## Suggested fixes (apply only if consistent with your research)",
        "",
        "Apply a fix ONLY if it agrees with your research (the selling points and the Improvement Log).",
        "A synthetic objection that contradicts real evidence gets recorded, not acted on. When a fix",
        "is applied, keep the pre-fix original too, so a later test can prove the fix actually helped.",
        "",
    ]
    lines += [f"{i}. {e}" for i, e in enumerate(themes.get("suggested_edits", []), 1)]
    if comparison:
        lines += [
            "",
            f"## Round comparison (vs Round {comparison.get('prev_round') or 'previous'})",
            "",
            "| Candidate | Previous | This round | Delta |",
            "|-----------|----------|------------|-------|",
        ]
        for row in comparison["rows"]:
            if "delta_votes" in row:
                d = row["delta_votes"]
                arrow = "up" if d > 0 else ("down" if d < 0 else "flat")
                lines.append(
                    f"| {row['id']} | {row.get('prev_votes') or 0} votes | "
                    f"{row['votes']} votes | {'+' if d > 0 else ''}{d} votes ({arrow}) |"
                )
            else:
                lines.append(f"| {row['id']} | new this round | {row['votes']} votes | - |")
        if comparison.get("dropped_ids"):
            lines += ["", f"Not in this round: {', '.join(comparison['dropped_ids'])}."]
    lines += [
        "",
        "## How to read this card (house rules)",
        "",
        "- These tasters are language models playing shoppers, not real shoppers. Never quote these",
        "  numbers as customer results.",
        "- The verdict label is standardized by bootstrap resampling the recorded votes: Clear lead",
        "  (holds in >= 95% of resamples), Lean (80-95%), Toss-up (under 80%, or the base models",
        "  disagree). Anything under Clear lead is a lean, not proof.",
        "- A single-model panel carries one shared model taste that can bias the winner; the model mix",
        "  softens this. If the per-model rows disagree on the winner, treat it as NO reliable verdict.",
        "- The most reliable value here is the relative per-image ranking plus the recurring",
        "  objections. Those travel well; the exact counts do not.",
        "- For a real-money decision, a real shopper poll (the optional Pro Move bonus) is the gold",
        "  standard.",
        "",
        "Method: free-text reactions mapped to 1-5 purchase intent via embedding similarity to Likert",
        "anchor statements (SSR, arXiv:2510.08338); forced choice shown per taster in shuffled order;",
        "tasters conditioned on the real buyer demographics.",
    ]
    (out_dir / "tasting-card.md").write_text("\n".join(lines))
    # success -> drop the checkpoint so the next run starts clean (only now:
    # a crash while writing the card must stay resumable)
    try:
        ckpt_path.unlink()
    except FileNotFoundError:
        pass
    print(f"wrote {out_dir}/tasting-card.md and results.json")
    # HANDOFF, not done. run.py renders tasting-card.html in a separate process
    # after this one exits, and that file is what the owner is told to open.
    # Claiming FINISHED here put 100% on the live page while it did not exist.
    prog.handoff("results.json + tasting-card.md written",
                 "rendering the Tasting Card...")
    print(json.dumps({i: {"intent": agg[i]["ssr_mean"], "votes": agg[i]["choice_votes"]} for i in agg}, indent=1))


def cmd_estimate(argv):
    """`panel.py estimate cfg1.json [cfg2.json ...] [lite]`: price a whole
    sitting before anything runs. Exits 1 when the total is over the cap (the
    cap is read from the first config, default $10), with the one question the
    owner is asked. Sends nothing."""
    lite = bool(argv) and argv[-1].lower() == "lite"
    files = argv[:-1] if lite else argv
    if not files:
        print("usage: python3 panel.py estimate <config.json> [<config.json> ...] [lite]")
        return 1
    total, cap = 0.0, None
    for f in files:
        cfg = json.loads(Path(f).read_text())
        if lite:
            cfg["mode"] = "lite"
        cfg = apply_mode(cfg)
        if cap is None:
            cap = float(cfg.get("spend_cap_usd", SPEND_CAP_DEFAULT_USD))
        est = estimate_cost(cfg)
        total += est["usd"]
        print(f"{Path(f).name}: {format_estimate(est['usd'], cap)}")
    ok, line = cap_check(round(total, 2), cap)
    print(f"sitting total: about ${total:.2f} of the ${cap:g} cap ({PRICES_PER_1K_USD['_as_of']})")
    if not ok:
        print(line)
        return 1
    return 0


if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "estimate":
        sys.exit(cmd_estimate(sys.argv[2:]))
    main()

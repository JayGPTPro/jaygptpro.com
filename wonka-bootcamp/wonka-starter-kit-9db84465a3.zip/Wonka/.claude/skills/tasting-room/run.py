#!/usr/bin/env python3
"""Runner for the Tasting Room. Works on macOS, Windows, and Linux.

Usage: python3 run.py <config.json> [lite]
  lite = a quick taste at roughly 1/5 the tasters (1/4 the per-image sample). Faster and coarser; good for
         eyeballing a set or testing the machine. Use the full tasting for
         anything that feeds a real decision.

What it does:
  1. Runs the panel engine (panel.py). On macOS it wraps the run in
     `caffeinate -i` so the laptop cannot fall asleep and kill it mid-way.
  2. Renders the Tasting Card (tasting-card.html) from results.json.

RESUMABLE: the expensive phases checkpoint to <out_dir>/.panel_ckpt.json as
they finish. If the run stops for any reason, run the SAME command again and
it continues from the last checkpoint instead of restarting.
"""

import json
import shutil
import subprocess
import sys
from pathlib import Path


def main():
    if len(sys.argv) < 2:
        print("usage: python3 run.py <config.json> [lite]")
        sys.exit(1)
    cfg_path = Path(sys.argv[1]).resolve()
    mode = sys.argv[2].lower().lstrip("-") if len(sys.argv) > 2 else ""
    # An unrecognised second argument used to fall through to the FULL tasting,
    # which is the expensive one. "lit", "light", "--lite", "fast": all of them
    # quietly bought a full paid race instead of the cheap taste that was asked
    # for. Refuse instead, because a typo must never be a purchase.
    if mode not in ("", "lite", "full"):
        print(f"unknown mode {sys.argv[2]!r}. Use 'lite' for the quick taste, or leave it off "
              "for the full tasting. Nothing ran and nothing was spent.")
        sys.exit(1)
    cfg = json.loads(cfg_path.read_text())
    if "out_dir" not in cfg:
        print(f"{cfg_path.name} has no \"out_dir\" field, so there is nowhere to write "
              "the results. Add it and run again. Nothing ran and nothing was spent.")
        sys.exit(1)
    out_dir = Path(cfg["out_dir"])
    here = Path(__file__).resolve().parent

    # The same estimate line the engine prints, said here first, before the
    # engine process starts: the number the sitting runs on is visible even if
    # the engine's own output scrolls past. The engine re-checks the cap itself
    # and refuses over it; this print never spends and never decides.
    try:
        sys.path.insert(0, str(here))
        from panel import SPEND_CAP_DEFAULT_USD, apply_mode, estimate_cost, format_estimate
        est_cfg = dict(cfg, mode="lite") if mode == "lite" else dict(cfg)
        est = estimate_cost(apply_mode(est_cfg))
        print(format_estimate(est["usd"], float(cfg.get("spend_cap_usd", SPEND_CAP_DEFAULT_USD))), flush=True)
    except Exception as e:  # noqa: BLE001 - a missing package is the engine's message to give, not this one's
        print(f"(no estimate: {str(e)[:80]})", flush=True)

    cmd = [sys.executable, "-u", str(here / "panel.py"), str(cfg_path)]
    if mode == "lite":
        cmd.append("lite")
    if sys.platform == "darwin" and shutil.which("caffeinate"):
        cmd = ["caffeinate", "-i"] + cmd  # keep the Mac awake for the whole run

    print(f"tasting: {cfg_path.name}{' [lite]' if mode == 'lite' else ''} (resumable; if it stops, run the same command again)", flush=True)
    rc = subprocess.call(cmd)
    if rc != 0:
        print("the tasting stopped before finishing. Run the SAME command again; it resumes from the checkpoint.")
        sys.exit(rc)

    subprocess.check_call([sys.executable, str(here / "tasting_card.py"), str(out_dir / "results.json")])
    print(f"done: {out_dir}/tasting-card.html (open it in a browser), tasting-card.md, results.json")


if __name__ == "__main__":
    main()

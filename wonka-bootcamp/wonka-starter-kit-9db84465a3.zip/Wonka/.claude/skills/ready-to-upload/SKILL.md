---
name: ready-to-upload
description: Package the proven winner and the full tested creative set into an upload pack: the complete package (main + secondary gallery + A+ + variations) assembled from the latest edit round into final/ inside the product folder, copied to output/ ready to upload to Amazon, the evidence behind it, the exact upload instructions, and an OPTIONAL Amazon A/B plan for the main image. Gated on a Tasting round having run, on the owner's recorded decision, and on variations being done or explicitly skipped; runs ONLY when the owner invokes it or asks to package in words, never off a Day 8 approval. Use after Day 9, when the owner asks for the package. Triggers: /ready-to-upload, "package the winner", "ready to upload", "ship the package", "stamp it", "put it in output", "how do I upload this", "launch the A/B".
---

# The Shipping Room

| Meta | Value |
|------|-------|
| Room | The Shipping Room |
| Station | PROVE (step 2 of 3) |
| Taught | Day 10, the closing lesson, once the variation slot is either filled by `/variations` on Day 9 or recorded as `Variations: skipped (owner, [date])` (or `n/a`, single SKU). It runs on the owner's invocation only |
| Needs | The latest Tasting Round's main race card (`tests/tasting-r[N]-[date]-main/tasting-card.md`) with a winner, that round's `config.json`, the tested assets on disk, resolved per class (main and gallery from the highest `edits/v[N]/`, or `images/` when no round ran; A+ and variations from the highest `edits/v[N]/` that contains them, else `aplus/` and `variations/`), the current live main image (or, pre-launch, the competitor benchmark the Tasting Room copied into `incumbent/`) as the control. Brand Registry status only if the owner wants the optional A/B |
| Saves to | factory/Products/[product]/tests/upload-pack.md + factory/Products/[product]/final/ (the approved package, inside the product folder) + output/[product-slug]-package/ (a copy of final/) + one row in factory/Improvement Log.md (ONLY if the owner opts into an Amazon A/B) |
| Typical cost | Free, except the upscale in check 3b: the planned finish of any shipping file still carrying `upscale: owed` (reported, then run), and an OFFER on anything else that falls short. A dead Genrupt connection or a missing OpenAI key never closes this room. |

## What this room does

An upload pack is a tested creative package with papers. The Shipping Room checks the gate first (a round ran, the files are the owner's recorded decision, the quality and integrity checks pass), verifies the winning file is the exact one that raced, assembles the whole tested set (the winning main, the secondary gallery in a deliberate order, the A+ modules, the variation imagery when it exists) from the CURRENT set of each class (the highest `edits/v[N]/` snapshot that holds that class, else its originals folder), writes the evidence behind it, writes the upload instructions the owner will actually follow, assembles the lot into `final/` inside the product folder, and copies `final/` to `output/[product-slug]-package/` so the product folder and the handoff folder each hold the complete package. For anyone who wants controlled proof of the main image lift, an Amazon A/B (Manage Your Experiments) is written as an OPTIONAL plan on top.

**The station finishes here.** `/variations` on Day 9 turns the winner into a family, `/improvement-loop` writes all three parts of the Improvement Log and closes the session, and the graduation checklist is a resource the owner reads, not a command this room runs. Re-running this room after `/variations` extends the same pack rather than rewriting it: this room is the ONLY writer of `tests/upload-pack.md`, and `/variations` only records `upscale: owed` for the family, which this room's re-run picks up and finishes. The promise this room delivers is exactly the one the course sells: a full, tested creative package ready to upload, never a sales result.

## The pack is checked for INTERNAL consistency, not only per-file quality

One check that only exists at pack level: **resolution consistency across classes.** Measured 27
August 2026: a variations family shipped at 2048 while the parent hero and gallery stood at 1024,
so a buyer switching children got MORE pixels than the parent listing, backwards. Nothing upstream
plans this, it emerges whenever one class got an upscale another did not. Compare the shipped
resolutions per class, and when they diverge, say so in one line and OFFER the equalizing upscale
with a live-read cost (an offer, never a report, because no approval upstream covers it).

## What this room never does

- **Never uploads anything, never edits a live listing, never launches an experiment.** Wonka prepares the files and the instructions; the human performs the upload in Seller Central. On a listing that belongs to someone else this is absolute, and the bootcamp's on-camera demo listing is exactly that case: the upload and A/B lesson is taught as a procedure, never performed, and never faked with a screen recording.
- **Never opens without a round that ran and a recorded decision**, and never talks a Lean up into a verdict: the owner's pick ships as the owner's decision, labelled as such, and the panel outcome is preserved as it was.
- **Never runs by itself.** A passed Tasting Room gate makes this room AVAILABLE; it never triggers it. The owner's approval of the Day 8 image set (`Owner decision: approve ...`) completes Day 8 and is not a request to package. This room runs when the owner invoked `/ready-to-upload`, asked to package in words, or said yes to Wonka's next-room question ("Variations are done. Ready for the Shipping Room?"), exactly as in every other room, AND `status.md` reads variations as done, `n/a` or `skipped (owner, [date])`. The question is asked only when variations are done or skipped and no stop stands; a yes to it is the ask. Measured 14 September 2026: the owner approved the images, said "We're stopping here" and "Next is Day 9", and the room started packaging. The refusal, when it applies, is one line naming the missing record.
- **Never runs while the owner's explicit stop stands.** A `Next stage:` line as the last entry in `status.md` is the record of a session the owner ended; a new session resumes from it and this room waits for the owner's ask.
- **Never edits, crops, or re-exports a packaged image.** It copies. The tested file ships exactly as tested, or it is not the tested file. The ONE permitted filename change is the gallery slot prefix on the copy (`01-` in front of the original name, which stays intact), and the pack maps every prefixed copy back to its source file. The main image copy keeps its exact filename, because that name is the evidence.
- **Never promises a sales lift, a ranking, or a conversion number.**
- **Never writes a `tasting-room` row into the Improvement Log's experiments ledger.** That row belongs to `/tasting-room`; two rooms writing it double counts the same test. This room writes at most one `amazon-ab` row, and only if the owner opts in.
- **Never mixes files across edit rounds.** Each CLASS has exactly one source, and it is the newest one that exists for that class: main and gallery from the highest `edits/v[N]/` (which by contract holds the complete current set, edited files edited and untouched files copied in as-is), or `images/` when no round ran; A+ and variations from the highest `edits/v[N]/` that contains them, else `aplus/` and `variations/`. Within a class, cherry-picking a file from an older round is how an untested mix ships. Across classes, reading a class from its originals when a round fixed it is how a fix gets silently thrown away.
- **Never deletes anything already sitting in `final/` or `output/`.**

## Before you start

Six checks, in this order. The first two can close the room, so they run before any assembly work.

**0. The stage gate: was this room asked for, and is Day 9 behind us?** Run it before reading any card:

```bash
python3 .claude/skills/ready-to-upload/stage_gate.py "factory/Products/[product]" --ship --invoked
```

Pass `--invoked` when the owner invoked `/ready-to-upload`, asked to package in words ("package it", "ship it", "put it in output"), or answered yes to the next-room question in THIS session. An approval of the images, a passed panel, a `Next room:` note Wonka wrote earlier, or a `Next stage:` line are none of those. The script reads `status.md` and exits 1 with one line naming the missing record when the `Owner decision:` line is absent or withdrawn, when variations are still `pending`, `in progress` or `blocked`, or when the room was not invoked. On exit 1: say that line, name what fills it (write the decision, run `/variations`, or record `Variations: skipped (owner, [date])` on the owner's word, or ask "Ready for the Shipping Room?" once when everything else stands), and stop. Write nothing, copy nothing, ask nothing. No "Proceed?": the owner's ask IS the proceed. Exit 0: continue to check 1.

**1. The gate, and it runs first among the evidence checks.** Read the tasting card in the LATEST `tests/tasting-r[N]-[date]-main/` folder (the MAIN race). If several round folders exist, the highest round number is the gate, and you name that folder out loud so there is no ambiguity about which card is being used. Three conditions, and the label is not one of them:

- (a) a round RAN and its card exists (`config.json`, `results.json`, `tasting-card.md` in that folder), **and**
- (b) the files being packed are the owner's RECORDED decision: the card's winner, or the owner's pick with the decision line present in the round notes and in `status.md` (`Owner decision: ship [files], after [label] on round [N], reason: ...`), **and**
- (c) the image-quality and data-integrity checks pass unchanged: the `/inspect` gates on every packed file, provenance, and the MD5 of each packed file against the round's `config.json` (or, for a file revised after testing, its trail back to that round's notes, check 2). **The main image and every file named on the `Owner decision:` line MUST have a passing scorecard AND must appear in a round's `config.json` (raced) or carry a `revised after test` trail from one. Missing either BLOCKS, with a one-line reason naming the file and what it lacks.** `ungated` is a label only for A+ modules and variations, the files the Tasting Room never races; it is never a label for a main or a decision-line file.

All three true, the room is open, on a Clear lead, a Lean, a Toss-up, a model disagreement or an incumbent win alike. What differs is the LABEL the pack carries, never whether it opens. No card at all fails (a): there is no evidence, so there is no pack, back to `/tasting-room`. A pick with no decision line fails (b): ask the owner for the line in one sentence, write it, continue. A failed check fails (c): route the file (`/fix`, `/inspect`) before packing it.

- **The owner-decision paragraph, and what Day 10 teaches when the panel did not settle it.** A synthetic panel often does not settle the question: the rounds come back Toss-up, or the base models disagree, or the incumbent held, and the honest tiebreaker (the live Amazon A/B on real traffic) needs an owned listing. That is a normal end state, not a failure, and the owner decides. The pack then carries the panel outcome exactly as it was (label, counts, the vs-incumbent line) and, beside it, the owner's decision on its own line, with their reason. Never relabel a Lean or a Toss-up as a win, never fake a Clear lead, and never argue the owner out of their listing. Day 10 still teaches everything it owns: the gallery verdict, the objection ledger, the resolution table, the upload instructions, and the A/B plan written for the day they run this on their own listing, where real shoppers settle the flip for free. On the bootcamp's demo product (a listing the owner does not control) the decision line reads `Owner decision: procedure only, listing not owned` and nothing is uploaded.

- **Pre-launch product with no live incumbent:** the Tasting Room raced the strongest competitor's files (its step 4b) and the winner beat a named rival, not the owner's own live image. The gate is the same three conditions, and the pack records `Control: competitor [name] (pre-launch benchmark)` with one line naming the claim made. `Control: none` is written only when the owner explicitly skipped the competitor race, and then the pack says the verdict is weaker for it.
- **The GALLERY race card (Scenario C) is evidence, never a gate.** Report its set level verdict in the pack. A gallery that lost does not close the room: the pack says so plainly and recommends keeping the live gallery, or uploading only the frames that beat their counterparts per the frame by frame dive.

**2. The winner traces to the exact file that raced.** Name the package source folder first: the highest `edits/v[N]/`, or `images/` when no edit round ran. The card names the winner by id AND by filename (its verdict table carries a File column, and the winner line repeats it). Confirm that filename exists in the source folder, open it once with Read, and confirm the same filename appears in that round's `config.json`, the reproducibility record the Tasting Room saves. Two independent records agreeing is the point; if the card and the config disagree, stop and say so rather than picking one. A neighbouring sibling (the raw `images/main-02.png` packaged in place of the tested `edits/v1/main-02.png` copy, or the other way round) is the classic way an untested image ships. **The MODE B case is lawful and labelled:** when the winner was refined AFTER the round per the tasting notes (the Day 8 design: race, mine the notes, refine), the pack packages the refined copy from the latest `edits/v[N]/`, labels it `revised after test`, names the raced original and its card beside it, and says in one line that the refinements themselves are re-inspected but untasted; a further comparison, when the owner asks for one, is the upgrade for a change big enough to be a different image. What stays forbidden is a SILENT swap: an edit that has no MODE B trail back to that round's notes (a new layout, new casting, a different concept) is a different image, and it does not ship from this room: it races in a comparison the owner asks for, or the raced original ships. A main, or any file named on the `Owner decision:` line, with no passing scorecard, or with neither a config entry in a round nor a `revised after test` trail, BLOCKS the pack with one line naming the file and what it lacks. The pack names which file raced and which file ships, or the pack is wrong.

**3. Inventory the package before writing a word of it. Resolve the source PER CLASS, because a fix round does not touch every class.** The rule is the Fixing Room's own: the current set of a class is the highest `edits/v[N]/` that CONTAINS that class, else that class's originals folder. So main and gallery come from the highest `edits/v[N]/` (or `images/` if no round ran); A+ comes from the highest `edits/v[N]/aplus/` if any round fixed a module, else `aplus/`; variations the same way against `variations/`. Name the resolved folder for each class out loud. **Reading A+ or variations straight from the originals when a fix round touched them silently ships the unfixed version**, and nothing errors, because the originals are exactly where they always were. Then list what exists in each and read the counts back to the owner in one line. Anything missing gets asked about ONCE, per the table below. Nothing is assumed, nothing is invented, and no group is quietly dropped from the manifest.

**3b. Read the real pixel size of every packaged file, and say it out loud.** Amazon opens zoom at 1000 pixels on the longest side and rewards 1600 and up; a listing whose hero does not zoom loses the one interaction that sells a physical product. Nothing upstream guarantees this, because a surgical edit returns the endpoint's working size rather than the source's, so the edited files (the MAIN above all, since MODE B refines the winner by design) are usually the smallest in an otherwise full-resolution set. Measure, never assume:

Run it on the folders check 3 just inventoried, NOT on `final/`: `final/` is assembled in step 14, long after this, so it is empty right now. Pass the package source folder (the highest `edits/v[N]/`, or `images/`) plus `aplus/` and `variations/`:

The zoom thresholds are a LISTING-image rule: the main, the gallery, and the variation mains and swatches. A+ modules are not listing images, never zoom, and carry their own module dimensions, so they are measured and reported but never judged against 1000 or 1600. The script keeps that distinction:

```bash
python3 - <<'PY' "[resolved main+gallery folder]" "[resolved variations folder]" -- "[resolved aplus folder]"
import pathlib, sys
try:
    from PIL import Image
except ImportError:
    raise SystemExit("Pillow not installed. Run: pip3 install pillow")
EXT = {".png", ".jpg", ".jpeg", ".webp"}
args = sys.argv[1:]
cut = args.index("--") if "--" in args else len(args)
groups = [("listing", args[:cut]), ("aplus", args[cut + 1:])]
seen = 0
for kind, roots in groups:
    for root in roots:
        d = pathlib.Path(root)
        if not d.is_dir():
            print(f"(skipped, no such folder: {root})")
            continue
        for p in sorted(q for q in d.rglob("*") if q.suffix.lower() in EXT):
            if p.name.startswith("._"):
                continue  # AppleDouble sidecar, metadata not an image
            try:
                w, h = Image.open(p).size
            except Exception:
                print(f"{p.relative_to(d.parent)!s:44} UNREADABLE, zero-byte or corrupt. "
                      "Fix or remove it before packaging.")
                continue
            if kind == "listing":
                flag = ("  <-- UNDER 1000, zoom will not work" if max(w, h) < 1000
                        else "  <-- under 1600, below Amazon's recommendation" if max(w, h) < 1600
                        else "")
            else:
                flag = "  (A+ module, zoom rules do not apply)"
            print(f"{p.relative_to(d.parent)!s:44} {w}x{h}{flag}")
            seen += 1
print(f"\n{seen} file(s) measured")
PY
```

On Windows, save the block between the PY markers as `measure.py` and run `python measure.py [folders]`; the heredoc form is bash-only. Everything before `--` is judged as a listing image; everything after it is reported only. If it measures 0 files, the paths are wrong: stop and fix them rather than reporting a clean result on an empty scan.

Report the table in the pack. Then act on it, in this order:

- **Anything under 1000 on the longest side** is a BLOCKING line in the pack, named by filename. It ships only if the owner says so after hearing what it costs.
- **Anything under 1600, or noticeably softer than its neighbours,** gets the upscale OFFER, once, with its cost. Do not upscale silently and do not upscale by default: it spends the owner's credits, and the no-silent-spend rule covers it like any other paid run. (A file that already carries a 2048 upscale made on request on Day 5, `main-NN-2048.png` beside `main-NN.png`, is packaged as-is and never upscaled again; files carrying `upscale: owed` are the next bullet's business. The rule: this room owns ALL upscales. No other room upscales, and a file arriving here undersized WITHOUT an `upscale: owed` tag is an unplanned spend, so the owner decides.)
- **Anything carrying `upscale: owed` is not remedial, it is the PLANNED finish, and it runs on report.** The owed list is: every OpenAI-born main tagged `upscale: owed` in the batch log, and every frame of the variation family tagged `upscale: owed` on Day 9 (`variations-plan.md` and the Variations line in `status.md`), reused frames included. The upscale runs ONCE, here, on the files that ship, after every fix and the tasting, so the mains and the family are finished together and land at the same resolution. Report the owed list and its live-read cost in one line, then run it: Genrupt `upscale_image`, model `High Fidelity V3`, factor 2, face enhancement off. Output lands in `final/upscaled/`, the package copies from there, and the tag letters on every result get read back.
- **The cost is read live, for THIS operation on THIS account, and one authorisation covers the run.** Quote the machine's own preview for the chosen operation against the owner's current balance; a per-frame figure written into an earlier status line, a plan or this skill is a forecast, and forecasts have been wrong by half in both directions. Run one frame first when the run is large, read the balance delta, then run the rest; report the measured total at the end. An owed run, or an offered run the owner accepted, is authorised once for its whole list: never re-ask per frame or per batch inside work already authorised, and stop for a fresh go-ahead only if the measured cost turns out materially above the quoted one (the standing spend rule in CLAUDE.md).

- **Say it even when the owner did not ask.** "Your main is 1024 and the rest of the gallery is 2000" is exactly the kind of thing a seller only discovers from a performance report months later. Naming it is the job.

**The upscale, owed or accepted.** It runs on the Genrupt machine (`upscale_image`, `High Fidelity V3`, factor 2, face enhancement off; the same settings for a main, a gallery frame and a variation frame). Find the capability with `search_capabilities` and READ ITS INPUT SCHEMA before calling, the same discipline the Reference Room uses, because the tool's exact name and fields are Genrupt's to change. Two ways in, and the difference decides whether it is even possible:

- A Genrupt-generated image is already on the Genrupt side and is referenced by its own id. This is the easy path.
- A file edited locally through the OpenAI endpoint exists only on this disk. Genrupt needs a reachable HTTPS URL, so it has to be uploaded first, through the same upload path the Reference Room uses for photos. **If that upload path is not available on this connection, say so plainly and stop.** The honest answer is "this file cannot be upscaled from here, and it will ship at [N]px", never a silent skip that leaves the owner believing it was handled.

Save upscaled files NEXT TO the originals (`final/upscaled/`), never over them, and label them `upscaled` in the pack; the package copies to `output/` from `final/upscaled/` for every upscaled file, the upload list names the upscaled file as the one that uploads, and the 1024 original stays as the raced record. A file that already has its `-2048` twin from Day 5 is copied as that twin and skipped here. **The incumbent is never upscaled or enhanced**, in the pack or anywhere else: it is the control, and improving it would be as dishonest as degrading it.

**3c. Inspect every enlarged file against its source before it is packaged.** An upscaler invents detail, and on small printed text it can invent the wrong detail: on one run, two of twenty-six enlarged frames came back with the control-panel lettering changed where the source read correctly. So, for every file the upscale produced, read the regions that carry printed text, logos, labels, badges and fine product detail at native scale, side by side with the same regions of the source file. Not a difference scan, not a thumbnail: the regions, read. The three outcomes, and each is written into the pack:
   - **Clean:** the enlarged file is the source with more pixels. It ships.
   - **Damaged, repaired:** keep the raw enlarged output beside the repair (`[name]-raw.png` or similar, named in the pack), repair the damaged region by whatever route keeps the source's truth (compositing the region back from a plain 2x resample of the source is one method that has worked; a `/fix` region edit against the source is another), then INSPECT the repair the same way before adopting it: the region reads as the source does, and nothing outside the region changed. The pack names the file, the region, the method and the inspection result.
   - **Damaged, not repairable here:** say so, and the source file ships at its own size with its size named in the pack. Never ship an enlarged file whose text or product detail no longer matches the approved source.
   The recorded sizes in the pack's resolution table come from the files that actually ship after this step, not from before it.
**4. Every packaged asset traces to a gate pass. COUNT it, do not eyeball it.** After `final/` is assembled (step 14), run:

    ```bash
    python3 .claude/skills/ready-to-upload/gate_trail.py "factory/Products/[product]"
    ```

    It reads the classes actually in `final/` against the scopes actually in `scorecards/` and prints the gate-trail lines for the pack. An A+ module or a variation with no scorecard is not blocked, it is LABELLED `ungated` with one line on the risk, in the owner's words; those are the files the Tasting Room never races. The main image and every file named on the `Owner decision:` line are different: no passing scorecard, or no round config entry and no `revised after test` trail, BLOCKS the pack with a one-line reason (condition (c)). They are never labelled `ungated` or `untested` and shipped. Amazon does not care about our scorecards; the owner does, and a silent gap in the evidence trail is the one thing this room exists to prevent.

    **Counting is the point, and the reason is a measured failure.** A full ten-day run once shipped a 14-file A+ and a variation that had never been inspected: Day 7 generated the A+ and then went straight to Day 8, skipping the loop half of its own day. The pack carried no gate-trail line at all, so nothing anywhere said the A+ was ungated, and the miss surfaced only when somebody happened to ask whether the faces had been fixed. The rule below was already written. What was missing was a step that cannot be forgotten, and prose is not that step.

**5. Ask the A/B question once, plainly.** When the `Live` row of `status.md` reads `no`, skip the A/B section in one line: there is no traffic to split yet; Amazon's own test is the second opinion after launch. Otherwise: "Do you want the optional Amazon A/B on the main image, or are you uploading it as it stands?" If yes: ask whether the seller has **Brand Registry** (Manage Your Experiments requires it, plus Amazon's own traffic threshold on the ASIN), and check `factory/Improvement Log.md` for a live experiment on this ASIN. **One experiment per ASIN at a time**; a second one waits in the queue and the pack says so. If no, skip every A/B step and write no experiments row. The package is complete either way. The A/B is a proof upgrade, never the finish.

**"I don't have it" is a real answer, and almost always the run proceeds.** What blocks is missing EVIDENCE (the verdict, the tested file), never a missing convenience.

| The owner says | What happens |
|---|---|
| "No A/B, I am just uploading it" | The default and a lawful finish. A/B steps skipped, no experiments row, pack records `A/B: not requested`. Nothing about the finish changes. |
| "No Brand Registry" | Manage Your Experiments is out. The pack carries the swap-with-monitoring fallback instead, labelled weaker evidence in writing. The run proceeds. |
| "It is not my listing" | Nothing is uploaded and no experiment is launched, by anyone. The pack is written as a procedure for the owner's OWN listing and records `A/B: not applicable, listing not owned`. This is the bootcamp demo's own situation, and it is said out loud rather than faked. |
| "I skipped A+" or "no A+ yet" | Declared gap: `A+ modules: not produced (skipped)`. The package ships without them and names exactly what is missing. A declared gap is fine, a silent one is not. |
| "The gallery is not finished" | Package the frames that exist, list the empty slots by name from the brief, record the gap. Partial galleries upload fine; the pack says which slots are still open. |
| `variations/` is empty | Lawful when `status.md` reads `Variations: skipped (owner, [date])` or `n/a (single SKU)`: the pack records the skip in the owner's words and ships without the class. When it reads `pending (Day 9)`, `in progress` or `blocked`, check 0 already closed the room: Day 9 comes first, run `/variations` or record the skip on the owner's word. Re-running this room after a later `/variations` extends the pack. |
| "I cannot find the live image now" | Take it from the round's `config.json`: it raced, so it is on disk at the path recorded there. Only if that path is gone does the control become `not supplied`, recorded as such. |
| "Just ship it, the label says Lean" | The owner's call, and the pack says so. Write the decision line (`Owner decision: ship [files], after Lean on round [N], reason: ...`) in the round notes and in `status.md`, keep the label Lean in the evidence block, and pack. The one refusal is relabelling: a Lean never becomes a win on paper, and the pack never says the panel chose what the owner chose. |
| No answer on the A/B question | Write the pack with `A/B: not requested` and finish. A completed package never sits parked waiting on an optional question. |

## Process

1. **Run the gate and say the result out loud, before anything else.** Name the round folder, the file that ships (the winner, or the owner's pick with its decision line), the label as the panel gave it, and the vs-incumbent result. Gate passed: continue. Gate failed (no round, no decision line, a check failing): stop here, name the failed condition and what fills it (run the round, write the line, fix the file), write nothing, and copy nothing.

2. **Main pre-flight on the winner. Wonka's own check, one line of output.** Open the winning file and check four things: white background with the product filling most of the frame; no added text, badge, watermark or border (props, contents, the approved hang tag and lawful people stay); every part of the product present and countable; nothing promised beyond what ships. Then say the result in one line and write it in the pack: `main pre-flight: pass` or `main pre-flight: [what fails], fix before upload`. No explanation of why, no policy talk.

   A fail does NOT ship as the main. Route it: added text or a drawn badge goes to `/fix` (a prop leaves only on the owner's word); background, crop, layout, or composition goes back to `/main-image` for a regeneration. A beautiful image that misses the main slot can still earn a place in the gallery; say so rather than losing the work. The backup on disk is the swap-in if the main ever comes down; that is the whole risk line, said once.

3. **Assemble the evidence block.** The winner's filename and one line on what the image is. The control (the current live main image). The numbers from every round that ran (one sitting is the default; a second appears only if the owner asked for one): shares, panel size, date, stability label, and the vs-incumbent result each time. The top recurring notes and objections from the cards. When a gallery race ran, its set level verdict too. Then label the evidence honestly, in the file and out loud: a directional verdict from an AI taster panel (SSR method), not real shopper data, with the real shopper poll named as the gold standard upgrade for real money decisions.

4. **Write the hypothesis, then set the metric.** One sentence, causal and falsifiable, built from what the tasters actually said and never from taste: "the new main image lifts CTR because tasters said they could count all four tiers and judge the height at thumbnail size." Then the metric: a MAIN image test watches **CTR**, because the main image's only job is winning the click; a gallery or A+ test watches **CVR**, because those assets work after the click. State which one applies and why. Judging a main image by conversion is how good images get killed.

5. **Decide the gallery order and write the reason for it.** The gallery is uploaded in the order the owner chooses, so choose it deliberately. When a Scenario C card exists, the frame by frame dive names which frame carries the set: that one leads. Otherwise the brief's order stands. Number the slots `01` to `NN` and give each a one line reason. The copies carry the number as a prefix in front of the original filename (`01-sec-03.png`), so the order survives the handoff to a VA, a designer, or the owner's own future self, and the pack maps every slot back to its source file.

6. **Cross check the A+ against the winning angle.** Read `aplus/aplus-plan.md` and the modules against the angle the tasters rewarded. Three honest outcomes, and the pack records which one: **aligned** (say in one line why, usually because the same research drove both), **out of step** (name the modules now arguing the losing angle and route them back to `/aplus` BEFORE the pack ships, or, if the owner chooses to ship anyway, record it as a declared gap in writing), or **no A+ produced** (declared gap). An A+ page never faces an A/B the way a main image does. That does not exempt it from the verdict.

7. **Assemble the full package list, with counts.** Every file in the tested set, grouped: MAIN, GALLERY (in slot order), A+ MODULES, VARIATIONS. Every class comes from the source resolved in check 3: main and gallery from the package source folder, A+ from `edits/v[N]/aplus/` when a round fixed a module and `aplus/` otherwise, variations the same way. Name the folder each group came from. Each entry is the exact filename plus a one line description, and each group carries a count. Those counts are what step 14 reconciles against, so they are the manifest, not decoration. Missing groups appear as a declared gap line, never as an absence. **The VARIATIONS group carries two lines of its own.** First, the `assumed` claims: every truth-table value `variations/variations-plan.md` marks `assumed` and every `SHIP (assumed: ...)` verdict on the variations scorecard is copied into the pack as `assumed`, NOT verified, with its child and frame (`gate_trail.py` surfaces `assumed` as an open issue for the same reason); the pack never re-labels one verified, and the owner sources it from the child's listing or removes it from the frame before that file uploads. Second, the A+ for the children: the plan's shared-versus-per-child map says which modules a child may reuse, and when the plan records none the line reads `A+ for [child]: not classified`, because the parent's A+ is never handed to a child by default.

8. **Write the upload instructions. These are always written, A/B or no A/B.** This is the "ready to upload" the room is named for:
   1. **Main and gallery:** Seller Central, edit the listing, images tab. Slot one is the main. The rest fill the gallery in the numbered order from step 5.
   2. **The main slot:** the packaged main, with its pre-flight line from step 2 (`main pre-flight: pass`). The backup on disk is the swap-in if the main ever comes down.
   2b. **Name the exact file that uploads, by path, for every slot.** When a class was enlarged, the 2048 file in `upscaled/` is the upload and the 1024 file in `gallery/` (or `main/`, `variations/`) is the raced or inspected record, kept for evidence. The instructions say which is which by filename, per slot, so a VA or the owner's future self never uploads the record instead of the delivery. Challengers, page views, raw enlarger output, concepts and anything marked `superseded` are named as NOT for upload. Selecting a whole folder is never the instruction.
   3. **A+ content** goes in through A+ Content Manager, which requires Brand Registry. Build, attach the ASINs, submit, and it queues for review. Rejections are usually about claims, so every comparison row stays provable.
   4. **Variations** are uploaded against the parent or child ASINs per the variation plan (Day 9's variation map fills this line).
   5. **Size matters, and it is measured, not assumed.** Amazon opens zoom at 1000 pixels on the longest side and rewards 1600 and up. Quote each packaged file's real size from check 3b, name anything that falls short by filename, and say which files were upscaled if any were. Zoom is what a shopper uses instead of holding the product.
   6. **Upload copies, keep the originals.** The factory's files stay where they are.
   7. **If you intend to measure anything, change one thing at a time.** A listing that changed in four places at once produces a number nobody can attribute.
   8. **Held assets, when there are any.** Every upload blocker from the "Upload readiness" sort gets its own line here: the asset by path, the word HOLD, and what removes the hold. The rest of the list stands as written; the instructions never say "upload everything" while a HOLD line exists, and never carry a HOLD line for an informational note.

--- Steps 9 to 12 run ONLY if the owner opted into the optional Amazon A/B in check 5. If not, or if the `Live` row of `status.md` reads `no` (no traffic to split yet), go to step 13. ---

9. **The launch walkthrough (Brand Registry path, Manage Your Experiments):**
   1. Seller Central > Brands > Manage Your Experiments.
   2. Create a new experiment, experiment type Main Image (or A+ Content / Title as relevant).
   3. Select the ASIN. Amazon checks eligibility on the spot; the ASIN needs enough traffic to reach significance, and Amazon says so on this screen if it does not.
   4. The current live image stays Version A. The winner goes in as Version B. Nothing else on the listing changes during the test.
   5. Name the experiment (use the pack name), set the duration, and put the step 4 hypothesis in the hypothesis field. A hypothesis you cannot be wrong about is not a hypothesis.
   6. **Duration: run to significance, typically 8 to 10 weeks.** Choose 10 with "end early if a winner is found" when offered. **No peeking and no stopping early**: early leads flip, and a stopped test proves nothing.
   7. Launch, then paste the start date back so the pack and the Improvement Log carry it.

10. **No Brand Registry: the honest fallback.** A straight swap with before and after monitoring:
    1. Record a few weeks of baseline from Business Reports (Detail Page Sales and Traffic: sessions, unit session percentage, and impressions where available).
    2. Swap the main image to the winner.
    3. Watch the same report over the same span after.

    Then say it plainly, and write it in the pack: this is WEAKER evidence than a real A/B. There is no control group, and seasonality, price changes, ads, and competitors all move the same numbers. It answers "did things get better", never "did the image cause it". Record `method: swap_with_monitoring`.

11. **Append the experiment row** to `factory/Improvement Log.md` (create the file with the canonical header if it is missing). One NEW row in the canonical 8 column schema, and no other column set:

    `| Date | Product | Type | Candidates | Winner | Margin | Key why | Status |`

    Type `amazon-ab`, Status `planned`, flipping to `running` once the owner confirms the experiment started in Seller Central. This is the row `/improvement-loop` closes when the verdict lands (and the one a `/factory-report`, if the owner ever runs one, reads as an open experiment). Never add a second row for the tasting itself; `/tasting-room` already wrote that one.

12. **Set the follow up.** Name the date to come back with results, and say that `/improvement-loop` runs on the outcome either way, win or lose. A lost A/B is an Improvement Log entry, not a failure.

--- End of the optional A/B steps. ---

13. **Write the pack** to `tests/upload-pack.md` in the Output format below: the gate line, the winner, the full package list with counts, the control, the evidence, the gallery order, the A+ alignment result, the upload instructions, any declared gaps, and the A/B plan only if the owner opted in.

14. **Assemble `final/`, copy it to `output/`, then reconcile both file by file.** Copy (never move, never re-export, never rename beyond the gallery slot prefix) from the package source folder into `final/` INSIDE the product folder, then copy the assembled `final/` to `output/[product-slug]-package/`: `variations/concepts/` is never copied into `final/`.

    ```
    factory/Products/[product]/final/
    ├── upload-pack.md
    ├── main/[the exact winning filename]
    │   └── challengers/[rank]-[filename]-[votes]votes.png   (the other candidates that raced)
    ├── gallery/01-[...].png, 02-[...].png, ...
    ├── aplus/[module files]
    │   ├── aplus-page-desktop.jpg + aplus-page-mobile.jpg    (the page as a shopper reads it)
    │   └── aplus-order-desktop.jpg + aplus-order-mobile.jpg  (the same page, upload order marked)
    └── variations/   (filled by Day 9's /variations run, or a written none on a single SKU)

    output/[product-slug]-package/    (an exact copy of final/, same layout)
    ```

    ```bash
    # from the kit root (Mac and Linux; on Windows use copy/xcopy or the file tools)
    mkdir -p "factory/Products/[product]/final"/{main/challengers,gallery,aplus,variations}
    cp "factory/Products/[product]/edits/v[N]/[winner].png" "factory/Products/[product]/final/main/"
    # ... gallery (with the 01- prefix on the copy), aplus, variations ...
    # the A+ page views, built from the module files that just landed:
    python3 .claude/skills/aplus/aplus_page.py "factory/Products/[product]/final/aplus"
    mkdir -p "output/[product-slug]-package"
    cp -R "factory/Products/[product]/final/." "output/[product-slug]-package/"
    ```

    **`main/challengers/` is not a bonus folder, it is the next experiment.** The
    room ships ONE main because Amazon's Manage Your Experiments compares exactly
    two versions: what is live now against one challenger. But the race that
    picked the winner also produced 3 to 5 other candidates on deliberately
    different tactics, and burying them in `images/` means the owner's second
    test starts from scratch months later, with a cold Improvement Log and no
    memory of what the tasters said. So every candidate that RACED is copied
    here, named with its finishing rank and its vote count, and the pack names
    the runner-up as the queued next challenger. One at a time, never two at
    once: a second experiment on the same ASIN waits for the first to finish.
    Not live yet (the `Live` row of `status.md` reads `no`)? The queue is written and the Seller Central steps are skipped in one line: there is no traffic to split yet.

    **The A+ page views are built, not exported.** Genrupt cuts ONE continuous
    design into modules, so the seams fall mid sentence and mid image and a
    folder of `m1..m7` tells a human nothing about what the page looks like or
    which module goes first. `aplus_page.py` stacks them back into the page and
    into a numbered order sheet. Neither is uploaded to Amazon: the cut module
    files are the upload, these two are how the owner sees the work and follows
    the order. Build them from `final/aplus/` AFTER the modules land there, so
    the page shows exactly the files being shipped.

    Then reconcile TWICE, and report both out loud. First **list `final/` back and reconcile it against the manifest from step 7**, group by group, count by count: main 1 of 1, gallery N of N, A+ N of N, variations pending. Second **list `output/[product-slug]-package/` back and reconcile it against `final/`**: every file in `final/` landed, same names, same counts, **and the same bytes** (compare a checksum per file, `md5` or `shasum`; equal counts alone have hidden a stale copy before). If a file did not land in either folder, or a copy differs from its original, say which one and fix it before the room is called done. A pack that claims a file a folder does not hold is worse than no pack. Re-runs overwrite the pack and re-copy the current package into BOTH folders; anything already in `final/` or `output/` that is no longer part of the package stays on disk and is named `superseded` in the pack, never deleted. **Any zip offered beside the folder is built from `final/` AFTER the last change to it**, and rebuilt whenever a file in `final/` changes later (a repair, a metadata tag), so the folder, the copy, the zip and the instructions always describe the same bytes.

14b. **Amazon's AI-person disclosure tag, as export preparation.** Amazon's current instruction (checked 15 September 2026, and re-read at run time because it can change): listing and A+ images that show a photorealistic AI-generated person carry the keyword `contains-synthetic-performer` in the file's XMP metadata, field `dc:subject`. It is a metadata field, nothing visible on the image, and nothing in Seller Central substitutes for it. The kit ships a dependency-free tool for it:

    ```bash
    python3 .claude/skills/ready-to-upload/xmp_tag.py tag    [final files that apply]
    python3 .claude/skills/ready-to-upload/xmp_tag.py verify [the same files, and their copies]
    ```

    - **Applicability is the owner's call, made against Amazon's own scope, per file.** Wonka lists the final files that show a person (the casting is a structured field, so the cast frames are known; hands and partial figures are named separately as the ambiguous cases), points the owner at the current official text, and asks ONCE which files the disclosure applies to. Wonka never decides scope for the owner, never invents a face-only rule, and never tags every file "to be safe". The owner's answer is recorded in the pack, with the date and the source read.
    - **Tag the FINAL files, after the last conversion.** An enlargement, a re-export or a format conversion can drop metadata, so the tag goes onto the exact files that upload (the enlarged ones where those are the upload) and onto nothing earlier in the chain. The tool refuses to change a pixel: it copies the image data byte for byte and verifies that before writing, and existing metadata in the file survives.
    - **Verify, then refresh every copy.** Run `verify` on the tagged files in `final/`, then re-copy them to `output/[product-slug]-package/`, run `verify` on the copies too, and rebuild the zip if one exists. The pack records the verify line per file. A file the tool reports as `UNSUPPORTED` (a format other than PNG or JPEG) is named in the pack as untagged, with the fix (convert it to PNG or JPEG first, then tag the converted file), never silently skipped.
    - **The demo listing.** On the bootcamp's demo product nothing is uploaded, so the step is taught, run on the packaged files the owner names, and its result recorded; it is never faked as a completed Amazon upload.

15. **Close out honestly, delivery first, and in the state the pack records.** Lead with the delivery and anything that needs the owner's decision: the exact main that uploads, the gallery in order, the A+ modules, the variation sets, each as full-size files or an opened folder, then the open items in one short list, sorted as the "Upload readiness" section below sorts them: the upload blockers first, each with its asset and what remains (an `assumed` claim to source or remove, a disclosure tag the owner said applies but is not yet verified, a file under 1000 px the owner has not chosen to ship), then the informational notes (an unclassified child A+, a flagged frame the owner chose to keep, a frame labelled `ungated`, a skip recorded in writing). Say plainly whether an A/B was launched and, if not, why not. Make no promise about sales: the course's promise is a package promise. **The closing sentence matches the `Upload readiness` line of the pack**: a ready package is called ready and the owner is told to follow the upload list; a package with upload blockers is called assembled, the held assets are named, and no sentence tells the owner to upload everything. Then say that `/improvement-loop` is how this run's lessons get saved, when the owner is ready, and stop. The chat carries the decisions; the source traces, checksums and measurements live in the pack on disk, not in the closing message.

## Upload readiness (the one sort every line of the pack agrees with)

The package being ASSEMBLED and the package being READY TO UPLOAD are two different facts, and the pack records both. Assembled means `final/` and `output/` hold the reconciled set. Ready means nothing in the pack holds an asset back. Every disclosed item lands in exactly one of two lists, and the summary, the `## Status` block, the upload instructions, `status.md` and the closing sentence all read from the same sort:

- **Upload blockers** hold ONE named asset each, and the pack says what removes the hold. Three kinds: an `assumed` claim carried on a frame (source it from that child's listing or remove it from the frame); a disclosure tag the owner said applies to a file that is not yet tagged and verified (run `xmp_tag.py tag` then `verify`, refresh the copy); a listing file under 1000 px on its longest side that the owner has not explicitly chosen to ship (upscale it here, or the owner says ship). A main that fails pre-flight never reaches this list because it never ships as the main (step 2). Every other asset in the package uploads while a blocked one waits; a blocker holds its asset, never the package.
- **Informational notes** hold nothing back and are still written: a frame labelled `ungated` with its risk line, a child A+ `not classified`, a flagged frame the owner chose to keep, a file under 1600 px after a declined upscale offer, a skip recorded in the owner's words, an A+ shipped out of step as a declared gap on the owner's decision, an enlargement that could not be repaired so the source ships at its own size.
- **Writing a blocker down does not resolve it.** The blocker stays in the pack, in the upload instructions and in `status.md` until the fix lands and the pack is re-run or amended with the fix named. A re-run that clears a blocker rewrites all three places in the same pass.
- **Not every disclosed limitation is a blocker.** The list above is closed: an item not on it is informational. Never promote a note to a blocker to look careful, and never demote a blocker to a note to call the package ready.

## Output format

`tests/upload-pack.md`:

```markdown
# Upload Pack . [Product Name] . [YYYY-MM-DD]

Built from: tests/tasting-r[N]-[date]-main/tasting-card.md (round [N], main race), [tasting-r1 card],
[scorecard files], brief/creative-brief.md, the live listing

## Gate
- Round used: tests/tasting-r[N]-[date]-main/ . panel winner [exact filename], label [Clear lead / Lean / Toss-up / no reliable verdict], [beat the incumbent x votes to y / the incumbent held]
- Decision: [the panel winner ships / Owner decision: ship [files], after [label] on round [N], reason: ...]
- Gate: PASSED (round ran, decision recorded, quality and integrity checks pass)

## The winning main image
- Package source: [edits/v[N]/ (highest edit round) / images/ (no edit rounds ran)]
- File: [source folder]/[exact filename] (verified on disk and against that round's config.json)
- What it is: [one line, e.g. main image, the four tier fountain on pure white, all four tiers visible]
- Amazon main slot pre-flight: [PASS / FAIL + what was fixed]

## The full tested package
- MAIN (1): [source folder]/[winning filename]
- MAIN CHALLENGERS (N): every other candidate that raced, ranked, in `main/challengers/`.
  Next A/B challenger: [runner-up filename] ([votes] votes, [tactic]). Test it against the
  winner only after the first experiment finishes; one per ASIN at a time.
- A+ PAGE VIEWS (2 per mode): aplus-page-[mode].jpg (the page as read) and
  aplus-order-[mode].jpg (upload order). Reference only, never uploaded.
- GALLERY ([N], in upload order): 01 [file] . [role]; 02 [file] . [role]; ...
- A+ MODULES ([N]): aplus/[files]
- VARIATIONS ([N] / skipped (owner, [date]) / n-a): variations/[files]
- Assumed claims carried from Day 9: [none / "[claim]" ([child], [frame]), from variations-plan.md and the variations scorecard: NOT verified, source it or remove it before that file uploads]
- A+ for the children: [per variations-plan.md: [module] shared / per child / excluded / not classified: the parent's A+ is not handed to the children]
- Gate trail: [N of N assets have a scorecard / listed ungated: [files]]

## Resolution (measured, check 3b)
Amazon opens zoom at 1000px on the longest side and rewards 1600+. A+ modules carry their own
module dimensions and are reported without the zoom judgement.

| File | Pixels | Verdict |
|---|---|---|
| [main filename] | [WxH] | [ok / under 1600 / UNDER 1000, blocking] |
| [gallery file] | [WxH] | [ok] |
| aplus/[file] | [WxH] | A+ module, zoom rules do not apply |

- Below the floor: [none / [files], named to the owner as blocking, shipped only on their explicit say-so]
- Upscale: [not needed / done on Day 5 on request: [file]-2048, packaged as-is / run as the planned finish on [files] (owed: mains and the variation family), saved to final/upscaled/, labelled `upscaled` / offered at [cost] and declined / run on [files] after the offer, saved to final/upscaled/, labelled `upscaled`]
- The incumbent was NOT upscaled or enhanced. It is the control.

## Gallery order and why
- 01 [file]: [one line reason, e.g. named strongest frame in the Scenario C frame by frame]
- 02 [file]: [reason]

## A+ alignment with the winning angle
- [Aligned: [one line why] / Out of step: [modules], realigned via /aplus before packaging / Shipped as is (declared gap) / No A+ produced (declared gap)]

## The control
- The current live Amazon main image, the incumbent beaten in Tasting Round [N] (and in the earlier round, if two ran) (or the competitor benchmark on the pre-launch route)
- [or: Control: competitor [name] (pre-launch benchmark). The claim made is beating a named rival, not the owner's own live image.]
- [or, only when the owner explicitly skipped the competitor race: Control: none. The verdict is weaker for it.]

## Evidence
- Tasting Round 1 [date], main race: winner [x] votes to incumbent [y] (or the competitor benchmark on the pre-launch route), panel of [tasters], [label]
- [only if a second sitting ran] Tasting Round [N] [date], main race: winner [x] votes, challenger [y], incumbent [z], panel of [tasters], [label]
- Gallery race (Scenario C, when run): proposed gallery [x] votes to live gallery [y], panel of [tasters], [label], round [N]
- Taster reasons: [top 2 recurring notes, one line each, with mention counts]
- Nature of evidence: directional verdict from an AI taster panel (SSR method), not real shopper data.
  A real shopper poll (PickFu, ProductPinion, or any panel) is the gold standard upgrade for
  real money decisions. Not run unless the owner chose to.

## How to upload this package
1. Seller Central, edit the listing, images tab. Slot one is the main; the gallery follows in the numbered order above.
2. Main slot: the packaged main. main pre-flight: [pass / what fails, fix before upload]. The backup on disk is the swap-in if the main ever comes down.
3. A+ through A+ Content Manager (requires Brand Registry). Attach the ASINs, submit, wait for review. Keep every comparison row provable.
4. Variations against the parent or child ASINs per the variation plan.
5. Upload copies. The factory keeps the originals.
6. If you intend to measure anything, change one thing at a time.
7. Held assets: [none / HOLD [path]: [what removes the hold] ... one line per upload blocker]
- Who uploads: the owner. Wonka prepares the files and the instructions and performs no upload.

## Enlargement check (step 3c)
- [file]: clean, read against its source at native scale
- [file]: damaged at [region], repaired by [method], raw output kept as [name], repair inspected: [region reads as source, 0 pixels changed outside it]
- [file]: damaged, not repairable here; the source ships at [W x H]

## AI-person disclosure metadata (step 14b)
- Source read: [Amazon's current instruction, date read]
- Applies to (owner's call, [date]): [files] / none of the packaged files show a photorealistic AI-generated person / owner has not decided yet
- Tagged and verified: [file: VERIFIED] ... ; copies in output/ verified; zip rebuilt [yes / no zip]
- Untagged: [file: UNSUPPORTED format, convert to PNG or JPEG and re-run] / none

## Declared gaps (the long form of the Informational notes line above; the same items, never new ones)
- [e.g. Variations: skipped (owner, [date]), in the owner's words. Re-run /ready-to-upload after a later /variations to extend this pack.]
- [e.g. A+ modules: not produced (skipped). Package ships without them.]
- [none]

## Optional A/B (only if the owner opted in)
- Hypothesis: the new main image lifts CTR because [specific taster backed reason].
- Metric: [CTR (main image test) / CVR (gallery or A+ test)], measured by [Manage Your Experiments / Business Reports before and after]
- Method: [Manage Your Experiments / swap_with_monitoring (no Brand Registry: weaker evidence, no control group)]
- Steps: [the numbered walkthrough, ASIN filled in]
- Duration: [8 to 10 weeks, run to significance, no early stopping]
- Queue check: [no other experiment running on this ASIN / QUEUED behind experiment X]

## Status
- Package: assembled and reconciled. In final/ and copied to output/[product-slug]-package/ on [date].
- Upload readiness: [ready: no asset is held, follow the upload list / assembled with upload blockers: [asset]: [what remains]; [asset]: [what remains]. Every other asset uploads as listed]
- Informational notes (do not hold any asset): [none / ungated: [files] / A+ for [child] not classified / [file] kept at [W x H] after the upscale offer was declined / variations skipped (owner, [date]) / ...]
- Reconciliation: final/ main 1/1, gallery [N]/[N], A+ [N]/[N], variations [pending]; output/ matches final/ file for file.
- A/B: [not requested / not applicable, listing not owned / pending launch / launched YYYY-MM-DD, results expected ~YYYY-MM-DD]
- No result is promised anywhere in this pack. The promise is a tested, assembled package with its open items named.
```

Row appended to `factory/Improvement Log.md` ONLY if the owner opted into the A/B (canonical 8 column schema `| Date | Product | Type | Candidates | Winner | Margin | Key why | Status |`):

```markdown
| [YYYY-MM-DD] | [product] | amazon-ab | 2 ([winner file] vs incumbent) | | | | planned |
```

Status flips to `running` once the owner confirms the experiment started in Seller Central. No A/B means no row from this room, and this room never writes a `tasting-room` row.

## Golden Standards check

Before presenting, verify:
- [ ] `stage_gate.py --ship --invoked` ran BEFORE anything else and exited 0: the owner invoked this room, asked to package in words, or said yes to the next-room question in this session, the `Owner decision:` line stands, and variations read done, `n/a` or `skipped (owner, [date])`. An exit 1 was reported as its one line and the room stopped with nothing written.
- [ ] The gate ran FIRST among the evidence checks and was reported out loud: round folder named, the file that ships is the panel winner or the owner's recorded decision (`Owner decision:` line present), the checks passed. The label was carried as the panel gave it and never talked up; an owner's pick ships as the owner's decision.
- [ ] The package source folder was named out loud (the highest `edits/v[N]/`, or `images/` when no edit round ran) and every main and gallery file came from that one folder. No cross-round mixing.
- [ ] The winning filename was verified on disk with Read, in the package source folder, AND against that round's `config.json`. No sibling file substituted. A MODE B refinement packaged after the race is labelled `revised after test` with the raced original named beside it; nothing untested is stamped as tested.
- [ ] The main pre-flight ran on the packaged main and its one-line result is in the pack (`main pre-flight: pass`, or the fail named). A fail was routed to `/fix` or `/main-image`, never packaged, and no policy lecture was given.
- [ ] The full package is listed with counts (main + gallery in order + A+ + variations), each an exact filename, and every missing group appears as a DECLARED gap, never as a silent absence. Every `assumed` claim from Day 9 is in the pack as assumed, none re-labelled verified, and the children's A+ line follows the plan's classification or reads `not classified`.
- [ ] `gate_trail.py` was RUN on the assembled `final/`, and its output is in the pack. Every packaged asset traces to a scorecard, or is labelled `ungated` with its risk line. **And tracing is not passing:** any scorecard the script flags as recording open issues (DEGRADED, FAIL, UNSCORED, defects left unfixed) is named out loud in the pack, in one line per class, so nothing ships looking certified because a card merely EXISTS. Measured 27 August 2026: a 26-of-26 trace covered an A+ whose own card recorded a wrong count, a garbled bullet and two unsupported claims.
- [ ] Every packaged file's real pixel size was MEASURED and reported. Every file tagged `upscale: owed` (mains and the variation family) was upscaled here on report, once, into `final/upscaled/`; anything else under 1600 got the upscale offer with its cost, once; a Day 5 `-2048` twin was packaged as-is. Anything under 1000 on the longest side is named as blocking. No file was upscaled silently, and the incumbent was not touched.
- [ ] Every enlarged file was read against its source at native scale in the text, logo and detail regions (step 3c); any repair kept the raw output beside it and was inspected before adoption; the pack's sizes are the sizes of the files that ship.
- [ ] The upload instructions name the exact file that uploads per slot, by path, and name the records, challengers, page views and raw outputs as not for upload.
- [ ] Every open item was sorted by the "Upload readiness" section into a blocker (one asset, what removes the hold) or an informational note, and the `Upload readiness` line, the Held assets line, the PROVE line in `status.md` and the closing sentence all say the same thing. No "upload it as it stands" while an asset is held; no held asset invented from a note.
- [ ] The AI-person disclosure step ran (14b): the owner decided applicability against Amazon's current text, the applicable FINAL files were tagged and verified after the last conversion, the copies in `output/` verified, any zip rebuilt, and any unsupported file named as untagged with its fix. Nothing was tagged on Wonka's guess.
- [ ] `output/` was reconciled against `final/` by name AND checksum, not by count alone.
- [ ] The gallery order is deliberate and each slot carries a one line reason (the Scenario C frame by frame leads when it exists).
- [ ] The A+ was cross checked against the winning angle and the result recorded (aligned / realigned / declared gap / none).
- [ ] Upload instructions are in the pack, always, A/B or no A/B, and they say the owner uploads and Wonka does not.
- [ ] Evidence is labelled as a directional AI taster panel verdict, never real shopper data, with the real poll named as the gold standard upgrade.
- [ ] The A/B section is clearly OPTIONAL and the finish does not depend on it. Nothing was uploaded, no experiment was launched, and no listing belonging to someone else was touched.
- [ ] No promise of sales, rank, or conversion anywhere.
- [ ] If the owner opted into the A/B: the hypothesis cites a taster backed reason, the metric matches the asset type (CTR for main, CVR for gallery or A+), duration says 8 to 10 weeks with no peek and stop, the one-experiment-per-ASIN queue was checked, any no-Brand-Registry fallback is labelled weaker evidence, and exactly one `amazon-ab` row was appended in the canonical 8 column schema.
- [ ] The package was ASSEMBLED into `final/` inside the product folder, COPIED to `output/[product-slug]-package/`, and reconciled file by file TWICE: `final/` against the manifest, then `output/` against `final/`, with both counts reported. Nothing in `final/` or `output/` was deleted, the main kept its exact filename, and the only filename change is the gallery slot prefix, mapped back to its source in the pack.
- [ ] English only, zero em or en dashes.

## Wonka lines

Openers:
- "The Shipping Room. Very few candies make it this far, so let us stamp this one properly."
- "Gate first, papers second. I check the verdict before I touch a single file."
- "A winner with a hundred witnesses. Now we give it papers, a folder, and instructions a stranger could follow."

Closers:
- On a ready package: "Stamped. The whole package sits in final/, with a matching copy in output/, in order, with the reasoning attached. Nothing is held; follow the upload list as it stands."
- On a package with upload blockers: "Assembled and reconciled, in final/ and output/. Two files are held, and the pack says why and what clears each: [asset], [asset]. Everything else uploads as listed."
- "Tasted, refined, packaged once. The A/B is optional and it is yours to run. I do not touch listings; I hand you the files and the steps."
- "The label read Lean. That is a hint, not a verdict. You decided, I wrote the decision down as yours, and the pack says exactly that."
- "Variations skipped on your word, and the pack says so. If a family ever appears, come back and I will extend this pack rather than rewrite it."

Refusals (one line, then stop):
- "Not yet. Your approval closed Day 8; Day 9 is variations. Run /variations, or tell me to skip them, and then ask me to package."
- "You ended the session on a Next stage line. I resume there when you say so; the Shipping Room waits for your ask."

## When it goes wrong

- **The card says Lean or Toss-up.** The owner decides. Their options, said once: name changes from the objections and re-inspect; keep the live set; or ship their pick with the decision line recorded. A further comparison is theirs to ask for when it answers a concrete question; it is never required.
- **The incumbent won.** A downgrade to a working listing was just avoided for the price of lunch. Mine the notes for WHY it holds (a free teardown of a proven image), keep that read in the test file for `/improvement-loop`, and build the next candidates from it.
- **The base models disagreed on the winner.** No reliable verdict. Use the objections, drop the counts; the owner decides, and a decision to ship is recorded as theirs with the label kept as it was.
- **The winning file is not in the package source folder, or its name does not match `config.json`.** Stop. Do not package a lookalike. Find the tested file, or re-run the round on the files that exist.
- **An edit round ran after the tasting and touched the winner.** If it is the MODE B refinement driven by that round's notes (the Day 8 design), package it labelled `revised after test`, with the raced original and its card named beside it. If the edit has no MODE B trail to the notes, that is a different image: it ships only as the owner's recorded decision, labelled untested, or in a comparison the owner asks for, or the raced original from the round's `config.json` path ships. Never stamp a silent swap with a tested verdict.
- **The main passed the panel but misses the main slot.** Route it: added text or a drawn badge to `/fix`; background, crop, or layout to `/main-image`. Then re-check. Consider keeping the rejected version as a gallery frame instead of losing the work.
- **`final/` or `output/` already holds an older package.** Re-copy over the same folders. Nothing is deleted; anything no longer in the package is named `superseded` in the pack.
- **A second product arrives, whenever the owner brings one.** It runs every gate; it gets its own `final/` inside its own product folder and its own `output/[product-slug]-package/` folder. Packages never share a folder.

## Definition of Done

- The stage gate passed on the owner's ask: this room was invoked, packaging asked for in words, or the next-room question answered yes in this session, after variations were done or skipped in writing. A Day 8 approval alone never opened it.
- The gate was checked FIRST against the latest round's main race card (round ran, files are the owner's recorded decision, checks pass), and its result was stated out loud before any assembly.
- `tests/upload-pack.md` exists and contains: the gate line, the verified winning filename, the full package list with counts, the gallery order with reasons, the A+ alignment result, the control, the evidence of every round that actually ran (one sitting is the bootcamp default; a second is optional and appears only when it ran) with honest labelling, the upload instructions, declared gaps, the `Upload readiness` line with its blockers and notes sorted, and the optional A/B plan only if the owner opted in.
- `final/main/challengers/` holds every OTHER candidate from the main race, named by rank and votes, and the pack names the runner-up as the queued next A/B challenger.
- `final/aplus/` holds `aplus-page-[mode].jpg` and `aplus-order-[mode].jpg` beside the module files, built by `aplus_page.py` from the modules actually shipped.
- `factory/Products/[product]/final/` exists with `upload-pack.md` plus `main/`, `gallery/`, `aplus/`, and `variations/`, assembled from the package source folder (the highest `edits/v[N]/`, or `images/` when no edit round ran), and `output/[product-slug]-package/` exists as its copy. Both were RECONCILED file by file: `final/` against the manifest and `output/` against `final/`, counts reported. Nothing was moved, edited, or deleted, and the only filename change is the gallery slot prefix.
- If the owner opted into an A/B: exactly one `amazon-ab` row exists in `factory/Improvement Log.md` (canonical 8 column schema, Status `planned` or `running`), and the owner has the exact Seller Central steps, or the honest fallback, plus a date to return with results.
- Every enlarged file was inspected against its source (step 3c) and the pack records the outcome per file; the AI-person disclosure step (14b) ran on the owner's applicability call, with the verify line per tagged file and its copy.
- The owner knows the station finishes here, that the package is assembled with no promise about the result, that it is ready to upload OR which assets are held and why (the same state the pack, the upload list and `status.md` record), that they are the one who uploads, and that `/improvement-loop` saves this run's lessons when they are ready. No report and no further room was appended to the close.
- The summary, the `## Status` block, the upload instructions (its Held assets line), the `status.md` PROVE line and the closing sentence all name the same readiness state and the same held assets. One of them disagreeing with the others is a bug in the pack.

## Update status.md

Set PROVE from the pack's `Upload readiness` line, keeping the `done:` keyword that the status readers parse:

- `done: package ready to upload` when no asset is held.
- `done: assembled, upload blockers: [asset]: [what remains]; [asset]: [what remains]` when one or more assets are held. The blockers are listed inline, on the same line, because a `done` beside a caveat three screens lower reads as a pass (CLAUDE.md, the status rule). When a later run clears them, rewrite the line to `done: package ready to upload` in the same pass that amends the pack.
- `in progress: A/B pending` only if the owner opted into and launched an A/B; the readiness state then goes into the Log line instead.

`tests/upload-pack.md` is the artifact in every case. Keep the INVENT sub-status line `Variations: skipped (owner, [date])` (or `n/a`) as the owner recorded it. Add a Log line: `[date] Upload pack issued: gate passed on tasting-r[N] ([file that ships], [label][, owner decision]), full package assembled in final/ from [edits/v[N] / images], copied to output/[product-slug]-package/ and reconciled both ways. Upload readiness: [ready / blockers: [assets]]. A/B [not requested / not applicable, listing not owned / launched / pending launch / queued].`

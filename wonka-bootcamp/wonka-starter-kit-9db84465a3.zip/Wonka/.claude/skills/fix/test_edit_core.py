"""edit_core.py: a fix renders from the clean base, at the frame's own size, and never stacks.
Run: python3 test_edit_core.py

The OpenAI client is the one true external edge and is faked here; everything else (the lineage,
the anchor choice, the sizing, the composite, the gate, the migration) runs for real on files
built in a temp folder."""
import base64
import io
import os
import sys
import tempfile
from pathlib import Path

import numpy as np
from PIL import Image, ImageFilter

HERE = Path(__file__).parent
sys.path.insert(0, str(HERE))
import edit_core as ec  # noqa: E402

fails = []
def check(name, cond):
    print(("  PASS  " if cond else "  FAIL  ") + name)
    if not cond:
        fails.append(name)


def photo(size=(320, 240), seed=1):
    w, h = size
    img = Image.new("RGB", size); px = img.load()
    for y in range(h):
        for x in range(w):
            c = 40 if ((x // 9) + (y // 9)) % 2 else 200
            px[x, y] = ((x * 3 + seed) % 256, (c + y // 2) % 256, (x + y * 2 + seed * 5) % 256)
    return img


class FakeClient:
    """Returns what it was sent, with the core of the editable area painted red, at the size asked."""
    def __init__(self, transform=None):
        self.calls, self.transform, self.images = [], transform, self
    def edit(self, **kw):
        self.calls.append(kw)
        first = kw["image"][0] if isinstance(kw["image"], list) else kw["image"]
        first.seek(0); im = Image.open(first).convert("RGB")
        w, h = (int(v) for v in kw["size"].split("x"))
        out = im.copy()
        if "mask" in kw:
            kw["mask"].seek(0)
            a = Image.open(kw["mask"]).getchannel("A")
            core = a.point(lambda v: 255 if v == 0 else 0).filter(ImageFilter.MinFilter(33))
            out = Image.composite(Image.new("RGB", im.size, (255, 0, 0)), im, core)
        if out.size != (w, h):
            out = out.resize((w, h))
        if self.transform:
            out = self.transform(out)
        buf = io.BytesIO(); out.save(buf, format="PNG")
        class D: b64_json = base64.b64encode(buf.getvalue()).decode()
        class R: data = [D()]
        return R()


def outside_same(a, b, boxes):
    A, B = np.asarray(a.convert("RGB")).astype(int), np.asarray(b.convert("RGB")).astype(int)
    m = np.zeros(A.shape[:2], bool)
    for x, y, w, h in boxes: m[y:y + h, x:x + w] = True
    return int((np.abs(A - B).sum(2)[~m] > 0).sum()) == 0


os.environ.pop("WONKA_DEPTH_GATE", None); os.environ.pop("WONKA_DEPTH_UNKNOWN", None)
os.environ["WONKA_IMAGE_MODEL"] = "test-model"

with tempfile.TemporaryDirectory() as d:
    root = Path(d) / "factory" / "Products" / "demo"
    (root / "images").mkdir(parents=True); (root / "edits" / "v1").mkdir(parents=True)

    # --- hashes
    im = photo(); a = root / "images" / "sec-01.png"; im.save(a)
    b = root / "edits" / "v1" / "sec-01.png"; im.save(b)
    j = root / "images" / "lossy.jpg"; im.save(j, quality=95)
    check("pixel hash survives a copy into the next round", ec.pixel_hash(Image.open(a)) == ec.pixel_hash(Image.open(b)))
    check("pixel hash differs after a lossy save", ec.pixel_hash(Image.open(a)) != ec.pixel_hash(Image.open(j)))
    check("the lineage lives in the product's edits folder", ec.Lineage(b).path == (root / "edits" / "lineage.jsonl").resolve())

    # --- sizes
    info = ec.native_api_size(1000, 800)
    check("a frame inside the limit goes at its own size, padded to 16", tuple(info["send"]) == (1008, 800) and info["scale"] == 1.0)
    check("a 4096 square is downscaled to 2160", tuple(ec.native_api_size(4096, 4096)["send"]) == (2160, 2160))
    try:
        ec.native_api_size(4000, 1000); check("a 4:1 frame is refused", False)
    except ValueError:
        check("a 4:1 frame is refused", True)
    try:
        ec.restore_from_api(Image.new("RGB", (256, 256)), ec.native_api_size(512, 512)); check("a wrong returned size raises", False)
    except ValueError:
        check("a wrong returned size raises", True)

    # --- first fix: no lineage yet -> registered as the clean base with a note (a student is never stuck)
    fake = FakeClient()
    out1 = root / "edits" / "v1" / "sec-01.png"
    rec1 = ec.run_edit(a, out1, "fix A", [(20, 20, 60, 60)], client=fake)
    kw = fake.calls[0]
    check("sent at the frame's own size as png", kw["size"] == "320x240" and kw["output_format"] == "png" and kw["model"] == "test-model")
    r = Image.open(out1).convert("RGB").load()
    check("the fix landed", r[50, 50] == (255, 0, 0))
    check("every pixel outside the box is the target's own", outside_same(Image.open(a), Image.open(out1), [(20, 20, 60, 60)]))
    lin = ec.Lineage(out1)
    check("the unknown file was registered, then the edit recorded at depth 1",
          [x["op"] for x in lin.records] == ["register", "edit"] and rec1["boxes"][-1]["depth"] == 1 and rec1["boxes"][-1]["box"] == [20, 20, 60, 60])

    # --- second fix on disjoint pixels edits the current file (depth 0 there)
    (root / "edits" / "v2").mkdir()
    out2 = root / "edits" / "v2" / "sec-01.png"
    ec.run_edit(out1, out2, "fix B", [(200, 100, 60, 60)], client=fake)
    r = Image.open(out2).convert("RGB").load()
    check("a disjoint second fix keeps the first", r[50, 50] == (255, 0, 0) and r[230, 130] == (255, 0, 0))
    check("only two calls so far", len(fake.calls) == 2)

    # --- third fix overlapping the first: refused until the instruction covers the earlier fix
    (root / "edits" / "v3").mkdir()
    out3 = root / "edits" / "v3" / "sec-01.png"
    try:
        ec.run_edit(out2, out3, "fix C", [(60, 60, 40, 40)], client=fake); check("overlap without --covers-earlier is refused", False)
    except SystemExit as e:
        check("overlap without --covers-earlier is refused, naming the earlier instruction", "fix A" in str(e) and "Nothing spent" in str(e))
    check("the refusal spent nothing", len(fake.calls) == 2 and not out3.exists())
    rec3 = ec.run_edit(out2, out3, "fix A and fix C together", [(60, 60, 40, 40)], covers=True, client=fake)
    sent = fake.calls[2]["image"]; sent.seek(0)
    check("the model was shown the clean base, not the edited target", Image.open(sent).convert("RGB").tobytes() == Image.open(a).convert("RGB").tobytes())
    mk = fake.calls[2]["mask"]; mk.seek(0); alpha = Image.open(mk).getchannel("A").load()
    check("the editable area is the union of A and C, and B's box is frozen", alpha[25, 25] == 0 and alpha[95, 95] == 0 and alpha[230, 130] == 255)
    r = Image.open(out3).convert("RGB").load()
    check("fix B survived: the render was pasted onto the target", r[230, 130] == (255, 0, 0) and r[50, 50] == (255, 0, 0))
    check("depth never rose above one", max(x["depth"] for x in rec3["boxes"]) == 1 and rec3["anchor"] == ec.pixel_hash(Image.open(a)))

    # --- override: allowed with a reason, recorded as depth 2
    (root / "edits" / "v4").mkdir()
    out4 = root / "edits" / "v4" / "sec-01.png"
    rec4 = ec.run_edit(out3, out4, "on top", [(60, 60, 40, 40)], override="owner asked for a third version", client=fake)
    sent = fake.calls[3]["image"]; sent.seek(0)
    check("an override edits the target itself and records depth 2",
          Image.open(sent).convert("RGB").tobytes() == Image.open(out3).convert("RGB").tobytes() and max(x["depth"] for x in rec4["boxes"]) == 2
          and any(x["op"] == "override_depth" for x in ec.Lineage(out4).records))

    # --- wrong returned size: refused, nothing written
    bad = FakeClient(transform=lambda im: im.resize((im.size[0] // 2, im.size[1] // 2)))
    out5 = root / "edits" / "v4" / "sec-02.png"
    photo(seed=3).save(root / "images" / "sec-02.png")
    try:
        ec.run_edit(root / "images" / "sec-02.png", out5, "x", [(20, 20, 60, 60)], client=bad); check("a wrong size is refused", False)
    except SystemExit as e:
        check("a wrong size is refused and nothing written", "returned" in str(e) and not out5.exists())

    # --- the gate: a smeared render warns (installed with the numbers) and blocks in block mode
    smear = FakeClient(transform=lambda im: im.filter(ImageFilter.GaussianBlur(4)))
    big = photo((640, 480), seed=5); bp = root / "images" / "sec-03.png"; big.save(bp)
    (root / "edits" / "v5").mkdir()
    out6 = root / "edits" / "v5" / "sec-03.png"
    ec.thresholds = lambda: {**ec.DEFAULT_THRESHOLDS, "seam_band_max": 999.0}   # the fake smears the seam band too; test the ring gate alone
    rec6 = ec.run_edit(bp, out6, "darken", [(40, 40, 80, 80)], gate="warn", client=smear)
    check("warn mode installs the file and records the finding", out6.exists() and rec6["findings"] and rec6["gate"]["retention"] < 0.75)
    out7 = root / "edits" / "v5" / "sec-03b.png"
    try:
        ec.run_edit(out6, out7, "again", [(300, 300, 80, 80)], gate="block", client=smear); check("block mode refuses a smeared render", False)
    except SystemExit as e:
        check("block mode refuses a smeared render and keeps the evidence", "GATE (block)" in str(e) and not out7.exists() and (root / "edits" / "v5" / "sec-03b-render.png").exists())
    ec.thresholds = lambda: dict(ec.DEFAULT_THRESHOLDS)

    # --- window mode: native pixels around the box, back one to one
    wide = photo((1000, 800), seed=7); wp = root / "images" / "sec-04.png"; wide.save(wp)
    fw = FakeClient()
    out8 = root / "edits" / "v5" / "sec-04.png"
    rec8 = ec.run_edit(wp, out8, "fix the logo", [(700, 600, 60, 40)], window=True, client=fw)
    w, h = (int(v) for v in fw.calls[0]["size"].split("x"))
    check("a window smaller than the frame, edges a multiple of 16", w % 16 == 0 and h % 16 == 0 and w < 1000 and h < 800 and rec8["window"] is not None)
    check("the window holds the box and stays inside the frame", rec8["window"][0] <= 700 and 760 <= rec8["window"][0] + rec8["window"][2] <= 1000)
    check("outside the box the frame is untouched after a window edit", outside_same(wide, Image.open(out8), [(700, 600, 60, 40)]))

    # --- migration on a product that predates the lineage: images + three rounds, one real fix
    prod = Path(d) / "factory" / "Products" / "old"
    (prod / "images").mkdir(parents=True)
    orig = photo(seed=11); orig.save(prod / "images" / "main-07.png")
    other = photo(seed=12); other.save(prod / "images" / "sec-02.png")
    for n in (1, 2, 3):
        rd = prod / "edits" / f"v{n}"; rd.mkdir(parents=True)
        orig.save(rd / "main-07.png")
        if n == 2:
            fixed = other.copy(); fixed.paste((255, 0, 0), (10, 10, 40, 40)); fixed.save(rd / "sec-02.png")
        elif n == 3:
            Image.open(prod / "edits" / "v2" / "sec-02.png").save(rd / "sec-02.png")
        else:
            other.save(rd / "sec-02.png")
    orig.save(prod / "edits" / "v3" / "main-07-rejected.png")
    s = ec.migrate(prod)
    lin = ec.Lineage(prod)
    fixed_sha = ec.pixel_hash(Image.open(prod / "edits" / "v2" / "sec-02.png"))
    check("migration: two anchors, one fix, the copies counted as copies", s["anchors"] == 2 and s["fixes"] == 1 and s["copies"] >= 4)
    check("migration: the fix is depth 1 from the original, whole frame", lin.depth_in(fixed_sha, []) == 1 and lin.latest(fixed_sha)["anchor"] == ec.pixel_hash(other))
    check("migration: the untouched file stays depth 0", lin.depth_in(ec.pixel_hash(orig), []) == 0)
    s2 = ec.migrate(prod)
    check("migration is idempotent", s2["anchors"] == 0 and s2["fixes"] == 0)
    check("migration skips evidence files", not any("rejected" in (r.get("file") or "") for r in lin.records))

    # --- refusals that must be sentences, never tracebacks
    up = root / "images" / "main-13-2048.png"; photo(seed=21).save(up)
    ec._cli(["register", str(up), "--origin", "upscale", "--from", str(a)])
    try:
        ec.run_edit(up, root / "edits" / "v5" / "main-13-2048.png", "x", [(20, 20, 60, 60)], client=FakeClient()); check("an upscale is refused as an edit base", False)
    except SystemExit as e:
        check("an upscale is refused as an edit base, with the way out", "never the base" in str(e) and "Nothing spent" in str(e))
    try:
        ec.run_edit(root / "images" / "missing.png", root / "edits" / "v5" / "missing.png", "x", [(20, 20, 60, 60)], client=FakeClient()); check("a missing source is a sentence", False)
    except SystemExit as e:
        check("a missing source is a sentence", "no such file" in str(e))
    check("a made-up origin is refused", ec._cli(["register", str(a), "--origin", "genrupp"]) == 2)
    check("show on a missing file is a sentence", ec._cli(["show", str(root / "nope.png")]) == 2)
    wrong = root / "images" / "wrong-anchor.png"; photo(seed=33).save(wrong)
    try:
        ec.run_edit(out2, root / "edits" / "v5" / "sec-01.png", "fix A and C", [(60, 60, 40, 40)], covers=True, anchor_path=str(wrong), client=FakeClient()); check("a wrong --anchor file is refused", False)
    except SystemExit as e:
        check("a wrong --anchor file is refused by its pixels", "does not hold the clean base" in str(e))

print()
print("ALL PASS" if not fails else f"{len(fails)} FAILED: " + ", ".join(fails))
sys.exit(1 if fails else 0)

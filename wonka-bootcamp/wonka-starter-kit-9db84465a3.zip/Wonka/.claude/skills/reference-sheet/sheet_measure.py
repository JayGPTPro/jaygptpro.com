#!/usr/bin/env python3
"""Measure a sheet or a frame against the anatomy contract: is this the real product?

The Fixing Room's drift gate (edit_core.py) asks whether an image degraded against ITSELF.
This asks whether it matches the PRODUCT, which is a per-product question: a knife has a
blade-to-handle ratio, three windows and three rivets; a bowl has a rim-to-base ratio. So the
contract names which RECIPES apply and what the real photos measured, and this script runs
them on a sheet or a frame and prints PASS/FAIL rows plus a strip with the landmarks drawn.
Every length is a percentage of the product's overall extent along its main axis, so a sheet
at any scale compares directly with targets measured on real photos.

Recipes (all mechanical, all assuming a light even background and the product roughly
aligned with the axis; the contract says which panel box holds the product):
  extent            the product's span along the axis (the 0..100 scale) and its height
  dark_start        first column past `from_frac` dominated by dark pixels (a handle, a base)
  enclosed_regions  count and extents of enclosed near-background regions (windows, holes)
  bright_blobs      bright blobs inside the dark part, as fractions of that part (rivets, studs)
  height_at         product height at a fraction of its length (a blade's depth, a taper)
  texture           band-pass blotch ratio of a surface box against a real photo's crop

What this is NOT: universal. A product whose landmarks fit none of these gets the second
look (the Reference Room, step 4a) and the eye; the script says "no recipe" and stops.
Region counting and the texture row need scipy (`pip install scipy`); without it those rows
say so and the rest still run.

Usage:
  sheet_measure.py <contract.json> <image.png> [--panel x0,y0,x1,y1 (fractions)] [--out dir] [--json]
Contract shape: see contract-example.json beside this script. Exit 0 = every gated row inside tolerance.
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw


def runs(mask):
    out, start = [], None
    for i, v in enumerate(mask):
        if v and start is None:
            start = i
        elif not v and start is not None:
            out.append((start, i - 1)); start = None
    if start is not None:
        out.append((start, len(mask) - 1))
    return out


def load_panel(path, panel):
    im = Image.open(path).convert("L")
    w, h = im.size
    x0, y0, x1, y1 = panel
    box = (int(x0 * w), int(y0 * h), int(x1 * w), int(y1 * h))
    a = np.asarray(im.crop(box)).astype(int)
    return a, box


def measure(contract: dict, image_path, panel=None, out_dir=None):
    fid = contract.get("fidelity") or {}
    panel = tuple(panel or fid.get("panel_box") or (0, 0, 1, 1))
    axis = fid.get("axis", "horizontal")
    a, box = load_panel(image_path, panel)
    if axis == "vertical":
        a = a.T
    bg = float(np.median(np.concatenate([a[:6, :].ravel(), a[-6:, :].ravel()])))
    fg = np.abs(a - bg) > fid.get("fg_threshold", 22)
    cols = np.where(fg.sum(0) > 3)[0]
    if len(cols) < 10:
        return False, {"error": {"sheet": None, "real": None, "ok": False, "note": "no product found in the panel"}}
    x0, x1 = int(cols.min()), int(cols.max())
    L = float(x1 - x0)
    pct = lambda x: (x - x0) / L * 100
    rows = {}
    ok = True
    strict = np.abs(a - bg) > fid.get("strict_threshold", 45)
    top = np.full(a.shape[1], -1); bot = np.full(a.shape[1], -1)
    for x in range(x0, x1 + 1):
        ys = np.where(fg[:, x])[0]; yb = np.where(strict[:, x])[0]
        if len(ys): top[x] = ys.min()
        if len(yb): bot[x] = yb.max()
    marks = []
    dark_start = None

    for lm in fid.get("landmarks", []):
        name, recipe, p = lm["name"], lm["recipe"], lm.get("params", {})
        gated = "target" in lm or "target_count" in lm or "target_fracs" in lm
        row = {"sheet": None, "real": lm.get("target", lm.get("target_count", lm.get("target_fracs"))), "tol": lm.get("tol"), "ok": True, "gated": gated}
        try:
            if recipe == "extent":
                hmax = int(max(bot[x] - top[x] for x in range(x0, x1 + 1) if top[x] >= 0 and bot[x] >= 0))
                row["sheet"] = round(hmax / L * 100, 1)
            elif recipe == "dark_start":
                dark = (a < p.get("threshold", 75)).sum(0)
                ref_col = int(x0 + p.get("ref_frac", 0.8) * L)
                cands = [x for x in range(int(x0 + p.get("from_frac", 0.4) * L), x1 + 1) if dark[x] > p.get("share", 0.35) * max(1, dark[ref_col])]
                if not cands:
                    raise ValueError("no dark part found")
                dark_start = min(cands)
                row["sheet"] = round(pct(dark_start), 1); marks.append(("v", dark_start, name))
            elif recipe == "enclosed_regions":
                try:
                    from scipy import ndimage
                except ImportError:
                    raise ValueError("region counting needs scipy (pip install scipy); count the windows by eye")
                nearbg = np.abs(a - bg) < p.get("bg_tolerance", 7)
                lab, n = ndimage.label(nearbg)
                border = set(np.unique(np.concatenate([lab[0], lab[-1], lab[:, 0], lab[:, -1]])))
                wins = []
                limit = dark_start if dark_start is not None else x1
                for i, sl in enumerate(ndimage.find_objects(lab), start=1):
                    if i in border or sl is None:
                        continue
                    ys, xs = sl
                    w_, h_ = xs.stop - xs.start, ys.stop - ys.start
                    area = int((lab[sl] == i).sum())
                    # a region that runs INTO the dark part is a shadow pocket, not a window (the knife, v9 on)
                    if w_ > p.get("min_w_frac", 0.04) * L and h_ > p.get("min_h_frac", 0.02) * L and xs.stop - 1 < limit and area > 0.35 * w_ * h_:
                        wins.append((area, xs.start, xs.stop - 1))
                # count what qualifies: regions at least `min_area_rel` of the largest one (a
                # window is a window-sized hole; a reflection or a prong slot is not), trimmed to
                # the largest N only when the contract says so (params.count), never to the target,
                # or a fourth window could not fail
                if wins:
                    biggest = max(a_ for a_, _, _ in wins)
                    wins = [w for w in wins if w[0] >= p.get("min_area_rel", 0.3) * biggest]
                k = int(p["count"]) if "count" in p else len(wins)
                wins = sorted([(s_, e_) for _, s_, e_ in sorted(wins, reverse=True)[:k]])
                fid["_regions"] = wins
                row["sheet"] = len(wins)
                for s_, e_ in wins:
                    marks.append(("v", s_, "")); marks.append(("v", e_, ""))
                if "target_count" in lm:
                    row["ok"] = len(wins) == int(lm["target_count"])
            elif recipe == "enclosed_region_edge":
                wins = fid.get("_regions") or []
                i = int(p.get("index", 0)); edge = p.get("edge", "start")
                if i >= len(wins):
                    raise ValueError("region index out of range (run enclosed_regions first)")
                row["sheet"] = round(pct(wins[i][0] if edge == "start" else wins[i][1]), 1)
            elif recipe == "bright_blobs":
                if dark_start is None:
                    raise ValueError("bright_blobs needs a dark_start landmark before it")
                bright = np.zeros(a.shape[1], bool)
                for x in range(dark_start + 5, x1 - 5):
                    if top[x] < 0 or bot[x] < 0:
                        continue
                    seg = a[top[x]:bot[x] + 1, x]
                    mid = seg[int(len(seg) * 0.2):int(len(seg) * 0.8)]
                    bright[x] = (mid > p.get("threshold", 170)).sum() > 3
                rv = [r for r in runs(bright) if r[1] - r[0] > p.get("min_len_frac", 0.008) * L and r[1] < x1 - 0.03 * L]
                wl = max(1, x1 - dark_start)
                fr = [round(((r[0] + r[1]) / 2 - dark_start) / wl, 3) for r in rv]
                row["sheet"] = fr
                for r in rv:
                    marks.append(("v", (r[0] + r[1]) // 2, ""))
                if "target_fracs" in lm:
                    tf = lm["target_fracs"]; tol = lm.get("tol", 0.03)
                    row["ok"] = len(fr) == len(tf) and all(abs(x - y) <= tol for x, y in zip(fr, tf))
            elif recipe == "height_at":
                xq = int(x0 + p["at_frac"] * L)
                if top[xq] < 0 or bot[xq] < 0:
                    raise ValueError("no product at that fraction")
                row["sheet"] = round((bot[xq] - top[xq]) / L * 100, 2); marks.append(("v", xq, name))
            else:
                raise ValueError(f"no recipe {recipe!r}")
            if "target" in lm and row["sheet"] is not None and not isinstance(row["sheet"], list):
                row["ok"] = abs(row["sheet"] - float(lm["target"])) <= float(lm.get("tol", 0))
        except Exception as e:
            row["ok"] = False; row["note"] = f"{type(e).__name__}: {e}"
        if gated:
            ok = ok and row["ok"]
        rows[name] = row

    tex = fid.get("texture")
    if tex and tex.get("real_crop"):
        try:
            rows["texture"] = texture_ratio(image_path, tex, Path(image_path).parent)
            if tex.get("max_ratio") is not None and rows["texture"]["sheet"] is not None:
                rows["texture"]["ok"] = rows["texture"]["sheet"] <= float(tex["max_ratio"])
                ok = ok and rows["texture"]["ok"]
        except Exception as e:
            rows["texture"] = {"sheet": None, "real": None, "ok": False, "note": f"{type(e).__name__}: {e}", "gated": True}
            ok = False

    if out_dir:
        strip(image_path, box, axis, x0, x1, marks, Path(out_dir) / (Path(image_path).stem + "-landmarks.png"))
    return ok, rows


def texture_ratio(image_path, tex, base_dir):
    """Band-pass (sigma 1.5 minus sigma 6) std on the flat part of the sheet's surface box
    against the same measure on a real photo's crop, both resampled so the box is `grid` wide.
    A ratio above ~1.5 means the finish broke up (the knife: hammered foil against brushed steel).
    Real photos under hard light score high on their own, so the contract chooses a matched crop."""
    try:
        from scipy import ndimage as nd
    except ImportError:
        raise ValueError("the texture row needs scipy (pip install scipy); judge the finish at 3x")
    def prep(path, box, grid=600):
        im = Image.open(path).convert("L"); w, h = im.size
        x0, y0, x1, y1 = (int(box[0] * w), int(box[1] * h), int(box[2] * w), int(box[3] * h))
        crop = im.crop((x0, y0, x1, y1)); s = grid / max(1, crop.size[0])
        g = np.asarray(crop.resize((grid, max(8, int(crop.size[1] * s))), Image.LANCZOS)).astype(float)
        gm = nd.gaussian_filter(np.hypot(*np.gradient(nd.gaussian_filter(g, 1.0))), 3.0)   # flat at low frequency, so grain does not speckle the mask
        flat = nd.binary_erosion(gm < np.percentile(gm, 50), iterations=4)
        bp = nd.gaussian_filter(g, 1.5) - nd.gaussian_filter(g, 6)
        return float(bp[flat].std()) if flat.sum() > 200 else None
    real_path = Path(tex["real_crop"])
    if not real_path.is_absolute():
        real_path = Path(base_dir) / real_path
    s_val = prep(image_path, tex["surface_box"]); r_val = prep(real_path, tex.get("real_box", tex["surface_box"]))
    ratio = round(s_val / r_val, 3) if (s_val and r_val) else None
    return {"sheet": ratio, "real": 1.0, "tol": tex.get("max_ratio"), "ok": True, "gated": tex.get("max_ratio") is not None,
            "note": f"sheet bp {s_val and round(s_val, 3)}, real bp {r_val and round(r_val, 3)}"}


def strip(image_path, box, axis, x0, x1, marks, out_path):
    im = Image.open(image_path).convert("RGB").crop(box)
    d = ImageDraw.Draw(im)
    W, H = im.size
    for kind, pos, label in marks:
        if axis == "vertical":
            d.line([(0, pos), (W, pos)], fill=(220, 30, 30), width=2)
            if label: d.text((4, pos + 2), label, fill=(220, 30, 30))
        else:
            d.line([(pos, 0), (pos, H)], fill=(220, 30, 30), width=2)
            if label: d.text((pos + 3, 4), label, fill=(220, 30, 30))
    for pos, label in ((x0, "0%"), (x1, "100%")):
        if axis == "vertical":
            d.line([(0, pos), (W, pos)], fill=(30, 90, 220), width=2)
        else:
            d.line([(pos, 0), (pos, H)], fill=(30, 90, 220), width=2)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    im.save(out_path)
    return out_path


def main(argv):
    if len(argv) < 2:
        print(__doc__); return 2
    contract = json.loads(Path(argv[0]).read_text())
    image = argv[1]
    panel, out_dir, as_json = None, None, False
    i = 2
    while i < len(argv):
        if argv[i] == "--panel": panel = tuple(float(v) for v in argv[i + 1].split(",")); i += 2
        elif argv[i] == "--out": out_dir = argv[i + 1]; i += 2
        elif argv[i] == "--json": as_json = True; i += 1
        else: i += 1
    if not (contract.get("fidelity") or {}).get("landmarks") and not (contract.get("fidelity") or {}).get("texture"):
        print("the contract has no `fidelity` section (landmarks or texture): nothing to measure mechanically; "
              "the second look (Reference Room step 4a) and the eye decide"); return 2
    ok, rows = measure(contract, image, panel, out_dir)
    if as_json:
        print(json.dumps({"ok": ok, "rows": rows}, indent=1))
    else:
        for k, r in rows.items():
            tag = "PASS" if r.get("ok") else "FAIL"
            if not r.get("gated", True):
                tag = "INFO"
            print(f"{tag}  {k:22s} sheet {r.get('sheet')!s:>10}  real {r.get('real')!s:>8}  {r.get('note', '')}")
        print("VERDICT:", "PASS" if ok else "FAIL")
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))

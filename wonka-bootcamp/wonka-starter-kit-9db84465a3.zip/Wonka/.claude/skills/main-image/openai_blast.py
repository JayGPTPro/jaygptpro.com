#!/usr/bin/env python3
"""
The OpenAI Blast engine for the Main Image Room (Path B of the dual blast).

Wonka authors prompts.json; this script runs the pool and builds the pick sheets.
It is deliberately dumb: no retries beyond one attempt, no prompt editing, no
decisions. Resume is free: re-running skips every pool file already on disk.

Usage:
    python3 openai_blast.py run   prompts.json OUT_DIR   # generate the pool
    python3 openai_blast.py sheet OUT_DIR                # build pick sheets (20 tiles each)

prompts.json:
    {"product": "...", "refs": ["path1.jpg", ...], "images": [
        {"number": 1, "tier": "t1-pure", "variation": 1, "prompt": "..."}, ...]}

Pool filename contract (canonical, never improvise a different one):
    pool-NNN_TIER_vV.png           e.g. pool-107_t2-tag_v3.png
    Pool numbers live at 101 and up (prompt number + 100), so an OpenAI candidate never
    shares a number with a Genrupt-born main-NN, and a promoted pick KEEPS its number
    (pool-130 becomes main-130). One image, one number, all day (Jay, 6 September 2026).
The printed id on the sheet is the NUMBER "NN", big, and that is how the owner names a pick.

Env: OPENAI_API_KEY (loaded from ./.env if unset), QUALITY (default low),
WORKERS (default 6), SIZE (default 1024x1024), WONKA_IMAGE_MODEL (default gpt-image-2.5-sunburst,
also read from ./.env).
"""
import base64
import json
import os
import sys


def image_model():
    """The image model this factory runs on: WONKA_IMAGE_MODEL in the environment, else that
    line in the nearest .env upward (the Factory root is where /machines-check put it), else
    the house default. One setting, every machine (kit v51, 17 September 2026). The parser
    forgives what people type into a .env: a BOM, spaces around =, an export prefix, a
    trailing comment, CRLF, a stray non-UTF-8 byte."""
    m = os.environ.get("WONKA_IMAGE_MODEL", "").strip()
    if m:
        return m
    here = os.path.abspath(os.getcwd())
    while True:
        p = os.path.join(here, ".env")
        try:
            with open(p, encoding="utf-8", errors="ignore") as f:
                for line in f:
                    s = line.lstrip("\ufeff").strip()
                    if s.startswith("export "):
                        s = s[7:].strip()
                    k, _, v = s.partition("=")
                    if k.strip() == "WONKA_IMAGE_MODEL":
                        v = v.split("#", 1)[0].strip().strip('"').strip("'")
                        if v:
                            return v
            break
        except (OSError, UnicodeDecodeError):
            pass
        up = os.path.dirname(here)
        if up == here:
            break
        here = up
    return "gpt-image-2.5-sunburst"
from pathlib import Path

POOL_BASE = 100   # pool ids are prompt number + 100: 101.., never colliding with main-01..99


def pool_id(number):
    """The number printed on the tile and kept for life: 1 -> 101, 30 -> 130, 130 -> 130."""
    n = int(number)
    return n if n > POOL_BASE else n + POOL_BASE


def load_key():
    if os.environ.get("OPENAI_API_KEY"):
        return
    env = Path(".env")
    if env.exists():
        for line in env.read_text().splitlines():
            if line.startswith("OPENAI_API_KEY="):
                os.environ["OPENAI_API_KEY"] = line.split("=", 1)[1].strip().strip('"').strip("'")
                return
    sys.exit("OPENAI_API_KEY not set and no .env found. The Machine Room (guides/mcp-setup-guide.md, Part 2) covers this.")


def run(prompts_file, out_dir):
    load_key()
    from concurrent.futures import ThreadPoolExecutor, as_completed
    try:
        from openai import OpenAI
    except ImportError:
        raise SystemExit(
            "The openai package is not installed. Run: "
            "python3 -m pip install openai pillow"
        )

    client = OpenAI()
    quality = os.getenv("QUALITY", "low")
    size = os.getenv("SIZE", "1024x1024")
    workers = int(os.getenv("WORKERS", "6"))
    data = json.loads(Path(prompts_file).read_text())
    base = Path(prompts_file).parent
    refs = [str(p) if os.path.isabs(p) else str(base / p) for p in data["refs"]]
    # Validate every reference BEFORE the pool spends anything. A stray non-image in
    # the refs list (a .gitkeep, a sidecar, a corrupt download) fails EVERY edit call
    # with a cryptic "unsupported mimetype" error; naming the bad file here is the
    # difference between a one-line fix and a mystery.
    try:
        from PIL import Image as _Img
        for rp in refs:
            with _Img.open(rp) as _im:
                _im.verify()
    except Exception as e:
        sys.exit(f"reference file is not a usable image: {rp} ({e}). Remove or replace it "
                 "in prompts.json refs, then rerun. Nothing was generated and nothing was spent.")
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    images = data["images"]
    model = image_model()
    print(f"OpenAI Blast: {len(images)} prompts | quality={quality} | {len(refs)} refs | model {model}")

    def one(img):
        name = f"pool-{pool_id(img['number']):03d}_{img['tier']}_v{img['variation']}.png"
        path = out / name
        if path.exists() and path.stat().st_size > 10000:
            return (img["number"], "skipped (exists)")
        handles = []
        try:
            handles = [open(p, "rb") for p in refs]
            r = client.images.edit(model=model, image=handles, prompt=img["prompt"],
                                   size=size, quality=quality, n=1)
            path.write_bytes(base64.b64decode(r.data[0].b64_json))
            return (img["number"], "generated")
        except Exception as e:
            msg = str(e)
            if "insufficient_quota" in msg or "credit_balance_exhausted" in msg:
                # not a per-image failure: every remaining call will fail the same way
                raise SystemExit("the OpenAI account is OUT OF CREDITS (not a rate limit; "
                                 "retrying cannot help). Top up at platform.openai.com billing, "
                                 "then rerun; finished pool files are kept and skipped.")
            if "verify" in msg.lower() and "organization" in msg.lower() or "403" in msg and "organization" in msg.lower():
                # one account-level block, not N image failures: without this branch
                # a Day 5 pool printed the same truncated 403 forty times
                raise SystemExit("OpenAI is refusing gpt-image because the ORGANIZATION IS NOT "
                                 "VERIFIED yet (a one-time identity step on OpenAI's side, not a "
                                 "billing problem). Fix: platform.openai.com > Settings > "
                                 "Organization > General > Verify Organization. The kit walks it "
                                 "through in downloads/openai-key-and-verification-walkthrough.md. "
                                 "Verification can take a few minutes to propagate; then rerun, "
                                 "finished files are kept and skipped.")
            return (img["number"], f"FAILED: {msg[:180]}")
        finally:
            for h in handles:
                try:
                    h.close()
                except Exception:
                    pass

    results = []
    with ThreadPoolExecutor(max_workers=workers) as ex:
        for f in as_completed([ex.submit(one, i) for i in images]):
            n, status = f.result()
            print(f"  pool-{pool_id(n):03d}: {status}", flush=True)
            results.append((n, status))
    gen = sum(1 for _, s in results if s == "generated")
    skip = sum(1 for _, s in results if s.startswith("skipped"))
    fail = [(n, s) for n, s in results if s.startswith("FAILED")]
    print(f"reconciliation: planned {len(images)} = generated {gen} + skipped {skip} + failed {len(fail)}")
    if gen == 0 and not skip:
        sys.exit("the pool generated NOTHING. Read the FAILED lines above; the batch is not done.")
    for n, s in fail:
        print(f"  pool-{pool_id(n):03d} {s}")


def sheet(out_dir):
    try:
        from PIL import Image, ImageDraw
    except ImportError:
        raise SystemExit(
            "Pillow is not installed, so the pick sheet cannot be built. Run: "
            "python3 -m pip install pillow"
        )

    out = Path(out_dir)
    files = sorted(out.glob("pool-*.png"))
    if not files:
        sys.exit(f"no pool-*.png files in {out}")
    # An interrupted run leaves zero-byte or truncated pool files behind. One bad
    # tile must not kill the whole sheet: name it, skip it, and let the rerun of
    # `run` regenerate it (resume skips only files that open cleanly here too).
    readable = []
    for f in files:
        try:
            with Image.open(f) as im:
                im.load()
            readable.append(f)
        except Exception:
            print(f"  SKIPPED unreadable pool file (interrupted run?): {f.name}. "
                  f"Delete it and re-run `run` to regenerate that tile.")
    files = readable
    if not files:
        sys.exit(f"no READABLE pool files in {out}; delete the broken ones and re-run `run`")
    # The owner reads NUMBERS, never filenames (measured 6 September 2026: an owner handed
    # "pool-30_t3-motion_v1" could not say which one he liked). The number is printed big;
    # the tier rides along small, for Wonka.
    from PIL import ImageFont
    def font(size):
        for name in ("DejaVuSans-Bold.ttf", "Arial Bold.ttf", "Arial.ttf", "Helvetica.ttc",
                     "/System/Library/Fonts/Supplemental/Arial Bold.ttf",
                     "/System/Library/Fonts/Helvetica.ttc", "C:/Windows/Fonts/arialbd.ttf"):
            try:
                return ImageFont.truetype(name, size)
            except Exception:
                continue
        try:
            return ImageFont.load_default(size=size)
        except TypeError:
            return ImageFont.load_default()
    big, small = font(40), font(16)
    COLS, ROWS, TH, LABEL = 4, 5, 420, 64
    per = COLS * ROWS
    pages = [files[i:i + per] for i in range(0, len(files), per)]
    for p, chunk in enumerate(pages, 1):
        rows = (len(chunk) + COLS - 1) // COLS
        sheet_im = Image.new("RGB", (COLS * TH, rows * (TH + LABEL)), "white")
        d = ImageDraw.Draw(sheet_im)
        for i, f in enumerate(chunk):
            x, y = (i % COLS) * TH, (i // COLS) * (TH + LABEL)
            stem = f.stem.replace("pool-", "")
            number, _, tier = stem.partition("_")
            d.rectangle([x, y, x + TH - 1, y + LABEL - 1], fill="black")
            d.text((x + 12, y + 6), number, fill="white", font=big)
            d.text((x + 12, y + LABEL - 20), tier, fill=(200, 200, 200), font=small)
            sheet_im.paste(Image.open(f).convert("RGB").resize((TH, TH)), (x, y + LABEL))
        name = out / f"pick-sheet-{p}.jpg"
        sheet_im.save(name, quality=86)
        print(f"{name} ({len(chunk)} tiles)")
    print(f"{len(pages)} sheet(s). The owner names a pick by the printed NUMBER (e.g. \"07\").")


if __name__ == "__main__":
    if len(sys.argv) < 3:
        sys.exit(__doc__)
    cmd = sys.argv[1]
    if cmd == "run":
        run(sys.argv[2], sys.argv[3] if len(sys.argv) > 3 else "openai-blast")
    elif cmd == "sheet":
        sheet(sys.argv[2])
    else:
        sys.exit(__doc__)

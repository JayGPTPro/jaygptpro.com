---
name: fix-faces
description: One-click rescue for AI-looking people in ANY image, no factory context needed. Point it at an image file (or a folder), Wonka diagnoses which of the three realism signatures it shows (doll face, waxy skin + uniform tone, filter glow), runs ONE whole-image gpt-image edit pass that touches only the people, and saves the fixed version under its own name in a new edit round inside the factory (beside the original for a loose file). Clean images are left alone and told so. Works on factory images, old images, images from anywhere. Use when people in an image look fake, plastic, AI-generated, waxy, or over-filtered. Triggers: /fix-faces, "fix the faces", "the people look fake", "make the people real", "the skin looks weird", "AI-looking people".
---

# The Face Clinic

| Meta | Value |
|------|-------|
| Room | The Face Clinic (a walk-in clinic, not a production station) |
| Station | None. Runs any day, on any image, factory or not |
| Needs | An image file path (or a folder of images) and `OPENAI_API_KEY` |
| Saves to | Inside a product folder: `edits/v[N+1]/[same name].png`, a new round built from the ADOPTED SET (every asset at its adopted version, assets generated after the last round included, `-rejected` and `-render` evidence excluded; `round.md` in the folder names each file's source), so the Tasting Room, `/inspect` and the Shipping Room find it by name. The name is the asset's identity: `sec-03-v2.png` is fixed as `sec-03-v2.png`, and the format is part of it: a `.jpg` original is fixed as `.jpg`, so a round holds one file per asset. A `-fix2` or `_fix2` file is evidence either way, never a gallery member. An A+ module: `edits/v[N+1]/aplus/[mode]/[same name]`, a touched neighbour beside it (see On an A+ module). A loose file outside the factory: `[name]-faces-fixed.[same format]` beside it. The original is never touched |
| Typical cost | One gpt-image edit per flagged image at quality **high** (~100s each on gpt-image-2; another model, another number, read it off the first repair). More than the house low default, on purpose: see step 3. Reported, not gated |

## What this room does

Generated people sometimes come out AI-looking. This clinic diagnoses WHICH way, fixes only what is
broken, and leaves clean images alone. It is deliberately tiny: no preconditions, no product folder,
no brief. Bring an image, leave with a real-looking one.

## The three signatures (the diagnosis vocabulary)

1. **Signature A, doll face** (geometry and expression): too-perfect symmetric features, uniform
   flawless teeth, glassy eyes, and everyone in frame at identical peak expression (all mid-laugh at
   once). Shows up even when lighting and color are believable.
2. **Signature B, waxy skin + uniform tone**: zero skin micro-texture (no pores, one smooth
   gradient), and every person wearing the same peach-orange tone that matches the design palette
   instead of varying per person.
3. **Signature C, the filter layer**: a diffusion/bloom glow like a beauty filter, highlights
   smearing on forehead and cheekbones, and warm light patches painted on with no single consistent
   light direction.

## Process

1. **Open the image and diagnose, out loud.** Look at the people at full size. Name which
   signature(s) apply, with one line of evidence each, or say **CLEAN** and stop: a clean image is
   never "improved" speculatively. No people in the image at all: say so and stop.
2. **Draw the head boxes, and PROVE them before spending.** For every person, one tight rectangle:
   the whole head and all of its hair, nothing else. Then crop each box out and LOOK at the crops.
   Two laws, each bought with a measured failure:
   - **A box never touches on-image text or the product.** Everything inside a box is surrendered
     to the re-render. A generous box that reached into the layout composited back a ghost
     microphone and a floating letter.
   - **A box never cuts through a head.** A box that covered half a face left the original half
     standing beside the new one, a two-face ghost. Whole head or redraw the box.
   - **A box ends on quiet background, never mid-garment.** The fade is invisible over a bench or
     foliage and plainly visible over a dark hoodie: the same seam that vanished on one child
     printed a soft line across another's chest and cheek. On a person wearing something dark,
     run the box down past the shoulders so the falloff lands off the body.
   - **Name what the box must never touch, then look at the final region before spending.** Draw a
     protect box around the product and around the on-image text nearest the head (`--protect`, the
     same `x1,y1,x2,y2` syntax, the same coordinates as the head boxes), and run once with
     `--dry-run`: the engine validates the region, writes `[name]-boxes.png` (red = the head box as
     drawn, orange = the region the edit may land in, blue = protected) and spends nothing. READ that
     copy. On an A+ module the region is larger than the head box you drew, because the engine
     grows it across the seam and sideways for the shoulders, and on the Day 7 desktop hero that
     growth ran a box placed carefully at x=1136 into the fountain at x=1021 (reproduced 10
     September 2026). With the fountain protected the engine trims the growth back to its edge and
     keeps the neck; a head box that overlaps a protect box is refused outright; a protect box that
     sits where the person continues across the seam is refused too, with the reason, before any
     money goes. Then run for real with the same boxes.
3. **Quality is HIGH here, and that is not the house default.** Everywhere else in this factory
   the rule is low: a Draft Blast makes a hundred candidates and ninety-nine are discarded, so
   paying for detail on all of them is waste. This room is the opposite case and gets the opposite
   rule. **Cheap pools, expensive repairs.** It runs on ONE image, once, whose
   faces are already wrong, on an asset the owner has already paid to generate. The whole point of
   the pass is the part a customer looks at hardest.

   Measured on the same frame, same boxes and same prompt:

   | tier | render time | what it returns |
   |---|---|---|
   | low | ~20s | soft skin, no real texture, still faintly synthetic on a child's cheek |
   | medium | ~40s | real texture, hair strands, believable teeth |
   | high | ~100s | the best structure and eyes, and the house default here |

   Every render is a fresh draw, so some of any single comparison is luck rather than tier. The one
   thing that is not luck: low is soft every time. Judge a tier by looking at the face at 3x, not by
   a texture metric: high-frequency energy counts noise as detail and will rank a grainier render
   above a more human one.

4. **Report the cost in one line** (one edit at high, and it takes about a minute and a half) and run:

   ```bash
   python3 .claude/skills/fix-faces/face_fix.py IMAGE --boxes "x1,y1,x2,y2;x1,y1,x2,y2" --protect "x1,y1,x2,y2;..." --dry-run   # the region proof, nothing spent
   python3 .claude/skills/fix-faces/face_fix.py IMAGE --boxes "x1,y1,x2,y2;x1,y1,x2,y2" --protect "x1,y1,x2,y2;..."             # the fix
   ```

   What the engine does, and why it is an engine rather than one API call: it sends the FULL frame
   to gpt-image (context: the scene, the light, the palette), at `size="auto"` (a forced size
   re-composes at the wrong aspect and every head lands outside its box), with a prompt that
   REPLACES each face with a new real one, same casting, same pose, pinned to the same position.
   Then it composites ONLY the head boxes back over the original through a feathered mask, with a
   spatially varying, capped tone match so the seam carries no exposure edge and no color bleed.
   Every pixel outside the boxes is the original file by construction: the feather falls off
   INWARD from the box edge (kit v28; before that it blurred outward and a ring of up to 20 px
   outside every box took render pixels) and it reaches the original AT the boundary (kit v36;
   v28 to v35 clipped a blur to the box, which kept the outside untouched and left half the
   render's opacity on the first pixel inside, a hard edge the outside count could not see). The
   engine counts changed pixels against the plain box union and refuses to write if that count is
   not 0, prints both counts and the blend's opacity on the first ring inside the box (it refuses
   above 8 of 255), and the tone field is a proper weighted mean, so a flat exposure shift is
   corrected by that shift and never past it. Headlines, product and layout cannot drift, because
   they are never replaced. The `[name]-boxes.png` proof is copied into the round beside the fix as
   evidence.
5. **Verify the composite, then the faces.** Open the result full-size next to the original:
   - No ghost fragments at box edges, no second face, no relocated feature. The model sometimes
     moves a person inside the render despite the position pin; when that shows, ONE retry (a fresh
     render is a fresh draw, cents). If it survives the retry, this image wants a regeneration in
     its own room, not a bigger clinic bill.
   - The people read as real at 3x zoom on the face itself, not at module scale.
   - Everything outside the boxes is untouched, which the engine guarantees, so any drift you see
     outside a box means the boxes are not where you think they are: recheck them.
6. **Done.** Inside the factory the fix sits in the new round as `edits/v[N+1]/[name].png` and the engine
   printed which round it opened; when `/fix` already opened this round, pass `--out edits/v[N]/[name].png`
   so the file lands in that snapshot instead of a new one. A loose file landed beside its source as
   `[name]-faces-fixed.png`. The original is never overwritten; log the edit in `edits/fixes-log.md` like any fix.
7. **On a folder**: diagnose every image first, list the flagged ones with their signatures and
   boxes, give ONE total cost line, check it against CLAUDE.md's routine-fix policy (faces run at `high`,
   so a folder crosses the estimated-cost limit fast; a crossed limit waits for one yes, a list inside
   the limits runs on the report; single-image mode always runs, because invoking the room on one
   image IS the ask), then fix them in parallel.

**Know what this clinic cannot fix.** When the whole frame is color-graded (fake-tan skin, teeth
that are not white, nothing neutral anywhere), the defect is the GRADE, and `/inspect`'s
`cast_check.py` will say so. Fix the grade first; faces second. Corrected people inside an orange
room look worse than the problem.

## On an A+ module

An exported A+ module (`aplus/export/[mode]/mN.png`) is an image like any other here, with one difference
that matters: an A+ page is ONE canvas cut into strips, so a person can live in two files at once. Run the
clinic on the module exactly as on a gallery frame, same command, same head boxes, same prompt; the owner
is asked nothing new and approves nothing new. House routing (Jay, 9 September 2026): `/aplus` exports the
chosen concept at the pick, and A+ people fixes run HERE, on the exported file, never as a Genrupt
whole-concept re-render (that re-rolls every module for one face and is used only when the owner
explicitly asks to keep the concept and change the page). The engine does the rest by itself:

1. **It fixes across the seam.** Measured 10 September 2026 on the Day 7 desktop hero: the woman's face
   sat in m1 and her neck and shoulders ran on into m2. The clinic replaced the face inside m1 alone,
   "0 outside" and the edge rows all passed, and her neck was cut at the module edge: a visible seam.
   So when a head box comes within about 12% of the module height of the top or bottom edge, touches
   it, or would have to run past it to hold the whole head, the engine opens the neighbouring module(s)
   too: it stacks them in page order, runs ONE edit on the joined image with the box grown to hold the
   whole person across the seam (head, neck and shoulders; a box never cuts through a person),
   composites through the same inward feather, re-cuts the result at exactly the original module
   boundaries and sizes, and writes every touched module (two or three files) into the SAME round.
   Outside the joint box nothing changes, so every untouched row stays byte-identical. It prints that it
   joined, which modules, and the joint box it used. **Joining gives the model context; it never
   authorises replacing everything inside an enlarged rectangle.** The grown box is trimmed back off every
   `--protect` box (the product, the text) to the smallest region that still holds the person across the
   seam, drawn on the joined image as the proof, and validated again on the retry, whose box is a new
   region.
2. **It works from the adopted copies, of THIS export.** The input to every fix is each module's current
   version: the newest `edits/vN/aplus/[mode]/` that holds the filename AND descends from the current
   export (`edits/vN/aplus/lineage.md`, written when the round opened), else the export. A round from
   another concept exported earlier under the same filenames is never adopted, a round with NO lineage
   record (opened by hand, or before kit v36) is never adopted while an export exists, and the engine
   says which rounds it passed over. The chosen line in `aplus-plan.md` (`folder edits/vN/aplus/`) names
   the round the owner wants: that round is served on the owner's word, rounds above it are not the
   set, and after every standalone fix the engine moves the line to the round it just wrote (the
   ceiling would otherwise keep serving the round before the fix). When the export on disk changed
   after a round was fixed, the two hold the same filenames and no chosen line names a folder, the
   engine STOPS before any spend and asks which set is current, because a re-export of the same concept
   and a new concept under the same names are the same event on disk. Pass the export path while a
   fixed copy exists and the engine uses the fixed copy, and says so. The result lands in
   `edits/v[N+1]/aplus/[mode]/` under the module's own name, and the round carries the full A+ set for
   that mode (`round.md` names each file's source), so once this round exists the chosen round's
   `edits/vN/aplus/` is the upload.
3. **It hands you the seam to READ.** After the composite it rebuilds the page from the fixed round and
   writes two crops beside the fixed files: `seam-[a]-[b]-2x.png` (the 300 px band around the seam
   between the touched modules, magnified 2x) and `seam-[a]-[b]-1x.png` (the same seam at 1:1, inside
   the whole person). Open BOTH before saying anything is done. At 2x: is the neck one neck, does the
   hair fall through the seam, does the skin match above and below it. At 1:1: does this read as one
   photographed person, one light direction, shoulders where a body would put them. Then the module's
   top and bottom edges still meet their neighbours, as on any page.
4. **The numbers are technical only.** The engine still prints the inside and outside counts and still
   refuses to write on any outside change, and none of that says the fix looks right. A visible seam or
   an unnatural body join FAILS the fix even when every count passes. The answer is a wider joint box.
   The engine grows it once on its own, by the neck and shoulder height, when the feather would land on
   re-rendered content (one automatic retry, one more edit at high, printed when it happens). The
   retry's region is settled before the first edit is paid for: when a `--protect` box caps the growth
   so the grown region equals the first one, or the grown region is refused, the engine says so up
   front and runs ONE attempt, because a second edit on the same region is a re-roll, not a wider box
   (kit v35 paid for the re-roll and called it growth). **A second
   attempt that still fails that check is never promoted:** it is written as `[name]-rejected` evidence
   beside the unchanged adopted modules, the run exits with the reason, and the accepted parents stay the
   current set (kit v35 wrote it as the fix). A numerical pass is still not a verdict: the seam crops
   decide. If your read finds a seam, run again with the head box drawn down past the shoulders (it may
   run into the next module; the engine joins it), and if two runs will not join, the owner picks another
   concept from the run (`/aplus` step 8). It is not sent to a Genrupt edit by default.

A head clear of both edges is fixed on its module alone, and a gallery frame or a loose file never
stacks, whatever its box.

## What this room never does

- Never touches a CLEAN image, and never lands changes outside the head boxes.
- Never keeps the doll: replacement IS the method. Asking the model to
  "make the same face realistic" keeps the doll geometry and paints texture on it, which reads as a
  skin disease. A NEW face with the same casting, expression and position is what actually looks
  human. A different POSE or a different casting is still a regeneration, back in the image's own room.
- Never overwrites an original.
- Never claims the fix is invisible: it verifies side by side and reports drift honestly.

## Wonka lines

- "The Face Clinic. Walk-ins welcome, bring me anyone who came out of the ovens looking like a mannequin."
- "Diagnosis first. I do not operate on healthy faces."
- "There. Same picture, real people. The original is untouched, as always."

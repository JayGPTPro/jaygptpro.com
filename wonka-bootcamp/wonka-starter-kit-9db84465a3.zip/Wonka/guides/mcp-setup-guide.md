# Connections Setup Guide

The Factory has **two** external connections, and that is the whole list:

| Machine | What it is | Where it works |
|---|---|---|
| **Genrupt MCP** | the Inventing Room's production machine | Day 3 (sending the approved brief), Day 4 (the locked reference and the smoke test), Day 5 (main image), Day 6 (secondary set), Day 7 (A+), Day 9 (variations: Type B generation and the Type A fallback; Type A itself runs on the OpenAI key), Day 10 (the Shipping Room's one owed upscale, run once on the files that ship) |
| **Your OpenAI API key** | the second blast machine, the Fixing Room's scalpel AND the Tasting Room's panel | Day 1 (First Candy), Day 5 (the OpenAI Blast), Days 5 to 7 (every fix), Day 8 (the Tasting Round, two races; a further comparison only when you ask for one), Day 9 (variation edits) |

Nothing else. No survey account, no research extension, no third tool to buy. The Research Room on
Day 2 needs no tool at all, because it runs on your own listing, your reviews, and your competitors.
The Tasting Room runs inside the factory on the same OpenAI key you already set up.

Both connections are made on **Day 1**, and Wonka verifies them himself in the same sitting. Nothing
here requires coding. Every step is a click path or a copy and paste.

Genrupt connects through an MCP (Model Context Protocol): a direct line that lets Wonka drive an
outside tool himself from inside Claude, with no external website for you to log into and build
things on. **Your ticket covers your first month of Genrupt: 1,000 credits, claimed with a coupon at signup.**

---

## Part 1: Genrupt MCP

Once connected, Wonka can drive Genrupt himself: build product reference sheets, lock the Mold, and
generate images, without you touching the Genrupt website.

**The connection values are fixed and known.** The connector is named `Genrupt`, and the server
URL is `https://genrupt.com/api/agent/mcp`. That is all the connector needs; there is no Genrupt
API key to create or paste anywhere in this flow. Authentication happens by signing in to Genrupt
in the browser window that opens when you click Connect.

Product photos: Genrupt reference sheets are built from image URLs or Genrupt's own upload paths (the
app or the CLI bridge). Wonka walks you through it on Day 4, in the Reference Room.

### Option A: Claude Desktop (Connectors UI)

1. Open Claude Desktop.
2. Click **Settings** (gear icon, bottom left), then **Connectors** (on some versions: Settings, then
   Extensions or Integrations).
3. Click **"Add custom connector"**.
4. Name it exactly `Genrupt`, and paste `https://genrupt.com/api/agent/mcp` as the server URL.
5. Click **Add**, then **Connect**, and complete the Genrupt sign-in in the browser window that
   opens.
6. Then **quit Claude Desktop completely and reopen it** (Mac: Cmd+Q, not just closing
   the window. Windows: right click the tray icon, Quit). Claude only loads a connector on a full
   restart.

### Option B: Claude Code (.mcp.json file)

1. In your kit folder there may already be a file named `.mcp.json` (remember: files starting with a
   dot are hidden. Mac: Cmd+Shift+. in Finder).
2. If not, ask Wonka to create it:
   ```
   Create a .mcp.json in this folder for the Genrupt MCP. The server URL is
   https://genrupt.com/api/agent/mcp and the name is Genrupt.
   ```
3. Restart Claude Code (type `exit`, then start `claude` again in the folder).
4. On first use, Claude will ask you to approve the new MCP server. Approve it.

### Verify Genrupt

In a fresh session, type:

```
/machines-check
```

Wonka makes free, read only calls on each connected machine (a tool listing, an account context
call, and the credit balance) and reports each machine as PASS, FAIL, or SKIPPED. A working Genrupt
connection returns real account details plus your **credit fuel gauge**, the number you will see
before every production run. He will tell you plainly if it failed, and he never reports a machine as
working on hope.

### If it fails

- **The MCP does not appear at all:** you did not fully restart Claude. Quit completely (Cmd+Q, or
  Quit from the tray) and reopen. This fixes most cases.
- **"Unauthorized" errors:** the Genrupt sign-in did not complete or went stale. Remove the
  connector, add it again, and finish the sign-in in the browser window that opens.
- **Connected but calls fail:** log in to genrupt.com in your browser once and retry. Some setups
  need an active web session.
- **Wrong account signed in:** the credit gauge and the account line in the machines report tell you
  which account answered. If it is not the one your ticket activated, sign in to the right one before
  Day 3, not in the middle of a batch.
- **Still stuck:** post the exact error and a screenshot in the bootcamp group if your ticket
  includes one, or email support. Do not lose an evening to it. The fallback path below keeps you
  moving.

**Fallback:** without Genrupt, Wonka generates using OpenAI's image model directly (the Part 2 key is
required). Product reference accuracy is lower and Wonka marks that honestly in your files. **Every
day except Day 7 stays doable.** The A+ Room has no fallback and closes without Genrupt: A+ is
hands-off by design, which means Genrupt authors the page, and there is no second engine to hand
that job to.

---

## Part 2: OpenAI API key (the second blast, the Fixing Room AND the Tasting Room)

One key, four rooms. On Day 5 it is half of the dual blast: the OpenAI Blast bakes its own pool of
hero candidates beside Genrupt's (typical cost: a couple of dollars at low quality). Surgical image
edits run directly on OpenAI's image model (typical cost: cents per edit). The Tasting Room's panel of about 100 AI tasters runs on the same key (`/tasting-room`,
typical cost: a few dollars per race, and each Tasting Round is two races). This is the key that makes your images testable the
same hour they are made.

### Create the key

1. Go to **platform.openai.com** and log in (create an account if needed. This is separate from a
   ChatGPT subscription).
2. Top right profile menu, then **API keys** (direct: platform.openai.com/api-keys).
3. Click **"Create new secret key"**, name it `wonka-factory`, click Create.
4. **Copy it now.** It starts with `sk-` and is shown only once.
5. Go to **Settings, then Billing**, add a payment method, and load **$10 to $20** of credit. For most
   people that covers every edit and both Tasting Room races of the whole bootcamp: cents per
   edit, a few dollars per race, two races in the one round (a further comparison, only when you ask for one, adds to that).
6. **One time organization verification.** OpenAI may require it before image models work. If it
   asks, go to **platform.openai.com, Settings, Organization, Verify** and start it **on Day 1,
   during setup**: approval can take a few minutes or a day or two, so it is the one item worth
   doing early rather than discovering later with a batch waiting.

**Never screenshot your key and never paste it in the group.** If it ever appears somewhere public,
revoke it on the API keys page and create a new one. That takes thirty seconds.

### Save the key for Wonka

The simple, recommended way: a `.env` file in the kit folder.

Lesson 4's rule was: never paste the key into a chat, a screenshot, or a screen recording. That
includes the chat you are about to open. A key pasted there lives in the transcript forever. So the
key goes into a file, and Wonka opens that file for you.

1. Tell Wonka:
   ```
   Prepare the .env file for my OpenAI key and open it for me. I will paste the
   key into the file myself.
   ```
2. He creates the file with a placeholder, opens it in your text editor, and tells you exactly what
   to replace. You paste the key **there**, save, and tell him done. He verifies it without ever
   printing it back: he reports only that it is present, its length, and its last four characters.
3. The `.env` stays on your machine and is not shared when you post screenshots (never screenshot
   the file itself). Every room that needs the key loads it from here.

**If you already pasted the key into a chat**, no drama, one fix: let Wonka store it, then go to
platform.openai.com, API keys, revoke that key and make a new one, and wire the new one through the
file. Thirty seconds, and the transcript now holds a dead key.

Comfortable with system settings instead? Set an environment variable named `OPENAI_API_KEY` (Mac: in
`~/.zshrc`. Windows: System Properties, Environment Variables). Either method works. The `.env` is
easier.

### Verify, and then prove it

```
/machines-check
```

The check confirms the key is present. No API call is made and nothing is spent.

**A key check cannot prove the one thing that matters: whether OpenAI will let your key actually make
an image.** That is what the **First Candy** is for. Wonka offers it, states the cost first, and only
prints on your explicit yes:

```
Yes, print the First Candy.
```

One small welcome card, a few cents, saved to `output/first-candy.png`. It proves the whole pipeline
end to end: key, billing, verification, generation. If it fails with a verification error, that is
this step doing its job. You found out on Day 1 with the fix one click away.

### If it fails

- **"Invalid API key":** re copy the key. Stray spaces and truncated pastes are the usual crime. If
  the key is lost, create a new one and delete the old one.
- **"Insufficient quota":** billing has no credit. Load $10 to $20 at platform.openai.com under
  Billing.
- **403, or verification required:** the organization verification has not completed. Go to
  platform.openai.com, Settings, Organization, Verify, finish it, then run `/machines-check` again.
  Day 1 is complete when all three checks pass and the First Candy is printed, so this is the
  fix to chase today rather than carry forward.
- **A fix or a tasting run says the key is missing:** the room loads the key from the `.env` at the
  factory root. Confirm the file is there and the variable is named `OPENAI_API_KEY`.
- **Edits fail with a content flag:** usually an instruction mentioning a third party logo or brand.
  Rephrase the edit without it. Wonka knows this rule and routes around it.

---

## Quick reference: verify everything at once

Type this any time you want a full systems check:

```
/machines-check
```

It runs three checks in one pass: Python (a free local process, nothing to pay for), the Genrupt
MCP with free read only calls plus the credit fuel gauge, and the OpenAI key's presence, with the
First Candy print as the end to end proof. Each machine comes back PASS, FAIL, or SKIPPED with the reason, and every FAIL carries
the exact fix and where in this guide to find it.

**Remember this command.** Every "it is not working" problem in this bootcamp starts here. Run
`/machines-check` first, then debug. Anything it does not solve lives in `guides/troubleshooting.md`.

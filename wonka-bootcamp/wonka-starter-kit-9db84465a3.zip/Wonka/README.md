# The Wonka Starter Kit

Welcome to the Factory.

This folder IS your AI Creative Director. His name is Willy Wonka, and he runs a creative production line for a full Amazon listing package: research, brief, generation (main image, secondary images, A+ content, and variations), quality inspection, and instant panel testing in the Tasting Room. There is nothing to install inside this folder. You open it in Claude, and Wonka wakes up with his personality, his skills, and his memory intact.

The Wonka Creative Bootcamp runs as **10 days**, numbered from 1. One day is one room in the Factory. Day 1 is The Front Gate, where you cut the keys and wire the machines. Day 10 is where the factory starts teaching itself.

What you are here to build: a full creative package for your product, generated on your locked real product and raced against your live listing before a dollar of ad spend. "Tested" means the Tasting Room sitting on Day 8, both races, and any changes you chose made afterwards. No sales lift is promised. Results vary by product and niche.

New here? Start with `QUICK_START.md` (5 minutes), then the Day 1 guide, `guides/episode1-guide.md`.

## The map

```
Wonka/
├── CLAUDE.md                  Wonka's operating manual, loaded every session
├── README.md                  This file
├── QUICK_START.md             5-minute orientation
│
├── .claude/                   Hidden folder (Mac: Cmd+Shift+. to see it)
│   ├── wonka-character.md     Who Wonka is: voice, rules, what he would never do
│   └── skills/                The rooms of the Factory, 16 skills (one per room)
│
├── factory/                   The Factory floor
│   ├── Products/              One folder per product, moving down the line
│   │   └── TEMPLATE/          Copied for every new product by /meet-my-product
│   │       ├── 1-inputs/      You drop inputs here: reviews.txt, competitors/, notes.txt, demographics
│   │       ├── 2-reference/   photos/ (product + packaging), logo/ (your real logo, optional), brand/ (a real brand book or style guide, optional), reference-sheet.md
│   │       ├── research/      Wonka writes: insights, reviews, persona, competitors, selling points, product report
│   │       ├── brief/         The creative brief
│   │       ├── images/        Raw generation output, write-once
│   │       ├── edits/         v1/, v2/... one COMPLETE set snapshot per edit round
│   │       ├── final/         The approved package (/ready-to-upload also copies it to output/)
│   │       ├── incumbent/     Your LIVE Amazon main + gallery, fetched by Wonka at the opening of Day 8. Not live yet? The strongest competitor's files, chosen on Day 2
│   │       ├── aplus/  variations/  scorecards/  tests/
│   │       └── status.md      The station tracker
│   ├── Brand/                 The Wrapper, optional: brand styling read from your brand book, only on request
│   ├── Improvement Log.md     The ONE learning file: what the market taught us + what the factory taught itself
│   └── Factory Log/           Machine checks, pace, and any status reports you ask for
│
├── guides/                    One guide per day, Day 1 to Day 10, plus reference guides
├── downloads/                 Short reference one-pagers for the days that need them
└── output/                    Finished deliverables ready to leave the Factory
```

## The ten days

| Day | Room | What you leave with |
|---|---|---|
| 1 | The Front Gate | Both machines wired and verified, First Candy printed. The floor is ready; no product is registered yet |
| 2 | Wonka, Meet My Product | The full research pass, and one readable Product Report: buyer pains counted, the Must-Haves, whitespace, persona, funnel diagnosis |
| 3 | The Creative Brief | Your whole plan written, reviewed by you with three questions, approved, and sent into the machine in your words |
| 4 | The Reference Room | Your product locked as a Mold and PROVED with a smoke test, and your brief seen as pictures for the first time |
| 5 | The Main Image Room | The doctrine, well over a hundred hero candidates from two machines, a shortlist of one to five, and the quality loop learned once and properly |
| 6 | The Secondary Images Room | Ten complete style directions read in rows, one locked as the style, three candidates per slot in that look, one frame chosen per job, the set inspected and fixed on the chosen frames |
| 7 | The A+ Room | An A+ judged on beauty rather than coverage, and exported already cut and ready to upload |
| 8 | The Tasting Room | A hundred shopper personas race your images against what is live, and their objections become your final set the same day. Nothing is uploaded today: Day 8 tests, Day 10 ships |
| 9 | The Variations Room | Most of your variant family already exists. Two tables, the first images reviewed before the rest, then the whole family propagated on the instruction that worked. Optional if you sell a single SKU |
| 10 | The Improvement Loop | Three lessons: Get Your Files Ready for Amazon (your package in `output/`, every shipping file measured, enlarged once and checked against its source, the exact upload files named), Make the Next Product Better (the lessons saved at the strength the evidence carries, read again by the next product's research and brief), and Your Creative Employee, From Here On (the next product, the next brand, and the work beyond Amazon) |

Days are numbered, not scheduled. Work them at whatever pace your week allows.

## The 16 rooms (skills)

`/machines-check`, `/meet-my-product`, `/reference-sheet`, `/brand-kit`, `/creative-brief`, `/main-image`, `/secondary-images`, `/aplus`, `/variations`, `/inspect`, `/fix`, `/tasting-room`, `/ready-to-upload`, `/improvement-loop`, `/factory-report`, `/fix-faces`.

## How Wonka uses this folder

- **CLAUDE.md** and **.claude/wonka-character.md** load at the start of every session. That is how he stays Wonka across hundreds of conversations.
- **factory/Products/[your-product]/status.md** is his memory of where each product stands. He reads it when a session starts and updates it after every station.
- **factory/Brand/brand-kit.md** is read before every generation, so everything comes out on-brand. With more than one brand, each has its own kit file and each product's `status.md` names which one it uses; Wonka reads that row, never a default.
- **factory/Improvement Log.md** is read at the start of every session and again before every new creative brief, so every test you run makes the next product better and Wonka gets better at his own job over time.

Copy the folder, and you copy your entire Creative Director: memory, skills, learnings, everything.

## The Production Line in 5 lines

1. **RESEARCH**: register the product, then learn what the niche demands, what buyers complain about, what competitors show, who actually buys.
2. **BRIEF**: a written creative brief for the FULL package (main, secondaries, A+, variations), each asset one job, one message, every selling point mapped.
3. **INVENT**: lock a Reference Sheet of your REAL product (your own photos, all angles plus one hand-for-scale shot; listing and review images only when there is genuinely no unit in hand, and recorded as such), smoke test it, then generate the main image, the secondary images, the A+ modules, and the variations.
4. **INSPECT**: every asset is scored against the Golden Standards, then `/fix` cleans defects, before you ever pick anything.
5. **PROVE**: a panel of ~100 AI tasters, matched to your real buyer, runs two races in one sitting: your main candidates against your current live image, and your new gallery against the live Amazon gallery (`/tasting-room`), instantly. The verdict is directional, from synthetic tasters and not real shoppers, and it comes with the objections in their own words. Wonka lists what the tasting notes propose and stops; you name the changes, he refines what you named (another comparison only when you ask for one; the honest second opinion is Amazon's own A/B), your recorded decision ships, and the package earns its Golden Ticket on Day 10 (`/ready-to-upload`, the Shipping Room: every file's real pixel size read, the one owed upscale run, then the approved package lands in `final/` and a copy in `output/`), and the Factory learns twice in one run: `/improvement-loop` writes both kinds of lesson into the Improvement Log, what your market rewards and how Wonka works better.

"We don't guess in this factory. We test."

# Day 4: The Reference Room

Yesterday you approved a plan made of words. Today the machines learn what your product actually
looks like, and then, for the first time, the plan becomes pictures.

Two lessons: lock the product, then run the smoke test. The order is deliberate. The sheets are
built and approved first, and the smoke test is what turns an approved sheet into a locked one.

**The sentence for the day: an approved sheet is a status. A generated image that shows your
product is the evidence.**

## What you will have by the end of today

- **Approved Product Reference Sheets**: one to five images, each with a clear role, that lock your
  product's angles, scale, materials, proportions and details. Every image the factory makes from
  now on inherits the product from them
- **Optionally, a Brand Kit** (`factory/Brand/brand-kit.md`), only if you own a real Brand Book or
  Style Guide. Most sellers do not, and nothing waits for it
- **A passed smoke test**: one cheap image per planned gallery slot, opened and read by you, twice
- **A locked product**: `2-reference/reference-sheet.md` carrying `Reference status: LOCKED` and
  `Smoke test: PASS`, the two lines Day 5 reads before it generates anything

Costs today are small, and Wonka reports each one as it runs. Your brief approval yesterday covers
the sheets and the smoke test, so he does not stop to ask.

---

## Lesson 1: Lock the Product

### The mold, and why you do not rush it

The Product Reference Sheets are the most important output in this entire bootcamp. Every main
image, secondary image and A+ module you make later inherits the product from them. Think of a sheet
as the mold the factory pours from. If the mold is accurate, every room begins from an accurate
product. If the mold is wrong, the same mistake spreads into everything that follows.

So this is not a step to rush. Stay here as long as you need. Do not approve the sheets until you
are genuinely confident they represent your product correctly.

### What Wonka does before the first sheet

```
/reference-sheet
```

Wonka starts with the real product photos you already gave him on Day 2. You do not have to find
them, open a folder, or move anything: he keeps track of what you sent and where he filed it. If
something is missing, attach it to Claude and he takes it from there. He
identifies the available angles, the visible materials, every countable part, the dimensions you can
confirm, and any detail the model must not invent. For products with small or precise parts, he
zooms into the source photos and describes those parts individually. This specification is the
standard the sheets are judged against.

If you gave Wonka a real logo file, he also uploads it and connects it to Genrupt during this
lesson, and tells you it is done in one line. If you did not, he simply carries on. No logo is
needed to run this bootcamp, and he never draws one.

**Scale matters more than people expect.** A number in inches helps. A visual cue is much stronger:
a hand holding the product, a forearm beside it, a familiar object in the same frame, or, for a
countertop product, objects whose size people already know. Make sure at least one sheet gives
Genrupt a clear visual understanding of scale. There is a real setting for this, and Wonka chooses
it deliberately.

### Inspect it zoomed in, beside the source photos

Wonka combines the real photographs into a Product Reference Sheet: an image, not a written
document, showing the product from enough angles to lock its shape, materials, proportions, details
and scale. It carries no text, captions, arrows or badges. It locks identity and nothing else.

Do not judge it only as a full image. A sheet judged at full size gets approved with the wrong metal
color, the wrong proportions and a misspelled label. Put the sheet beside the source photos, zoom
into the matching areas, and run five checks, every time:

1. **Angles.** Can Genrupt clearly understand the front, back, sides, top, and any part that changes
   position or opens? Whatever is not in this picture, the model gets to invent forever.
2. **Scale.** Is there a hand or another visual cue that makes the real size obvious?
3. **Panel quality.** Is every important view clear, useful, and attractive enough to serve as a
   reference? An ugly panel does not just fail to help. It poisons everything poured from this mold.
4. **Material truth.** Do metal, plastic, glass, fabric, texture, gloss and color look like the real
   product? A mixed-material product rendered as one gleaming metal object sells something that does
   not arrive in the box.
5. **Product integrity.** Has anything been added, removed, duplicated, reshaped or invented? Count
   the parts. Check the labels. Check the proportions.

If anything is wrong, do not approve it because most of the sheet looks good. Every later image will
inherit this mold. `downloads/five-point-sheet-check.md` is the same five checks on one page.

### Wonka checks and corrects it first

Before you see a sheet, Wonka measures it against your photos, panel by panel: the surface finish,
the outline, the small parts his checks know how to read, the panels it should have. Whatever he
can fix, he fixes himself, always from the cleanest version and never on top of an earlier fix.
Free fixes come first; a fix only the image machine can make costs a few credits, reported as it
runs, and he stops after the attempts and credits set for one sheet. Then you get the best sheet
as a file, before-and-after pictures for the parts that can be shown that way, and a plain list of
anything he could not fix with what he proposes for it. You still zoom in and you still approve.
If you see something he missed, say it in your own words: if a machine check can measure it, it
becomes a check on every later sheet of this product; if not, he checks it by eye.

### Correcting it: revise, never restart

Tell Wonka exactly what needs to change:

```
The reference sheet is close, but please fix these details: [describe the exact issues]. Keep everything else unchanged and create a revised version.
```

Name the defect in nouns ("the tower reads as chrome, it is brushed steel"), because a machine
cannot act on "it looks off". Give a proportion a number measured from a real photo, because "too
short" just buys another guess.

Wonka uses the cleanest sheet so far as the base (not always the latest one) and carries every correction so far into one instruction, so each revision is one step from that base and never a step on top of the previous revision. He does not rebuild
from zero because one detail is wrong, and every version stays on disk as `sheet-v[N].png`, so you
can put old beside new. Then you inspect again, all five checks. Two or three revision rounds are
not a failure. They are the normal way to build the most important reference in the factory.

**If the same defect survives two rounds, stop rewording.** Two suspects: a missing source photo
(take it and attach it to Claude), or an instruction that contradicts the product's real geometry
(re-check the claim against the zoomed source). Wonka checks both before buying a third round of the
same words.

### Up to five sheets, each with a job

You can have up to five sheets. If your product is a set, has several separate components, changes
between states, or contains an important part that needs more coverage, ask Wonka for additional
sheets; on a complex product he proposes the set himself, with one line of reason per sheet. Each
sheet has a clear role: one locks the complete product, another the accessories or the parts
inventory, another a critical mechanism or state. Do not create extra sheets merely to use all five.
**One sheet is almost always enough, and the count has a price.** Up to three references on a blast
cost nothing extra; four or five raise the price of every blast you run afterwards, and Wonka shows
you the quote before running one. When more than one sheet exists, Wonka checks that shared facts
agree across all of them and settles a conflict by re-measuring the source photo. The complete-product
sheet is the primary sheet, and the order you approve in does not matter: approving it replaces your
listing photos inside Genrupt, and from then on the machine sees your sheets and nothing else: the
primary, plus any extra sheet attached by id beside it. A blast uses the sheets you select, and it
starts with the primary alone.

### Packaging stays out of the main sheet

Normally the packaging is not included in the main sheet. Wonka keeps the packaging photos in a
separate place inside Genrupt, so they stay available for the packaging tactics on Day 5 without
bleeding into every generated image. Leaving them out does not throw them away. Only if the
packaging must appear consistently across the image set does it get treated as part of the product
or receive its own additional sheet. For most products, keep it separate.

### A kit with many small parts: the parts sheet comes before the smoke test

If your product ships with accessories, a set of bits, blades, stencils, anything a buyer counts,
the identity sheet alone is not enough. It locks the product; it says nothing about what comes
with it, and the machine fills that silence with parts it invents. On a 26-piece engraving kit the
first smoke test drew a wrench and a brush that were not in the box and 17 bits under a label
reading 15. Wonka proposes a parts sheet for such a product before the smoke test runs, one panel
per family (the engraving bits, the polishing bits, the blades, the stencils), each panel laid out
so the pieces can be counted, and when the parts ship in a tray he shows them in the tray. A
family larger than about eight is split into two labelled rows. Say yes to that sheet; it is a few
credits, and the smoke test it saves is many more.

### When the machine cannot draw a part, your photo can

Some parts are too exact for any generator: a control panel with a grid of little indicator
lights, a printed model number, a charging port that sits to one side of an end cap, the diamond
grit on a bit. The machine redraws these from your sheet every time, and every time it gets them
almost right, which on a product photo is wrong. Wonka names these parts at the start, when he
writes the product's facts, and asks you for one straight-on, well-lit photo of each. He does not
spend round after round trying to teach the machine the part. He sets your real photo of it onto
the sheet itself, and onto the finished pictures where the part is large enough to read. Your buyer sees your panel, not the machine's guess at it. If you already see Wonka
sending a second correction for the same tiny part, stop him and ask for this route.

### Approve, and stop

When you have inspected every sheet and every correction landed:

```
Approve all
```

Two words are enough, **after** you have looked. Wonka approves all the sheets, attaches them to the
plan you approved on Day 3, and then sweeps the wording of that plan against what the sheets
established. That sweep matters: a slot that still describes a part the way Day 3 guessed it would
fight the sheet in every render, and a correct sheet with an incorrect brief pulls the model in two
directions. He writes `Reference status: APPROVED (smoke test pending)`.

The sheets are approved. **The product is not locked yet.** An approved sheet still has to prove it
produces the correct product inside a real generated image. That proof is lesson 2.

---

## A note on branding before you move on

You can connect a **Brand Kit** at this point, and most people will not. It runs on one input: a real
Brand Book or Style Guide your brand already owns. If you have one, attach it to Claude and run:

```
/brand-kit
```

Wonka reads the colors, typography, tone, approved claims and avoid list out of that document,
creates a branding preset inside Genrupt and attaches it to the plan you saved on Day 3.

**No brand book? Run it anyway if you want a starting point.** Wonka will never raise branding on his
own, and he never invents one behind your back. But if you run `/brand-kit` without a guide, he asks
you one question: do you want a proposed direction for colors, typography and tone, or do you want to
run unbranded? Say no and it ends there. Say yes and everything he proposes is labelled a proposal,
reasoned from your product, your category and your buyer, and yours to accept, change or reject. Two
things stay facts either way: no claim without proof, and no logo is ever drawn.

**In the demonstration, the instructor chooses to continue without one.** Branding adds consistency,
and it can also restrain the results. That trade is a real choice every brand makes for itself, and
you can test it later by generating with branding attached and then without it.

Your logo is separate from all of this. If you gave Wonka a real logo file it was already uploaded and
connected during the sheets; if you did not, nothing is owed.

---

## Lesson 2: The Smoke Test

### Two questions, and only two

Before producing real candidates, run one small test. The smoke test creates one image for every
planned gallery slot, at the cheapest setting, straight off the plan. It is not trying to make the
final gallery. It tests two things, as cheaply and quickly as possible: did we lock the correct
product, and did we approve the correct brief.

```
run the smoke test
```

Wonka runs one low-count generation per slot, saves the round in `2-reference/smoke-test-v[N]/`,
and sends you every frame as its own full-size file. Open every one, not just the good ones.

**Before you look:** every image may come back with different colors, different fonts, and a
different visual style. Ignore that. You are not judging the typography, the colors, the final
composition, or the polish. Those get chosen later, from far more options, and judging them now
makes you throw away a good frame for a reason that has not been decided yet.

### Read one: is this my product?

Open each image at full size and inspect the product, on every frame:

| Ask | It fails when |
|---|---|
| Does it have the correct number of parts? | a part is missing or invented, or the count is wrong |
| Are the materials correct? | premium reads cheap, cheap reads premium, or one material swallows the rest |
| Are the shape and proportions correct? | a part is reshaped, stretched or shrunk |
| Does the scale feel believable? | a countertop product renders as catering equipment |
| Did the model add, remove, duplicate or invent anything? | a badge, seal or award appears that is not physically on the product |

Compare the result with the real photographs and with the approved sheets. If the product itself is
wrong, this is a Reference Sheet problem. Do not rewrite the creative idea to hide an inaccurate
product. Return to the sheets, correct the mold, approve the new version, and run the test again. If
one frame has the wrong product, the mold is loose and the other frames got lucky.

### Read two: is this the brief I wanted?

You can read a written brief many times and still find it hard to imagine what it will look like. It
is cheaper to make strategic corrections while reviewing the written brief on Day 3, but if you need
to see the idea with your own eyes, this is the place to catch what the written brief did not
reveal. Review every image in gallery order and ask:

- Is the intended message immediately clear?
- Does this image answer the buyer question assigned to it?
- Does it feel useful inside this gallery?
- Does it repeat another image?
- Is an important message still missing?

Do not comment on fonts, colors or layout. Comment on the job and the message. If a slot is
strategically wrong, tell Wonka exactly what needs to change:

```
Revise the brief for [slot number]. The current message is [describe the problem]. Change it to [the corrected message or job], update the saved plan, and rerun that smoke-test image.
```

Wonka updates the brief, updates the saved plan, and reruns only that slot. You correct the
instruction first, then test the corrected instruction, instead of generating the same wrong idea
again and hoping. "I do not want that frame at all" is also a legitimate answer: the slot is dropped
and its selling points re-mapped in the brief.

### The diagnosis, and it starts by counting the failures

Count how many frames failed before deciding what to fix. The number names the culprit.

- **The same product defect across the set**: back to the Reference Sheets. The mold is loose.
- **One frame fails while the rest hold the product**: the mold proved itself in the frames that
  passed, so do not rebuild it. Look at that slot instead. The commonest cause is the angle or the
  crop: a high or tight framing cuts part of the product out and the model loses whatever left the
  frame. Next, whether that slot's own wording describes the product differently from the sheets, and
  whether the composition forces what the frame has to prove. A frame that carries a count has to
  group, label or lay the pieces out, never fan or pile them.
- **The product is right and the message is wrong**: back to the brief.
- **A slot doing two jobs, or a job another slot already does**: that is an overlap, and it is a brief
  fix, not a generation fix.
- **Different fonts, colors or layouts**: they mean nothing at this stage.

Then fix the source and rerun **only the slots that changed**. Not the whole set, and never the same
instruction again in the hope of better luck.

### Pass, and lock

When every image passes both reads, including any slot you had rerun:

```
The smoke test passes. Lock the reference and mark the smoke test as passed.
```

Wonka writes `Reference status: LOCKED` and `Smoke test: PASS` together in `reference-sheet.md`
and records the passed test in the product status. Both lines have to be there before Day 5 will
generate anything. Now the product is truly locked, because you used the sheets to generate real
images and confirmed the product survived, and that the approved brief produces the messages you
actually wanted.

The pass is your word, never Wonka's. Silence, "ok" or "next" is not a verdict. He asks again,
naming both reads.

---

## Common mistakes, and what they look like

| Symptom | Cause | Fix |
|---|---|---|
| You approved the first sheet because most of it looked good | Politeness, or judging at full size | Zoom in beside the source photos and run all five checks. Two or three rounds is normal |
| The same defect survives two rounds | A missing photo, or an instruction that contradicts the real geometry | Take the photo, or re-check your own claim against the zoomed source. Stop rewording |
| The box shows up in every smoke-test frame | Packaging was put inside the main sheet | Keep packaging out of the main sheet. Give it its own sheet only if a slot stars it |
| One frame lost a part and you rebuilt the sheet | A single failure treated as a mold failure | Count the failures first. One bad frame is a slot problem: look at its angle and crop before anything else |
| The same defect appears across the whole set and you rewrote one slot | Fixing the mold with a sentence | A set-wide product defect is a sheet problem. Revise the sheet, approve, rerun |
| A slot's message is wrong and you asked for another image | Fixing the input with the output | Revise the brief for that slot, update the plan, rerun that one image |
| One slot keeps failing read one while the others pass | That slot's brief text describes the product differently from the sheets | Have Wonka fix that slot's wording in the plan, then rerun it |
| Day 5 refuses to generate | `reference-sheet.md` is missing `LOCKED` or `PASS` | Finish the smoke test and give the pass line in your own words |

## What good looks like

- [ ] Every version of every sheet is still on disk as `sheet-v[N].png`. Nothing was overwritten
- [ ] The approved sheets pass all five checks, zoomed in, and at least one carries a visual scale cue
- [ ] Each additional sheet has a stated role, and packaging is out of the main sheet unless you decided otherwise
- [ ] If you had a brand book or style guide: `brand-kit.md` carries the hex codes, font direction, tone and claims that the guide actually establishes, with proof or the no-claims line. If you did not: the status says `Brand kit: none` and nothing is pending
- [ ] Any preset you do have (brand styling, a logo, or both) is attached to the saved plan and Wonka read it back with the approval intact
- [ ] Every smoke-test frame was opened at full size; read one passed on every frame; read two changed the brief where it needed changing, and only that slot was rerun
- [ ] You said the pass line yourself, and `reference-sheet.md` carries `Smoke test: PASS` and `Reference status: LOCKED`

## Common questions

**The product is not in my hands. Can I still build the sheets?**
Yes, on a weaker path you approve by name: Wonka builds from your own listing gallery and customer
review photos, records the source, and warns that scale and the back of the product are the parts
most likely to drift. The smoke test then matters double. Never a competitor's photo, and never an
AI-generated image, because a reference built from a generation locks that generation's mistakes.

**Can I connect a Brand Kit before the smoke test?**
Yes, if you own a real Brand Book or Style Guide. Run `/brand-kit` after the sheets are approved and
the styling rides along into the test. Attach it later instead and Wonka says once that whatever it
adds was never smoke-tested.

**Can I skip branding entirely?**
Yes. Skipping is a recorded choice, not a gap. Wonka records it and every later room runs unbranded
without stopping to ask and without raising branding again. And if you change your mind later, run
`/brand-kit` whenever you like.

**What if I have a logo but no brand book?**
That is a common and completely normal case. Your logo is uploaded and connected in Lesson 1, on its
own. Having a logo never obliges you to build a brand kit, and Wonka will not suggest it.

**Can I change a sheet after the lock?**
Yes. A new version supersedes the old one, and the product goes back through this room. If Day 5's
inspection fails product fidelity on more than one image, that is a reference problem wearing an
image problem's clothes, and the fix is here, not in the Fixing Room.

## What Day 5 opens with

The Main Image Room. The strategy is ready, the product is locked, and the visual direction is
connected if you chose to use it. Tomorrow Wonka reads `Reference status: LOCKED` and
`Smoke test: PASS` before he generates a single candidate. The machines can no longer hallucinate
your product.

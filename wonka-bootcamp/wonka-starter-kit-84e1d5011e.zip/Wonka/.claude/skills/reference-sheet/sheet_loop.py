#!/usr/bin/env python3
"""The faithfulness loop: Wonka judges a reference sheet against the owner's photos, fixes it, and
stops at a pass or at the cap. The student's job is the approval at the end, not the rounds.

Why it routes instead of retrying (measured 24 to 29 September 2026): a Genrupt sister re-renders
every panel, so even from the clean anchor it re-rolls the finish (seven versions of an engraving
pen, seven textures; four edits never drew its nine-segment panel; a knife sister came back
mottled), while the local route (a warp, a smoothing, the owner's photo pasted in) converged
every time and cost nothing. And the agent's eye alone is not the judge: on the same pen the owner
caught, over five rounds, flaws the agent had approved. So: mechanical rows decide (sheet_measure),
each failing row has a defect CLASS, each class a fixed ladder of routes (loop.json), and the loop
climbs the ladder by what the ledger says was already tried.

Depth one, enforced here and not in prose:
  - a Genrupt sister is recorded only when its base was the ANCHOR's sheet id; a sister never
    becomes the base of another sister;
  - a local candidate is always built from a GENERATED version plus the whole recipe, in one pass
    (sheet_fix.build); a panel may come from any generated version of the same sheet;
  - every file the loop reads back is checked against the hash it recorded.

The loop does not call Genrupt: a script cannot reach the MCP. When the next step is a sister,
`next` prints exactly what to send (base id, edit instructions built from the contract's facts,
the frozen facts for `notes`), Wonka shows that text to the owner verbatim as it goes and sends
it, then `record-generator` files what came back.

  sheet_loop.py start  --contract 2-reference/anatomy.json --versions "2-reference/sheet-v*.png"
                       [--ids sheet-v1.png=<sheetId>,...] [--anchor sheet-v3.png --why "..."]
  sheet_loop.py next                         the next step: SISTER, LOCAL, or STOP, and why
  sheet_loop.py build                        build the planned local candidate and judge it
  sheet_loop.py record-generator --file 2-reference/sheet-v8.png --base-id <anchorId> --sheet-id <id>
                       --credits-before N --credits-after M [--instructions-file t.txt]
  sheet_loop.py map <file> front,back,...    the panel roles of a sheet whose panels the contract
                                             cannot place by order (a panel missing mid-strip)
  sheet_loop.py map <file> --boxes '{"front": [x0,y0,x1,y1], ...}'   boxes drawn by hand, for a layout
                                             the gutters do not show (panels inside panels)
  sheet_loop.py status                       attempts, credits, the best so far, its rows
  sheet_loop.py report                       the owner's before/after: board images + report.md
  sheet_loop.py owner --approve | --defect "<owner's words>" [--check '<row json>'] [--reset row,...]
  sheet_loop.py rejudge                      after the contract changed: judge every image again
All state lives in 2-reference/loop/ledger.jsonl, so a new session resumes where the last stopped. A product
with several sheets runs one loop per sheet: add `--loop parts` (or any short name) to every command, and that
loop lives in 2-reference/loop/parts/ with its own contract, ledger and report.
numpy and pillow only.
"""
from __future__ import annotations

import glob as _glob
import hashlib
import json
import os
import re
import shutil
import sys
import time
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import sheet_measure as sm  # noqa: E402
import sheet_fix as sf  # noqa: E402

LIMITS_FILE = HERE / "loop.json"
# the judge's own code is part of a verdict: a self-update between two judgements makes the older one stale
CODE_SHA = hashlib.sha256(b"".join((HERE / f).read_bytes() for f in ("sheet_measure.py", "sheet_fix.py", "npimage.py"))).hexdigest()[:16]
RESERVED = {"report", "boards", "main"}
DEFAULT_LIMITS = {"max_attempts": 10, "max_credits": 10, "sister_estimate_credits": 3,
                  "generator_tries_per_class": {"structure": 2, "count": 2, "colour": 1, "finish": 1, "exact_feature": 1},
                  "local_tries_per_row": 2, "finish_generator_only_if_no_version_passes": True}
# words that describe how a product LOOKS: never in Wonka's own instruction text (the words rule)
APPEARANCE = re.compile(r"\b(smooth(er|ly)?|gloss(y)?|shin(y|ier)|matte|textur(e|ed)|finish(ed)?|rippl(e|ed|ing)|wav(y|ier)|"
                        r"curv(e|ed|ature)|slant(ed)?|taper(ed|s)?|silhouette|proportion(s|ed)?|sleek|elegant|premium|"
                        r"polished|brushed|satin|sheen|looks? (like|as)|rounded|chunky|slim(mer)?)\b", re.I)


# ============================================================================= small helpers
def limits() -> dict:
    lim = json.loads(json.dumps(DEFAULT_LIMITS))
    try:
        data = json.loads(LIMITS_FILE.read_text())
        for k, v in data.items():
            if k == "_":
                continue
            if isinstance(v, dict) and isinstance(lim.get(k), dict):
                lim[k].update(v)
            else:
                lim[k] = v
    except Exception:
        pass
    return lim


def file_sha(path) -> str:
    """sha256 of the decoded pixels (a renamed or re-saved file with the same picture is the same)."""
    im = Image.open(path).convert("RGB")
    h = hashlib.sha256()
    h.update(f"{im.size[0]}x{im.size[1]}".encode()); h.update(im.tobytes())
    return h.hexdigest()


def lint_words(text: str) -> list:
    """Sentences that describe appearance in Wonka's own words. The one exception is the owner's
    own sentence, said over a photo, quoted verbatim and marked (owner's words); a tag without the
    owner's quoted words is still Wonka's sentence."""
    bad = []
    for sent in re.split(r"(?<=[.;!?])\s+", text or ""):
        low = sent.lower()
        quoted = re.search(r'["\u201c][^"\u201d]{2,}["\u201d]', sent) is not None
        owners = ("owner's words" in low or "owner said" in low) and quoted
        if APPEARANCE.search(sent) and not owners:
            bad.append(sent.strip())
    return bad


def score(rows: dict) -> tuple:
    """Lower is better: failing gated rows, then failing rows of any kind, then how rippled."""
    gated = sum(1 for r in rows.values() if r.get("status") == "FAIL")
    any_ = sum(1 for r in rows.values() if r.get("status") in ("FAIL", "WARN"))
    rip = sum(float(r.get("ratio_rel") or 0) for r in rows.values() if r.get("recipe") == "finish")
    return (gated, any_, round(rip, 3))


# ============================================================================= the ledger
class Loop:
    """One sheet's loop. A product with several sheets (identity, parts, a working state) runs one
    loop per sheet: `main` lives in 2-reference/loop/, any other name in 2-reference/loop/<name>/."""

    def __init__(self, ref_dir: Path, name: str = "main"):
        self.ref = Path(ref_dir)
        self.name = name or "main"
        if not re.fullmatch(r"[a-z0-9][a-z0-9_-]{0,30}", self.name):
            raise ValueError(f"--loop {self.name!r}: a short lower-case name (letters, digits, - or _)")
        self.dir = self.ref / "loop" if self.name == "main" else self.ref / "loop" / self.name
        self.path = self.dir / "ledger.jsonl"
        self.events = []
        if self.path.exists():
            for line in self.path.read_text().splitlines():
                if line.strip():
                    try:
                        self.events.append(json.loads(line))
                    except json.JSONDecodeError:
                        continue
        self.lim = limits()
        for ev in self.events:
            if ev.get("event") == "extend":          # the owner's one go-ahead past the cap, with the number
                self.lim["max_attempts"] = int(self.lim["max_attempts"]) + int(ev.get("attempts") or 0)
                self.lim["max_credits"] = float(self.lim["max_credits"]) + float(ev.get("credits") or 0)

    # ---- writing
    def add(self, ev: dict) -> dict:
        ev = dict(ev)
        ev.setdefault("ts", time.strftime("%Y-%m-%dT%H:%M:%S"))
        self.dir.mkdir(parents=True, exist_ok=True)
        with open(self.path, "a") as f:
            f.write(json.dumps(ev, ensure_ascii=False, default=str) + "\n")
        self.events.append(ev)
        return ev

    # ---- reading
    def latest(self, kind):
        for ev in reversed(self.events):
            if ev.get("event") == kind:
                return ev
        return None

    @property
    def start(self):
        return self.latest("start")

    def contract_path(self) -> Path:
        rel = getattr(self, "_contract", None) or self.start["contract"]
        return Path(rel) if Path(rel).is_absolute() else self.ref.parent / rel

    def contract(self) -> dict:
        return json.loads(self.contract_path().read_text())

    def rel(self, p) -> str:
        try:
            return str(Path(p).resolve().relative_to(self.ref.parent.resolve()))
        except ValueError:
            return str(Path(p).resolve())

    def abs(self, rel) -> Path:
        p = Path(rel)
        return p if p.is_absolute() else self.ref.parent / p

    def maps(self) -> dict:
        out = {}
        for ev in self.events:
            if ev.get("event") == "map":
                out[ev["sha"]] = ev["roles"]
        return out

    def contract_sha(self) -> str:
        return hashlib.sha256(self.contract_path().read_bytes()).hexdigest()

    def current(self) -> list:
        """The events of the loop as it stands: everything after the latest start (a --restart opens
        a fresh loop; the older events stay in the ledger as history)."""
        idx = 0
        for i, ev in enumerate(self.events):
            if ev.get("event") == "start":
                idx = i
        # judgements written while start was judging the versions come just before it
        j = idx
        while j > 0 and self.events[j - 1].get("event") == "judge" and self.events[j - 1].get("kind") == "version":
            j -= 1
        return self.events[j:]

    def images(self, any_contract: bool = False) -> list:
        """Every judged image in this loop, newest judgement per sha, under the CURRENT contract and
        the CURRENT judge code (a row added, a target changed or a self-update makes older verdicts stale)."""
        cur = None if any_contract else self.contract_sha()
        seen = {}
        for ev in self.current():
            if ev.get("event") != "judge":
                continue
            if cur is None or (ev.get("contract_sha") == cur and ev.get("code_sha") == CODE_SHA):
                if ev["sha"] in seen and seen[ev["sha"]].get("kind") in ("version", "generator") and ev.get("kind") == "local":
                    continue                       # a local judgement never takes over a generated version's identity
                seen[ev["sha"]] = ev
        return list(seen.values())

    def generated(self) -> list:
        return [im for im in self.images() if im.get("kind") in ("version", "generator")]

    def attempts(self) -> list:
        return [ev for ev in self.current() if ev.get("event") in ("generator", "local")]

    def credits_used(self) -> float:
        return float(sum(ev.get("credits") or 0 for ev in self.current() if ev.get("event") == "generator"))

    def anchor(self) -> dict:
        a = dict(self.start["anchor"])
        if not a.get("sheet_id"):
            for ev in self.events:
                if ev.get("event") == "ids":
                    a["sheet_id"] = ev["ids"].get(Path(a["file"]).name) or a.get("sheet_id")
        return a

    def stopped(self):
        """The most recent stop that no later attempt or owner finding reopened."""
        for ev in reversed(self.events):
            if ev.get("event") in ("generator", "local", "owner_defect", "judge"):
                return None
            if ev.get("event") == "stop":
                return ev
        return None


# ============================================================================= judging
def judge_file(loop: Loop, path: Path, kind: str, extra: dict | None = None) -> dict:
    c = loop.contract()
    sha = file_sha(path)
    pmap = loop.maps().get(sha)
    out_dir = loop.dir / "boards" / sha[:12]
    zone_hint = (extra or {}).get("zone_hint")
    ok, rows, info = sm.judge(c, path, pmap, out_dir, loop.contract_path().parent, zone_hint=zone_hint)
    ev = {"event": "judge", "file": loop.rel(path), "sha": sha, "kind": kind, "ok": ok, "rows": rows, "info": info,
          "score": list(score(rows)), "contract_sha": loop.contract_sha(), "code_sha": CODE_SHA}
    for r in rows.values():
        if r.get("board"):
            r["board"] = loop.rel(r["board"])           # boards are found again from any working folder
    if extra:
        ev.update({k: v for k, v in extra.items() if k != "zone_hint"})
    return loop.add(ev)


def print_rows(rows: dict):
    for k, r in rows.items():
        print(f"  {r['status']:5s} {k:24s} [{r['class']}] {r['note']}")


# ============================================================================= the router
def _checks(contract):
    return {c["name"]: c for c in (contract.get("fidelity") or {}).get("checks", [])}


def _row_fails(r):
    return r.get("status") in ("FAIL", "WARN")


def _role_rows(rows: dict, role: str) -> list:
    return [r for r in rows.values() if r.get("panel") == role]


def _role_score(rows: dict, role: str) -> tuple:
    rr = {r["name"]: r for r in _role_rows(rows, role)}
    if not rr:
        return (0, 0, 0.0)
    if any(r.get("missing_panel") for r in rr.values()):
        return (99, 99, 99.0)
    return score(rr)


def _local_tries(loop: Loop, name: str) -> int:
    """How many local candidates already carried an operation for this row and still failed it,
    counted from the owner's last word on that row (a new photo, an accepted soft paste)."""
    n = 0
    for ev in loop.events:
        if ev.get("event") == "owner_defect" and name in (ev.get("reset") or []):
            n = 0
            continue
        if ev.get("event") != "local":
            continue
        if name not in (ev.get("targets") or []):
            continue
        j = next((e for e in reversed(loop.events) if e.get("event") == "judge" and e.get("sha") == ev.get("sha")), None)
        if j and _row_fails(j["rows"].get(name, {})):
            n += 1
    return n


def _generator_tries(loop: Loop, cls: str) -> int:
    return sum(1 for ev in loop.events if ev.get("event") == "generator" and cls in (ev.get("classes") or []))


def plan(loop: Loop, estimate=None) -> dict:
    """The next step. Returns dict(action: SISTER | LOCAL | STOP, why, ...). `estimate` is the live
    finalCreditsCost of one sister, read just before; without it the loop.json figure stands in and
    the plan says so."""
    lim = loop.lim
    c = loop.contract()
    checks = _checks(c)
    expect = list((c.get("fidelity") or {}).get("panels", {}).get("expect") or [])
    att = loop.attempts()
    imgs = loop.images()
    if not imgs:
        if loop.images(any_contract=True):
            return {"action": "STOP", "why": "the contract changed since the last judgement: run `sheet_loop.py rejudge`", "stale": True}
        return {"action": "STOP", "why": "nothing judged yet: run start first"}
    best = min(imgs, key=lambda im: tuple(im["score"]))
    if not best["rows"]:
        return {"action": "STOP", "why": "the contract has no rows: nothing was measured, so nothing can be called a pass"}
    unmeasurable = [k for k, r in best["rows"].items() if r.get("error") and not r.get("missing_panel")]
    failing = {k: r for k, r in best["rows"].items() if _row_fails(r) and k not in unmeasurable}
    if not failing:
        why = "every row passes on the best candidate: ready for the owner"
        if unmeasurable:
            why = f"every row that could be measured passes; {', '.join(unmeasurable)} could not be measured (drop or fix the row, 4a2)"
        return {"action": "STOP", "why": why, "ready": not unmeasurable, "best": best["file"], "unmeasurable": unmeasurable}

    if len(att) >= int(lim["max_attempts"]):
        return {"action": "STOP", "why": f"the attempt cap: {len(att)} of {lim['max_attempts']} used", "cap": "attempts",
                "rows": sorted(failing), "best": best["file"]}
    gens = loop.generated()
    anchor = loop.anchor()
    credits_left = float(lim["max_credits"]) - loop.credits_used()
    typed = estimate is None
    est = float(lim.get("sister_estimate_credits", 3)) if typed else float(estimate)

    # ---- 1. the paid route first, only for classes only a generator can fix, and only from the anchor
    sister_rows = []
    for name, r in failing.items():
        cls = r.get("class") or "other"
        chk = checks.get(name, {})
        fixed_somewhere = any(not _row_fails(g["rows"].get(name, {"status": "FAIL"})) for g in gens)
        if r.get("missing_panel") and any(r.get("panel") in g["info"]["roles"] for g in gens):
            continue                                      # another generated version has that panel: transplant it, free
        if cls in ("structure", "count") or (cls == "colour" and chk.get("material")) \
                or (cls == "exact_feature" and not chk.get("crop")) \
                or (cls == "finish" and not fixed_somewhere and _local_tries(loop, name) >= int(lim["local_tries_per_row"])):
            if fixed_somewhere:
                continue                                  # a generated version already passes it: transplant it, free
            cap = int(lim["generator_tries_per_class"].get(cls, 0))
            if _generator_tries(loop, cls) >= cap:
                continue
            sister_rows.append((name, cls))
    if sister_rows:
        why_not = None
        if not anchor.get("sheet_id"):
            why_not = "the anchor has no Genrupt sheet id on record (sheet_loop.py start --ids), so no sister can be asked for"
        elif credits_left < est:
            why_not = f"the credit cap: {loop.credits_used():g} of {lim['max_credits']} used, and the next sister is {est:g}"
        elif est > 10:
            why_not = f"one sister at {est:g} credits is above the factory's 10-credit small-spend floor: it needs the owner's go-ahead with that number"
        if why_not is None:
            facts = []
            for name, cls in sister_rows:
                f = checks.get(name, {}).get("fact")
                if f and f not in facts:
                    facts.append(f)
            # a row that fails only because its panel is missing is covered by the panel row's fact
            missing = [n for n, _ in sister_rows if not checks.get(n, {}).get("fact") and not best["rows"].get(n, {}).get("missing_panel")]
            if missing or not facts:
                missing = missing or [n for n, _ in sister_rows]
                return {"action": "STOP", "why": f"a sister is the route for {', '.join(missing)}, but the contract has no `fact` for "
                        f"them: write each as a fact (counts, positions, materials), then `rejudge` and `next`", "rows": missing}
            text = " ".join(facts)
            frozen = (c.get("fidelity") or {}).get("frozen_facts", "")
            return {"action": "SISTER", "rows": [n for n, _ in sister_rows], "classes": sorted({cl for _, cl in sister_rows}),
                    "base_id": anchor["sheet_id"], "base_file": anchor["file"],
                    "editInstructions": text, "notes": frozen,
                    "lint": lint_words(text) + lint_words(frozen),
                    "estimate_credits": est, "estimate_is_live": not typed, "credits_left": credits_left,
                    "confirm": [n for n, _ in sister_rows if not best["rows"].get(n, {}).get("gated")],
                    "why": "a part only the generator can add or count: ONE sister from the anchor, never from a sister. "
                           + ("Read the live finalCreditsCost and run `next --estimate [it]` first. " if typed else "")
                           + "Rows under `confirm` only warn: look at each at 3x, and drop a row that misreads the product (then rejudge) instead of paying for it."}
        # the paid route is closed for these rows; they go to the report unless a transplant covers them
        closed = {"rows": [n for n, _ in sister_rows], "why": why_not}
    else:
        closed = None

    # ---- 2. the free route: the best panel per role from any generated version, then local operations
    if not gens:
        return {"action": "STOP", "why": "no generated version judged", "closed": closed}
    # the base is the ANCHOR: every attempt starts from the clean anchor, panels come in from the others
    base = next((g for g in gens if g["sha"] == anchor["sha"]), None) or min(gens, key=lambda g: tuple(g["score"]))
    base_roles = set(base["info"]["roles"])
    prev = None
    if best.get("kind") == "local":
        prev = next((e for e in reversed(loop.events) if e.get("event") == "local" and e.get("sha") == best["sha"]), None)
    if prev is not None and any(any(not _row_fails(g["rows"].get(n, {"status": "FAIL"})) for g in gens) for n in failing):
        prev = None            # a generated version now passes an open row: re-pick every panel from all of them
    if prev is not None:
        # keep what made the best candidate pass; change only the operations of rows it still fails
        recipe = [dict(o) for o in prev["recipe"]]
        notes = [f"from candidate {prev['n']}: keeps its operations, changes only what it still fails"]
        rows_src = {name: (r, r.get("panel")) for name, r in best["rows"].items()}
    else:
        recipe, notes = [], []
        chosen = {}
        for role in expect:
            cands = [g for g in gens if role in g["info"]["roles"]]
            if not cands:
                continue
            pick = min(cands, key=lambda g: (_role_score(g["rows"], role), g["sha"] != base["sha"]))
            chosen[role] = pick
            if pick["sha"] != base["sha"]:
                pf = {"op": "panel_from", "role": role, "source": pick["file"]}
                if loop.maps().get(pick["sha"]) is not None:
                    pf["source_map"] = loop.maps()[pick["sha"]]
                recipe.append(pf)
                notes.append(f"panel '{role}' from {Path(pick['file']).name} ({'replaces' if role in base_roles else 'adds'} the base's)")
        rows_src = {}
        for role, src in chosen.items():
            for name, r in src["rows"].items():
                if r.get("panel") == role:
                    rows_src[name] = (r, role)
    targets, exhausted = [o["row"] for o in recipe if o.get("row")], []
    for name, (r, role) in rows_src.items():
        if not _row_fails(r) or role is None:
            continue
        chk = checks.get(name, {})
        cls = r.get("class") or "other"
        if r.get("missing_panel"):
            exhausted.append(name)
            continue
        tries = _local_tries(loop, name)
        if tries >= int(lim["local_tries_per_row"]):
            exhausted.append(name)
            continue
        op = None
        # every further try changes something (a softer colour match and a tighter fit, a stronger
        # smoothing); the cap above, not repetition, is what ends the ladder
        if cls == "exact_feature" and chk.get("crop"):
            op = {"op": "paste_zone", "role": role, "crop": chk["crop"], "params": chk.get("params") or {}, "row": name}
            for k in ("max_upscale", "match", "feather", "crop_params"):
                if k in chk:
                    op[k] = chk[k]
            if tries:
                op["match"] = round(max(0.0, 0.6 - 0.3 * tries), 2); op["inset"] = round(0.02 * tries, 2)
        elif cls == "finish":
            op = {"op": "smooth_finish", "role": role, "along": (chk.get("params") or {}).get("along", [0.2, 0.8]),
                  "axis": (chk.get("params") or {}).get("axis"), "strength": round(1.0 + 0.5 * tries, 2), "row": name}
        elif cls == "proportion" and chk.get("warp_points"):
            op = {"op": "warp_along", "role": role, "points": chk["warp_points"], "row": name}
        # straighten, recolor and remove_mark stay out of the automatic ladder until their review
        # findings are fixed (October 2026): an outline, a colour or a mark goes to the report with
        # its manual route, and runs only as a recipe Wonka builds on the owner's word
        if op is None:
            exhausted.append(name)
            continue
        recipe = [o for o in recipe if o.get("row") != name] + [op]
        targets.append(name)
    same = prev is not None and prev["recipe"] == recipe
    last = loop.latest("local")
    same = same or (last is not None and last.get("recipe") == recipe and last.get("base_sha") == base["sha"])
    if recipe and not same:
        return {"action": "LOCAL", "base": base["file"], "base_sha": base["sha"], "recipe": recipe,
                "targets": sorted(set(targets)), "notes": notes, "exhausted": exhausted, "closed": closed,
                "why": "free, deterministic, from the anchor: the best panel of each role, then the operations each failing row's class calls for"}
    leftovers = sorted(set(exhausted + (closed["rows"] if closed else []) + [n for n in failing if n not in targets]))
    return {"action": "STOP", "why": "every route the ladder allows for the failing rows has been tried", "rows": leftovers,
            "closed": closed, "best": best["file"]}


PROPOSALS = {
    "structure": "a new photo of the missing view, sent as a source for one more sister, or a fresh sheet from the photos with additionalSheet: true",
    "count": "a composition that forces the count (a tray, labelled rows), a real photo of the parts laid out, or dropping the number from the image",
    "exact_feature": "a closer, evenly lit, head-on photo of the part; until then the sheet keeps it plain and the finished frames get the photo pasted in",
    "finish": "accept the closest version, or a fresh sheet from the photos with additionalSheet: true (a sister re-rolls the finish)",
    "outline": "a local redraw measured off the photo; or, when the board shows the row misreads this product, dropping the row with a note (4a2)",
    "colour": "a photo of the part in neutral light, or the owner's word on the colour",
    "proportion": "the ratio measured on two photos, then a local warp",
    "mark": "the box of the mark, then a local fill",
}


# ============================================================================= the report
def _thumb(im: Image.Image, h: int) -> Image.Image:
    im = im.convert("RGB")
    return im.resize((max(1, int(im.size[0] * h / im.size[1])), h), Image.LANCZOS)


def write_report(loop: Loop) -> dict:
    """The owner's before/after: one board per row (the photo, the anchor, the best candidate),
    the full sheets side by side, and report.md for Wonka to relay in plain words."""
    c = loop.contract()
    checks = _checks(c)
    imgs = loop.images()
    best = min(imgs, key=lambda im: tuple(im["score"]))
    anchor_ev = next((im for im in imgs if im["sha"] == loop.anchor()["sha"]), None)
    out = loop.dir / "report"
    out.mkdir(parents=True, exist_ok=True)
    boards = []
    for name, chk in checks.items():
        r_best = best["rows"].get(name, {})
        r_anc = (anchor_ev or {}).get("rows", {}).get(name, {})
        tiles, labels = [], []
        real = chk.get("crop") or (chk.get("real") or {}).get("crop")
        if real and loop.abs(Path(loop.start["contract"]).parent / real).exists():
            tiles.append(_thumb(Image.open(loop.abs(Path(loop.start["contract"]).parent / real)), 360)); labels.append("the owner's photo")
        for tag, r in (("anchor", r_anc), ("now", r_best)):
            if r.get("board") and loop.abs(r["board"]).exists():
                tiles.append(_thumb(Image.open(loop.abs(r["board"])), 360)); labels.append(f"{tag}: {r.get('status')}")
        if not tiles:
            continue
        W = sum(t.size[0] for t in tiles) + 12 * (len(tiles) + 1)
        board = Image.new("RGB", (max(W, 560), 410), "white")
        d = ImageDraw.Draw(board)
        d.text((12, 6), f"{name}  [{r_best.get('class', chk.get('class', ''))}]  {r_best.get('status', '')}", fill=(43, 20, 57))
        x = 12
        for t, lab in zip(tiles, labels):
            board.paste(t, (x, 40)); d.text((x, 24), lab, fill=(107, 90, 69)); x += t.size[0] + 12
        p = out / f"row-{name}.png"
        board.save(p)
        boards.append(str(p))
    # the two sheets side by side
    a_img = Image.open(loop.abs(loop.anchor()["file"]))
    b_img = Image.open(loop.abs(best["file"]))
    pair = Image.new("RGB", (a_img.size[0] // 2 + b_img.size[0] // 2 + 20, max(a_img.size[1], b_img.size[1]) // 2), "white")
    pair.paste(_thumb(a_img, pair.size[1]), (0, 0)); pair.paste(_thumb(b_img, pair.size[1]), (a_img.size[0] // 2 + 20, 0))
    pair.save(out / "sheets-before-after.png")
    st = loop.stopped() or {}
    att = loop.attempts()
    lines = [f"# Faithfulness loop . {time.strftime('%Y-%m-%d')}", "",
             f"- Anchor: {loop.anchor()['file']} ({loop.anchor().get('why', 'chosen at start')})",
             f"- Best now: {best['file']}",
             f"- Attempts: {len(att)} of {loop.lim['max_attempts']}; credits: {loop.credits_used():g} of {loop.lim['max_credits']} (balance delta, as recorded)",
             f"- Stopped because: {st.get('why', 'not stopped yet')}", "", "## Rows on the best candidate", ""]
    for name, r in best["rows"].items():
        lines.append(f"- {r['status']} {name} [{r['class']}]: {r['note']}")
    left = [n for n, r in best["rows"].items() if _row_fails(r)]
    pasted, refused = {}, {}
    loc = next((e for e in reversed(loop.events) if e.get("event") == "local" and e.get("sha") == best["sha"]), None)
    planned = [o for o in (loc or {}).get("recipe", []) if o["op"] == "paste_zone"]
    done = [o for o in (loc or {}).get("ops", []) if o.get("op") == "paste_zone"]
    for plan_op, did in zip(planned, done):
        if did.get("refused"):
            refused[plan_op.get("row")] = did["refused"]
        else:
            pasted.setdefault(plan_op["role"], set()).add(plan_op["crop"])
    if left:
        lines += ["", "## What is still open, and the route I propose", ""]
        for n in left:
            r = best["rows"][n]
            cls = r.get("class", "other")
            chk = checks.get(n, {})
            if n in refused and "prints soft" in refused[n]:
                lines.append(f"- {n} [{cls}]: the owner's photo could not go in: {refused[n]}. A closer photo of the part; or, on the "
                             f"owner's word that a softer paste is fine until one exists, that row's max_upscale set to the enlargement printed here")
            elif n in refused:
                lines.append(f"- {n} [{cls}]: the paste was refused: {refused[n]}. Check the row's search window and the crop, "
                             f"or draw the panel's box by hand (map --boxes), then rejudge")
            elif chk.get("crop") and chk["crop"] in pasted.get(r.get("panel"), set()):
                lines.append(f"- {n} [{cls}]: this part on the sheet is the owner's photo now, so what the row still reports most likely "
                             f"sits in the photo itself (a hair, a scratch, a reflection): look at its board; a cleaner, evenly lit photo would fix it")
            else:
                lines.append(f"- {n} [{cls}]: {PROPOSALS.get(cls, 'the owner decides')}")
    lines += ["", "## Every attempt", ""]
    for ev in att:
        if ev["event"] == "generator":
            lines.append(f"- {ev['n']}. sister of the anchor -> {ev['file']} ({ev.get('credits')} credits)")
        else:
            lines.append(f"- {ev['n']}. local from {Path(ev['base']).name}: " + ", ".join(o["op"] + "(" + o.get("role", "") + ")" for o in ev["ops"]) + f" -> {ev['out']}")
    (out / "report.md").write_text("\n".join(lines) + "\n")
    return {"boards": boards, "pair": str(out / "sheets-before-after.png"), "md": str(out / "report.md"), "best": best["file"]}


# ============================================================================= commands
def cmd_start(args) -> int:
    contract = Path(args["--contract"])
    ref = contract.parent
    loop = Loop(ref, args.get("--loop") or "main")
    if loop.start and not args.get("--restart"):
        print(f"a loop is already open in {loop.path} (started {loop.start['ts']}); `status` shows it. "
              f"Pass --restart to open a new one beside it (the ledger keeps both)."); return 2
    files = sorted((Path(f) for f in _glob.glob(args["--versions"])),
                   key=lambda p: [int(t) if t.isdigit() else t for t in re.split(r"(\d+)", p.name)])
    files = [f for f in files if "loop" not in f.parts and "corrected" not in f.name]
    if loop.name in RESERVED and loop.name != "main":
        print(f"--loop {loop.name}: that name is taken by the loop's own folders"); return 2
    held = {}
    for ledger in [loop.ref / "loop" / "ledger.jsonl"] + sorted((loop.ref / "loop").glob("*/ledger.jsonl")):
        if ledger.resolve() == loop.path.resolve() or not ledger.exists():
            continue
        for line in ledger.read_text().splitlines():
            try:
                e = json.loads(line)
            except json.JSONDecodeError:
                continue
            if e.get("event") == "judge" and e.get("sha"):
                held[e["sha"]] = "main" if ledger.parent.resolve() == (loop.ref / "loop").resolve() else ledger.parent.name
    own = {e.get("sha"): e.get("kind") for e in loop.events if e.get("event") == "judge"}
    if not files:
        print(f"no sheet matches {args['--versions']}"); return 2
    ids = {}
    for pair in (args.get("--ids") or "").split(","):
        if "=" in pair:
            k, v = pair.split("=", 1); ids[Path(k.strip()).name] = v.strip()
    loop._contract = loop.rel(contract)            # the start event is written after the versions are judged
    judged = []
    for f in files:
        sh = file_sha(f)
        if sh in held:
            print(f"refused: {f.name} already belongs to the '{held[sh]}' loop; one sheet, one loop, one cap"); return 2
        if own.get(sh) in ("generator", "local"):
            print(f"skipped {f.name}: this loop already holds it as a {'sister' if own[sh] == 'generator' else 'candidate'}, never a version")
            continue
        ev = judge_file(loop, f, "version", {"sheet_id": ids.get(f.name)})
        judged.append(ev)
        print(f"{f.name}: score {ev['score']}  ({sum(1 for r in ev['rows'].values() if _row_fails(r))} rows failing)")
    if args.get("--anchor"):
        pick = next((e for e in judged if Path(e["file"]).name == Path(args["--anchor"]).name), None)
        if pick is None:
            print(f"--anchor {args['--anchor']} is not among the versions"); return 2
        why = args.get("--why") or "chosen by Wonka"
    else:
        pick = min(judged, key=lambda e: tuple(e["score"]))
        why = "the best score on disk (fewest failing rows, then the least rippled finish), which is not always the newest"
    anchor = {"file": pick["file"], "sha": pick["sha"], "sheet_id": ids.get(Path(pick["file"]).name), "why": why}
    loop.add({"event": "start", "contract": loop.rel(contract), "anchor": anchor, "limits": loop.lim,
              "versions": [{"file": e["file"], "sha": e["sha"], "score": e["score"]} for e in judged]})
    loop._contract = None
    print(f"anchor: {anchor['file']} ({why})" + ("" if anchor["sheet_id"] else "  [no Genrupt id on record: sisters are closed until --ids gives one]"))
    return 0


def cmd_next(args) -> int:
    loop = _open(args)
    p = plan(loop, args.get("--estimate"))
    print(json.dumps(p, indent=1, ensure_ascii=False, default=str))
    if p["action"] == "STOP":
        loop.add({"event": "stop", **{k: v for k, v in p.items() if k != "action"}})
    return 0


def cmd_build(args) -> int:
    loop = _open(args)
    p = plan(loop)
    if args.get("--recipe"):
        recipe = json.loads(Path(args["--recipe"]).read_text())
        base = args.get("--base") or p.get("base") or loop.anchor()["file"]
        p = {"action": "LOCAL", "recipe": recipe, "base": base, "targets": [o.get("row") for o in recipe if o.get("row")]}
    if p["action"] != "LOCAL":
        print(f"the next step is {p['action']}, not a local build: {p['why']}"); return 2
    if len(loop.attempts()) >= int(loop.lim["max_attempts"]):
        print(f"the attempt cap: {len(loop.attempts())} of {loop.lim['max_attempts']} used; past it only with the owner's word (owner --extend-attempts)"); return 2
    base = loop.abs(p["base"])
    gen = {g["sha"]: g for g in loop.generated()}
    base_sha = file_sha(base)
    if base_sha not in gen:
        print(f"{p['base']} is not a generated version this loop judged: a candidate is never built on a candidate"); return 2
    run_recipe = json.loads(json.dumps(p["recipe"]))     # the ledger keeps the recipe as planned (product-relative)
    for op in run_recipe:
        if op["op"] == "panel_from":
            src = loop.abs(op["source"])
            if not src.exists() or file_sha(src) not in gen:
                print(f"panel_from {op['source']}: not a generated version this loop judged; panels come only from generated versions"); return 2
            op["source"] = str(src.resolve())
    n = len(loop.attempts()) + 1
    out = loop.dir / f"candidate-{n:02d}.png"
    cpath = loop.contract_path()
    rec = sf.build(base, run_recipe, loop.contract(), out, cpath.parent, loop.maps().get(base_sha))
    sha = file_sha(out)
    earlier = {im["sha"] for im in loop.images(any_contract=True) if im.get("kind") == "local"}
    if sha in gen or sha in earlier:
        # every operation was refused: the "candidate" is a generated version's own pixels, never a correction
        out.unlink()
        out.with_name(out.stem + "-regions.png").unlink(missing_ok=True)
        loop.add({"event": "local", "n": n, "base": loop.rel(base), "base_sha": base_sha, "recipe": p["recipe"],
                  "targets": p.get("targets") or [], "ops": rec["ops"], "out": None, "sha": sha, "unchanged": True})
        print(f"build {n} made no new picture (every operation was refused, or it repeats an earlier candidate); no candidate:")
        for o in rec["ops"]:
            if o.get("refused"):
                print(f"  refused {o['op']} on {o.get('role')}: {o['refused']}")
        return 0
    hints = {}
    crops = {o.get("row"): o.get("crop") for o in p["recipe"] if o["op"] == "paste_zone"}
    for o, src in zip([o for o in rec["ops"] if o.get("op") == "paste_zone"], [o for o in p["recipe"] if o["op"] == "paste_zone"]):
        if o.get("quad"):
            hints.setdefault(o["role"], {})[src["crop"]] = o["quad"]
    loop.add({"event": "local", "n": n, "base": loop.rel(base), "base_sha": base_sha, "recipe": p["recipe"],
              "targets": p.get("targets") or [], "ops": rec["ops"], "out": loop.rel(out), "sha": sha, "zone_hint": hints})
    if rec.get("boxes"):
        loop.add({"event": "map", "file": loop.rel(out), "sha": sha, "roles": rec["boxes"], "from_build": n})
    ev = judge_file(loop, out, "local", {"attempt": n, "zone_hint": hints})
    print(f"candidate {n}: {loop.rel(out)}  score {ev['score']}")
    print_rows(ev["rows"])
    return 0


def cmd_record_generator(args) -> int:
    loop = _open(args)
    anchor = loop.anchor()
    if not anchor.get("sheet_id"):
        print("the anchor has no Genrupt sheet id on record; a sister cannot be checked against it"); return 2
    if args.get("--base-id") != anchor["sheet_id"]:
        print(f"refused: the sister's base was {args.get('--base-id')!r}, the anchor is {anchor['sheet_id']!r}. "
              f"Every sister comes from the anchor, never from another sister (depth one)."); return 2
    f = Path(args["--file"])
    if not f.exists():
        print(f"{f}: no such file"); return 2
    sha_new = file_sha(f)
    if any(ev.get("sha") == sha_new for ev in loop.events if ev.get("event") in ("judge", "generator", "local")):
        print(f"refused: {f.name} holds pixels this loop already has (a version, a sister or a candidate); a sister is a new render from the anchor"); return 2
    p = plan(loop, args.get("--estimate"))
    if p["action"] != "SISTER" and not args.get("--outside-plan"):
        print(f"refused: the loop did not ask for a sister ({p['action']}: {p['why']}). A spend outside the plan is recorded only with --outside-plan \"why\""); return 2
    est = float(p.get("estimate_credits") or loop.lim.get("sister_estimate_credits", 3))
    cb, ca = args.get("--credits-before"), args.get("--credits-after")
    try:
        credits = float(cb) - float(ca)
        if not np.isfinite(credits) or credits < 0:
            raise ValueError
        note = None
    except (TypeError, ValueError):
        credits, note = est, f"the balance was not read cleanly before and after ({cb!r}, {ca!r}); counted at the estimate {est:g}"
    n = len(loop.attempts()) + 1
    text = Path(args["--instructions-file"]).read_text() if args.get("--instructions-file") else p.get("editInstructions")
    loop.add({"event": "generator", "n": n, "base_id": anchor["sheet_id"], "file": loop.rel(f), "sha": sha_new, "credit_note": note,
              "outside_plan": args.get("--outside-plan"),
              "sheet_id": args.get("--sheet-id"), "credits": credits, "credits_before": cb, "credits_after": ca,
              "classes": p.get("classes") or [], "rows": p.get("rows") or [], "instructions": text,
              "notes": p.get("notes")})
    ev = judge_file(loop, f, "generator", {"attempt": n, "sheet_id": args.get("--sheet-id")})
    print(f"sister {n}: {loop.rel(f)}  score {ev['score']}  credits {credits:g}" + (f"  ({note})" if note else ""))
    print_rows(ev["rows"])
    return 0


def cmd_rejudge(args) -> int:
    loop = _open(args)
    done = 0
    for im in loop.images(any_contract=True):
        f = loop.abs(im["file"])
        if f.exists() and file_sha(f) == im["sha"]:
            hint = next((e.get("zone_hint") for e in loop.events if e.get("event") == "local" and e.get("sha") == im["sha"]), None)
            judge_file(loop, f, im["kind"], {"attempt": im.get("attempt"), "zone_hint": hint, "rejudged": True})
            done += 1
    print(f"re-judged {done} images under the current contract"); return 0


def cmd_map(args, pos) -> int:
    """The panel roles of one sheet: names for the boxes found, in order (`front,back,...`), or the
    boxes themselves drawn by hand (`--boxes '{"front": [x0, y0, x1, y1], ...}'`, fractions) for a
    layout the gutters do not show."""
    loop = _open(args)
    f = Path(pos[0])
    if args.get("--boxes"):
        roles = json.loads(args["--boxes"])
        if not isinstance(roles, dict) or not all(isinstance(v, list) and len(v) == 4 for v in roles.values()):
            print("--boxes wants {\"role\": [x0, y0, x1, y1], ...} as fractions of the sheet"); return 2
    elif len(pos) > 1:
        roles = [s.strip() for s in pos[1].split(",")]
    else:
        print("map needs the roles in order (front,back,...) or --boxes"); return 2
    sha = file_sha(f)
    loop.add({"event": "map", "file": loop.rel(f), "sha": sha, "roles": roles})
    prev = next((im for im in loop.images(any_contract=True) if im["sha"] == sha), None)
    kind = prev["kind"] if prev else "version"
    ev = judge_file(loop, f, kind, {"remapped": True})
    print(f"{f.name}: panels are {roles}; judged again, score {ev['score']}"); return 0


def cmd_status(args) -> int:
    loop = _open(args)
    imgs = loop.images()
    if not imgs:
        print("nothing judged under the current contract and code: run rejudge"); return 2
    best = min(imgs, key=lambda im: tuple(im["score"]))
    print(f"anchor: {loop.anchor()['file']}  ({loop.anchor().get('why')})")
    print(f"attempts: {len(loop.attempts())} of {loop.lim['max_attempts']}; credits {loop.credits_used():g} of {loop.lim['max_credits']}")
    print(f"best so far: {best['file']}  score {best['score']}")
    print_rows(best["rows"])
    st = loop.stopped()
    if st:
        print(f"stopped: {st.get('why')}")
    return 0


def cmd_report(args) -> int:
    loop = _open(args)
    if not loop.images():
        print("nothing judged under the current contract and code: run rejudge first"); return 2
    r = write_report(loop)
    best = loop.abs(r["best"])
    stem = "sheet-corrected" if loop.name == "main" else f"{loop.name}-sheet-corrected"
    k = 1
    while (loop.ref / f"{stem}-{k}.png").exists():
        k += 1
    if Path(r["best"]).resolve().parent == loop.dir.resolve():
        dest = loop.ref / f"{stem}-{k}.png"
        if not any(file_sha(p) == file_sha(best) for p in loop.ref.glob(f"{stem}-*.png")):
            shutil.copyfile(best, dest)
            r["corrected"] = loop.rel(dest)
    print(json.dumps(r, indent=1))
    return 0


def cmd_ids(args, pos) -> int:
    """Genrupt sheet ids learnt after start: `ids sheet-v1.png=<id>,sheet-v2.png=<id>`."""
    loop = _open(args)
    ids = {}
    for pair in (pos[0] if pos else "").split(","):
        if "=" in pair:
            k, v = pair.split("=", 1); ids[Path(k.strip()).name] = v.strip()
    if not ids:
        print("ids wants sheet-v[N].png=<sheet id>,..."); return 2
    loop.add({"event": "ids", "ids": ids})
    print(f"recorded {len(ids)} id(s); the anchor's id is {loop.anchor().get('sheet_id')}"); return 0


def cmd_owner(args) -> int:
    loop = _open(args)
    if args.get("--extend-attempts") or args.get("--extend-credits"):
        if not args.get("--words"):
            print("an extension past the cap needs the owner's words (--words), with the number they approved"); return 2
        loop.add({"event": "extend", "attempts": int(args.get("--extend-attempts") or 0),
                  "credits": float(args.get("--extend-credits") or 0), "words": args["--words"]})
        lp = Loop(loop.ref, loop.name)
        print(f"the owner extended this sheet's cap to {lp.lim['max_attempts']} attempts and {lp.lim['max_credits']:g} credits"); return 0
    if args.get("--approve"):
        if not args.get("--file"):
            print("--approve needs --file: the exact picture the owner saw and approved"); return 2
        f = loop.abs(args["--file"])
        if not f.exists():
            print(f"{args['--file']}: no such file"); return 2
        sha = file_sha(f)
        known = {im["sha"]: im for im in loop.images(any_contract=True)}
        if sha not in known:
            print(f"refused: {f.name} is not an image this loop judged"); return 2
        loop.add({"event": "owner_approve", "file": loop.rel(f), "sha": sha, "words": args.get("--words")})
        print(f"approved by the owner: {loop.rel(f)}"); return 0
    words = args.get("--defect")
    if not words:
        print("owner needs --approve, --defect \"<the owner's words>\" or --extend-attempts/--extend-credits with --words"); return 2
    ev = {"event": "owner_defect", "words": words,
          "reset": [r.strip() for r in (args.get("--reset") or "").split(",") if r.strip()]}
    if args.get("--check"):
        chk = json.loads(args["--check"])
        c_now = loop.contract()
        expect = (c_now.get("fidelity") or {}).get("panels", {}).get("expect") or []
        names = {x.get("name") for x in (c_now.get("fidelity") or {}).get("checks", [])}
        known_r = sm.NEW_RECIPES | sm.LEGACY_RECIPES
        problem = None
        if not isinstance(chk, dict) or not chk.get("name"):
            problem = "the row needs a name"
        elif chk["name"] in names:
            problem = f"a row named {chk['name']!r} already exists"
        elif chk.get("recipe") not in known_r:
            problem = f"no recipe {chk.get('recipe')!r} (known: {', '.join(sorted(known_r))})"
        elif chk.get("recipe") != "panel_count" and chk.get("panel", "main") not in expect and expect:
            problem = f"panel {chk.get('panel')!r} is not in panels.expect {expect}"
        if problem:
            print(f"refused, nothing written: {problem}"); return 2
        chk.setdefault("source", f"owner, {time.strftime('%Y-%m-%d')}: {words}")
        cpath = loop.contract_path()
        c = json.loads(cpath.read_text())
        c.setdefault("fidelity", {}).setdefault("checks", []).append(chk)
        cpath.write_text(json.dumps(c, indent=1, ensure_ascii=False))
        ev["check"] = chk["name"]
        # the new row is judged on every image the loop knows, so the router sees it at once
        for im in list(loop.images(any_contract=True)):
            f = loop.abs(im["file"])
            if f.exists() and file_sha(f) == im["sha"]:
                hint = next((e.get("zone_hint") for e in loop.events if e.get("event") == "local" and e.get("sha") == im["sha"]), None)
                judge_file(loop, f, im["kind"], {"attempt": im.get("attempt"), "zone_hint": hint, "rejudged_for": chk["name"]})
    loop.add(ev)
    print("recorded the owner's finding" + (f" as row {ev['check']}" if ev.get("check") else " (no row: add one with --check so the machine looks for it from now on)"))
    return 0


def _open(args) -> Loop:
    ref = Path(args.get("--ref") or "2-reference")
    loop = Loop(ref, args.get("--loop") or "main")
    if not loop.start:
        raise SystemExit(f"no loop is open in {loop.dir} (run start first)")
    return loop


class _Lock:
    def __init__(self, folder: Path):
        self.path = Path(folder) / ".lock"

    def __enter__(self):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        for _ in range(2):
            try:
                fd = os.open(str(self.path), os.O_CREAT | os.O_EXCL | os.O_WRONLY)
                os.write(fd, str(os.getpid()).encode()); os.close(fd)
                return self
            except FileExistsError:
                if time.time() - self.path.stat().st_mtime > 900:
                    self.path.unlink(missing_ok=True)       # a session that died holding it
                    continue
                raise SystemExit(f"another session is working on this loop right now ({self.path}); try again when it finishes")
        raise SystemExit(f"could not take the loop's lock ({self.path})")

    def __exit__(self, *a):
        self.path.unlink(missing_ok=True)


def _parse(argv):
    opts, pos, i = {}, [], 0
    flags = {"--approve", "--restart"}
    while i < len(argv):
        a = argv[i]
        if a.startswith("--"):
            if a in flags:
                opts[a] = True; i += 1
            else:
                opts[a] = argv[i + 1] if i + 1 < len(argv) else None; i += 2
        else:
            pos.append(a); i += 1
    return opts, pos


def main(argv) -> int:
    if not argv:
        print(__doc__); return 2
    cmd, rest = argv[0], argv[1:]
    opts, pos = _parse(rest)
    if opts.get("--product"):
        # every path in the ledger is relative to the product folder, so the loop runs from there
        prod = Path(opts["--product"])
        if not (prod / "2-reference").is_dir():
            print(f"--product {prod}: no 2-reference/ folder there"); return 2
        os.chdir(prod)
    ref = Path(opts.get("--ref") or "2-reference")
    name = opts.get("--loop") or "main"
    try:
        lock_dir = Loop(ref, name).dir
    except ValueError as e:
        print(str(e)); return 2
    if cmd in ("status",):
        return _dispatch(cmd, opts, pos)
    with _Lock(lock_dir):
        return _dispatch(cmd, opts, pos)


def _dispatch(cmd, opts, pos) -> int:
    try:
        if cmd == "start":
            if not opts.get("--contract") or not opts.get("--versions"):
                print("start needs --contract and --versions"); return 2
            return cmd_start(opts)
        if cmd == "next":
            return cmd_next(opts)
        if cmd == "build":
            return cmd_build(opts)
        if cmd == "record-generator":
            return cmd_record_generator(opts)
        if cmd == "rejudge":
            return cmd_rejudge(opts)
        if cmd == "ids":
            return cmd_ids(opts, pos)
        if cmd == "map" and pos:
            return cmd_map(opts, pos)
        if cmd == "status":
            return cmd_status(opts)
        if cmd == "report":
            return cmd_report(opts)
        if cmd == "owner":
            return cmd_owner(opts)
    except ValueError as e:
        print(str(e), file=sys.stderr); return 1
    print(__doc__); return 2


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))

"""sheet_measure.py and npimage.py: the faithfulness judge on synthetic sheets.
Run: python3 test_sheet_measure.py

No network, no scipy, no product data. Every image is drawn here: a strip of panels with gutters,
a barrel with a fine grain or a coarse ripple, a dark control panel with bright segments (one of
them split on purpose), a ring with and without a notch, an end cap with its port centred or off
to one side. Each recipe is watched to PASS on the right drawing and to FAIL on the wrong one."""
import json
import sys
import tempfile
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw

HERE = Path(__file__).parent
sys.path.insert(0, str(HERE))
import npimage as npi  # noqa: E402
import sheet_measure as sm  # noqa: E402

fails = []


def check(name, cond, detail=""):
    print(("  PASS  " if cond else "  FAIL  ") + name + ("" if cond else f"  {detail}"))
    if not cond:
        fails.append(name)


tmp = Path(tempfile.mkdtemp(prefix="sheet_measure_"))
rng = np.random.default_rng(11)
BG = 236


# ----------------------------------------------------------------------------- drawing
def barrel(w, h, ripple=0.0, grain=3.0, seed=1):
    """A blue barrel strip, full width: cylinder shading, a fine grain, and optionally a coarse
    ripple (blotches about a fifth of the width across)."""
    r = np.random.default_rng(seed)
    x = np.linspace(-1, 1, w)
    shade = 150 + 60 * (1 - x ** 2) ** 0.5
    base = np.tile(shade, (h, 1))
    base += r.normal(0, grain, (h, w))
    if ripple:
        blot = npi.gaussian(r.normal(0, 1, (h, w)), w / 10.0)
        blot = blot / (blot.std() + 1e-9) * ripple
        base += blot
    rgb = np.stack([base * 0.30, base * 0.62, base * 1.0], axis=2)
    return np.clip(rgb, 0, 255).astype(np.uint8)


def pill(w, h, cols=((0.3, 3), (0.72, 6)), split=None, ring_notch=False, lit=None, y0s=(0.36, 0.36)):
    """A dark control panel: a ring at the top, bright segments in columns below it."""
    im = Image.new("RGB", (w, h), (0, 0, 0, 0)[:3])
    a = Image.new("L", (w, h), 0)
    d = ImageDraw.Draw(im); da = ImageDraw.Draw(a)
    d.rounded_rectangle([0, 0, w - 1, h - 1], radius=w // 2, fill=(26, 26, 30))
    da.rounded_rectangle([0, 0, w - 1, h - 1], radius=w // 2, fill=255)
    cx, cy, rr = w // 2, int(h * 0.17), int(w * 0.30)
    d.ellipse([cx - rr, cy - rr, cx + rr, cy + rr], outline=(150, 150, 156), width=max(4, w // 10))
    if ring_notch:
        import math as _m
        a_ = _m.radians(135)                       # a crack straight across the ring, lower left
        d.line([(cx + (rr - 8) * _m.cos(a_), cy + (rr - 8) * _m.sin(a_)), (cx + (rr + 8) * _m.cos(a_), cy + (rr + 8) * _m.sin(a_))],
               fill=(26, 26, 30), width=3)
    sw, sh = max(4, int(w * 0.12)), max(6, int(h * 0.045))
    step = 0.085
    for ci, (fx, n) in enumerate(cols):
        for k in range(n):
            x = int(fx * w); y = int((y0s[ci] + k * step) * h)
            col = (160, 160, 165)
            d.rectangle([x - sw // 2, y, x + sw // 2, y + sh], fill=col)
            if split == (ci, k):
                d.rectangle([x - sw // 2, y + sh // 2 - 1, x + sw // 2, y + sh // 2 + 1], fill=(26, 26, 30))
    return im, a


def sheet(panels, H=900, gutter=10):
    """Panels (PIL images of height H) side by side with light gutters."""
    W = sum(p.size[0] for p in panels) + gutter * (len(panels) - 1)
    out = Image.new("RGB", (W, H), (BG, BG, BG - 2))
    x = 0
    for i, p in enumerate(panels):
        out.paste(p, (x, 0)); x += p.size[0]
        if i < len(panels) - 1:
            out.paste(Image.new("RGB", (gutter, H), (252, 252, 252)), (x, 0)); x += gutter
    return out


def pen_panel(W=260, H=900, ripple=0.0, with_pill=True, split=None, notch=False, wavy=0.0):
    p = Image.new("RGB", (W, H), (BG, BG, BG - 2))
    bw, bh = 90, 760
    b = barrel(bw, bh, ripple=ripple)
    if wavy:
        # an outline that wanders: shift rows sideways by a slow sine
        bb = np.full((bh, bw + 8, 3), (BG, BG, BG - 2), np.uint8)
        for y in range(bh):
            s = int(round(4 + wavy * np.sin(y / 23.0)))
            bb[y, s:s + bw] = b[y]
        bimg = Image.fromarray(bb); x0 = (W - bw - 8) // 2
    else:
        bimg = Image.fromarray(b); x0 = (W - bw) // 2
    p.paste(bimg, (x0, 70))
    if with_pill:
        pim, pa = pill(60, 240, split=split, ring_notch=notch)
        p.paste(pim, ((W - 60) // 2, 480), pa)
    return p


def end_panel(W=300, H=900, offset=0.0):
    p = Image.new("RGB", (W, H), (BG, BG, BG - 2))
    d = ImageDraw.Draw(p)
    cx, cy, a, b = W // 2, 470, 110, 90
    d.ellipse([cx - a, cy - b, cx + a, cy + b], fill=(20, 20, 22))
    py = int(cy - offset * b)
    d.rounded_rectangle([cx - 34, py - 11, cx + 34, py + 11], radius=10, outline=(200, 200, 205), width=4)
    return p


# ----------------------------------------------------------------------------- npimage
print("npimage")
def brute_label(m):
    """A breadth-first reference labelling (8-connected), for comparison."""
    H, W = m.shape
    lab = np.zeros((H, W), int); n = 0
    for y in range(H):
        for x in range(W):
            if m[y, x] and not lab[y, x]:
                n += 1; stack = [(y, x)]; lab[y, x] = n
                while stack:
                    cy, cx = stack.pop()
                    for dy in (-1, 0, 1):
                        for dx in (-1, 0, 1):
                            yy, xx = cy + dy, cx + dx
                            if 0 <= yy < H and 0 <= xx < W and m[yy, xx] and not lab[yy, xx]:
                                lab[yy, xx] = n; stack.append((yy, xx))
    return lab, n
same = True
for t in range(25):
    m = rng.random((rng.integers(4, 40), rng.integers(4, 40))) > rng.uniform(0.35, 0.7)
    a, n = npi.label(m); b, k = brute_label(m)
    same &= (n == k) and len(set(zip(a[m].tolist(), b[m].tolist()))) == n
check("run-length labelling matches a breadth-first reference on random masks", same)
ring = np.zeros((20, 20), bool); ring[4:16, 4:16] = True; ring[7:13, 7:13] = False
check("fill_holes fills an enclosed hole", npi.fill_holes(ring)[10, 10] and not npi.fill_holes(ring)[0, 0])
imp = np.zeros((41, 41)); imp[20, 20] = 1.0
g = npi.gaussian(imp, 3.0)
check("gaussian keeps the total and spreads by sigma", abs(g.sum() - 1.0) < 1e-6 and abs(g[20, 23] / g[20, 20] - np.exp(-0.5)) < 0.02)
box = npi.principal_box(np.pad(np.ones((60, 20), bool), 10))
check("principal_box finds a vertical major axis, 60 by 20", box and abs(box["major"] - 59) <= 1 and abs(box["minor"] - 19) <= 1)

# ----------------------------------------------------------------------------- panels
print("panels")
s3 = sheet([pen_panel(), pen_panel(), end_panel()])
boxes = sm.detect_panels(s3)
check("three panels found between two gutters", len(boxes) == 3, str(boxes))
check("no gutter, one panel", len(sm.detect_panels(Image.new("RGB", (400, 300), (BG, BG, BG)))) == 1)
# a layout the gutters do not show: two pens side by side with no gutter, boxes drawn by hand
nogut = Image.new("RGB", (520, 900), (BG, BG, BG - 2)); nogut.paste(pen_panel(with_pill=False), (0, 0)); nogut.paste(pen_panel(with_pill=False), (260, 0))
nogut.save(tmp / "nogutter.png")
c_box = {"fidelity": {"panels": {"expect": ["left", "right"]}, "checks": [{"name": "panels", "recipe": "panel_count", "target": {"count": 2}}]}}
_, rnog, _ = sm.judge(c_box, tmp / "nogutter.png")
_, rbox, ibox = sm.judge(c_box, tmp / "nogutter.png", {"left": [0, 0, 0.5, 1], "right": [0.5, 0, 1, 1]})
check("hand-drawn boxes name panels the gutters do not show", rnog["panels"]["ok"] is False and rbox["panels"]["ok"] is True
      and ibox["roles"]["right"][0] == 260, f"{rnog['panels']['note']} | {rbox['panels']['note']} | {ibox['roles']}")

# ----------------------------------------------------------------------------- finish
print("finish")
real = Image.fromarray(barrel(120, 300, ripple=0.0, grain=4.0, seed=5))
real_p = tmp / "real-barrel.png"; real.save(real_p)
contract = {"fidelity": {"panels": {"expect": ["front", "back", "end"]}, "checks": [
    {"name": "back_finish", "panel": "back", "recipe": "finish", "params": {"along": [0.15, 0.85]},
     "real": {"crop": str(real_p)}, "target": {"ratio_max": 2.0, "grain_min": 0.3}}]}}
# the back panel is the plain barrel (a finish row's stretch never crosses a printed or dark part)
good = sheet([pen_panel(), pen_panel(ripple=0.0, with_pill=False), end_panel()]); good.save(tmp / "good.png")
bad = sheet([pen_panel(), pen_panel(ripple=14.0, with_pill=False), end_panel()]); bad.save(tmp / "bad.png")
ok_g, rows_g, _ = sm.judge(contract, tmp / "good.png")
ok_b, rows_b, _ = sm.judge(contract, tmp / "bad.png")
check("a fine-grained barrel passes the finish row", rows_g["back_finish"]["ok"] is True, rows_g["back_finish"]["note"])
check("a rippled barrel fails the finish row as rippled", rows_b["back_finish"]["ok"] is False and "rippled" in rows_b["back_finish"]["note"],
      rows_b["back_finish"]["note"])
plastic = sheet([pen_panel(), Image.fromarray(np.full((900, 260, 3), (BG, BG, BG - 2), np.uint8)), end_panel()])
pl = Image.new("RGB", (260, 900), (BG, BG, BG - 2)); pl.paste(Image.fromarray(barrel(90, 760, grain=0.8)), (85, 70))
sheet([pen_panel(), pl, end_panel()]).save(tmp / "plastic.png")
_, rows_p, _ = sm.judge(contract, tmp / "plastic.png")
check("a barrel gone plastic (a fifth of the photo's grain, no ripple) fails as too smooth, not as rippled",
      rows_p["back_finish"]["ok"] is False and "too smooth" in rows_p["back_finish"]["note"] and "rippled" not in rows_p["back_finish"]["note"],
      rows_p["back_finish"]["note"])
check("the finish row WARNS (new recipe, not calibrated on two products), never FAILS", rows_b["back_finish"]["status"] == "WARN")
# the single-panel texture row keeps its 26.9 meaning (a 26.9 contract is judged as it was), and runs without scipy
tex = {"surface_box": None, "real_crop": str(real_p), "max_ratio": 1.5}
gb = sm.detect_panels(Image.open(tmp / "bad.png"))[1]
W, H = Image.open(tmp / "bad.png").size
tex["surface_box"] = [(gb[0] + 100) / W, 150 / H, (gb[0] + 160) / W, 750 / H]
r_old = sm.texture_ratio(tmp / "bad.png", tex, tmp)
check("the single-panel texture row runs with numpy only and returns its ratio", r_old["sheet"] is not None and "sheet bp" in r_old["note"])
check("and it keeps its 26.9 rule: the ratio against max_ratio decides", r_old["ok"] == (r_old["sheet"] <= 1.5), str(r_old))

# ----------------------------------------------------------------------------- straight edges
print("straight edges")
c_edges = {"fidelity": {"panels": {"expect": ["front"]}, "checks": [
    {"name": "front_edges", "panel": "front", "recipe": "straight_edges", "params": {"along": [0.05, 0.95]}, "target": {"max_rel": 0.0015}}]}}
pen_panel(with_pill=False).save(tmp / "straight.png")
pen_panel(with_pill=False, wavy=2.5).save(tmp / "wavy.png")
_, r1, _ = sm.judge(c_edges, tmp / "straight.png")
_, r2, _ = sm.judge(c_edges, tmp / "wavy.png")
check("a straight barrel passes, a wandering outline fails", r1["front_edges"]["ok"] is True and r2["front_edges"]["ok"] is False,
      f"{r1['front_edges']['note']} | {r2['front_edges']['note']}")

# ----------------------------------------------------------------------------- exact features
print("exact features")
pim, pa = pill(120, 480)
real_pill = Image.new("RGB", (130, 490), (60, 100, 160)); real_pill.paste(pim, (5, 5), pa)
real_pill_p = tmp / "panel-real.png"; real_pill.save(real_pill_p)
meas = sm.measure_real(real_pill_p, "blob_layout", {"params": {"aspect": [2.5, 6]}})
L = sorted(m["y"] for m in meas["marks"] if m["x"] < 0.5); R = sorted(m["y"] for m in meas["marks"] if m["x"] >= 0.5)
check("the real panel crop reads 3 and 6", (len(L), len(R)) == (3, 6), str(meas["marks"]))
lay = {"name": "front_segments", "panel": "front", "recipe": "blob_layout",
       "params": {"search": [0, 0.4, 1, 0.95], "aspect": [2.5, 6]},
       "target": {"columns": [{"x": 0.3, "count": 3, "y": L}, {"x": 0.72, "count": 6, "y": R}], "tol_y": 0.05}}
ringc = {"name": "front_ring", "panel": "front", "recipe": "ring", "params": {"search": [0, 0.4, 1, 0.95], "aspect": [2.5, 6]}}
c_ex = {"fidelity": {"panels": {"expect": ["front"]}, "checks": [lay, ringc]}}
pen_panel().save(tmp / "pill-good.png")
pen_panel(split=(1, 2)).save(tmp / "pill-split.png")
pen_panel(notch=True).save(tmp / "pill-notch.png")
_, rg, _ = sm.judge(c_ex, tmp / "pill-good.png")
_, rs, _ = sm.judge(c_ex, tmp / "pill-split.png")
_, rn, _ = sm.judge(c_ex, tmp / "pill-notch.png")
check("the right layout passes", rg["front_segments"]["ok"] is True, rg["front_segments"]["note"])
check("a segment drawn split fails", rs["front_segments"]["ok"] is False, rs["front_segments"]["note"])
check("an unbroken ring passes", rg["front_ring"]["ok"] is True, rg["front_ring"]["note"])
check("a ring with a crack across it fails", rn["front_ring"]["ok"] is False, rn["front_ring"]["note"])
# a different layout with the right COUNTS fails on position: the left column starts lower
wrong_pos = pen_panel(with_pill=False)
pim2, pa2 = pill(60, 240, y0s=(0.55, 0.36))
wrong_pos.paste(pim2, ((260 - 60) // 2, 480), pa2)
wrong_pos.save(tmp / "pill-wrongpos.png")
_, rw, _ = sm.judge(c_ex, tmp / "pill-wrongpos.png")
check("segments in the wrong places fail even when a count happens to match", rw["front_segments"]["ok"] is False, rw["front_segments"]["note"])

# a LIT segment drawn split, its two halves welded into one blob by the glow around them (the v7 failure)
glow = pen_panel()
gp, ga = pill(60, 240)
gd = ImageDraw.Draw(gp)
sx, sy = int(0.72 * 60), int((0.36 + 2 * 0.085) * 240)
gd.rectangle([sx - 6, sy - 3, sx + 6, sy + 16], fill=(60, 70, 120))            # the glow joins the halves
gd.rectangle([sx - 3, sy, sx + 3, sy + 4], fill=(170, 200, 255))
gd.rectangle([sx - 3, sy + 8, sx + 3, sy + 12], fill=(170, 200, 255))
glow.paste(gp, ((260 - 60) // 2, 480), ga)
glow.save(tmp / "pill-glowsplit.png")
_, rgl, _ = sm.judge(c_ex, tmp / "pill-glowsplit.png")
check("a lit segment drawn split under its glow is caught as split", rgl["front_segments"]["ok"] is False
      and rgl["front_segments"]["sheet"]["split"] >= 1, rgl["front_segments"]["note"])

# the port
endc = {"name": "end_port", "panel": "end", "recipe": "part_offset", "params": {"aspect": [1.0, 2.5]}, "target": {"offset": 0.5, "tol": 0.12}}
c_end = {"fidelity": {"panels": {"expect": ["end"]}, "checks": [endc]}}
end_panel(offset=0.5).save(tmp / "end-off.png"); end_panel(offset=0.0).save(tmp / "end-centre.png")
_, ro, _ = sm.judge(c_end, tmp / "end-off.png")
_, rc, _ = sm.judge(c_end, tmp / "end-centre.png")
check("a port off to one side, as in the photo, passes", ro["end_port"]["ok"] is True, ro["end_port"]["note"])
check("a port drawn centred fails", rc["end_port"]["ok"] is False, rc["end_port"]["note"])

# ----------------------------------------------------------------------------- structure, statuses, gating
print("structure and gating")
c_cnt = {"fidelity": {"panels": {"expect": ["front", "back", "end"]}, "checks": [
    {"name": "panels", "recipe": "panel_count", "target": {"count": 3}},
    {"name": "end_port", "panel": "end", "recipe": "part_offset", "params": {"aspect": [1.0, 2.5]}, "target": {"offset": 0.5, "tol": 0.12}}]}}
sheet([pen_panel(), pen_panel()]).save(tmp / "two.png")
ok2, r2p, info = sm.judge(c_cnt, tmp / "two.png")
check("two panels where three are expected fails the count", r2p["panels"]["ok"] is False and "2 panels found" in r2p["panels"]["note"])
check("a row on a missing panel fails as STRUCTURE, it is not skipped", r2p["end_port"]["ok"] is False and r2p["end_port"]["class"] == "structure"
      and r2p["end_port"].get("missing_panel"))
check("uncalibrated rows warn, so the verdict holds", ok2 is True and r2p["panels"]["status"] == "WARN")
c_gate = {"fidelity": {"panels": {"expect": ["front"]}, "checks": [dict(lay, gate=True)]}}
_, rgate, _ = sm.judge(c_gate, tmp / "pill-split.png")
check("gate: true on an uncalibrated recipe still only warns, and says why", rgate["front_segments"]["status"] == "WARN"
      and "not calibrated" in rgate["front_segments"]["note"])
check("the numpy-only build never imports scipy", "scipy" not in sys.modules)

# ----------------------------------------------------------------------------- the CLI
print("cli")
cp = tmp / "anatomy.json"; cp.write_text(json.dumps(c_ex))
check("cli exits 0 when no GATED row failed", sm.main([str(cp), str(tmp / "pill-split.png")]) == 0)
check("cli `panels` lists the boxes", sm.main(["panels", str(tmp / "good.png")]) == 0)

print()
print("ALL PASS" if not fails else f"{len(fails)} FAILED: " + ", ".join(fails))
sys.exit(1 if fails else 0)

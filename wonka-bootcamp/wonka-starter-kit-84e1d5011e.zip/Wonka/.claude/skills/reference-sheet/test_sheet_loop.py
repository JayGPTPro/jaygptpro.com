"""sheet_loop.py: the faithfulness loop routes by defect class, keeps depth one, and stops at the cap.
Run: python3 test_sheet_loop.py

No network, no Genrupt, no scipy, no product data. A product folder is drawn here: an anchor whose
finish is clean but which lacks a panel and draws its control panel wrong, a sister that adds the
panel and breaks the finish, the owner's photos of the parts. The loop is driven through its own
command functions, the way Wonka drives it."""
import io
import json
import os
import sys
import tempfile
from contextlib import redirect_stdout
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw

HERE = Path(__file__).parent
sys.path.insert(0, str(HERE))
import npimage as npi  # noqa: E402
import sheet_loop as sl  # noqa: E402
import sheet_measure as sm  # noqa: E402

fails = []


def check(name, cond, detail=""):
    print(("  PASS  " if cond else "  FAIL  ") + name + ("" if cond else f"  {detail}"))
    if not cond:
        fails.append(name)


BG = 236


def barrel(w, h, ripple=0.0, grain=3.0, seed=1):
    r = np.random.default_rng(seed)
    x = np.linspace(-1, 1, w)
    base = np.tile(150 + 60 * (1 - x ** 2) ** 0.5, (h, 1)) + r.normal(0, grain, (h, w))
    if ripple:
        blot = npi.gaussian(r.normal(0, 1, (h, w)), w / 10.0)
        base += blot / (blot.std() + 1e-9) * ripple
    return np.clip(np.stack([base * 0.30, base * 0.62, base], axis=2), 0, 255).astype(np.uint8)


def pill(w, h, split=None):
    im = Image.new("RGB", (w, h), (0, 0, 0)); a = Image.new("L", (w, h), 0)
    d = ImageDraw.Draw(im); ImageDraw.Draw(a).rounded_rectangle([0, 0, w - 1, h - 1], radius=w // 2, fill=255)
    d.rounded_rectangle([0, 0, w - 1, h - 1], radius=w // 2, fill=(26, 26, 30))
    cx, cy, rr = w // 2, int(h * 0.17), int(w * 0.30)
    d.ellipse([cx - rr, cy - rr, cx + rr, cy + rr], outline=(150, 150, 156), width=max(4, w // 10))
    sw, sh = max(4, int(w * 0.12)), max(6, int(h * 0.045))
    for ci, (fx, n) in enumerate(((0.3, 3), (0.72, 6))):
        for k in range(n):
            x = int(fx * w); y = int((0.36 + k * 0.085) * h)
            d.rectangle([x - sw // 2, y, x + sw // 2, y + sh], fill=(160, 160, 165))
            if split == (ci, k):
                d.rectangle([x - sw // 2, y + sh // 2 - 1, x + sw // 2, y + sh // 2 + 1], fill=(26, 26, 30))
    return im, a


def pen_panel(ripple=0.0, with_pill=True, split=None, seed=1):
    p = Image.new("RGB", (260, 900), (BG, BG, BG - 2))
    p.paste(Image.fromarray(barrel(90, 760, ripple=ripple, seed=seed)), (85, 70))
    if with_pill:
        pim, pa = pill(60, 240, split=split)
        p.paste(pim, (100, 480), pa)
    return p


def end_panel(offset=0.0):
    p = Image.new("RGB", (300, 900), (BG, BG, BG - 2)); d = ImageDraw.Draw(p)
    d.ellipse([40, 380, 260, 560], fill=(20, 20, 22))
    py = int(470 - offset * 90)
    d.rounded_rectangle([116, py - 11, 184, py + 11], radius=10, outline=(200, 200, 205), width=4)
    return p


def sheet(panels, gutter=10):
    W = sum(p.size[0] for p in panels) + gutter * (len(panels) - 1)
    out = Image.new("RGB", (W, 900), (BG, BG, BG - 2)); x = 0
    for i, p in enumerate(panels):
        out.paste(p, (x, 0)); x += p.size[0]
        if i < len(panels) - 1:
            out.paste(Image.new("RGB", (gutter, 900), (252, 252, 252)), (x, 0)); x += gutter
    return out


def run(fn, *a):
    buf = io.StringIO()
    with redirect_stdout(buf):
        rc = fn(*a)
    return rc, buf.getvalue()


def product():
    """A fresh product folder; returns its path (cwd is set to it)."""
    root = Path(tempfile.mkdtemp(prefix="sheet_loop_")) / "pen"
    ref = root / "2-reference"; (ref / "photos" / "_crops").mkdir(parents=True)
    os.chdir(root)
    pim, pa = pill(120, 480)
    rp = Image.new("RGB", (130, 490), (60, 100, 160)); rp.paste(pim, (5, 5), pa); rp.save(ref / "photos" / "_crops" / "panel-real.png")
    er = Image.new("RGB", (240, 240), (200, 170, 150)); de = ImageDraw.Draw(er)
    de.ellipse([10, 10, 230, 230], fill=(22, 20, 20)); de.rounded_rectangle([86, 50, 154, 74], radius=10, outline=(210, 200, 190), width=4)
    er.save(ref / "photos" / "_crops" / "end-real.png")
    Image.fromarray(barrel(120, 300, seed=5, grain=4.0)).save(ref / "photos" / "_crops" / "barrel-real.png")
    lay = {"search": [0, 0.4, 1, 0.95], "aspect": [2.5, 6]}
    meas = sm.measure_real(ref / "photos" / "_crops" / "panel-real.png", "blob_layout", {"params": lay})
    L = sorted(m["y"] for m in meas["marks"] if m["x"] < 0.5); R = sorted(m["y"] for m in meas["marks"] if m["x"] >= 0.5)
    contract = {"fidelity": {"panels": {"expect": ["front", "back", "end"]},
                             "frozen_facts": "1 round button; 9 indicator segments; USB-C port in the end cap.", "checks": [
        {"name": "panels", "recipe": "panel_count", "target": {"count": 3},
         "fact": "The sheet has three panels: front, back, and the end cap seen head-on from the new photo."},
        {"name": "back_finish", "panel": "back", "recipe": "finish", "params": {"along": [0.15, 0.85]},
         "real": {"crop": "photos/_crops/barrel-real.png"}},
        {"name": "front_segments", "panel": "front", "recipe": "blob_layout", "params": lay,
         "target": {"columns": [{"x": 0.3, "count": 3, "y": L}, {"x": 0.72, "count": 6, "y": R}], "tol_y": 0.05},
         "crop": "photos/_crops/panel-real.png"},
        {"name": "end_port", "panel": "end", "recipe": "part_offset", "params": {"aspect": [1.0, 2.5]},
         "target": {"offset": 0.6, "tol": 0.15}, "crop": "photos/_crops/end-real.png"}]}}
    (ref / "anatomy.json").write_text(json.dumps(contract))
    return root, ref


# ----------------------------------------------------------------------------- the anchor
print("start")
root, ref = product()
sheet([pen_panel(split=(1, 2)), pen_panel(with_pill=False)]).save(ref / "sheet-v1.png")              # clean, short a panel
sheet([pen_panel(split=(1, 2)), pen_panel(ripple=14.0, with_pill=False)]).save(ref / "sheet-v2.png")  # newer, rippled
rc, out = run(sl.cmd_start, {"--contract": "2-reference/anatomy.json", "--versions": "2-reference/sheet-v*.png",
                             "--ids": "sheet-v1.png=ID-V1,sheet-v2.png=ID-V2"})
loop = sl.Loop(ref)
check("start anchors on the cleanest version, not the newest", rc == 0 and loop.anchor()["file"].endswith("sheet-v1.png"), out)
rc2, out2 = run(sl.cmd_start, {"--contract": "2-reference/anatomy.json", "--versions": "2-reference/sheet-v*.png"})
check("a second start without --restart is refused (the ledger is the state)", rc2 == 2)

# ----------------------------------------------------------------------------- the paid route, only for structure
print("the sister")
p = sl.plan(loop)
check("a panel no version has: ONE sister, from the anchor's id", p["action"] == "SISTER" and p["base_id"] == "ID-V1"
      and "panels" in p["rows"], json.dumps(p)[:300])
check("the instruction is the contract's fact, the notes are the frozen facts", p["editInstructions"].startswith("The sheet has three panels")
      and "9 indicator segments" in p["notes"])
check("the instruction passed the words rule", p["lint"] == [], str(p["lint"]))
check("the words rule flags appearance in Wonka's own words, and a bare (owner's words) tag does not excuse it",
      sl.lint_words("Make the barrel smoother and less rippled.") != []
      and sl.lint_words("The panel is matte dark aluminum (owner's words).") != []
      and sl.lint_words('The panel is "matte dark aluminum" (owner\'s words, 24.9).') == [])
sheet([pen_panel(split=(1, 2), seed=3), pen_panel(ripple=14.0, with_pill=False, seed=3), end_panel(offset=0.0)]).save(ref / "sheet-v3.png")
rc, out = run(sl.cmd_record_generator, {"--file": "2-reference/sheet-v3.png", "--base-id": "ID-V2", "--sheet-id": "ID-V3",
                                        "--credits-before": "100", "--credits-after": "97"})
check("a sister whose base was not the anchor is refused (depth one)", rc == 2 and "never from another sister" in out, out)
rc, out = run(sl.cmd_record_generator, {"--file": "2-reference/sheet-v3.png", "--base-id": "ID-V1", "--sheet-id": "ID-V3",
                                        "--credits-before": "100", "--credits-after": "97"})
loop = sl.Loop(ref)
check("the anchor's sister is recorded with its credits from the balance delta", rc == 0 and loop.credits_used() == 3.0, out)

# ----------------------------------------------------------------------------- the free route
print("the local route")
p = sl.plan(loop)
ops = [(o["op"], o.get("role")) for o in p.get("recipe", [])]
check("next: LOCAL from the anchor, the end panel taken from the sister, the owner's photos pasted",
      p["action"] == "LOCAL" and p["base"].endswith("sheet-v1.png") and ("panel_from", "end") in ops
      and ("paste_zone", "front") in ops and ("paste_zone", "end") in ops, json.dumps(ops))
check("the sister's broken finish is not taken: the back panel stays the anchor's", ("panel_from", "back") not in ops)
rc, out = run(sl.cmd_build, {})
loop = sl.Loop(ref)
best = min(loop.images(), key=lambda im: tuple(im["score"]))
loc = loop.latest("local")
check("the candidate was built from the anchor (its hash), never from another candidate", loc["base_sha"] == loop.anchor()["sha"])
check("the candidate passes every row", best["kind"] == "local" and all(r["status"] == "PASS" for r in best["rows"].values()),
      json.dumps({k: (r["status"], r["note"]) for k, r in best["rows"].items()})[:600])
p = sl.plan(loop)
check("next: STOP, ready for the owner", p["action"] == "STOP" and p.get("ready") is True, json.dumps(p)[:200])
(ref / "r.json").write_text(json.dumps(loc["recipe"]))
rc, out = run(sl.cmd_build, {"--base": loc["out"], "--recipe": str(ref / "r.json")})
check("a candidate is never the base of a build", rc == 2 and "never built on a candidate" in out, out)
sheet([pen_panel(split=(1, 2), seed=8), pen_panel(with_pill=False, seed=8), end_panel(offset=0.6)]).save(ref / "sheet-v9.png")
rc, out = run(sl.cmd_record_generator, {"--file": "2-reference/sheet-v9.png", "--base-id": "ID-V1", "--sheet-id": "X",
                                        "--credits-before": "97", "--credits-after": "94"})
check("a sister the loop did not ask for is refused (no spend outside the plan unless declared)", rc == 2 and "did not ask for a sister" in out, out)
rc, out = run(sl.cmd_record_generator, {"--file": loc["out"], "--base-id": "ID-V1", "--sheet-id": "X", "--outside-plan": "test"})
check("a candidate can never be recorded as a sister", rc == 2 and "already has" in out, out)

# ----------------------------------------------------------------------------- the report and the owner
print("report and owner")
rc, out = run(sl.cmd_report, {})
r = json.loads(out)
check("the report writes a board per row, the two sheets side by side, and report.md",
      rc == 0 and Path(r["md"]).exists() and Path(r["pair"]).exists() and len(r["boards"]) >= 3)
check("the best candidate is copied once as sheet-corrected-N.png, never over an existing file",
      r.get("corrected", "").startswith("2-reference/sheet-corrected-") and (root / r["corrected"]).exists())
rc, out2 = run(sl.cmd_report, {})
check("a second report does not copy the same picture again", "corrected" not in json.loads(out2))
chk = {"name": "end_ring", "panel": "end", "recipe": "panel_count", "target": {"count": 9}}
rc, out = run(sl.cmd_owner, {"--defect": "the end cap has a ring", "--check": json.dumps(chk)})
loop = sl.Loop(ref)
c = json.loads((ref / "anatomy.json").read_text())
added = [x for x in c["fidelity"]["checks"] if x["name"] == "end_ring"]
check("an owner's finding becomes a contract row, with its source in the owner's words",
      added and added[0]["source"].startswith("owner") and "the end cap has a ring" in added[0]["source"])
check("every image is judged again under the new row, so the router sees it at once",
      len(loop.images()) >= 3 and all("end_ring" in im["rows"] for im in loop.images()), str(len(loop.images())))
best_now = min(sl.Loop(ref).images(), key=lambda im: tuple(im["score"]))
rc0, _ = run(sl.cmd_owner, {"--approve": True})
rc, out = run(sl.cmd_owner, {"--approve": True, "--file": best_now["file"]})
check("approval names the exact picture the owner saw (refused without --file)", rc0 == 2 and rc == 0, out)
check("the owner's approval is recorded on the best candidate", sl.Loop(ref).latest("owner_approve") is not None)

# ----------------------------------------------------------------------------- caps and exhaustion
print("caps")
root2, ref2 = product()
sheet([pen_panel(split=(1, 2)), pen_panel(with_pill=False)]).save(ref2 / "sheet-v1.png")
run(sl.cmd_start, {"--contract": "2-reference/anatomy.json", "--versions": "2-reference/sheet-v*.png", "--ids": "sheet-v1.png=ID-V1"})
loop2 = sl.Loop(ref2)
loop2.lim["max_credits"] = 10
loop2.add({"event": "generator", "n": 1, "base_id": "ID-V1", "file": "x", "sha": "x", "credits": 9, "classes": ["count"]})
p = sl.plan(loop2)
check("the credit cap closes the paid route before it is spent, and says why",
      p["action"] != "SISTER" and p.get("closed") and "credit cap" in p["closed"]["why"], json.dumps(p)[:300])
loop2.lim["max_attempts"] = 1
p = sl.plan(loop2)
check("the attempt cap stops the loop", p["action"] == "STOP" and p.get("cap") == "attempts", json.dumps(p)[:200])
root3, ref3 = product()
sheet([pen_panel(split=(1, 2)), pen_panel(with_pill=False), end_panel(offset=0.0)]).save(ref3 / "sheet-v1.png")
c3 = json.loads((ref3 / "anatomy.json").read_text())
Image.new("RGB", (40, 40), (200, 170, 150)).save(ref3 / "photos" / "_crops" / "flat.png")
for x in c3["fidelity"]["checks"]:
    if x["name"] == "end_port":
        x["crop"] = "photos/_crops/flat.png"            # a photo with no end cap in it: the paste can never land
(ref3 / "anatomy.json").write_text(json.dumps(c3))
run(sl.cmd_start, {"--contract": "2-reference/anatomy.json", "--versions": "2-reference/sheet-v*.png"})
for _ in range(4):
    p = sl.plan(sl.Loop(ref3))
    if p["action"] != "LOCAL":
        break
    run(sl.cmd_build, {})
p = sl.plan(sl.Loop(ref3))
check("a row whose local route failed twice is exhausted, and the loop stops with it listed",
      p["action"] == "STOP" and "end_port" in (p.get("rows") or []), json.dumps(p)[:300])
check("two tries per row, then stop: exactly two builds were spent on it", len(sl.Loop(ref3).attempts()) == 2)
lp3 = sl.Loop(ref3)
cands = [im for im in lp3.images() if im["kind"] == "local"]
check("no build records the anchor's own pixels as a candidate, and the anchor stays the anchor",
      any(g["sha"] == lp3.anchor()["sha"] for g in lp3.generated()) and all(c["sha"] != lp3.anchor()["sha"] for c in cands))
rc, out = run(sl.cmd_report, {})
corr = json.loads(out).get("corrected")
check("a corrected copy is never the anchor's own pixels", corr is None or sl.file_sha(root3 / corr) != lp3.anchor()["sha"])
md = Path(json.loads(out)["md"]).read_text()
check("the report names the open row and proposes a route", "end_port" in md and "photo" in md.lower(), md[-400:])
c3["fidelity"]["checks"][0]["target"]["count"] = 3
(ref3 / "anatomy.json").write_text(json.dumps(c3, indent=2))
p = sl.plan(sl.Loop(ref3))
check("a changed contract makes every judgement stale: next asks for rejudge", p["action"] == "STOP" and p.get("stale"), json.dumps(p)[:200])
rc, out = run(sl.cmd_rejudge, {})
check("rejudge judges every image again under the new contract", rc == 0 and sl.Loop(ref3).images() != [])
run(sl.cmd_owner, {"--defect": "here is a real photo of the end", "--reset": "end_port"})
check("the owner's word on a row resets its tries", sl._local_tries(sl.Loop(ref3), "end_port") == 0)
rc, out = run(sl.cmd_map, {"--boxes": json.dumps({"front": [0, 0, 0.3, 1], "back": [0.3, 0, 0.6, 1], "end": [0.6, 0, 1, 1]})}, ["2-reference/sheet-v1.png"])
lp = sl.Loop(ref3)
mapped = lp.maps().get(sl.file_sha(ref3 / "sheet-v1.png"))
check("map --boxes records hand-drawn panel boxes for a sheet", rc == 0 and isinstance(mapped, dict) and mapped["end"] == [0.6, 0, 1, 1], out)
rc, out = run(sl.cmd_map, {"--boxes": "[1, 2]"}, ["2-reference/sheet-v1.png"])
check("map --boxes refuses a shape that is not role -> [x0, y0, x1, y1]", rc == 2)
# a second sheet of the same product runs its own loop beside the first
sheet([pen_panel(seed=9), pen_panel(with_pill=False, seed=9), end_panel(offset=0.6)]).save(ref3 / "parts-sheet-v1.png")
(ref3 / "dup-sheet-v1.png").write_bytes((ref3 / "sheet-v1.png").read_bytes())
rc_d, out_d = run(sl.cmd_start, {"--contract": "2-reference/anatomy.json", "--versions": "2-reference/dup-sheet-v*.png", "--loop": "dup"})
check("a second loop over the SAME sheet is refused: one sheet, one cap", rc_d == 2 and "already belongs" in out_d, out_d)
rc, out = run(sl.cmd_start, {"--contract": "2-reference/anatomy.json", "--versions": "2-reference/parts-sheet-v*.png", "--loop": "parts"})
check("a named loop opens beside the main one, with its own ledger", rc == 0 and (ref3 / "loop" / "parts" / "ledger.jsonl").exists()
      and sl.Loop(ref3, "parts").anchor()["file"].endswith("parts-sheet-v1.png") and sl.Loop(ref3).anchor()["file"].endswith("sheet-v1.png"), out)
try:
    sl.Loop(ref3, "../escape"); bad_name = False
except ValueError:
    bad_name = True
check("a loop name cannot climb out of 2-reference/loop", bad_name)
root4, ref4 = product()
c4 = json.loads((ref4 / "anatomy.json").read_text())
for x in c4["fidelity"]["checks"]:
    x.pop("crop", None)                                   # no crops on file: the sister route is open for exact features
(ref4 / "anatomy.json").write_text(json.dumps(c4))
sheet([pen_panel(split=(1, 2)), pen_panel(with_pill=False), end_panel(offset=0.6)]).save(ref4 / "sheet-v1.png")
sheet([pen_panel(seed=5), pen_panel(ripple=14.0, with_pill=False, seed=5), end_panel(offset=0.6)]).save(ref4 / "sheet-v2.png")
run(sl.cmd_start, {"--contract": "2-reference/anatomy.json", "--versions": "2-reference/sheet-v*.png", "--ids": "sheet-v1.png=A,sheet-v2.png=B"})
p4 = sl.plan(sl.Loop(ref4))
check("a version on disk that passes a row is transplanted free; no sister is bought for it",
      p4["action"] == "LOCAL" and any(o["op"] == "panel_from" and o["role"] == "front" for o in p4.get("recipe", [])), json.dumps(p4)[:300])
root5, ref5 = product()
c5 = json.loads((ref5 / "anatomy.json").read_text())
Image.new("RGB", (40, 40), (200, 170, 150)).save(ref5 / "photos" / "_crops" / "flat.png")
for x in c5["fidelity"]["checks"]:
    if x["name"] == "end_port":
        x["crop"] = "photos/_crops/flat.png"
(ref5 / "anatomy.json").write_text(json.dumps(c5))
sheet([pen_panel(), pen_panel(with_pill=False), end_panel(offset=0.0)]).save(ref5 / "sheet-v1.png")
run(sl.cmd_start, {"--contract": "2-reference/anatomy.json", "--versions": "2-reference/sheet-v*.png"})
rc, out = run(sl.cmd_build, {})
lp5 = sl.Loop(ref5)
check("a build whose every operation is refused makes no candidate: the anchor stays, and next still plans from it",
      "made no new picture" in out and not list((ref5 / "loop").glob("candidate-*.png"))
      and lp5.generated() and sl.plan(lp5)["why"] != "no generated version judged", out + json.dumps(sl.plan(lp5))[:200])
check("no scipy was imported", "scipy" not in sys.modules)

print()
print("ALL PASS" if not fails else f"{len(fails)} FAILED: " + ", ".join(fails))
sys.exit(1 if fails else 0)

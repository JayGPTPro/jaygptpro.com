#!/usr/bin/env python3
"""Measure a sheet or a frame against the anatomy contract: is this the real product?

The Fixing Room's drift gate (edit_core.py) asks whether an image degraded against ITSELF.
This asks whether it matches the PRODUCT, which is a per-product question: a knife has a
blade-to-handle ratio, three windows and three rivets; a pen has a straight barrel, a smooth
finish and a nine-segment panel. So the contract names which RECIPES apply and what the real
photos measured, and this script runs them on a sheet and prints PASS/FAIL rows plus a board per
row with what it found drawn on it. Lengths are fractions of the product's own extent, so a sheet
at any scale compares directly with targets measured on real photos.

Two contract shapes, both read here:

1. The single-panel shape (26 September 2026, the knife): `fidelity.panel_box` + `landmarks`
   + `texture`. Recipes: extent, dark_start, enclosed_regions (+ enclosed_region_edge),
   bright_blobs, height_at, texture.
2. The multi-panel shape (3 October 2026, the engraving pen): `fidelity.panels.expect` names the
   sheet's panels in order, and `fidelity.checks` is a list of rows, each on one panel:
     finish          the surface's texture at the part's own scale against a real photo crop:
                     the fine grain and the coarse ripple, two-sided (too smooth fails, rippled fails)
     straight_edges  how far a straight part's outline wanders off a fitted straight line
     blob_layout     an exact feature's layout: bright segments per column inside a dark zone
                     (a control panel's indicator grid), tilt-corrected
     ring            a ring inside a zone is round and unbroken (a button's bezel)
     part_offset     how far a feature sits from the centre of its zone, as a fraction of the
                     zone's radius (a charging port off-centre in an end cap)
     color           a part's colour against the real photo, each white-balanced on its background
     panel_count     how many panels the sheet holds against how many the contract expects
     object_count    separate pieces on one panel (a parts sheet)
   The single-panel recipes run on a named panel too.

Gating (the owner's rule, 3 October 2026): a row BLOCKS only when its recipe has separated good
sheets from bad ones on the history of two products (`CALIBRATED`); every other row WARNS. A
warning is still a finding the loop acts on and the owner sees; it just cannot hold a sheet back
on its own. A wrong measurement is worse than none: every row draws what it found on its board,
and a row that misfires on a product is dropped from that product's contract with a one-line note.

numpy and pillow only (npimage.py): the kit installs nothing else.

Usage:
  sheet_measure.py <contract.json> <image.png> [--panel x0,y0,x1,y1] [--map front,back,...] [--out dir] [--json]
  sheet_measure.py real <crop.png> <recipe> ['{"params": ...}']   measure a real photo crop the way
                                                                    a row will, to write its target
  sheet_measure.py panels <image.png>                               the panel boxes this script sees
Exit 0 = every gated row passed. Contract shape: contract-example.json beside this script.
"""
from __future__ import annotations

import json
import math
import sys
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import npimage as npi  # noqa: E402

# recipes whose numbers separated good sheets from bad on two products' histories (the rule above)
CALIBRATED = {"extent", "dark_start", "enclosed_regions", "enclosed_region_edge", "bright_blobs", "height_at"}
NEW_RECIPES = {"finish", "straight_edges", "blob_layout", "ring", "part_offset", "color", "panel_count", "object_count"}
LEGACY_RECIPES = {"extent", "dark_start", "enclosed_regions", "enclosed_region_edge", "bright_blobs", "height_at"}
DEFAULT_CLASS = {"finish": "finish", "texture": "finish", "straight_edges": "outline", "ring": "outline",
                 "blob_layout": "exact_feature", "part_offset": "exact_feature", "color": "colour",
                 "panel_count": "structure", "object_count": "count", "extent": "proportion",
                 "dark_start": "proportion", "enclosed_regions": "proportion", "enclosed_region_edge": "proportion",
                 "bright_blobs": "proportion", "height_at": "proportion"}
FINISH_BANDS = ((0.7, 1.5), (1.5, 3.0), (3.0, 6.0), (6.0, 12.0))
FINISH_W0 = 200          # the part's full width is resampled to this many pixels before measuring


def runs(mask):
    out, start = [], None
    for i, v in enumerate(mask):
        if v and start is None:
            start = i
        elif not v and start is not None:
            out.append((start, i - 1)); start = None
    if start is not None:
        out.append((start, len(mask) - 1))
    return out


def load_panel(path, panel):
    im = Image.open(path).convert("L")
    w, h = im.size
    x0, y0, x1, y1 = panel
    box = (int(x0 * w), int(y0 * h), int(x1 * w), int(y1 * h))
    a = np.asarray(im.crop(box)).astype(int)
    return a, box


# ============================================================================= single-panel shape
def measure(contract: dict, image_path, panel=None, out_dir=None):
    fid = contract.get("fidelity") or {}
    panel = tuple(panel or fid.get("panel_box") or (0, 0, 1, 1))
    axis = fid.get("axis", "horizontal")
    a, box = load_panel(image_path, panel)
    if axis == "vertical":
        a = a.T
    bg = float(np.median(np.concatenate([a[:6, :].ravel(), a[-6:, :].ravel()])))
    fg = np.abs(a - bg) > fid.get("fg_threshold", 22)
    cols = np.where(fg.sum(0) > 3)[0]
    if len(cols) < 10:
        return False, {"error": {"sheet": None, "real": None, "ok": False, "note": "no product found in the panel"}}
    x0, x1 = int(cols.min()), int(cols.max())
    L = float(x1 - x0)
    pct = lambda x: (x - x0) / L * 100
    rows = {}
    ok = True
    strict = np.abs(a - bg) > fid.get("strict_threshold", 45)
    top = np.full(a.shape[1], -1); bot = np.full(a.shape[1], -1)
    for x in range(x0, x1 + 1):
        ys = np.where(fg[:, x])[0]; yb = np.where(strict[:, x])[0]
        if len(ys): top[x] = ys.min()
        if len(yb): bot[x] = yb.max()
    marks = []
    dark_start = None

    for lm in fid.get("landmarks", []):
        name, recipe, p = lm["name"], lm["recipe"], lm.get("params", {})
        gated = "target" in lm or "target_count" in lm or "target_fracs" in lm
        row = {"sheet": None, "real": lm.get("target", lm.get("target_count", lm.get("target_fracs"))), "tol": lm.get("tol"), "ok": True, "gated": gated}
        try:
            if recipe == "extent":
                hmax = int(max(bot[x] - top[x] for x in range(x0, x1 + 1) if top[x] >= 0 and bot[x] >= 0))
                row["sheet"] = round(hmax / L * 100, 1)
            elif recipe == "dark_start":
                dark = (a < p.get("threshold", 75)).sum(0)
                ref_col = int(x0 + p.get("ref_frac", 0.8) * L)
                cands = [x for x in range(int(x0 + p.get("from_frac", 0.4) * L), x1 + 1) if dark[x] > p.get("share", 0.35) * max(1, dark[ref_col])]
                if not cands:
                    raise ValueError("no dark part found")
                dark_start = min(cands)
                row["sheet"] = round(pct(dark_start), 1); marks.append(("v", dark_start, name))
            elif recipe == "enclosed_regions":
                nearbg = np.abs(a - bg) < p.get("bg_tolerance", 7)
                lab, _ = npi.label(nearbg, connectivity=4)          # scipy's default, which the knife's targets were set on
                border = set(np.unique(np.concatenate([lab[0], lab[-1], lab[:, 0], lab[:, -1]])).tolist())
                wins = []
                limit = dark_start if dark_start is not None else x1
                for o in npi.objects(lab, int(lab.max())):
                    if o["label"] in border:
                        continue
                    w_, h_ = o["x1"] - o["x0"] + 1, o["y1"] - o["y0"] + 1
                    area = o["area"]
                    # a region that runs INTO the dark part is a shadow pocket, not a window (the knife, v9 on)
                    if w_ > p.get("min_w_frac", 0.04) * L and h_ > p.get("min_h_frac", 0.02) * L and o["x1"] < limit and area > 0.35 * w_ * h_:
                        wins.append((area, o["x0"], o["x1"]))
                # count what qualifies: regions at least `min_area_rel` of the largest one (a
                # window is a window-sized hole; a reflection or a prong slot is not), trimmed to
                # the largest N only when the contract says so (params.count), never to the target,
                # or a fourth window could not fail
                if wins:
                    biggest = max(a_ for a_, _, _ in wins)
                    wins = [w for w in wins if w[0] >= p.get("min_area_rel", 0.3) * biggest]
                k = int(p["count"]) if "count" in p else len(wins)
                wins = sorted([(s_, e_) for _, s_, e_ in sorted(wins, reverse=True)[:k]])
                fid["_regions"] = wins
                row["sheet"] = len(wins)
                for s_, e_ in wins:
                    marks.append(("v", s_, "")); marks.append(("v", e_, ""))
                if "target_count" in lm:
                    row["ok"] = len(wins) == int(lm["target_count"])
            elif recipe == "enclosed_region_edge":
                wins = fid.get("_regions") or []
                i = int(p.get("index", 0)); edge = p.get("edge", "start")
                if i >= len(wins):
                    raise ValueError("region index out of range (run enclosed_regions first)")
                row["sheet"] = round(pct(wins[i][0] if edge == "start" else wins[i][1]), 1)
            elif recipe == "bright_blobs":
                if dark_start is None:
                    raise ValueError("bright_blobs needs a dark_start landmark before it")
                bright = np.zeros(a.shape[1], bool)
                for x in range(dark_start + 5, x1 - 5):
                    if top[x] < 0 or bot[x] < 0:
                        continue
                    seg = a[top[x]:bot[x] + 1, x]
                    mid = seg[int(len(seg) * 0.2):int(len(seg) * 0.8)]
                    bright[x] = (mid > p.get("threshold", 170)).sum() > 3
                rv = [r for r in runs(bright) if r[1] - r[0] > p.get("min_len_frac", 0.008) * L and r[1] < x1 - 0.03 * L]
                wl = max(1, x1 - dark_start)
                fr = [round(((r[0] + r[1]) / 2 - dark_start) / wl, 3) for r in rv]
                row["sheet"] = fr
                for r in rv:
                    marks.append(("v", (r[0] + r[1]) // 2, ""))
                if "target_fracs" in lm:
                    tf = lm["target_fracs"]; tol = lm.get("tol", 0.03)
                    row["ok"] = len(fr) == len(tf) and all(abs(x - y) <= tol for x, y in zip(fr, tf))
            elif recipe == "height_at":
                xq = int(x0 + p["at_frac"] * L)
                if top[xq] < 0 or bot[xq] < 0:
                    raise ValueError("no product at that fraction")
                row["sheet"] = round((bot[xq] - top[xq]) / L * 100, 2); marks.append(("v", xq, name))
            else:
                raise ValueError(f"no recipe {recipe!r}")
            if "target" in lm and row["sheet"] is not None and not isinstance(row["sheet"], list):
                row["ok"] = abs(row["sheet"] - float(lm["target"])) <= float(lm.get("tol", 0))
        except Exception as e:
            row["ok"] = False; row["note"] = f"{type(e).__name__}: {e}"
        if gated:
            ok = ok and row["ok"]
        rows[name] = row

    tex = fid.get("texture")
    if tex and tex.get("real_crop"):
        try:
            rows["texture"] = texture_ratio(image_path, tex, Path(image_path).parent)
            if tex.get("max_ratio") is not None and rows["texture"]["sheet"] is not None:
                ok = ok and rows["texture"]["ok"]
        except Exception as e:
            rows["texture"] = {"sheet": None, "real": None, "ok": False, "note": f"{type(e).__name__}: {e}", "gated": True}
            ok = False

    if out_dir:
        strip(image_path, box, axis, x0, x1, marks, Path(out_dir) / (Path(image_path).stem + "-landmarks.png"))
    return ok, rows


def texture_ratio(image_path, tex, base_dir):
    """The single-panel texture row of the 26 September contracts, judged exactly as it was then
    (now in numpy, so it runs on a student's machine instead of skipping): band-pass (sigma 1.5
    minus sigma 6) std on the flat part of the surface box against the same measure on a real
    photo's crop, both resampled so the box is 600 px wide; a ratio above `max_ratio` fails.
    It fails only a finish ROUGHER than the photo at pixel scale and cannot see a coarse ripple
    (measured 3 October 2026: it passed all seven versions of a sheet whose finish had broken into
    a hammered ripple). A new contract uses the multi-panel `finish` recipe, which sees both."""
    def prep(path, box, grid=600):
        im = Image.open(path).convert("L"); w, h = im.size
        x0, y0, x1, y1 = (int(box[0] * w), int(box[1] * h), int(box[2] * w), int(box[3] * h))
        crop = im.crop((x0, y0, x1, y1)); s = grid / max(1, crop.size[0])
        g = np.asarray(crop.resize((grid, max(8, int(crop.size[1] * s))), Image.LANCZOS)).astype(float)
        G = lambda a, sg: npi.gaussian(a, sg, truncate=4.0, mode="reflect")
        gy, gx = np.gradient(G(g, 1.0))
        gm = G(np.hypot(gy, gx), 3.0)                       # flat at low frequency, so grain does not speckle the mask
        flat = npi.erode_cross(gm < np.percentile(gm, 50), 4)
        bp = G(g, 1.5) - G(g, 6)
        return float(bp[flat].std()) if flat.sum() > 200 else None
    real_path = Path(tex["real_crop"])
    if not real_path.is_absolute():
        real_path = Path(base_dir) / real_path
    s_val = prep(image_path, tex["surface_box"]); r_val = prep(real_path, tex.get("real_box", tex["surface_box"]))
    ratio = round(s_val / r_val, 3) if (s_val and r_val) else None
    ok = True if (ratio is None or tex.get("max_ratio") is None) else ratio <= float(tex["max_ratio"])
    return {"sheet": ratio, "real": 1.0, "tol": tex.get("max_ratio"), "ok": bool(ok), "gated": tex.get("max_ratio") is not None,
            "note": f"sheet bp {s_val and round(s_val, 3)}, real bp {r_val and round(r_val, 3)}"}


def strip(image_path, box, axis, x0, x1, marks, out_path):
    im = Image.open(image_path).convert("RGB").crop(box)
    d = ImageDraw.Draw(im)
    W, H = im.size
    for kind, pos, label in marks:
        if axis == "vertical":
            d.line([(0, pos), (W, pos)], fill=(220, 30, 30), width=2)
            if label: d.text((4, pos + 2), label, fill=(220, 30, 30))
        else:
            d.line([(pos, 0), (pos, H)], fill=(220, 30, 30), width=2)
            if label: d.text((pos + 3, 4), label, fill=(220, 30, 30))
    for pos, label in ((x0, "0%"), (x1, "100%")):
        if axis == "vertical":
            d.line([(0, pos), (W, pos)], fill=(30, 90, 220), width=2)
        else:
            d.line([(pos, 0), (pos, H)], fill=(30, 90, 220), width=2)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    im.save(out_path)
    return out_path


# ============================================================================= panels and the product
def detect_panels(img) -> list:
    """Panel boxes (x0, y0, x1, y1), pixels, row by row then left to right. A sheet is a collage
    split by thin gutters; a gutter shows as a line where nearly every row (or column) steps.
    No gutter found: the whole image is one panel."""
    g = npi.to_gray(img)
    H, W = g.shape

    def cuts(a, along):
        """Gutters across `along` (axis 1 = vertical gutters). A gutter is a thin band with a step
        on BOTH sides along nearly every line: two opposite step lines at most 24 px apart. One
        step alone is a product's straight edge (a tall barrel reaches 0.85 of the rows on its own)."""
        d = np.abs(np.diff(a, axis=along))
        frac = (d > 6).mean(axis=1 - along)
        idx = np.flatnonzero(frac > 0.85)
        n = a.shape[along]
        groups = []
        for c in idx.tolist():
            if groups and c - groups[-1][-1] <= 2:
                groups[-1].append(c)
            else:
                groups.append([c])
        lines = [(min(gr), max(gr), float(frac[min(gr):max(gr) + 1].max())) for gr in groups]
        edge = max(4, int(0.01 * n))
        out, i = [], 0
        while i < len(lines):
            a0, b0, f0 = lines[i]
            if a0 <= edge or b0 >= n - edge:
                i += 1; continue
            if i + 1 < len(lines) and 1 <= lines[i + 1][0] - b0 <= 24 and lines[i + 1][1] < n - edge:
                out.append((b0 + 1, lines[i + 1][0] + 1))     # a gutter band: a step on both sides
                i += 2
            elif f0 > 0.97:
                out.append((b0 + 1, b0 + 1))                   # a seam on every line: two panels that abut
                i += 1
            else:
                i += 1                                         # one step on most lines: a product's straight edge
        return out

    def split(lo, hi, gaps, n_min):
        spans, cur = [], lo
        for a0, a1 in gaps:
            if a0 - cur >= n_min:
                spans.append((cur, a0))
            cur = a1
        if hi - cur >= n_min:
            spans.append((cur, hi))
        return spans or [(lo, hi)]

    bands = split(0, H, cuts(g, 0), int(0.05 * H))
    out = []
    for (y0, y1) in bands:
        sub = g[y0:y1]
        for (x0, x1) in split(0, W, cuts(sub, 1), int(0.03 * W)):
            cell = g[y0:y1, x0:x1]
            if len(bands) > 1 or True:
                bg = panel_background(cell)
                if (np.abs(cell - bg) > 22).mean() < 0.005:
                    continue                        # an empty cell of a grid is not a panel
            out.append((x0, y0, x1, y1))
    return out or [(0, 0, W, H)]


def panel_background(g: np.ndarray) -> float:
    edge = max(2, int(0.01 * min(g.shape)))
    ring = np.concatenate([g[:edge].ravel(), g[-edge:].ravel(), g[:, :edge].ravel(), g[:, -edge:].ravel()])
    return float(np.median(ring))


def product_mask(g: np.ndarray, thr: float = 22) -> tuple:
    """(mask, bg): the largest foreground object on a light, even panel, holes filled."""
    bg = panel_background(g)
    fg = np.abs(g - bg) > thr
    m = npi.fill_holes(npi.largest(fg))
    return m, bg


def product_frame(mask: np.ndarray, axis: str | None = None) -> dict:
    """The product's bounding box and main axis (vertical when taller than wide)."""
    ys, xs = np.nonzero(mask)
    if len(xs) == 0:
        raise ValueError("no product found on the panel")
    y0, y1, x0, x1 = int(ys.min()), int(ys.max()), int(xs.min()), int(xs.max())
    if axis is None:
        axis = "vertical" if (y1 - y0) >= (x1 - x0) else "horizontal"
    return {"y0": y0, "y1": y1, "x0": x0, "x1": x1, "axis": axis,
            "length": float((y1 - y0) if axis == "vertical" else (x1 - x0))}


def edges_along(g: np.ndarray, mask: np.ndarray, frame: dict, along: tuple, bg: float, thr: float = 22):
    """For each line across the product inside `along` (fractions of its length), the sub-pixel
    position of its two outline edges. Vertical product: rows, left/right edges."""
    gg, mm = (g, mask) if frame["axis"] == "vertical" else (g.T, mask.T)
    lo = frame["y0"] if frame["axis"] == "vertical" else frame["x0"]
    L = frame["length"]
    a0, a1 = int(lo + along[0] * L), int(lo + along[1] * L)
    pos, left, right = [], [], []
    for y in range(max(0, a0), min(gg.shape[0], a1 + 1)):
        xs = np.flatnonzero(mm[y])
        if len(xs) < 6:
            continue
        row = gg[y]
        def sub(xa, xb):
            va, vb = abs(row[xa] - bg), abs(row[xb] - bg)
            return xa + (thr - va) / (vb - va + 1e-9) * (xb - xa)
        x0, x1 = int(xs[0]), int(xs[-1])
        left.append(sub(x0 - 1, x0) if x0 > 0 else float(x0))
        right.append(sub(x1 + 1, x1) if x1 < len(row) - 1 else float(x1))
        pos.append(y)
    return np.array(pos, float), np.array(left, float), np.array(right, float)


def straight_span(pos, left, right, tol=0.03):
    """The longest run of lines whose width stays within `tol` of the median: the straight part of
    a barrel, without the caps, tips or tapers at either end."""
    if len(pos) == 0:
        return slice(0, 0)
    w = right - left
    med = np.median(w)
    ok = np.abs(w - med) < tol * med
    best, start = (0, 0), None
    for i, v in enumerate(ok.tolist() + [False]):
        if v and start is None:
            start = i
        if not v and start is not None:
            if i - start > best[1] - best[0]:
                best = (start, i)
            start = None
    s, e = best
    m = int((e - s) * 0.04)
    return slice(s + m, max(s + m, e - m))


def robust_line_rms(t, x):
    """RMS of the residual from a robust straight-line fit (three passes trimming 3 sigma)."""
    if len(t) < 8:
        return None
    tt, xx = t.copy(), x.copy()
    for _ in range(3):
        p = np.polyfit(tt, xx, 1)
        r = xx - np.polyval(p, tt)
        s = float(np.std(r))
        keep = np.abs(r) < 3 * s + 0.5
        tt, xx = tt[keep], xx[keep]
    p = np.polyfit(tt, xx, 1)
    r = xx - np.polyval(p, tt)
    return float(np.sqrt((r ** 2).mean())), p


# ============================================================================= finish
def finish_profile(g: np.ndarray, axis: str = "vertical", w0: int = FINISH_W0, inset: float = 0.2,
                   shade_sigma: float = 25.0, ends: int = 30) -> dict:
    """The texture of a surface strip whose box spans the part's FULL width (edge to edge). The
    strip is resampled so that width is `w0` pixels, so a sheet and a phone photo are measured at
    the same physical scale; the shading (a cylinder's light runs along its length) is removed by
    a strong blur along the axis; then the band-passed residual is measured in four octaves.
    grain = the finest band, ripple = the coarsest, ratio = ripple / grain."""
    a = np.asarray(g, dtype=np.float64)
    if axis == "horizontal":
        a = a.T
    h, w = a.shape
    if w < 8 or h < 16:
        raise ValueError(f"the surface strip is {w}x{h} px; too small to measure a finish")
    s = w0 / w
    im = Image.fromarray(np.clip(a, 0, 255).astype(np.uint8), "L").resize((w0, max(16, int(round(h * s)))), Image.LANCZOS)
    a = np.asarray(im, dtype=np.float64)
    r = a - npi.gaussian1d(a, shade_sigma, axis=0)
    m = int(w0 * inset)
    e = min(ends, max(2, r.shape[0] // 6))
    r = r[e:-e, m:w0 - m]
    if r.shape[0] < 12:
        raise ValueError("the surface strip is too short once its ends are trimmed")
    vals = []
    for lo, hi in FINISH_BANDS:
        vals.append(float((npi.gaussian(r, lo) - npi.gaussian(r, hi)).std()))
    grain, ripple = vals[0], vals[-1]
    return {"bands": [round(v, 3) for v in vals], "grain": round(grain, 3), "ripple": round(ripple, 3),
            "ratio": round(ripple / grain, 3) if grain > 0 else None, "scale": round(s, 3)}


def compare_finish(s: dict, r: dict, ratio_max: float = 2.0, grain_min: float = 0.3) -> dict:
    """Sheet against real: the ripple-to-grain ratio may be at most `ratio_max` times the photo's,
    and the grain at least `grain_min` of the photo's."""
    grain_rel = s["grain"] / r["grain"] if r["grain"] else None
    ratio_rel = s["ratio"] / r["ratio"] if (s["ratio"] is not None and r["ratio"]) else None
    ok = grain_rel is not None and ratio_rel is not None and grain_rel >= grain_min and ratio_rel <= ratio_max
    why = []
    if ratio_rel is not None and ratio_rel > ratio_max:
        why.append(f"rippled: the coarse texture is {ratio_rel:.2f}x the photo's share (limit {ratio_max})")
    if grain_rel is not None and grain_rel < grain_min:
        why.append(f"too smooth: {grain_rel:.2f} of the photo's grain (floor {grain_min})")
    note = (f"ripple/grain {s['ratio']} vs photo {r['ratio']}; grain {s['grain']} vs photo {r['grain']}"
            + (" . " + "; ".join(why) if why else ""))
    return {"ok": bool(ok), "ratio_rel": None if ratio_rel is None else round(ratio_rel, 3),
            "grain_rel": None if grain_rel is None else round(grain_rel, 3), "note": note}


def surface_strip(g: np.ndarray, mask: np.ndarray, frame: dict, along: tuple, bg: float, thr: float):
    """The full-width strip of the product between two fractions of its length (straight part
    only), as (gray strip, box in panel pixels)."""
    pos, left, right = edges_along(g, mask, frame, along, bg, thr)
    sl = straight_span(pos, left, right)
    if sl.stop - sl.start < 24:
        raise ValueError("no straight stretch of the part in that range")
    L = int(math.floor(np.median(left[sl]))) + 1
    R = int(math.ceil(np.median(right[sl]))) - 1
    a0, a1 = int(pos[sl][0]), int(pos[sl][-1])
    if frame["axis"] == "vertical":
        return g[a0:a1 + 1, L:R + 1], (L, a0, R + 1, a1 + 1)
    return g[L:R + 1, a0:a1 + 1], (a0, L, a1 + 1, R + 1)


# ============================================================================= zones (exact features)
def otsu(values: np.ndarray) -> float:
    """Otsu's threshold on 0..255 values."""
    v = np.clip(np.asarray(values, dtype=np.float64).ravel(), 0, 255)
    if v.size == 0:
        return 128.0
    hist = np.bincount(v.astype(np.int64), minlength=256).astype(np.float64)
    w = np.cumsum(hist); mu = np.cumsum(hist * np.arange(256))
    total, mt = w[-1], mu[-1]
    w1 = total - w
    with np.errstate(divide="ignore", invalid="ignore"):
        between = (mt * w - mu * total) ** 2 / (w * w1)
    between[~np.isfinite(between)] = -1
    return float(np.argmax(between)) + 0.5


def find_zone(img_rgb: Image.Image, search=None, kind: str = "dark", thr="auto", min_area: float = 0.002,
              open_frac: float = 0.006, aspect=None, solidity_min: float = 0.6):
    """The zone a feature lives in, inside `search` (fractions of the panel): a control panel, an
    end cap, a label. Candidates are the dark (or bright) blobs at a fixed threshold, or at the
    two Otsu levels when `thr` is "auto" (a light background, a mid-tone product and a dark panel
    are three levels; the darkest class is the panel). An OPENING first cuts the thin strands that
    join a zone to shadows (a pen held in a hand). At the darkest level that has one, the largest
    candidate whose shape fits wins: solid (area over its rotated box at least `solidity_min`) and,
    when given, within `aspect` (major over minor). Returns (mask in panel pixels, principal box)
    or (None, None)."""
    g = npi.to_gray(img_rgb)
    H, W = g.shape
    sx0, sy0, sx1, sy1 = search or (0, 0, 1, 1)
    X0, Y0 = int(sx0 * W), int(sy0 * H)
    X1, Y1 = max(X0 + 2, int(sx1 * W)), max(Y0 + 2, int(sy1 * H))
    sub = g[Y0:Y1, X0:X1]
    if thr == "auto" or thr is None:
        t1 = otsu(sub)
        side = sub[sub < t1] if kind == "dark" else sub[sub > t1]
        t2 = otsu(side) if side.size > 64 else t1
        levels = [t2, t1]
    else:
        levels = [float(thr)]
    r = max(1, int(round(open_frac * min(H, W))))
    best, fallback = None, None
    for t in levels:
        if best is not None:
            break                      # the darkest level that holds a fitting zone wins (a barrel is solid too)
        cand = (sub < t) if kind == "dark" else (sub > t)
        cand = npi.dilate(npi.erode(cand, r), r)
        lab, n = npi.label(cand)
        for o in npi.objects(lab, n):
            if o["area"] < min_area * H * W:
                continue
            comp = npi.fill_holes(lab[o["y0"]:o["y1"] + 1, o["x0"]:o["x1"] + 1] == o["label"])
            box = npi.principal_box(comp)
            if box is None:
                continue
            area = float(comp.sum())
            solidity = area / max(1.0, box["major"] * box["minor"])
            asp = box["major"] / max(1.0, box["minor"])
            fits = solidity >= solidity_min and (aspect is None or aspect[0] <= asp <= aspect[1])
            key = (o, comp, t)
            if fits and (best is None or area > best[0]):
                best = (area, key)
            if fallback is None or area > fallback[0]:
                fallback = (area, key)
    pick = best or (fallback if aspect is None else None)   # a shape was asked for: nothing that misses it stands in
    if pick is None:
        return None, None
    o, comp, _ = pick[1]
    m = np.zeros_like(g, bool)
    m[Y0 + o["y0"]:Y0 + o["y1"] + 1, X0 + o["x0"]:X0 + o["x1"] + 1] = comp
    return m, npi.principal_box(m)


def _local_level(g: np.ndarray, inner: np.ndarray, r: int) -> np.ndarray:
    """The zone's own darkness around each pixel, with bright marks clipped so they do not lift it."""
    cap = np.percentile(g[inner], 60) if inner.any() else g.mean()
    return npi.box_mean(np.minimum(g, cap), r)


def bright_marks(zone_rgb: Image.Image, delta: float = 18, inner_frac: float = 0.10, min_area_rel: float = 0.0006,
                 fill_min: float = 0.55, thr="auto", open_frac: float = 0.012):
    """Bright marks inside a dark zone image that was cut upright: segments, a ring, a port rim.
    Returns (objects with positions as fractions of the zone, zone mask, labels, zone box x0, y0, w, h)."""
    g = npi.to_gray(zone_rgb)
    H, W = g.shape
    t = otsu(g) if (thr == "auto" or thr is None) else float(thr)
    zmask = npi.fill_holes(npi.largest(npi.erode(npi.dilate(g < t, 2), 2)))
    if zmask.sum() < 0.2 * H * W:
        zmask = np.ones_like(g, bool)
    ys, xs = np.nonzero(zmask)
    zx0, zx1, zy0, zy1 = xs.min(), xs.max(), ys.min(), ys.max()
    zw, zh = float(zx1 - zx0 + 1), float(zy1 - zy0 + 1)
    inner = npi.erode(zmask, max(2, int(inner_frac * zw)))
    level = _local_level(g, inner, max(4, int(0.12 * zw)))
    bright = (g - level > delta) & inner
    # an OPENING: a hair, a scratch or an edge highlight is thinner than any segment, and a
    # closing would weld it to the segment it touches (the owner's panel photo has a hair across it)
    r = max(1, int(round(open_frac * zw)))
    if open_frac > 0:
        bright = npi.dilate(npi.erode(bright, r), r) & inner
    lab, n = npi.label(bright)
    out = []
    zarea = float(zmask.sum())
    for o in npi.objects(lab, n):
        w_, h_ = o["x1"] - o["x0"] + 1, o["y1"] - o["y0"] + 1
        fill = o["area"] / float(w_ * h_)
        # positions are fractions of the zone itself (the dark panel), not of the crop around it
        o.update({"fx": (o["cx"] - zx0) / zw, "fy": (o["cy"] - zy0) / zh, "fw": w_ / zw, "fh": h_ / zh, "fill": round(fill, 2)})
        o["kept"] = o["area"] >= min_area_rel * zarea and o["fw"] <= 0.3 and o["fh"] <= 0.12 and fill >= fill_min
        # a segment drawn SPLIT: two bright halves with a darker band between them, the glow
        # holding them together as one blob (every lit segment on the pen's seventh version)
        cw = max(1, (o["x1"] - o["x0"] + 1) // 4)
        xc = (o["x0"] + o["x1"]) // 2
        win = slice(max(o["x0"], xc - cw), min(o["x1"] + 1, xc + cw + 1))
        prof = g[o["y0"]:o["y1"] + 1, win].mean(axis=1) - level[o["y0"]:o["y1"] + 1, win].mean(axis=1)
        o["split"] = False
        k = len(prof)
        if k >= 9:
            # smoothed, so the grain inside a photographed segment never reads as a gap; then a
            # split is a band under half the brightness of BOTH halves, each half a real plateau
            prof = np.convolve(prof, np.ones(3) / 3.0, mode="same")
            for i in range(int(k * 0.35), int(k * 0.65) + 1):
                lp, rp = prof[:i].max(), prof[i + 1:].max()
                if min(lp, rp) <= 0 or prof[i] >= 0.5 * min(lp, rp):
                    continue
                left_plateau = (prof[:i] > 0.75 * lp).sum() >= 0.2 * k
                right_plateau = (prof[i + 1:] > 0.75 * rp).sum() >= 0.2 * k
                if left_plateau and right_plateau:
                    o["split"] = True
                    break
        out.append(o)
    return out, zmask, lab, (float(zx0), float(zy0), zw, zh)


def layout_of(objs, ignore_top=0.28, ignore_bottom=1.0, exclude=(), edge=0.12, min_rel_area=0.35):
    """The marks that count: kept by shape, below the button area, off the zone's rim (a rim
    highlight is never a segment), outside any excluded box (zone fractions)."""
    kept = []
    for o in objs:
        if not o["kept"] or o["fy"] < ignore_top or o["fy"] > ignore_bottom:
            continue
        if o["fx"] < edge or o["fx"] > 1 - edge:
            continue
        if any(x0 <= o["fx"] <= x1 and y0 <= o["fy"] <= y1 for (x0, y0, x1, y1) in exclude):
            continue
        kept.append(o)
    if len(kept) >= 3:
        # a crumb of a glyph or a rim glint is far smaller than the segments around it
        med = float(np.median([o["area"] for o in kept]))
        kept = [o for o in kept if o["area"] >= min_rel_area * med]
    return kept


def compare_layout(kept, target):
    """Marks against the photo's layout: the marks are split into as many columns as the photo
    has, at the widest horizontal gaps (absolute positions differ with how tightly a zone is cut,
    the order of the columns does not), then counted, placed and checked for splits."""
    cols = target.get("columns") or []
    k = len(cols)
    marks = sorted(kept, key=lambda o: o["fx"])
    groups = [[] for _ in range(k)]
    if k and marks:
        gaps = sorted(range(1, len(marks)), key=lambda i: marks[i]["fx"] - marks[i - 1]["fx"], reverse=True)[:k - 1]
        cut = sorted(gaps)
        j, start = 0, 0
        for c in cut + [len(marks)]:
            groups[j] = marks[start:c]; start = c; j += 1
        # columns that are not really apart (one column split in two) do not count as two
        min_gap = float(target.get("min_col_gap", 0.15))
        for i in range(1, k):
            if groups[i] and groups[i - 1] and abs(np.mean([o["fx"] for o in groups[i]]) - np.mean([o["fx"] for o in groups[i - 1]])) < min_gap:
                groups[i - 1] = groups[i - 1] + groups[i]; groups[i] = []
    counts = [len(gr) for gr in groups]
    ys = [sorted(round(o["fy"], 3) for o in gr) for gr in groups]
    want = [int(c["count"]) for c in cols]
    extra = 0 if k else len(kept)
    ok = counts == want and extra == 0
    off = []
    if ok:
        tol_y = float(target.get("tol_y", 0.04))
        for c, got in zip(cols, ys):
            if c.get("y") and len(c["y"]) == len(got):
                d = [abs(a - b) for a, b in zip(sorted(c["y"]), got)]
                off.append(round(max(d), 3))
                ok = ok and max(d) <= tol_y
    splits = sum(1 for o in kept if o.get("split"))
    ok = ok and splits == 0
    return ok, counts, want, extra, ys, splits, off


def fit_circle(xs, ys):
    """Algebraic least-squares circle: (cx, cy, r)."""
    A = np.stack([xs, ys, np.ones_like(xs)], axis=1)
    b = xs ** 2 + ys ** 2
    c = np.linalg.lstsq(A, b, rcond=None)[0]
    cx, cy = c[0] / 2, c[1] / 2
    return float(cx), float(cy), float(np.sqrt(max(1e-9, c[2] + cx ** 2 + cy ** 2)))


# ============================================================================= the multi-panel judge
class Ctx:
    """One sheet: its panels, their roles and their product masks, computed once."""

    def __init__(self, image_path, contract: dict, panel_map=None, base_dir=None, zone_hint=None):
        self.path = Path(image_path)
        # {role: {crop: quad in sheet pixels}}: where the loop pasted a real photo, so a row that
        # reads that photo reads it where it was put, not where a re-detection guesses it is
        self.zone_hint = zone_hint or {}
        self.img = Image.open(image_path).convert("RGB")
        self.gray = npi.to_gray(self.img)
        self.fid = contract.get("fidelity") or {}
        self.thr = float(self.fid.get("fg_threshold", 22))
        self.base_dir = Path(base_dir) if base_dir else self.path.parent
        expect = (self.fid.get("panels") or {}).get("expect") or []
        self.roles = {}
        if isinstance(panel_map, dict):
            # boxes drawn by hand, as fractions of the sheet: for a layout the gutters do not show
            # (panels inside panels, two rows with no gutter between them)
            W, H = self.img.size
            for role, b in panel_map.items():
                self.roles[role] = (int(b[0] * W), int(b[1] * H), int(b[2] * W), int(b[3] * H))
            self.boxes = list(self.roles.values())
        else:
            self.boxes = detect_panels(self.gray)
            roles = list(panel_map) if panel_map else list(expect[:len(self.boxes)])
            for i, b in enumerate(self.boxes):
                if i < len(roles) and roles[i]:
                    self.roles[roles[i]] = b
        self.expect = expect
        self._cache = {}

    def panel(self, role):
        if role not in self.roles:
            return None
        if role not in self._cache:
            x0, y0, x1, y1 = self.roles[role]
            g = self.gray[y0:y1, x0:x1]
            self._cache[role] = {"box": (x0, y0, x1, y1), "gray": g, "rgb": self.img.crop((x0, y0, x1, y1))}
        return self._cache[role]

    def product(self, role, axis=None):
        p = self.panel(role)
        key = ("product", role, axis)
        if key not in self._cache:
            m, bg = product_mask(p["gray"], self.thr)
            self._cache[key] = (m, bg, product_frame(m, axis))
        return self._cache[key]

    def legacy(self, role):
        """The single-panel recipes of one panel, run together in contract order (a window's
        edge reads the window count before it, rivets read where the handle starts)."""
        key = ("legacy", role)
        if key not in self._cache:
            x0, y0, x1, y1 = self.panel(role)["box"]
            W, H = self.img.size
            lms = [{**c} for c in self.fid.get("checks", []) if c.get("panel", "main") == role and c["recipe"] in LEGACY_RECIPES]
            sub = {"fidelity": {**{k: v for k, v in self.fid.items() if k not in ("checks", "texture", "landmarks")},
                                "panel_box": [x0 / W, y0 / H, x1 / W, y1 / H], "landmarks": lms}}
            _, rows = measure(sub, str(self.path), None, None)
            self._cache[key] = rows
        return self._cache[key]

    def resolve(self, rel):
        p = Path(rel)
        return p if p.is_absolute() else self.base_dir / p


def _board(name, out_dir, im: Image.Image, lines=(), scale=None):
    if not out_dir:
        return None
    im = im.convert("RGB")
    if scale is None:
        scale = max(1.0, min(3.0, 360.0 / max(1, min(im.size))))
    if scale != 1.0:
        im = im.resize((max(1, int(im.size[0] * scale)), max(1, int(im.size[1] * scale))), Image.LANCZOS)
    pad = 16 + 15 * len(lines)
    out = Image.new("RGB", (max(im.size[0], 420), im.size[1] + pad), "white")
    out.paste(im, (0, pad))
    d = ImageDraw.Draw(out)
    d.text((6, 3), name, fill=(40, 20, 60))
    for i, t in enumerate(lines):
        d.text((6, 17 + 15 * i), str(t)[:120], fill=(90, 70, 50))
    path = Path(out_dir) / f"board-{name}.png"
    path.parent.mkdir(parents=True, exist_ok=True)
    out.save(path)
    return str(path)


def _hint_box(ctx, role, chk):
    quad = (ctx.zone_hint.get(role) or {}).get(chk.get("crop") or "")
    if not quad:
        return None
    x0, y0 = ctx.panel(role)["box"][:2]
    pts = [(float(x) - x0, float(y) - y0) for x, y in quad]
    tl, tr, br, bl = [np.array(q) for q in pts]
    c = (tl + tr + br + bl) / 4
    side_v = float(np.hypot(*(bl - tl))); side_h = float(np.hypot(*(tr - tl)))
    vv = (tl - bl) / max(1e-9, side_v); hh = (tr - tl) / max(1e-9, side_h)
    if side_v >= side_h:
        major, minor, ax, bx = side_v, side_h, vv, hh
    else:
        major, minor, ax, bx = side_h, side_v, hh, vv
    return {"cx": float(c[0]), "cy": float(c[1]), "major": major, "minor": minor,
            "axis_major": ax.tolist(), "axis_minor": bx.tolist(), "corners": pts,
            "angle": float(np.arctan2(ax[1], ax[0])), "hinted": True}


def _zone_upright(ctx, p, params, chk=None):
    rgb = ctx.panel(p)["rgb"]
    box = _hint_box(ctx, p, chk or {})
    if box is None:
        m, box = find_zone(rgb, params.get("search"), params.get("zone", "dark"), params.get("zone_thr", "auto"),
                           aspect=params.get("aspect"))
    if box is None:
        raise ValueError("the zone was not found on this panel")
    return npi.upright_crop(rgb, box), box


def run_check(ctx: Ctx, chk: dict, out_dir=None) -> dict:
    name, recipe, role = chk["name"], chk["recipe"], chk.get("panel", "main")
    params, target = chk.get("params") or {}, chk.get("target") or {}
    row = {"name": name, "recipe": recipe, "panel": role, "class": chk.get("class") or DEFAULT_CLASS.get(recipe, "other"),
           "sheet": None, "target": None, "ok": None, "note": "", "board": None}
    if recipe != "panel_count" and ctx.panel(role) is None:
        row.update(ok=False, note=f"panel '{role}' is not on this sheet ({len(ctx.boxes)} panels found)",
                   missing_panel=True, **{"class": "structure"})
        return row

    if recipe == "panel_count":
        want = int(target.get("count", len(ctx.expect)))
        row.update(sheet=len(ctx.boxes), target=want, ok=len(ctx.boxes) == want,
                   note=f"{len(ctx.boxes)} panels found, {want} expected")
        if out_dir:
            im = ctx.img.copy(); d = ImageDraw.Draw(im)
            for role, (x0, y0, x1, y1) in ctx.roles.items():
                d.rectangle([x0 + 4, y0 + 4, x1 - 4, y1 - 4], outline=(220, 30, 30), width=max(4, im.size[0] // 400))
                d.text((x0 + 12, y0 + 12), role, fill=(220, 30, 30))
            row["board"] = _board(name, out_dir, im.resize((1200, max(1, int(im.size[1] * 1200 / im.size[0])))), [row["note"]], scale=1.0)
        return row

    if recipe == "finish":
        m, bg, fr = ctx.product(role, params.get("axis"))
        g = ctx.panel(role)["gray"]
        strip_, box = surface_strip(g, m, fr, tuple(params.get("along", (0.2, 0.8))), bg, ctx.thr)
        s = finish_profile(strip_, axis=fr["axis"])
        real = chk.get("real") or {}
        if not real.get("crop"):
            row.update(sheet=s, note="no real crop in the contract: measured, not compared")
            return row
        rim = Image.open(ctx.resolve(real["crop"])).convert("L")
        if real.get("box"):
            W_, H_ = rim.size; b = real["box"]
            rim = rim.crop((int(b[0] * W_), int(b[1] * H_), int(b[2] * W_), int(b[3] * H_)))
        r = finish_profile(np.asarray(rim, dtype=np.float64), axis=real.get("axis", fr["axis"]))
        c = compare_finish(s, r, float(target.get("ratio_max", 2.0)), float(target.get("grain_min", 0.3)))
        row.update(sheet={"grain": s["grain"], "ratio": s["ratio"]}, target={"grain": r["grain"], "ratio": r["ratio"]},
                   ok=c["ok"], note=c["note"], ratio_rel=c["ratio_rel"], grain_rel=c["grain_rel"])
        x0, y0, x1, y1 = box
        crop = ctx.panel(role)["rgb"].crop((x0, y0, x1, y1))
        crop = crop.resize((crop.size[0], max(1, min(crop.size[1], crop.size[0] * 4))))
        row["board"] = _board(name, out_dir, crop, [c["note"]])
        return row

    if recipe == "straight_edges":
        m, bg, fr = ctx.product(role, params.get("axis"))
        g = ctx.panel(role)["gray"]
        pos, left, right = edges_along(g, m, fr, tuple(params.get("along", (0.1, 0.9))), bg, ctx.thr)
        sl = straight_span(pos, left, right)
        if sl.stop - sl.start < 24:
            raise ValueError("no straight stretch to fit")
        width = float(np.median(right[sl] - left[sl]))
        rl, rr = robust_line_rms(pos[sl], left[sl]), robust_line_rms(pos[sl], right[sl])
        worst = max(rl[0], rr[0])
        rel = worst / width
        lim = float(target.get("max_rel", 0.0015))
        floor_px = float(target.get("floor_px", 0.35))       # anti-aliasing and noise alone read about 0.2 px at any width
        lim = max(lim, floor_px / width)
        row.update(sheet=round(rel, 5), target=round(lim, 5), ok=rel <= lim,
                   note=f"outline wanders {worst:.2f} px RMS off a straight line over {sl.stop - sl.start} px ({rel:.5f} of the width {width:.0f} px, limit {lim})")
        if out_dir:
            im = ctx.panel(role)["rgb"].copy(); d = ImageDraw.Draw(im)
            t0, t1 = float(pos[sl][0]), float(pos[sl][-1])
            for _, pfit in (rl, rr):
                a0_, a1_ = np.polyval(pfit, t0), np.polyval(pfit, t1)
                seg = [(a0_, t0), (a1_, t1)] if fr["axis"] == "vertical" else [(t0, a0_), (t1, a1_)]
                d.line(seg, fill=(220, 30, 30), width=2)
            row["board"] = _board(name, out_dir, im, [row["note"]], scale=1.0)
        return row

    if recipe == "blob_layout":
        zone, box = _zone_upright(ctx, role, params, chk)
        objs, zmask, lab, zb = bright_marks(zone, float(params.get("delta", 18)), fill_min=float(params.get("fill_min", 0.55)),
                                            thr=params.get("zone_thr", "auto"))
        kept = layout_of(objs, float(params.get("ignore_top", 0.28)), float(params.get("ignore_bottom", 1.0)),
                         [tuple(e) for e in params.get("exclude", [])])
        ok, counts, want, extra, ys, splits, off = compare_layout(kept, target)
        row.update(sheet={"counts": counts, "extra": extra, "y": ys, "split": splits}, target={"counts": want}, ok=ok,
                   note=f"segments per column {counts} (want {want}), {extra} outside every column, {splits} drawn split"
                        + (f", furthest from the photo's position {max(off):.3f}" if off else ""))
        if out_dir:
            im = zone.convert("RGB"); d = ImageDraw.Draw(im)
            for o in objs:
                col = ((230, 160, 20) if o.get("split") else (40, 200, 60)) if o in kept else (200, 60, 40)
                d.rectangle([o["x0"], o["y0"], o["x1"], o["y1"]], outline=col)
            for c, got in zip(target.get("columns", []), ys):
                for yv in c.get("y") or []:
                    yy = int(zb[1] + yv * zb[3]); d.line([(int(zb[0]), yy), (int(zb[0] + 6), yy)], fill=(60, 120, 230), width=2)
            row["board"] = _board(name, out_dir, im, [row["note"]])
        return row

    if recipe == "ring":
        zone, box = _zone_upright(ctx, role, params, chk)
        objs, zmask, lab, zb = bright_marks(zone, float(params.get("delta", 18)), fill_min=0.0, open_frac=0.0,
                                            thr=params.get("zone_thr", "auto"))
        y0f, y1f = params.get("where", (0.0, 0.34))
        cand = [o for o in objs if y0f <= o["fy"] <= y1f and o["area"] > 0.002 * zb[2] * zb[3]]
        if not cand:
            raise ValueError("no ring found in the zone")
        ring = max(cand, key=lambda o: o["area"])
        ys, xs = np.nonzero(lab == ring["label"])
        cx, cy, r = fit_circle(xs.astype(float), ys.astype(float))
        ang = np.arctan2(ys - cy, xs - cx); rad = np.hypot(xs - cx, ys - cy)
        bins = int(np.clip(2 * np.pi * r / 3.0, 36, 180))         # a wedge about 3 px of arc: fair to a thin ring
        idx = ((ang + np.pi) / (2 * np.pi) * bins).astype(int) % bins
        count = np.bincount(idx, minlength=bins).astype(float)       # pixels per 2-degree wedge ~ the ring's thickness there
        mean_r = np.array([rad[idx == b].mean() if count[b] else np.nan for b in range(bins)])
        med = float(np.median(count)) or 1.0
        whole = count >= 0.5 * med                                     # a wedge at under half the usual thickness is a break
        coverage = float(whole.mean())
        roundness = float(np.nanstd(mean_r) / r) if np.isfinite(mean_r).any() else 1.0
        # a crack: a narrow dark notch across the ring, darker than the ring on either side of it
        g = npi.to_gray(zone)
        width = float(np.percentile(rad, 90) - np.percentile(rad, 10))
        prof = []
        for b in range(360):
            a = (b + 0.5) / 360 * 2 * np.pi - np.pi
            pts = [(int(round(cy + rr * math.sin(a))), int(round(cx + rr * math.cos(a)))) for rr in np.linspace(r - width / 3, r + width / 3, 9)]
            prof.append(float(np.mean([g[min(max(py, 0), g.shape[0] - 1), min(max(px, 0), g.shape[1] - 1)] for py, px in pts])))
        prof = np.array(prof)
        local = np.array([np.median(np.take(prof, range(b - 20, b + 21), mode="wrap")) for b in range(360)])
        dip = float((1 - prof / np.maximum(local, 1.0)).max())
        lim_c, lim_r = float(target.get("coverage_min", 0.97)), float(target.get("roundness_max", 0.05))
        lim_d = float(target.get("dip_max", 0.12))
        row.update(sheet={"coverage": round(coverage, 3), "roundness": round(roundness, 3), "dip": round(dip, 3)},
                   target={"coverage_min": lim_c, "roundness_max": lim_r, "dip_max": lim_d},
                   ok=coverage >= lim_c and roundness <= lim_r and dip <= lim_d,
                   note=f"ring whole on {coverage:.0%} of its circle (min {lim_c:.0%}), radius varies {roundness:.3f} (max {lim_r}), deepest notch {dip:.0%} (max {lim_d:.0%})")
        if out_dir:
            im = zone.convert("RGB"); d = ImageDraw.Draw(im)
            d.ellipse([cx - r, cy - r, cx + r, cy + r], outline=(60, 120, 230))
            for b in range(bins):
                if not whole[b]:
                    a = (b + 0.5) / bins * 2 * np.pi - np.pi
                    d.ellipse([cx + r * math.cos(a) - 3, cy + r * math.sin(a) - 3, cx + r * math.cos(a) + 3, cy + r * math.sin(a) + 3], fill=(220, 40, 40))
            row["board"] = _board(name, out_dir, im, [row["note"]])
        return row

    if recipe == "part_offset":
        rgb = ctx.panel(role)["rgb"]
        box = _hint_box(ctx, role, chk)
        if box is not None:
            em = Image.new("L", rgb.size, 0)
            ImageDraw.Draw(em).polygon([tuple(q) for q in box["corners"]], fill=255)
            # the ellipse inscribed in the hinted quad: shrink the polygon mask to it
            m = np.asarray(em) > 127
            yy, xx = np.nonzero(m)
            d = np.stack([xx - box["cx"], yy - box["cy"]])
            u = (np.array(box["axis_major"]) @ d) / (box["major"] / 2)
            v = (np.array(box["axis_minor"]) @ d) / (box["minor"] / 2)
            keep = u ** 2 + v ** 2 <= 1.0
            m = np.zeros_like(m); m[yy[keep], xx[keep]] = True
        else:
            m, box = find_zone(rgb, params.get("search"), params.get("zone", "dark"), params.get("zone_thr", "auto"),
                               aspect=params.get("aspect"))
        if box is None:
            raise ValueError("the zone was not found on this panel")
        res = offset_in_zone(rgb, m, box, params)
        want, tol = float(target.get("offset", 0.0)), float(target.get("tol", 0.1))
        row.update(sheet=round(res["offset"], 3), target=want, ok=abs(res["offset"] - want) <= tol,
                   note=f"the feature sits {res['offset']:.2f} of the radius from the centre (photo {want:.2f}, tol {tol})")
        if out_dir:
            im = rgb.copy(); d = ImageDraw.Draw(im)
            d.polygon([tuple(p) for p in box["corners"]], outline=(60, 120, 230))
            fx, fy = res["feature"]; d.ellipse([fx - 6, fy - 6, fx + 6, fy + 6], outline=(220, 40, 40), width=3)
            d.ellipse([box["cx"] - 4, box["cy"] - 4, box["cx"] + 4, box["cy"] + 4], fill=(60, 120, 230))
            x0, y0, x1, y1 = (int(min(p[0] for p in box["corners"])), int(min(p[1] for p in box["corners"])),
                              int(max(p[0] for p in box["corners"])), int(max(p[1] for p in box["corners"])))
            row["board"] = _board(name, out_dir, im.crop((max(0, x0 - 20), max(0, y0 - 20), x1 + 20, y1 + 20)), [row["note"]])
        return row

    if recipe == "color":
        rgb = ctx.panel(role)["rgb"]
        val = region_color(rgb, params)
        real = chk.get("real") or {}
        if not real.get("crop"):
            row.update(sheet=val, note="no real crop: measured, not compared")
            return row
        rim = Image.open(ctx.resolve(real["crop"])).convert("RGB")
        ref = region_color(rim, {"box": real.get("box", [0, 0, 1, 1]), "white_box": real.get("white_box")})
        dist = float(sum(abs(a - b) for a, b in zip(val["chroma"], ref["chroma"])))
        tol = float(target.get("tol", 0.04))
        row.update(sheet=val["chroma"], target=ref["chroma"], ok=dist <= tol,
                   note=f"chromaticity off the photo by {dist:.3f} (tol {tol})")
        return row

    if recipe == "object_count":
        g = ctx.panel(role)["gray"]
        bg = panel_background(g)
        fg = npi.fill_holes(np.abs(g - bg) > float(params.get("thr", ctx.thr)))
        lab, n = npi.label(fg)
        objs = npi.objects(lab, n)
        big = max([o["area"] for o in objs], default=0)
        keep = [o for o in objs if o["area"] >= float(params.get("min_area_rel", 0.15)) * big]
        want = int(target.get("count", -1))
        row.update(sheet=len(keep), target=want, ok=len(keep) == want, note=f"{len(keep)} separate pieces (want {want})")
        return row

    if recipe in LEGACY_RECIPES:
        rows_l = ctx.legacy(role)
        if "error" in rows_l:
            row.update(ok=False, note=rows_l["error"].get("note", "no product found in the panel"))
            return row
        r = rows_l.get(name) or {"ok": False, "note": "the single-panel measure returned nothing for this row"}
        row.update(sheet=r.get("sheet"), target=r.get("real"), ok=r.get("ok"), note=r.get("note", ""))
        return row

    raise ValueError(f"no recipe {recipe!r}")


def offset_in_zone(rgb: Image.Image, m, box, params) -> dict:
    """The brightest mark inside a dark zone (a port's metal rim), and its distance from the zone's
    centre in units of the zone's own radius along that direction (the zone is an ellipse when a
    round end is seen at an angle, a circle head-on)."""
    g = npi.to_gray(rgb)
    inner = npi.erode(m, max(2, int(0.04 * box["minor"])))
    level = _local_level(g, inner, max(4, int(0.1 * box["minor"])))
    bright = (g - level > float(params.get("delta", 25))) & inner
    lab, n = npi.label(npi.erode(npi.dilate(bright, 2), 1))
    objs = npi.objects(lab, n)
    if not objs:
        raise ValueError("no feature found inside the zone")
    o = max(objs, key=lambda o: o["area"])
    d = np.array([o["cx"] - box["cx"], o["cy"] - box["cy"]])
    u = float(d @ np.array(box["axis_major"])) / (box["major"] / 2)
    v = float(d @ np.array(box["axis_minor"])) / (box["minor"] / 2)
    return {"offset": float(math.hypot(u, v)), "feature": (o["cx"], o["cy"]), "uv": (u, v)}


def region_color(rgb: Image.Image, params) -> dict:
    a = np.asarray(rgb.convert("RGB"), dtype=np.float64)
    H, W = a.shape[:2]
    def sel(b):
        return a[int(b[1] * H):int(b[3] * H), int(b[0] * W):int(b[2] * W)].reshape(-1, 3)
    if params.get("box"):
        px = sel(params["box"])
    else:
        m, box = find_zone(rgb, params.get("search"), params.get("zone", "dark"), params.get("zone_thr", "auto"),
                           aspect=params.get("aspect"))
        if m is None:
            raise ValueError("the region was not found")
        px = a[m]
    white = sel(params["white_box"]).mean(0) if params.get("white_box") else np.median(
        np.concatenate([a[:4].reshape(-1, 3), a[-4:].reshape(-1, 3)]), axis=0)
    c = px.mean(0) / np.maximum(white, 1.0)
    s = float(c.sum()) or 1.0
    return {"chroma": [round(float(v / s), 4) for v in c], "light": round(float(c.mean()), 3)}


def judge(contract: dict, image_path, panel_map=None, out_dir=None, base_dir=None, zone_hint=None):
    """Every row of a multi-panel contract on one sheet. Returns (ok, rows, info): ok is False
    when any GATED row failed; rows carry status PASS / FAIL (gated) / WARN (ungated) / INFO
    (measured, no target)."""
    ctx = Ctx(image_path, contract, panel_map, base_dir, zone_hint)
    rows = {}
    ok = True
    for chk in (contract.get("fidelity") or {}).get("checks", []):
        try:
            row = run_check(ctx, chk, out_dir)
        except Exception as e:
            row = {"name": chk["name"], "recipe": chk["recipe"], "panel": chk.get("panel"),
                   "class": chk.get("class") or DEFAULT_CLASS.get(chk["recipe"], "other"),
                   "sheet": None, "target": None, "ok": False, "note": f"{type(e).__name__}: {e}", "board": None,
                   "error": True}
        if row.get("ok") is not None:
            row["ok"] = bool(row["ok"])          # a numpy bool is not JSON, and `is False` never matches it
        calibrated = chk["recipe"] in CALIBRATED
        gated = calibrated and chk.get("gate", True) is not False
        if chk.get("gate") is True and not calibrated:
            row["note"] += " (gate requested, but this recipe is not calibrated on two products yet: it warns)"
        row["gated"] = bool(gated)
        if row["ok"] is None:
            row["status"] = "INFO"
        elif row["ok"]:
            row["status"] = "PASS"
        else:
            row["status"] = "FAIL" if gated else "WARN"
        if row.get("error") and not row.get("missing_panel"):
            row["status"] = "FAIL" if gated else "WARN"
        if row["status"] == "FAIL":
            ok = False
        rows[chk["name"]] = row
    info = {"panels": [list(b) for b in ctx.boxes], "roles": {k: list(v) for k, v in ctx.roles.items()},
            "expect": ctx.expect}
    return ok, rows, info


def measure_real(crop_path, recipe: str, spec: dict) -> dict:
    """Measure a real photo crop the way a row will measure the sheet, to write the row's target."""
    img = Image.open(crop_path).convert("RGB")
    # a real crop is cut to the part, so the panel's search window never applies to it
    params = {k: v for k, v in (spec.get("params") or {}).items() if k != "search"}
    if recipe == "finish":
        return finish_profile(npi.to_gray(img), axis=params.get("axis", "vertical"))
    if recipe == "ring":
        c = {"fidelity": {"panels": {"expect": ["p"]}, "checks": [{"name": "ring", "panel": "p", "recipe": "ring",
                                                                   "params": params, "target": {}}]}}
        tmp_ctx = Ctx(crop_path, c, {"p": [0, 0, 1, 1]})
        return run_check(tmp_ctx, c["fidelity"]["checks"][0])["sheet"]
    if recipe == "blob_layout":
        m, box = find_zone(img, params.get("search"), params.get("zone", "dark"), params.get("zone_thr", "auto"),
                           aspect=params.get("aspect"))
        if box is None:
            raise ValueError("the zone was not found on the crop")
        zone = npi.upright_crop(img, box)
        objs, _, _, _ = bright_marks(zone, float(params.get("delta", 18)), fill_min=float(params.get("fill_min", 0.55)),
                                     thr=params.get("zone_thr", "auto"))
        kept = layout_of(objs, float(params.get("ignore_top", 0.28)), float(params.get("ignore_bottom", 1.0)),
                         [tuple(e) for e in params.get("exclude", [])])
        return {"marks": [{"x": round(o["fx"], 3), "y": round(o["fy"], 3), "w": round(o["fw"], 3), "h": round(o["fh"], 3)} for o in kept]}
    if recipe == "part_offset":
        m, box = find_zone(img, params.get("search"), params.get("zone", "dark"), params.get("zone_thr", "auto"),
                           aspect=params.get("aspect"))
        if box is None:
            raise ValueError("the zone was not found on the crop")
        return offset_in_zone(img, m, box, params)
    if recipe == "color":
        return region_color(img, params)
    raise ValueError(f"measure_real has no recipe {recipe!r}")


def main(argv):
    if not argv:
        print(__doc__); return 2
    if argv[0] == "panels" and len(argv) > 1:
        for i, b in enumerate(detect_panels(Image.open(argv[1]))):
            print(i, b)
        return 0
    if argv[0] == "real" and len(argv) > 2:
        spec = json.loads(argv[3]) if len(argv) > 3 else {}
        print(json.dumps(measure_real(argv[1], argv[2], spec), indent=1, default=float)); return 0
    if len(argv) < 2:
        print(__doc__); return 2
    cpath = Path(argv[0])
    contract = json.loads(cpath.read_text())
    image = argv[1]
    panel, out_dir, as_json, pmap = None, None, False, None
    i = 2
    while i < len(argv):
        if argv[i] == "--panel": panel = tuple(float(v) for v in argv[i + 1].split(",")); i += 2
        elif argv[i] == "--out": out_dir = argv[i + 1]; i += 2
        elif argv[i] == "--map": pmap = [s.strip() for s in argv[i + 1].split(",")]; i += 2
        elif argv[i] == "--json": as_json = True; i += 1
        else: i += 1
    fid = contract.get("fidelity") or {}
    if fid.get("checks"):
        ok, rows, info = judge(contract, image, pmap, out_dir, cpath.parent)
        if as_json:
            print(json.dumps({"ok": ok, "rows": rows, "info": info}, indent=1, default=str))
        else:
            print(f"panels: {len(info['panels'])} found, roles {list(info['roles'])}")
            for k, r in rows.items():
                print(f"{r['status']:5s} {k:24s} [{r['class']}] {r['note']}")
            print("VERDICT:", "PASS" if ok else "FAIL")
        return 0 if ok else 1
    if not fid.get("landmarks") and not fid.get("texture"):
        print("the contract has no `fidelity` section (checks, landmarks or texture): nothing to measure mechanically; "
              "the second look (Reference Room step 4a2) and the eye decide"); return 2
    ok, rows = measure(contract, image, panel, out_dir)
    if as_json:
        print(json.dumps({"ok": ok, "rows": rows}, indent=1))
    else:
        for k, r in rows.items():
            tag = "PASS" if r.get("ok") else "FAIL"
            if not r.get("gated", True):
                tag = "INFO"
            print(f"{tag}  {k:22s} sheet {r.get('sheet')!s:>10}  real {r.get('real')!s:>8}  {r.get('note', '')}")
        print("VERDICT:", "PASS" if ok else "FAIL")
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))

"""sheet_fix.py: the loop's local fixes change only what they name, from the base, in one pass.
Run: python3 test_sheet_fix.py

No network, no scipy, no product data: every sheet and every 'photo' is drawn here."""
import json
import sys
import tempfile
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw

HERE = Path(__file__).parent
sys.path.insert(0, str(HERE))
import npimage as npi  # noqa: E402
import sheet_fix as sf  # noqa: E402
import sheet_measure as sm  # noqa: E402

fails = []


def check(name, cond, detail=""):
    print(("  PASS  " if cond else "  FAIL  ") + name + ("" if cond else f"  {detail}"))
    if not cond:
        fails.append(name)


tmp = Path(tempfile.mkdtemp(prefix="sheet_fix_"))
BG = 236


def barrel(w, h, ripple=0.0, grain=3.0, seed=1):
    r = np.random.default_rng(seed)
    x = np.linspace(-1, 1, w)
    base = np.tile(150 + 60 * (1 - x ** 2) ** 0.5, (h, 1)) + r.normal(0, grain, (h, w))
    if ripple:
        blot = npi.gaussian(r.normal(0, 1, (h, w)), w / 10.0)
        base += blot / (blot.std() + 1e-9) * ripple
    return np.clip(np.stack([base * 0.30, base * 0.62, base], axis=2), 0, 255).astype(np.uint8)


def pill(w, h, split=None):
    im = Image.new("RGB", (w, h), (0, 0, 0)); a = Image.new("L", (w, h), 0)
    d = ImageDraw.Draw(im); ImageDraw.Draw(a).rounded_rectangle([0, 0, w - 1, h - 1], radius=w // 2, fill=255)
    d.rounded_rectangle([0, 0, w - 1, h - 1], radius=w // 2, fill=(26, 26, 30))
    cx, cy, rr = w // 2, int(h * 0.17), int(w * 0.30)
    d.ellipse([cx - rr, cy - rr, cx + rr, cy + rr], outline=(150, 150, 156), width=max(4, w // 10))
    sw, sh = max(4, int(w * 0.12)), max(6, int(h * 0.045))
    for ci, (fx, n) in enumerate(((0.3, 3), (0.72, 6))):
        for k in range(n):
            x = int(fx * w); y = int((0.36 + k * 0.085) * h)
            d.rectangle([x - sw // 2, y, x + sw // 2, y + sh], fill=(160, 160, 165))
            if split == (ci, k):
                d.rectangle([x - sw // 2, y + sh // 2 - 1, x + sw // 2, y + sh // 2 + 1], fill=(26, 26, 30))
    return im, a


def pen_panel(W=260, H=900, ripple=0.0, with_pill=True, split=None, seed=1, mark=False):
    p = Image.new("RGB", (W, H), (BG, BG, BG - 2))
    p.paste(Image.fromarray(barrel(90, 760, ripple=ripple, seed=seed)), ((W - 90) // 2, 70))
    if with_pill:
        pim, pa = pill(60, 240, split=split)
        p.paste(pim, ((W - 60) // 2, 480), pa)
    if mark:
        ImageDraw.Draw(p).ellipse([125, 250, 137, 262], fill=(250, 250, 250))
    return p


def end_panel(W=300, H=900, offset=0.0):
    p = Image.new("RGB", (W, H), (BG, BG, BG - 2)); d = ImageDraw.Draw(p)
    cx, cy, a, b = W // 2, 470, 110, 90
    d.ellipse([cx - a, cy - b, cx + a, cy + b], fill=(20, 20, 22))
    py = int(cy - offset * b)
    d.rounded_rectangle([cx - 34, py - 11, cx + 34, py + 11], radius=10, outline=(200, 200, 205), width=4)
    return p


def sheet(panels, H=900, gutter=10):
    W = sum(p.size[0] for p in panels) + gutter * (len(panels) - 1)
    out = Image.new("RGB", (W, H), (BG, BG, BG - 2)); x = 0
    for i, p in enumerate(panels):
        out.paste(p, (x, 0)); x += p.size[0]
        if i < len(panels) - 1:
            out.paste(Image.new("RGB", (gutter, H), (252, 252, 252)), (x, 0)); x += gutter
    return out


arr = lambda p: np.asarray(Image.open(p).convert("RGB")).astype(int)
(tmp / "photos").mkdir()
pim, pa = pill(120, 480)
real_pill = Image.new("RGB", (130, 490), (60, 100, 160)); real_pill.paste(pim, (5, 5), pa)
real_pill.save(tmp / "photos" / "panel-real.png")
end_real = Image.new("RGB", (240, 240), (200, 170, 150)); de = ImageDraw.Draw(end_real)
de.ellipse([10, 10, 230, 230], fill=(22, 20, 20)); de.rounded_rectangle([86, 50, 154, 74], radius=10, outline=(210, 200, 190), width=4)
end_real.save(tmp / "photos" / "end-real.png")
Image.fromarray(barrel(120, 300, seed=5, grain=4.0)).save(tmp / "photos" / "barrel-real.png")

LAY_PARAMS = {"search": [0, 0.4, 1, 0.95], "aspect": [2.5, 6]}
meas = sm.measure_real(tmp / "photos" / "panel-real.png", "blob_layout", {"params": LAY_PARAMS})
L = sorted(m["y"] for m in meas["marks"] if m["x"] < 0.5); R = sorted(m["y"] for m in meas["marks"] if m["x"] >= 0.5)
contract = {"fidelity": {"panels": {"expect": ["front", "back", "end"]}, "checks": [
    {"name": "panels", "recipe": "panel_count", "target": {"count": 3}},
    {"name": "back_finish", "panel": "back", "recipe": "finish", "params": {"along": [0.15, 0.85]},
     "real": {"crop": "photos/barrel-real.png"}},
    {"name": "front_segments", "panel": "front", "recipe": "blob_layout", "params": LAY_PARAMS,
     "target": {"columns": [{"x": 0.3, "count": 3, "y": L}, {"x": 0.72, "count": 6, "y": R}], "tol_y": 0.05},
     "crop": "photos/panel-real.png"},
    {"name": "end_port", "panel": "end", "recipe": "part_offset", "params": {"aspect": [1.0, 2.5]},
     "target": {"offset": 0.6, "tol": 0.15}, "crop": "photos/end-real.png"}]}}
(tmp / "anatomy.json").write_text(json.dumps(contract))

base = sheet([pen_panel(split=(1, 2)), pen_panel(ripple=14.0, with_pill=False), end_panel()])
base.save(tmp / "sheet-v1.png")
sister = sheet([pen_panel(seed=4), pen_panel(with_pill=False, seed=4), end_panel(offset=0.0)])
sister.save(tmp / "sheet-v2.png")
two = sheet([pen_panel(split=(1, 2)), pen_panel(with_pill=False)])
two.save(tmp / "sheet-two.png")

# 1. panel_from REPLACE: the back panel comes from the sister, every other pixel is the base's
print("panel_from")
out = tmp / "c-replace.png"
rec = sf.build(tmp / "sheet-v1.png", [{"op": "panel_from", "role": "back", "source": str(tmp / "sheet-v2.png")}], contract, out, tmp)
b_boxes = sm.detect_panels(base)
a0, a1 = arr(tmp / "sheet-v1.png"), arr(out)
fx0, _, fx1, _ = b_boxes[0]; ex0, _, ex1, _ = b_boxes[2]
check("replace: the front and end panels are byte-identical to the base",
      (a0[:, fx0:fx1] == a1[:, fx0:fx1]).all() and (a0[:, ex0:ex1] == a1[:, ex0:ex1]).all())
_, rows, _ = sm.judge(contract, out, None, None, tmp)
check("replace: the transplanted back panel carries the sister's finish", rows["back_finish"]["ok"] is True, rows["back_finish"]["note"])

# 2. panel_from INSERT: the base has no end panel; the strip is re-laid with three panels
out2 = tmp / "c-insert.png"
rec2 = sf.build(tmp / "sheet-two.png", [{"op": "panel_from", "role": "end", "source": str(tmp / "sheet-v2.png")}], contract, out2, tmp)
check("insert: the sheet now has three panels in the contract's order",
      len(sm.detect_panels(Image.open(out2))) == 3 and rec2["roles"] == ["front", "back", "end"], str(rec2["roles"]))
check("insert: the sheet keeps its size", Image.open(out2).size == two.size)

# 3. paste_zone: the owner's panel replaces a drawn one; nothing outside the destination moves
print("paste_zone")
out3 = tmp / "c-paste.png"
rec3 = sf.build(tmp / "sheet-v1.png", [{"op": "paste_zone", "role": "front", "crop": "photos/panel-real.png", "params": LAY_PARAMS,
                                       "row": "front_segments"}], contract, out3, tmp)
op = rec3["ops"][0]
q = np.array(op["quad"]); x0, y0 = q.min(0); x1, y1 = q.max(0)
a3 = arr(out3)
outside = np.ones(a3.shape[:2], bool); outside[y0:y1 + 1, x0:x1 + 1] = False
check("paste: every pixel outside the destination's box is the base's own", (a0[outside] == a3[outside]).all() and op["outside"] == 0)
_, r_before, _ = sm.judge(contract, tmp / "sheet-v1.png", None, None, tmp)
_, r_after, _ = sm.judge(contract, out3, None, None, tmp, zone_hint={"front": {"photos/panel-real.png": op["quad"]}})
check("paste: the drawn panel failed, the pasted photo reads the photo's layout",
      r_before["front_segments"]["ok"] is False and r_after["front_segments"]["ok"] is True, r_after["front_segments"]["note"])
check("paste: the photo landed on the part (the zone found again overlaps it)", op["zone_overlap"] > 0.6, str(op["zone_overlap"]))
# the photo travels cut to the part's own outline: the quad's corners (outside the pill) stay the base's
tl, tr, br, bl = [np.array(p_, float) for p_ in op["quad"]]
corner_pts = [tl + (tr - tl) * 0.04 + (bl - tl) * 0.02, tr + (tl - tr) * 0.04 + (br - tr) * 0.02,
              br + (bl - br) * 0.04 + (tr - br) * 0.02, bl + (br - bl) * 0.04 + (tl - bl) * 0.02]
same_corners = all((a0[int(round(y_)), int(round(x_))] == a3[int(round(y_)), int(round(x_))]).all() for x_, y_ in corner_pts)
check("paste: the quad's corners, outside the pill, keep the base's pixels (no rectangle of photo around the part)", same_corners)
tiny = Image.new("RGB", (40, 40), (200, 170, 150)); ImageDraw.Draw(tiny).ellipse([2, 2, 37, 37], fill=(22, 20, 20)); tiny.save(tmp / "photos" / "tiny.png")
out4 = tmp / "c-tiny.png"
rec4 = sf.build(tmp / "sheet-v1.png", [{"op": "paste_zone", "role": "end", "crop": "photos/tiny.png", "params": {"aspect": [1.0, 2.5]}, "row": "end_port"},
                                      {"op": "paste_zone", "role": "front", "crop": "photos/panel-real.png", "params": LAY_PARAMS, "row": "front_segments"}],
                contract, out4, tmp)
check("paste: a photo too small to enlarge honestly is refused, and the rest of the recipe still runs",
      rec4["ops"][0].get("refused") and "prints soft" in rec4["ops"][0]["refused"] and not rec4["ops"][1].get("refused"))
out5 = tmp / "c-end.png"
rec5 = sf.build(tmp / "sheet-v1.png", [{"op": "paste_zone", "role": "end", "crop": "photos/end-real.png", "params": {"aspect": [1.0, 2.5]},
                                       "row": "end_port"}], contract, out5, tmp)
_, r5, _ = sm.judge(contract, out5, None, None, tmp, zone_hint={"end": {"photos/end-real.png": rec5["ops"][0]["quad"]}})
_, r5b, _ = sm.judge(contract, tmp / "sheet-v1.png", None, None, tmp)
check("paste: the end cap photo puts the port off-centre where the drawn one was centred",
      r5b["end_port"]["ok"] is False and r5["end_port"]["ok"] is True, f"{r5b['end_port']['note']} | {r5['end_port']['note']}")

# 4. smooth_finish: the ripple goes, the grain and the outline stay, the background never moves
print("smooth_finish")
out6 = tmp / "c-smooth.png"
sf.build(tmp / "sheet-v1.png", [{"op": "smooth_finish", "role": "back", "along": [0.1, 0.9]}], contract, out6, tmp)
_, r6, _ = sm.judge(contract, out6, None, None, tmp)
_, r6b, _ = sm.judge(contract, tmp / "sheet-v1.png", None, None, tmp)
check("smooth: a rippled barrel fails before and passes after", r6b["back_finish"]["ok"] is False and r6["back_finish"]["ok"] is True,
      f"{r6b['back_finish']['note']} | {r6['back_finish']['note']}")
bx0, by0, bx1, by1 = b_boxes[1]
pan0, pan6 = a0[:, bx0:bx1], arr(out6)[:, bx0:bx1]
bgmask = np.abs(pan0.mean(2) - BG) < 4
check("smooth: the background around the barrel is untouched", (pan0[bgmask] == pan6[bgmask]).all())

# 5. recolor, remove_mark, straighten, warp_along
print("recolor, remove_mark, straighten, warp_along")
grey = Image.new("RGB", (60, 60), (128, 128, 128)); grey.save(tmp / "photos" / "grey.png")
out7 = tmp / "c-recolor.png"
sf.build(tmp / "sheet-v1.png", [{"op": "recolor", "role": "back", "box": [0.4, 0.3, 0.6, 0.5], "toward": "photos/grey.png", "strength": 1.0}],
         contract, out7, tmp)
reg = lambda a: a[int(0.3 * 900):int(0.5 * 900), bx0 + int(0.4 * (bx1 - bx0)):bx0 + int(0.6 * (bx1 - bx0))].reshape(-1, 3).mean(0)
c0, c7 = reg(a0), reg(arr(out7))
spread = lambda c: float(c.max() - c.min()) / max(1.0, float(c.mean()))
check("recolor: a blue region moves toward the grey photo", spread(c7) < spread(c0) * 0.6, f"{c0} -> {c7}")
marked = sheet([pen_panel(), pen_panel(with_pill=False, mark=True), end_panel()]); marked.save(tmp / "sheet-mark.png")
out8 = tmp / "c-mark.png"
mb = sm.detect_panels(marked)[1]; mw = mb[2] - mb[0]
sf.build(tmp / "sheet-mark.png", [{"op": "remove_mark", "role": "back", "box": [118 / mw, 244 / 900, 144 / mw, 268 / 900]}], contract, out8, tmp)
a8 = arr(out8); patch = a8[250:262, mb[0] + 125:mb[0] + 137].mean()
around = arr(tmp / "sheet-mark.png")[230:240, mb[0] + 120:mb[0] + 142].mean()
check("remove_mark: the white dot is gone, the patch reads like the barrel around it", abs(patch - around) < 18, f"{patch:.0f} vs {around:.0f}")
c_edges = {"fidelity": {"panels": {"expect": ["front"]}, "checks": [
    {"name": "front_edges", "panel": "front", "recipe": "straight_edges", "params": {"along": [0.05, 0.95]}, "target": {"max_rel": 0.0015}}]}}
wav = Image.new("RGB", (260, 900), (BG, BG, BG - 2)); b_ = barrel(90, 760)
bb = np.full((760, 98, 3), (BG, BG, BG - 2), np.uint8)
for y in range(760):
    s_ = int(round(4 + 1.6 * np.sin(y / 23.0))); bb[y, s_:s_ + 90] = b_[y]
wav.paste(Image.fromarray(bb), (81, 70)); wav.save(tmp / "wavy.png")
out9 = tmp / "c-straight.png"
_, rw0, _ = sm.judge(c_edges, tmp / "wavy.png")
sf.build(tmp / "wavy.png", [{"op": "straighten", "role": "front", "along": [0.05, 0.95]}], c_edges, out9, tmp)
_, rw1, _ = sm.judge(c_edges, out9)
check("straighten: a wandering outline fails before and passes after", rw0["front_edges"]["ok"] is False and rw1["front_edges"]["ok"] is True,
      f"{rw0['front_edges']['note']} | {rw1['front_edges']['note']}")
try:
    big = Image.new("RGB", (260, 900), (BG, BG, BG - 2)); bb2 = np.full((760, 120, 3), (BG, BG, BG - 2), np.uint8)
    for y in range(760):
        s_ = int(round(15 + 12 * np.sin(y / 40.0))); bb2[y, s_:s_ + 90] = b_[y]
    big.paste(Image.fromarray(bb2), (70, 70)); big.save(tmp / "bent.png")
    r10 = sf.build(tmp / "bent.png", [{"op": "straighten", "role": "front", "along": [0.05, 0.95]}], c_edges, tmp / "c-bent.png", tmp)
    refused = bool(r10["ops"][0].get("refused"))
except ValueError:
    refused = True
check("straighten refuses a reshape (an outline off by more than a few pixels)", refused)
band = Image.new("RGB", (260, 900), (BG, BG, BG - 2)); band.paste(Image.fromarray(barrel(90, 760)), (85, 70))
ImageDraw.Draw(band).rectangle([85, 70 + int(0.40 * 759), 174, 70 + int(0.40 * 759) + 8], fill=(15, 15, 15)); band.save(tmp / "band.png")
out11 = tmp / "c-warp.png"
sf.build(tmp / "band.png", [{"op": "warp_along", "role": "front", "points": [[0.40, 0.45]]}], c_edges, out11, tmp)
a11 = arr(out11)[:, 125].mean(1)
dark_rows = np.flatnonzero(a11 < 40)
check("warp_along moves a band from 40% to 45% of the length", len(dark_rows) and abs((dark_rows.min() - 70) / 759 - 0.45) < 0.01,
      str(dark_rows[:3]))

# 6. one pass from the base: the same recipe gives the same pixels, every time
print("determinism")
recipe = [{"op": "panel_from", "role": "back", "source": str(tmp / "sheet-v2.png")},
          {"op": "paste_zone", "role": "front", "crop": "photos/panel-real.png", "params": LAY_PARAMS, "row": "front_segments"},
          {"op": "remove_mark", "role": "back", "box": [0.45, 0.2, 0.55, 0.25]}]
sf.build(tmp / "sheet-v1.png", recipe, contract, tmp / "d1.png", tmp)
sf.build(tmp / "sheet-v1.png", recipe, contract, tmp / "d2.png", tmp)
check("the same base and recipe build byte-identical candidates", (arr(tmp / "d1.png") == arr(tmp / "d2.png")).all())
_raises = True
try:
    sf.build(tmp / "sheet-v1.png", recipe, contract, tmp / "d.jpg", tmp); _raises = False
except ValueError:
    pass
check("a .jpg candidate is refused", _raises)
check("no scipy was imported", "scipy" not in sys.modules)

print()
print("ALL PASS" if not fails else f"{len(fails)} FAILED: " + ", ".join(fails))
sys.exit(1 if fails else 0)

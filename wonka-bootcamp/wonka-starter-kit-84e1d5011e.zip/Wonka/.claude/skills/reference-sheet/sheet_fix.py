#!/usr/bin/env python3
"""The faithfulness loop's local fixes: deterministic pixel operations on a reference sheet.

A sister from Genrupt re-renders EVERY panel, so it re-rolls the finish even from the clean
anchor (seven versions of the engraving pen, seven textures; a knife sister from its anchor came
back mottled). These operations change only what they name and cost nothing:

  panel_from     take one panel from another GENERATED version of the same sheet: replace the
                 base's panel of that role, or insert it when the base has none (re-lays the strip)
  paste_zone     the owner's real photo of an exact feature set onto the zone it belongs in (a
                 control panel, an end cap), found on both images, warped by its four corners,
                 alpha cut to the zone, colour matched (paste_real.py's paste, at depth one)
  smooth_finish  remove the coarse ripple from a surface at the part's own scale, keeping its
                 shading and its fine grain
  recolor        move a part's colour toward the real photo's (white-balanced on both)
  remove_mark    fill a box from the surface around it (an invented glyph, a stray label)
  straighten     move a straight part's outline back onto its fitted line (at most a few pixels)
  warp_along     stretch a part along its axis, piecewise linear (a proportion off the photos)

The rule the loop enforces, and this tool assumes: a candidate is ALWAYS built from its base (a
generated version) plus the full recipe, in one pass. A fix never runs on a fixed file; drop an
operation from the recipe and no trace of it remains.

Usage:
  sheet_fix.py build <base.png> <recipe.json> <out.png> --contract 2-reference/anatomy.json [--map front,back,...]
numpy and pillow only.
"""
from __future__ import annotations

import json
import math
import sys
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw, ImageFilter

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
sys.path.insert(0, str(HERE.parent / "fix"))
import npimage as npi  # noqa: E402
import sheet_measure as sm  # noqa: E402

OPS = ("panel_from", "paste_zone", "smooth_finish", "recolor", "remove_mark", "straighten", "warp_along")


# ============================================================================= the sheet as panels
class Sheet:
    """A working copy of a sheet with its panel boxes and their roles."""

    def __init__(self, img: Image.Image, contract: dict, panel_map=None):
        self.img = img.convert("RGB")
        self.fid = contract.get("fidelity") or {}
        self.expect = list((self.fid.get("panels") or {}).get("expect") or [])
        if isinstance(panel_map, dict):
            W, H = self.img.size
            self.roles = {r: (int(b[0] * W), int(b[1] * H), int(b[2] * W), int(b[3] * H)) for r, b in panel_map.items()}
            self.boxes = list(self.roles.values())
        else:
            self.boxes = sm.detect_panels(self.img)
            roles = list(panel_map) if panel_map else self.expect[:len(self.boxes)]
            self.roles = {r: b for r, b in zip(roles, self.boxes) if r}
        self.thr = float(self.fid.get("fg_threshold", 22))

    def panel(self, role) -> Image.Image:
        x0, y0, x1, y1 = self.roles[role]
        return self.img.crop((x0, y0, x1, y1))

    def put(self, role, panel_img: Image.Image):
        x0, y0, x1, y1 = self.roles[role]
        if panel_img.size != (x1 - x0, y1 - y0):
            raise ValueError(f"panel {role}: the new panel is {panel_img.size}, the slot is {(x1 - x0, y1 - y0)}")
        self.img.paste(panel_img.convert("RGB"), (x0, y0))


def _gutter_strip(img: Image.Image, boxes) -> Image.Image | None:
    """The sheet's own gutter, cut from between its first two panels (None for a one-panel sheet)."""
    if len(boxes) < 2:
        return None
    a, b = boxes[0], boxes[1]
    if b[0] > a[2] and a[1] == b[1]:
        return img.crop((a[2], a[1], b[0], a[3]))
    return None


def _content_span(panel: Image.Image, thr: float, margin: float = 0.08):
    """The columns the panel's content needs: its foreground extent plus a margin of the panel height."""
    g = npi.to_gray(panel)
    bg = sm.panel_background(g)
    fg = np.abs(g - bg) > thr
    cols = np.flatnonzero(fg.sum(0) > max(3, 0.002 * g.shape[0]))
    W = g.shape[1]
    if len(cols) == 0:
        return 0, W
    m = int(margin * g.shape[0] * 0.25)
    return max(0, int(cols.min()) - m), min(W, int(cols.max()) + 1 + m)


def relayout(base: Image.Image, panels: list, gutter: Image.Image | None, size, thr: float) -> tuple:
    """Lay panels side by side on a canvas of `size`, each tightened to its content, all scaled
    down together when they do not fit, padded with each panel's own edge pixels. Returns
    (image, boxes)."""
    W, H = size
    gw = gutter.size[0] if gutter is not None else 0
    tight, bgs = [], []
    for p in panels:
        x0, x1 = _content_span(p, thr)
        tp = p.crop((x0, 0, x1, p.size[1]))
        if tp.size[1] != H:                       # one height for every panel: a taller or shorter sister is scaled to fit
            tp = tp.resize((max(1, int(round(tp.size[0] * H / tp.size[1]))), H), Image.LANCZOS)
        tight.append(tp)
        a_ = np.asarray(p.convert("RGB"))
        ring = np.concatenate([a_[:3].reshape(-1, 3), a_[-3:].reshape(-1, 3), a_[:, :3].reshape(-1, 3), a_[:, -3:].reshape(-1, 3)])
        bgs.append(tuple(int(v) for v in np.median(ring, axis=0)))
    need = sum(t.size[0] for t in tight) + gw * (len(tight) - 1)
    s = min(1.0, (W - gw * (len(tight) - 1)) / max(1, sum(t.size[0] for t in tight)))
    scaled = [t if s >= 0.999 else t.resize((max(1, int(t.size[0] * s)), max(1, int(t.size[1] * s))), Image.LANCZOS) for t in tight]
    spare = W - sum(t.size[0] for t in scaled) - gw * (len(scaled) - 1)
    extra = spare // max(1, len(scaled))
    out = Image.new("RGB", (W, H), (240, 240, 238))
    boxes, x = [], 0
    for i, t in enumerate(scaled):
        pw = t.size[0] + (extra if i < len(scaled) - 1 else W - x - t.size[0] - gw * 0)
        pw = min(pw, W - x)
        pw = max(pw, t.size[0])
        cell = Image.new("RGB", (pw, H), bgs[i])          # the panel's own background colour, never a smear of its edge pixels
        cell.paste(t.convert("RGB"), ((pw - t.size[0]) // 2, (H - t.size[1]) // 2))
        out.paste(cell, (x, 0))
        boxes.append((x, 0, x + pw, H))
        x += pw
        if i < len(scaled) - 1 and gutter is not None:
            out.paste(gutter.resize((gw, H)), (x, 0))
            x += gw
    return out, boxes, {"scale": round(s, 3), "need": need}


# ============================================================================= operations
def op_panel_from(sheet: Sheet, op: dict, ctx: dict) -> dict:
    role = op["role"]
    src_path = Path(op["source"])
    src = Sheet(Image.open(src_path), ctx["contract"], op.get("source_map"))
    srole = op.get("source_role", role)
    if srole not in src.roles:
        raise ValueError(f"panel_from: {src_path.name} has no '{srole}' panel")
    new_panel = src.panel(srole)
    if role in sheet.roles:
        x0, y0, x1, y1 = sheet.roles[role]
        W, H = x1 - x0, y1 - y0
        # fit by height, centre on the content, pad with the panel's own edge
        p = new_panel
        if p.size[1] != H:
            p = p.resize((max(1, int(p.size[0] * H / p.size[1])), H), Image.LANCZOS)
        cx0, cx1 = _content_span(p, sheet.thr)
        if cx1 - cx0 > W:
            s = W / float(cx1 - cx0)
            p = p.resize((max(1, int(p.size[0] * s)), max(1, int(p.size[1] * s))), Image.LANCZOS)
            cx0, cx1 = _content_span(p, sheet.thr)
        centre = (cx0 + cx1) // 2
        a = np.asarray(p.convert("RGB"))
        left = W // 2 - centre
        a = np.pad(a, ((max(0, (H - a.shape[0]) // 2), max(0, H - a.shape[0] - (H - a.shape[0]) // 2)),
                       (max(0, left), max(0, W - a.shape[1] - left)), (0, 0)), mode="edge")
        a = a[:H, max(0, -left):max(0, -left) + W]
        sheet.put(role, Image.fromarray(a))
        return {"op": "panel_from", "role": role, "mode": "replace", "source": src_path.name}
    # insert: the base has no panel of this role; every panel, in the contract's order
    if len({b[1] for b in sheet.boxes}) > 1:
        raise ValueError("panel_from cannot insert into a sheet laid out in several rows; draw the new layout by hand, or let a sister carry the panel")
    order = [r for r in sheet.expect if r in sheet.roles or r == role]
    panels = [new_panel if r == role else sheet.panel(r) for r in order]
    gutter = _gutter_strip(sheet.img, sheet.boxes)
    img, boxes, info = relayout(sheet.img, panels, gutter, sheet.img.size, sheet.thr)
    sheet.img = img
    sheet.boxes = boxes
    sheet.roles = {r: b for r, b in zip(order, boxes)}
    return {"op": "panel_from", "role": role, "mode": "insert", "source": src_path.name, "layout_scale": info["scale"]}


def shape_mask(size, aspect: float, shape: str = "auto") -> Image.Image:
    """The zone's ideal outline inside its upright rectangle: a stadium (a pill-shaped control
    panel) when it is long, an ellipse (an end cap) when it is round. A photo's zone mask also
    catches the shadowed barrel beside the part; the ideal outline does not."""
    w, h = size
    m = Image.new("L", (w * 4, h * 4), 0)
    d = ImageDraw.Draw(m)
    if shape == "ellipse" or (shape == "auto" and aspect < 1.35):
        d.ellipse([0, 0, w * 4 - 1, h * 4 - 1], fill=255)
    else:
        r = min(w, h) * 2                       # semicircular ends on the short side
        d.rounded_rectangle([0, 0, w * 4 - 1, h * 4 - 1], radius=r, fill=255)
    return m.resize((w, h), Image.LANCZOS)


def _crop_to_zone(crop_path: Path, params: dict) -> Image.Image:
    """The owner's crop cut to its own zone, upright, with the zone's ideal outline as its alpha
    (so the barrel or the background around the part never travels with it)."""
    img = Image.open(crop_path).convert("RGB")
    cp = {k: v for k, v in params.items() if k != "search"}
    m, box = sm.find_zone(img, None, cp.get("zone", "dark"), cp.get("zone_thr", "auto"), aspect=cp.get("aspect"))
    if box is None:
        raise ValueError(f"the zone was not found on the crop {crop_path.name}")
    if box["major"] / max(1.0, box["minor"]) < 1.35:
        # a round zone has no principal axis worth trusting: cut it straight, the photo's top stays its top
        ys, xs = np.nonzero(m)
        x0, x1, y0, y1 = int(xs.min()), int(xs.max()) + 1, int(ys.min()), int(ys.max()) + 1
        box = {"cx": (x0 + x1) / 2, "cy": (y0 + y1) / 2, "major": float(max(x1 - x0, y1 - y0)), "minor": float(min(x1 - x0, y1 - y0)),
               "corners": [(x0, y0), (x1, y0), (x1, y1), (x0, y1)], "axis_major": [0.0, -1.0], "axis_minor": [1.0, 0.0], "angle": 0.0}
    up = npi.upright_crop(img, box)
    if cp.get("shape", "auto") == "mask":
        mask = Image.fromarray((m * 255).astype(np.uint8), "L")
        alpha = npi.upright_crop(mask, box).point(lambda v: 255 if v > 127 else 0).filter(ImageFilter.GaussianBlur(1.2))
    else:
        alpha = shape_mask(up.size, box["major"] / max(1.0, box["minor"]), cp.get("shape", "auto"))
    rgba = up.convert("RGBA")
    rgba.putalpha(alpha)
    return rgba


def _quad_from_box(box: dict, prefer_up: bool = True) -> list:
    """The zone's rotated rectangle as a paste quad (TL, TR, BR, BL). For a round zone (an end cap
    seen at an angle) the rotation is free; the crop's top is turned toward the image's top."""
    c = [tuple(map(float, p)) for p in box["corners"]]
    if prefer_up and box["major"] / max(1.0, box["minor"]) < 1.35:
        best = None
        for k in range(4):
            q = c[k:] + c[:k]
            top_mid_y = (q[0][1] + q[1][1]) / 2
            if best is None or top_mid_y < best[0]:
                best = (top_mid_y, q)
        c = best[1]
    return [(int(round(x)), int(round(y))) for x, y in c]


def op_paste_zone(sheet: Sheet, op: dict, ctx: dict) -> dict:
    import paste_real as pr
    role = op["role"]
    params = op.get("params") or {}
    panel = sheet.panel(role)
    m, box = sm.find_zone(panel, params.get("search"), params.get("zone", "dark"), params.get("zone_thr", "auto"),
                          aspect=params.get("aspect"))
    if box is None:
        raise ValueError(f"paste_zone: the zone was not found on panel '{role}'")
    crop = _crop_to_zone(ctx["resolve"](op["crop"]), {**params, **(op.get("crop_params") or {})})
    # a small outset by default: the photo's own rim lands on the sheet's rim, so the sheet's drawn
    # outline does not peek out beside it as a second edge (the "doubled outline" an owner caught by hand)
    grow = float(op.get("grow", 0.02)) - float(op.get("inset", 0.0))
    if grow:
        cx, cy = box["cx"], box["cy"]
        grown = [(cx + (x - cx) * (1 + grow), cy + (y - cy) * (1 + grow)) for x, y in box["corners"]]
        pw, ph = panel.size
        if grow < 0 or all(0 <= x <= pw - 1 and 0 <= y <= ph - 1 for x, y in grown):
            box = dict(box, corners=grown)      # a zone at the panel's edge keeps its own size
    q = _quad_from_box(box)
    x0, y0, _, _ = sheet.roles[role]
    qs = [(x + x0, y + y0) for x, y in q]
    res = pr.paste(sheet.img, crop, qs, feather=int(op.get("feather", 6)), match=float(op.get("match", 0.6)),
                   max_upscale=float(op.get("max_upscale", pr.MAX_UPSCALE_DEFAULT)))
    before = sheet.img
    sheet.img = res["image"]
    # did the photo land ON the part: the zone found again after the paste must overlap the zone
    # it replaced (a zone's outline is a real edge, so a colour step there means nothing)
    m2, _ = sm.find_zone(sheet.panel(role), params.get("search"), params.get("zone", "dark"),
                         params.get("zone_thr", "auto"), aspect=params.get("aspect"))
    iou = float((m & m2).sum() / max(1, (m | m2).sum())) if m2 is not None else 0.0
    if iou < float(op.get("min_overlap", 0.5)):
        sheet.img = before
        raise ValueError(f"the photo did not land on the part (its zone overlaps the drawn one by {iou:.2f}, minimum {op.get('min_overlap', 0.5)})")
    return {"op": "paste_zone", "role": role, "crop": Path(op["crop"]).name, "quad": [list(p) for p in qs],
            "scale": res["scale"], "zone_overlap": round(iou, 3), "inside": res["inside"], "outside": res["outside"],
            "max_upscale": float(op.get("max_upscale", pr.MAX_UPSCALE_DEFAULT))}


def _product(sheet: Sheet, role, axis=None):
    panel = sheet.panel(role)
    g = npi.to_gray(panel)
    m, bg = sm.product_mask(g, sheet.thr)
    fr = sm.product_frame(m, axis)
    return panel, g, m, bg, fr


def op_smooth_finish(sheet: Sheet, op: dict, ctx: dict) -> dict:
    """Remove the coarse texture band (the ripple) from the part's surface between two fractions
    of its length, at the part's own scale; shading and fine grain stay. Feathered at the part's
    outline so the edge itself is untouched."""
    role = op["role"]
    panel, g, m, bg, fr = _product(sheet, role, op.get("axis"))
    pos, left, right = sm.edges_along(g, m, fr, tuple(op.get("along", (0.1, 0.9))), bg, sheet.thr)
    sl = sm.straight_span(pos, left, right)
    if sl.stop - sl.start < 24:
        raise ValueError("smooth_finish: no straight stretch in that range")
    width = float(np.median(right[sl] - left[sl]))
    k = width / sm.FINISH_W0                       # sheet pixels per measuring pixel
    lo, hi = float(op.get("band_lo", 3.0)) * k, float(op.get("band_hi", 24.0)) * k
    strength = float(op.get("strength", 1.0))
    a = np.asarray(panel, dtype=np.float64)
    vertical = fr["axis"] == "vertical"
    if not vertical:
        a = a.transpose(1, 0, 2); m = m.T
    p0, p1 = int(pos[sl][0]), int(pos[sl][-1])
    region = np.zeros(m.shape, bool)
    region[p0:p1 + 1] = True
    region &= m
    # the outline stays: weight 0 at the edge, 1 a few pixels in
    inner = npi.erode(region, max(2, int(0.04 * width)))
    wgt = npi.gaussian(inner.astype(float), max(1.0, 0.02 * width))
    wgt = np.clip(wgt * 1.6, 0, 1) * region
    out = a.copy()
    for c in range(3):
        ch = a[..., c]
        fill = np.where(region, ch, ch[region].mean())
        shade = npi.gaussian1d(fill, 100.0 * k, axis=0)         # the light along a cylinder runs with its length (half a width)
        resid = np.where(region, ch - shade, 0.0)                # the texture alone; the background contributes nothing
        band = npi.gaussian(resid, lo) - npi.gaussian(resid, hi)
        out[..., c] = ch - strength * wgt * band
    out = np.clip(out, 0, 255)
    if not vertical:
        out = out.transpose(1, 0, 2)
    sheet.put(role, Image.fromarray(out.astype(np.uint8)))
    return {"op": "smooth_finish", "role": role, "band_px": [round(lo, 1), round(hi, 1)], "strength": strength,
            "rows": [p0, p1]}


def _region_mask(sheet: Sheet, role, op) -> np.ndarray:
    panel = sheet.panel(role)
    W, H = panel.size
    b = op.get("box") or (op.get("params") or {}).get("box")
    if b:
        m = np.zeros((H, W), bool)
        m[int(b[1] * H):int(b[3] * H), int(b[0] * W):int(b[2] * W)] = True
        return m
    p = op.get("params") or {}
    m, box = sm.find_zone(panel, p.get("search"), p.get("zone", "dark"), p.get("zone_thr", "auto"), aspect=p.get("aspect"))
    if m is None:
        raise ValueError(f"the region was not found on panel '{role}'")
    return m


def op_recolor(sheet: Sheet, op: dict, ctx: dict) -> dict:
    role = op["role"]
    panel = sheet.panel(role)
    m = _region_mask(sheet, role, op)
    a = np.asarray(panel, dtype=np.float64)
    white = np.median(np.concatenate([a[:4].reshape(-1, 3), a[-4:].reshape(-1, 3)]), axis=0)
    ref = sm.region_color(Image.open(ctx["resolve"](op["toward"])).convert("RGB"),
                          {"box": op.get("toward_box", [0, 0, 1, 1]), "white_box": op.get("toward_white_box")})
    cur = a[m].mean(0) / np.maximum(white, 1)
    tgt = np.array(ref["chroma"]) * float(cur.sum())          # same lightness, the photo's chromaticity
    gain = np.clip(tgt / np.maximum(cur, 1e-3), 0.5, 2.0)
    strength = float(op.get("strength", 0.8))
    soft = npi.gaussian(m.astype(float), 1.5)
    out = a * (1 + (gain[None, None, :] - 1) * (strength * soft)[..., None])
    sheet.put(role, Image.fromarray(np.clip(out, 0, 255).astype(np.uint8)))
    return {"op": "recolor", "role": role, "gain": [round(float(v), 3) for v in gain], "strength": strength}


def op_remove_mark(sheet: Sheet, op: dict, ctx: dict) -> dict:
    """Fill the box from the surface around it: a diffusion fill (the shading continues across),
    then the ring's own grain added back so the patch is not a smear."""
    role = op["role"]
    panel = sheet.panel(role)
    m = _region_mask(sheet, role, op)
    a = np.asarray(panel, dtype=np.float64)
    ring = npi.dilate(m, 6) & ~m
    if not ring.any():
        raise ValueError("remove_mark: the box has no surroundings")
    out = a.copy()
    rng = np.random.default_rng(7)
    for c in range(3):
        ch = a[..., c].copy()
        ch[m] = ch[ring].mean()
        for _ in range(int(op.get("iterations", 200))):
            sm_ = npi.box_mean(ch, 1)
            ch[m] = sm_[m]
        grain = (a[..., c] - npi.gaussian(a[..., c], 2.0))[ring].std()
        ch[m] += rng.normal(0, grain, int(m.sum()))
        out[..., c] = ch
    sheet.put(role, Image.fromarray(np.clip(out, 0, 255).astype(np.uint8)))
    return {"op": "remove_mark", "role": role, "pixels": int(m.sum())}


def op_straighten(sheet: Sheet, op: dict, ctx: dict) -> dict:
    """Shift each line of a straight part sideways so its two outline edges land on their fitted
    lines; the shift fades to zero at the part's centre, so only the outline band moves. Refuses
    to move anything more than `max_px` (a straighten is a correction, not a reshape)."""
    role = op["role"]
    panel, g, m, bg, fr = _product(sheet, role, op.get("axis"))
    pos, left, right = sm.edges_along(g, m, fr, tuple(op.get("along", (0.1, 0.9))), bg, sheet.thr)
    sl = sm.straight_span(pos, left, right)
    if sl.stop - sl.start < 24:
        raise ValueError("straighten: no straight stretch in that range")
    t = pos[sl]
    _, pl = sm.robust_line_rms(t, left[sl]); _, pr_ = sm.robust_line_rms(t, right[sl])
    dl = np.polyval(pl, t) - left[sl]; dr = np.polyval(pr_, t) - right[sl]
    max_px = float(op.get("max_px", 3.0))
    if max(np.abs(dl).max(), np.abs(dr).max()) > max_px:
        raise ValueError(f"straighten: the outline is off by up to {max(np.abs(dl).max(), np.abs(dr).max()):.1f} px (limit {max_px}); that is a reshape, not a correction")
    a = np.asarray(panel, dtype=np.float64)
    vertical = fr["axis"] == "vertical"
    if not vertical:
        a = a.transpose(1, 0, 2)
    out = a.copy()
    Wl = a.shape[1]
    xs = np.arange(Wl, dtype=np.float64)
    for i, y in enumerate(t.astype(int)):
        L, R = left[sl][i], right[sl][i]
        mid = (L + R) / 2
        # displacement field across the line: dl at the left edge, dr at the right, 0 at the centre
        disp = np.where(xs < mid, dl[i] * np.clip((mid - xs) / max(1.0, mid - L), 0, 1.5),
                        dr[i] * np.clip((xs - mid) / max(1.0, R - mid), 0, 1.5))
        src = np.clip(xs - disp, 0, Wl - 1)
        for c in range(3):
            out[y, :, c] = np.interp(src, xs, a[y, :, c])
    if not vertical:
        out = out.transpose(1, 0, 2)
    sheet.put(role, Image.fromarray(np.clip(out, 0, 255).astype(np.uint8)))
    return {"op": "straighten", "role": role, "max_shift_px": round(float(max(np.abs(dl).max(), np.abs(dr).max())), 2)}


def op_warp_along(sheet: Sheet, op: dict, ctx: dict) -> dict:
    """Remap the panel along the product's axis: `points` are [from, to] pairs as fractions of the
    product's length (0 and 1 are pinned), so a handle that starts at 58% can be moved to 61%."""
    role = op["role"]
    panel, g, m, bg, fr = _product(sheet, role, op.get("axis"))
    pts = sorted([(0.0, 0.0), (1.0, 1.0)] + [tuple(p) for p in op["points"]])
    src_f = np.array([p[0] for p in pts]); dst_f = np.array([p[1] for p in pts])
    a = np.asarray(panel, dtype=np.float64)
    vertical = fr["axis"] == "vertical"
    if not vertical:
        a = a.transpose(1, 0, 2)
    lo = fr["y0"] if vertical else fr["x0"]
    L = fr["length"]
    n = a.shape[0]
    yy = np.arange(n, dtype=np.float64)
    f = (yy - lo) / L
    inside = (f >= 0) & (f <= 1)
    src = yy.copy()
    src[inside] = lo + np.interp(f[inside], dst_f, src_f) * L
    out = np.empty_like(a)
    for c in range(3):
        for x in range(a.shape[1]):
            out[:, x, c] = np.interp(src, yy, a[:, x, c])
    if not vertical:
        out = out.transpose(1, 0, 2)
    sheet.put(role, Image.fromarray(np.clip(out, 0, 255).astype(np.uint8)))
    return {"op": "warp_along", "role": role, "points": [list(p) for p in op["points"]]}


DISPATCH = {"panel_from": op_panel_from, "paste_zone": op_paste_zone, "smooth_finish": op_smooth_finish,
            "recolor": op_recolor, "remove_mark": op_remove_mark, "straighten": op_straighten, "warp_along": op_warp_along}


def build(base_path, recipe: list, contract: dict, out_path, base_dir=None, panel_map=None) -> dict:
    """The candidate = the base + the whole recipe, in one pass. panel_from operations run first
    (they set the layout), the others in recipe order. Writes the candidate and a regions file
    beside it; returns the record of what each operation did."""
    base_path, out_path = Path(base_path), Path(out_path)
    if out_path.suffix.lower() != ".png":
        raise ValueError("a candidate is written as .png")
    root = Path(base_dir) if base_dir else Path(".")
    resolve = lambda rel: (Path(rel) if Path(rel).is_absolute() else root / rel)
    sheet = Sheet(Image.open(base_path), contract, panel_map)
    ctx = {"contract": contract, "resolve": resolve}
    done = []
    ordered = [o for o in recipe if o["op"] == "panel_from"] + [o for o in recipe if o["op"] != "panel_from"]
    for op in ordered:
        if op["op"] not in DISPATCH:
            raise ValueError(f"no operation {op['op']!r} (known: {', '.join(OPS)})")
        if op["op"] == "panel_from":
            op = dict(op, source=str(resolve(op["source"])))
        try:
            done.append(DISPATCH[op["op"]](sheet, op, ctx))
        except (ValueError, OSError, KeyError) as e:
            # one refused operation (a photo too small to enlarge honestly, a zone not found, a crop
            # file missing) is recorded and the rest of the recipe still runs; its row stays failing
            if op["op"] == "panel_from":
                raise ValueError(f"panel_from {op.get('role')}: {e}")
            done.append({"op": op["op"], "role": op.get("role"), "row": op.get("row"), "refused": f"{type(e).__name__}: {e}"})
    out_path.parent.mkdir(parents=True, exist_ok=True)
    sheet.img.save(out_path)
    ev = sheet.img.copy()
    d = ImageDraw.Draw(ev)
    for r in done:
        if r.get("quad"):
            d.line([tuple(p) for p in r["quad"]] + [tuple(r["quad"][0])], fill=(255, 0, 0), width=4)
    for role, (x0, y0, x1, y1) in sheet.roles.items():
        d.rectangle([x0, y0, x1 - 1, y1 - 1], outline=(30, 90, 220), width=3)
        d.text((x0 + 8, y0 + 8), role, fill=(30, 90, 220))
    ev.save(out_path.with_name(out_path.stem + "-regions.png"))
    W, H = sheet.img.size
    boxes = {r: [round(b[0] / W, 5), round(b[1] / H, 5), round(b[2] / W, 5), round(b[3] / H, 5)] for r, b in sheet.roles.items()}
    return {"base": str(base_path), "out": str(out_path), "ops": done, "roles": list(sheet.roles), "boxes": boxes}


def _cli(argv) -> int:
    if len(argv) < 4 or argv[0] != "build":
        print(__doc__); return 2
    base, recipe_path, out = argv[1], argv[2], argv[3]
    contract_path, pmap = None, None
    i = 4
    while i < len(argv):
        if argv[i] == "--contract": contract_path = argv[i + 1]; i += 2
        elif argv[i] == "--map": pmap = [s.strip() for s in argv[i + 1].split(",")]; i += 2
        else: i += 1
    if not contract_path:
        print("build needs --contract (the anatomy contract names the panels)"); return 2
    contract = json.loads(Path(contract_path).read_text())
    recipe = json.loads(Path(recipe_path).read_text())
    try:
        rec = build(base, recipe, contract, out, Path(contract_path).parent, pmap)
    except ValueError as e:
        print(str(e), file=sys.stderr); return 1
    print(json.dumps(rec, indent=1))
    return 0


if __name__ == "__main__":
    sys.exit(_cli(sys.argv[1:]))

#!/usr/bin/env python3
"""numpy-only image helpers for the Reference Room's measuring and fixing tools.

The kit installs numpy and pillow and nothing else (`/machines-check` checks openai, numpy, PIL
and dotenv), so nothing in the Reference Room may need scipy: before October 2026 two of
sheet_measure.py's rows (counting enclosed windows, the texture row) needed it and quietly
skipped on every student's machine. Everything here takes and returns numpy arrays: float64 for
images, bool for masks, int32 for labels.
"""
from __future__ import annotations

import numpy as np
from PIL import Image


# ----------------------------------------------------------------------------- filters
def _conv1d(a: np.ndarray, k: np.ndarray, axis: int) -> np.ndarray:
    r = (len(k) - 1) // 2
    n = a.shape[axis]
    pad = [(0, 0)] * a.ndim
    pad[axis] = (r, r)
    mode = "symmetric" if n >= r else "edge"
    pp = np.pad(a, pad, mode=mode)
    out = np.zeros_like(a, dtype=np.float64)
    for i, w in enumerate(k):
        sl = [slice(None)] * a.ndim
        sl[axis] = slice(i, i + n)
        out += w * pp[tuple(sl)]
    return out


def gaussian1d(a, sigma: float, axis: int, truncate: float = 3.0, mode: str = "symmetric") -> np.ndarray:
    """A true Gaussian along one axis (kernel to `truncate` sigma; edges mirrored, scipy's 'reflect')."""
    a = np.asarray(a, dtype=np.float64)
    if sigma <= 0:
        return a.copy()
    r = max(1, int(truncate * sigma + 0.5))
    x = np.arange(-r, r + 1, dtype=np.float64)
    k = np.exp(-0.5 * (x / sigma) ** 2)
    return _conv1d(a, k / k.sum(), axis)


def gaussian(a, sigma: float, truncate: float = 3.0, mode: str = "symmetric") -> np.ndarray:
    """A true separable Gaussian over the two spatial axes. sigma 0 returns a float copy.
    (edit_core's three-box approximation overshoots small sigmas by about 2x, which is fine for
    its ring gate and wrong for a band-pass that has to land on a named scale.)"""
    out = gaussian1d(a, sigma, 0, truncate)
    return gaussian1d(out, sigma, 1, truncate)


def box_mean(a, r: int) -> np.ndarray:
    """Mean over a (2r+1) square, edges replicated, by cumulative sums."""
    a = np.asarray(a, dtype=np.float64)
    if r <= 0:
        return a.copy()
    out = a
    for axis in (0, 1):
        n = out.shape[axis]
        pad = [(0, 0), (0, 0)]
        pad[axis] = (r + 1, r)
        pp = np.pad(out, pad, mode="edge")
        c = np.cumsum(pp, axis=axis)
        hi = np.take(c, range(2 * r + 1, 2 * r + 1 + n), axis=axis)
        lo = np.take(c, range(0, n), axis=axis)
        out = (hi - lo) / (2 * r + 1)
    return out


def to_gray(img) -> np.ndarray:
    """A PIL image or an array to float64 luminance."""
    if isinstance(img, Image.Image):
        return np.asarray(img.convert("L"), dtype=np.float64)
    a = np.asarray(img, dtype=np.float64)
    return a if a.ndim == 2 else a[..., :3] @ np.array([0.299, 0.587, 0.114])


# ----------------------------------------------------------------------------- morphology
def _minmax(m: np.ndarray, iterations: int, fn) -> np.ndarray:
    out = m.copy()
    for _ in range(iterations):
        p = np.pad(out, 1, mode="edge")
        stack = [p[1:-1, 1:-1], p[:-2, 1:-1], p[2:, 1:-1], p[1:-1, :-2], p[1:-1, 2:],
                 p[:-2, :-2], p[:-2, 2:], p[2:, :-2], p[2:, 2:]]
        out = fn(np.stack(stack), axis=0)
    return out


def erode(mask, iterations: int = 1) -> np.ndarray:
    m = np.asarray(mask, bool)
    return _minmax(m, iterations, np.all) if iterations > 0 else m.copy()


def erode_cross(mask, iterations: int = 1) -> np.ndarray:
    """Erosion by a 3x3 CROSS with a False border, scipy's binary_erosion defaults."""
    out = np.asarray(mask, bool).copy()
    for _ in range(iterations):
        p = np.pad(out, 1, mode="constant", constant_values=False)
        out = p[1:-1, 1:-1] & p[:-2, 1:-1] & p[2:, 1:-1] & p[1:-1, :-2] & p[1:-1, 2:]
    return out


def dilate(mask, iterations: int = 1) -> np.ndarray:
    m = np.asarray(mask, bool)
    return _minmax(m, iterations, np.any) if iterations > 0 else m.copy()


# ----------------------------------------------------------------------------- connected components
def label(mask, connectivity: int = 8):
    """(labels, n): connected components of a boolean mask, labels 1..n, 0 = background.
    Run-length union-find, so the Python loop runs per run of pixels, never per pixel."""
    m = np.asarray(mask, bool)
    H, W = m.shape
    labels = np.zeros((H, W), np.int32)
    parent = [0]

    def find(x):
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x

    reach = 1 if connectivity == 8 else 0
    prev, runs = [], []
    for y in range(H):
        row = m[y]
        if not row.any():
            prev = []
            continue
        d = np.diff(np.concatenate(([0], row.view(np.int8), [0])))
        starts = np.flatnonzero(d == 1).tolist()
        ends = (np.flatnonzero(d == -1) - 1).tolist()
        cur, j = [], 0
        for s, e in zip(starts, ends):
            rid = len(parent)
            parent.append(rid)
            lo, hi = s - reach, e + reach
            while j < len(prev) and prev[j][1] < lo:
                j += 1
            k = j
            while k < len(prev) and prev[k][0] <= hi:
                a, b = find(rid), find(prev[k][2])
                if a != b:
                    parent[max(a, b)] = min(a, b)
                k += 1
            cur.append((s, e, rid))
            runs.append((y, s, e, rid))
        prev = cur
    roots, n = {}, 0
    for (y, s, e, rid) in runs:
        r = find(rid)
        if r not in roots:
            n += 1
            roots[r] = n
        labels[y, s:e + 1] = roots[r]
    return labels, n


def objects(labels: np.ndarray, n: int) -> list:
    """Per label 1..n: dict(y0, y1, x0, x1 inclusive, area, cy, cx). Empty labels are skipped."""
    if n == 0:
        return []
    ys, xs = np.nonzero(labels)
    lab = labels[ys, xs]
    area = np.bincount(lab, minlength=n + 1)
    big = np.iinfo(np.int64).max
    y0 = np.full(n + 1, big); x0 = np.full(n + 1, big)
    y1 = np.full(n + 1, -1); x1 = np.full(n + 1, -1)
    np.minimum.at(y0, lab, ys); np.minimum.at(x0, lab, xs)
    np.maximum.at(y1, lab, ys); np.maximum.at(x1, lab, xs)
    sy = np.bincount(lab, weights=ys, minlength=n + 1)
    sx = np.bincount(lab, weights=xs, minlength=n + 1)
    out = []
    for i in range(1, n + 1):
        if area[i] == 0:
            continue
        out.append({"label": i, "y0": int(y0[i]), "y1": int(y1[i]), "x0": int(x0[i]), "x1": int(x1[i]),
                    "area": int(area[i]), "cy": float(sy[i] / area[i]), "cx": float(sx[i] / area[i])})
    return out


def largest(mask) -> np.ndarray:
    """The largest connected component of a mask (all False when the mask is empty)."""
    lab, n = label(mask)
    if n == 0:
        return np.zeros_like(np.asarray(mask, bool))
    area = np.bincount(lab.ravel(), minlength=n + 1)
    area[0] = 0
    return lab == int(np.argmax(area))


def fill_holes(mask) -> np.ndarray:
    """Background regions that do not touch the border become foreground."""
    m = np.asarray(mask, bool)
    lab, n = label(~m, connectivity=4)
    if n == 0:
        return m.copy()
    border = set(np.unique(np.concatenate([lab[0], lab[-1], lab[:, 0], lab[:, -1]])).tolist())
    holes = ~np.isin(lab, list(border | {0}))
    return m | holes


# ----------------------------------------------------------------------------- geometry
def principal_box(mask):
    """The mask's rotated bounding rectangle along its principal axes.
    Returns dict(cx, cy, angle (radians of the MAJOR axis from +x, in (-pi/2, pi/2]),
    major, minor (full lengths along each axis), corners [(x, y)] * 4) with the corners ordered
    from the major axis's end nearer the TOP of the image: (top-left, top-right, bottom-right,
    bottom-left) as seen when the major axis is turned upright. None for an empty mask."""
    ys, xs = np.nonzero(np.asarray(mask, bool))
    if len(xs) < 3:
        return None
    cx, cy = float(xs.mean()), float(ys.mean())
    X = np.stack([xs - cx, ys - cy]).astype(np.float64)
    cov = X @ X.T / len(xs)
    w, v = np.linalg.eigh(cov)
    major = v[:, int(np.argmax(w))]
    if major[1] > 0 or (major[1] == 0 and major[0] < 0):
        major = -major                       # point the major axis UP (toward smaller y)
    minor = np.array([-major[1], major[0]])  # perpendicular, pointing to the right of "up"
    if minor[0] < 0:
        minor = -minor
    pm, pn = major @ X, minor @ X
    a0, a1, b0, b1 = float(pm.min()), float(pm.max()), float(pn.min()), float(pn.max())
    c = np.array([cx, cy])
    tl = c + major * a1 + minor * b0
    tr = c + major * a1 + minor * b1
    br = c + major * a0 + minor * b1
    bl = c + major * a0 + minor * b0
    ang = float(np.arctan2(major[1], major[0]))
    return {"cx": cx, "cy": cy, "angle": ang, "major": a1 - a0, "minor": b1 - b0,
            "axis_major": major.tolist(), "axis_minor": minor.tolist(),
            "corners": [tuple(map(float, p)) for p in (tl, tr, br, bl)]}


def upright_crop(img: Image.Image, box: dict, pad: float = 0.0, scale: float = 1.0) -> Image.Image:
    """Resample the rotated rectangle `box` (from principal_box) into an upright image, the
    major axis vertical, top end first. `pad` widens it by a fraction of its own size."""
    tl, tr, br, bl = [np.array(p) for p in box["corners"]]
    if pad:
        c = (tl + tr + br + bl) / 4
        tl, tr, br, bl = [c + (p - c) * (1 + 2 * pad) for p in (tl, tr, br, bl)]
    w = max(2, int(round(np.hypot(*(tr - tl)) * scale)))
    h = max(2, int(round(np.hypot(*(bl - tl)) * scale)))
    # PIL QUAD maps the output rectangle onto the source quad: upper-left, lower-left, lower-right, upper-right
    data = (*tl, *bl, *br, *tr)
    return img.transform((w, h), Image.QUAD, data, Image.BICUBIC)

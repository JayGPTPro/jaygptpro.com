"""paste_real.py: the owner's photo of a part goes into the frame at depth one, and nothing else moves.
Run: python3 test_paste_real.py

No network. Every check runs on images built in a temp folder: the geometry, the feather, the
colour match, the refusals, the lineage record, and the depth rule shared with edit_core."""
import json
import os
import sys
import tempfile
from pathlib import Path

import numpy as np
from PIL import Image

HERE = Path(__file__).parent
sys.path.insert(0, str(HERE))
import edit_core as ec  # noqa: E402
import paste_real as pr  # noqa: E402

fails = []
def check(name, cond):
    print(("  PASS  " if cond else "  FAIL  ") + name)
    if not cond:
        fails.append(name)


def scene(size=(400, 300), seed=3):
    """A rendered-looking frame: a gradient with a checker so every pixel is distinct."""
    w, h = size
    img = Image.new("RGB", size); px = img.load()
    for y in range(h):
        for x in range(w):
            c = 30 if ((x // 11) + (y // 11)) % 2 else 180
            px[x, y] = ((x + seed * 7) % 256, (c + y // 3) % 256, (x * 2 + y + seed) % 256)
    return img


def crop_img(size=(120, 80), color=(20, 200, 40), corner=(250, 30, 30)):
    """A 'photo' of the part: flat green with a red top-left corner marker."""
    im = Image.new("RGB", size, color)
    im.paste(Image.new("RGB", (12, 12), corner), (0, 0))
    return im


tmp = Path(tempfile.mkdtemp(prefix="paste_real_"))
root = tmp / "factory" / "Products" / "pen"
(root / "images").mkdir(parents=True); (root / "edits" / "v1").mkdir(parents=True); (root / "photos").mkdir()
os.chdir(root)
scene().save(root / "images" / "sec-03.png")
crop_img().save(root / "photos" / "panel-crop.png")
# a crop with transparency: a round button
rgba = Image.new("RGBA", (100, 100), (0, 0, 0, 0))
from PIL import ImageDraw
ImageDraw.Draw(rgba).ellipse([0, 0, 99, 99], fill=(200, 200, 210, 255))
rgba.save(root / "photos" / "button.png")

# 1. an upright paste, no matching: inside is the crop, outside is byte for byte the target
t = root / "images" / "sec-03.png"; out = root / "edits" / "v1" / "sec-03.png"
rec = pr.run_paste(t, root / "photos" / "panel-crop.png", out, pr.rect_quad("100,80,120,80"), feather=0, match=0.0)
a = np.asarray(Image.open(t).convert("RGB")).astype(int); b = np.asarray(Image.open(out).convert("RGB")).astype(int)
diff = np.abs(a - b).sum(2) > 0
check("nothing outside the destination changed", diff[:80, :].sum() == 0 and diff[160:, :].sum() == 0 and diff[:, :100].sum() == 0 and diff[:, 220:].sum() == 0)
check("the middle of the destination is the photo's pixel", tuple(b[120, 160]) == (20, 200, 40))
check("the crop's corner marker landed at the destination's top-left", tuple(b[84, 104]) == (250, 30, 30))
check("the record is a depth-one paste with the crop as its prompt id", rec["op"] == "paste_real" and rec["boxes"][-1]["depth"] == 1 and rec["prompt_id"].startswith("paste:"))
check("the evidence file with the quad drawn exists and carries the -regions suffix", (root / "edits" / "v1" / "sec-03-regions.png").exists())
lin = ec.Lineage(out)
check("the lineage knows the pasted file", lin.known(ec.pixel_hash(Image.open(out))))
check("the target is on record as the clean base of that box", lin.latest(ec.pixel_hash(Image.open(out)))["anchor"] == ec.pixel_hash(Image.open(t)))

# 2. a perspective paste: the corner marker follows the quad's top-left, not the bounding box's
out2 = root / "edits" / "v1" / "sec-04.png"; scene(seed=9).save(root / "images" / "sec-04.png")
q = pr.parse_quad("120,60,260,90,250,220,110,200")
big_crop = crop_img(size=(240, 160)); big_crop.paste(Image.new("RGB", (24, 24), (250, 30, 30)), (0, 0)); big_crop.save(root / "photos" / "panel-big.png")
rec2 = pr.run_paste(root / "images" / "sec-04.png", root / "photos" / "panel-big.png", out2, q, feather=0, match=0.0)
b2 = np.asarray(Image.open(out2).convert("RGB")).astype(int)
check("perspective: a pixel just inside the quad's top-left corner is the red marker", tuple(b2[64, 126]) == (250, 30, 30))
check("perspective: the bounding-box corner outside the quad is untouched", tuple(b2[61, 111]) == tuple(np.asarray(scene(seed=9))[61, 111]))
check("perspective: the middle is the photo", tuple(b2[140, 185]) == (20, 200, 40))

# 3. the feather ramps from the base at the edge to the photo `feather` px in
out3 = root / "edits" / "v1" / "sec-05.png"; scene(seed=4).save(root / "images" / "sec-05.png")
pr.run_paste(root / "images" / "sec-05.png", root / "photos" / "panel-crop.png", out3, pr.rect_quad("100,80,120,80"), feather=10, match=0.0)
b3 = np.asarray(Image.open(out3).convert("RGB")).astype(int); s3 = np.asarray(scene(seed=4)).astype(int)
check("feather: the first pixel inside the edge is (almost) the base", np.abs(b3[120, 100] - s3[120, 100]).max() <= 30)
check("feather: ten pixels in it is the photo", tuple(b3[120, 112]) == (20, 200, 40))
check("feather: outside stays byte-identical", (np.abs(b3 - s3).sum(2)[:, :100] > 0).sum() == 0)

# 4. colour match moves the crop's mean toward the target's under the footprint
tgt = Image.open(root / "images" / "sec-05.png")
r0 = pr.paste(tgt, crop_img(), pr.rect_quad("100,80,120,80"), feather=0, match=0.0)
r1 = pr.paste(tgt, crop_img(), pr.rect_quad("100,80,120,80"), feather=0, match=1.0)
under = np.asarray(tgt.convert("RGB"))[80:160, 100:220].reshape(-1, 3).mean(0)
m0 = np.asarray(r0["image"])[80:160, 100:220].reshape(-1, 3).mean(0); m1 = np.asarray(r1["image"])[80:160, 100:220].reshape(-1, 3).mean(0)
check("match 1.0 brings the pasted mean to the target's mean", np.abs(m1 - under).max() < 6 and np.abs(m0 - under).max() > 20)
check("the numbers are reported per channel", set(r1["match"]) == {"r", "g", "b"})

# 5. transparency in the crop rides into the mask
r5 = pr.paste(tgt, Image.open(root / "photos" / "button.png"), pr.rect_quad("150,100,100,100"), feather=0, match=0.0)
o5 = np.asarray(r5["image"]).astype(int); s5 = np.asarray(tgt.convert("RGB")).astype(int)
check("alpha: the square's corner outside the circle is untouched", tuple(o5[101, 151]) == tuple(s5[101, 151]))
check("alpha: the circle's centre is the button", tuple(o5[150, 200]) == (200, 200, 210))

# 6. refusals, nothing written
def refused(fn, needle):
    try:
        fn(); return False
    except (SystemExit, ValueError) as e:
        return needle in str(e)
big = pr.rect_quad("20,20,360,240")
check("a crop enlarged past the limit is refused", refused(lambda: pr.paste(tgt, crop_img(), big, max_upscale=1.5), "prints soft"))
check("a corner outside the frame is refused", refused(lambda: pr.validate_quad(pr.rect_quad("300,200,200,200"), tgt.size), "outside"))
check("a folded quad is refused", refused(lambda: pr.validate_quad(pr.parse_quad("10,10,100,100,100,10,10,100"), tgt.size), "degenerate"))
check("a destination under 8 px is refused", refused(lambda: pr.validate_quad(pr.rect_quad("10,10,100,4"), tgt.size), "dot"))
check("an evidence name for the output is refused", refused(lambda: pr.run_paste(t, root / "photos" / "panel-crop.png", root / "edits" / "v1" / "x-regions.png", pr.rect_quad("100,80,120,80")), "evidence suffix"))
check("a non-png output is refused", refused(lambda: pr.run_paste(t, root / "photos" / "panel-crop.png", root / "edits" / "v1" / "x.jpg", pr.rect_quad("100,80,120,80")), ".png"))
check("--quad wants eight numbers", refused(lambda: pr.parse_quad("1,2,3"), "eight"))
check("a missing crop is a sentence", refused(lambda: pr.run_paste(t, root / "photos" / "nope.png", root / "edits" / "v1" / "y.png", pr.rect_quad("100,80,120,80")), "no such file"))
check("the refused runs wrote nothing", not (root / "edits" / "v1" / "x-regions.png").exists() and not (root / "edits" / "v1" / "y.png").exists())

# 7. depth: a paste over an earlier fix waits for --covers-earlier, then takes its ring from the clean base
(root / "edits" / "v2").mkdir()
prev = root / "edits" / "v1" / "sec-03.png"            # depth 1 inside 100,80,120,80 from test 1
out7 = root / "edits" / "v2" / "sec-03.png"
check("pasting onto an earlier fix without the flag stops with the depth sentence",
      refused(lambda: pr.run_paste(prev, root / "photos" / "panel-crop.png", out7, pr.rect_quad("110,90,60,40")), "--covers-earlier"))
check("... and wrote nothing", not out7.exists())
rec7 = pr.run_paste(prev, root / "photos" / "panel-crop.png", out7, pr.rect_quad("110,90,60,40"), feather=0, match=0.0, covers=True)
b7 = np.asarray(Image.open(out7).convert("RGB")).astype(int)
check("with the flag the box became the union of both fixes", rec7["boxes"][-1]["box"] == [100, 80, 120, 80])
check("with the flag the ring under the paste came from the clean base, not the earlier render", tuple(b7[85, 105]) == tuple(np.asarray(scene())[85, 105]))
check("the anchor on record is still the original frame", rec7["anchor"] == ec.pixel_hash(Image.open(t)))

# 8. --draw writes evidence and no lineage
n_before = len(ec.Lineage(t).records)
rc = pr._cli(["--draw", str(t), str(root / "edits" / "v2" / "sec-03-regions.png"), "--rect", "100,80,120,80"])
check("--draw exits 0 and writes the regions file", rc == 0 and (root / "edits" / "v2" / "sec-03-regions.png").exists())
check("--draw touches no lineage", len(ec.Lineage(t).records) == n_before)
check("cli: no destination is a sentence", pr._cli([str(t), str(root / "photos" / "panel-crop.png"), str(root / "edits" / "v2" / "z.png")]) == 2)
check("cli: both --quad and --rect is a sentence", pr._cli([str(t), "c.png", "o.png", "--quad", "1,1,2,1,2,2,1,2", "--rect", "1,1,2,2"]) == 2)

# 9. every record is valid json on its own line
lines = (root / "edits" / "lineage.jsonl").read_text().splitlines()
check("lineage lines all parse", all(json.loads(l) for l in lines if l.strip()))

print()
print("ALL PASS" if not fails else f"{len(fails)} FAILED: " + ", ".join(fails))
sys.exit(1 if fails else 0)

#!/usr/bin/env python3
"""The Fixing Room's edit core: one command that renders a fix from the right base, at the frame's
own size, pastes only the box back, measures the drift, and writes the lineage.

Why this exists (26 September 2026). The edit endpoint re-renders the whole frame on every call,
so a fix made on top of an earlier fix stacks the model's own texture: after a few rounds a
brushed-steel blade reads as hammered foil and a face gets the plastic, over-filtered look the
owner complained about. Measured on a 2048 main frame: three stacked fixes carried twice the
drift on the pixels nobody touched compared with the same three fixes made in one pass from the
clean base. And the old path shrank every frame to 1024 before editing, which alone lost a
quarter of the detail in one pass (0.73 kept, against 0.94 when the frame goes at its own size).

The rule the tool enforces, so no skill text has to remember it:
  1. The ANCHOR (what the model is shown) is the version in which the pixels inside the box are
     at depth 0. The TARGET (what the render is pasted onto) is the current chosen version.
     A box on untouched pixels: the target is the anchor. A box that overlaps an earlier fix:
     the render comes from that fix's anchor, the box widens to the union of both, and the
     instruction must carry both fixes (`--covers-earlier` says it does). Pixels never stack;
     instructions do.
  2. Depth is a property of pixels: `edits/lineage.jsonl` keeps a list of boxes per file, keyed
     by a hash of the decoded pixels, so copying a file into the next round or renaming it
     changes nothing.
  3. The frame goes to the API at its own size (any size up to 3840x2160, edges padded to a
     multiple of 16 and cropped back). Only above that is it downscaled.
  4. The gate blocks only what is never acceptable (a pixel outside the box changed, the API
     returned a different size, a lossy container, a window that came back shifted); the texture
     numbers on the ring around the box are WARNINGS written into the lineage and printed, and
     the eye at 3x decides the box itself. A measurement that disagrees with a careful look loses.

Usage (from the kit root):
  edit_core.py edit <target.png> <out.png> "<one change>" --box x,y,w,h [--box ...] [--sheet ref.png]
                    [--quality low|high] [--window] [--covers-earlier] [--override-depth "why"]
                    [--declare-anchor "why"] [--gate off|warn|block] [--faces]
  edit_core.py register <image> [--origin genrupt|generation|photo|external|upscale] [--from <image>] [--note text]
  edit_core.py show <image>
  edit_core.py declare-anchor <image> "<why>"
  edit_core.py migrate <product folder>     one-time: reconstructs depth for images/, edits/vN, aplus/, variations/

Env: WONKA_IMAGE_MODEL (the factory's one model setting), WONKA_DEPTH_GATE=off|warn|block (default
warn), WONKA_DEPTH_UNKNOWN=warn|declare (default warn: a file with no lineage is registered as an
anchor with a warning, so a product mid-run is never stuck). Needs only pillow, numpy, openai.
"""
from __future__ import annotations

import base64
import hashlib
import io
import json
import os
import re
import sys
import time
from pathlib import Path

import numpy as np
from PIL import Image

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from composite_region import RING_LIMIT, boundary_ring_max, feather_mask, parse_boxes  # noqa: E402

API_MAX_LONG, API_MAX_SHORT = 3840, 2160
API_EXPERIMENTAL_LONG, API_EXPERIMENTAL_SHORT = 2560, 1440
ASPECT_MAX = 3.0
DEFAULT_THRESHOLDS = {
    "retention_min": 0.75, "retention_max": 1.30, "blotch_max": 1.50, "de_p95_max": 8.0,
    "shift_max_px": 1, "min_ring_px": 5000, "grid_long_edge": 1600, "flat_erosion_px": 8,
    "seam_band_max": 24.0, "gate_default": "warn",
}
GATE_MODES = ("off", "warn", "block")
ORIGINS = ("generation", "photo", "genrupt", "external", "upscale")
FEATHER_DEFAULT = 24
EVIDENCE = re.compile(r"-(rejected|render|boxes|regions)(-\d+)?$", re.I)


# ----------------------------------------------------------------------------- the factory's settings
def image_model() -> str:
    """The factory's one image-model setting: WONKA_IMAGE_MODEL from the environment or the
    nearest .env upward, else gpt-image-2.5-sunburst (CLAUDE.md, 'Which image model')."""
    v = os.environ.get("WONKA_IMAGE_MODEL", "").strip()
    if v:
        return v
    for a in [Path.cwd()] + list(Path.cwd().parents):
        f = a / ".env"
        if f.is_file():
            for line in f.read_text(errors="ignore").splitlines():
                s = line.strip()
                s = s[7:].strip() if s.startswith("export ") else s
                k, _, val = s.partition("=")
                if k.strip() == "WONKA_IMAGE_MODEL":
                    val = val.split("#", 1)[0].strip().strip('"').strip("'")
                    if val:
                        return val
    return "gpt-image-2.5-sunburst"


def load_key():
    """OPENAI_API_KEY from the environment, else the nearest .env upward."""
    if os.environ.get("OPENAI_API_KEY"):
        return
    for a in [Path.cwd()] + list(Path.cwd().parents):
        f = a / ".env"
        if f.is_file():
            for line in f.read_text(errors="ignore").splitlines():
                if line.strip().startswith("OPENAI_API_KEY="):
                    os.environ["OPENAI_API_KEY"] = line.split("=", 1)[1].strip().strip('"').strip("'")
                    return


def thresholds() -> dict:
    """The gate's numbers, from `.claude/skills/fix/gate.json` when present (the file the
    routine-fix policy names), else the defaults above."""
    t = dict(DEFAULT_THRESHOLDS)
    p = HERE / "gate.json"
    try:
        t.update({k: v for k, v in json.loads(p.read_text()).items() if k in t and k != "_"})
    except Exception:
        pass
    return t


def gate_mode(explicit: str | None = None) -> str:
    """--gate, else WONKA_DEPTH_GATE, else gate.json's gate_default, else warn."""
    m = (explicit or os.environ.get("WONKA_DEPTH_GATE") or str(thresholds().get("gate_default") or "warn")).lower()
    if m not in GATE_MODES:
        raise ValueError(f"--gate must be one of {', '.join(GATE_MODES)} (got {m!r})")
    return m


# ----------------------------------------------------------------------------- hashes and intake
def pixel_hash(img) -> str:
    """sha256 over the DECODED pixels: the same picture hashes the same whatever its file name,
    round folder or metadata; a lossy save does not."""
    im = img
    if im.mode not in ("RGB", "RGBA"):
        im = im.convert("RGBA" if ("A" in im.mode or im.mode == "P") else "RGB")
    h = hashlib.sha256()
    h.update(im.mode.encode()); h.update(f"{im.size[0]}x{im.size[1]}".encode()); h.update(im.tobytes())
    return h.hexdigest()


def intake_normalize(img):
    """EXIF orientation applied; an embedded non-sRGB profile (phone photos are Display P3)
    converted to sRGB when Pillow's colour module is available; alpha kept."""
    from PIL import ImageOps
    notes = []
    out = ImageOps.exif_transpose(img)
    if out is not img:
        notes.append("exif_transposed")
    icc = out.info.get("icc_profile")
    if icc:
        try:
            from PIL import ImageCms
            src = ImageCms.ImageCmsProfile(io.BytesIO(icc))
            desc = ImageCms.getProfileDescription(src) or ""
            if "srgb" not in desc.lower():
                mode = "RGBA" if out.mode == "RGBA" else "RGB"
                out = ImageCms.profileToProfile(out.convert(mode), src, ImageCms.createProfile("sRGB"), outputMode=mode)
                notes.append(f"icc_to_srgb:{desc.strip()[:40]}")
            out.info.pop("icc_profile", None)
        except Exception as e:
            notes.append(f"icc_unreadable:{type(e).__name__}")
    return out, notes


# ----------------------------------------------------------------------------- lineage
def product_root(start: Path) -> Path:
    """The product folder: the first ancestor that holds `images/` or `status.md` (a factory
    product), else the folder itself."""
    cur = start if start.is_dir() else start.parent
    for _ in range(6):
        if (cur / "images").is_dir() or (cur / "status.md").is_file():
            return cur
        if cur.parent == cur:
            break
        cur = cur.parent
    return start if start.is_dir() else start.parent


class Lineage:
    """`edits/lineage.jsonl` in the product folder, append-only, one line per event."""

    def __init__(self, start: Path, path: Path | None = None):
        root = product_root(Path(start).resolve())
        self.root = root
        self.path = Path(path) if path else root / "edits" / "lineage.jsonl"
        self.records = self.load(self.path)

    @staticmethod
    def load(path: Path) -> list:
        out = []
        if path.exists():
            for line in path.read_text().splitlines():
                line = line.strip()
                if line:
                    try:
                        out.append(json.loads(line))
                    except json.JSONDecodeError:
                        continue
        return out

    def append(self, rec: dict) -> dict:
        rec = dict(rec)
        rec.setdefault("ts", time.strftime("%Y-%m-%dT%H:%M:%S"))
        rec.setdefault("pid", os.getpid())
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with open(self.path, "a") as f:
            f.write(json.dumps(rec, ensure_ascii=False) + "\n")
        self.records = self.load(self.path)
        return rec

    def latest(self, sha: str):
        for rec in reversed(self.records):
            if rec.get("sha") == sha:
                return rec
        return None

    def known(self, sha: str) -> bool:
        return self.latest(sha) is not None

    @staticmethod
    def _intersects(a, b) -> bool:
        if a is None or b is None:
            return True
        ax, ay, aw, ah = a; bx, by, bw, bh = b
        return ax < bx + bw and bx < ax + aw and ay < by + bh and by < ay + ah

    def boxes_of(self, sha: str) -> list:
        rec = self.latest(sha)
        return list(rec.get("boxes") or []) if rec else []

    def depth_in(self, sha: str, boxes: list):
        rec = self.latest(sha)
        if rec is None:
            return None
        d = 0
        for b in rec.get("boxes") or []:
            if any(self._intersects(b.get("box"), r) for r in (boxes or [None])):
                dv = b.get("depth", 0)
                d = max(d, int(dv) if isinstance(dv, int) else 0)
        return d

    def earlier_edits_in(self, sha: str, boxes: list) -> list:
        return [b for b in self.boxes_of(sha)
                if isinstance(b.get("depth"), int) and b["depth"] >= 1
                and any(self._intersects(b.get("box"), r) for r in (boxes or [None]))]

    def resolve_anchor(self, target_sha: str, boxes: list):
        """(anchor_sha, earlier_boxes, union_box). Depth 0 under the boxes: the target is the
        anchor and there is no union. Otherwise the recorded anchor of the overlapping fix(es)
        and the union of the request with their boxes."""
        earlier = self.earlier_edits_in(target_sha, boxes)
        if not earlier:
            return target_sha, [], None
        anchors = {b.get("anchor") for b in earlier if b.get("anchor")}
        anchor = anchors.pop() if len(anchors) == 1 else self._walk_to_depth0(target_sha, boxes)
        union = None
        if boxes and all(b.get("box") for b in earlier):
            union = union_boxes([tuple(b["box"]) for b in earlier] + list(boxes))
        return anchor, earlier, union

    def _walk_to_depth0(self, sha: str, boxes: list) -> str:
        seen, cur = set(), sha
        while cur and cur not in seen:
            seen.add(cur)
            rec = self.latest(cur)
            if rec is None or self.depth_in(cur, boxes) == 0:
                return cur
            cur = rec.get("anchor") or rec.get("from")
        return cur or sha

    def locate(self, sha: str, near: list):
        rec = self.latest(sha)
        if rec and rec.get("file"):
            p = Path(rec["file"])
            if not p.is_absolute():
                p = self.root / p
            if p.exists():
                try:
                    if pixel_hash(Image.open(p)) == sha:
                        return p
                except Exception:
                    pass
        for d in near:
            d = Path(d)
            if not d.is_dir():
                continue
            for p in sorted(list(d.glob("*.png")) + list(d.glob("*.jpg")))[:400]:
                try:
                    if pixel_hash(Image.open(p)) == sha:
                        return p
                except Exception:
                    continue
        return None

    def rel(self, p: Path) -> str:
        try:
            return str(Path(p).resolve().relative_to(self.root))
        except ValueError:
            return str(Path(p).resolve())


def union_boxes(boxes: list):
    boxes = [tuple(b) for b in boxes if b]
    if not boxes:
        return None
    x0 = min(b[0] for b in boxes); y0 = min(b[1] for b in boxes)
    x1 = max(b[0] + b[2] for b in boxes); y1 = max(b[1] + b[3] for b in boxes)
    return (x0, y0, x1 - x0, y1 - y0)


def next_boxes(target_boxes: list, union, depth: int, anchor_sha: str, prompt_id) -> list:
    if union is None:
        return [{"box": None, "depth": depth, "anchor": anchor_sha, "prompt_id": prompt_id}]
    ux, uy, uw, uh = union
    kept = []
    for b in target_boxes:
        bx = b.get("box")
        if bx is None:
            if isinstance(b.get("depth"), int) and b["depth"] >= 1:
                kept.append(b)
            continue
        x, y, w, h = bx
        if not (x >= ux and y >= uy and x + w <= ux + uw and y + h <= uy + uh):
            kept.append(b)
    kept.append({"box": [ux, uy, uw, uh], "depth": depth, "anchor": anchor_sha, "prompt_id": prompt_id})
    return kept


# ----------------------------------------------------------------------------- sizes
def _round16(v: int, up: bool = True) -> int:
    return ((v + 15) // 16) * 16 if up else (v // 16) * 16


def native_api_size(w: int, h: int) -> dict:
    long_, short_ = max(w, h), min(w, h)
    if long_ / short_ > ASPECT_MAX:
        raise ValueError(f"the frame's aspect ({long_ / short_:.2f}:1) is outside the endpoint's 1:3 to 3:1; edit a window (--window) or a crop")
    scale = min(1.0, API_MAX_LONG / long_, API_MAX_SHORT / short_)
    if scale < 1.0:
        sw, sh = _round16(int(w * scale), up=False), _round16(int(h * scale), up=False)
        return dict(send=(sw, sh), pad=(0, 0), scale=scale, source=(w, h),
                    experimental=max(sw, sh) > API_EXPERIMENTAL_LONG or min(sw, sh) > API_EXPERIMENTAL_SHORT)
    sw, sh = _round16(w), _round16(h)
    return dict(send=(sw, sh), pad=(sw - w, sh - h), scale=1.0, source=(w, h),
                experimental=max(sw, sh) > API_EXPERIMENTAL_LONG or min(sw, sh) > API_EXPERIMENTAL_SHORT)


def pad_edge(img, pad):
    pw, ph = pad
    if not pw and not ph:
        return img
    a = np.asarray(img)
    a = np.pad(a, [(0, ph), (0, pw)] + [(0, 0)] * (a.ndim - 2), mode="edge")
    return Image.fromarray(a, img.mode)


def prepare_for_api(img):
    info = native_api_size(*img.size)
    if info["scale"] < 1.0:
        return img.resize(info["send"], Image.BOX), info
    return pad_edge(img, info["pad"]), info


def restore_from_api(returned, info):
    """Crop the padding back off (or upsample after a downscale). A size that differs from the
    request raises: the tool never resamples a mismatch quietly."""
    if tuple(returned.size) != tuple(info["send"]):
        raise ValueError(f"the endpoint returned {returned.size[0]}x{returned.size[1]} for a {info['send'][0]}x{info['send'][1]} request")
    w, h = info["source"]
    if info["scale"] < 1.0:
        return returned.resize((w, h), Image.LANCZOS), True
    pw, ph = info["pad"]
    return (returned.crop((0, 0, w, h)) if (pw or ph) else returned), False


def window_for(boxes: list, size, feather: int, margin_frac: float = 0.25, min_margin: int = 48):
    W, H = size
    u = union_boxes(boxes)
    if u is None:
        return None
    x, y, w, h = u
    m = max(min_margin + feather, int(max(w, h) * margin_frac))
    ww, wh = _round16(min(W, w + 2 * m)), _round16(min(H, h + 2 * m))
    ww, wh = min(ww, _round16(W, up=False)), min(wh, _round16(H, up=False))
    wx = min(max(0, x + w // 2 - ww // 2), W - ww)
    wy = min(max(0, y + h // 2 - wh // 2), H - wh)
    return (wx, wy, ww, wh)


# ----------------------------------------------------------------------------- numpy-only filters (no scipy in the kit)
def _box_blur(a: np.ndarray, r: int) -> np.ndarray:
    if r <= 0:
        return a
    out = a
    for axis in (0, 1):
        n = out.shape[axis]
        pad = [(0, 0), (0, 0)]; pad[axis] = (r, r)
        pp = np.pad(out, pad, mode="edge")
        c = np.cumsum(pp, axis=axis, dtype=np.float64)
        c = np.concatenate([np.zeros_like(np.take(c, [0], axis=axis)), c], axis=axis)
        hi = np.take(c, range(2 * r + 1, 2 * r + 1 + n), axis=axis)
        lo = np.take(c, range(0, n), axis=axis)
        out = (hi - lo) / (2 * r + 1)
    return out


def gaussian(a: np.ndarray, sigma: float) -> np.ndarray:
    """Three box blurs approximate a Gaussian of this sigma (the same trick tone matching uses)."""
    if sigma <= 0:
        return a.astype(np.float64)
    r = max(1, int(round(sigma * (3.0 / 3) ** 0.5)))
    out = a.astype(np.float64)
    for _ in range(3):
        out = _box_blur(out, r)
    return out


def laplace(a: np.ndarray) -> np.ndarray:
    p = np.pad(a, 1, mode="edge")
    return p[:-2, 1:-1] + p[2:, 1:-1] + p[1:-1, :-2] + p[1:-1, 2:] - 4 * a


def _minmax(m: np.ndarray, iterations: int, fn) -> np.ndarray:
    out = m.copy()
    for _ in range(iterations):
        p = np.pad(out, 1, mode="edge")
        stack = [p[1:-1, 1:-1], p[:-2, 1:-1], p[2:, 1:-1], p[1:-1, :-2], p[1:-1, 2:],
                 p[:-2, :-2], p[:-2, 2:], p[2:, :-2], p[2:, 2:]]
        out = fn(np.stack(stack), axis=0)
    return out


def erode(m, it): return _minmax(m.astype(bool), it, np.all) if it > 0 else m.astype(bool)
def dilate(m, it): return _minmax(m.astype(bool), it, np.any) if it > 0 else m.astype(bool)


def phase_shift(a, b):
    h, w = a.shape
    win = np.outer(np.hanning(h), np.hanning(w))
    fa, fb = np.fft.fft2((a - a.mean()) * win), np.fft.fft2((b - b.mean()) * win)
    r = fa * np.conj(fb); r /= np.abs(r) + 1e-9
    c = np.abs(np.fft.ifft2(r)); dy, dx = np.unravel_index(np.argmax(c), c.shape)
    if dy > h // 2: dy -= h
    if dx > w // 2: dx -= w
    return int(dy), int(dx)


# ----------------------------------------------------------------------------- the gate

def best_shift(a, b, mask=None, max_shift: int = 4):
    """(dy, dx) of b relative to a as the integer shift within +-max_shift that minimises the
    mean absolute difference on `mask` (default: everything). Brute force on purpose: phase
    correlation locks onto periodic structure (grids, text, packaging) and read a 3 px shift as
    0 on the test texture; 81 evaluations of a window are cheap."""
    import numpy as np
    h, w = a.shape
    m = np.ones_like(a, dtype=bool) if mask is None else mask
    best = (0, 0, None)
    s = max_shift
    core_a = a[s:h - s, s:w - s]; core_m = m[s:h - s, s:w - s]
    if core_m.sum() == 0:
        return 0, 0
    for dy in range(-s, s + 1):
        for dx in range(-s, s + 1):
            bb = b[s + dy:h - s + dy, s + dx:w - s + dx]
            v = float(np.abs(core_a - bb)[core_m].mean())
            if best[2] is None or v < best[2] - 1e-9:
                best = (dy, dx, v)
    return -best[0], -best[1]


def gate_metrics(anchor, target, candidate, hard_mask, th=None) -> dict:
    """Drift on the CONTEXT RING (outside the box dilated 8 px, minus a border) on a common grid.
    Texture against the ANCHOR, colour and registration against the TARGET. Nothing is measured
    inside the box: the eye at 3x judges the fix itself."""
    th = th or thresholds()
    G = int(th["grid_long_edge"])
    W, H = target.size
    s = min(1.0, G / max(W, H))
    gs = (max(16, int(W * s)), max(16, int(H * s)))
    gray = lambda im: np.asarray(im.convert("L").resize(gs, Image.LANCZOS)).astype(np.float64)
    a, t, c = gray(anchor), gray(target), gray(candidate)
    m = np.asarray(hard_mask.convert("L").resize(gs, Image.NEAREST)) > 127
    ring = ~dilate(m, max(1, int(8 * s)))
    border = max(2, int(18 * s))
    ring[:border] = ring[-border:] = False; ring[:, :border] = ring[:, -border:] = False
    n = int(ring.sum())
    out = {"ring_px_grid": n, "grid": list(gs), "measurable": n >= int(th["min_ring_px"]) * s * s}
    if not out["measurable"]:
        return out
    la, lc = laplace(gaussian(a, 1.0))[ring].var(), laplace(gaussian(c, 1.0))[ring].var()
    out["retention"] = round(float(lc / la), 3) if la > 0 else None
    gy, gx = np.gradient(gaussian(a, 1.0))
    gm = gaussian(np.hypot(gx, gy), 3.0)          # flat at low frequency: grain must not speckle the mask
    flat = ring & (gm < np.percentile(gm[ring], 50))
    flat = erode(flat, max(1, int(th["flat_erosion_px"] * s)))
    bp = lambda g: gaussian(g, 1.5) - gaussian(g, 6)
    if flat.sum() > 200:
        ba, bc = bp(a)[flat].std(), bp(c)[flat].std()
        out["blotch"] = round(float(bc / ba), 3) if ba > 0 else None
    else:
        out["blotch"] = None
    d = np.abs(c - t)
    out["de_p95"] = round(float(np.percentile(d[ring], 95)), 1)
    out["ring_mean_abs"] = round(float(d[ring].mean()), 2)
    best = None
    ph = min(gs) // 2
    for (yy, xx) in ((0, 0), (0, gs[0] - ph), (gs[1] - ph, 0), (gs[1] - ph, gs[0] - ph)):
        sl = (slice(yy, yy + ph), slice(xx, xx + ph))
        frac = ring[sl].mean()
        if best is None or frac > best[0]:
            best = (frac, sl)
    if best and best[0] > 0.9:
        dy, dx = best_shift(t[best[1]], c[best[1]], ring[best[1]])
        out["shift_px"] = [round(dy / s, 1), round(dx / s, 1)]
    else:
        out["shift_px"] = None
    return out


def gate_verdict(metrics: dict, th=None) -> list:
    th = th or thresholds()
    f = []
    if not metrics.get("measurable", False):
        return ["ring too small to measure (eye only)"]
    r = metrics.get("retention")
    if r is not None and r < th["retention_min"]:
        f.append(f"detail retention {r} on the ring around the box (floor {th['retention_min']}): the render smeared what it was told to keep")
    if r is not None and r > th["retention_max"]:
        f.append(f"detail retention {r} on the ring (ceiling {th['retention_max']}): added grain or halo, not detail")
    b = metrics.get("blotch")
    if b is not None and b > th["blotch_max"]:
        f.append(f"blotch ratio {b} on the ring's flat areas (limit {th['blotch_max']}): the finish is breaking up")
    de = metrics.get("de_p95")
    if de is not None and de > th["de_p95_max"]:
        f.append(f"colour drift p95 {de} levels on the ring (limit {th['de_p95_max']})")
    sh = metrics.get("shift_px")
    if sh and max(abs(sh[0]), abs(sh[1])) > th["shift_max_px"]:
        f.append(f"registration shift {sh} px (limit {th['shift_max_px']})")
    return f


# ----------------------------------------------------------------------------- the edit
def _prompt_id(prompt: str) -> str:
    return hashlib.sha1(prompt.encode()).hexdigest()[:8]


def _png(im, name="image.png"):
    b = io.BytesIO(); im.save(b, format="PNG"); b.seek(0); b.name = name; return b


def edge_band_disagreement(target, render, allowed: np.ndarray, band: int) -> float:
    """Mean level difference in the outer `band` pixels inside the boxes. Above the seam limit,
    the feather would print a line; widen the box onto quiet background."""
    inner = erode(allowed, band)
    ring = allowed & ~inner
    if not ring.any():
        return 0.0
    t = np.asarray(target.convert("RGB"), dtype=np.int16); r = np.asarray(render.convert("RGB"), dtype=np.int16)
    return float(np.abs(t - r).sum(2)[ring].mean() / 3.0)


def composite(target, render, boxes, feather: int):
    """Only the boxes change; every pixel outside their union is the target's own (byte for byte).
    Returns (out, allowed, inside, outside, ring_max)."""
    if render.size != target.size:
        raise ValueError(f"the render is {render.size[0]}x{render.size[1]} but the target is {target.size[0]}x{target.size[1]}; the tool never resizes a mismatch")
    W, H = target.size
    allowed = np.zeros((H, W), bool)
    for x, y, w, h in boxes:
        allowed[y:y + h, x:x + w] = True
    mask = feather_mask(target.size, boxes, feather)
    m = np.asarray(mask).copy(); m[~allowed] = 0
    ring = boundary_ring_max(m, allowed)
    if feather and ring > RING_LIMIT:
        raise ValueError(f"the blend is {ring}/255 on the first pixel inside a box (limit {RING_LIMIT}); the feather must reach the base at the boundary")
    out = Image.composite(render.convert("RGB"), target.convert("RGB"), Image.fromarray(m, "L"))
    a, o = np.asarray(target.convert("RGB")), np.asarray(out).copy()
    o[~allowed] = a[~allowed]
    out = Image.fromarray(o, "RGB")
    changed = np.abs(a.astype(int) - o.astype(int)).sum(2) > 0
    return out, allowed, int(changed[allowed].sum()), int(changed[~allowed].sum()), ring


def make_client():
    load_key()
    if not os.environ.get("OPENAI_API_KEY"):
        raise SystemExit("OPENAI_API_KEY is not set and no .env upward holds it; run /machines-check first. Nothing spent")
    from openai import OpenAI
    return OpenAI(timeout=900)


def resolve(lin: Lineage, target_path: Path, target_sha: str, boxes: list, declare: str, override: str, covers: bool, anchor_path: str):
    """The anchor decision. Returns (anchor_path or None for the target itself, anchor_sha, union, note, override_used).
    Raises SystemExit with a sentence that says what to do next; nothing is spent before it."""
    unknown_policy = os.environ.get("WONKA_DEPTH_UNKNOWN", "warn").lower()
    if not lin.known(target_sha):
        if declare:
            lin.append({"op": "declare_anchor", "sha": target_sha, "anchor": target_sha, "origin": "declared",
                        "boxes": [{"box": None, "depth": 0, "anchor": target_sha, "prompt_id": None}], "file": lin.rel(target_path), "reason": declare})
            note = f"declared {target_path.name} the clean base ({declare})"
        elif unknown_policy == "warn":
            lin.append({"op": "register", "sha": target_sha, "anchor": target_sha, "origin": "pre-lineage",
                        "boxes": [{"box": None, "depth": 0, "anchor": target_sha, "prompt_id": None}], "file": lin.rel(target_path),
                        "note": "no lineage on record when first edited; treated as the clean base"})
            note = f"{target_path.name} had no lineage; taking it as the clean base (run `edit_core.py migrate` once per product to reconstruct history)"
            print("note: " + note, file=sys.stderr)
        else:
            raise SystemExit(f"{target_path.name} is not in the lineage ({lin.path}). Register it (`edit_core.py register <file> --origin genrupt|generation|external`) or vouch for it once with --declare-anchor \"why\". Nothing spent")
        return None, target_sha, None, note, False
    rec = lin.latest(target_sha) or {}
    if declare:
        lin.append({"op": "declare_anchor", "sha": target_sha, "anchor": target_sha, "origin": "declared",
                    "boxes": [{"box": None, "depth": 0, "anchor": target_sha, "prompt_id": None}], "file": lin.rel(target_path),
                    "reason": declare, "depth_seen": lin.depth_in(target_sha, boxes)})
        return None, target_sha, None, f"declared {target_path.name} the clean base ({declare})", False
    if rec.get("origin") == "upscale":
        raise SystemExit(f"{target_path.name} is an UPSCALE and an upscale is never the base of a fix: fix the frame it was made from "
                         f"(the lineage names it) and upscale the result again. Nothing spent")
    depth = lin.depth_in(target_sha, boxes)
    if rec.get("origin") == "external" and depth == 0:
        print(f"note: {target_path.name} came from outside the factory (its earlier edits are unknown); taking it as the clean base", file=sys.stderr)
    if depth == 0:
        return None, target_sha, None, "the box sits on untouched pixels; the target is the anchor", False
    if override:
        lin.append({"op": "override_depth", "target": target_sha, "reason": override, "boxes_requested": [list(b) for b in boxes], "depth_seen": depth, "file": lin.rel(target_path)})
        print(f"note: editing on top of an earlier render (depth {depth}) because: {override}. Recorded as the stack it is.", file=sys.stderr)
        return None, target_sha, None, f"override on depth {depth}", True
    anchor_sha, earlier, union = lin.resolve_anchor(target_sha, boxes)
    prompts = []
    for b in earlier:
        for rec in lin.records:
            if rec.get("prompt_id") == b.get("prompt_id") and rec.get("prompt"):
                prompts.append(rec["prompt"]); break
    if not covers:
        lines = "\n".join("  - " + p for p in prompts) or "  - (the earlier instruction is not on record)"
        raise SystemExit(f"the box overlaps an earlier fix on this file. Pixels never stack here, instructions do: the render will come from the clean base, "
                         f"which does not contain that fix, so the instruction must carry it too. Earlier instruction(s):\n{lines}\n"
                         f"Merge them with the new one (a newer sentence about the same thing replaces the older one), run again with --covers-earlier, "
                         f"and the box becomes the union {union}. Nothing spent")
    if anchor_sha == target_sha:
        return None, target_sha, union, "anchor=target", False
    near = [target_path.parent, lin.root / "images", lin.root / "edits"] + sorted((lin.root / "edits").glob("v*")) if (lin.root / "edits").is_dir() else [target_path.parent, lin.root / "images"]
    ap = Path(anchor_path) if anchor_path else lin.locate(anchor_sha, near)
    if ap is None or not ap.exists():
        raise SystemExit(f"the clean base for this box ({anchor_sha[:12]}) is on record but its file is not on disk near {target_path.parent}. Pass --anchor <file>. Nothing spent")
    return ap, anchor_sha, union, f"anchor={ap.name} (the box had been fixed before; rendering from the clean base with the merged instruction)", False


def run_edit(target_path: Path, out_path: Path, prompt: str, boxes: list, sheet: str = "", quality: str = "low",
             window: bool = False, covers: bool = False, override: str = "", declare: str = "", gate: str | None = None,
             faces: bool = False, feather: int = FEATHER_DEFAULT, anchor_path: str = "", client=None, lineage_path: str = "") -> dict:
    """The whole run. Returns the lineage record written. Raises SystemExit with a sentence on
    every stop; nothing is written unless every check passed."""
    mode = gate_mode(gate)
    th = thresholds()
    if out_path.suffix.lower() != ".png":
        raise SystemExit(f"the fix must be written as .png (got {out_path.suffix}); a lossy save re-encodes the pixels the fix promised to leave alone. Nothing spent")
    if EVIDENCE.search(out_path.stem):
        raise SystemExit(f"{out_path.name} carries an evidence suffix; a fix takes the canonical name. Nothing spent")
    if not target_path.is_file():
        raise SystemExit(f"{target_path}: no such file. Nothing spent")
    target = Image.open(target_path)
    target, _ = intake_normalize(target)
    W, H = target.size
    boxes = parse_boxes([f"{x},{y},{w},{h}" for (x, y, w, h) in boxes], target.size, 0)
    if not boxes:
        raise SystemExit("a fix needs at least one --box x,y,w,h (the whole object, its shadow and its reflection). Nothing spent")
    lin = Lineage(target_path, Path(lineage_path) if lineage_path else None)
    target_sha = pixel_hash(target)
    ap, anchor_sha, union, note, override_used = resolve(lin, target_path, target_sha, list(boxes), declare, override, covers, anchor_path)
    anchor = Image.open(ap) if ap else target
    if ap:
        anchor, _ = intake_normalize(anchor)
        if pixel_hash(anchor) != anchor_sha:
            raise SystemExit(f"{Path(ap).name} does not hold the clean base's pixels ({anchor_sha[:12]}); pass the file the lineage names. Nothing spent")
    if anchor.size != target.size:
        raise SystemExit(f"the clean base {ap} is {anchor.size[0]}x{anchor.size[1]} but the target is {W}x{H}; they must be the same frame. Nothing spent")
    if union is not None:
        boxes = [tuple(union)]
    print(f"lineage: {note}")
    try:
        info = native_api_size(W, H)
    except ValueError as e:
        raise SystemExit(f"{e}. Nothing spent")
    min_short = min(min(w, h) for (_, _, w, h) in boxes)
    feather = max(2, min(feather, min_short // 4))
    win = window_for(boxes, target.size, feather) if window and not faces else None

    # the editable mask (alpha 0 where the model may paint, the endpoint's convention)
    allowed = np.zeros((H, W), bool)
    for x, y, w, h in boxes:
        allowed[y:y + h, x:x + w] = True

    client = client or make_client()
    model = image_model()
    sent_sha = None
    refs = []
    if sheet:
        if not Path(sheet).is_file():
            raise SystemExit(f"--sheet {sheet}: file not found. Nothing spent")
        refs.append(open(sheet, "rb"))
    if faces:
        # the whole frame is the context a believable face needs; only the head boxes come back
        sent, sinfo = prepare_for_api(anchor.convert("RGB"))
        first = _png(sent); sent_sha = hashlib.sha256(first.getvalue()).hexdigest()[:16]
        image_arg = [first] + refs if refs else first
        r = client.images.edit(model=model, image=image_arg, prompt=prompt, size=f"{sinfo['send'][0]}x{sinfo['send'][1]}",
                               quality=quality, n=1, output_format="png")
        ret = Image.open(io.BytesIO(base64.b64decode(r.data[0].b64_json))).convert("RGB")
        try:
            render, resampled = restore_from_api(ret, sinfo)
        except ValueError as e:
            raise SystemExit(f"{e}; nothing written")
        sent_size = sinfo["send"]
    elif win is not None:
        wx, wy, ww, wh = win
        sub = anchor.convert("RGB").crop((wx, wy, wx + ww, wy + wh))
        sent, sinfo = prepare_for_api(sub)
        m = Image.fromarray((allowed[wy:wy + wh, wx:wx + ww] * 255).astype(np.uint8), "L")
        m = pad_edge(m, sinfo["pad"])
        rgba = sent.convert("RGBA"); rgba.putalpha(m.point(lambda v: 0 if v >= 128 else 255))
        first = _png(sent); sent_sha = hashlib.sha256(first.getvalue()).hexdigest()[:16]
        image_arg = [first] + refs if refs else first
        r = client.images.edit(model=model, image=image_arg, mask=_png(rgba, "mask.png"), prompt=prompt,
                               size=f"{sinfo['send'][0]}x{sinfo['send'][1]}", quality=quality, n=1, output_format="png")
        ret = Image.open(io.BytesIO(base64.b64decode(r.data[0].b64_json))).convert("RGB")
        try:
            back, resampled = restore_from_api(ret, sinfo)
        except ValueError as e:
            raise SystemExit(f"{e}; nothing written")
        render = target.convert("RGB").copy(); render.paste(back, (wx, wy))
        sent_size = sinfo["send"]
        print(f"window: {ww}x{wh} at {wx},{wy}, returned one to one")
    else:
        sent, sinfo = prepare_for_api(anchor.convert("RGB"))
        m = Image.fromarray((allowed * 255).astype(np.uint8), "L")
        if sinfo["scale"] < 1.0:
            m = m.resize(sinfo["send"], Image.LANCZOS)
        else:
            m = pad_edge(m, sinfo["pad"])
            ma = np.asarray(m).copy(); ma[H:, :] = 0; ma[:, W:] = 0; m = Image.fromarray(ma, "L")
        rgba = sent.convert("RGBA"); rgba.putalpha(m.point(lambda v: 0 if v >= 128 else 255))
        first = _png(sent); sent_sha = hashlib.sha256(first.getvalue()).hexdigest()[:16]
        image_arg = [first] + refs if refs else first
        r = client.images.edit(model=model, image=image_arg, mask=_png(rgba, "mask.png"), prompt=prompt,
                               size=f"{sinfo['send'][0]}x{sinfo['send'][1]}", quality=quality, n=1, output_format="png")
        ret = Image.open(io.BytesIO(base64.b64decode(r.data[0].b64_json))).convert("RGB")
        try:
            render, resampled = restore_from_api(ret, sinfo)
        except ValueError as e:
            raise SystemExit(f"{e}; nothing written")
        sent_size = sinfo["send"]

    band = edge_band_disagreement(target, render, allowed, feather)
    if band > th["seam_band_max"]:
        rej = out_path.with_name(out_path.stem + "-render.png"); render.save(rej)
        raise SystemExit(f"the feather lands on re-rendered content (mean {band:.0f} levels in the outer {feather} px of the box, limit {th['seam_band_max']:.0f}): the fade would print a line. Widen the box onto quiet background and run again. The render is at {rej.name} (evidence, not a candidate)")
    try:
        result, allowed, inside, outside, ring = composite(target, render, boxes, feather)
    except ValueError as e:
        raise SystemExit(f"{e}; nothing written")
    if outside:
        raise SystemExit(f"the composite touched {outside} pixels outside the boxes; nothing written")
    if not inside:
        print("note: 0 pixels changed inside the box; the edit did not land (compare the hashes, not the eyes)", file=sys.stderr)
    hard = Image.fromarray((allowed * 255).astype(np.uint8), "L")
    if win is not None:
        wx, wy, ww, wh = win
        wbox = (wx, wy, wx + ww, wy + wh)
        gm = gate_metrics(anchor.crop(wbox), target.crop(wbox), render.crop(wbox), hard.crop(wbox), th) if mode != "off" else {}
    else:
        gm = gate_metrics(anchor, target, render, hard, th) if mode != "off" else {}
    findings = gate_verdict(gm, th) if mode != "off" else []
    if win is not None and mode != "off":
        wx, wy, ww, wh = win
        tg = np.asarray(target.convert("L").crop((wx, wy, wx + ww, wy + wh))).astype(np.float64)
        cg = np.asarray(render.convert("L").crop((wx, wy, wx + ww, wy + wh))).astype(np.float64)
        m2 = allowed[wy:wy + wh, wx:wx + ww]
        cg = cg.copy(); cg[m2] = tg[m2]          # the box cannot drive the registration
        pad = 24
        if ww > 3 * pad and wh > 3 * pad and not m2[pad:-pad, pad:-pad].all():
            dy, dx = best_shift(tg[pad:-pad, pad:-pad], cg[pad:-pad, pad:-pad], ~m2[pad:-pad, pad:-pad])
            gm["window_shift_px"] = [dy, dx]
            if max(abs(dy), abs(dx)) > th["shift_max_px"]:
                rej = out_path.with_name(out_path.stem + "-render.png"); render.save(rej)
                raise SystemExit(f"the window came back shifted by {[dy, dx]} px against the target (limit {th['shift_max_px']}): a shifted paste prints a step "
                                 f"along every edge crossing the box. Widen the box's margin or run without --window. The render is at {rej.name} (evidence). Nothing installed")
    pid = _prompt_id(prompt)
    if findings and mode == "block":
        rej = out_path.with_name(out_path.stem + "-render.png"); render.save(rej)
        lin.append({"op": "render_reject", "sha": pixel_hash(render), "from": anchor_sha, "anchor": anchor_sha, "target": target_sha,
                    "prompt_id": pid, "prompt": prompt, "gate": gm, "findings": findings, "file": lin.rel(rej)})
        raise SystemExit("GATE (block): " + "; ".join(findings) + f". The render is at {rej.name} (evidence). Nothing installed; run again with --gate warn to install it with the numbers attached")
    out_path.parent.mkdir(parents=True, exist_ok=True)
    result.save(out_path)
    depth_new = 1 if not override_used else (lin.depth_in(target_sha, boxes) or 0) + 1
    new_boxes = lin.boxes_of(target_sha)
    if faces:
        new_boxes = next_boxes(new_boxes, None, depth_new, anchor_sha, pid)
    else:
        for bx in boxes:
            new_boxes = next_boxes(new_boxes, tuple(bx), depth_new, anchor_sha, pid)
    rec = {"op": "edit", "sha": pixel_hash(result), "from": anchor_sha, "anchor": anchor_sha, "target": target_sha,
           "prompt_id": pid, "prompt": prompt, "model": model, "quality": quality, "size_sent": list(sent_size),
           "size_source": [W, H], "resample": int(resampled), "window": list(win) if win else None, "faces": bool(faces),
           "sent_sha": sent_sha, "boxes": new_boxes,
           "gate": gm, "findings": findings, "gate_mode": mode, "file": lin.rel(out_path), "override": override or None}
    lin.append(rec)
    print(f"wrote {out_path}: {inside} pixels changed inside the box, {outside} outside (must be 0), seam band {band:.0f}, "
          f"sent {sent_size[0]}x{sent_size[1]}, model {model}, depth {depth_new}")
    if gm:
        print("gate (" + mode + "): " + json.dumps({k: gm[k] for k in ("retention", "blotch", "de_p95", "shift_px", "window_shift_px") if k in gm}))
    for f_ in findings:
        print("gate warning: " + f_, file=sys.stderr)
    return rec


# ----------------------------------------------------------------------------- migration
def migrate(product: Path, write: bool = True) -> dict:
    """Reconstruct the lineage of a product that predates it. images/, aplus/, variations/ and
    2-reference/ files are anchors (depth 0, origin pre-lineage). Round folders edits/vN are
    walked in order: a file whose pixels equal its same-name copy in the previous round (or in
    images/) is a copy, not an event; a file whose pixels differ is a fix of that parent, recorded
    as depth (parent depth + 1) over the WHOLE frame (the boxes are not recoverable), with the
    parent as its anchor when the parent is itself an anchor, else the parent's anchor. Nothing on
    disk is moved or renamed."""
    product = Path(product).resolve()
    lin = Lineage(product)
    known = {r["sha"] for r in lin.records if r.get("sha")}
    summary = {"anchors": 0, "fixes": 0, "copies": 0, "skipped": 0, "lineage": str(lin.path)}

    def load(p):
        """The decoded image, or None for anything Pillow cannot fully read (a truncated download,
        a zero-byte file): counted as skipped, never a crash in the middle of a product."""
        try:
            im = Image.open(p); im.load(); return im
        except Exception:
            return None

    def add(rec):
        if rec["sha"] in known:
            return
        known.add(rec["sha"])
        if write:
            lin.append(rec)
        else:
            lin.records.append(rec)

    # anchors
    for sub in ("images", "aplus", "variations", "2-reference"):
        d = product / sub
        if not d.is_dir():
            continue
        for p in sorted(d.rglob("*")):
            if p.suffix.lower() not in (".png", ".jpg", ".jpeg", ".webp") or "edits" in p.parts:
                continue
            im = load(p)
            if im is None:
                summary["skipped"] += 1; continue
            sha = pixel_hash(im)
            if sha in known:
                continue
            add({"op": "register", "sha": sha, "anchor": sha, "origin": "pre-lineage",
                 "boxes": [{"box": None, "depth": 0, "anchor": sha, "prompt_id": None}], "file": lin.rel(p), "note": "migrated"})
            summary["anchors"] += 1
    # rounds
    edits = product / "edits"
    rounds = sorted([d for d in edits.glob("v*") if d.is_dir() and d.name[1:].isdigit()], key=lambda d: int(d.name[1:])) if edits.is_dir() else []
    prev_by_name: dict = {}
    for p in (product / "images").glob("*.png") if (product / "images").is_dir() else []:
        im = load(p)
        if im is not None:
            prev_by_name[p.name] = pixel_hash(im)
    for rd in rounds:
        cur_by_name = dict(prev_by_name)
        for p in sorted(rd.rglob("*.png")):
            if EVIDENCE.search(p.stem):
                continue
            im = load(p)
            if im is None:
                summary["skipped"] += 1; continue
            sha = pixel_hash(im)
            rel_name = str(p.relative_to(rd))
            parent = prev_by_name.get(rel_name) or prev_by_name.get(p.name)
            if parent == sha or (sha in known and parent is None):
                summary["copies"] += 1
                cur_by_name[rel_name] = sha; cur_by_name[p.name] = sha
                continue
            if sha in known:
                cur_by_name[rel_name] = sha; cur_by_name[p.name] = sha
                continue
            if parent is None:
                add({"op": "register", "sha": sha, "anchor": sha, "origin": "pre-lineage",
                     "boxes": [{"box": None, "depth": 0, "anchor": sha, "prompt_id": None}], "file": lin.rel(p), "note": f"migrated, first seen in {rd.name}"})
                summary["anchors"] += 1
            else:
                prec = lin.latest(parent)
                pdepth = lin.depth_in(parent, []) or 0
                anchor = (prec.get("anchor") if prec and pdepth >= 1 else parent) or parent
                add({"op": "edit", "sha": sha, "from": parent, "anchor": anchor, "target": parent, "prompt_id": None,
                     "prompt": None, "origin": "migrated", "boxes": [{"box": None, "depth": pdepth + 1, "anchor": anchor, "prompt_id": None}],
                     "file": lin.rel(p), "note": f"migrated from {rd.name}: differs from its parent, box unknown (whole frame)"})
                summary["fixes"] += 1
            cur_by_name[rel_name] = sha; cur_by_name[p.name] = sha
        prev_by_name = cur_by_name
    return summary


# ----------------------------------------------------------------------------- CLI
def _cli(argv) -> int:
    if not argv or argv[0] not in ("edit", "register", "show", "declare-anchor", "migrate"):
        print(__doc__); return 2
    cmd, args = argv[0], argv[1:]
    if cmd == "migrate":
        if not args:
            print("migrate needs the product folder"); return 2
        s = migrate(Path(args[0]), write="--dry-run" not in args)
        print(json.dumps(s, indent=1)); return 0
    if not args:
        print(__doc__); return 2
    if cmd == "edit":
        pos, opt = [], {"box": [], "sheet": "", "quality": "low", "window": False, "covers": False, "override": "", "declare": "",
                        "gate": None, "faces": False, "anchor": "", "feather": FEATHER_DEFAULT, "lineage": ""}
        i = 0
        while i < len(args):
            a = args[i]
            if a == "--box": opt["box"].append(args[i + 1]); i += 2
            elif a == "--sheet": opt["sheet"] = args[i + 1]; i += 2
            elif a == "--quality": opt["quality"] = args[i + 1]; i += 2
            elif a == "--window": opt["window"] = True; i += 1
            elif a == "--covers-earlier": opt["covers"] = True; i += 1
            elif a == "--override-depth": opt["override"] = args[i + 1]; i += 2
            elif a == "--declare-anchor": opt["declare"] = args[i + 1]; i += 2
            elif a == "--gate": opt["gate"] = args[i + 1]; i += 2
            elif a == "--faces": opt["faces"] = True; i += 1
            elif a == "--anchor": opt["anchor"] = args[i + 1]; i += 2
            elif a == "--feather": opt["feather"] = int(args[i + 1]); i += 2
            elif a == "--lineage": opt["lineage"] = args[i + 1]; i += 2
            else: pos.append(a); i += 1
        if len(pos) < 3:
            print('edit needs: <target.png> <out.png> "<one change>" --box x,y,w,h'); return 2
        if opt["quality"] not in ("low", "high"):
            print("--quality is low or high (low unless a face is the thing repaired)"); return 2
        try:
            boxes = [tuple(int(v) for v in b.split(",")) for b in opt["box"]]
        except ValueError:
            print("--box wants x,y,w,h integers"); return 2
        try:
            run_edit(Path(pos[0]), Path(pos[1]), pos[2], boxes, sheet=opt["sheet"], quality=opt["quality"], window=opt["window"],
                     covers=opt["covers"], override=opt["override"], declare=opt["declare"], gate=opt["gate"], faces=opt["faces"],
                     feather=opt["feather"], anchor_path=opt["anchor"], lineage_path=opt["lineage"])
        except ValueError as e:
            print(str(e)); return 2
        return 0
    p = Path(args[0])
    if not p.exists():
        print(f"{p}: no such file"); return 2
    img = Image.open(p); sha = pixel_hash(img); lin = Lineage(p)
    if cmd == "show":
        rec = lin.latest(sha)
        print(json.dumps({"file": str(p), "sha": sha[:16], "lineage": str(lin.path), "known": rec is not None,
                          "depth_whole_frame": lin.depth_in(sha, []), "record": rec}, indent=1, ensure_ascii=False)); return 0
    if cmd == "register":
        origin, frm, note = "generation", None, ""
        rest = args[1:]; i = 0
        while i < len(rest):
            if rest[i] == "--origin": origin = rest[i + 1]; i += 2
            elif rest[i] == "--from": frm = rest[i + 1]; i += 2
            elif rest[i] == "--note": note = rest[i + 1]; i += 2
            else: i += 1
        if origin not in ORIGINS:
            print(f"--origin must be one of {', '.join(ORIGINS)} (got {origin!r})"); return 2
        if frm and not Path(frm).is_file():
            print(f"--from {frm}: no such file"); return 2
        if lin.known(sha):
            print(f"already in the lineage as {sha[:12]} ({lin.path})"); return 0
        from_sha = pixel_hash(Image.open(frm)) if frm else None
        depth = {"generation": 0, "photo": 0, "genrupt": 0}.get(origin, "unknown")
        _, notes = intake_normalize(img)
        lin.append({"op": "register", "sha": sha, "from": from_sha, "anchor": sha if depth == 0 else None, "origin": origin,
                    "boxes": [{"box": None, "depth": depth, "anchor": from_sha or sha, "prompt_id": None}], "file": lin.rel(p), "intake": notes, "note": note})
        print(f"registered {p.name} as {sha[:12]} origin={origin} depth={depth} -> {lin.path}"); return 0
    if cmd == "declare-anchor":
        reason = args[1] if len(args) > 1 else ""
        if not reason.strip():
            print("declare-anchor needs a reason in quotes"); return 2
        lin.append({"op": "declare_anchor", "sha": sha, "anchor": sha, "origin": "declared",
                    "boxes": [{"box": None, "depth": 0, "anchor": sha, "prompt_id": None}], "file": lin.rel(p), "reason": reason})
        print(f"declared {p.name} ({sha[:12]}) the clean base: {reason}"); return 0
    return 2


if __name__ == "__main__":
    try:
        sys.exit(_cli(sys.argv[1:]))
    except SystemExit as e:
        if isinstance(e.code, str):
            print(e.code, file=sys.stderr); sys.exit(1)
        raise

#!/usr/bin/env python3
"""Put the REAL part into the picture.

Some parts the generator redraws instead of copying, however good the sheet: a control panel's
grid of indicator segments, a printed model number, a port sitting off-centre in an end cap, the
grit on an engraving bit. Measured 24 to 25 September 2026 on a cordless engraving pen: four sheet
edits and a smoke test of nine frames never once drew the nine-segment panel or the model number
right, while the owner's phone photo had both. For a part like that the fix is not another render.
It is the owner's own photo of the part, cut out and set into the frame, at depth one, with
everything outside the destination byte-identical.

  python3 .claude/skills/fix/paste_real.py <target.png> <real-crop.png> <out.png> \\
      --quad x1,y1,x2,y2,x3,y3,x4,y4   the four corners on the TARGET where the crop's corners land
                                       (top-left, top-right, bottom-right, bottom-left, in that order)
    | --rect x,y,w,h                    an upright destination; the quad is its corners
      [--feather 12]                    inward soft edge, pixels (0 = hard edge)
      [--match 0.6]                     0..1, how far the crop's colour statistics move toward the
                                        target's under the same footprint (0 = the photo as shot)
      [--max-upscale 1.5]               refuse when the crop must be enlarged more than this
      [--note "..."] [--lineage path] [--declare-anchor "why"] [--covers-earlier] [--anchor file]

To DRAW the destination before deciding (the proof the quad holds the whole part and nothing else):

  python3 .claude/skills/fix/paste_real.py --draw <target.png> <out-regions.png> --quad ... | --rect ...

The crop is the owner's photo, cut to the part (a PNG with transparency is honoured: the alpha
rides into the mask, so a round button can be pasted without its square). It is warped by a true
perspective onto the quad, so a panel photographed head-on can sit on a pen drawn at an angle.
Measure the quad on the target at magnification: the four points are where the crop's four
corners go, and a quad that also swallows barrel or background prints the photo's background.

What is checked before anything is written: the quad is inside the frame, not degenerate, and
its short side is at least 8 px; the crop is not enlarged past --max-upscale (an enlarged photo
prints soft, take a larger crop or a closer photo); the output name is a canonical .png. After
the paste: the pixel count changed outside the destination's bounding box (must be 0), the count
inside, the scale the crop was drawn at, and the seam (mean colour step on the outer ring of the
quad, after matching). The paste is written to edits/lineage.jsonl as a depth-one event with the
crop's hash as its prompt id, so `/fix` and the migration see it like any other fix.

Depth: the destination should sit on untouched pixels (depth 0) of the target. When it overlaps
an earlier fix, the tool takes the ring under the feather from the clean base and says so, and
runs only with --covers-earlier, the same rule as edit_core.py.
"""
import hashlib
import json
import sys
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw, ImageFilter

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import edit_core as ec  # noqa: E402

FEATHER_DEFAULT = 12
MATCH_DEFAULT = 0.6
MAX_UPSCALE_DEFAULT = 1.5
MIN_SIDE = 8


# ----------------------------------------------------------------------------- geometry
def parse_quad(s: str) -> list:
    try:
        v = [int(round(float(t))) for t in s.split(",")]
    except ValueError:
        raise ValueError("--quad wants eight integers x1,y1,x2,y2,x3,y3,x4,y4")
    if len(v) != 8:
        raise ValueError("--quad wants eight integers x1,y1,x2,y2,x3,y3,x4,y4")
    return [(v[0], v[1]), (v[2], v[3]), (v[4], v[5]), (v[6], v[7])]


def rect_quad(s: str) -> list:
    try:
        x, y, w, h = (int(t) for t in s.split(","))
    except ValueError:
        raise ValueError("--rect wants x,y,w,h integers")
    return [(x, y), (x + w, y), (x + w, y + h), (x, y + h)]


def quad_bbox(q: list) -> tuple:
    xs = [p[0] for p in q]; ys = [p[1] for p in q]
    return (min(xs), min(ys), max(xs) - min(xs), max(ys) - min(ys))


def _dist(a, b) -> float:
    return float(np.hypot(a[0] - b[0], a[1] - b[1]))


def quad_sides(q: list) -> tuple:
    """(width, height) of the destination, as the mean of opposite edges."""
    w = (_dist(q[0], q[1]) + _dist(q[3], q[2])) / 2
    h = (_dist(q[0], q[3]) + _dist(q[1], q[2])) / 2
    return w, h


def _cross(o, a, b) -> float:
    return (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0])


def validate_quad(q: list, size: tuple):
    W, H = size
    for (x, y) in q:
        if x < 0 or y < 0 or x > W or y > H:
            raise ValueError(f"the destination corner ({x},{y}) is outside the {W}x{H} frame")
    signs = [_cross(q[i], q[(i + 1) % 4], q[(i + 2) % 4]) for i in range(4)]
    if any(s == 0 for s in signs) or not (all(s > 0 for s in signs) or all(s < 0 for s in signs)):
        raise ValueError("the destination quad is degenerate or folds over itself; give the corners in order top-left, top-right, bottom-right, bottom-left")
    w, h = quad_sides(q)
    if min(w, h) < MIN_SIDE:
        raise ValueError(f"the destination is {w:.0f}x{h:.0f} px; a part smaller than {MIN_SIDE} px on a side is not a paste, it is a dot")


def perspective_coeffs(src: list, dst: list) -> list:
    """The eight coefficients PIL wants for Image.transform(PERSPECTIVE): they map OUTPUT
    coordinates (the target) to INPUT coordinates (the crop), so src = target quad, dst = crop corners."""
    A, B = [], []
    for (x, y), (u, v) in zip(src, dst):
        A.append([x, y, 1, 0, 0, 0, -u * x, -u * y]); B.append(u)
        A.append([0, 0, 0, x, y, 1, -v * x, -v * y]); B.append(v)
    sol = np.linalg.lstsq(np.asarray(A, float), np.asarray(B, float), rcond=None)[0]
    return [float(c) for c in sol]


# ----------------------------------------------------------------------------- masks
def polygon_mask(size: tuple, q: list) -> Image.Image:
    m = Image.new("L", size, 0)
    ImageDraw.Draw(m).polygon([tuple(p) for p in q], fill=255)
    return m


def inward_ramp(mask: Image.Image, feather: int) -> np.ndarray:
    """0 on the first pixel inside the polygon, full strength `feather` pixels in, linear between;
    nothing outside. Built by erosion so it follows the quad's own edges, not a box."""
    hard = np.asarray(mask) > 127
    if feather <= 0:
        return hard.astype(np.float32)
    acc = np.zeros(hard.shape, np.float32)
    cur = Image.fromarray((hard * 255).astype(np.uint8), "L")
    for _ in range(feather):
        cur = cur.filter(ImageFilter.MinFilter(3))
        acc += (np.asarray(cur) > 127)
    ramp = acc / float(feather)
    ramp[~hard] = 0.0
    return ramp


# ----------------------------------------------------------------------------- colour
def match_stats(warped: np.ndarray, under: np.ndarray, weight: np.ndarray, strength: float) -> tuple:
    """Move the crop's per-channel mean and spread toward the target's under the same footprint,
    by `strength` (0 leaves the photo as shot). The spread ratio is clamped to [0.5, 2] so a flat
    render can never crush a real texture to nothing, or blow grain into noise."""
    if strength <= 0:
        return warped, {}
    w = weight > 0.5
    if w.sum() < 16:
        return warped, {}
    out = warped.astype(np.float32).copy()
    stats = {}
    for c in range(3):
        a = warped[..., c][w].astype(np.float32); b = under[..., c][w].astype(np.float32)
        ma, sa, mb, sb = a.mean(), a.std() + 1e-6, b.mean(), b.std() + 1e-6
        ratio = float(np.clip(sb / sa, 0.5, 2.0))
        mapped = (warped[..., c].astype(np.float32) - ma) * ratio + mb
        out[..., c] = warped[..., c] + strength * (mapped - warped[..., c])
        stats["rgb"[c]] = {"crop_mean": round(float(ma), 1), "target_mean": round(float(mb), 1), "spread_ratio": round(ratio, 2)}
    return np.clip(out, 0, 255), stats


# ----------------------------------------------------------------------------- the paste
def warp_crop(crop: Image.Image, q: list, size: tuple) -> tuple:
    """The crop drawn onto a target-sized canvas through the quad. Returns (rgb float array,
    alpha float array 0..1, scale). The crop is first shrunk toward the destination size with a
    proper filter so a large photo does not alias through the transform."""
    cw, ch = crop.size
    dw, dh = quad_sides(q)
    scale = max(dw / cw, dh / ch)
    crop = crop.convert("RGBA")
    if scale < 0.5:
        nw, nh = max(2, int(round(cw * scale * 2))), max(2, int(round(ch * scale * 2)))
        crop = crop.resize((nw, nh), Image.LANCZOS)
        cw, ch = crop.size
    coeffs = perspective_coeffs(q, [(0, 0), (cw, 0), (cw, ch), (0, ch)])
    warped = crop.transform(size, Image.PERSPECTIVE, coeffs, Image.BICUBIC)
    arr = np.asarray(warped).astype(np.float32)
    return arr[..., :3], arr[..., 3] / 255.0, scale


def paste(target: Image.Image, crop: Image.Image, q: list, feather: int = FEATHER_DEFAULT, match: float = MATCH_DEFAULT,
          max_upscale: float = MAX_UPSCALE_DEFAULT, underlay: Image.Image | None = None, region: tuple | None = None) -> dict:
    """The pure image operation. `underlay` (the clean base) supplies the pixels inside `region`
    (the quad's bounding box, or the union with an earlier fix it covers) when the target's are not
    depth 0 there. Returns a dict with the output image and numbers."""
    validate_quad(q, target.size)
    W, H = target.size
    bx, by, bw, bh = region or quad_bbox(q)
    rgb, alpha, scale = warp_crop(crop, q, target.size)
    if scale > max_upscale:
        cw, ch = crop.size
        raise ValueError(f"the crop is {cw}x{ch} px and the destination is {quad_sides(q)[0]:.0f}x{quad_sides(q)[1]:.0f}: enlarging a photo {scale:.2f}x prints soft (limit {max_upscale}). Take a larger crop from the photo or a closer photo")
    ramp = inward_ramp(polygon_mask(target.size, q), feather) * alpha
    base = np.asarray((underlay or target).convert("RGB")).astype(np.float32)
    tgt = np.asarray(target.convert("RGB")).astype(np.float32)
    rgb, stats = match_stats(rgb, base, ramp, match)
    out = tgt.copy()
    win = (slice(by, by + bh), slice(bx, bx + bw))
    r3 = ramp[win][..., None]
    out[win] = base[win] * (1 - r3) + rgb[win] * r3
    out_u8 = np.clip(np.rint(out), 0, 255).astype(np.uint8)
    changed = np.abs(out_u8.astype(int) - tgt.astype(int)).sum(2) > 0
    inside = np.zeros((H, W), bool); inside[win] = True
    # the seam: colour step between what was pasted and what it sits on, on the outer 2 px inside the quad
    hard = np.asarray(polygon_mask(target.size, q)) > 127
    inner = np.asarray(Image.fromarray((hard * 255).astype(np.uint8), "L").filter(ImageFilter.MinFilter(5))) > 127
    ring = hard & ~inner
    seam = float(np.abs(rgb[ring] - base[ring]).mean()) if ring.any() else 0.0
    return {"image": Image.fromarray(out_u8, "RGB"), "inside": int(changed[inside].sum()), "outside": int(changed[~inside].sum()),
            "scale": round(float(scale), 3), "seam": round(seam, 1), "bbox": [bx, by, bw, bh], "match": stats,
            "alpha_used": bool(crop.mode in ("RGBA", "LA") or "transparency" in crop.info)}


def draw_quad(target: Image.Image, q: list) -> Image.Image:
    im = target.convert("RGB").copy(); d = ImageDraw.Draw(im)
    pts = [tuple(p) for p in q]
    d.line(pts + [pts[0]], fill=(255, 0, 0), width=max(2, target.size[0] // 800))
    bx, by, bw, bh = quad_bbox(q)
    d.rectangle([bx, by, bx + bw, by + bh], outline=(255, 160, 0), width=1)
    for i, p in enumerate(pts):
        d.text((p[0] + 4, p[1] + 2), "TL TR BR BL".split()[i], fill=(255, 0, 0))
    return im


# ----------------------------------------------------------------------------- the run, with lineage
def run_paste(target_path: Path, crop_path: Path, out_path: Path, q: list, feather: int = FEATHER_DEFAULT, match: float = MATCH_DEFAULT,
              max_upscale: float = MAX_UPSCALE_DEFAULT, note: str = "", lineage_path: str = "", declare: str = "",
              covers: bool = False, anchor_path: str = "") -> dict:
    if out_path.suffix.lower() != ".png":
        raise SystemExit(f"the paste must be written as .png (got {out_path.suffix}); a lossy save re-encodes the pixels it promised to leave alone. Nothing written")
    if ec.EVIDENCE.search(out_path.stem):
        raise SystemExit(f"{out_path.name} carries an evidence suffix; a fix takes the canonical name. Nothing written")
    for p in (target_path, crop_path):
        if not p.is_file():
            raise SystemExit(f"{p}: no such file. Nothing written")
    target = Image.open(target_path); target, _ = ec.intake_normalize(target)
    crop = Image.open(crop_path)
    try:
        validate_quad(q, target.size)
    except ValueError as e:
        raise SystemExit(f"{e}. Nothing written")
    bbox = quad_bbox(q)
    lin = ec.Lineage(target_path, Path(lineage_path) if lineage_path else None)
    target_sha = ec.pixel_hash(target)
    try:
        ap, anchor_sha, union, lnote, _ = ec.resolve(lin, target_path, target_sha, [bbox], declare, "", covers, anchor_path)
    except SystemExit as e:
        msg = str(e)
        if "overlaps an earlier fix" in msg:
            depth = lin.depth_in(target_sha, [bbox])
            raise SystemExit(f"the destination overlaps an earlier fix on this file (depth {depth}). The paste replaces those pixels with the photo and takes the ring under its edge from the clean base, not from the earlier render; run again with --covers-earlier to accept that, or move the destination. Nothing written")
        raise
    underlay = None
    if ap:
        underlay = Image.open(ap); underlay, _ = ec.intake_normalize(underlay)
        if ec.pixel_hash(underlay) != anchor_sha:
            raise SystemExit(f"{Path(ap).name} does not hold the clean base's pixels ({anchor_sha[:12]}); pass the file the lineage names. Nothing written")
        if underlay.size != target.size:
            raise SystemExit(f"the clean base {ap} is {underlay.size[0]}x{underlay.size[1]} but the target is {target.size[0]}x{target.size[1]}. Nothing written")
    print(f"lineage: {lnote}")
    try:
        res = paste(target, crop, q, feather=feather, match=match, max_upscale=max_upscale, underlay=underlay, region=tuple(union) if union else None)
    except ValueError as e:
        raise SystemExit(f"{e}. Nothing written")
    if res["outside"]:
        raise SystemExit(f"the paste touched {res['outside']} pixels outside the destination; nothing written")
    if not res["inside"]:
        raise SystemExit("0 pixels changed inside the destination: the crop is empty or fully transparent there. Nothing written")
    out_path.parent.mkdir(parents=True, exist_ok=True)
    res["image"].save(out_path)
    ev = out_path.with_name(out_path.stem + "-regions.png")
    draw_quad(target, q).save(ev)
    crop_sha = hashlib.sha256(crop_path.read_bytes()).hexdigest()[:16]
    pid = "paste:" + crop_sha
    boxes = ec.next_boxes(lin.boxes_of(target_sha), tuple(union or bbox), 1, anchor_sha, pid)
    rec = {"op": "paste_real", "sha": ec.pixel_hash(res["image"]), "from": anchor_sha, "anchor": anchor_sha, "target": target_sha,
           "prompt_id": pid, "prompt": f"real photo crop {crop_path.name} pasted", "crop": lin.rel(crop_path), "crop_sha": crop_sha,
           "quad": [list(p) for p in q], "bbox": res["bbox"], "scale": res["scale"], "feather": feather, "match": match,
           "match_stats": res["match"], "seam": res["seam"], "alpha": res["alpha_used"], "boxes": boxes,
           "file": lin.rel(out_path), "evidence": lin.rel(ev), "note": note}
    lin.append(rec)
    print(f"wrote {out_path}: {res['inside']} pixels changed inside the destination, {res['outside']} outside (must be 0), "
          f"crop drawn at {res['scale']:.2f}x, seam {res['seam']:.1f} levels, feather {feather}, match {match}, depth 1")
    print(f"evidence: {ev.name} (the quad drawn on the target; open it before the result)")
    return rec


# ----------------------------------------------------------------------------- cli
def _cli(argv) -> int:
    if not argv or argv[0] in ("-h", "--help"):
        print(__doc__); return 2
    draw = argv[0] == "--draw"
    args = argv[1:] if draw else argv
    pos, opt = [], {"quad": "", "rect": "", "feather": FEATHER_DEFAULT, "match": MATCH_DEFAULT, "max_upscale": MAX_UPSCALE_DEFAULT,
                    "note": "", "lineage": "", "declare": "", "covers": False, "anchor": ""}
    i = 0
    try:
        while i < len(args):
            a = args[i]
            if a == "--quad": opt["quad"] = args[i + 1]; i += 2
            elif a == "--rect": opt["rect"] = args[i + 1]; i += 2
            elif a == "--feather": opt["feather"] = int(args[i + 1]); i += 2
            elif a == "--match": opt["match"] = float(args[i + 1]); i += 2
            elif a == "--max-upscale": opt["max_upscale"] = float(args[i + 1]); i += 2
            elif a == "--note": opt["note"] = args[i + 1]; i += 2
            elif a == "--lineage": opt["lineage"] = args[i + 1]; i += 2
            elif a == "--declare-anchor": opt["declare"] = args[i + 1]; i += 2
            elif a == "--covers-earlier": opt["covers"] = True; i += 1
            elif a == "--anchor": opt["anchor"] = args[i + 1]; i += 2
            else: pos.append(a); i += 1
    except (IndexError, ValueError):
        print("an option is missing its value or has the wrong shape; see --help"); return 2
    if not opt["quad"] and not opt["rect"]:
        print("the destination is missing: --quad x1,y1,x2,y2,x3,y3,x4,y4 or --rect x,y,w,h"); return 2
    if opt["quad"] and opt["rect"]:
        print("give --quad or --rect, not both"); return 2
    try:
        q = parse_quad(opt["quad"]) if opt["quad"] else rect_quad(opt["rect"])
    except ValueError as e:
        print(str(e)); return 2
    if not 0.0 <= opt["match"] <= 1.0:
        print("--match is between 0 and 1"); return 2
    if opt["feather"] < 0:
        print("--feather is 0 or more"); return 2
    if draw:
        if len(pos) < 2:
            print("--draw needs: <target.png> <out-regions.png> --quad ... | --rect ..."); return 2
        t = Path(pos[0])
        if not t.is_file():
            print(f"{t}: no such file"); return 2
        im = Image.open(t); im, _ = ec.intake_normalize(im)
        try:
            validate_quad(q, im.size)
        except ValueError as e:
            print(str(e)); return 2
        out = Path(pos[1]); out.parent.mkdir(parents=True, exist_ok=True)
        draw_quad(im, q).save(out)
        w, h = quad_sides(q)
        print(f"drew the destination ({w:.0f}x{h:.0f} px, bbox {quad_bbox(q)}) on {out}"); return 0
    if len(pos) < 3:
        print("paste needs: <target.png> <real-crop.png> <out.png> --quad ... | --rect ..."); return 2
    try:
        run_paste(Path(pos[0]), Path(pos[1]), Path(pos[2]), q, feather=opt["feather"], match=opt["match"], max_upscale=opt["max_upscale"],
                  note=opt["note"], lineage_path=opt["lineage"], declare=opt["declare"], covers=opt["covers"], anchor_path=opt["anchor"])
    except SystemExit as e:
        if isinstance(e.code, str):
            print(e.code, file=sys.stderr); return 1
        raise
    return 0


if __name__ == "__main__":
    sys.exit(_cli(sys.argv[1:]))

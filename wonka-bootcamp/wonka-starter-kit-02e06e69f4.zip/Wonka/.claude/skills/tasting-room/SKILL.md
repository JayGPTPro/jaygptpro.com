---
name: tasting-room
description: The Tasting Room. A synthetic consumer panel (SSR method, arXiv 2510.08338) tastes the candidate images before any real money moves. About 100 demographic-matched AI tasters react in free text, reactions map to purchase intent, a blind forced choice picks a winner, bootstrap resampling grades how stable that winner is, and the recurring objections become concrete fixes. The live Amazon incumbent is always in the race. Runs ONCE per product on Day 8: the MAIN race and the GALLERY race in the same sitting, then the fixes. A second round is optional, not the default. Triggers: /tasting-room, "run the tasting", "Tasting Room", "taste test the images", "which image wins", "run the panel", "test the candidates", "tasting round 2".
---

# The Tasting Room

| Meta | Value |
|------|-------|
| Room | The Tasting Room |
| Station | PROVE (step 1 of 3: taste, refine, then ship; a second tasting is optional) |
| Taught | Day 8, both races, ONE round. The fixes it produces are applied the same day; the real second opinion is Amazon's own A/B on the live listing, not another synthetic round |
| Needs | Gate-passed candidates the OWNER picked (`/inspect` done, `scorecards/` written), the CURRENT live Amazon image or gallery in `incumbent/`, `research/persona.md`, `OPENAI_API_KEY` in the Factory root `.env` |
| Saves to | `factory/Products/[product]/tests/tasting-r[N]-[YYYY-MM-DD]-[race]/` (config.json, results.json, tasting-card.html, tasting-card.md) plus one row per race in `factory/Improvement Log.md` |
| Typical cost | Full tasting (~100 tasters): a few dollars and about 3 to 6 minutes, per race. Lite taste (~20 tasters): under a dollar, a minute or two. One go-ahead before either, every time. |

## What this room does

**This room replaces asking an AI to score your images, and the difference is not small.**

The obvious move, once you have candidates, is to ask a model to look at them and rate them. That
gives you one opinion, from something with no demographics, no shopping history, and no reason to
prefer anything. It is a confident guess with a number attached.

Instead, this room builds a **panel**: about a hundred distinct AI shopper personas, each conditioned
on YOUR buyer from `research/persona.md` (age, gender, income, shopping habits), each shown the
candidates the way a shopper meets them, each reacting in free text rather than scoring. Those
reactions are then read for purchase intent, and a blind forced choice produces a result with a
stability tier.

**What it is for:** one more round of sharpening before the product goes to Amazon, or to a paid
real-shopper survey. It is a refinement step, not a verdict.

**What it does NOT replace:** paid surveys with real people. Those remain the gold standard when a
decision carries real money, and every participant should decide for themselves whether their
stakes justify one. This room never claims to be that.

**What it very much DOES replace:** "Claude, look at these five images and tell me which is best."

The room runs ONCE per product by default, and that sitting holds TWO races. The fixes it produces
are applied the same day, and the genuine second opinion afterwards is Amazon's own A/B on live
traffic, which is free and which the owner already has.


## What this room never does

- **Never writes a Tasting Card by hand.** A card exists because the engine wrote it, or it does not exist. There is no prose version, no "here is roughly what a panel would say", no reconstructed card after a failed run.
- **Never quotes a taster who did not speak.** Every quote, theme and count is read out of `results.json`. Inventing one objection poisons every decision downstream of it.
- **Never presents the panel as real shoppers**, and never converts a vote count into a sales, ranking or conversion prediction. **Never reports the forced choice as a percentage**: a share reads as a market share and a forced binary choice cannot produce one. Always "preferred by N of M panelists".
- **Never picks the candidates.** The owner picks, Wonka echoes the exact filenames back and waits for a yes.
- **Never spends without the cost line and an explicit go-ahead**, and one go-ahead covers one run.
- **Never tests a main image without the incumbent in the grid.**
- **Never tastes an image that has not passed `/inspect`.** No image enters this room ungated, not even one born from tasting data.
- **Never generates, edits, scores or ranks images.** That is `/main-image`, `/fix` and `/inspect`. This room asks the panel and reports what it said.

## The three test scenarios

Every tasting is one of these three. Name the scenario out loud before building any config.

### Scenario A. MAIN image: new vs current (the classic A/B)

**Answers:** "Is my new main image better than what is live on Amazon right now?" Two entries, your candidate and the live incumbent, with `incumbent_id` set.

```json
{
  "product": "Nostalgia 4 Tier Electric Chocolate Fondue Fountain",
  "product_context": "A 4 tier electric chocolate fondue fountain, 32 ounce capacity, 8 x 8 x 18 inches, stainless steel base, disassembles for cleaning",
  "round": 1,
  "images": [
    {"id": "main_01", "label": "chocolate moving over all four tiers", "path": "/abs/.../images/main-01.png"},
    {"id": "current_listing", "label": "current listing", "path": "/abs/.../incumbent/main-live.png"}
  ],
  "incumbent_id": "current_listing",
  "demographics": { "...copied from research/persona.md..." },
  "out_dir": "/abs/.../tests/tasting-r1-[YYYY-MM-DD]-main"
}
```

**What to read:** the verdict band. Winner, the COUNT that preferred it, the stability label, and the purchase-intent gap. Clear lead for the challenger means proceed toward refinement and Round 2. Anything less means the notes matter more than the counts.

### Scenario B. MAIN image: multiple candidates, plus the incumbent, always

**Answers:** "Which of my candidates is strongest, and does the best one beat reality?" Same shape as A with 2 to 5 candidates PLUS the incumbent. The incumbent is never optional on a main race: a winner that only beat your other drafts has proved nothing except which draft is least weak. This is the Day 8 main race.

```json
{
  "images": [
    {"id": "main_01", "label": "chocolate moving over all four tiers", "path": "/abs/.../images/main-01.png"},
    {"id": "main_03", "label": "full height with fruit and pretzels at the base", "path": "/abs/.../images/main-03.png"},
    {"id": "current_listing", "label": "current listing", "path": "/abs/.../incumbent/main-live.png"}
  ],
  "incumbent_id": "current_listing"
}
```

**What to read:** the verdict band for the ranking AND the explicit vs-incumbent line. Then the losing cards' "What hurt" chips, because the loser's objections usually explain the winner.

### Scenario C. GALLERY: our secondary set vs the live Amazon set

**Answers:** "Does our whole image stack sell better than the stack that is live?" Each side gets `"paths": [...]` in gallery order, 2 to 12 frames. This is the Day 8 gallery race.

```json
{
  "images": [
    {"id": "set_new", "label": "proposed gallery", "paths": ["/abs/.../images/sec-01.png", "/abs/.../images/sec-02-v2.png", "/abs/.../images/sec-03.png"]},
    {"id": "set_live", "label": "live gallery", "paths": ["/abs/.../incumbent/live-01.png", "/abs/.../incumbent/live-02.png", "/abs/.../incumbent/live-03.png"]}
  ],
  "incumbent_id": "set_live"
}
```

**Match the frame counts, or say the asymmetry out loud.** A bigger set gets more chances to land a frame the panel likes, so an unequal race reports a margin that is really an UPPER BOUND. New galleries are usually longer than the live one, so this is the common case, not the rare one. Either race equal counts (drop your weakest frames to match, and say which), or run it unequal and write the asymmetry into the round notes and into how you report the win. The engine prints the same note before it spends anything. Resolution and format parity are handled by the engine, which normalises every frame the same way at send time; frame count is the author's job.

**What to read: TWO layers, never collapsed.** The SET verdict answers WHO WINS, because shoppers judge the whole hand and a set's score is not the average of its frames. The FRAME-BY-FRAME dive answers WHAT TO FIX: which frame carries the set, which one drags it, and each frame's works and hurts notes. When the layers disagree, the set verdict decides and the frame dive feeds `/fix`.

**Round 2 of any scenario:** the same shape with `"round": 2`, a fresh `out_dir`, and `"compare_to"` pointing at the matching Round 1 `results.json`.

## Before you start

Check all six. Open the files; never take `status.md`'s word for them. A miss is either a named gap the run carries, or a hard block, per the table below.

1. **`/inspect` ran and the OWNER picked.** `scorecards/scorecard-[scope]-[date].md` exists and the candidates in front of you are gate-passed. The scorecard rank is a RECOMMENDATION. If the owner overrides it, that is legitimate and expected: record the pick and the one-line reason in the round notes and in `status.md`. An override with a reason is data. An override nobody wrote down is noise.
2. **The exact files, confirmed out loud.** Echo the list back in one line ("Tasting these 3: main-01.png, main-03.png, plus the live main from incumbent/") and wait for a yes. Say what you did NOT assume, by name: the `-v2` regenerations sitting beside the originals and the edited copies in the `edits/vN/` round folders are the trap, and picking the wrong one silently tests the wrong image. Never run on a folder, a wildcard, or "the latest".
3. **The incumbent is in the race, and it is actually CURRENT.** Pull the live main image (and for the gallery race the live gallery, in order) from `incumbent/`. Map it only through `incumbent_id`. Then spend thirty seconds confirming the folder still matches reality, because these files were downloaded on Day 7 and a listing can change under you:
   - Open the live listing and check the main image is still the one on disk, and that the live gallery has the same number of frames as the set in `incumbent/`.
   - Check the live images are not already ours. An owner who uploaded a candidate mid-bootcamp would be racing our image against itself, and the card would call it a win.
   - Record the answer in the round notes: `incumbent source: [confirmed live on YYYY-MM-DD / folder from YYYY-MM-DD, unverified / named competitor, pre-launch]`. A stale champion is the one flaw that makes every number on the card wrong in the flattering direction.
4. **`research/persona.md`, with the REAL buyer** (written by `/meet-my-product` on Day 2). Tasters are built from the buyer's real age, gender and income. Never the aspirational display age used for casting models INSIDE the images: that skew belongs to the people in the pictures, never to the people judging them. If the persona is derived rather than exported from Brand Registry, carry the word `estimated` into the demographics notes so it prints on the card.
5. **`OPENAI_API_KEY` is available.** The engine loads the `.env` from the Factory root automatically. No key means the room is closed.
6. **The engine can run.** `python3 -m pip install openai numpy python-dotenv pillow` once. Without Pillow the run still works, just heavier and slower.

**"I don't have it" is a real answer, and most of the time the run proceeds.** What blocks is a missing MACHINE or a missing DECISION, never missing convenience.

| The owner says | What happens |
|---|---|
| "The product is not launched, there is no live image" | Run without an incumbent. Record `incumbent: none (pre-launch)` in the round notes and say plainly that the verdict is weaker: it can rank your drafts, it cannot tell you whether any of them deserves to replace a working listing. The run proceeds. |
| "I have no persona.md" | The engine falls back to its stated default (a general US Amazon shopper) and prints a note. Record `demographics: default general shopper` in the round notes. The run proceeds, blunter. |
| "The persona is derived, I have no Brand Registry export" | Normal, and it is the on-camera demo's own situation. Use the derived persona and put `estimated` in the demographics notes so the label rides on the card. The run proceeds. |
| "I have no OpenAI key" | The room is CLOSED. Say exactly what is missing, point to `guides/mcp-setup-guide.md`, record `blocked: no OpenAI key` in `status.md`, and stop. Never simulate a panel in prose. |
| "I have no Gemini key" | Single-FAMILY run, which is the default anyway (the default is still a MIX of two OpenAI models, and that mix stays; never drop to one model). Say the one-line caveat once: one model family carries one taste, so a thin margin deserves less trust. The run proceeds. |
| "I have no live gallery to race against" | Run Scenario C without an incumbent set and say what it costs you: the frame-by-frame diagnosis still works fully, the set verdict has nothing real to beat. Or skip the gallery race and record it as a named skip. Both are fine, silence is not. |
| "Just test everything in images/" | Not an instruction this room can act on. Ask for the list, echo it back, get the yes. Which version runs is always the owner's call. |
| "Skip the cost line, just run it" | The number gets said either way, it just gets said fast. State it in one line, then run. |
| "Can I decide off the lite run?" | No. Lite is for eyeballing a set or testing the machine. A lite card never fills a Status in `Improvement Log.md`, never closes a decision, and never opens `/ready-to-upload`. The card prints `lite` in its panel line, so a lite card presented as a verdict is visible to everybody later. |
| "Should I run a second round after the fixes?" | OPTIONAL, not required. One round plus the fixes is the design: the honest second opinion is Amazon's own A/B on live traffic, which is free and uses real buyers. Re-run only when the change was large enough that it is effectively a different image.  It costs minutes and a few dollars. |
| No answer at all on the go-ahead | Nothing runs. Leave the station `in progress` with the Blocked on list naming the go-ahead you are waiting for, say exactly what you need, and stop. |

## Process

0. **Derive the scope before you author anything.** Run it against the product folder:

   ```
   python3 .claude/skills/tasting-room/scope.py plan "factory/Products/[product]"
   ```

   It reads `images/` and `incumbent/` off the disk and prints what each race owes, with any FAIL a scorecard already recorded attached to the frame it is about. **Scope stops being a judgment call.** The failure this prevents: eight frames approved, one tested, seven never tested including one already known to be broken, and nothing anywhere saying so. "The approved candidates" in prose is a wish; two records that must agree with no code comparing them will drift, and the drift is invisible.

1. **Name the scenario, and name the RACES.** A sitting is TWO races: the MAIN race (Scenario B) and the GALLERY race (Scenario C). Two runs, two configs, two `out_dir` folders, two cards. Never merge them into one run: a main image and a gallery answer different questions and a merged grid answers neither. State the plan in one line, then reconcile at the end: races planned = races run + races skipped with a named reason. A quietly missing race is the failure this step exists to prevent.

2. **Confirm the exact files.** Echo the filenames back, name the siblings you did not take, and wait for the yes. Open each candidate once with Read so you know you are tasting what the owner meant, including which version it is (the `images/` original, a `-v2` regeneration, or the edited copy in an `edits/vN/` round folder).

3. **Assemble each config.** Wonka writes the JSON; the owner never does. Fields:

   | Key | Required | Notes |
   |---|---|---|
   | `product`, `product_context` | yes | `product_context` is ONE honest line: what it is plus its listed features. Every word of it comes from the Reference Sheet and the research, never from imagination. |
   | `images` | yes | 2 to 12 entries. Single image = `path`. A whole gallery = `paths` in gallery order. |
   | `incumbent_id` | yes on a main race | Must match one of the candidate ids exactly. |
   | `demographics` | recommended | Copied from `research/persona.md`, shaped `{"age_dist": {"35-44": 0.5, "45-54": 0.5}, "gender": {"female": 0.8, "male": 0.2}, "income": {"middle income": 1.0}, "notes": "one line on who this is, plus estimated when it is derived"}`. Omit the block entirely and the engine uses its stated default. |
   | `out_dir` | yes | Absolute path, one folder per race: `tests/tasting-r[N]-[YYYY-MM-DD]-main` and `...-gallery`. |
   | `round` | yes | 1 or 2. It prints on the card. |
   | `compare_to` | Round 2 | Absolute path to the matching Round 1 `results.json`. |
   | `models` | optional | Default is a mix of two OpenAI models, `{"gpt-5.4-mini": 0.6, "gpt-5.4": 0.4}`, on the one key the Factory already has. Two models disagree where one model's private taste would quietly become "the verdict": a single-model panel once called a 75/25 that a mixed panel read as 45/55. Leave this key out; write it only when the owner explicitly asks for a specific model. |
   | `seed` | optional | Default 42. The run is seeded, so the same config replays the same panel and the same shuffles. |

   **BLIND rule.** No label may hint at outcome or ownership: no "new", "ours", "winner", "old", "improved". The engine already hides labels from the tasters and swaps them for neutral aliases before it synthesizes themes, so the leak this rule closes is the HUMAN one: labels print all over the card, and "our new design" tells the person reading the verdict what to think before they have read it. Incumbency travels only through `incumbent_id`.

   **Round 2 id stability.** Keep candidate ids IDENTICAL across rounds. The refined winner is a new FILE (the same filename inside a new `edits/vN/` round folder, or a regenerated `main-01-v2.png`) that keeps its Round 1 id (`main_01`), which is the only thing that lets the card draw an arrow between the rounds instead of showing two unrelated bar charts. Rename a candidate id between rounds and the delta is gone.

4. **Save the config into its round folder as `config.json`.** The engine also writes it there if it is missing, and never overwrites one that already exists, so the reproducibility record cannot be forgotten and cannot be quietly rewritten.

4b. **If there is no incumbent, race the competitors instead.** A brand-new product with nothing live has no current image to beat, and racing your candidates only against each other answers a much weaker question. **Use the strongest competitor's main image, and their gallery, as the benchmark**, taken from `1-inputs/competitors/`. Say out loud which competitor was used and why, and record it in the config, because "beat the category leader" and "beat my own previous image" are different claims and the Card should not blur them.

4c. **Say how long it takes, and point at the live view.** A full sitting is not instant. Tell the owner plainly that it runs for a while, that `live.html` opens by itself in the browser and refreshes on its own, and that the honest thing to do is **go and do something else and come back.** Watching a progress bar is not participation. If the page does not open, `progress.json` in the round folder carries the same information, and `PANEL_OPEN_LIVE=0` suppresses the auto-open for anyone who does not want a browser tab appearing.

5. **Quote the cost, then stop.** One line covering both races: "[N] tasters x [M] candidates, main race and gallery race, full mode, a few dollars per race, about 3 to 6 minutes each. Proceed?" Never state a dollar figure more precise than what you can actually stand behind. The go-ahead covers THESE runs only. Round 2, a re-run after a bad parse rate, and any extra race each get their own line.

6. **Run it** from the kit root, once per race:

```bash
python3 .claude/skills/tasting-room/run.py [config.json]          # full tasting
python3 .claude/skills/tasting-room/run.py [config.json] lite     # quick taste, about a fifth of the tasters
```

   Windows uses `python` instead of `python3`. Before spending anything the engine refuses a broken config out loud (a file that does not exist, two candidates sharing an id, an `incumbent_id` matching no candidate, more than 12 candidates or 12 frames) and it checks that every provider in the model mix has its key. Let it check; it costs nothing and it is cheaper than finding out at minute four. A live progress page (`live.html`) opens and self-refreshes with a stall detector, so a minutes-long run is never a silent terminal. Set `PANEL_OPEN_LIVE=0` to skip the auto-open. **If it stops for any reason (sleep, a closed laptop, a dropped connection), run the SAME command again: it resumes from its checkpoint instead of restarting, and nothing is paid for twice.**

6b. **Record the race, then gate on the coverage.** After each race finishes:

   ```
   python3 .claude/skills/tasting-room/scope.py record "factory/Products/[product]" "<that race out_dir>"
   ```

   Coverage ACCUMULATES: recording the gallery race must never erase the main race, and a second round registers its own row instead of adopting round 1's. Then, before telling the owner the room is done:

   ```
   python3 .claude/skills/tasting-room/scope.py check "factory/Products/[product]"
   ```

   It BLOCKS while anything approved is neither tested nor waived. A deliberate skip stays possible (`scope.py waive <product> <file> "reason"`); a silent one does not. **Run the gate BEFORE asking the owner to decide anything: putting a partial round in front of them is the wrong question.**

7. **Verify the run actually landed, before reading anything.** List the round folder and confirm four files: `config.json`, `results.json`, `tasting-card.html`, `tasting-card.md`. Then open the quality block in `results.json` (or look for the red banner at the top of the card): if `choice_parse_rate` is under 0.9, the counts sit on a reduced sample. Say so, re-run (it resumes and retries the gaps), and do not present the result as solid until it clears. If the run failed, the room has no result. Say that plainly and stop; a described card is a fabricated card.

8. **Read the Tasting Card** (`tasting-card.html` in the round folder, `tasting-card.md` is the compact text twin). It reads top to bottom:

   1. **Header.** Product, round, date, panel size, models, mode. A red data-quality banner appears here when a parse rate fell under 90%. A card wearing that banner is weaker evidence, so re-run before acting on it.
   2. **Verdict card, the DECISION layer.** The winner by exact filename, the one-line verdict, a ready-to-copy next command, and the stability tier from bootstrap resampling the recorded votes (1,000 resamples; the card states in how many the winner held and how many flipped votes would change the result). **Clear lead** (holds in 95% or more AND purchase intent separates them by at least +0.25 of 5): act on it. **Lean** (80 to 95%, or stable-but-tiny): a real lean, not proof. **Toss-up** (under 80%, or the base models disagree): a tie.

      **Why a top tier needs two things.** The bootstrap answers "would resampling these same tasters flip the winner", which a near-unanimous vote never does. It says nothing about SIZE. A forced binary choice converts any consistent preference into a landslide however small it is, so a 76-4 vote can sit on a purchase-intent gap of +0.06 of 5, about 1% of the scale. Reported alone the count would claim a certainty the run never had. Direction is checked first and a big intent gap never rescues an unstable vote. The +0.25 bar is PROVISIONAL and gets refit as real results accumulate in the Improvement Log.
   3. **Candidate cards.** Image, the vote COUNT, purchase intent (which is also the magnitude gate, not decoration), then "What worked" and "What hurt" chips with mention counts (x6 = six tasters raised it), every raw reaction collapsed underneath. Set candidates show the filmstrip.
   4. **Frame by frame (Scenario C, the DIAGNOSIS layer).** Within-set votes per frame (most convincing, weakest), boosts / neutral / hurts, per-frame notes, and a one-line lead on which frame to lead with and which to fix or drop. This layer feeds `/fix`, never the verdict.
   5. **Segments.** Mean intent by age band, gender, and with a model mix per base model. Disagreement between base models is called out in red.
   6. **What the tasters keep saying.** The recurring objections ranked by mentions, tagged with the candidates they apply to. The most portable output of the whole room.
   7. **Suggested fixes.** Numbered and concrete, guarded by step 10.
   8. **Round comparison** (when `compare_to` is set). Previous votes, current votes, delta in votes.
   9. **Footer.** The honest framing and the method line.

9. **Present the verdict honestly, out loud, every time.**
   - These tasters are language models playing shoppers. Never present the numbers as real shopper results, to the owner or in any file.
   - Use the standardized labels: Clear lead, Lean, Toss-up. Anything under Clear lead is a lean, not proof.
   - Say the vs-incumbent result explicitly, win or lose.
   - A single-model panel carries one shared taste. If the per-model rows disagree on the winner, say "no reliable verdict", keep the objections and drop the counts.
   - The most reliable output is the relative ranking plus the recurring objections. Those travel. Exact counts do not.
   - For a real-money decision, a real shopper poll (the optional Pro Move bonus) is the gold standard, and an on-Amazon A/B outranks everything.

10. **Mine the notes into routed actions.** Every recurring objection ends in exactly one of three states, in writing:
    - **Surgical edit.** Word swaps, removals, shortenings go to `/fix` MODE B, each edit citing the objection and its mention count.
    - **Regeneration.** Layout, framing, size in frame, casting and anything spatial goes back to `/main-image` or `/secondary-images` with the exact sentence the tighter brief must carry.
    - **Refused, with a reason.** A synthetic objection that contradicts the research (the selling points, the Reference Sheet, the Improvement Log) is recorded in the round notes as refused and never acted on. The panel is directional; the research is evidence.
    Keep every pre-fix original so an optional Round 2 (or the on-Amazon A/B) can prove the fix helped. **If no theme reached three or more mentions, the winner has no documented flaw: skip MODE B and say so.** Changing a winner without a reason is how winners get broken.

11. **Log the experiment, one row per race, in the same session.** Append to `factory/Improvement Log.md` in the canonical 8-column schema:

    `| Date | Product | Type | Candidates | Winner | Margin | Key why | Status |`

    Type `tasting-room`. Candidates names the race and includes "incumbent". Margin like "preferred by 54 of 100 synthetic tasters vs 31, intent +0.31 of 5, round 1, Clear lead". Key why is the top recurring objection in the tasters' words. Status is `won`, `lost` or `inconclusive`, and it is `inconclusive` whenever the label is not Clear lead OR the base models disagreed. A synthetic tasting does not wait for anything, so the row is written now.

12. **Hand off, with the exact next step.**
    - **Round 1, Clear lead for one of ours:** `/fix` MODE B on the main winner and on the weakest gallery frame from the Scenario C card, everything back through `/inspect`, and the refined set is FINAL: `/ready-to-upload` is open (the pack labels the refined winner `refined after test`, citing this round's card). A Round 2 re-race of the refined set is OPTIONAL, worth it only when the change was large enough to be effectively a different image.
    - **Round 1, anything weaker (Lean, Toss-up, incumbent won, models disagree):** mine the notes, refine or build a challenger (`/fix` MODE B, or `/main-image` if a praise theme handed you a thesis this round never tested), then back here for Round 2 with `compare_to` wired. The Shipping Room stays shut until a round of ours produces a Clear lead. **And say the honest ceiling out loud after Round 2:** if two rounds both came back without a reliable verdict (model disagreement especially), a third synthetic round is unlikely to break the tie, and the honest tiebreaker is the live Amazon A/B. On a listing the owner does not control (the bootcamp demo), that tiebreaker does not exist, so the lawful end state is `no synthetic verdict`; the Shipping Room knows how to teach Day 10 in exactly that shape rather than demanding a verdict the method cannot produce.
    - Either way `/improvement-loop` reads these rows on Day 10.

## When the result is not what you hoped

Decisive answers, so nobody has to improvise one under pressure.

| The card says | What it means | What happens |
|---|---|---|
| Clear lead, and it beats the incumbent | The strongest outcome available here | Mine the notes, refine the winner, re-inspect, ship. An optional Round 2 re-race is for changes big enough to be a different image. |
| Lean | Directionally useful, not proof | Fine for choosing what to refine. Never fine for shipping. Refine, then Round 2 decides. |
| Toss-up | Treat it as a tie | Use the objections, ignore the counts. Do not ship on it. |
| The base models disagree | Model taste, not shopper signal | No reliable verdict. Keep the objections, drop the counts, say it in that order. |
| The incumbent won | The cheapest good news in the factory | Say it as a save: a working listing was not downgraded, for the price of lunch, instead of finding out over months of lost traffic. Then mine WHY the incumbent holds, which is a free teardown of a proven image, and build Round 2's candidates from those notes. The Shipping Room stays shut until one of ours wins. That is the system working. |
| The owner's override lost | Normal, and worth saying out loud | Record it honestly beside the reason they gave. A recorded losing instinct is exactly what makes the next pick better, and it is why the reason gets written down before the run, not after. |
| Parse rate under 90% (red banner) | The counts sit on a reduced sample | Re-run the same command (it resumes and retries the gaps) before trusting the result. A vote the engine cannot read is DROPPED rather than guessed, which is exactly why this number can fall: a falling parse rate is the guard working, not the guard failing. |
| No theme with three or more mentions | The winner has no documented flaw | Skip MODE B rather than inventing a fix. Round 2 can still run the winner against your strongest unused gate-passed candidate plus the incumbent. |
| An objection contradicts the research | A synthetic hunch against real evidence | Record it as refused, with the evidence that outranks it. Never act on it. |

## Output format

```
tests/
  tasting-r1-[YYYY-MM-DD]-main/        the MAIN race
    config.json          the exact configuration that ran (reproducibility)
    results.json         every raw reaction, vote, score, theme count, and the quality block
    tasting-card.html    the full Tasting Card, self-contained, images embedded
    tasting-card.md      the compact text twin, same structure
  tasting-r1-[YYYY-MM-DD]-gallery/     the GALLERY race, same four files
  tasting-r2-[YYYY-MM-DD]-main/        Round 2, with compare_to wired
  tasting-r2-[YYYY-MM-DD]-gallery/
```

`tasting-card.md` carries the verdict table with the standardized label, the strongest-frame list, segments, ranked objections with counts, numbered fixes, the round comparison when `compare_to` is set, and the house rules. `live.html` and `progress.json` are run-time views and can be ignored afterwards.

## Golden Standards check

Before presenting, verify:
- [ ] The scenario was named, both races were planned, and races planned = races run + races skipped with a named reason.
- [ ] The exact tested files were echoed back and confirmed by the owner, no folder was guessed, the sibling versions not taken (`-v2` regenerations, `edits/vN/` copies) were named out loud, and each file was opened once with Read.
- [ ] The incumbent is one of the candidates on every main race, or `pre-launch, no incumbent` is recorded in writing.
- [ ] The owner's picks are recorded, and any override of the scorecard rank carries its one-line reason.
- [ ] Demographics came from `research/persona.md` with the REAL buyer age, never the aspirational casting age, and a derived persona carries the word `estimated`. A default fallback is recorded as such.
- [ ] No candidate label hints at outcome or ownership; incumbency travels only through `incumbent_id`.
- [ ] The cost line was stated and one go-ahead was given before each run.
- [ ] `config.json`, `results.json`, `tasting-card.html` and `tasting-card.md` all exist in every round folder, and the folder was actually listed to confirm it.
- [ ] The parse rate was checked; anything under 90% was flagged and re-run rather than presented as solid.
- [ ] The verdict was presented with its standardized label, the vs-incumbent result, and the model-disagreement check, and the Pro Move line (a real poll is the gold standard) was said with it.
- [ ] Round 2 set `compare_to` to the matching Round 1 `results.json` and kept every candidate id stable.
- [ ] Every recurring objection is routed to an edit, a regeneration, or recorded as refused with the evidence that outranks it. Nothing is left hanging.
- [ ] One `Improvement Log.md` row per race, with Status `inconclusive` whenever the label is not Clear lead or the models disagreed.
- [ ] Nothing anywhere presents panel numbers as real shopper results, and no card, quote or count was written by hand.
- [ ] All outputs are in English with zero em or en dashes.

## Wonka lines

Openers:
- "To the Tasting Room. A hundred tasters are waiting, and not one of them is polite."
- "My opinion retires at this door. Let the panel chew on it."
- "Bring the incumbent too. In this room, reality always gets a seat at the table."
- "Read me the filenames. I have never once regretted spending ten seconds before spending ten dollars."

Closers:
- "The panel has spoken, directionally. main-01 takes the golden ticket, and the notes tell us exactly what to sharpen."
- "The tasters split by model, which means no verdict at all. We take the objections and leave the counts."
- "The incumbent held. Wonderful. It just saved you from shipping a prettier, weaker image, and it cost you pocket change."
- "They voted for the cascade and then asked how big the thing is. They gave us the winner and the next fix in the same breath."
- "Two cards, two races, one afternoon. Now we do the part that most sellers never do: we listen to them."

## Definition of Done

- Every planned race has its round folder on disk with all four files present, confirmed by listing the folder. A race that did not run is recorded as a named skip, never left silent.
- The verdict was presented with the honest framing: the standardized label, the vs-incumbent result, the model-disagreement check, and the Pro Move gold-standard line.
- The owner's picks, and any override with its reason, are on the record.
- `factory/Improvement Log.md` carries one row per race, Status filled.
- Every recurring objection is routed (edit, regeneration) or recorded as refused with its reason.
- `status.md` updated per below, and the owner knows the exact next step: a Clear lead for one of ours goes to refine and then `/ready-to-upload`; anything weaker goes to refine and Round 2, which opens the Shipping Room only when one of ours wins with a Clear lead.
- If any line above is missing, the room is NOT done. Say which line, and never fill the gap with a written-out card.

## Update status.md

Set PROVE to `in progress` with the round folders as the artifact. This room never sets it `done`: that belongs to `/ready-to-upload` when the pack exists, or to `/improvement-loop` when the owner closes the cycle without packaging. Add one Log line per race: `[date] Tasting Round [N] [main/gallery]: [winner] preferred by [N] of [M] tasters, intent +[G] of 5, vs incumbent [beaten/held], [n] tasters, [Clear lead / Lean / Toss-up]. Owner picked [files][, overriding rank [N] because "[reason]"]. Notes routed to [/fix MODE B / challenger / none, no theme reached 3 mentions]. See tests/tasting-r[N]-[date]-[race]/.`

## Troubleshooting

- **"OPENAI_API_KEY is missing"**: the key goes in the `.env` file at the Factory root (the Day 1 setup). `guides/mcp-setup-guide.md` walks through it.
- **"CONFIG PROBLEM(S). Nothing ran and nothing was spent"**: the preflight caught a broken config before the first call. It prints the exact lines to fix (a missing file, a duplicate id, an `incumbent_id` that matches no candidate, too many candidates or frames). Fix and run the same command again.
- **The run stopped mid-way** (sleep, network, a closed terminal): run the exact same command again. The checkpoint in the round folder resumes it, nothing is lost and nothing is charged twice. Changing images, counts, models or seed resets the checkpoint on purpose; adding `compare_to` does not.
- **A red data-quality banner, or a console warning about parse rates under 90%**: some votes did not come back readable, so the counts sit on a smaller sample. Usually a flaky connection. Re-run before trusting the result.
- **The Round Comparison section is missing**: `compare_to` must be an ABSOLUTE path to the previous round's `results.json`, and the candidate ids must match across rounds. The console prints a note when the file could not be read.
- **A run that takes an hour is broken, not slow.** Full tastings finish in minutes. Stop it and run the same command again.
- **"gemini-* taster models need GEMINI_API_KEY"**: a config explicitly asked for a Gemini taster model. Add that key to the `.env`, or remove the `"models"` block so the default OpenAI mix runs on the key the Factory already has.
- **Missing Python packages**: `python3 -m pip install openai numpy python-dotenv pillow`, once. Pillow also powers the automatic downscaling that keeps requests small and fast.

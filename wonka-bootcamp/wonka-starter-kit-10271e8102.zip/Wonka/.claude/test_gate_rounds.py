"""gate.py rounds: old kits keep reading the bare (round 1) lines, new kits read their own round."""
import os, sys, io, tempfile, importlib.util, contextlib
from datetime import datetime, timezone
HERE = os.path.dirname(os.path.abspath(__file__))
spec = importlib.util.spec_from_file_location("gate", os.path.join(HERE, "gate.py"))
gate = importlib.util.module_from_spec(spec); spec.loader.exec_module(gate)

SCHED = """# comment
round wonka_r1 start 2026-09-01
round wonka_r2 start 2026-09-22
1 2026-09-01T12:40Z
2 2026-09-02T12:40Z
10 2026-09-17T12:40Z
wonka_r2 1 2026-09-22T12:40Z
wonka_r2 2 2026-09-23T12:40Z
wonka_r2 10 2026-10-08T12:40Z
"""
def U(s): return datetime.fromisoformat(s.replace("Z", "+00:00"))

def test_default_round_is_the_bare_lines_and_legacy_parse_matches():
    rounds, starts = gate.parse_rounds(SCHED)
    assert set(rounds) == {"wonka_r1", "wonka_r2"}
    assert rounds["wonka_r1"][1][10] == U("2026-09-17T12:40Z")
    assert rounds["wonka_r2"][1][10] == U("2026-10-08T12:40Z")
    assert starts["wonka_r2"] == U("2026-09-22T00:00Z")
    assert gate.parse(SCHED) == rounds["wonka_r1"]

def test_old_parser_skips_round_lines():
    """The v49 parser: two-word lines only. It must still see round 1 and nothing of round 2."""
    sched = {}
    for line in SCHED.splitlines():
        line = line.strip()
        if not line or line.startswith("#") or line.lower() == "all": continue
        parts = line.split()
        if len(parts) != 2: continue
        sched[int(parts[0])] = parts[1]
    assert sched == {1: "2026-09-01T12:40Z", 2: "2026-09-02T12:40Z", 10: "2026-09-17T12:40Z"}

def test_round_all_line():
    rounds, _ = gate.parse_rounds(SCHED + "wonka_r2 all\n")
    assert rounds["wonka_r2"] == ("all", None)
    assert rounds["wonka_r1"][0] == "schedule"
    rounds, _ = gate.parse_rounds("all\nwonka_r2 2 2026-09-23T12:40Z\n")
    assert rounds["wonka_r1"] == ("all", None) and rounds["wonka_r2"][0] == "schedule"

def _kit(tmp, upgraded=False, round_file=None):
    os.makedirs(os.path.join(tmp, ".claude"))
    if upgraded: os.makedirs(os.path.join(tmp, "_pre-upgrade-2026-09-18"))
    if round_file: open(os.path.join(tmp, ".claude", "round"), "w").write(round_file + "\n")
    gate.__file__ = os.path.join(tmp, ".claude", "gate.py")

def test_round_file_wins():
    with tempfile.TemporaryDirectory() as tmp:
        _kit(tmp, upgraded=True, round_file="wonka_r2")
        _, starts = gate.parse_rounds(SCHED)
        assert gate.kit_round(starts, U("2026-09-18T00:00Z")) == ("wonka_r2", "file")

def test_upgraded_kit_is_round_1_even_near_round_2_start():
    with tempfile.TemporaryDirectory() as tmp:
        _kit(tmp, upgraded=True)
        _, starts = gate.parse_rounds(SCHED)
        assert gate.kit_round(starts, U("2026-09-21T00:00Z")) == ("wonka_r1", "upgraded-kit")
        assert open(os.path.join(tmp, ".claude", "round")).read().strip() == "wonka_r1"

def test_fresh_download_takes_the_nearest_start_and_records_it_once():
    with tempfile.TemporaryDirectory() as tmp:
        _kit(tmp)
        _, starts = gate.parse_rounds(SCHED)
        assert gate.kit_round(starts, U("2026-09-18T00:00Z")) == ("wonka_r2", "nearest-start")
        # a later call reads the file, even if the clock now says otherwise
        assert gate.kit_round(starts, U("2026-09-02T00:00Z")) == ("wonka_r2", "file")

def test_fresh_download_early_in_round_1_is_round_1():
    with tempfile.TemporaryDirectory() as tmp:
        _kit(tmp)
        _, starts = gate.parse_rounds(SCHED)
        assert gate.kit_round(starts, U("2026-09-05T00:00Z"))[0] == "wonka_r1"

def test_no_rounds_declared_means_default():
    with tempfile.TemporaryDirectory() as tmp:
        _kit(tmp)
        _, starts = gate.parse_rounds("1 2026-09-01T12:40Z\n2 2026-09-02T12:40Z\n")
        assert gate.kit_round(starts, U("2026-09-05T00:00Z")) == ("wonka_r1", "no-rounds-declared")

def _run(argv):
    buf = io.StringIO()
    with contextlib.redirect_stdout(buf):
        code = gate.main(argv)
    return code, buf.getvalue()

def test_main_verdicts_per_round():
    gate.fetch = lambda: (SCHED, U("2026-09-25T00:00Z"))
    gate._maybe_update_quietly = lambda: None
    with tempfile.TemporaryDirectory() as tmp:
        _kit(tmp, round_file="wonka_r2")
        code, out = _run(["gate.py", "2"])
        assert code == 0 and out.strip().splitlines()[-1].startswith("OPEN day=2 round=wonka_r2"), out
        code, out = _run(["gate.py", "10"])
        assert code == 3 and "CLOSED day=10 round=wonka_r2" in out, out
    with tempfile.TemporaryDirectory() as tmp:
        _kit(tmp, round_file="wonka_r1")
        code, out = _run(["gate.py", "10"])
        assert code == 0, out   # round 1 is fully open by then

def test_unknown_round_warns_and_continues():
    gate.fetch = lambda: (SCHED, U("2026-09-25T00:00Z"))
    gate._maybe_update_quietly = lambda: None
    with tempfile.TemporaryDirectory() as tmp:
        _kit(tmp, round_file="wonka_r9")
        code, out = _run(["gate.py", "5"])
        assert code == 0 and "WARN" in out, out

if __name__ == "__main__":
    fails = 0
    for name, fn in list(globals().items()):
        if name.startswith("test_") and callable(fn):
            try:
                fn(); print("ok  ", name)
            except Exception as e:
                fails += 1; print("FAIL", name, "->", repr(e))
    print("RESULT", "FAIL" if fails else "PASS", fails)
    sys.exit(1 if fails else 0)

---
name: fix
description: Surgical image edits in the Fixing Room, in two modes. MODE A (pre-tasting, QA-driven) fixes the defects the Inspection Room flagged. MODE B (post-tasting, note-driven) reads the Tasting Card notes and refines the images the owner named off them, typically the winning main image or the frame the Card flagged. Fixes the chosen image first (a focused edit with the references, the changed region composited back so the rest of the frame stays byte-identical), regenerates from that base only for broad changes or after two failed edits, never swaps a chosen image for another, runs routine fixes on a report under CLAUDE.md's routine-fix policy, refuses fixes that break a house rule or fight the research, writes every edit round as a COMPLETE set snapshot to edits/v1, v2 and so on (originals stay write-once in images/), verifies side by side, re-inspects, and logs every edit and every routing decision. Triggers: /fix, "fix this image", "remove the badge", "shorten that text", "change the word", "edit the image", "refine the winner", "act on the tasting notes", or fix items coming from /inspect or /tasting-room.
---

# The Fixing Room

| Meta | Value |
|------|-------|
| Room | The Fixing Room |
| Station | INSPECT (fix leg, MODE A) and PROVE (post-tasting refinement, MODE B) |
| Taught | Day 5, MODE A, as the second half of the quality loop. MODE B on Day 8, off the Tasting Cards, the same day the panel runs. Runs again whenever a scorecard or a Tasting Card names a defect |
| Needs | The image file and the exact defect (MODE A: the scorecard. MODE B: the Tasting Card notes), `OPENAI_API_KEY`, plus `2-reference/reference-sheet.md` and `brief/creative-brief.md` whenever a fix changes on-image text |
| Saves to | `factory/Products/[product]/edits/v[N]/`, one folder per edit ROUND, each holding the COMPLETE current set (new renders for fixed files, unchanged copies of everything else). Originals stay write-once in `images/` (and `aplus/`, `variations/`). The round log is `edits/fixes-log.md` |
| Typical cost | Cents per edit at low quality, roughly $0.02 to $0.10 (measured on gpt-image-2; on another model, quote from the first edit of the run). A face repair runs at `high` instead (slower and dearer, see step 7). Every edit is counted and logged; routine fixes run on a report inside the routine-fix policy's limits (CLAUDE.md), and a round that crosses a limit stops once for one approval. |

## What this room does

Most defects on a chosen image cost cents to fix ON that image. This room fixes the chosen image first: one precise change at a time on the direct OpenAI image edit API with the references attached, the changed REGION composited back onto the base so every other pixel stays the base's own, the original always preserved, every result verified against it and re-inspected before it counts. A broad change (recast, new scene, new layout) or a defect that failed two edits goes back to its generation room (`/main-image`, `/secondary-images`, `/aplus`, `/variations`) as a regeneration FROM THIS FILE AS THE BASE with a tighter brief. What this room never does is hunt for a different image to avoid a fix: the owner chose this one. The route, the spend and the stops are CLAUDE.md's routine-fix policy, the one source. The room services mains, secondaries, and variation imagery. **A+ module images are fixed HERE, on the exported module file, through ONE door for the student (house decision, Jay 9 September 2026, evening; it replaces the 27 July "all A+ edits inside Genrupt" rule and the two-door routing of kit v30).** `/aplus` exports the chosen concept at the pick, so the file is already on disk when the scorecard lands. The Genrupt A+ export is flat image files cut to the final module size (about 1464x600 desktop, 972x729 mobile), so a local edit on an exported module keeps the upload-ready cut by construction, and the composite keeps every pixel outside the box identical. What makes an A+ module different from a gallery frame is only that the page is one canvas sliced into strips: a local fix near a module's top or bottom edge must still meet its neighbour at the seam, so every A+ local fix is verified at the seam as well as in the box (`/aplus` step 8c). The routing:

| A+ defect | Route |
|---|---|
| A local defect on one module: a typo, a badge, a stray element, one part off its axis, one wrong label | **Here**, on the EXPORTED module file (`aplus/export/[mode]/`), the same focused edit and region composite as any listing frame, cents, then the seam read. The default: fix the chosen design |
| The same local defect repeated across modules (the same wrong word in three modules) | **Here, one fix per module.** Repetition is never a reason to change concept |
| AI-looking people in one module | **`/fix-faces` on the exported module file**, its head boxes and its own composite; the module keeps its exact dimensions |
| A page-level change: a different layout, a different direction for the whole page, a module doing the wrong job | **ROUTE to `/aplus` step 8**: another concept from the same run, or a new round with the same recipe. Never an edit here |
| The owner says, in words, "keep THIS concept and change the page" | **`/aplus` step 8, Genrupt's `edit_aplus_concept`**, only on that explicit ask: the whole concept re-renders at a variable price, and after it the export and every local fix are done again. Never offered first |

The reason the 27 July rule existed was the fear that a local edit would break the export. It does not: the export is the file. What it would break is a version in the Genrupt builder, so the log records that the adopted module is a LOCAL edit of Genrupt version N, and a Genrupt edit on that concept, if the owner ever asks for one, starts from N, not from the local file. Every A+ fix lands in `edits/vN/aplus/` beside the untouched export, never in `aplus/` itself, and once that round exists it is the upload (`/aplus` step 11). Log the route and the reason for every A+ item.

Every fixing session is a ROUND, and every round writes a complete set snapshot to its own folder: `edits/v1/` for the first round, then `v2/`, `v3/`, and so on. Fixed files go in as new renders; every untouched file is COPIED in unchanged, same filename. The version lives in the folder name, never in the filename. The law this buys: **the newest `vN` folder holds the ADOPTED SET as it stood when the round opened**: every asset at its adopted version, and its `round.md` names where each copy came from. Read that manifest, never guess from the folder alone: an asset generated AFTER the last round (Day 6 secondaries after a Day 5 main fix) lives only in `images/` until the next round adopts it, and an evidence file (`-rejected`, `-render`) is never a set member. `images/` is the raw generation output and it is write-once: this room reads from it and never writes into it.

**The economics, said to the owner once and then simply done.** A normal listing-image repair (a wrong word, a badge, an element, a part off its axis, a small local change) runs on the direct OpenAI edit endpoint at `low`: usually cents, no new Genrupt batch, the original untouched, the result in a new edit round, verified before it counts. That is why "one thing is wrong on my chosen frame" never becomes "buy another set of candidates": Genrupt gives volume, ideas and the Amazon-specific environment; this room gives cheap, targeted work on the winners. The owner never needs to know how to edit an image; they need to know what they want changed. (A+ modules route by defect, the table above: a page-wide change runs inside Genrupt through `/aplus`, a local defect on one exported module runs here for cents.)

The Fixing Room runs in TWO modes, and this is a core promise of the bootcamp: creative does not stop at "generated", it improves with evidence. **And MODE A's fix list has THREE lawful sources, all first class:** the Inspection Room's scorecard (Wonka-led: he finds it, explains it, fixes it), a Tasting Card in MODE B, and the OWNER's own eyes (owner-led: "Wonka passed this, but the tower looks off to me", "remove that person", "this headline is weak"). No scorecard is required for an owner to point at a visible problem; the route, the verification and the log are the same whichever door the item came through.

- **MODE A . pre-tasting, QA-driven (Day 5).** Fix the specific defects the Inspection Room flagged, so only gate-passing candidates ever reach the Tasting Room. MODE A removes flaws.
- **MODE B . post-tasting, note-driven (Day 8, straight after the panel).** After a Tasting Round, read the Tasting Cards and refine what the owner named, typically the winning MAIN image (from the main race Card's friction themes) and/or the frame the gallery race Card's frame-by-frame layer flagged; the main may stay untouched, and a losing main candidate is still never refined. After the corrections the set goes back to `/inspect` and is then final on the owner's word. Another comparison runs only if the owner asks a concrete question; a challenger brief for `/main-image` is built when the owner wants one, never queued by default. MODE B chases conversion.

Both modes use the same routing table, the same refusal gate, the same edit API, the same keep-the-original discipline, and the same verification. The only difference is where the fix list comes from: the scorecard, or the Tasting Card notes.

## What this room never does

- **Never regenerates.** A regenerate-class defect leaves this room as a written brief instruction naming the current file as the base, not an edit.
- **Never swaps.** A defect on the image the owner chose is fixed on that image. Wonka never proposes a free alternative, another candidate or the pool instead of the fix; an alternative is offered only when the owner asks for one, approves one, or two edits and the regeneration route have both failed.
- **Never "fixes" a preference.** "I like the other one more" and "make it pop" are not defects; they get one sentence of Wonka's reading and a question. A named image plus a named direction ("a simpler layout for sec-03, same message") is a request, never a preference: it routes. A plain-language DEFECT ("the column is not centred", "the logo is missing on the left one") is a fix order and runs without a `/fix`, a prompt, or a "go".
- **Never removes a prop, an ingredient or an accessory nobody asked to lose.** Props are lawful on every image, the main included; a prop leaves only on the owner's word, and Wonka never lectures Amazon policy to justify a removal.
- **Never edits the incumbent.** The live Amazon image is the benchmark to beat and it belongs to another seller. It is never an edit base and never a generation reference.
- **Never writes into `images/`** (or `aplus/`, `variations/`). Those folders are write-once generation output. Every render this room produces lands in the round folder `edits/vN/`, nowhere else.
- **Never overwrites, renames, or deletes an original**, and never touches a previous round folder after the next round opens. The owner prunes their own files.
- **Never leaves a round folder incomplete.** A `vN` missing files is a broken snapshot: every file the round did not fix gets copied in unchanged before the round closes.
- **Never puts a word on an image that is not traceable** to the Reference Sheet, the brief, or the live listing. A fix is the easiest place in the whole factory to invent a product fact. It does not happen here.
- **Never spends outside the routine-fix policy.** Inside its limits (calls per round, estimated cost per round, attempts per defect, `low` quality outside a face repair) a routine fix runs on a REPORT with its estimate; crossing a limit, a paid regeneration route, or an owner preference on file that says ask first, stops the round once for one approval. Never a silent cent, never a ping per item, never a round split to stay under a limit.
- **Never edits an image it has not opened with Read**, and never logs a fix as SUCCESS it has not opened again afterwards.
- **Never presents a failed, unverified, or un-re-inspected fix as a candidate.**

## Before you start

- **State the mode and the list's source out loud.** MODE A if the list comes from an Inspection Room scorecard OR from the owner directly (log `list source: owner` for the second; both are MODE A). MODE B if the change was named after a completed Tasting Round, off its Cards, whoever named it (log `list source: owner` there too when the owner named it). It changes only where the list comes from, never how edits run.
- **MODE B: read the Cards first.** Open the latest `tests/tasting-r[N]-[date]-main/tasting-card.md` (and the `...-gallery` Card if both races ran), and confirm from the verdict band which file WON the main race (the table's File column names it, and the winner line repeats it) and which frame the frame-by-frame layer named weakest. Refinement targets what the owner named, typically the winner and/or the flagged frame; the main may stay untouched. It never targets losing candidates.
- **Find the current set.** The current version of every file is its ADOPTED copy: the newest same-name copy across the `edits/vN` rounds when one exists, else the original in `images/` (A+ in `aplus/`, variations in `variations/`). A file generated after the last round is current in `images/` even though the newest round does not hold it. `-rejected` and `-render` files are evidence, never candidates. Confirm the exact target files exist there and open each one with Read so you can see the defect yourself. Echo the list back in one line before doing anything.
- **Confirm the key.** If `$OPENAI_API_KEY` is not set, load it from the Factory root `.env` first, with the same parser `/machines-check` uses:
  ```bash
  export OPENAI_API_KEY=$(grep -m1 '^OPENAI_API_KEY=' .env | cut -d= -f2- | tr -d '"' | tr -d "'" | tr -d ' ')
  export WONKA_IMAGE_MODEL=${WONKA_IMAGE_MODEL:-$(grep -m1 '^WONKA_IMAGE_MODEL=' .env | cut -d= -f2- | cut -d'#' -f1 | tr -d '"' | tr -d "'" | tr -d ' ')}
  ```
  The second line is the model setting from CLAUDE.md ("Which image model"); without it the curl below would ignore the `.env` and run the default.
  The `-f2-` and the quote stripping both matter. A key written as `OPENAI_API_KEY="sk-..."` is normal, and a parser that cuts at the first `=` and keeps the quotes hands the API a truncated key wrapped in quote marks. It fails as a 401, which reads like a bad key rather than a bad parse, and it fails HERE on Day 5 even though Day 1's check passed with the same file..
- **Get one sentence for the defect and one for the desired result.** "Make it better" is not a fix order; ask for the specific change. "The column is not centred on the left one" IS one: the desired result is what the reference shows, and Wonka writes both sentences himself from the references, verifies the defect on the magnified crop, and runs.
- **The spend is the routine-fix policy in `CLAUDE.md`, nothing else.** Build the WHOLE list first with ONE estimate line, check it against the policy's limits, and RUN on a report when it is inside them. A list that crosses a limit (calls, estimated cost, a third attempt on one defect) or that contains a paid regeneration stops ONCE for ONE approval, with the number that crossed. An owner preference on file ("ask before every spend"; "just check, do not fix yet") wins in either direction.

### "I don't have it" is a real answer

Missing convenience never stops this room. Missing EVIDENCE stops only the item it belongs to. Record every gap in the log and proceed.

| The owner says | What happens |
|---|---|
| "No scorecard, but this badge has to go" | Proceed on the stated defect. Log `list source: owner, no scorecard on file`. |
| "No Tasting Card, but they said the text was busy" (MODE B) | Proceed on the stated notes. Log `notes source: owner recollection, no Card on file`, and say plainly that no count is on file; an owner-named change runs regardless, logged as owner-named. |
| "No reference sheet / no brief" and a fix changes on-image text | Do not invent. Read the new wording back and get the owner to confirm it is literally true of the product. Log `wording verified by owner, no reference sheet on file`. |
| "I deleted the original" (the `images/` file is gone) | The edit can still run off the latest `edits/vN` copy, but say plainly that the side-by-side check against the true original is degraded. Verify against the previous round's file and the scorecard's literal description instead and log `no original on file, verification degraded`. |
| "No OpenAI key" | Paid edits are closed, the ROOM IS NOT. Run the whole list through the refusal gate and the routing table, log every decision, hand the regenerate items to their rooms, and park the edit items as `blocked: no key` with a pointer to `guides/mcp-setup-guide.md`. |
| No answer on a stop the policy required (a limit crossed, a paid regeneration) | Nothing beyond the limit runs. Park the station `in progress`, say exactly what is waiting, and stop. Fixes inside the limits already ran. |
| "Just fix all of them, do not ask" | That is the default already. The routing and the refusal gate still run; the list is announced with its estimate and runs at once, and only a policy limit stops it. |
| "I only want the left machine fixed, leave the rest" | Scope the round to what was named. The composite step keeps the rest of the frame byte-identical anyway; say so once. |

## The refusal gate. Two fixes Wonka will not run

Apply this to every item BEFORE routing. A refusal is a result, not a failure: it gets logged with its reason and its reroute, and the owner may override in writing.

1. **A fix that breaks a house rule.** The commonest one by far: an objection about the MAIN image that can only be answered with text or a graphic. A main carries no overlay text, no callouts, no badges, no arrows, **and no added graphic logo**, ever. (A logo printed on the real product is product truth and stays.) Refused everywhere too: drawing, redrawing, re-spelling or approximating a logo. A logo defect is fixed by re-running the wiring in `/reference-sheet` against the real supplied asset, or by removing the rendered graphic, never by having the model draw it better. Also refused everywhere: adding a star rating or review reference, a drawn award or Best Seller badge, a third-party logo, a flag graphic, an invented percentage, or a medical claim. **Reroute, do not build:** the message goes to a secondary frame where it is allowed to live, and the gallery often already has that frame. Example: tasters say they cannot tell how big the fountain is. No "8 x 8 x 18 IN" callout may be added to the main. It goes to the gallery scale frame.
2. **A fix that fights the research.** The panel is cheap and fast, which is exactly why it never quietly overrules expensive real evidence like reviews, returns, and the selling-points checklist. Example: tasters ask for a bigger, fuller chocolate cascade, but the reviews report that a fill at the listed capacity gives a thin flow. Answering that objection sells a promise the product cannot keep as sold, which is the complaint that drives its one-star reviews. Record it in the test file, do not execute it. The owner can override; the reason goes in the log.

## Process

1. **Write the instruction list before any surgery.** Orders first, scalpel second. One line per item: what changes, which asset it belongs to, and the evidence that justifies it.
   - **MODE A:** each item cites the scorecard flag (the dimension and the element).
   - **MODE B:** the list is the changes the OWNER named off the Cards; each item cites the exact tasting note and the number of tasters who raised it as evidence. **Counts never block an owner-named change and never order one.** The three-mention bar applies only to a proposal Wonka offers on his own: one taster is noise, three or more is worth proposing. **If the owner names no change, MODE B runs no edits at all**: say so, log `no change named, no refinement`, send the set back to `/inspect`, and it is then final on the owner's word. Another comparison only if the owner asks a concrete question. Changing a winner without a reason is how winners get broken.
   - A good instruction: "Remove the two smallest callouts. Justified by: five tasters said the text was busy." A bad one: "Make it pop more." Strike anything of Wonka's own that reads like taste smuggled in as data; an owner-named change is never struck, it is logged with whatever evidence exists.

2. **Run the refusal gate** (above) on every item. Refused items get their reason and their reroute written down now, and they never reach the routing table.

3. **ROUTE EVERY SURVIVING ITEM. This decision is the room.**

   | Defect | Route |
   |---|---|
   | Shorten or remove text | EDIT |
   | Remove an element (badge, card, stray object) | EDIT |
   | Add a short supporting line of true, sourced text on a secondary frame | EDIT, wording checked against the brief or the Reference Sheet (step 5), by the surgical prompt or the local retype (step 7c), composited back |
   | Swap a word or a claim for a shorter, truer one | EDIT, by either route: the surgical prompt (step 5), or the local retype (step 7c) when the text sits on a flat or gently graded background and an installed font matches; same verification either way |
   | Recolor an accent | EDIT |
   | A part of the product in the wrong place: off its axis, misaligned with another part, a tier not centred, a joint that does not meet | EDIT, focused on that instance's region, the reference sheet attached, composited back by region |
   | Restore the product's own markings (a logo, control labels) or reshape an object ("make the marshmallow a short cylinder") | EDIT, focused, references attached, composited back; after two failed edits a regeneration from this file as the base |
   | Fix the product itself (wrong part count, wrong material, wrong label) on ONE instance or one region | EDIT first, references attached; two failures route it to regeneration from this base |
   | Move or resize ONE element inside its own region; a small layout change that stays local | EDIT first, composited back; two failures route it to regeneration |
   | A SMALL element, under about 200 pixels on the base: an icon, a label, an inset, a control panel, a diagram detail | EDIT by the REGION route (step 7d), chosen FIRST for an element this size: the region is cropped with margin, enlarged to the endpoint's working size, edited at full resolution, scaled back and composited. A whole-frame edit leaves an element this small untouched (measured 14 September 2026: the PT04 FLOW icon survived two whole-frame edits and landed on the first region edit). It is an edit under the same attempts limit, never a reset of the counter |
   | Enlarge text so it reads at its class's display size (160px for a listing image; an A+ module's body text at Amazon's column width or phone width, never at 160) | REGENERATE from this base (an enlargement re-flows the layout around it). A+ body text is never sent here because it fails at 160 |
   | Change the whole layout or composition, a new scene, most of the frame wrong | REGENERATE from this base, tighter brief |
   | Make AI-looking people look real (the three signatures: doll face / waxy skin / filter glow) | EDIT, via the people-rescue pass below, `high` |
   | RECAST a person (different age, different person) or change their pose | REGENERATE from this base |
   | An A+ module with a local defect (typo, badge, element, one part, one label, one face), on one module or repeated across several | EDIT here on the adopted copy of the exported module, one fix per module, composited back, then the continuity read (the A+ routing above) |
   | An A+ defect whose object continues into the neighbouring module (a person whose neck and shoulders cross the seam, a product cut by the strip) | EDIT the JOINT region: open the adjacent modules together, one edit on the stacked image with a box that holds the whole object across the seam, re-cut at the original boundaries and sizes, every touched module lands in the same round; then the continuity read at 2x and at 1x. Measured 10 September 2026: a face replaced inside m1 alone left a visible seam at the neck in m2 while every numeric check passed |
   | An A+ page that needs a page-level change (a different layout, a different direction, a module doing the wrong job) | ROUTE to `/aplus` step 8: another concept from the same run or a new round with the same recipe; Genrupt's edit only when the owner asks in words to keep this concept |
   | "Keep main-07 as the base and take X from main-03" | REGENERATE, `/main-image` step 8b (develop), new number |
   | The same defect after TWO failed edits | Propose REGENERATE from this base (the default after two); a third edit runs only when the owner asks for more edit attempts, in words, with a bound ("three more versions to compare"), and it is logged as owner-requested. The region route (step 7d) is such an edit: after two failed whole-frame edits on a small element it is the THIRD attempt, run on the owner's word and logged as owner-requested, which is why it is chosen first on a small element rather than after |

   The reason the composite exists is mechanical: the edit endpoint re-renders the WHOLE frame, so even a correct local fix comes back with the rest of the picture drifted (measured 7 September 2026 on a two-machine frame: the tower re-centred as asked, and both machines came back smaller with the jug reshaped). Pasting only the fixed region back onto the base (step 7b) keeps everything outside it byte-identical, which is what makes spatial fixes an edit. **For every REGENERATE item: do not edit it.** Send it to its generation room with THIS file named as the base and the exact sentence the tighter brief must contain, for example "The machine has FOUR tiers. All four must be visible and countable." Record the routing decision in the log even when no edit runs. An image needing three or more edits is a regeneration wearing a disguise: say so and recommend the ovens, from this base.

4. **Announce the plan with its estimate, check the policy's limits, and run.** The routine-fix policy in `CLAUDE.md` pre-authorises the round inside its limits; the plan is REPORTED, never gated, and runs in the same breath. It stops for ONE approval only when a limit is crossed (calls per round, estimated cost per round, a third attempt on one defect), when an item is a paid regeneration, or when an owner preference on file says ask first.

   ```
   Fix plan . [product] . MODE [A/B]
   1. [file]  EDIT       [change, region x,y,w,h]   [evidence]   ~$0.0X
   2. [file]  EDIT       [change, region x,y,w,h]   [evidence]   ~$0.0X
   3. [file]  REGENERATE [change] from this base    [evidence]   Genrupt, [runs: the owner named it / waits for a yes: Wonka proposed it]
   4. [file]  REFUSED    [change]            [rule broken / research it contradicts] -> [reroute]
   [n] edits, about $0.XX (estimate; the balance delta is the charge), inside the routine-fix limits. Running now.
   ```

5. **Write the surgical prompt.** It names ONE change and freezes everything else. One change per API call.
   - "Remove the red BEST SELLER ribbon from the top left corner. Change nothing else in the image."
   - A structure fix names the instance, the part and what the reference shows, never how the product looks in general (the words rule; the sheet carries the product): "On the LEFT fountain only, move the central column so it rises from the centre of the bowl and the base on one vertical axis, with all three tiers centred on it, exactly as in the reference sheet. Keep the right fountain, the text, the props and the background exactly as they are." The locked reference sheet goes in as the first image, the base second.
   - "Change the text 'HOLDS 4 LBS' to 'HOLDS 32 OZ'. Keep the exact same font, size, color, and position. Change nothing else."
   - **Any text a fix introduces must be true and sourced.** Check the new wording against the Reference Sheet, the brief, or the live listing, and write that source into the log. A shorter lie is still a lie.

   **The people-rescue pass runs on the Face Clinic's engine, never on a hand-rolled prompt.** When `/inspect` flags a people image with realism signatures (A doll face, B waxy skin, C filter glow), the fix is `/fix-faces` on that file: head boxes drawn and proven, the full frame sent to gpt-image at `high` (a face is always `high`, Jay, 6 September 2026), each face REPLACED by a new real one of the same casting, pose and position, and only the head boxes composited back through a feathered mask, so everything outside them is the original by construction. It runs conditionally: no signature flagged, no pass. Asking the model to "keep the same people and make them realistic" keeps the doll geometry and paints texture on it, which reads as a skin disease; that is why the Clinic replaces. Inside a round, run it with `--out edits/v[N]/[name].png` so the fixed file takes its canonical name in the snapshot this round opened (the engine opens its own round only when run standalone). A different pose or a different casting is a regeneration, not a face fix.

6. **Open the round folder BEFORE any render.** Find the highest existing `edits/vN`; this round is `edits/v[N+1]` (`edits/v1` if no round exists yet). Create it, then copy the ADOPTED SET into it, same filenames: every original in `images/` at its adopted version (the newest same-name copy from an earlier round when one exists, else the original), including assets generated after the last round, and no `-rejected` or `-render` file. Never copy the previous folder whole: on 9 September 2026 that opened a Day 6 round holding only the Day 5 main and none of the eight new secondaries. Write `round.md` in the folder listing each file and where it came from. **Open the round with `face_fix.open_round()`, not by hand**: it writes `round.md`, copies every class's adopted set in, and records `edits/vN/aplus/lineage.md` (which export the A+ files descend from); a round with no lineage record is never adopted while an export exists (reproduced 10 September 2026: a hand-opened round of one concept was served for the next concept because the filenames matched). If a round is ever opened any other way, write `lineage.md` explicitly (`[mode]: [face_fix.export_fingerprint()]`) before any file lands in it. When this round fixes an A+ module, finish by moving the chosen line in `aplus/aplus-plan.md` to this round: `face_fix.set_chosen_round(product, N)` rewrites `folder ...` to `edits/vN/aplus/`; without it the resolver keeps serving the round before the fix. The renders in the next step will replace only the files this round fixes.
   - The EDIT BASE for every item is its adopted copy: the newest round that holds `[name].png`, or `images/[name].png` when no round does (always the case on round 1, and for any asset generated after the last round). A file's name is its identity, `-v2` included: `sec-03-v2.png` is fixed as `sec-03-v2.png`, never as `sec-03.png`. Never edit off `images/` when a later version exists: that would silently discard earlier fixes.
   - A+ module images and variation imagery follow the same law. Their originals live write-once in `aplus/` and `variations/`; a round that fixes them copies that class's full current set into `edits/vN/aplus/` or `edits/vN/variations/` and replaces only the fixed files. The current set of a class is resolved the same way: each file's adopted copy in the newest round that holds it, else its originals folder.

7. **Run the edit on the OpenAI images.edit endpoint directly**, using the factory's image model (`gpt-image-2.5-sunburst` unless `WONKA_IMAGE_MODEL` in the `.env` names another; see CLAUDE.md, "Which image model"). **Quality depends on WHAT is being repaired, not on which room you are in:**
   - **A person's face is the thing being fixed: `high`.** Same rule and same reason as the Face Clinic, and if the repair is a face-realism pass, use `/fix-faces` and its engine rather than hand-rolling one here. Cheap pools, expensive repairs: this is one asset, already paid for, already known to be wrong, and faces are what a customer looks at hardest.
   - **Everything else: `low`.** Shortening text, removing an element, swapping a word or a colour, a structure fix. Low is the cheapest option and it preserves burned-in text well. **Quality is a variable, not a cure, and the one measurement on file says so:** on the sec-03 tower repair (7 September 2026) the same prompt was run at `low` and at `high`; `low` landed the column at about 1.4 percent off the axis and `high` at about 1.7 percent, so the dearer setting did not beat the cheap one. One case, recorded as evidence, never as doctrine: it does not make `low` better than `high`, it means the expensive setting does not solve a geometry problem by itself. Whether `medium` preserves text better has still never been measured; if someone measures it, record the numbers rather than assuming. Run from the kit root with full paths. The output path is the canonical filename INSIDE the new round folder, replacing the copy placed there in step 6:

   `quality` is `low` here; pass `high` whenever the edit touches a face.

   ```bash
   curl -s https://api.openai.com/v1/images/edits \
     -H "Authorization: Bearer $OPENAI_API_KEY" \
     -F model="${WONKA_IMAGE_MODEL:-gpt-image-2.5-sunburst}" \
     -F image="@factory/Products/[product]/edits/v[N-1]/[name].png" \
     -F prompt="[the surgical prompt]" \
     -F size="1024x1024" \
     -F quality="low" \
   | python3 -c '
   import sys, json, base64, pathlib
   r = json.load(sys.stdin)
   if "error" in r:
       sys.exit("EDIT FAILED, nothing written: " + str(r["error"].get("message", r["error"])))
   out = pathlib.Path(sys.argv[1])
   out.write_bytes(base64.b64decode(r["data"][0]["b64_json"]))
   print("wrote", out, out.stat().st_size, "bytes")
   ' "factory/Products/[product]/edits/v[N]/[name].png"
   ```

   **`size` is passed on purpose, and it costs resolution. Say so.** The edit endpoint returns a fixed working size, not the source's size, so an edited file usually comes back SMALLER than the Genrupt original it was built from. Set `size` to match the source's aspect ratio (`1024x1024` for a square listing image, the portrait or landscape option for a frame that is not square); leaving it out lets the API choose, and a portrait frame can return square with the composition cropped. The consequence travels: because a round copies the whole set forward, the edited files become the low-resolution members of an otherwise full-resolution set, and the MAIN image is the most exposed of all since MODE B refines the winner by design. That is not a reason to avoid editing, it is a reason to check. The Shipping Room reads every packaged file's real pixel size, reports it, and offers the Genrupt upscale before anything is uploaded.

   **A structure fix passes the reference sheet as well**: `-F image[]=@[reference sheet].png -F image[]=@[base].png`, sheet first, so the product's identity comes from the sheet and the base carries the scene. Read the endpoint's current schema for the multi-image form before typing it.

7b. **Composite the changed region back onto the base. Every render that was a LOCAL fix goes through this before verification.** The endpoint re-rendered the whole frame; only the region you asked to change is wanted from it. Measure the box on the base (source pixels, generous enough to hold the whole part and its shadow, never cutting through the object or through text), then:

   **The box rules (Jay, 9 September 2026, the same rules he uses by hand in the Genrupt editor):** a box never cuts through a person or an object; if the defect sits on a person, the box holds the whole person, and if it sits on a product, the whole product with its shadow and reflection. When the thing is cut, widen the box until it is whole, even if that makes the box most of the frame, because a seam through a body or a product reads as a defect worse than the one being fixed. Text is the same: the whole word, the whole line it sits on, never half a letter. On an A+ module the same rule crosses the strip: when the person or object continues into the neighbouring module, the box holds it across the seam, so the edit runs on the adjacent modules stacked together and the result is re-cut at the original boundaries (the joint fix in the A+ routing above). **Before spending, DRAW the boxes and show them:** `python3 .claude/skills/fix/composite_region.py --draw "[base].png" "[out]-boxes.png" x,y,w,h [...]` renders the boxes on a copy so the owner (or Wonka, on a Read) can see nothing is cut; the drawn copy is evidence in the round folder. The same drawn box, with its `x,y,w,h`, is what Wonka hands the owner when they prefer to make the edit themselves in the Genrupt app's region editor: Wonka marks WHERE, the owner clicks.

   ```bash
   python3 .claude/skills/fix/composite_region.py "[base].png" "[render].png" "[out in edits/vN]/[name].png" x,y,w,h [x2,y2,w2,h2] --feather 24
   ```

   The tool resizes the render to the base's size, pastes the boxes back with a feathered edge that runs INWARD (the soft edge lives inside the box, so no pixel outside the union of the boxes can change), and prints two numbers: pixels changed inside the region and pixels changed OUTSIDE it, which must be 0. Both counts are measured against the plain boxes as typed, never against the feathered mask, so the number is the contract and not an impression. The tool checks the boxes before it writes anything (inside the image, non-empty, twice the feather smaller than the box's short side) and exits with a plain message otherwise; fix the boxes, never accept the drift. The whole-frame render is kept beside it as `[name]-render.png` for the log. A people-rescue pass and a recolour that legitimately touch the whole frame skip this step and say so in the log.

   On round 1 the `-F image=` input is `images/[name].png`. The guard matters: the API error is checked BEFORE the output file is opened, so a refused or failed call leaves the copied-in parent file in place instead of an empty render pretending to be a fix. **If the "wrote ... bytes" line did not print, no new image exists** and the round folder still holds the unchanged copy. Never log that item as anything but FAILED.

7c. **The local retype: a second route for text-only defects, chosen when it suits the defect, never mandatory.** A wrong word, a typo or a shortened label on a flat or gently graded background does not always need a generative render: the Day 7 demonstration (10 September 2026) repaired an A+ footer by replacing the text locally after the generative route had failed on it twice, and the lesson is to choose the repair method that fits, not to repeat one route until it works. The route, and every step is a requirement:
   - **Check the installed fonts first** (`fc-list` on macOS and Linux, the Fonts folder on Windows) and pick the face and weight closest to the original; measure the original's cap height, x-height and letter spacing on a 3x crop and match them. Say in the log which font was used and whether it is the same face or an approximation. **Never present an approximate font as an exact match.** When nothing installed comes close, this route is out and the surgical prompt runs.
   - **Preserve the background.** Sample the background across the whole text box and carry its gradient through the patch (a linear fit across the box, or the untouched rows above and below stretched through it), never a flat rectangle of one colour. A patch that reads as a patch is a failed fix.
   - **Measure the replacement against its neighbours**: same baseline as the line it sits on, same colour as the surviving text on the module (sampled, not guessed), same size within a pixel.
   - **Composite by region like any edit** (7b): the box holds the whole word and the whole line it sits on, the drawn box is shown first, the count outside is 0.
   - **Inspect at display size AND at 3x.** Reject on any of: ghost letters (the old word showing through), horizontal streaks where the background was extended, a visible patch edge, a font that reads as a different face beside the surviving text. A rejection is a `-rejected` file per step 8, and the other route is next.
   The log entry names the route (`local retype`), the font and its match status, and the background method, beside the same hash, side-by-side and re-inspection lines as any edit.

7d. **The region route: a third lawful route, for SMALL elements, chosen first for them.** An icon, a label, an inset, a control panel, a parts-diagram detail that sits under about 200 pixels on the base is below what a whole-frame edit will redraw: the endpoint re-renders 1024 pixels of frame and an element that small comes back as it was (measured 14 September 2026 on the demo product: the PT04 FLOW icon, 176 by 176 pixels, survived two whole-frame edits on both children; the region edit landed it on both, first try, 0 pixels changed outside the box). The route: measure the box on the base by the box rules of 7b (the whole element with margin, never cutting through it), crop it, enlarge the crop to the endpoint's working size, edit THAT image with the same prompt and references, and composite it with `composite_region.py --region x,y,w,h` (the box's own numbers; the flag scales the render to the box's size and places it at x,y on a copy of the base before the 7b composite runs, so the count outside is 0). Never run the plain 7b line on a region render: without `--region` the tool stretches the small render to the whole base and the composite is silently wrong. Verify by 9 and re-inspect by 10 like any edit, at 3x and at display size. **It is an edit, not a new budget:** it counts as one attempt on that defect under the routine-fix policy's limits, it never resets the attempt counter, and it bypasses no approval a limit requires. On a variation frame, record the instruction correction it revealed in `variations-work/manifest.json` beside that frame's instruction as well (`/variations` step 7), so the next batch carries it. The log names the route (`region, enlarged`), the box and the scale.

8. **Rejected renders never take the canonical name.** If a render FAILS verification (next step), rename it to `[name]-rejected.png` (`-rejected-2` for a second failure) inside the round folder, then copy the parent version back in as `[name].png` so the snapshot stays whole. No later room can mistake a rejected file for a candidate, and the round folder is never missing a file. Two failed attempts on the same defect means Wonka proposes regeneration from this base (the policy's default limit); a further edit round runs only on the owner's explicit, bounded request (the companion page says so too), and the regeneration is a paid route that waits for one yes. The page builder, the adopted-set resolvers and the Face Clinic all skip evidence names (`-rejected`, `-render`, `-boxes`, `-faces-fixed`, `-fixN`, `seam-a-b-Nx`), so a rejected render can sit beside its parent without ever reaching a page or an upload set (fixed 10 September 2026: `-desktop-rejected` sorted before `-desktop.` and the stitched page showed the render the owner had thrown out).

   **Every attempt branches from the SAME accepted parent.** Attempt two is never an edit of attempt one's rejected render, and when the owner wants variants tested (a lower pour, a different angle, `high` beside `low`), every variant is made from the same accepted base, verified separately, and only one of them is promoted; the others are renamed `-rejected-[n]` with the reason. Chaining an edit onto a rejected edit compounds the drift the first one already had, and it hides which change actually worked.

   **Creative permission, asked only when attempt two needs freedom the owner has not given.** A second attempt inside the same region and the routine bounds runs without a stop. A frozen-whole-frame prompt ("move the column, change nothing else") often cannot move ONE object independently: the model re-renders the frame and the fix comes back partial with the surroundings drifted (measured 7 September 2026: attempt one moved the tower from about ten percent off the axis to about six and shifted the framing, and was rejected). Before the second cheap attempt, ask the owner ONE question: will they allow limited drift in the surrounding composition (the pour, the angle, the props nearest the part) so the part can be placed correctly? With that permission stated, the second prompt names the freedom explicitly and the composite still keeps everything outside the region byte-identical. What is recorded is the PRINCIPLE (ask for bounded composition freedom when a frozen frame cannot move one object), never a recipe like "a lower pour fixes geometry": that was one frame's answer.

9. **Verify: first the hash, then the eyes.**

   **The hash check runs BEFORE any looking.** Compare a checksum of the edit base against the new render:

   ```bash
   md5 -q "[edit base].png" "[new render].png"                                                        # macOS
   python3 -c "import hashlib,sys; print(*[hashlib.md5(open(p,'rb').read()).hexdigest() for p in sys.argv[1:]], sep='\n')" "[edit base].png" "[new render].png"   # anywhere
   ```

   **Identical hashes mean the edit silently FAILED**: the API returned the input unchanged, or the output path never actually replaced the step-6 copy, and the render "success" line was telling the truth about bytes while lying about work. Eyes are the wrong tool for catching this, because a person shown two identical images politely finds the difference they were told to expect. Identical = treat exactly like a failed render: rename per step 8, retry once with a tighter prompt or route to regeneration. Record both short hashes in the log entry either way.

   **Then verify side by side, against the true original.** Open the new render in `edits/vN` AND the `images/` original with Read and compare deliberately. For a file that was already fixed in an earlier round (a chained edit), ALSO open the immediate parent in `edits/v[N-1]`, because each re-render drifts a little and the drift compounds where a single-step check cannot see it. Check four things:
   - (a) the requested change actually happened,
   - (b) every other piece of text still reads exactly as before, transcribed word for word, not glanced at,
   - (c) the product is untouched: label, material, colors, and part count (a four tier machine still shows four tiers),
   - (d) nothing new appeared anywhere in the frame,
   - (e) for a composited fix: the seam is clean at 3x (`python3 .claude/skills/inspect/magnify.py [out] [dir] x,y,w,h` on the box, and the same box on the base beside it), and the defect is gone on the magnified crop, not only at full size; the other instance of the product, if any, is compared on the same strip.
   Anything else changed means the edit FAILED. Rename it rejected per step 8, restore the parent copy, log it, and either retry ONCE with a tighter prompt or route it to regeneration.

10. **Re-inspect mechanically. Nothing is fixed because it feels fixed.** Write a real 160px copy of the fixed file to `scorecards/squint/`, named with the round so no squint copy shadows another, and READ that copy, then re-run the compliance gate and the six scores per the Inspection Room. A fix to a gallery frame also re-runs the listing set-level checks, because a change to one frame can duplicate another frame's message. **An A+ module inherits the Inspection Room's display-width rule (its step 4):** the 160 copy reads the headline hierarchy only, and the verdict on body text comes from a second copy at the module's real display width (Amazon's desktop column, or phone width for mobile), read in the assembled page. A+ body text is never failed, and never sent for regeneration, because it is unreadable at 160; name the deciding read in the log.

   ```bash
   mkdir -p "factory/Products/[product]/scorecards/squint"
   sips --resampleWidth 160 "factory/Products/[product]/edits/v[N]/[name].png" --out "factory/Products/[product]/scorecards/squint/[name]-v[N]-160.png"   # macOS
   magick "[in].png" -resize 160x "[out]-160.png"                                                                                                        # Windows / ImageMagick
   python3 -c "from PIL import Image; im=Image.open('[in].png'); im.resize((160, round(im.height*160/im.width))).save('[out]-160.png')"                  # anywhere with Pillow
   ```

   A fix that passes replaces its parent in the slot ranking. Update the current scorecard. A fix that fails the gate is not a fix.

11. **Log the round** in `edits/fixes-log.md` (create `edits/` and the log on the first round). Append, never overwrite. Every round gets a header stating the round folder, the base it was copied from, and which files were fixed versus copied. Every item gets its own entry: edits, regenerate routings, refusals, and blocked items alike.

12. **Hand off.**
    - **MODE A:** back to `/inspect` for the updated scorecard, then the human picks from gate-passed candidates only.
    - **MODE B:** the refined files go back to `/inspect`, and the set is then final on the owner's word. A second synthetic sitting is optional and rarely worth it; the real second opinion is Amazon's own A/B. **The refined winner keeps its Round 1 candidate id in the Round 2 config**, even though the file now lives in `edits/v[N]`. Change the id and the round-over-round delta, which is the only number that says whether the fix worked, cannot line up.

## Output format

`edits/fixes-log.md`, one round header plus one entry per item, appended:

```markdown
# Round v[N] . [YYYY-MM-DD HH:MM] . MODE [A/B]
- Copied from: [edits/v[N-1] / images/ (first round)]
- Fixed this round: [file, file]
- Copied unchanged: [count] files
- Round cost: ~$[X.XX] estimated across [n] edits, [charge from the balance delta when read]. Policy limits: [n]/12 calls, ~$[X.XX]/$3.00, no defect past 2 attempts [or: STOPPED at [limit], approved by the owner at [time]]. Running product total: ~$[X.XX]

## [name].png
- Target: [the flagged image / the main race WINNER / the weakest gallery frame / the image the owner named]
- Defect or request: [what was wrong or wanted]
- Evidence: [MODE A: scorecard flag, dimension and element / MODE B: the exact note, verbatim, and the taster count]
- Route: [EDIT / REGENERATE, sent to /[room] with the exact brief sentence / REFUSED: which rule or which research finding, and where it was rerouted / BLOCKED: what is missing]
- Edit base: [edits/v[N-1]/[name].png / images/[name].png]
- Prompt: "[the exact surgical prompt]"
- New wording source: [Reference Sheet / brief / live listing / owner-confirmed. n-a if no text changed]
- Region: [x,y,w,h on the base / whole frame (people pass or recolour)] . composite: [inside [n] px, outside 0 / n-a]
- Result: [SUCCESS, [n] bytes written / FAILED: what else broke -> renamed [name]-rejected.png, parent copy restored]
- Attempt: [1 of 2 / 2 of 2 -> next route is regeneration from this base / 3, owner-requested] . route: [whole frame / region, enlarged [box, scale] / local retype]
- Hash check: [base [first 8 chars] vs new [first 8 chars], differ / IDENTICAL -> silent failure, treated as FAILED]
- Side-by-side check: [change OK vs the images/ original (and vs the v[N-1] parent for a chained edit), other text transcribed and intact, product and part count intact, nothing new]
- Re-inspection: squint [PASS/FAIL] at 160px (an A+ module: headline read at 160, body text at display width [PASS/FAIL], the deciding read named), compliance [PASS/FAIL], scores [summary]
- Cost: ~$[0.0X]
```

## Golden Standards check

Before presenting, verify:
- [ ] The mode is stated. MODE B targeted what the owner named (typically the winner and/or the flagged frame), never a losing main candidate, and each edit cites its note and count as evidence.
- [ ] The three-mention bar was applied only to Wonka's own proposals; a run where the owner named no change made NO edits and logged `no change named, no refinement`.
- [ ] The refusal gate ran on every item. Every refusal names the rule it would break or the research it contradicts, plus where the message was rerouted.
- [ ] The routing table was applied BEFORE any edit: the chosen image was fixed first, no defect got a third edit without the owner's bounded request (logged as owner-requested), every regenerate item left with THIS file named as its base and the exact sentence its tighter brief must contain, and no owner-reported defect was answered with an offer of a different image.
- [ ] Every edit prompt names one change and ends with an explicit "change nothing else".
- [ ] Every word a fix put on an image is true and its source is named in the log.
- [ ] The full list was announced with ONE estimate line and checked against the routine-fix policy's limits; inside them it ran on the report, and a crossed limit or a paid regeneration stopped once for one approval, never per item.
- [ ] Every local fix went through `composite_region.py` with 0 pixels changed outside its boxes, the seam was read at 3x, and the whole-frame render was kept beside it.
- [ ] `images/` (and `aplus/`, `variations/`) are untouched: nothing there was written, renamed, or deleted.
- [ ] The round folder `edits/vN` holds the COMPLETE current set: new renders for the fixed files, unchanged copies of every other file, same filenames throughout. Nothing downstream needs a second folder.
- [ ] Every edit ran off the file's adopted copy (the newest round holding it, or the `images/` original for a frame no round has touched), never off a stale version.
- [ ] Failed renders are renamed `[name]-rejected.png` inside the round folder and the parent copy was restored as `[name].png`, so no later room can pick a reject and no file is missing.
- [ ] Every attempt and every variant branched from the same accepted parent, never from a rejected render; between attempt one and two on a spatial defect the owner was asked once about bounded composition freedom, and the answer is in the log.
- [ ] An owner-led item (no scorecard) was accepted as a first-class MODE A source, logged `list source: owner`, and run through the same gate, routing and verification.
- [ ] The hash check ran on every render BEFORE the visual compare, both short hashes are in the log, and an identical pair was treated as a failed edit, never as a subtle success.
- [ ] The `images/` original and the fix were both opened (plus the `v[N-1]` parent for chained edits), other on-image text was transcribed and confirmed, and the product part count was counted, not assumed.
- [ ] Every fixed image has a round-named 160px squint copy on disk and passed the compliance gate. No full-size legibility judgments. An A+ module's body text was judged at its display width in the assembled page, never failed at 160.
- [ ] Every item is in `edits/fixes-log.md` under its round header: edits, routings, refusals, and blocked items.
- [ ] All output is English with zero em or en dashes.

## Troubleshooting

- **"wrote ... bytes" never printed:** no file was written. Read the error the guard printed. Nothing is logged as SUCCESS.
- **A verification or organization error from the API:** the OpenAI organization needs its one-time verification at platform.openai.com. See `guides/mcp-setup-guide.md`. The room parks as blocked, the routing still runs.
- **The API refuses the prompt on content policy:** almost always a face, a person, or a third-party logo in the instruction. Rewrite the prompt to name only the region and the change, or route it to regeneration.
- **The fix landed but something across the frame broke:** that defect was regenerate territory. Rename the output rejected, restore the parent copy so the round folder stays whole, and send it to the ovens with a tighter brief.
- **The hashes came back identical:** the API returned the input unchanged (it happens, quietly). Nothing was fixed no matter how the render looks. Retry once with a more explicit prompt naming the exact region; a second identical pair routes to regeneration.
- **`sips` not found (Windows):** use the ImageMagick or Pillow line in step 10. Missing Pillow: `python3 -m pip install pillow`.
- **The same defect failed twice:** stop editing. Two failures is the policy's attempts limit: the next route is a regeneration from this file as the base, which waits for one yes. Not a different image. The one third edit worth proposing beside it: a SMALL element that failed twice as a whole-frame edit takes the region route (7d), on the owner's word, logged as owner-requested; and next time an element that size goes to the region route first. An owner's "regenerate" on an element under about 200 px is met by regenerating the REGION (7d), said back to them in those words: "I will regenerate the region, the [element] on its own crop, and composite it back."
- **`composite_region.py` reports pixels changed outside the boxes:** the render came back at a different size or the box is off. The tool already resized; re-measure the box on the base, and never widen the feather to hide drift.
- **The owner says "just find another one":** that is the owner asking for an alternative, which is lawful. Say in one line what the fix would have cost and offer both; do not decide for them.

## Wonka lines

Openers:
- "To the Fixing Room. Small tools, steady hands, and absolutely no improvising."
- "One flaw, one scalpel. We do not repaint the whole candy to fix a smudge."
- "Bring the patient in. And bring the original. We never operate without it."

Closers:
- "Fixed, verified, and the original sleeps safely in images/, untouched as always. Back to the Inspection belt."
- "One new round folder, the whole set inside it, nothing scattered. That is how a factory keeps its shelves."
- "Two cents of surgery and the candy is whole. I do enjoy a bargain."
- "That one needs the ovens, not the scalpel. Off to the generation rooms with a stricter brief, and your pick goes in as the base."
- "Two tries is my limit on one wound. The ovens get it next, built from this very frame. I do not go shopping for a different candy."
- "No. Not on a main image, not for anyone. The message is welcome. It moves to the gallery, where it is legal."
- "A hundred tasters asked for a lie, and a hundred reviewers already paid for it. Noted, and refused."
- "The tasters told us what to sharpen, and we sharpened exactly that. Another taste only if you ask for one."

## Definition of Done

A run is done in one of two lawful shapes, and both end with the log on disk.

**Shape one, edits ran:**
- A new round folder `edits/vN` exists and holds the ENTIRE current set: the fixed files as new renders, every other file copied in from its adopted copy, same filenames, and `round.md` names each file's source. Every failed attempt inside it is renamed `[name]-rejected.png` with its parent copy restored.
- `images/` (and `aplus/`, `variations/`) are exactly as they were before the round. Write-once means write-once.
- Every fix was verified side by side against the `images/` original (and the `v[N-1]` parent for chained edits) and re-inspected, with its round-named 160px squint copy on disk (an A+ module: plus the display-width read of its body text in the assembled page).
- `edits/fixes-log.md` holds the round header plus a complete entry per item, including the running cost total.

**Shape two, no edit ran** (everything routed, refused, or blocked):
- NO new round folder is opened. A `vN` exists only when a render landed in it.
- `edits/fixes-log.md` still holds an entry per item with its route or refusal reason. A routing-only run is a real result and it is never dressed up as an edit.

In both shapes:
- Every REGENERATE item left with the current file named as its base and the exact sentence its tighter brief must contain, addressed to a named room.
- The report to the owner says, per file, found / fixed / open, with before and after attached. A round never closes as "nothing flagged" with a factual defect still open on a file in scope.
- MODE B: each change is tied to a note and its taster count, the refined winner keeps its original candidate id, the set goes back to `/inspect` and is then final on the owner's word, and a challenger is built with `/main-image` only when the owner wants one.

## Update status.md

Add a Log line: `[date] Fixing Room (MODE [A/B]): round v[N], [n] edits on [files], [n] routed to regeneration, [n] refused, ~$[X.XX] spent. Current set: edits/v[N]. See edits/fixes-log.md.`

MODE A: INSPECT stays `in progress` until the re-inspection passes, then it follows the Inspection Room's status. MODE B: PROVE stays `in progress`, and the refined winner plus the refined frame go back to `/inspect`; the set is final on the owner's word, recorded by the Tasting Room's close as an `Owner decision:` line. That line completes Day 8 and opens nothing: Day 9 (variations) is next, and `/ready-to-upload` runs on the owner's ask or their yes to "Ready for the Shipping Room?" after that, labelling these files `revised after test`. An explicit stop from the owner ends the session on a `Next stage:` line in `status.md`, with no skill invoked after it. Another comparison in `/tasting-room` only when the owner asks a concrete question, such as whether a change big enough to be a different image beats the raced original.

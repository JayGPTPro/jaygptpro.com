"""Offline tests for the Variations Room's code (kit v40, 12 September 2026).

No API key, no network, no image generation: the OpenAI client is stubbed before
`variations_run.py` is imported, and every image is a tiny PNG made here.

What is pinned:
  * `--frames MAIN,PT02` restricts the job list to those frames
  * `--dry-run` prints the estimate and the call count, and the restriction
  * the spend cap refuses above and allows below, before any call
  * `resolve_source()` picks the newest edits/vN copy and never an evidence file
  * `variations_land.land()` files a real child flat and a concept child under
    `variations/concepts/[child]/` with `-concept` in every name and a CONCEPT.md
  * `variations_intake.map_uploads()` turns three views of one colour into ONE
    child, three colours into three, and asks ONE question when it cannot tell
  * `variations_qa.py --ref` renders the reference as a third tile

Watched to fail against kit v39 (no --frames, no cap, no land/intake helpers,
no --ref) before the code was written.

Run: python3 test_variations_run.py
"""
import importlib.util
import io
import json
import sys
import tempfile
import types
from contextlib import redirect_stdout
from pathlib import Path

try:
    from PIL import Image
except ImportError:
    raise SystemExit("Pillow is not installed. Run: python3 -m pip install pillow")

HERE = Path(__file__).parent

# Stub the OpenAI client BEFORE the script is imported: a test that can reach the
# real client is a test that can spend money by accident.
_stub = types.ModuleType("openai")


class _NoClient:
    def __init__(self, *a, **k):
        raise AssertionError("the test tried to build a real OpenAI client")


_stub.OpenAI = _NoClient
sys.modules["openai"] = _stub


def _load(name):
    spec = importlib.util.spec_from_file_location(name, HERE / f"{name}.py")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


FAILURES = []


def check(name, cond, detail=""):
    print(("  PASS  " if cond else "  FAIL  ") + name + ("" if cond else "  " + detail))
    if not cond:
        FAILURES.append(name)


def png(path, size=(40, 50), colour=(250, 250, 250)):
    path.parent.mkdir(parents=True, exist_ok=True)
    Image.new("RGB", size, colour).save(path)
    return path


def make_work(root):
    """A variations-work/ folder with a two-child manifest and tiny frames."""
    work = root / "variations-work"
    for f in ("MAIN.png", "PT01.png", "PT02.png"):
        png(work / "source" / f)
    png(work / "refs" / "round.png")
    man = {
        "product": "test", "hero_frame": "MAIN",
        "frames": {"MAIN": "MAIN.png", "PT01": "PT01.png", "PT02": "PT02.png"},
        "shape_refs": {"round": "round.png"},
        "shape_prompts": {"round": "make it round"},
        "children": [
            {"child": "round-10in", "shape_ref": "round",
             "frames": {"MAIN": {"shape": True}, "PT01": {"shape": True}, "PT02": {"shape": True}}},
            {"child": "square-8set", "shape_ref": None,
             "frames": {"MAIN": {"text": "8"}, "PT01": {"text": "8"}}},
        ],
    }
    (work / "manifest.json").write_text(json.dumps(man))
    return work


def run_main(vr, argv):
    """Run variations_run.main() with argv, capturing stdout and SystemExit."""
    sys.argv = ["variations_run.py"] + argv
    buf = io.StringIO()
    code = 0
    with redirect_stdout(buf):
        try:
            vr.main()
        except SystemExit as e:
            code = e.code
        except Exception as e:  # noqa: BLE001  a crash is a result too, never a dead test run
            code = "CRASH " + repr(e)
    return code, buf.getvalue()


print("variations room, kit v40")

try:
    vr = _load("variations_run")
except Exception as e:  # noqa: BLE001
    check("variations_run.py imports with the OpenAI client stubbed", False, repr(e))
    vr = None

if vr:
    with tempfile.TemporaryDirectory() as d:
        root = Path(d)
        work = make_work(root)
        man = json.loads((work / "manifest.json").read_text())

        # ---- --frames restricts the job list --------------------------------
        check("build_jobs takes a frames filter", "frames" in vr.build_jobs.__code__.co_varnames,
              "build_jobs(man, root, only) has no frames parameter")
        try:
            chains = vr.build_jobs(man, work, None, frames={"MAIN", "PT02"})
            names = sorted({c[1] for c in chains})
            check("--frames MAIN,PT02 keeps only those frames", names == ["MAIN", "PT02"], str(names))
            check("  ... and drops a child's frame that is not selected",
                  all(c[1] != "PT01" for c in chains))
        except TypeError as e:
            check("--frames MAIN,PT02 keeps only those frames", False, repr(e))

        # ---- the estimate, dated ------------------------------------------------
        check("PRICE_PER_CALL_USD exists and is dated September 2026",
              "September 2026" in str(getattr(vr, "PRICE_PER_CALL_USD", {}).get("_as_of", "")),
              str(getattr(vr, "PRICE_PER_CALL_USD", None)))
        check("SPEND_CAP_DEFAULT_USD is 10.0", getattr(vr, "SPEND_CAP_DEFAULT_USD", None) == 10.0)
        if hasattr(vr, "estimate_cost"):
            all_chains = vr.build_jobs(man, work, None)
            est = vr.estimate_cost(all_chains, "low")
            # the fixture frames are 40x50, a 4:5 source: padded, so each of the 5 steps
            # counts twice (the edge-contact retry is a paid call, review 13.9)
            check("estimate_cost counts every call, twice on a padded source", est["calls"] == 10, str(est))
            check("estimate_cost prices calls x price", abs(est["usd"] - 10 * vr.PRICE_PER_CALL_USD["low"]) < 1e-9, str(est))
            check("a higher quality estimates dearer",
                  vr.estimate_cost(all_chains, "high")["usd"] > est["usd"])
        else:
            check("estimate_cost exists", False)

        # ---- the cap ---------------------------------------------------------------
        if hasattr(vr, "cap_check"):
            ok, line = vr.cap_check(0.25, 10.0)
            check("cap_check allows below the cap", ok and "cap $10" in line, line)
            ok, line = vr.cap_check(12.5, 10.0)
            check("cap_check refuses above the cap", not ok and "above" in line, line)
        else:
            check("cap_check exists", False)

        # ---- --dry-run prints the estimate, the count and the restriction --------
        code, out = run_main(vr, [str(work / "manifest.json"), "--dry-run", "--frames", "MAIN,PT02"])
        check("--dry-run exits clean", code == 0, f"exit {code}: {out[-300:]}")
        check("--dry-run prints the call count (3 padded steps = 6 calls)", "6 edit calls" in out, out)
        check("--dry-run prints the estimate line", "about $" in out and "cap $10" in out, out)
        check("--dry-run prints the frames restriction", "frames restricted to MAIN, PT02" in out, out)
        check("--dry-run never builds a client", "real OpenAI client" not in out)

        # ---- the cap refuses before any call, --cap and spend_cap_usd both work ---
        code, out = run_main(vr, [str(work / "manifest.json"), "--cap", "0.001"])
        check("--cap below the estimate refuses before any call",
              code not in (0, None) and "SPEND CAP" in str(out) + str(code), f"exit {code}: {out}")
        man2 = dict(man, spend_cap_usd=0.001)
        (work / "manifest-capped.json").write_text(json.dumps(man2))
        code, out = run_main(vr, [str(work / "manifest-capped.json")])
        check("spend_cap_usd in the manifest refuses the same way",
              code not in (0, None) and "SPEND CAP" in str(out) + str(code), f"exit {code}: {out}")
        code, out = run_main(vr, [str(work / "manifest.json"), "--cap", "0.001", "--dry-run"])
        check("--dry-run above the cap still prints, and says it is above",
              "above" in out, out)

        # ---- resolve_source: newest edits/vN copy, never evidence ---------------
        prod = root / "product"
        png(prod / "images" / "main-01.png")
        png(prod / "edits" / "v1" / "main-01.png")
        png(prod / "edits" / "v2" / "main-01.png")
        png(prod / "edits" / "v2" / "main-01-rejected.png")
        png(prod / "edits" / "v2" / "_chk_main-01.png")
        png(prod / "images" / "sec-03.png")
        if hasattr(vr, "resolve_source"):
            check("resolve_source picks the newest edits round",
                  vr.resolve_source(prod, "main-01.png") == prod / "edits" / "v2" / "main-01.png",
                  str(vr.resolve_source(prod, "main-01.png")))
            check("resolve_source falls back to images/ when no round holds the file",
                  vr.resolve_source(prod, "sec-03.png") == prod / "images" / "sec-03.png")
            refused = False
            try:
                vr.resolve_source(prod, "main-01-rejected.png")
            except ValueError:
                refused = True
            check("resolve_source refuses an evidence file", refused)
            refused = False
            try:
                vr.resolve_source(prod, "_chk_main-01.png")
            except ValueError:
                refused = True
            check("resolve_source refuses an underscore diagnostic", refused)
        else:
            check("resolve_source exists", False)

# ---- adversarial review fixes (13 September 2026) ----------------------------------
if vr:
    with tempfile.TemporaryDirectory() as d:
        root = Path(d)
        work = make_work(root)
        man = json.loads((work / "manifest.json").read_text())

        # MAJOR 3: a shape child with no shape reference refuses before any spend
        man3 = json.loads(json.dumps(man))
        man3["children"][0]["shape_ref"] = None
        (work / "manifest-noref.json").write_text(json.dumps(man3))
        code, out = run_main(vr, [str(work / "manifest-noref.json"), "--dry-run"])
        check("a shape child with shape_ref null refuses plainly, no KeyError",
              isinstance(code, str) and "shape reference" in code and "Nothing ran" in code,
              f"exit {code!r}: {out[-200:]}")

        # MAJOR 5: --frames with an empty value refuses
        code, out = run_main(vr, [str(work / "manifest.json"), "--dry-run", "--frames", ""])
        check("--frames \"\" refuses instead of running everything",
              isinstance(code, str) and "--frames" in code and "empty" in code and "Nothing ran" in code,
              f"exit {code!r}: {out[-200:]}")

        # MAJOR 6: a padded (non-square) source counts as 2 calls per step in the estimate
        sq = root / "sq"
        for f in ("MAIN.png", "PT01.png", "PT02.png"):
            png(sq / "variations-work" / "source" / f, size=(40, 40))
        png(sq / "variations-work" / "refs" / "round.png", size=(40, 40))
        (sq / "variations-work" / "manifest.json").write_text(json.dumps(man))
        chains_sq = vr.build_jobs(man, sq / "variations-work", None)
        chains_45 = vr.build_jobs(man, work, None)   # make_work frames are 40x50, a 4:5 source
        est_sq = vr.estimate_cost(chains_sq, "low")
        est_45 = vr.estimate_cost(chains_45, "low")
        check("a 4:5 source estimates double a square one (the edge-contact retry is a paid call)",
              est_45["calls"] == 2 * est_sq["calls"] and est_45["usd"] == round(2 * est_sq["usd"], 2),
              f"square {est_sq}, 4:5 {est_45}")

        # MINOR 17: the estimate skips frames already on disk unless --force
        png(sq / "variations-work" / "working" / "square-8set" / "MAIN.png", size=(40, 40))
        est_skip = vr.estimate_cost(chains_sq, "low")
        try:
            est_force = vr.estimate_cost(chains_sq, "low", force=True)
        except TypeError as e:
            est_force = {"calls": repr(e)}
        check("the estimate skips a frame already on disk",
              est_skip["calls"] == est_sq["calls"] - 1, f"was {est_sq}, now {est_skip}")
        check("  ... and --force counts it again", est_force["calls"] == est_sq["calls"], str(est_force))

        # MAJOR 4: resolve_source takes a stem, newest edits/vN first, and refuses a -2048 upscale
        prod = root / "product"
        png(prod / "images" / "main-13.png")
        png(prod / "edits" / "v8" / "main-13.png")
        png(prod / "edits" / "v8" / "main-13-2048.png")
        png(prod / "images" / "sec-03.jpg")
        try:
            got = vr.resolve_source(prod, "main-13")
            check("resolve_source resolves a stem to edits/v8/main-13.png",
                  got == prod / "edits" / "v8" / "main-13.png", str(got))
        except Exception as e:  # noqa: BLE001
            check("resolve_source resolves a stem to edits/v8/main-13.png", False, repr(e))
        try:
            got = vr.resolve_source(prod, "sec-03")
            check("  ... and a stem in images/ only, any image extension",
                  got == prod / "images" / "sec-03.jpg", str(got))
        except Exception as e:  # noqa: BLE001
            check("  ... and a stem in images/ only, any image extension", False, repr(e))
        refused = False
        try:
            vr.resolve_source(prod, "main-13-2048")
        except ValueError:
            refused = True
        except Exception as e:  # noqa: BLE001
            refused = repr(e)
        check("resolve_source refuses a -2048 upscale copy as evidence (ValueError)", refused is True, str(refused))

        # MAJOR 4: --source-from fills source/ from the product folder, copy never move
        man4 = json.loads(json.dumps(man))
        man4["frames"] = {"MAIN": "main-13", "PT01": "sec-03", "PT02": "PT02.png"}
        man4["children"][0]["frames"].pop("PT02")
        man4["children"][1]["frames"] = {"MAIN": {"text": "8"}}
        w4 = root / "w4" / "variations-work"
        w4.mkdir(parents=True)
        png(prod / "images" / "PT02.png")
        png(w4 / "refs" / "round.png")
        (w4 / "manifest.json").write_text(json.dumps(man4))
        code, out = run_main(vr, [str(w4 / "manifest.json"), "--dry-run", "--source-from", str(prod)])
        check("--source-from fills source/ through resolve_source and the dry run goes on",
              code == 0 and (w4 / "source" / "main-13.png").is_file() and (w4 / "source" / "sec-03.jpg").is_file(),
              f"exit {code!r}: {out[-400:]}")
        check("  ... the product copy is still there (copied, never moved)",
              (prod / "edits" / "v8" / "main-13.png").is_file())
        check("  ... and every resolved path is printed",
              "edits/v8/main-13.png" in out.replace("\\", "/"), out[-400:])
        man5 = json.loads(json.dumps(man4))
        man5["frames"]["MAIN"] = "main-13-2048"
        (w4 / "manifest-ev.json").write_text(json.dumps(man5))
        code, out = run_main(vr, [str(w4 / "manifest-ev.json"), "--dry-run"])
        check("an evidence or upscale name in the manifest frames refuses even without --source-from",
              isinstance(code, str) and "main-13-2048" in code, f"exit {code!r}: {out[-200:]}")

# ---- the landing helper ------------------------------------------------------------
try:
    vl = _load("variations_land")
except Exception as e:  # noqa: BLE001
    check("variations_land.py exists", False, repr(e))
    vl = None

if vl:
    with tempfile.TemporaryDirectory() as d:
        prod = Path(d) / "product"
        work = prod / "variations-work" / "working"
        png(work / "round-10in" / "MAIN.png")
        png(work / "round-10in" / "PT03.png")
        png(work / "onyx" / "MAIN.png")
        png(work / "onyx" / "SWATCH.png")
        landed = vl.land(prod, "round-10in", "real",
                         {"MAIN": work / "round-10in" / "MAIN.png", "PT03": work / "round-10in" / "PT03.png"})
        paths = [str(p.relative_to(prod)) for p in landed]
        check("a real child lands flat in variations/ with the child name",
              paths == ["variations/main-round-10in.png", "variations/pt03-round-10in.png"], str(paths))
        landed = vl.land(prod, "onyx", "concept",
                         {"MAIN": work / "onyx" / "MAIN.png", "SWATCH": work / "onyx" / "SWATCH.png"})
        paths = [str(p.relative_to(prod)) for p in landed]
        check("a concept child lands under variations/concepts/[child]/",
              all(p.startswith("variations/concepts/onyx/") for p in paths), str(paths))
        check("  ... with -concept in every filename",
              all("-concept" in Path(p).name for p in paths), str(paths))
        check("  ... named main-onyx-concept.png and swatch-onyx-concept.png",
              sorted(Path(p).name for p in paths) == ["main-onyx-concept.png", "swatch-onyx-concept.png"], str(paths))
        cmd = prod / "variations" / "concepts" / "onyx" / "CONCEPT.md"
        check("  ... and a CONCEPT.md one-liner sits in the folder",
              cmd.exists() and "possible product" in cmd.read_text(), str(cmd))
        # write-once: a second landing sits beside the first
        again = vl.land(prod, "round-10in", "real", {"MAIN": work / "round-10in" / "MAIN.png"})
        check("landing the same child again writes -v2 beside the untouched first file",
              again[0].name == "main-round-10in-v2.png" and (prod / "variations" / "main-round-10in.png").exists(),
              str(again))
        check("the working copy is untouched", (work / "round-10in" / "MAIN.png").exists())
        png(work / "aqua" / "MAIN.jpg")
        got = vl.land(prod, "aqua", "real", {"MAIN": work / "aqua" / "MAIN.jpg"})
        check("a .jpg source lands as .jpg (the suffix is kept)", got[0].name == "main-aqua.jpg", str(got))
        if hasattr(vl, "plan_lines"):
            lines = vl.plan_lines(prod)
            check("plan_lines lists every output path with its status",
                  any("variations/main-round-10in.png" in ln and "real" in ln for ln in lines)
                  and any("concepts/onyx/main-onyx-concept.png" in ln and "concept" in ln for ln in lines),
                  "\n".join(lines))
        else:
            check("plan_lines exists", False)

# ---- the intake helper ---------------------------------------------------------------
try:
    vi = _load("variations_intake")
except Exception as e:  # noqa: BLE001
    check("variations_intake.py exists", False, repr(e))
    vi = None

if vi:
    r = vi.map_uploads(["black-front.jpg", "black-side.jpg", "black-back.jpg"], "here is the black one")
    check("three views of one colour map to ONE child",
          "children" in r and len(r["children"]) == 1, str(r))
    if r.get("children"):
        c = r["children"][0]
        check("  ... named after the colour, source uploaded, three files",
              c["child"] == "black" and c["source"] == "uploaded" and len(c["files"]) == 3, str(c))
    r = vi.map_uploads(["red.jpg", "white.jpg", "black.jpg"], "three colours")
    check("three colours map to THREE children",
          "children" in r and sorted(c["child"] for c in r["children"]) == ["black", "red", "white"], str(r))
    r = vi.map_uploads(["IMG_2201.jpg", "IMG_2202.jpg", "IMG_2203.jpg"], "")
    check("three unnamed files with no words yield ONE question, not a guess",
          "question" in r and "children" not in r, str(r))
    if "question" in r:
        check("  ... and the question is the neutral one: three variants, or three views of one?",
              "three variants" in r["question"].lower() and "three views of one" in r["question"].lower(), r["question"])
    r = vi.map_uploads(["IMG_2201.jpg", "IMG_2202.jpg", "IMG_2203.jpg"], "three angles of the red one")
    check("the owner's words settle unnamed files: angles of one colour = one child",
          "children" in r and len(r["children"]) == 1 and r["children"][0]["child"] == "red", str(r))
    r = vi.map_uploads(["IMG_2201.jpg", "IMG_2202.jpg", "IMG_2203.jpg"], "red, white and black")
    check("three colours named for three camera-numbered files is a QUESTION, never a mapping by position",
          "question" in r and "which file is which colour, in order" in r["question"].lower(), str(r))
    if hasattr(vi, "children_from_sentence"):
        kids = vi.children_from_sentence("make this in black, white and red", known=("stainless", "black"))
        check("a sentence yields children; a colour the reference never showed is a concept",
              [(k["child"], k["status"]) for k in kids] == [("black", "real"), ("white", "concept"), ("red", "concept")],
              str(kids))
        check("  ... every one is source: described", all(k["source"] == "described" for k in kids))
        # BLOCKER 2: a finish word is a modifier of the next colour, never a child
        kids = vi.children_from_sentence("make this in matte black and glossy white", known=())
        check("'matte black' is ONE child, slug matte-black, label 'matte black'",
              [(k["child"], k["label"]) for k in kids] == [("matte-black", "matte black"), ("glossy-white", "glossy white")],
              str(kids))
        check("  ... and no bare 'matte' child exists", all(k["child"] != "matte" for k in kids))
        # MAJOR 8: no colour in the sentence is a question, not an empty list
        r = vi.children_from_sentence("the 5-tier model and a 2-pack")
        check("a sentence with no colour returns the one question",
              isinstance(r, dict) and "question" in r and "no colour" in r["question"].lower(), str(r))
    else:
        check("children_from_sentence exists", False)
    # MAJOR 10: a non-colour, non-view token stays in the slug and the label
    r = vi.map_uploads(["stainless-cascading.jpg"], "")
    check("stainless-cascading.jpg maps to child stainless-cascading, not stainless",
          "children" in r and r["children"][0]["child"] == "stainless-cascading"
          and r["children"][0]["label"] == "stainless cascading", str(r))
    r = vi.map_uploads(["stainless-cascading-front.jpg", "stainless-cascading-side.jpg"], "")
    check("  ... two views of it are still ONE child", "children" in r and len(r["children"]) == 1
          and r["children"][0]["child"] == "stainless-cascading", str(r))
    # MINOR 20: filenames say two colours, the words say one: ask
    r = vi.map_uploads(["red.jpg", "black.jpg"], "here is the red one")
    check("filenames naming two colours against words naming one is a question",
          "question" in r and "children" not in r, str(r))

# ---- variations_qa --ref: the third tile ------------------------------------------
try:
    vq = _load("variations_qa")
except Exception as e:  # noqa: BLE001
    check("variations_qa.py imports", False, repr(e))
    vq = None

if vq:
    with tempfile.TemporaryDirectory() as d:
        root = Path(d)
        src = Image.new("RGB", (40, 50), (250, 250, 250))
        out = Image.new("RGB", (40, 50), (200, 200, 200))
        ref = Image.new("RGB", (40, 50), (20, 20, 20))
        grid = vq.tile_diff(src, out, 2)
        p = root / "qa.png"
        try:
            vq.sheet(src, out, grid, 2, p, "t", ref=ref)
            w = Image.open(p).size[0]
            check("sheet(ref=...) renders FOUR tiles (source, generated, reference, overlay)",
                  w == vq.W * 4 + 30, f"width {w}")
        except TypeError as e:
            check("sheet() accepts a ref image", False, repr(e))
        p2 = root / "qa2.png"
        vq.sheet(src, out, grid, 2, p2, "t")
        check("sheet() without a ref still renders three tiles", Image.open(p2).size[0] == getattr(vq, "W", 420) * 3 + 20)
        check("--ref is documented in the usage", "--ref" in (vq.__doc__ or ""))

# ---- Day 9 review (14 September 2026): picks, run-log, concept references -----------
STATUS_V9 = """# status
INVENT sub-status:

**Main pick: main-13 (primary); alternatives: main-03, main-06; backup: vanilla-control.png**
**Gallery pick: edits/v9 (frames sec-01-v2, sec-02-v2, sec-03-v3, sec-04-v3, sec-05-v2, sec-06-v2, sec-07-v2, sec-08-v3, in that order)**
> Updated 2026-09-13: sec-03-v2 -> **sec-03-v3** and the round moved v8 -> v9.
"""
STATUS_V2 = """# status
- Main pick: main-05
- Gallery pick: edits/v2 (frames 02-07 in order)
"""
STATUS_NO_GALLERY = """# status
**Main pick: main-13 (primary)**
"""

if vr:
    with tempfile.TemporaryDirectory() as d:
        root = Path(d)
        # 2a: picks_from_status reads both spellings
        prod = root / "fondue"
        prod.mkdir()
        (prod / "status.md").write_text(STATUS_V9)
        prod3 = root / "nogallery"
        prod3.mkdir()
        (prod3 / "status.md").write_text(STATUS_NO_GALLERY)
        if hasattr(vr, "picks_from_status"):
            picks = vr.picks_from_status(prod)
            check("picks_from_status reads the primary main only",
                  picks.get("MAIN") == "main-13", str(picks))
            want = {"PT01": "sec-01-v2", "PT02": "sec-02-v2", "PT03": "sec-03-v3", "PT04": "sec-04-v3",
                    "PT05": "sec-05-v2", "PT06": "sec-06-v2", "PT07": "sec-07-v2", "PT08": "sec-08-v3"}
            check("  ... and the eight gallery names in the recorded order",
                  {k: v for k, v in picks.items() if k.startswith("PT")} == want, str(picks))
            prod2 = root / "plates"
            prod2.mkdir()
            (prod2 / "status.md").write_text(STATUS_V2)
            for n in ("02", "03", "04", "05", "06", "07"):
                png(prod2 / "edits" / "v2" / f"sec-{n}.png")
            try:
                picks2 = vr.picks_from_status(prod2)
            except Exception as e:  # noqa: BLE001
                picks2 = repr(e)
            check("the `frames 02-07 in order` spelling expands to six frames, each a FILE in the row's folder",
                  picks2 == {"MAIN": "main-05", "PT01": "sec-02.png", "PT02": "sec-03.png", "PT03": "sec-04.png",
                             "PT04": "sec-05.png", "PT05": "sec-06.png", "PT06": "sec-07.png"}, str(picks2))
            # F1 (review 14.9): a number is a frame NUMBER, never a filename. sec-02-v1 beats sec-02,
            # sec-03 stands alone, and a number no file carries refuses naming that number.
            prod4 = root / "plates-images"
            prod4.mkdir()
            (prod4 / "status.md").write_text("# status\n- Main pick: main-05\n- Gallery pick: images/ (frames 02-03 in order)\n")
            png(prod4 / "images" / "sec-02.png")
            png(prod4 / "images" / "sec-02-v1.png")
            png(prod4 / "images" / "sec-03.png")
            try:
                picks4 = vr.picks_from_status(prod4)
            except Exception as e:  # noqa: BLE001
                picks4 = repr(e)
            check("`frames 02-03 in order` under images/ resolves 02 to sec-02-v1.png (newest -vN) and 03 to sec-03.png",
                  picks4 == {"MAIN": "main-05", "PT01": "sec-02-v1.png", "PT02": "sec-03.png"}, str(picks4))
            prod5 = root / "plates-missing"
            prod5.mkdir()
            (prod5 / "status.md").write_text("# status\n- Main pick: main-05\n- Gallery pick: images/ (frames 02-03 in order)\n")
            png(prod5 / "images" / "sec-03.png")
            refused = None
            try:
                vr.picks_from_status(prod5)
            except Exception as e:  # noqa: BLE001
                refused = str(e)
            check("  ... and a number that matches no file refuses in one line naming 02",
                  refused is not None and "02" in refused and "\n" not in refused.strip(), str(refused))
            refused = None
            try:
                vr.picks_from_status(prod3)
            except Exception as e:  # noqa: BLE001
                refused = str(e)
            check("a missing Gallery pick row refuses in one line naming the row",
                  refused is not None and "Gallery pick" in refused, str(refused))
        else:
            check("picks_from_status exists", False)

        # 2a: --source-from-picks fills the frames and resolves sec-03-v3 to edits/v9
        for f in ("main-13", "sec-01-v2", "sec-02-v2", "sec-03-v2", "sec-04-v3", "sec-05-v2",
                  "sec-06-v2", "sec-07-v2", "sec-08-v3"):
            png(prod / "edits" / "v8" / f"{f}.png", size=(40, 40))
        for f in ("main-13", "sec-01-v2", "sec-02-v2", "sec-03-v3", "sec-04-v3", "sec-05-v2",
                  "sec-06-v2", "sec-07-v2", "sec-08-v3"):
            png(prod / "edits" / "v9" / f"{f}.png", size=(40, 40))
        png(prod / "edits" / "v9" / "sec-03-v3-render.png", size=(40, 40))
        # F5 (review 14.9): v8 holds a sec-03-v3.png TOO, with different bytes; the copy must be v9's
        png(prod / "edits" / "v8" / "sec-03-v3.png", size=(40, 40), colour=(10, 20, 30))
        wp = root / "wp" / "variations-work"
        wp.mkdir(parents=True)
        png(wp / "refs" / "round.png", size=(40, 40))
        manp = {
            "product": "fondue", "hero_frame": "MAIN",
            "frames": {"from": "picks"},
            "shape_refs": {"round": "round.png"},
            "shape_prompts": {"round": "make it round"},
            "children": [{"child": "white", "shape_ref": None, "status": "concept",
                          "frames": {"MAIN": {"text": "white"}, "PT03": {"text": "white"}}}],
        }
        (wp / "manifest.json").write_text(json.dumps(manp))
        code, out = run_main(vr, [str(wp / "manifest.json"), "--dry-run", "--source-from-picks", str(prod)])
        out_n = out.replace("\\", "/")
        check("--source-from-picks fills frames from the pick rows and the dry run goes on",
              code == 0 and (wp / "source" / "main-13.png").is_file(), f"exit {code!r}: {out[-500:]}")
        check("  ... sec-03-v3 resolves to edits/v9/sec-03-v3.png (the round holds v3, not v2)",
              "edits/v9/sec-03-v3.png" in out_n and (wp / "source" / "sec-03-v3.png").is_file(), out_n[-600:])
        check("  ... and the bytes copied into source/ are v9's, not v8's",
              (wp / "source" / "sec-03-v3.png").is_file()
              and (wp / "source" / "sec-03-v3.png").read_bytes() == (prod / "edits" / "v9" / "sec-03-v3.png").read_bytes()
              and (wp / "source" / "sec-03-v3.png").read_bytes() != (prod / "edits" / "v8" / "sec-03-v3.png").read_bytes())
        check("  ... every resolved path is printed with its folder",
              "edits/v9/main-13.png" in out_n and "edits/v9/sec-08-v3.png" in out_n, out_n[-600:])
        check("  ... and the job list runs on the filled frames (MAIN and PT03)",
              "white MAIN:" in out and "white PT03:" in out, out[-400:])
        code, out = run_main(vr, [str(wp / "manifest.json"), "--dry-run", "--source-from-picks", str(prod3)])
        check("--source-from-picks refuses when a pick row is missing, naming it",
              isinstance(code, str) and "Gallery pick" in code and "Nothing ran" in code, f"exit {code!r}")
        code, out = run_main(vr, [str(wp / "manifest.json"), "--dry-run"])
        check("frames {from: picks} without --source-from-picks refuses plainly",
              isinstance(code, str) and "--source-from-picks" in code, f"exit {code!r}: {out[-200:]}")
        # F3 (review 14.9): the same refusal through --source-from, not "picks is in no edits/vN/ round"
        code, out = run_main(vr, [str(wp / "manifest.json"), "--dry-run", "--source-from", str(prod)])
        check("frames {from: picks} with plain --source-from refuses the same plain way",
              isinstance(code, str) and "--source-from-picks" in code and "no edits/vN/ round" not in code,
              f"exit {code!r}: {out[-200:]}")

        # 7c: the run record
        work = make_work(root)
        code, out = run_main(vr, [str(work / "manifest.json"), "--dry-run"])
        check("a dry run writes no run-log.md", code == 0 and not (work / "run-log.md").exists(), f"exit {code!r}")
        calls = []
        def fake_edit(base, dst, prompt, ref, quality="low", force=False, tries=2):
            calls.append(dst)
            if dst.name == "PT01.png":
                raise RuntimeError("boom")
            if dst.name == "PT02.png":
                return f"skip (exists) {dst.name}", 0
            return f"wrote {dst.name}", 1
        real_edit, real_client = vr.edit, vr.client
        vr.edit, vr.client = fake_edit, (lambda: None)
        try:
            code, out = run_main(vr, [str(work / "manifest.json")])
        finally:
            vr.edit, vr.client = real_edit, real_client
        log = (work / "run-log.md").read_text() if (work / "run-log.md").exists() else ""
        check("a run with a stubbed edit() writes run-log.md", code == 0 and bool(log), f"exit {code!r}: {out[-300:]}")
        check("  ... with the children and frames", "round-10in" in log and "square-8set" in log and "MAIN" in log, log[-500:])
        check("  ... calls planned 5, made 2, failed 2, skipped 1",
              "calls planned: 5" in log and "calls made: 2" in log and "calls failed: 2" in log
              and "calls skipped (exists): 1" in log, log[-500:])

        # F2 (review 14.9): the record counts CALLS, not frames. A CLIPPED retry is two paid
        # calls for one written frame, and a chain that breaks after a failed shape step leaves
        # its text step not attempted; the four step numbers must add up to planned.
        w2 = root / "w2" / "variations-work"
        for f in ("MAIN.png", "PT01.png"):
            png(w2 / "source" / f, size=(40, 40))
        png(w2 / "refs" / "round.png", size=(40, 40))
        man_chain = {
            "product": "t", "hero_frame": "MAIN",
            "frames": {"MAIN": "MAIN.png", "PT01": "PT01.png"},
            "shape_refs": {"round": "round.png"}, "shape_prompts": {"round": "round"},
            "children": [{"child": "round", "shape_ref": "round",
                          "frames": {"MAIN": {"shape": True, "text": "8"}, "PT01": {"text": "8"}}}],
        }
        (w2 / "manifest.json").write_text(json.dumps(man_chain))
        def fake_edit2(base, dst, prompt, ref, quality="low", force=False, tries=2):
            if dst.name == "MAIN_shape.png":
                raise RuntimeError("boom")     # the chain breaks: MAIN.png is never attempted
            return f"wrote {dst.name}  CLIPPED left 5%", 2   # one frame, two paid calls
        vr.edit, vr.client = fake_edit2, (lambda: None)
        try:
            code, out = run_main(vr, [str(w2 / "manifest.json")])
        finally:
            vr.edit, vr.client = real_edit, real_client
        log2 = (w2 / "run-log.md").read_text() if (w2 / "run-log.md").exists() else ""
        import re as _re
        def _n(label):
            m = _re.search(r"- " + _re.escape(label) + r": (\d+)", log2)
            return int(m.group(1)) if m else None
        planned, made, failed, skipped, notatt = (_n("calls planned"), _n("calls made"), _n("calls failed"),
                                                   _n("calls skipped (exists)"), _n("not attempted (chain broken)"))
        check("the run record carries a `not attempted (chain broken)` count and a `frames written` count",
              notatt is not None and _n("frames written") is not None, log2[-600:])
        check("  ... planned 3 == failed 1 + not attempted 1 + written 1",
              planned == 3 and failed == 1 and notatt == 1 and _n("frames written") == 1
              and planned == (_n("frames written") or 0) + (failed or 0) + (skipped or 0) + (notatt or 0),
              f"planned {planned} written {_n('frames written')} failed {failed} skipped {skipped} not attempted {notatt}")
        check("  ... and calls made counts the CLIPPED retry: 2 calls for the one written frame",
              made == 2, f"calls made {made}: {log2[-400:]}")
        check("  ... the estimate and the price table date", "September 2026" in log and "$" in log, log[-500:])
        check("  ... and the billed-truth line",
              "no per-call usage" in log and "dashboard is the billed truth" in log, log[-500:])

# 1b: a shape concept from an ASIN reference
if vi:
    if hasattr(vi, "concept_from_reference"):
        c = vi.concept_from_reference("cascading tiers", "B011RBDCJQ")
        check("concept_from_reference returns a labelled concept with source asin-reference",
              c.get("child") == "cascading-tiers" and c.get("label") == "cascading tiers"
              and c.get("source") == "asin-reference" and c.get("status") == "concept"
              and c.get("reference") == "B011RBDCJQ", str(c))
        c = vi.concept_from_reference("wide bowl", "https://www.amazon.com/dp/B000FZ4TZC")
        check("  ... and takes a URL as the reference", c.get("reference") == "https://www.amazon.com/dp/B000FZ4TZC", str(c))
    else:
        check("concept_from_reference exists", False)

# F4 (review 14.9): land() checks the argument against the manifest's recorded status
if vl:
    with tempfile.TemporaryDirectory() as d:
        prod = Path(d) / "product"
        work = prod / "variations-work" / "working"
        png(work / "white" / "MAIN.png")
        (prod / "variations-work" / "manifest.json").write_text(json.dumps({
            "frames": {"MAIN": "MAIN.png"}, "children": [
                {"child": "white", "status": "concept", "frames": {"MAIN": {"text": "white"}}},
                {"child": "black", "status": "real", "frames": {"MAIN": {"text": "black"}}}]}))
        refused = None
        try:
            vl.land(prod, "white", "real", {"MAIN": work / "white" / "MAIN.png"})
        except Exception as e:  # noqa: BLE001
            refused = str(e)
        check("landing a manifest CONCEPT as `real` refuses in one line naming both",
              refused is not None and "concept" in refused and "real" in refused and "\n" not in refused.strip(),
              str(refused))
        check("  ... and nothing landed in variations/", not (prod / "variations" / "main-white.png").exists())
        got = vl.land(prod, "white", "concept", {"MAIN": work / "white" / "MAIN.png"})
        check("  ... while the recorded status lands as before",
              got and got[0].relative_to(prod).as_posix() == "variations/concepts/white/main-white-concept.png", str(got))
        # the CLI path refuses the same way, exit non-zero, nothing landed
        buf = io.StringIO()
        code = 0
        with redirect_stdout(buf):
            try:
                vl.main(["variations_land.py", str(prod), "black", "concept", f"MAIN={work / 'white' / 'MAIN.png'}"])
            except SystemExit as e:
                code = e.code
        check("  ... the CLI refuses too and lands nothing",
              code not in (0, None) and not (prod / "variations" / "concepts" / "black").exists(), f"exit {code!r}")
    with tempfile.TemporaryDirectory() as d:
        prod = Path(d) / "product"
        work = prod / "variations-work" / "working"
        png(work / "white" / "MAIN.png")
        got = vl.land(prod, "white", "real", {"MAIN": work / "white" / "MAIN.png"})
        check("without a manifest, land() proceeds on the argument as today",
              got and got[0].name == "main-white.png", str(got))

# 1b: a concept child's MAIN and PT03 land under concepts/
if vl:
    with tempfile.TemporaryDirectory() as d:
        prod = Path(d) / "product"
        work = prod / "variations-work" / "working"
        png(work / "white" / "MAIN.png")
        png(work / "white" / "PT03.png")
        got = vl.land(prod, "white", "concept", {"MAIN": work / "white" / "MAIN.png", "PT03": work / "white" / "PT03.png"})
        paths = [p.relative_to(prod).as_posix() for p in got]
        check("a concept child's MAIN and PT03 both land under variations/concepts/[child]/",
              paths == ["variations/concepts/white/main-white-concept.png",
                        "variations/concepts/white/pt03-white-concept.png"], str(paths))

# Day 9 maintenance (15.9.2026, the fountain run): a scoped rerun that regenerates nothing
# says so in one plain line, and the run record separates API calls from inspection.
if vr:
    with tempfile.TemporaryDirectory() as d:
        root = Path(d)
        work = make_work(root)
        # every output of the scoped child already on disk
        for f in ("MAIN.png", "PT01.png"):
            png(work / "working" / "square-8set" / f)
        real_edit, real_client = vr.edit, vr.client
        vr.client = lambda: None
        try:
            code, out = run_main(vr, [str(work / "manifest.json"), "--only", "square-8set"])
        finally:
            vr.edit, vr.client = real_edit, real_client
        check("a scoped rerun with every frame on disk exits 0 and spends nothing", code == 0, f"exit {code!r}")
        check("  ... and says plainly that nothing was regenerated and names --force",
              "Nothing regenerated" in out and "--force" in out, out[-400:])
        log = (work / "run-log.md").read_text() if (work / "run-log.md").exists() else ""
        check("  ... the run record says calls succeeded are API calls, not frames passed inspection",
              "passed inspection" in log and "/inspect" in log, log[-600:])
        check("  ... and that the estimate is not the charge",
              "not the charge" in log, log[-600:])
        # the dry run on the same state says the same thing
        code, out = run_main(vr, [str(work / "manifest.json"), "--only", "square-8set", "--dry-run"])
        check("the dry run on frames already on disk names the skip and --force",
              code == 0 and "already on disk" in out and "--force" in out, out[-400:])

# F3 (review 15.9): one evidence pattern in run and land: -rejected-2 and -superseded-1
for stem in ("pt04-black-rejected-2", "main-black-superseded-1"):
    check(f"variations_run._EVIDENCE matches {stem}", bool(vr._EVIDENCE.match(stem)))
    if vl:
        check(f"variations_land._EVIDENCE matches {stem}", bool(vl._EVIDENCE.match(stem)))

# F4 (review 15.9): the header counts steps, not paid calls; the dry listing marks outputs on disk
with tempfile.TemporaryDirectory() as d:
    work = make_work(Path(d))
    png(work / "working" / "square-8set" / "MAIN.png")
    code, out = run_main(vr, [str(work / "manifest.json"), "--dry-run"])
    check("dry header says steps, not edit calls", code == 0 and " steps" in out.split("\n")[0]
          and "edit calls" not in out.split("\n")[0], out.split("\n")[0])
    listing = [l for l in out.split("\n") if "square-8set MAIN:" in l]
    check("dry listing suffixes a step whose output exists with (on disk, skipped)",
          listing and "(on disk, skipped)" in listing[0], str(listing))
    other = [l for l in out.split("\n") if "square-8set PT01:" in l]
    check("  ... and not a step whose output is missing",
          other and "(on disk, skipped)" not in other[0], str(other))

# land() never takes an evidence file (a superseded frame, a rejected render, an underscore
# diagnostic) into variations/
if vl:
    with tempfile.TemporaryDirectory() as d:
        prod = Path(d) / "product"
        work = prod / "variations-work" / "working" / "black"
        for name in ("MAIN-superseded-1.png", "MAIN-rejected.png", "_TOWERS-black.png"):
            png(work / name)
        for name in ("MAIN-superseded-1.png", "MAIN-rejected.png", "_TOWERS-black.png"):
            refused = None
            try:
                vl.land(prod, "black", "real", {"MAIN": work / name})
            except Exception as e:  # noqa: BLE001
                refused = str(e)
            check(f"land() refuses {name} as a source",
                  refused is not None and "evidence" in refused.lower(), str(refused))
        check("  ... and nothing landed", not (prod / "variations").exists())

print()
if FAILURES:
    print(f"{len(FAILURES)} FAILED: {', '.join(FAILURES)}")
    sys.exit(1)
print("all passed")

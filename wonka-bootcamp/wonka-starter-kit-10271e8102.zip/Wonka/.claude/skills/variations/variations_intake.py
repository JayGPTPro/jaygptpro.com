#!/usr/bin/env python3
"""Intake helpers for the Variations Room: turn what the owner handed over into a
child list, or into the ONE question Wonka may ask.

Two inputs need code, because prose guesses:

  map_uploads(files, words)
      Uploaded images (method C). Decides "several variants" versus "several views
      of ONE variant" from the filename tokens (colour names, front/back/side) and
      the owner's sentence. Returns {"children": [...]} or {"question": "..."}.
      The question is the one focused question and nothing else.

  children_from_sentence(words, known)
      Written instructions (method B): "make this in black, white and red". Every
      colour named becomes a child, `source: described`. A colour the reference set
      never showed (not in `known`) is a CONCEPT child, labelled so.

  concept_from_reference(label, asin_or_url)
      A SHAPE concept the owner is exploring, with another listing (or a link) as its
      shape reference. `source: asin-reference`: the ASIN supplies the SHAPE only; it
      is not a child of the owner's listing and its listing facts are never read as
      the concept's facts.

Each child is a dict: child (slug), label, source (uploaded | described |
asin-reference), status (real | concept), files (uploads only), reference (shape
concepts only).

No network, no image reading. Filenames and words only.

CLI:
  python3 variations_intake.py <file> [<file> ...] "<the owner's words>"
  python3 variations_intake.py --sentence [--known stainless,black] make this in black, white and red
"""
from __future__ import annotations
import re
from pathlib import Path

COLOURS = (
    "black white red blue green yellow orange purple pink brown grey gray beige cream "
    "ivory navy teal aqua turquoise gold silver bronze copper rose coral mint olive "
    "khaki tan sand charcoal onyx graphite slate stainless steel chrome walnut oak "
    "maple natural clear amber burgundy maroon lavender lilac violet indigo sage "
    "emerald ruby sapphire champagne pearl"
).split()
# A finish word is a MODIFIER of the colour that follows it, never a child of its own:
# "in matte black" is one child, matte-black, labelled "matte black".
MODIFIERS = ("matte", "glossy", "gloss", "brushed", "satin")
# Filename noise that names nothing about the variant.
_NOISE = {"img", "image", "photo", "pic", "picture", "copy", "final", "main", "live",
          "jpg", "jpeg", "png", "webp", "dsc", "screenshot", "edited", "new"}
VIEWS = ("front", "back", "side", "top", "bottom", "detail", "closeup", "close-up",
         "angle", "left", "right", "rear", "profile", "macro", "view", "34", "three-quarter")
_ONE_VARIANT_WORDS = re.compile(r"\b(angles?|views?|sides?|shots?) of|\bone (colou?r|variant|model)\b|\bsame (colou?r|variant|one)\b", re.I)
_MANY_VARIANT_WORDS = re.compile(r"\b(\d+|two|three|four|five|six|seven|eight|nine|ten) (colou?rs|variants|finishes|models|children|options)\b|\bdifferent (colou?rs|variants|finishes)\b", re.I)


def _tokens(name: str) -> list:
    stem = Path(name).stem.lower()
    return [t for t in re.split(r"[^a-z0-9]+", stem) if t]


def _colour_tokens(tokens) -> list:
    return [t for t in tokens if t in COLOURS]


def _view_tokens(tokens) -> list:
    return [t for t in tokens if t in VIEWS]


def _colours_in(words: str) -> list:
    """Colour names in the owner's words, a finish modifier merged into the colour
    that follows it ("matte black" -> "matte black"), deduped, in order."""
    out = []
    toks = [t for t in re.split(r"[^a-z0-9-]+", (words or "").lower()) if t]
    i = 0
    while i < len(toks):
        t = toks[i]
        if t in MODIFIERS and i + 1 < len(toks) and toks[i + 1] in COLOURS:
            name = f"{t} {toks[i + 1]}"
            i += 2
        elif t in COLOURS:
            name = t
            i += 1
        else:
            i += 1
            continue
        if name not in out:
            out.append(name)
    return out


def _variant_name(tokens) -> str:
    """The variant a filename names: its colour plus every token that is neither a
    colour, a view, a number nor noise, in filename order. `stainless-cascading.jpg`
    names stainless-cascading, a different product from stainless; `black-front.jpg`
    names black. Empty when the filename names no colour."""
    if not _colour_tokens(tokens):
        return ""
    keep = [t for t in tokens
            if (t in COLOURS or t in MODIFIERS)
            or (t not in VIEWS and t not in _NOISE and not t.isdigit())]
    return " ".join(keep)


def _child(name: str, source: str, status: str = "real", files=None) -> dict:
    slug = re.sub(r"[^a-z0-9]+", "-", name.lower()).strip("-") or "child"
    d = {"child": slug, "label": name, "source": source, "status": status}
    if files is not None:
        d["files"] = [str(f) for f in files]
    return d


def question_for(files) -> str:
    """Neutral wording: the files may be colours, shapes or sizes, so the question
    never presumes colour."""
    n = len(files)
    word = {2: "two", 3: "three", 4: "four", 5: "five"}.get(n, str(n))
    return (f"Are these {word} files {word} variants, or {word} views of one? "
            f"({', '.join(Path(f).name for f in files)})")


ORDER_QUESTION = "Which file is which colour, in order? ({files})"


def map_uploads(files, words: str = "") -> dict:
    """Map uploaded files to children, or ask the one question."""
    files = list(files)
    if not files:
        return {"question": "Which files? Nothing was attached."}
    words = words or ""
    per_file = [(_tokens(f), _colour_tokens(_tokens(f)), _view_tokens(_tokens(f))) for f in files]
    # the VARIANT a filename names: colour plus its non-view tokens (stainless-cascading)
    file_colours = [_variant_name(t) or None for t, _, _ in per_file]
    distinct = [c for c in dict.fromkeys(file_colours) if c]
    any_views = any(v for _, _, v in per_file)
    words_colours = _colours_in(words)
    one_variant = bool(_ONE_VARIANT_WORDS.search(words))
    many_variants = bool(_MANY_VARIANT_WORDS.search(words))

    # 1. Filenames name several colours: one child per colour, views grouped under it.
    #    The filenames saying two and the words saying one is a disagreement: ask.
    if len(distinct) > 1 and not one_variant:
        if words_colours and len(words_colours) < len(distinct):
            return {"question": f"The filenames name {', '.join(distinct)} but your words name "
                                f"{', '.join(words_colours)}. Which is it: one variant, or "
                                f"{len(distinct)}?"}
        children = []
        for colour in distinct:
            group = [f for f, c in zip(files, file_colours) if c == colour]
            children.append(_child(colour, "uploaded", files=group))
        unnamed = [f for f, c in zip(files, file_colours) if not c]
        if unnamed:
            return {"question": f"{', '.join(Path(f).name for f in unnamed)}: which colour is this? "
                                f"The named ones map to {', '.join(distinct)}."}
        return {"children": children}

    # 2. One colour in the filenames (or views named, or the owner says one): ONE child.
    if len(distinct) == 1 and (any_views or one_variant or len(files) == 1 or not many_variants):
        name = distinct[0]
        return {"children": [_child(name, "uploaded", files=files)]}
    if one_variant:
        name = words_colours[0] if words_colours else (distinct[0] if distinct else "uploaded")
        return {"children": [_child(name, "uploaded", files=files)]}

    # 3. Unnamed files and the owner named one colour per file: the ORDER is a guess
    #    (camera numbers say nothing about colour), so it is the one question, never a map.
    if words_colours and len(words_colours) == len(files) and len(files) > 1:
        return {"question": ORDER_QUESTION.format(files=", ".join(Path(f).name for f in files))}
    if words_colours and len(words_colours) == 1:
        return {"children": [_child(words_colours[0], "uploaded", files=files)]}
    if many_variants and not words_colours:
        return {"question": f"{len(files)} variants: name each file's colour or variant in order "
                            f"({', '.join(Path(f).name for f in files)})."}
    if len(files) == 1:
        return {"children": [_child("uploaded", "uploaded", files=files)]}

    # 4. Genuinely unclear: the one question.
    return {"question": question_for(files)}


NO_COLOUR_QUESTION = ("I read no colour in that sentence. Which variants do you mean, and how "
                      "does each differ (shape, size, count)?")


def children_from_sentence(words: str, known=()):
    """Written instructions to children. This helper maps COLOURS only: a shape,
    count or size sentence ("the 5-tier model", "a 2-pack") is Wonka's to map into
    children with `source: described`, and here it returns the one question. A
    colour the reference set never showed (`known` is what it did show) is a
    CONCEPT: generated, labelled, never a claim. Returns a list of children, or
    {"question": ...} when the sentence names no colour."""
    known = {k.lower().replace("-", " ") for k in known}
    out = []
    for colour in _colours_in(words):
        out.append(_child(colour, "described", "real" if colour in known else "concept"))
    if not out:
        return {"question": NO_COLOUR_QUESTION}
    return out


def concept_from_reference(label: str, asin_or_url: str) -> dict:
    """A shape (or size, count, finish) concept whose geometry comes from another
    listing. The reference is kept verbatim (an ASIN or a URL); the concept is
    labelled everywhere like any concept and never a product claim."""
    d = _child(label, "asin-reference", "concept")
    d["reference"] = (asin_or_url or "").strip()
    return d


if __name__ == "__main__":
    import json
    import sys
    if len(sys.argv) < 2 or sys.argv[1] in ("-h", "--help"):
        sys.exit(__doc__)
    if sys.argv[1] == "--sentence":
        # --sentence [--known stainless,black] <words...>: known = the colours or finishes the
        # reference set (or the live listing) already shows; everything else is a concept.
        rest = sys.argv[2:]
        known = ()
        if rest and rest[0] == "--known":
            known = tuple(rest[1].split(","))
            rest = rest[2:]
        print(json.dumps(children_from_sentence(" ".join(rest), known=known), indent=2))
    else:
        print(json.dumps(map_uploads(sys.argv[1:-1], sys.argv[-1]) if len(sys.argv) > 2
                         else map_uploads(sys.argv[1:], ""), indent=2))

#!/usr/bin/env python3
"""The gate-trail reconciler.

Written after a full ten-day run shipped a 14-file A+ and a variation that had
never been inspected, under a pack that said nothing about it. The rule was
already in the room; only the counting was missing.

Run: python3 test_gate_trail.py
"""
import sys
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

FAILURES = []


def check(name, cond, detail=""):
    print(("  PASS  " if cond else "  FAIL  ") + name + ("  " + str(detail) if not cond and detail else ""))
    if not cond:
        FAILURES.append(name)


def build(tmp, cards):
    prod = Path(tmp)
    for cls, n in (("main", 1), ("gallery", 6), ("aplus", 14), ("variations", 2)):
        d = prod / "final" / cls
        d.mkdir(parents=True)
        for i in range(n):
            (d / f"f{i}.png").write_bytes(b"x")
    sc = prod / "scorecards"
    sc.mkdir()
    for name, head in cards:
        (sc / name).write_text(head)
    return prod


def run():
    import gate_trail

    # the shape that shipped uninspected: one listing scorecard, nothing else
    prod = build(tempfile.mkdtemp(), [("inspect-2026-08-26-listing.md", "# Inspection . listing scope\n")])
    ship, lines, ungated, flagged = gate_trail.report(prod)
    check("a listing scorecard gates main and gallery",
          "main" not in ungated and "gallery" not in ungated, ungated)
    check("and does NOT quietly gate the A+", "aplus" in ungated, ungated)
    check("nor the variations", "variations" in ungated, ungated)

    # the same pack once the missing rounds are run
    prod2 = build(tempfile.mkdtemp(), [
        ("inspect-2026-08-26-listing.md", "# Inspection . listing scope\n"),
        ("inspect-2026-08-26-aplus.md", "# Inspection . A+ scope\n"),
        ("inspect-2026-08-26-variations.md", "# Inspection . variations scope\n"),
    ])
    _, _, ungated2, _ = gate_trail.report(prod2)
    check("every class gated once its scorecard exists", ungated2 == [], ungated2)

    # a card that MENTIONS another class in its body must not gate that class
    prod2b = build(tempfile.mkdtemp(), [
        ("inspect-2026-08-26-listing.md", "# Inspection . listing scope\n"),
        ("inspect-2026-08-26-variations.md",
         "# Inspection . variations scope\n\nBuilt from: final/main/main-01.png, and the A+ card\n"
         "for aplus context. Compare against the gallery and the whole package.\n"),
    ])
    _, _, ungated2b, _ = gate_trail.report(prod2b)
    check("a body mention does not gate a class the card never inspected",
          "aplus" in ungated2b, ungated2b)

    # the Day 5 default since kit v21: a SHORTLIST scorecard gates the main
    prod2c = build(tempfile.mkdtemp(), [("scorecard-shortlist-2026-09-05.md", "# Scorecard . scope: shortlist\n")])
    _, _, ungated2c, _ = gate_trail.report(prod2c)
    check("a shortlist scorecard gates the main", "main" not in ungated2c, ungated2c)
    check("and only the main", "gallery" in ungated2c and "aplus" in ungated2c, ungated2c)

    # a package-scope scorecard covers everything, which /inspect allows
    prod3 = build(tempfile.mkdtemp(), [("inspect-2026-08-26-package.md", "# Inspection . whole package\n")])
    _, _, ungated3, _ = gate_trail.report(prod3)
    check("a whole-package scorecard gates every class", ungated3 == [], ungated3)

    # the built A+ page views are reference copies, never counted as assets
    prod4 = build(tempfile.mkdtemp(), [("inspect-2026-08-26-package.md", "# package\n")])
    for n in ("aplus-page-desktop.jpg", "aplus-order-mobile.jpg"):
        (prod4 / "final" / "aplus" / n).write_bytes(b"x")
    ship4, _, _, _ = gate_trail.report(prod4)
    check("the stitched page views do not inflate the A+ count",
          len(ship4["aplus"]) == 14, len(ship4["aplus"]))

    # challengers live under main/ and DO ship, so they must be counted
    prod5 = build(tempfile.mkdtemp(), [("inspect-2026-08-26-listing.md", "# listing\n")])
    ch = prod5 / "final" / "main" / "challengers"
    ch.mkdir()
    for i in range(4):
        (ch / f"rank{i + 2}.png").write_bytes(b"x")
    ship5, _, _, _ = gate_trail.report(prod5)
    check("challengers are counted as shipped files", len(ship5["main"]) == 5, len(ship5["main"]))

    # a concept is a picture of a possible product, never a shipped child: a
    # variations/concepts/ folder or a -concept name under final/ is never counted
    prod5b = build(tempfile.mkdtemp(), [("inspect-2026-09-13-variations.md", "# variations\n")])
    con = prod5b / "final" / "variations" / "concepts" / "onyx"
    con.mkdir(parents=True)
    (con / "main-onyx-concept.png").write_bytes(b"x")
    (prod5b / "final" / "variations" / "swatch-onyx-concept.png").write_bytes(b"x")
    ship5b, _, _, _ = gate_trail.report(prod5b)
    check("a concept under final/variations/concepts/ is never a shipped child",
          len(ship5b["variations"]) == 2, [f.name for f in ship5b["variations"]])

    print()
    # --- tracing is not passing ---------------------------------------------
    # A scorecard that recorded open defects still traces perfectly. The pack must
    # say so, or a DEGRADED A+ ships looking certified. Measured on the live run.
    prod6 = build(tempfile.mkdtemp(), [
        ("inspect-2026-08-27-aplus.md",
         "# Inspection . aplus scope\n\nStatus: DEGRADED\nTen brushes against a claim of twelve, left unfixed.\n"),
    ])
    _, _l6, ungated6, flagged6 = gate_trail.report(prod6)
    check("a card with open defects still counts as traced", "aplus" not in ungated6, ungated6)
    check("but the open issues are surfaced, not swallowed",
          any(cls == "aplus" for cls, _c, _m in flagged6), flagged6)
    check("and the marker itself is named",
          any("DEGRADED" in m for _c, _card, marks in flagged6 for m in marks), flagged6)

    # A clean card must NOT be flagged, or the warning becomes noise everyone ignores.
    prod7 = build(tempfile.mkdtemp(), [
        ("inspect-2026-08-28-aplus.md", "# Inspection . aplus scope\n\nEvery module passed. Nothing outstanding.\n"),
    ])
    _, _l7, _u7, flagged7 = gate_trail.report(prod7)
    check("a clean scorecard raises no flag",
          not any(cls == "aplus" for cls, _c, _m in flagged7), flagged7)

    # --- Day 9 maintenance (15.9.2026, the fountain run) -------------------------
    # A superseded frame, a rejected render, a magnified render, a box overlay or an
    # underscore diagnostic that slipped into final/ is evidence, never a shipped asset.
    prod8 = build(tempfile.mkdtemp(), [("inspect-2026-09-14-variations.md", "# variations\n")])
    v = prod8 / "final" / "variations"
    for name in ("main-black-superseded-1.png", "pt04-black-rejected.png", "pt04-black-render2.png",
                 "pt04-black-boxes.png", "_TOWERS-black.png"):
        (v / name).write_bytes(b"x")
    ship8, _, _, _ = gate_trail.report(prod8)
    check("superseded, rejected, render, boxes and underscore files are never shipped assets",
          len(ship8["variations"]) == 2, [f.name for f in ship8["variations"]])


    # F3 (review 15.9): a second rejected render and a superseded frame are evidence too
    prod8b = build(tempfile.mkdtemp(), [("inspect-2026-09-15-variations.md", "# variations\n")])
    for name in ("pt04-black-rejected-2.png", "main-black-superseded-1.png"):
        (prod8b / "final" / "variations" / name).write_bytes(b"x")
    ship8b, _, _, _ = gate_trail.report(prod8b)
    check("gate_trail: -rejected-2 and -superseded-1 are never shipped assets",
          len(ship8b["variations"]) == 2, [f.name for f in ship8b["variations"]])
    # A verdict that rides on an assumed claim is an open issue the pack must carry.
    prod9 = build(tempfile.mkdtemp(), [
        ("scorecard-variations-2026-09-14-r1.md",
         "# Inspection Scorecard . scope: variations\n\n- Verdict: SHIP (assumed: two adjustable front legs)\n"),
    ])
    _, _l9, _u9, flagged9 = gate_trail.report(prod9)
    check("a SHIP (assumed: ...) verdict is surfaced as an open issue",
          any(cls == "variations" and any("assumed" in m for m in marks) for cls, _c, marks in flagged9), flagged9)

    # --- F1 (review 15.9): FAIL is a verdict token, never a substring; `assumed` on a
    # Facts: line is the form the real fondue card writes, and it must surface.
    prod10 = build(tempfile.mkdtemp(), [
        ("scorecard-variations-2026-09-15-clean.md",
         "# Inspection Scorecard . scope: variations\n\n- Failure named in the brief was avoided.\n"
         "- This is not a fail. The edit failed two attempts before landing.\n- Verdict: SHIP\n"),
    ])
    _, _l10, _u10, flagged10 = gate_trail.report(prod10)
    check("prose 'not a fail' / 'failed two attempts' / 'Failure named' does not flag a clean card",
          not any(cls == "variations" for cls, _c, _m in flagged10), flagged10)
    prod11 = build(tempfile.mkdtemp(), [
        ("scorecard-variations-2026-09-15-fail.md",
         "# Inspection Scorecard . scope: variations\n\n- Verdict: FAIL\n"),
        ("scorecard-main-2026-09-15-gate.md",
         "# Inspection Scorecard . scope: main\n\n- Compliance gate: FAIL (badge)\n"),
    ])
    _, _l11, _u11, flagged11 = gate_trail.report(prod11)
    check("a `Verdict: FAIL` line is flagged",
          any(cls == "variations" and "FAIL" in marks for cls, _c, marks in flagged11), flagged11)
    check("a `Compliance gate: FAIL` line is flagged",
          any(cls == "main" and "FAIL" in marks for cls, _c, marks in flagged11), flagged11)
    prod12 = build(tempfile.mkdtemp(), [
        ("scorecard-variations-2026-09-15-facts.md",
         "# Inspection Scorecard . scope: variations\n\n"
         "- Facts: two adjustable front legs (assumed, owner's word, status.md 14.9)\n- Verdict: SHIP\n"),
    ])
    _, _l12, _u12, flagged12 = gate_trail.report(prod12)
    check("`assumed` on a Facts: line with a plain `Verdict: SHIP` is surfaced as an open issue",
          any(cls == "variations" and any("assumed" in m for m in marks) for cls, _c, marks in flagged12), flagged12)

    if FAILURES:
        print(f"FAILED ({len(FAILURES)}): " + ", ".join(FAILURES))
        return 1
    print("GATE TRAIL: all green")
    return 0


if __name__ == "__main__":
    sys.exit(run())

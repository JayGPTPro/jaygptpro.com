#!/usr/bin/env python3
"""Reconcile what the pack SHIPS against what was actually inspected.

The Shipping Room's rule has always been that every packaged asset either
traces to a scorecard or is labelled `ungated` with its risk line. Written as
prose, that rule is one a tired room skips: a full ten-day run shipped a
14-file A+ that had never been inspected, and the pack carried no gate-trail
line to say so. Nothing was wrong with the rule. It was just not mechanical,
and a rule that depends on remembering is a rule with a failure rate.

So this counts. It reads the shipped classes out of `final/`, reads which
classes have a scorecard in `scorecards/`, and prints the lines that go into
the pack. It does not judge quality and it cannot: a scorecard's existence is
all it checks. What it removes is the possibility of not noticing.

Usage:
    python3 gate_trail.py <product folder> [--strict]

--strict exits 1 when anything is ungated, for anyone who wants the room to
stop rather than to label. The default prints the labels and exits 0, which
matches the room: an ungated asset is disclosed, never blocked.
"""
import re
import sys
from pathlib import Path

# what a class is called in final/, and the scope words a scorecard may use for it
# `shortlist` is the Day 5 default scope since kit v21: /inspect scores only the
# candidates the owner shortlisted, and the card is named scorecard-shortlist-DATE.
# Before v23 this table did not know the word, so every v21+ student's main was
# printed UNGATED in the upload pack (reproduced 7 September 2026).
CLASSES = {
    "main": ("main", "shortlist", "listing", "package"),
    "gallery": ("gallery", "secondary", "listing", "package"),
    "aplus": ("aplus", "a+", "package"),
    "variations": ("variations", "variation", "package"),
}
IMG = (".png", ".jpg", ".jpeg", ".webp")
# built views, not assets: they are reference copies of files already counted.
# A `-concept` file is a picture of a POSSIBLE product from Day 9's Variations Room,
# never a shipped child: it must not be counted, gated or uploaded. Evidence beside a
# candidate (a `-superseded-N` frame moved aside by --force, a `-rejected` render, a
# magnified `-render`, a `-boxes` overlay, a leading-underscore diagnostic) is never
# a shipped asset either, whichever folder it was copied from (fountain run, 14.9.2026).
NOT_AN_ASSET = re.compile(
    r"^aplus-(page|order)-|-concept(\b|[-_.])|^_|-superseded-\d+\.|[-_](rejected|render\d*|boxes\d*)(-\d+)?\.",
    re.I)


def _is_concept(f: Path, root: Path) -> bool:
    """Anything under a `concepts/` folder inside final/ is Day 9's concept output."""
    return "concepts" in f.relative_to(root).parts


def shipped(final: Path) -> dict:
    out = {}
    for cls in CLASSES:
        d = final / cls
        if not d.is_dir():
            continue
        files = [f for f in sorted(d.rglob("*"))
                 if f.is_file() and f.suffix.lower() in IMG and not NOT_AN_ASSET.search(f.name)
                 and not _is_concept(f, d)]
        if files:
            out[cls] = files
    return out


def scoped_scorecards(scorecards: Path) -> dict:
    """Which classes each scorecard claims to cover.

    Read from the FILENAME plus the first heading line, and nothing else.
    Scanning the body instead was the obvious first version and it was wrong in
    a way that is worse than missing a card: a variations scorecard whose
    "Built from:" line cited `final/main/main-01.png` and whose second
    paragraph mentioned the A+ card was credited with gating the mains AND the
    A+. A checker that invents coverage is more dangerous than no checker, so
    a class counts only where /inspect actually writes its scope."""
    covered = {}
    if not scorecards.is_dir():
        return covered
    for f in sorted(scorecards.glob("*.md")):
        heading = ""
        try:
            for line in f.read_text(errors="replace").splitlines():
                if line.startswith("#"):
                    heading = line.lower()
                    break
        except OSError:
            pass
        hay = f.stem.lower() + " " + heading
        for cls, words in CLASSES.items():
            if any(w in hay for w in words):
                covered.setdefault(cls, []).append(f.name)
    return covered


# Words a scorecard uses when it recorded a defect it did NOT clear. Tracing to a card
# is not the same as passing it: a DEGRADED card with open flags traces perfectly well.
# Each marker is (label, compiled pattern). `FAIL` is a VERDICT token: it counts only as a
# whole word on a `Verdict:` or `Compliance gate:` line, because as a plain substring it
# matched "Failure named", "not a fail" and "failed two attempts" in prose and flagged
# clean cards (review 15.9.2026). `assumed` is a verdict riding on an owner assumption:
# the real card writes `Verdict: SHIP` with `assumed` on the `Facts:` line, an older form
# wrote `SHIP (assumed: <claim>)` on the verdict line. Both are caught, on those two
# lines only, and the pack carries the claim as its own line, never as verified.
OPEN_MARKERS = (
    ("FAIL", re.compile(r"^\W*(verdict|compliance gate)\s*:.*\bFAIL\b", re.I | re.M)),
    ("DEGRADED", re.compile(r"DEGRADED", re.I)),
    ("UNSCORED", re.compile(r"UNSCORED", re.I)),
    ("UNVERIFIED", re.compile(r"UNVERIFIED", re.I)),
    ("not fixed", re.compile(r"not fixed", re.I)),
    ("unfixed", re.compile(r"unfixed", re.I)),
    ("open defect", re.compile(r"open defect", re.I)),
    ("left unfixed", re.compile(r"left unfixed", re.I)),
    ("tagged, not fixed", re.compile(r"tagged, not fixed", re.I)),
    ("assumed", re.compile(r"^\W*(verdict|facts)\s*:.*\bassumed\b", re.I | re.M)),
)


def open_flags(card: Path) -> list:
    """Markers of unresolved defects inside one scorecard, deduped, in file order."""
    try:
        text = card.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return []
    found = []
    for label, pattern in OPEN_MARKERS:
        if pattern.search(text) and label not in found:
            found.append(label)
    return found


def report(product: Path):
    final = product / "final"
    ship = shipped(final)
    cover = scoped_scorecards(product / "scorecards")
    lines, ungated, flagged = [], [], []
    for cls, files in ship.items():
        cards = cover.get(cls, [])
        if cards:
            lines.append(f"  {cls}: {len(files)} file(s) gated by {', '.join(cards)}")
            for card in cards:
                marks = open_flags(product / "scorecards" / card)
                if marks:
                    lines.append(f"    ^ {card} records OPEN issues: {', '.join(marks)}")
                    flagged.append((cls, card, marks))
        else:
            lines.append(f"  {cls}: {len(files)} file(s) UNGATED, no scorecard covers this class")
            ungated.append(cls)
    return ship, lines, ungated, flagged


def main():
    args = sys.argv[1:]
    if not args:
        sys.exit(__doc__)
    product = Path(args[0])
    if not (product / "final").is_dir():
        sys.exit(f"no final/ in {product}. Assemble the package first; there is nothing to reconcile.")
    ship, lines, ungated, flagged = report(product)
    total = sum(len(v) for v in ship.values())
    gated = total - sum(len(ship[c]) for c in ungated)
    print(f"Gate trail: {gated} of {total} packaged files trace to a scorecard.")
    print("TRACING IS NOT PASSING: a scorecard that recorded open defects still counts as a trace.")
    print("\n".join(lines))
    if flagged:
        print()
        print("SAY THESE OUT LOUD BEFORE THE OWNER UPLOADS, one line each:")
        for cls, card, marks in flagged:
            print(f"  - {cls}: traces to {card}, which recorded {', '.join(marks)}. "
                  f"Packaged so it can be seen, not certified clean.")
    if ungated:
        print()
        print("PASTE INTO THE PACK, one risk line each, in the owner's words:")
        for cls in ungated:
            print(f"  - {cls}: shipped UNGATED. It was generated and eyeballed, never scored against "
                  f"the Golden Standards. Risk: [name it]. Fix: run /inspect scoped to the {cls}.")
    if ungated and "--strict" in args:
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())

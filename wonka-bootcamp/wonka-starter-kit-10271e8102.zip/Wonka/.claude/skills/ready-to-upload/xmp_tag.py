#!/usr/bin/env python3
"""Write and verify Amazon's AI-person disclosure tag in an image's XMP metadata.

Amazon's instruction (checked 15 September 2026): listing and A+ images that show a
photorealistic AI-generated person carry the keyword `contains-synthetic-performer`
in XMP `dc:subject`. This tool writes that keyword into the file's metadata and reads
it back. It never touches a pixel: the PNG image data chunks and the JPEG scan are
copied byte for byte, and `tag` refuses to write if they would differ.

No third-party library. Standard library only, so it runs on any owner's machine.

Formats:
  PNG   the packet lives in an iTXt chunk keyed `XML:com.adobe.xmp` (Adobe's PNG rule)
  JPEG  the packet lives in an APP1 segment headed `http://ns.adobe.com/xap/1.0/`
  anything else (webp, tiff, ...) is reported UNSUPPORTED and left alone. Convert the
  final file to PNG or JPEG first, then tag the converted file, because a conversion
  can drop metadata.

An existing XMP packet is kept: the keyword is added to the existing `dc:subject`
bag, or a `dc:subject` is added to the existing description, and every other field
(creator, rights, camera data) survives untouched. Tagging twice adds nothing.

Usage:
    python3 xmp_tag.py tag    FILE [FILE ...]      write the tag, then verify it
    python3 xmp_tag.py verify FILE [FILE ...]      read the tag back, write nothing
    python3 xmp_tag.py subjects FILE [FILE ...]    print every dc:subject keyword

Options:
    --tag KEYWORD    a different keyword (default: contains-synthetic-performer)

One line per file: TAGGED / ALREADY / VERIFIED / MISSING / UNSUPPORTED, then the path.
A file its owner cannot write is REFUSED (read-only) and left alone; a folder that will not
take the rewrite gives FAILED (permission) and the batch goes on to the next file. The file
keeps its permission bits. `tag` and `verify` exit 1 if any file did not end VERIFIED, so a
shell can gate on it.
"""
import os
import re
import stat
import struct
import sys
import zlib
from pathlib import Path
from xml.etree import ElementTree as ET

DEFAULT_TAG = "contains-synthetic-performer"

PNG_SIG = b"\x89PNG\r\n\x1a\n"
PNG_XMP_KEY = b"XML:com.adobe.xmp"
JPEG_XMP_HEADER = b"http://ns.adobe.com/xap/1.0/\x00"

NS_RDF = "http://www.w3.org/1999/02/22-rdf-syntax-ns#"
NS_DC = "http://purl.org/dc/elements/1.1/"
NS_X = "adobe:ns:meta/"

_PACKET_HEAD = '<?xpacket begin="﻿" id="W5M0MpCehiHzreSzNTczkc9d"?>'
_PACKET_TAIL = '<?xpacket end="w"?>'


# ---------------------------------------------------------------- packet text

def new_packet(keyword):
    return (
        _PACKET_HEAD
        + '<x:xmpmeta xmlns:x="%s"><rdf:RDF xmlns:rdf="%s">' % (NS_X, NS_RDF)
        + '<rdf:Description rdf:about="" xmlns:dc="%s">' % NS_DC
        + "<dc:subject><rdf:Bag><rdf:li>%s</rdf:li></rdf:Bag></dc:subject>" % _xml_escape(keyword)
        + "</rdf:Description></rdf:RDF></x:xmpmeta>"
        + _PACKET_TAIL
    )


def _xml_escape(s):
    return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def _xml_body(packet):
    """The XML inside the xpacket processing instructions (ElementTree rejects them)."""
    body = re.sub(r"<\?xpacket[^>]*\?>", "", packet).strip()
    return body


def subjects_in_packet(packet):
    """Every dc:subject keyword in an XMP packet, namespace-aware. Bad XML reads as none."""
    try:
        root = ET.fromstring(_xml_body(packet))
    except ET.ParseError:
        return []
    out = []
    for subj in root.iter("{%s}subject" % NS_DC):
        for li in subj.iter("{%s}li" % NS_RDF):
            if li.text and li.text.strip():
                out.append(li.text.strip())
    return out


def add_keyword_to_packet(packet, keyword):
    """Return the packet with the keyword added to dc:subject. Text-level edits only, so
    every other field keeps its exact bytes. Returns the packet unchanged if present."""
    if keyword in subjects_in_packet(packet):
        return packet
    esc = _xml_escape(keyword)
    # Find how the file spells the dc and rdf prefixes (almost always dc and rdf).
    dc = _prefix_for(packet, NS_DC) or "dc"
    rdf = _prefix_for(packet, NS_RDF) or "rdf"
    li = "<%s:li>%s</%s:li>" % (rdf, esc, rdf)

    # Case 1: an existing subject bag. Add one li before its closing tag.
    m = re.search(r"<%s:subject\b[^>]*>\s*<%s:Bag\b[^>]*?(/?)>" % (re.escape(dc), re.escape(rdf)), packet)
    if m:
        if m.group(1) == "/":
            # an empty self-closing Bag: expand it into a Bag holding our one li
            bag_open = m.group(0)[m.group(0).rfind("<"):-2] + ">"
            head = packet[:m.start()] + m.group(0)[:m.group(0).rfind("<")]
            return head + bag_open + li + "</%s:Bag>" % rdf + packet[m.end():]
        close = packet.find("</%s:Bag>" % rdf, m.end())
        if close != -1:
            return packet[:close] + li + packet[close:]

    # Case 2: a description element, add a whole dc:subject inside it.
    subject = "<%s:subject><%s:Bag>%s</%s:Bag></%s:subject>" % (dc, rdf, li, rdf, dc)
    m = re.search(r"<%s:Description\b[^>]*?(/?)>" % re.escape(rdf), packet)
    if m:
        open_tag = m.group(0)
        needs_ns = ('xmlns:%s=' % dc) not in packet
        ns_attr = ' xmlns:%s="%s"' % (dc, NS_DC) if needs_ns else ""
        if m.group(1) == "/":
            # self-closing description: open it up
            new_open = open_tag[:-2] + ns_attr + ">"
            return packet[:m.start()] + new_open + subject + "</%s:Description>" % rdf + packet[m.end():]
        new_open = open_tag[:-1] + ns_attr + ">"
        return packet[:m.start()] + new_open + subject + packet[m.end():]

    # Case 3: nothing usable inside. Start a fresh packet rather than guess at a structure.
    return new_packet(keyword)


def _prefix_for(packet, uri):
    m = re.search(r'xmlns:([A-Za-z_][\w.-]*)="%s"' % re.escape(uri), packet)
    return m.group(1) if m else None


# ------------------------------------------------------------------------ PNG

def _png_chunks(data):
    """Yield (kind, payload, raw_chunk_bytes) for every chunk. Raises ValueError if malformed."""
    if not data.startswith(PNG_SIG):
        raise ValueError("not a PNG")
    pos = len(PNG_SIG)
    while pos + 8 <= len(data):
        length = struct.unpack(">I", data[pos:pos + 4])[0]
        kind = data[pos + 4:pos + 8]
        end = pos + 12 + length
        if end > len(data):
            raise ValueError("truncated PNG chunk")
        yield kind, data[pos + 8:pos + 8 + length], data[pos:end]
        pos = end
        if kind == b"IEND":
            return
    raise ValueError("PNG has no IEND")


def _png_chunk(kind, payload):
    return struct.pack(">I", len(payload)) + kind + payload + struct.pack(">I", zlib.crc32(kind + payload) & 0xFFFFFFFF)


def _png_xmp_chunk(packet):
    # iTXt: keyword \0 compression_flag(0) compression_method(0) language \0 translated \0 text
    payload = PNG_XMP_KEY + b"\x00\x00\x00\x00\x00" + packet.encode("utf-8")
    return _png_chunk(b"iTXt", payload)


def _png_read_packet(payload):
    """The XMP text out of an iTXt payload keyed XML:com.adobe.xmp, or None if it is not one."""
    if not payload.startswith(PNG_XMP_KEY + b"\x00"):
        return None
    rest = payload[len(PNG_XMP_KEY) + 1:]
    if len(rest) < 2:
        return None
    comp_flag, comp_method = rest[0], rest[1]
    rest = rest[2:]
    # language tag \0 translated keyword \0
    i = rest.find(b"\x00")
    if i == -1:
        return None
    rest = rest[i + 1:]
    j = rest.find(b"\x00")
    if j == -1:
        return None
    text = rest[j + 1:]
    if comp_flag == 1:
        if comp_method != 0:
            return None
        try:
            text = zlib.decompress(text)
        except zlib.error:
            return None
    return text.decode("utf-8", "replace")


def _png_get_packet(data):
    for kind, payload, _ in _png_chunks(data):
        if kind == b"iTXt":
            p = _png_read_packet(payload)
            if p is not None:
                return p
    return None


def _png_pixels(data):
    return b"".join(payload for kind, payload, _ in _png_chunks(data) if kind == b"IDAT")


def _png_tag(data, keyword):
    """Return new bytes with the keyword present, or None when nothing had to change."""
    chunks = list(_png_chunks(data))
    existing = None
    for kind, payload, _ in chunks:
        if kind == b"iTXt" and _png_read_packet(payload) is not None:
            existing = _png_read_packet(payload)
            break
    if existing is not None and keyword in subjects_in_packet(existing):
        return None
    packet = add_keyword_to_packet(existing, keyword) if existing is not None else new_packet(keyword)
    out = [PNG_SIG]
    replaced = False
    for kind, payload, raw in chunks:
        if kind == b"iTXt" and _png_read_packet(payload) is not None and not replaced:
            out.append(_png_xmp_chunk(packet))
            replaced = True
            continue
        if kind == b"IEND" and not replaced:
            # No packet before: place ours right before IEND, after every image chunk.
            out.append(_png_xmp_chunk(packet))
            replaced = True
        out.append(raw)
    return b"".join(out)


# ----------------------------------------------------------------------- JPEG

def _jpeg_segments(data):
    """Yield (marker, raw_segment_bytes) up to and including the SOS marker segment.
    Everything from the SOS payload to EOI is the scan and is returned as ('scan', bytes).
    Anything after EOI comes back as ('trailer', bytes) so a rewrite keeps it."""
    if not data.startswith(b"\xff\xd8"):
        raise ValueError("not a JPEG")
    pos = 2
    yield "SOI", data[:2]
    while pos < len(data):
        if data[pos] != 0xFF:
            raise ValueError("JPEG marker expected at %d" % pos)
        # skip fill bytes
        while pos < len(data) and data[pos] == 0xFF:
            pos += 1
        if pos >= len(data):
            raise ValueError("truncated JPEG")
        marker = data[pos]
        pos += 1
        if marker == 0xD9:  # EOI
            yield "EOI", b"\xff\xd9"
            return
        if 0xD0 <= marker <= 0xD7 or marker == 0x01:  # standalone markers
            yield "M%02X" % marker, b"\xff" + bytes([marker])
            continue
        if pos + 2 > len(data):
            raise ValueError("truncated JPEG segment")
        length = struct.unpack(">H", data[pos:pos + 2])[0]
        seg = b"\xff" + bytes([marker]) + data[pos:pos + length]
        pos += length
        if marker == 0xDA:  # SOS: the rest up to EOI is entropy-coded scan data
            yield "SOS", seg
            end = data.rfind(b"\xff\xd9")
            if end == -1:
                raise ValueError("JPEG has no EOI")
            yield "scan", data[pos:end]
            yield "EOI", data[end:end + 2]
            if end + 2 < len(data):
                # bytes after EOI (a trailer some tools append) are carried unchanged
                yield "trailer", data[end + 2:]
            return
        yield "M%02X" % marker, seg
    raise ValueError("JPEG ended without EOI")


def _jpeg_is_xmp(seg):
    return seg[1] == 0xE1 and seg[4:4 + len(JPEG_XMP_HEADER)] == JPEG_XMP_HEADER


def _jpeg_packet_of(seg):
    return seg[4 + len(JPEG_XMP_HEADER):].decode("utf-8", "replace")


def _jpeg_xmp_segment(packet):
    body = JPEG_XMP_HEADER + packet.encode("utf-8")
    if len(body) + 2 > 65535:
        raise ValueError("XMP packet too large for one APP1 segment")
    return b"\xff\xe1" + struct.pack(">H", len(body) + 2) + body


def _jpeg_get_packet(data):
    for name, seg in _jpeg_segments(data):
        if name == "ME1" and _jpeg_is_xmp(seg):
            return _jpeg_packet_of(seg)
        if name in ("SOS", "scan"):
            break
    return None


def _jpeg_pixels(data):
    for name, seg in _jpeg_segments(data):
        if name == "scan":
            return seg
    raise ValueError("JPEG has no scan")


def _jpeg_tag(data, keyword):
    segs = list(_jpeg_segments(data))
    existing = None
    for name, seg in segs:
        if name == "ME1" and _jpeg_is_xmp(seg):
            existing = _jpeg_packet_of(seg)
            break
    if existing is not None and keyword in subjects_in_packet(existing):
        return None
    packet = add_keyword_to_packet(existing, keyword) if existing is not None else new_packet(keyword)
    new_seg = _jpeg_xmp_segment(packet)
    out = []
    placed = False
    # Place after the last leading APP0/APP1 segment (JFIF, Exif) so decoders that expect
    # JFIF first keep seeing it first; otherwise straight after SOI.
    for i, (name, seg) in enumerate(segs):
        if name == "ME1" and _jpeg_is_xmp(seg) and not placed:
            out.append(new_seg)
            placed = True
            continue
        if not placed and name not in ("SOI", "ME0", "ME1"):
            out.append(new_seg)
            placed = True
        out.append(seg)
    return b"".join(out)


# ------------------------------------------------------------------ public API

def _kind(path):
    data = Path(path).read_bytes()
    if data.startswith(PNG_SIG):
        return "png", data
    if data.startswith(b"\xff\xd8"):
        return "jpeg", data
    return None, data


def pixel_bytes(path):
    """The image data alone: PNG IDAT payloads, or the JPEG scan. Used to prove that a
    tagging pass changed no pixel. Raises ValueError on an unsupported or broken file."""
    kind, data = _kind(path)
    if kind == "png":
        return _png_pixels(data)
    if kind == "jpeg":
        return _jpeg_pixels(data)
    raise ValueError("unsupported format")


def read_subjects(path):
    """Every dc:subject keyword in the file's XMP, or [] when there is no packet."""
    kind, data = _kind(path)
    try:
        packet = _png_get_packet(data) if kind == "png" else _jpeg_get_packet(data) if kind == "jpeg" else None
    except ValueError:
        return []
    return subjects_in_packet(packet) if packet else []


def verify(path, keyword=DEFAULT_TAG):
    """VERIFIED / MISSING / UNSUPPORTED, read from the bytes on disk right now."""
    kind, _ = _kind(path)
    if kind is None:
        return "UNSUPPORTED"
    try:
        return "VERIFIED" if keyword in read_subjects(path) else "MISSING"
    except ValueError:
        return "UNSUPPORTED"


def tag(path, keyword=DEFAULT_TAG):
    """Write the keyword into the file's XMP. TAGGED / ALREADY / UNSUPPORTED, or
    REFUSED (read-only) for a file its owner cannot write, or FAILED (permission) when the
    folder would not take the rewrite. Refuses to write if the pixel bytes would change,
    keeps the file's mode, and re-reads the file afterwards."""
    path = Path(path)
    kind, data = _kind(path)
    if kind is None:
        return "UNSUPPORTED"
    try:
        before = _png_pixels(data) if kind == "png" else _jpeg_pixels(data)
        new = _png_tag(data, keyword) if kind == "png" else _jpeg_tag(data, keyword)
    except ValueError:
        return "UNSUPPORTED"
    if new is None:
        return "ALREADY"
    after = _png_pixels(new) if kind == "png" else _jpeg_pixels(new)
    if after != before:
        raise RuntimeError("refusing to write %s: pixel bytes would change" % path)
    if keyword not in subjects_in_packet(_png_get_packet(new) if kind == "png" else _jpeg_get_packet(new)):
        raise RuntimeError("refusing to write %s: the tag did not land in the packet" % path)
    mode = stat.S_IMODE(path.stat().st_mode)
    if not mode & stat.S_IWUSR:
        return "REFUSED (read-only)"
    tmp = path.with_name(path.name + ".xmp-tmp")
    try:
        tmp.write_bytes(new)
        os.chmod(tmp, mode)
        tmp.replace(path)
    except OSError:
        try:
            tmp.unlink()
        except OSError:
            pass
        return "FAILED (permission)"
    if verify(path, keyword) != "VERIFIED":
        raise RuntimeError("wrote %s but could not read the tag back" % path)
    return "TAGGED"


# ------------------------------------------------------------------------ CLI

def main(argv):
    args = list(argv)
    keyword = DEFAULT_TAG
    if "--tag" in args:
        i = args.index("--tag")
        keyword = args[i + 1]
        del args[i:i + 2]
    if len(args) < 2 or args[0] not in ("tag", "verify", "subjects"):
        print(__doc__)
        return 2
    cmd, files = args[0], args[1:]
    bad = 0
    for f in files:
        p = Path(f)
        if not p.is_file():
            print("MISSING-FILE %s" % f)
            bad += 1
            continue
        if cmd == "subjects":
            print("%s  %s" % (f, ", ".join(read_subjects(p)) or "(no dc:subject)"))
            continue
        if cmd == "tag":
            r = tag(p, keyword)
            if r in ("TAGGED", "ALREADY"):
                r = "%s (verify: %s)" % (r, verify(p, keyword))
                if not r.endswith("VERIFIED)"):
                    bad += 1
            else:
                bad += 1
            print("%s %s" % (r, f))
        else:
            r = verify(p, keyword)
            if r != "VERIFIED":
                bad += 1
            print("%s %s" % (r, f))
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))

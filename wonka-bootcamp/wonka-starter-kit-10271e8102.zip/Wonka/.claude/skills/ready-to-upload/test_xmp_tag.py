#!/usr/bin/env python3
"""xmp_tag.py, against files built in a temp folder.

Every case here was watched failing with the module absent before it passed.
The two claims the Shipping Room relies on: the pixels are byte-identical after
tagging, and verify reads the tag back from the finished file, not from memory.

Run: python3 test_xmp_tag.py
"""
import struct
import sys
import tempfile
import zlib
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

FAILURES = []


def check(name, cond, detail=""):
    print(("  PASS  " if cond else "  FAIL  ") + name + ("  " + str(detail) if not cond and detail else ""))
    if not cond:
        FAILURES.append(name)


# A 4x3 baseline JPEG (JFIF APP0, no XMP), 632 bytes, made once with Pillow.
JPEG_HEX = (
    "ffd8ffe000104a46494600010100000100010000ffdb004300100b0c0e0c0a100e0d0e1211101318281a1816"
    "16183123251d283a333d3c3933383740485c4e404457453738506d51575f626768673e4d71797064785c6567"
    "63ffdb0043011112121815182f1a1a2f63423842636363636363636363636363636363636363636363636363"
    "6363636363636363636363636363636363636363636363636363ffc000110800030004030122000211010311"
    "01ffc4001f0000010501010101010100000000000000000102030405060708090a0bffc400b5100002010303"
    "020403050504040000017d01020300041105122131410613516107227114328191a1082342b1c11552d1f024"
    "33627282090a161718191a25262728292a3435363738393a434445464748494a535455565758595a63646566"
    "6768696a737475767778797a838485868788898a92939495969798999aa2a3a4a5a6a7a8a9aab2b3b4b5b6b7"
    "b8b9bac2c3c4c5c6c7c8c9cad2d3d4d5d6d7d8d9dae1e2e3e4e5e6e7e8e9eaf1f2f3f4f5f6f7f8f9faffc400"
    "1f0100030101010101010101010000000000000102030405060708090a0bffc400b511000201020404030407"
    "05040400010277000102031104052131061241510761711322328108144291a1b1c109233352f0156272d10a"
    "162434e125f11718191a262728292a35363738393a434445464748494a535455565758595a63646566676869"
    "6a737475767778797a82838485868788898a92939495969798999aa2a3a4a5a6a7a8a9aab2b3b4b5b6b7b8b9"
    "bac2c3c4c5c6c7c8c9cad2d3d4d5d6d7d8d9dae2e3e4e5e6e7e8e9eaf2f3f4f5f6f7f8f9faffda000c030100"
    "02110311003f00c7a28a2b84fa83ffd9"
)


def png_chunk(kind, data):
    return struct.pack(">I", len(data)) + kind + data + struct.pack(">I", zlib.crc32(kind + data) & 0xFFFFFFFF)


def make_png(path, with_text=False):
    """A 2x2 RGB PNG built by hand: signature, IHDR, optional tEXt, IDAT, IEND."""
    raw = b"".join(b"\x00" + bytes([r, g, b]) * 2 for r, g, b in ((255, 0, 0), (0, 0, 255)))
    parts = [b"\x89PNG\r\n\x1a\n", png_chunk(b"IHDR", struct.pack(">IIBBBBB", 2, 2, 8, 2, 0, 0, 0))]
    if with_text:
        parts.append(png_chunk(b"tEXt", b"Software\x00wonka-test"))
    parts.append(png_chunk(b"IDAT", zlib.compress(raw)))
    parts.append(png_chunk(b"IEND", b""))
    path.write_bytes(b"".join(parts))


def make_jpeg(path):
    path.write_bytes(bytes.fromhex(JPEG_HEX))


EXISTING_XMP = (
    '<?xpacket begin="﻿" id="W5M0MpCehiHzreSzNTczkc9d"?>'
    '<x:xmpmeta xmlns:x="adobe:ns:meta/"><rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#">'
    '<rdf:Description rdf:about="" xmlns:dc="http://purl.org/dc/elements/1.1/">'
    '<dc:creator><rdf:Seq><rdf:li>Keep Me</rdf:li></rdf:Seq></dc:creator>'
    '<dc:subject><rdf:Bag><rdf:li>existing-keyword</rdf:li></rdf:Bag></dc:subject>'
    '</rdf:Description></rdf:RDF></x:xmpmeta><?xpacket end="w"?>'
)


def main():
    try:
        import xmp_tag
    except ImportError as e:
        check("xmp_tag imports", False, e)
        return finish()

    TAG = xmp_tag.DEFAULT_TAG
    check("default tag is Amazon's exact string", TAG == "contains-synthetic-performer", TAG)

    with tempfile.TemporaryDirectory() as td:
        td = Path(td)

        # ---- PNG: tag, pixels identical, verify reads it back --------------------
        p = td / "main-2048.png"
        make_png(p, with_text=True)
        before_pixels = xmp_tag.pixel_bytes(p)
        before_all = p.read_bytes()
        check("untagged PNG verifies as MISSING", xmp_tag.verify(p) == "MISSING")
        r = xmp_tag.tag(p)
        check("tag() reports TAGGED on a fresh PNG", r == "TAGGED", r)
        check("PNG pixel bytes are byte-identical after tagging", xmp_tag.pixel_bytes(p) == before_pixels)
        check("PNG file did change (the tag landed somewhere)", p.read_bytes() != before_all)
        check("PNG verify reads the tag back from disk", xmp_tag.verify(p) == "VERIFIED")
        check("PNG still ends with IEND", p.read_bytes()[-8:-4] == b"IEND")
        check("PNG keeps its other text chunk", b"Software\x00wonka-test" in p.read_bytes())
        r2 = xmp_tag.tag(p)
        check("tagging twice is idempotent (ALREADY)", r2 == "ALREADY", r2)
        check("tagging twice leaves exactly one tag", xmp_tag.read_subjects(p).count(TAG) == 1,
              xmp_tag.read_subjects(p))
        # A fresh copy of the tagged file must survive: the Shipping Room copies final/ to output/
        # and verifies the copy, not the original.
        q = td / "copy.png"
        q.write_bytes(p.read_bytes())
        check("verify works on the package copy", xmp_tag.verify(q) == "VERIFIED")

        # ---- PNG with an existing XMP packet: other metadata survives ------------
        p2 = td / "with-xmp.png"
        make_png(p2)
        raw = p2.read_bytes()
        itxt = png_chunk(b"iTXt", b"XML:com.adobe.xmp\x00\x00\x00\x00\x00" + EXISTING_XMP.encode("utf-8"))
        # insert the iTXt before IDAT
        idat_at = raw.index(b"IDAT") - 4
        p2.write_bytes(raw[:idat_at] + itxt + raw[idat_at:])
        check("existing keyword is read before tagging", xmp_tag.read_subjects(p2) == ["existing-keyword"],
              xmp_tag.read_subjects(p2))
        px2 = xmp_tag.pixel_bytes(p2)
        check("tag() merges into an existing packet", xmp_tag.tag(p2) == "TAGGED")
        subs = xmp_tag.read_subjects(p2)
        check("existing keyword survives the merge", "existing-keyword" in subs, subs)
        check("new tag is in the same Bag", TAG in subs, subs)
        check("dc:creator survives the merge", b"Keep Me" in p2.read_bytes())
        check("only one XMP chunk after the merge", p2.read_bytes().count(b"XML:com.adobe.xmp") == 1)
        check("PNG pixels identical after the merge", xmp_tag.pixel_bytes(p2) == px2)

        # ---- JPEG: tag, pixels identical, verify ---------------------------------
        j = td / "gallery-01.jpg"
        make_jpeg(j)
        jpx = xmp_tag.pixel_bytes(j)
        check("untagged JPEG verifies as MISSING", xmp_tag.verify(j) == "MISSING")
        check("tag() reports TAGGED on a fresh JPEG", xmp_tag.tag(j) == "TAGGED")
        check("JPEG scan bytes are byte-identical after tagging", xmp_tag.pixel_bytes(j) == jpx)
        check("JPEG verify reads the tag back from disk", xmp_tag.verify(j) == "VERIFIED")
        data = j.read_bytes()
        check("JPEG still starts with SOI and ends with EOI", data[:2] == b"\xff\xd8" and data[-2:] == b"\xff\xd9")
        check("JPEG APP1 XMP header is present once", data.count(b"http://ns.adobe.com/xap/1.0/\x00") == 1)
        check("JPEG keeps its JFIF APP0", b"JFIF\x00" in data)
        check("JPEG tagged twice is ALREADY", xmp_tag.tag(j) == "ALREADY")

        # ---- unsupported and broken inputs are said, not guessed ----------------
        w = td / "swatch.webp"
        w.write_bytes(b"RIFF\x00\x00\x00\x00WEBPVP8 ")
        check("webp is UNSUPPORTED, not silently skipped", xmp_tag.tag(w) == "UNSUPPORTED")
        check("webp verify is UNSUPPORTED too", xmp_tag.verify(w) == "UNSUPPORTED")
        bad = td / "broken.png"
        bad.write_bytes(b"not a png at all")
        check("a file that is not really a PNG is UNSUPPORTED", xmp_tag.tag(bad) == "UNSUPPORTED")
        check("a broken file is left untouched", bad.read_bytes() == b"not a png at all")

        # ---- an empty <rdf:Bag/> is expanded, never duplicated ------------------
        empty_bag = EXISTING_XMP.replace(
            "<dc:subject><rdf:Bag><rdf:li>existing-keyword</rdf:li></rdf:Bag></dc:subject>",
            "<dc:subject><rdf:Bag/></dc:subject>")
        merged = xmp_tag.add_keyword_to_packet(empty_bag, TAG)
        check("empty self-closing Bag: exactly one dc:subject after the merge",
              merged.count("<dc:subject") == 1, merged.count("<dc:subject"))
        check("empty self-closing Bag: the keyword is read back", xmp_tag.subjects_in_packet(merged) == [TAG],
              xmp_tag.subjects_in_packet(merged))

        # ---- JPEG bytes after EOI survive -----------------------------------------
        jt = td / "trailer.jpg"
        jt.write_bytes(bytes.fromhex(JPEG_HEX) + b"TRAILER-KEEP-ME")
        jtpx = xmp_tag.pixel_bytes(jt)
        check("JPEG with trailer bytes tags", xmp_tag.tag(jt) == "TAGGED")
        check("JPEG trailer bytes after EOI survive tagging", jt.read_bytes().endswith(b"\xff\xd9TRAILER-KEEP-ME"),
              jt.read_bytes()[-20:])
        check("JPEG with trailer: scan identical", xmp_tag.pixel_bytes(jt) == jtpx)
        check("JPEG with trailer verifies", xmp_tag.verify(jt) == "VERIFIED")

        # ---- file mode is preserved, a read-only file is refused ----------------
        import os, stat, subprocess
        pm = td / "mode600.png"
        make_png(pm)
        os.chmod(pm, 0o600)
        xmp_tag.tag(pm)
        check("tag() preserves the file mode (600 stays 600)", stat.S_IMODE(pm.stat().st_mode) == 0o600,
              oct(stat.S_IMODE(pm.stat().st_mode)))
        ro = td / "readonly.png"
        make_png(ro)
        os.chmod(ro, 0o444)
        ro_before = ro.read_bytes()
        r = xmp_tag.tag(ro)
        check("read-only file: tag() returns REFUSED (read-only)", r == "REFUSED (read-only)", r)
        check("read-only file: bytes untouched", ro.read_bytes() == ro_before)
        check("read-only file: mode still 444", stat.S_IMODE(ro.stat().st_mode) == 0o444,
              oct(stat.S_IMODE(ro.stat().st_mode)))
        out = subprocess.run([sys.executable, str(HERE / "xmp_tag.py"), "tag", str(ro)],
                             capture_output=True, text=True)
        check("CLI tag on a read-only file prints the REFUSED verdict and exits 1",
              out.returncode == 1 and out.stdout.strip() == "REFUSED (read-only) %s" % ro, out.stdout + out.stderr)
        os.chmod(ro, 0o644)

        # ---- an unwritable folder fails that file only, the batch continues ----
        rodir = td / "rodir"
        rodir.mkdir()
        locked = rodir / "x.png"
        make_png(locked)
        other = td / "other.jpg"
        make_jpeg(other)
        os.chmod(rodir, 0o555)
        try:
            out = subprocess.run([sys.executable, str(HERE / "xmp_tag.py"), "tag", str(locked), str(other)],
                                 capture_output=True, text=True)
        finally:
            os.chmod(rodir, 0o755)
        lines = out.stdout.strip().splitlines()
        check("unwritable folder: no traceback", out.stderr == "", out.stderr[-300:])
        check("unwritable folder: one verdict line per file", len(lines) == 2, out.stdout)
        check("unwritable folder: FAILED (permission) on the locked file",
              lines[0] == "FAILED (permission) %s" % locked if lines else False, lines)
        check("unwritable folder: the other file still gets tagged",
              lines[1].startswith("TAGGED") if len(lines) > 1 else False, lines)
        check("unwritable folder: exit 1", out.returncode == 1, out.returncode)
        check("unwritable folder: no tmp file left behind", not list(rodir.glob("*.xmp-tmp")), list(rodir.iterdir()))

        # ---- the CLI prints one line per file with the same verdicts ------------
        import subprocess
        out = subprocess.run([sys.executable, str(HERE / "xmp_tag.py"), "verify", str(p), str(j), str(w)],
                             capture_output=True, text=True)
        lines = out.stdout.strip().splitlines()
        check("CLI verify prints one line per file", len(lines) == 3, out.stdout + out.stderr)
        check("CLI verify lines start with the verdict", all(l.split()[0] in
              {"VERIFIED", "MISSING", "UNSUPPORTED"} for l in lines), lines)
        check("CLI verify exits 1 when any file is not VERIFIED", out.returncode == 1, out.returncode)
        out2 = subprocess.run([sys.executable, str(HERE / "xmp_tag.py"), "verify", str(p), str(j)],
                              capture_output=True, text=True)
        check("CLI verify exits 0 when every file is VERIFIED", out2.returncode == 0, out2.stdout)

        # ---- Pillow, when present, still opens the tagged files -----------------
        try:
            from PIL import Image
            for f in (p, p2, j):
                Image.open(f).load()
            check("Pillow opens every tagged file", True)
            png_xmp = getattr(Image.open(p), "text", {}).get("XML:com.adobe.xmp", "")
            jpg_xmp = Image.open(j).info.get("xmp", b"")
            jpg_xmp = jpg_xmp.decode("utf-8", "replace") if isinstance(jpg_xmp, bytes) else str(jpg_xmp)
            check("Pillow sees the XMP packet in the tagged PNG", TAG in png_xmp)
            check("Pillow sees the XMP packet in the tagged JPEG", TAG in jpg_xmp)
        except ImportError:
            print("  SKIP  Pillow not installed, decoder check skipped")

    return finish()


def finish():
    print()
    if FAILURES:
        print("FAILED: " + ", ".join(FAILURES))
        return 1
    print("all checks passed")
    return 0


if __name__ == "__main__":
    sys.exit(main())

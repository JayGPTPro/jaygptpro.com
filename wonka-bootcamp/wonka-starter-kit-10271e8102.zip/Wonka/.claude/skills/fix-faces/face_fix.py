#!/usr/bin/env python3
"""The Face Clinic's engine: replace AI-looking people with real-looking ones,
without letting the model touch anything else.

Why this exists as code rather than as one API call. The obvious approach,
one whole-frame images.edit pass, was measured failing: the model does not
EDIT a frame, it re-renders it. On one A+ module it fixed the
people beautifully and added a fifth tier to a four-tier product; on another
it moved the subject's face and aged her a decade. A repair that can break
the product is not a repair.

So the contract here is different:
  1. The FULL frame still goes to the model (context: lighting, palette,
     what the scene is), with a prompt that asks for new real faces.
  2. The result is resized back onto the original's grid.
  3. Only the PEOPLE BOXES are taken from it, through a feathered mask.
     Every pixel outside those boxes is the original file, by construction.
     Headlines, product, layout cannot drift because they are never replaced.

The boxes come from the agent LOOKING at the image, not from a detector: the
kit has no face-detection dependency, and the operator drawing two rectangles
is more reliable than a model guessing. Draw them TIGHT: the head and its
hair, nothing more. Everything inside a box is surrendered to the re-render,
and the first run proved what a generous box costs: one that reached into the
layout composited back a ghost microphone and a floating letter, because the
re-render had moved those things and the box carried the moved copies home.
Never let a box touch on-image text or the product. The feather plus the
ring-based tone match below handle the seam; margin does not need to.

Usage:
    python3 face_fix.py <image> --boxes "x1,y1,x2,y2;x1,y1,x2,y2" [--quality high]
                                [--protect "x1,y1,x2,y2;..."] [--out <path>] [--prompt-file <txt>]

`--protect` (kit v36) names the product and the on-image text in the SAME
coordinates as the head boxes (a protect box may run past the module's edges;
it is clipped). The edit region is validated against them BEFORE any spend: a
head box that overlaps a protect box is refused, and on an A+ module the
grown joint box is trimmed back on the side it grew until it clears every
protect box, never below the box as drawn. The reason: the joint box grows
sideways by SHOULDER_RATIO of the head width, and on the Day 7 desktop hero
that carried a head box drawn at x=1136 to x=1021, into the fountain the box
had been placed to avoid (reproduced 10 September 2026). The final region is
drawn on a copy (`<name>-boxes.png`, an evidence file) and its path printed
before the model is called, so the eyes check it before the money goes.

Where the result lands (kit v23): INSIDE a product folder (an ancestor that
holds images/ and status.md) the fix follows the Fixing Room's round law: a new
edits/v[N+1]/ is opened as the ADOPTED SET (kit v28: every original in images/
that is not an evidence file, each replaced by its newest same-name copy from an
earlier round when one exists; files generated after the last round are in too,
files named -rejected / -render / -faces-fixed are not) and the fixed file takes
its CANONICAL name there (main-06.png, never main-06-faces-fixed.png; a
generation's own -v2 stays: sec-03-v2.png fixes as sec-03-v2.png; the format
stays too: sec-02.jpg fixes as sec-02.jpg, one file per asset). The round
writes round.md naming where each file came from, so the Tasting Room, /inspect
and the Shipping Room resolve the current copy without guessing. OUTSIDE a
product folder (a loose file) it lands beside the source as <name>-faces-fixed.<ext>.
--out overrides both. An A+ MODULE (aplus/export/<mode>/mN.png, or its adopted
copy in edits/vN/aplus/<mode>/) lands in the round's aplus/<mode>/ under its own
name, and the input is always the module's adopted copy. When a head box sits
within EDGE_MARGIN of the module's top or bottom edge, or runs past it, the
person continues into the neighbouring module (an A+ page is one canvas cut
into strips; measured 10 September 2026 on the Day 7 hero: the face in m1, the
neck in m2, a fix inside m1 alone cut the neck at the module edge while every
count passed). So the clinic stacks the neighbour(s), edits ONCE on the joined
image with the box grown to hold head, neck and shoulders across the seam,
composites with the same inward feather, re-cuts at the original boundaries
and writes every touched module into the same round, plus two seam crops
(seam-<a>-<b>-2x.png, seam-<a>-<b>-1x.png) for the eyes. The counts are
technical: a visible seam fails the fix even at 0 outside.
Never touches the source. Cost: one images.edit call at quality HIGH by default (about 100
seconds; low is about 20). High is deliberate and it is the one place in this
factory that does not economise: this room only ever runs on an image whose
faces are ALREADY wrong, one image at a time, on an asset the owner has
already paid to generate. Cheap pools, expensive repairs.
"""

from __future__ import annotations   # PEP 604 (`Path | None`) in annotations
# is a runtime TypeError on Python 3.9, the version macOS ships. This makes
# annotations lazy strings so the kit runs on a stock Mac.
import base64
import os
import re
import shutil
import sys
from pathlib import Path


def image_model():
    """The image model this factory runs on: WONKA_IMAGE_MODEL in the environment, else that
    line in the nearest .env upward (the Factory root is where /machines-check put it), else
    the house default. One setting, every machine (kit v51, 17 September 2026). The parser
    forgives what people type into a .env: a BOM, spaces around =, an export prefix, a
    trailing comment, CRLF, a stray non-UTF-8 byte."""
    m = os.environ.get("WONKA_IMAGE_MODEL", "").strip()
    if m:
        return m
    here = os.path.abspath(os.getcwd())
    while True:
        p = os.path.join(here, ".env")
        try:
            with open(p, encoding="utf-8", errors="ignore") as f:
                for line in f:
                    s = line.lstrip("\ufeff").strip()
                    if s.startswith("export "):
                        s = s[7:].strip()
                    k, _, v = s.partition("=")
                    if k.strip() == "WONKA_IMAGE_MODEL":
                        v = v.split("#", 1)[0].strip().strip('"').strip("'")
                        if v:
                            return v
            break
        except (OSError, UnicodeDecodeError):
            pass
        up = os.path.dirname(here)
        if up == here:
            break
        here = up
    return "gpt-image-2.5-sunburst"

try:
    from PIL import Image, ImageDraw, ImageFilter
except ImportError:
    sys.exit("this needs Pillow: python3 -m pip install pillow")

# Replacement, not restoration. Asking the model to "make the same face
# realistic" keeps the doll geometry and adds texture ON it, which reads as a
# skin disease at low quality (measured). Asking for a NEW person of the same
# casting in the same pose lets it draw a face it actually knows how to draw.
PROMPT = (
    "This is a product marketing photo. Keep the composition, the product, all on-image text, "
    "the clothing, the poses, the framing and the lighting direction exactly as they are. "
    "Replace each person's face with a DIFFERENT real human face: same gender, same approximate "
    "age, same hairstyle and hair color, a natural candid version of the same expression. "
    "Every person must stay in EXACTLY the same position, size and crop as in the original "
    "image; do not move, rescale or duplicate anyone. "
    "The new faces must look like real photographed people, not AI renders: natural skin with "
    "faint pores and small imperfections, slight facial asymmetry, normal teeth that are not "
    "uniform veneers, realistic eyes with catchlights, individual hair strands. "
    "No beauty-filter glow, no airbrushed skin, no orange tan, no added makeup. Neutral, "
    "believable skin tones with natural variation between regions of the face. "
    "The result should read as a candid lifestyle photograph shot on a professional camera."
)

FEATHER = 40   # px of inward taper on the mask edge; hides the seam
BOUNDARY_LIMIT = 8   # max mask opacity (of 255) allowed on the first ring inside a box


def _box_gauss(a, sigma, passes=3):
    """A Gaussian-shaped blur of a float 2-D array, in float, no clipping.

    Three box blurs of equal radius approximate a Gaussian of `sigma` (the
    same construction Pillow uses), done here on float64 with edge padding so
    the values never pass through a uint8. Version 1 blurred through a
    uint8 image offset by 128: the numerator survived (a difference within
    +-30 fits) but the WEIGHTS did not (255 + 128 clips to 255, and comes
    back as 127), so the denominator was half its true size and every
    correction overshot by about two (a constant +5 shift on a flat grey was
    "corrected" to -6; reproduced 10 September 2026)."""
    import numpy as np
    a = np.asarray(a, dtype=np.float64)
    r = max(1, int(round(sigma * (3.0 / passes) ** 0.5)))   # box radius per pass
    for _ in range(passes):
        for axis in (0, 1):
            n = a.shape[axis]
            if n < 2:
                continue
            pad = [(0, 0), (0, 0)]
            pad[axis] = (r, r)
            p = np.pad(a, pad, mode="edge")
            c = np.cumsum(p, axis=axis)
            c = np.concatenate([np.zeros_like(np.take(c, [0], axis=axis)), c], axis=axis)
            hi = np.take(c, range(2 * r + 1, 2 * r + 1 + n), axis=axis)
            lo = np.take(c, range(0, n), axis=axis)
            a = (hi - lo) / (2 * r + 1)
    return a


def _tone_match(orig, edit, box, pad=60):
    """Align the edited box's tone to the original, spatially.

    Version 1 applied ONE per-channel offset per box, computed on the ring
    around it. Measured result: the box still printed as a faint bright
    rectangle, because the render's exposure shift is not constant across the
    box, so a single number under-corrects one edge and over-corrects the
    other. This version builds an offset MAP instead: wherever the two images
    still agree (background the render left alone, within 30 levels), the
    difference is trusted; where they disagree (the new face), it is not; the
    trusted differences are blurred into a smooth field and added. The
    correction therefore follows the background's own gradient and fades to
    the interpolated value under the face."""
    import numpy as np
    from PIL import ImageFilter
    w, h = orig.size
    x1, y1 = max(0, box[0] - pad), max(0, box[1] - pad)
    x2, y2 = min(w, box[2] + pad), min(h, box[3] + pad)
    o = np.asarray(orig.crop((x1, y1, x2, y2)), dtype=np.float64)
    e = np.asarray(edit.crop((x1, y1, x2, y2)), dtype=np.float64)
    d = o - e
    agree = (np.abs(d).max(axis=2) < 30).astype(np.float64)
    if agree.sum() < 500:
        return edit          # nothing trustworthy to anchor on; leave it be
    # numerator and weights blurred in FLOAT (see _box_gauss): the field is
    # the weighted mean of the trusted differences, so a constant shift is
    # corrected by exactly that shift, never by twice it
    weight = _box_gauss(agree, 40)
    field = np.stack([
        _box_gauss(d[..., c] * agree, 40) / np.maximum(weight, 1e-3)
        for c in range(3)], axis=2)
    # The field repairs EXPOSURE seams; it must never repaint a face. Uncapped,
    # a green foliage ring bled a visible green tint onto a cheek (measured on
    # the roast-together frame). +-18 is plenty for a seam and too little to
    # recolor skin.
    field = np.clip(field, -18, 18)
    fixed = np.clip(e + field, 0, 255).astype("uint8")
    out = edit.copy()
    out.paste(Image.fromarray(fixed), (x1, y1))
    return out


def parse_boxes(spec: str):
    out = []
    for part in spec.split(";"):
        part = part.strip()
        if not part:
            continue
        nums = [int(v) for v in part.replace(" ", "").split(",")]
        if len(nums) != 4 or nums[0] >= nums[2] or nums[1] >= nums[3]:
            sys.exit(f"bad box '{part}': need x1,y1,x2,y2 with x1<x2 and y1<y2")
        out.append(tuple(nums))
    if not out:
        sys.exit("no boxes given. The clinic edits people; with no people boxes there is no edit.")
    return out


# size is ALWAYS "auto". Forcing a fixed size looked harmless and was not:
# a 1.86-ratio banner pushed through 1536x1024 (ratio 1.5) re-composed at the
# wrong aspect, and squashing it back moved every head out of its box, so the
# composite printed bright off-register rectangles. "auto" renders at the
# source's own aspect (measured: a 1464x600 input came back 1958x803, ratio
# preserved), which keeps the geometry aligned with the boxes.


IMG_EXT = {".png", ".jpg", ".jpeg", ".webp"}
# Temporary FIX suffixes only. A generation's own version (`sec-03-v2.png`, a
# regenerated slot) is a different asset with its own identity and stays. Kit
# v27 stripped `-v2` too, so a fix on sec-03-v2 landed as sec-03.png: one file's
# repair written onto another file's name (reproduced 9 September 2026).
_FIX_SUFFIX = re.compile(r"^(?P<base>.+?)[-_](?:fix\d+|faces-fixed(?:-v\d+)?)$", re.I)
# Evidence names the Fixing Room leaves inside a round on purpose: a failed
# attempt (`-rejected`, `-rejected-2`), the whole-frame render kept for the log
# (`-render`), a loose-file clinic output. None of them is a gallery member.
# The separator is `[-_]` here as in _FIX_SUFFIX: the two regexes must agree,
# or `sec-05_fix2.png` is adopted as a gallery member by one and stripped to
# `sec-05.png` by the other (reproduced 9 September 2026). `-boxes` is the
# drawn-box proof the Fixing Room and this clinic write beside a fix; the
# page builder skipped it and this resolver did not (kit v35), so a drawn
# copy could be adopted as a module or stacked as a neighbour (reproduced
# 10 September 2026). aplus_page.py IMPORTS is_evidence from here: one rule.
_EVIDENCE = re.compile(r".+[-_](?:rejected(?:-\d+)?|render|boxes|fix\d+|faces-fixed(?:-v\d+)?)$", re.I)
# The seam crops the A+ path writes beside the fixed modules (kit v33).
_SEAM = re.compile(r"^seam-\d+-\d+-\d+x$", re.I)


def canonical_name(src: Path) -> str:
    """main-06-faces-fixed.png -> main-06.png; edits/v2/main-06.png -> main-06.png;
    sec-03-v2.png -> sec-03-v2.png (a generation's version is its identity).

    The suffix is the source's own, verbatim. Kit v28 wrote every fix as .png,
    so a `sec-02.jpg` original was adopted into the round under its own name
    AND its fix landed beside it as `sec-02.png`: two files for one asset, and
    every name-based resolver kept serving the unfixed jpg (reproduced
    9 September 2026). One asset, one name, one file per round."""
    m = _FIX_SUFFIX.match(src.stem)
    return (m.group("base") if m else src.stem) + src.suffix


def is_evidence(name: str) -> bool:
    stem = Path(name).stem
    return bool(_EVIDENCE.match(stem) or _SEAM.match(stem))


def _gallery_files(folder: Path):
    """The adoptable image files in one folder: images, not hidden, not evidence."""
    if not folder.is_dir():
        return []
    return sorted(f for f in folder.iterdir()
                  if f.is_file() and f.suffix.lower() in IMG_EXT
                  and not f.name.startswith(".") and not is_evidence(f.name))


def rounds(product: Path):
    """[(1, edits/v1), (2, edits/v2), ...] in order."""
    edits = product / "edits"
    if not edits.is_dir():
        return []
    return sorted((int(d.name[1:]), d) for d in edits.iterdir()
                  if d.is_dir() and re.fullmatch(r"v\d+", d.name))


def adopted_set(product: Path):
    """name -> the ADOPTED copy of every gallery asset: the original in images/,
    replaced by its newest same-name copy from a round when one exists. An
    asset that exists only in images/ (generated after the last round) is in;
    an evidence file is never in. This is the one rule every room reads."""
    adopted = {f.name: f for f in _gallery_files(product / "images")}
    for _, d in rounds(product):
        for f in _gallery_files(d):
            adopted[f.name] = f
    return adopted


def product_dir(src: Path):
    """The product folder an image belongs to, or None for a loose file."""
    for a in src.resolve().parents:
        if (a / "images").is_dir() and (a / "status.md").is_file():
            return a
    return None


def open_round(product: Path) -> Path:
    """Open edits/v[N+1] as the ADOPTED SET (the Fixing Room's law, step 6).

    Kit v27 copied the previous round folder whole. Reproduced 9 September
    2026: Day 5 fixed the main into edits/v1, Day 6 generated eight secondaries
    into images/, and the next fix opened v2 holding only the main. The round
    is now built from adopted_set(): every asset, at its adopted version, and
    no evidence file. round.md records where each copy came from."""
    prev = rounds(product)
    n = (prev[-1][0] + 1) if prev else 1
    new = product / "edits" / f"v{n}"
    new.mkdir(parents=True)
    lines = [f"# edits/v{n}: the adopted set when this round opened", "",
             "| file | adopted from |", "|---|---|"]
    for name, src in sorted(adopted_set(product).items()):
        shutil.copy2(src, new / name)
        lines.append(f"| {name} | {src.relative_to(product)} |")
    # The A+ classes ride along, per mode, so the round is the full current set
    # (the Fixing Room's law: the latest edits/vN/ holds everything current).
    # The round records WHICH export its A+ set descends from (lineage.md), so
    # a later export of another concept under the same filenames never
    # inherits this round's fixes (see aplus_adopted_set). A round opened from
    # an earlier round inherits that round's record: its files descend from
    # the export THAT round was cut from, not from whatever sits in
    # aplus/export/ today.
    lineage = []
    for mode in APLUS_MODES:
        modules = aplus_adopted_set(product, mode)
        if not modules:
            continue
        (new / "aplus" / mode).mkdir(parents=True)
        for name, src in sorted(modules.items()):
            shutil.copy2(src, new / "aplus" / mode / name)
            lines.append(f"| aplus/{mode}/{name} | {src.relative_to(product)} |")
        lineage.append(f"{mode}: {_lineage_for(product, mode, modules)}")
    if lineage:
        (new / "aplus" / LINEAGE_FILE).write_text(
            "# lineage: the export each A+ mode in this round descends from\n"
            "# (a fingerprint of aplus/export/<mode>/ when the round opened; never edit)\n"
            + "\n".join(lineage) + "\n")
    (new / "round.md").write_text("\n".join(lines) + "\n")
    return new


def default_dst(src: Path) -> Path:
    prod = product_dir(src)
    if prod is None:
        dst = src.with_name(src.stem + "-faces-fixed" + src.suffix)
        n = 2
        while dst.exists():
            dst = src.with_name(f"{src.stem}-faces-fixed-v{n}{src.suffix}")
            n += 1
        return dst
    rnd = open_round(prod)
    print(f"opened {rnd.relative_to(prod)} as the adopted set; the fix takes its canonical name there")
    ctx = aplus_context(src)
    if ctx:
        return rnd / "aplus" / ctx[1] / canonical_name(src)
    return rnd / canonical_name(src)


# ---- A+ modules: one canvas cut into strips ---------------------------------
APLUS_MODES = ("desktop", "mobile")
EDGE_MARGIN = 0.12    # of the module height: a head this close to an edge continues past it
NECK_RATIO = 0.8      # neck and upper shoulders below a head box, in head heights
TOP_RATIO = 0.5       # hair and crown above a head box that meets a module's top edge
SHOULDER_RATIO = 0.35 # how far shoulders run past the head box, per side, in head widths
SEAM_BAND = 300       # px of page around a seam in the evidence crops
EDGE_BAND_LIMIT = 20  # mean levels the render may differ from the base where the feather lands
_MODULE = re.compile(r"^(?:m|(?:amz-)?module-)0*(\d+)(?:[-_].*)?$", re.I)
LAST_JOINT = {}       # what the last joined run did (the box, the modules, the crops); for the log and the tests


def module_num(name):
    """m1.png -> 1, m07-desktop.jpg -> 7, amz-module-04-hero-desktop.jpg -> 4, main-06.png -> None."""
    m = _MODULE.match(Path(name).stem)
    return int(m.group(1)) if m else None


def aplus_context(src: Path):
    """(product, mode, module number) when src is an A+ module: a module-named
    file under aplus/export/<mode>/ or edits/vN/aplus/<mode>/ in a product
    folder. None for a gallery frame or a loose file, which never stack."""
    prod = product_dir(src)
    if prod is None:
        return None
    rel = src.resolve().relative_to(prod).parts
    ok = ((len(rel) == 4 and rel[0] == "aplus" and rel[1] == "export" and rel[2] in APLUS_MODES)
          or (len(rel) == 5 and rel[0] == "edits" and re.fullmatch(r"v\d+", rel[1])
              and rel[2] == "aplus" and rel[3] in APLUS_MODES))
    num = module_num(rel[-1]) if ok else None
    return (prod, rel[-2], num) if num else None


LINEAGE_FILE = "lineage.md"   # edits/vN/aplus/lineage.md: "<mode>: <export fingerprint>" per mode
_NOTED = set()


def _note(msg):
    """Print a resolver note once per process (the resolver runs several times per fix)."""
    if msg not in _NOTED:
        _NOTED.add(msg)
        print(msg)


def export_fingerprint(product: Path, mode: str):
    """A short content hash of the export set of one mode (names and bytes of
    every module file in aplus/export/<mode>/), or None when there is no
    export. This is the identity of the SELECTED concept as it landed on
    disk: a different concept, mode or version exports different pixels."""
    import hashlib
    files = [f for f in _gallery_files(product / "aplus" / "export" / mode) if module_num(f.name)]
    if not files:
        return None
    h = hashlib.md5()
    for f in files:
        h.update(f.name.encode())
        h.update(f.read_bytes())
    return h.hexdigest()[:12]


def round_lineage(d: Path, mode: str):
    """The export fingerprint edits/vN/aplus/<mode> was built from ("none" when
    the round opened with no export), or None for a round from before the
    record existed (kit v35 and earlier)."""
    f = d / "aplus" / LINEAGE_FILE
    if not f.is_file():
        return None
    for line in f.read_text().splitlines():
        if line.startswith(f"{mode}:"):
            return line.split(":", 1)[1].strip()
    return None


# The chosen line's folder token in aplus/aplus-plan.md: `folder edits/v3/aplus/` or
# `folder aplus/export/desktop/` (an optional backtick on either side survives a rewrite).
_CHOSEN_TOKEN = re.compile(r"folder\s+(`?)(?:edits/v(?P<n>\d+)/aplus/?|aplus/export/?[^\s|`]*)(`?)", re.I)
_PLAN = ("aplus", "aplus-plan.md")


def chosen_folder(product: Path):
    """What aplus/aplus-plan.md's chosen line names: ("round", N) for
    `folder edits/vN/aplus/`, ("export", None) for `folder aplus/export/...`,
    None when no plan or no line names a folder. A line carrying "chosen" is
    read first; any other line carrying the token is the fallback."""
    plan = product.joinpath(*_PLAN)
    if not plan.is_file():
        return None
    lines = plan.read_text(errors="ignore").splitlines()
    for pick in (lambda s: "chosen" in s.lower(), lambda s: True):
        for line in lines:
            if not pick(line):
                continue
            m = _CHOSEN_TOKEN.search(line)
            if m:
                return ("round", int(m.group("n"))) if m.group("n") else ("export", None)
    return None


def chosen_round(product: Path):
    """The round the owner CHOSE, when aplus/aplus-plan.md's chosen line names
    one (`folder edits/v3/aplus/`); rounds above it are not the current set
    (the owner who prefers v1 after a v2 exists, /aplus step 10). None when
    the line names the export or is not written."""
    c = chosen_folder(product)
    return c[1] if c and c[0] == "round" else None


def set_chosen_round(product: Path, n: int) -> bool:
    """Point aplus/aplus-plan.md's chosen line at edits/vN/aplus/ after a fix
    round wrote A+ files there, so every resolver serves the round the fix
    just made. Reproduced 10 September 2026: the chosen line named v1, a fix
    opened v2 from it, and the ceiling kept serving v1 with no prose telling
    anyone to move the line. Rewrites only the folder token, keeps the rest of
    the row. Returns True when a line was rewritten; otherwise prints what to
    write by hand."""
    plan = product.joinpath(*_PLAN)
    want = f"edits/v{n}/aplus/"
    if plan.is_file():
        text = plan.read_text(errors="ignore")
        new, count = _CHOSEN_TOKEN.subn(lambda m: f"folder {m.group(1)}{want}{m.group(3)}", text)
        if count:
            if new != text:
                plan.write_text(new)
                print(f"aplus/aplus-plan.md: the chosen line now names {want}")
            return True
    print(f"update the chosen line in aplus/aplus-plan.md to `folder {want}` so every room serves this round")
    return False


def _round_num(path: Path):
    """edits/v3/aplus/desktop/m1.png -> 3; None when the path is not inside a round."""
    parts = path.resolve().parts
    for i, p in enumerate(parts[:-1]):
        if p == "edits" and re.fullmatch(r"v\d+", parts[i + 1]):
            return int(parts[i + 1][1:])
    return None


def aplus_adopted_set(product: Path, mode: str):
    """name -> the adopted copy of every module of one mode: the export in
    aplus/export/<mode>/, replaced by its newest same-name copy from a round's
    aplus/<mode>/ (a flat round file tagged -<mode> counts too), but ONLY from
    rounds the lineage-plus-chosen-line rule accepts. Seam crops and anything
    not named as a module are never in.

    The rule, in order:
    - The round the chosen line names (`folder edits/vN/aplus/`) is adopted
      on the owner's word, whatever its record says; rounds above it are not
      the current set; rounds below it are adopted when their lineage.md
      matches the chosen round's.
    - With no round named, a round is adopted when its lineage.md names the
      current export's fingerprint.
    - A round with no lineage record is never adopted while an export exists
      (reproduced 10 September 2026: concept A fixed in a hand-opened v1,
      concept B exported under the same seven names, and v1's old-concept
      files were served because the filenames matched).
    - A round whose record names another export, under the SAME filenames,
      with no chosen line to say which set is current, STOPS: a re-export of
      the same concept and a new concept under the same names are the same
      bytes-differ event, and only the owner can tell them apart (reproduced
      the same day: a re-export silently dropped every accepted round).
      Under DIFFERENT filenames the export is demonstrably another set and
      the round is passed over with a note.

    Kit v35 overlaid every round by filename alone: a seven-module concept
    fixed in v1, then a six-module concept exported under the same canonical
    names, resolved to seven modules, all from the old round."""
    export = {f.name: f for f in _gallery_files(product / "aplus" / "export" / mode) if module_num(f.name)}
    adopted = dict(export)
    fp = export_fingerprint(product, mode) or "none"
    choice = chosen_folder(product)
    ceiling = choice[1] if choice and choice[0] == "round" else None
    chosen_rec = round_lineage(product / "edits" / f"v{ceiling}", mode) if ceiling is not None else None
    for n, d in rounds(product):
        if ceiling is not None and n > ceiling:
            continue
        flat = [f for f in _gallery_files(d / "aplus") if f"-{mode}" in f.stem.lower()]
        files = [f for f in flat + _gallery_files(d / "aplus" / mode) if module_num(f.name)]
        if not files:
            continue
        rec = round_lineage(d, mode)
        if ceiling is not None and n == ceiling:
            pass                                    # the owner's word
        elif rec is None:
            if export:
                _note(f"edits/v{n}/aplus holds {mode} modules but carries no lineage record (a round opened by "
                      f"hand, or kit v35 or earlier), so it cannot be tied to the export on disk; not adopted. "
                      f"Rounds are opened with face_fix.open_round(); if this round IS the current set, name it "
                      f"in aplus/aplus-plan.md's chosen line as `folder edits/v{n}/aplus/`")
                continue
        elif ceiling is not None:
            if rec != chosen_rec:
                _note(f"edits/v{n}/aplus/{mode} descends from export {rec}; the chosen round edits/v{ceiling} "
                      f"descends from {chosen_rec}; not adopted")
                continue
        elif rec != fp:
            if choice is None and {f.name for f in files} == set(export):
                sys.exit(f"STOP: aplus/export/{mode}/ changed after edits/v{n}/aplus/{mode} was fixed (the round "
                         f"descends from export {rec}, the export on disk is {fp}) and both hold the same "
                         f"{len(export)} filenames, so nothing on disk says whether this is a re-export of the same "
                         f"concept or a new concept under the same names. Say which set is current in "
                         f"aplus/aplus-plan.md's chosen line: `folder edits/v{n}/aplus/` keeps the round's fixes, "
                         f"`folder aplus/export/{mode}/` starts again from the export. Nothing adopted, nothing spent")
            _note(f"edits/v{n}/aplus/{mode} descends from export {rec}; the current export is {fp}; not adopted")
            continue
        for f in files:
            adopted[f.name] = f
    return adopted


def _lineage_for(product: Path, mode: str, modules: dict):
    """The record a new round writes for one mode: the lineage of the round its
    modules were adopted from when any came from a round (a round opened from
    v1 descends from what v1 descends from, whatever the export on disk says
    now), else the current export's fingerprint."""
    from_rounds = [(_round_num(p), p) for p in modules.values() if _round_num(p) is not None]
    if from_rounds:
        n = max(k for k, _ in from_rounds)
        rec = round_lineage(product / "edits" / f"v{n}", mode)
        if rec is not None:
            return rec
    return export_fingerprint(product, mode) or "none"


def joined_modules(boxes, size, num, adopted):
    """The modules to stack for these head boxes, in page order: the module
    alone when every head sits clear of both edges, else with the neighbour(s)
    a head runs into (within EDGE_MARGIN of an edge, or past it)."""
    w, h = size
    margin = round(EDGE_MARGIN * h)
    need = {num}
    for (x1, y1, x2, y2) in boxes:
        if y1 <= margin:
            need.add(num - 1)
        if y2 >= h - margin:
            need.add(num + 1)
    have = {module_num(name): path for name, path in adopted.items()}
    return [(n, have[n]) for n in sorted(need) if n in have]


def joint_box(box, seams, size, module_h, grow=1.0):
    """Grow a head box (already in joined coordinates) to hold the person
    across the seam(s) it approaches: neck and shoulders below a head that
    meets a seam from above, crown above a head that starts at a seam,
    shoulders sideways, and at least EDGE_MARGIN of the module past every seam
    it meets. A box never ends on the seam. `grow` scales the vertical reach
    (the automatic retry passes 2)."""
    w, h = size
    x1, y1, x2, y2 = box
    hh, hw = y2 - y1, x2 - x1
    margin = round(EDGE_MARGIN * module_h)
    # read the seam relation off the box as DRAWN; growing y2 for one seam must
    # not make the same box look like a head starting at that seam
    down = any(y2 >= s - margin and y1 < s for s in seams)
    up = any(s - margin <= y1 <= s + margin and y2 > s for s in seams)
    for s in seams:
        if down and y1 < s:
            y2 = max(y2, s + margin)
        if up and y2 > s:
            y1 = min(y1, s - margin)
    if down:
        y2 += round(NECK_RATIO * hh * grow)
    if up:
        y1 -= round(TOP_RATIO * hh * grow)
    if down or up:
        x1 -= round(SHOULDER_RATIO * hw)
        x2 += round(SHOULDER_RATIO * hw)
    return (max(0, x1), max(0, y1), min(w, x2), min(h, y2)), (down, up)


# ---- the protect boxes: the product and the text, named so the region can be validated ----
def parse_protect(spec):
    """Protect boxes in the head boxes' coordinates; the list may be empty and a
    box may run past the image (it is clipped where it is used)."""
    out = []
    for part in (spec or "").split(";"):
        part = part.strip()
        if not part:
            continue
        nums = [int(v) for v in part.replace(" ", "").split(",")]
        if len(nums) != 4 or nums[0] >= nums[2] or nums[1] >= nums[3]:
            sys.exit(f"bad protect box '{part}': need x1,y1,x2,y2 with x1<x2 and y1<y2")
        out.append(tuple(nums))
    return out


def _overlap(a, b):
    return a[0] < b[2] and b[0] < a[2] and a[1] < b[3] and b[1] < a[3]


def check_protect(boxes, protects, what="head box"):
    """A drawn box that overlaps a protect box is a contradiction: refused before any spend."""
    for b in boxes:
        for p in protects:
            if _overlap(b, p):
                sys.exit(f"REFUSED: {what} {b} overlaps protect box {p}; a box never touches the product "
                         f"or the text. Redraw one of them; nothing spent")


def clamp_to_protect(box, drawn, protects):
    """Trim a GROWN box back until it clears every protect box, never inside
    the head box as drawn. Each step takes the single trim that loses the
    least area, so a fountain beside the head costs the sideways growth and
    keeps the neck, and a text line under the neck costs the depth and keeps
    the shoulders. Returns the trimmed box; the caller validates it."""
    x1, y1, x2, y2 = box
    dx1, dy1, dx2, dy2 = drawn
    for _ in range(32):
        hit = [p for p in protects if _overlap((x1, y1, x2, y2), p)]
        if not hit:
            break
        px1, py1, px2, py2 = hit[0]
        options = []
        if x1 < dx1 and px2 > x1 and px1 < dx1:            # the left growth strip
            nx1 = min(dx1, max(x1, px2))
            options.append(((nx1 - x1) * (y2 - y1), (nx1, y1, x2, y2)))
        if x2 > dx2 and px1 < x2 and px2 > dx2:            # the right growth strip
            nx2 = max(dx2, min(x2, px1))
            options.append(((x2 - nx2) * (y2 - y1), (x1, y1, nx2, y2)))
        if y2 > dy2 and py1 < y2 and py2 > dy2:            # below the head
            ny2 = max(dy2, min(y2, py1))
            options.append(((y2 - ny2) * (x2 - x1), (x1, y1, x2, ny2)))
        if y1 < dy1 and py2 > y1 and py1 < dy1:            # above the head
            ny1 = min(dy1, max(y1, py2))
            options.append(((ny1 - y1) * (x2 - x1), (x1, ny1, x2, y2)))
        options = [o for o in options if o[1] != (x1, y1, x2, y2)]
        if not options:
            break                                          # the drawn box itself overlaps: check_protect's case
        # the cheapest trim that CLEARS this protect box; a trim that leaves the overlap standing
        # (six pixels off the left while a text line runs under the neck) is progress, not a choice
        clearing = [o for o in options if not _overlap(o[1], hit[0])]
        _, (x1, y1, x2, y2) = min(clearing or options, key=lambda o: o[0])
    return (x1, y1, x2, y2)


def validate_joint(box, drawn, sides, seams, module_h, protects):
    """The final edit region after growth and trimming: clear of every protect
    box, and still past every seam it was grown for by EDGE_MARGIN of the
    module (a box that ends on the seam is the cut-neck failure). Exits
    before any spend otherwise."""
    check_protect([box], protects, what="joint box")
    x1, y1, x2, y2 = box
    down, up = sides
    margin = round(EDGE_MARGIN * module_h)
    for s in seams:
        if down and drawn[1] < s <= drawn[3] + margin and y2 < s + margin:
            sys.exit(f"REFUSED: the joint box {box} cannot reach past the seam at y={s} without touching a "
                     f"protect box, so the person would be cut at the module edge. Redraw the protect box, "
                     f"or draw the head box down past the shoulders; nothing spent")
        if up and drawn[3] > s and drawn[1] - margin <= s <= drawn[1] + margin and y1 > s - margin:
            sys.exit(f"REFUSED: the joint box {box} cannot reach above the seam at y={s} without touching a "
                     f"protect box; redraw the protect box or the head box; nothing spent")


def draw_region(im, heads, joints, protects, path: Path):
    """The proof: head boxes red, the final edit region orange, protect boxes
    blue, on a copy. Written BEFORE the model is called and copied into the
    round as `<name>-boxes.png` (an evidence file, never adopted)."""
    out = im.convert("RGB").copy()
    d = ImageDraw.Draw(out)
    lw = max(2, min(out.size) // 300)
    for (x1, y1, x2, y2) in protects:
        d.rectangle((max(0, x1), max(0, y1), min(out.size[0], x2) - 1, min(out.size[1], y2) - 1),
                    outline=(40, 90, 255), width=lw)
    for (x1, y1, x2, y2) in joints:
        d.rectangle((x1, y1, x2 - 1, y2 - 1), outline=(255, 140, 0), width=lw + 1)
    for (x1, y1, x2, y2) in heads:
        d.rectangle((x1, y1, x2 - 1, y2 - 1), outline=(255, 40, 40), width=lw)
    legend = "red = head box as drawn   orange = the region the edit may land in   blue = protected"
    d.rectangle((0, 0, 12 + int(d.textlength(legend)), 22), fill=(24, 20, 28))
    d.text((6, 6), legend, fill=(240, 226, 200))
    out.save(path)
    return path


def edge_band_disagreement(orig, edited, box, sides, band=FEATHER):
    """Mean levels the render differs from the base inside the box's edge
    band(s) on the grown side(s), where the feather lands. Quiet background
    reads near 0; a re-rendered shoulder reads high, and the fade would then
    print a soft line across the garment (the dark-hoodie failure)."""
    import numpy as np
    x1, y1, x2, y2 = box
    down, up = sides
    o = np.asarray(orig, dtype=int)
    e = np.asarray(edited, dtype=int)
    worst = 0.0
    if down:
        worst = max(worst, float(np.abs(o[max(y1, y2 - band):y2, x1:x2] - e[max(y1, y2 - band):y2, x1:x2]).mean()))
    if up:
        worst = max(worst, float(np.abs(o[y1:min(y2, y1 + band), x1:x2] - e[y1:min(y2, y1 + band), x1:x2]).mean()))
    return worst


def load_key():
    """OPENAI_API_KEY from the environment, else the nearest .env upward (the
    factory root .env is where /machines-check put it)."""
    if os.environ.get("OPENAI_API_KEY"):
        return
    for a in [Path.cwd()] + list(Path.cwd().parents):
        f = a / ".env"
        if f.is_file():
            for line in f.read_text(errors="ignore").splitlines():
                if line.strip().startswith("OPENAI_API_KEY="):
                    os.environ["OPENAI_API_KEY"] = line.split("=", 1)[1].strip().strip('"').strip("'")
                    return


def _edit(client, path: Path, prompt, quality, size):
    """One images.edit call on the file at `path`, returned on `size`'s grid."""
    r = client.images.edit(model=image_model(), image=[open(path, "rb")],
                           prompt=prompt, size="auto", quality=quality, n=1)
    edited = Image.open(__import__("io").BytesIO(base64.b64decode(r.data[0].b64_json)))
    return edited.convert("RGB").resize(size, Image.LANCZOS)


def _feather_mask(size, boxes, feather=FEATHER):
    """The blend mask: 0 outside every box, and inside a box a smooth ramp
    from (near) 0 at the box's first pixel to 255 `feather` pixels in, by the
    pixel's distance to the nearest box edge; boxes union by max. A side that
    meets the image edge gets no ramp (there is no seam there). The ramp is
    capped at a third of the box's short side so a small box still lands at
    full strength in its middle.

    Kit v28 to v35 blurred a filled rectangle and CLIPPED it to the box, which
    keeps every outside pixel original and leaves half the render's opacity on
    the first pixel inside: black base, white render, box (80,80,320,320)
    read 0 / 130 / 255 at the pixel outside, the first inside, the centre
    (reproduced 10 September 2026). A hard step at the boundary is a visible
    edge whatever the outside count says. The ramp reaches the original AT the
    boundary; boundary_ring_max() below is the check."""
    import numpy as np
    w, h = size
    m = np.zeros((h, w), dtype=np.float64)
    inf = float("inf")
    for (x1, y1, x2, y2) in boxes:
        cx1, cy1, cx2, cy2 = max(0, x1), max(0, y1), min(w, x2), min(h, y2)
        if cx2 <= cx1 or cy2 <= cy1:
            continue
        f = max(1, min(feather, min(x2 - x1, y2 - y1) // 3))
        xs = np.arange(cx1, cx2, dtype=np.float64)
        ys = np.arange(cy1, cy2, dtype=np.float64)
        # distance 0 on the first pixel inside (so it stays the original exactly), f pixels in = full
        dx = np.minimum(xs - x1 if x1 > 0 else inf, x2 - 1 - xs if x2 < w else inf)
        dy = np.minimum(ys - y1 if y1 > 0 else inf, y2 - 1 - ys if y2 < h else inf)
        d = np.minimum.outer(dy, dx)
        t = np.clip(d / f, 0.0, 1.0)
        v = 255.0 * t * t * (3.0 - 2.0 * t)   # smoothstep: no kink at either end
        m[cy1:cy2, cx1:cx2] = np.maximum(m[cy1:cy2, cx1:cx2], v)
    return Image.fromarray(np.round(m).astype("uint8"), "L")


def boundary_ring_max(mask, allowed):
    """The highest mask opacity on the first ring INSIDE the allowed area
    (pixels inside whose 4-neighbour is outside). Near 0 means the blend
    reaches the original at the boundary; 130 was the old clipped blur."""
    import numpy as np
    a = np.asarray(allowed, dtype=bool)
    m = np.asarray(mask, dtype=int)
    if not a.any():
        return 0
    pad = np.pad(a, 1, constant_values=False)
    outside_neighbour = (~pad[:-2, 1:-1]) | (~pad[2:, 1:-1]) | (~pad[1:-1, :-2]) | (~pad[1:-1, 2:])
    # a ring pixel on the image edge has no outside neighbour there; the pad counts it as outside,
    # which is the conservative reading only when the box does not meet the image edge
    h, w = a.shape
    edge = np.zeros_like(a)
    edge[0, :] = edge[-1, :] = True
    edge[:, 0] = edge[:, -1] = True
    ring = a & outside_neighbour & ~edge
    return int(m[ring].max()) if ring.any() else 0


def _composite(im, edited, boxes):
    """The render's boxes over the original, through the inward feather.
    Returns (result, allowed, inside, outside, ring); refuses when outside is
    not 0 or when the blend does not reach the original at the boundary."""
    w, h = im.size
    for b in boxes:
        edited = _tone_match(im, edited, b)
    # the mask IS the contract: white = the edit may land, black = original pixels.
    # Two masks, on purpose. `allowed` is the plain box union, the contract the
    # operator drew. `mask` is the tapered one the composite uses, and it is 0
    # outside `allowed` by construction (kit v27 blurred outward, so a ring of
    # up to FEATHER/2 px outside every box took render pixels; measured
    # 9 September 2026, 25,850 pixels on a 256x256 test frame).
    allowed = Image.new("L", (w, h), 0)
    da = ImageDraw.Draw(allowed)
    for (x1, y1, x2, y2) in boxes:
        da.rectangle((x1, y1, x2 - 1, y2 - 1), fill=255)   # [x1, x2) x [y1, y2)
    mask = _feather_mask((w, h), boxes)
    mask = Image.composite(mask, Image.new("L", (w, h), 0), allowed)
    ring = boundary_ring_max(mask, allowed)
    if ring > BOUNDARY_LIMIT:
        sys.exit(f"REFUSED: the blend mask is {ring}/255 on the first pixel inside a box; the feather must reach "
                 f"the original at the boundary (limit {BOUNDARY_LIMIT}); nothing written")

    result = Image.composite(edited, im, mask)
    inside, outside = outside_changed(im, result, allowed)
    if outside:
        sys.exit(f"REFUSED: {outside} pixels changed outside the head boxes; nothing written")
    return result, allowed, inside, outside, ring


def _save(img, dst: Path):
    # The fix is written in the source's own format so the round holds ONE file
    # per asset. JPEG recompresses on save; 95 keeps the repaired faces intact.
    save_kw = {"quality": 95} if dst.suffix.lower() in (".jpg", ".jpeg") else {}
    img.save(dst, **save_kw)


def _proof_path(stem: str) -> Path:
    import tempfile
    return Path(tempfile.mkdtemp()) / f"{stem}-boxes.png"


def run(src: Path, boxes, quality="high", out: Path | None = None, prompt: str = PROMPT,
        protect=(), dry_run=False):
    """`protect`: boxes the edit may never touch (the product, the text), in the
    head boxes' coordinates. `dry_run`: validate, write the region proof, print
    it, spend nothing, return the proof's path."""
    ctx = aplus_context(src)
    if ctx:
        prod, mode, num = ctx
        adopted = aplus_adopted_set(prod, mode)
        cur = adopted.get(src.name)
        if cur is not None and cur.resolve() != src.resolve():
            print(f"using the adopted copy {cur.relative_to(prod)} (newer than {src.relative_to(prod)})")
            src = cur
        parts = joined_modules(boxes, Image.open(src).size, num, adopted)
        widths = {Image.open(p).size[0] for _, p in parts}
        if len(parts) > 1 and len(widths) == 1:
            return run_joined(prod, mode, num, parts, boxes, quality, out, prompt, list(protect), dry_run)
        if len(parts) > 1:
            print(f"modules differ in width ({sorted(widths)}); not one canvas, so fixing {src.name} alone")
    im = Image.open(src).convert("RGB")
    w, h = im.size
    for (x1, y1, x2, y2) in boxes:
        if x1 < 0 or y1 < 0 or x2 > w or y2 > h:
            sys.exit(f"box ({x1},{y1},{x2},{y2}) falls outside the {w}x{h} image")
    protect = list(protect)
    check_protect(boxes, protect)
    proof = draw_region(im, boxes, [], protect, _proof_path(canonical_name(src).rsplit(".", 1)[0]))
    print(f"region proof: {proof} (red = the boxes the edit may land in, blue = protected). READ it before spending")
    if dry_run:
        print("dry run: nothing spent, nothing written")
        return proof
    # The round opens BEFORE the spend (the Fixing Room's step 6): opening it
    # runs the A+ resolver, and a resolver that stops on an ambiguous export
    # must stop before the render is paid for, not after.
    dst = out or default_dst(src)
    from openai import OpenAI
    client = OpenAI()
    edited = _edit(client, src, prompt, quality, (w, h))
    result, allowed, inside, outside, ring = _composite(im, edited, boxes)
    _save(result, dst)
    shutil.copy2(proof, dst.with_name(dst.stem + "-boxes.png"))
    print(f"{inside} pixels changed inside the boxes, {outside} outside; blend {ring}/255 at the boundary "
          f"(technical: the eyes still judge the seam)")
    if ctx and out is None and _round_num(dst) is not None:
        set_chosen_round(ctx[0], _round_num(dst))
    return dst


def run_joined(prod, mode, num, parts, boxes, quality, out, prompt, protect=(), dry_run=False):
    """The cross-module fix. `parts` is [(module number, adopted path)] in page
    order, two or three of them, the fixed module among them. One edit on the
    joined image, one composite, a re-cut at the original boundaries.

    The region is validated BEFORE the spend on every attempt: the joint box is
    grown, trimmed back off every protect box, checked to still cross the
    seam, drawn on the joined image and printed. A second attempt that still
    fails the edge-band check is NOT promoted: it is written as `-rejected`
    evidence beside the retained parents and the run exits non-zero (kit v35
    wrote it as the fix)."""
    import tempfile
    ims = [(n, p, Image.open(p).convert("RGB")) for n, p in parts]
    ims_by = {n: im for n, _, im in ims}
    w = ims[0][2].size[0]
    offsets, y = {}, 0
    for n, _, im in ims:
        offsets[n] = y
        y += im.size[1]
    joined = Image.new("RGB", (w, y))
    for n, _, im in ims:
        joined.paste(im, (0, offsets[n]))
    seams = [offsets[n] for n, _, _ in ims[1:]]
    jh = joined.size[1]
    names = "+".join(f"m{n}" for n, _, _ in ims)
    print(f"the head meets a module edge: joined {names} ({w}x{jh}) and fixing across the seam")

    shifted = [(x1, y1 + offsets[num], x2, y2 + offsets[num]) for (x1, y1, x2, y2) in boxes]
    for (x1, y1, x2, y2) in shifted:
        if x1 < 0 or y1 < 0 or x2 > w or y2 > jh:
            sys.exit(f"box ({x1},{y1},{x2},{y2}) falls outside the joined {w}x{jh} image")
    protect = [(x1, y1 + offsets[num], x2, y2 + offsets[num]) for (x1, y1, x2, y2) in protect]
    check_protect(shifted, protect)
    tmp = Path(tempfile.mkdtemp()) / f"joined-{names}.png"
    joined.save(tmp)
    module_h = ims_by[num].size[1]

    def region(grow, draw=True):
        """The final edit region for this attempt: grown, trimmed, validated, drawn."""
        jb, sd = [], []
        for b in shifted:
            g, s = joint_box(b, seams, (w, jh), module_h, grow)
            g = clamp_to_protect(g, b, protect)
            validate_joint(g, b, s, seams, module_h, protect)
            jb.append(g)
            sd.append(s)
        if not draw:
            return jb, sd, None
        proof = draw_region(joined, shifted, jb, protect, _proof_path(f"joined-{names}"))
        print(f"joint box {jb} on the joined {names} (grown by {grow:g}); region proof: {proof} "
              f"(red = head as drawn, orange = the region the edit may land in, blue = protected). READ it before spending")
        return jb, sd, proof

    jboxes, sides, proof = region(1.0)
    # The retry's region is settled BEFORE attempt 1 is paid for. Reproduced
    # 10 September 2026: a --protect box capped the growth, so the grow=2
    # region equalled attempt 1's and the second paid edit was a re-roll while
    # the note claimed growth; and a retry region that fails validation used
    # to sys.exit after the first spend with nothing written.
    no_retry = ""
    try:
        retry_boxes, _, _ = region(2.0, draw=False)
        if retry_boxes == jboxes:
            no_retry = ("the grown region equals attempt 1's (a --protect box caps the growth), so a second "
                        "edit would be a re-roll, not a wider box; no automatic retry")
    except SystemExit as e:
        no_retry = f"the grown region is refused ({e}), so no automatic retry"
    if no_retry:
        print(f"note: {no_retry}")
    if dry_run:
        print("dry run: nothing spent, nothing written")
        return proof
    # the round opens before the spend, so a resolver stop costs nothing (see run())
    if out is not None:
        dest = {num: out}
        for n, p, _ in ims:
            dest.setdefault(n, out.parent / p.name)
    else:
        rnd = open_round(prod)
        print(f"opened {rnd.relative_to(prod)} as the adopted set; the fixed modules take their own names in aplus/{mode}/")
        (rnd / "aplus" / mode).mkdir(parents=True, exist_ok=True)
        dest = {n: rnd / "aplus" / mode / canonical_name(p) for n, p, _ in ims}
    from openai import OpenAI
    client = OpenAI()
    note, band = "", 0.0
    for attempt in (1, 2):
        edited = _edit(client, tmp, prompt, quality, (w, jh))
        band = max(edge_band_disagreement(joined, edited, b, s) for b, s in zip(jboxes, sides))
        if band <= EDGE_BAND_LIMIT:
            break
        if attempt == 1:
            if no_retry:
                note = (f"the feather landed on changed content (the render differs from the base by "
                        f"{band:.0f} levels in the box's edge band); {no_retry}")
                print(note)
                break
            note = (f"the feather landed on changed content (the render differs from the base by "
                    f"{band:.0f} levels in the box's edge band); one automatic retry with the box "
                    f"grown by the neck and shoulder height")
            print(note)
            jboxes, sides, proof = region(2.0)      # re-validated: the retry's box is a new region
    failed = band > EDGE_BAND_LIMIT
    result, allowed, inside, outside, ring = _composite(joined, edited, list(jboxes))

    # re-cut at exactly the original boundaries; write every module the box union touches
    if failed:
        # evidence only: the attempt beside the RETAINED parents, nothing promoted
        kept = []
        for n, p, im in ims:
            y0, y1 = offsets[n], offsets[n] + im.size[1]
            if not allowed.crop((0, y0, w, y1)).getbbox():
                continue
            ev = dest[n].with_name(dest[n].stem + "-rejected" + dest[n].suffix)
            _save(result.crop((0, y0, w, y1)), ev)
            kept.append(ev)
        shutil.copy2(proof, dest[num].with_name(dest[num].stem + "-boxes.png"))
        LAST_JOINT.clear()
        LAST_JOINT.update({"modules": [n for n, _, _ in ims], "box": tuple(jboxes[0]), "boxes": list(jboxes),
                           "attempts": attempt, "note": note, "written": [], "evidence": kept, "rejected": True})
        sys.exit(f"FAILED after {attempt} attempts: the render still differs from the base by {band:.0f} levels "
                 f"where the feather lands (limit {EDGE_BAND_LIMIT}), so the fade would print a line across the "
                 f"person. The attempt is kept as evidence ({', '.join(e.name for e in kept)}) beside the unchanged "
                 f"adopted modules; nothing was promoted. Draw the head box down past the shoulders, or add "
                 f"--protect for what the box must avoid, and run again")
    touched = []
    for n, p, im in ims:
        y0, y1 = offsets[n], offsets[n] + im.size[1]
        if not allowed.crop((0, y0, w, y1)).getbbox():
            continue
        _save(result.crop((0, y0, w, y1)), dest[n])
        touched.append((n, dest[n]))
    shutil.copy2(proof, dest[num].with_name(dest[num].stem + "-boxes.png"))
    written = ", ".join(f"{d.name} {ims_by[n].size[0]}x{ims_by[n].size[1]}" for n, d in touched)
    print(f"{inside} pixels changed inside the joint box, {outside} outside; blend {ring}/255 at the boundary (technical only)")
    print(f"joint box {list(jboxes)} on the joined image; re-cut at the module boundaries: {written} in {touched[0][1].parent}")

    # the continuity read, produced for the eyes: the page rebuilt from the fixed set
    folder = touched[0][1].parent
    page_set = {n: p for n, p in ((module_num(f.name), f) for f in _gallery_files(folder)) if n}
    for n, d in touched:
        page_set[n] = d
    page_ims = [(n, Image.open(page_set[n]).convert("RGB")) for n in sorted(page_set)]
    pw = max(im.size[0] for _, im in page_ims)
    page_off, y = {}, 0
    for n, im in page_ims:
        page_off[n] = y
        y += im.size[1]
    page = Image.new("RGB", (pw, y), "white")
    for n, im in page_ims:
        page.paste(im, (0, page_off[n]))
    shift = page_off[ims[0][0]] - offsets[ims[0][0]]
    ux1 = min(b[0] for b in jboxes)
    uy1 = min(b[1] for b in jboxes) + shift
    ux2 = max(b[2] for b in jboxes)
    uy2 = max(b[3] for b in jboxes) + shift
    crops = []
    for (a, _), (b, _) in zip(touched, touched[1:]):
        s = page_off[b]
        band_im = page.crop((0, max(0, s - SEAM_BAND // 2), pw, min(page.size[1], s + SEAM_BAND // 2)))
        two_x = folder / f"seam-{a}-{b}-2x.png"
        band_im.resize((band_im.size[0] * 2, band_im.size[1] * 2), Image.LANCZOS).save(two_x)
        cw, ch = ux2 - ux1, uy2 - uy1
        ctx_box = (max(0, ux1 - cw // 2), max(0, uy1 - ch // 2), min(pw, ux2 + cw // 2), min(page.size[1], uy2 + ch // 2))
        one_x = folder / f"seam-{a}-{b}-1x.png"
        page.crop(ctx_box).save(one_x)
        crops += [two_x, one_x]
        print(f"evidence: {two_x} (the seam band at 2x), {one_x} (1:1, the whole person)")
    print("READ BOTH before calling this done: head, neck, hair and lighting must be continuous across the seam. "
          "The counts above are technical. A visible seam or an unnatural body join FAILS this fix even at "
          "0 outside; the answer is a wider joint box (grow it by the neck and shoulder height) and another run.")
    LAST_JOINT.clear()
    LAST_JOINT.update({"modules": [n for n, _, _ in ims], "box": tuple(jboxes[0]), "boxes": list(jboxes),
                       "attempts": attempt, "note": note, "written": [d for _, d in touched], "evidence": crops})
    if out is None and _round_num(dest[num]) is not None:
        set_chosen_round(prod, _round_num(dest[num]))
    return dest[num]


def outside_changed(original, result, allowed):
    """(inside, outside) pixel counts that differ, measured against the plain
    box union, never against the feathered mask the composite was built from.
    Measuring against the blurred mask counts every pixel the blur reached as
    inside, which is how a leak reports as zero."""
    import numpy as np
    a = np.asarray(original.convert("RGB"), dtype=int)
    b = np.asarray(result.convert("RGB"), dtype=int)
    changed = np.abs(a - b).max(axis=2) > 0
    box = np.asarray(allowed, dtype=bool)
    return int(changed[box].sum()), int(changed[~box].sum())


def main():
    args = sys.argv[1:]
    if not args or "--boxes" not in args:
        sys.exit(__doc__)
    src = Path(args[0])
    if not src.is_file():
        sys.exit(f"no such image: {src}")
    boxes = parse_boxes(args[args.index("--boxes") + 1])
    quality = args[args.index("--quality") + 1] if "--quality" in args else "high"
    out = Path(args[args.index("--out") + 1]) if "--out" in args else None
    protect = parse_protect(args[args.index("--protect") + 1]) if "--protect" in args else []
    dry_run = "--dry-run" in args
    prompt = PROMPT
    if "--prompt-file" in args:
        prompt = Path(args[args.index("--prompt-file") + 1]).read_text()
    if dry_run:
        run(src, boxes, quality, out, prompt, protect, dry_run=True)
        return
    load_key()
    if not os.environ.get("OPENAI_API_KEY"):
        sys.exit("OPENAI_API_KEY is not set. The clinic runs on Machine 2; add the key to the .env.")
    dst = run(src, boxes, quality, out, prompt, protect)
    print(f"wrote {dst}")


if __name__ == "__main__":
    main()

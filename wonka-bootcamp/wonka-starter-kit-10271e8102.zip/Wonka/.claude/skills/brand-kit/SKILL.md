---
name: brand-kit
description: OPTIONAL brand styling. Reads a real Brand Book or Style Guide the owner already owns, and when the owner runs this room WITHOUT one and asks for it, proposes a starting direction they approve. Never offered unprompted, and never proposed without an explicit yes. Extracts the colors, typography, tone, approved claims and avoid list that guide actually establishes, and carries them into the Genrupt branding preset. It never invents a brand: with no Brand Book and no Style Guide there is nothing to run and the line continues unbranded. It does not handle the logo file; a real logo is uploaded and wired by /reference-sheet, with or without any styling. Run once per brand, reused by every product. Use when the owner HAS a Brand Book or Style Guide. Triggers: /brand-kit, "brand kit", "here is our brand book", "here is our style guide", "brand guidelines", "our brand colors are documented", "approved claims", "avoid list".
---

# The Brand Room

| Meta | Value |
|------|-------|
| Room | The Brand Room |
| Station | OPTIONAL, and not a lesson of its own. Day 4 mentions it in one line after the sheets are approved, for the owners who have a real Brand Book or Style Guide; run it there and the smoke test carries the styling. Nothing in the factory waits for this room |
| Needs | A real **Brand Book or Style Guide** the owner already owns, in `2-reference/brand/` or attached to Claude. **With no such document this room is not blocked, it is narrowed**: it asks once whether the owner wants a proposed starting direction, and a no ends it in a line. Running unbranded is a complete answer, not a gap |
| Saves to | The resolved brand's kit file (`factory/Brand/brand-kit.md` for the first brand, `factory/Brand/brand-kit-[brand-slug].md` for every later one) and that brand's own Genrupt branding preset. The preset id is recorded in the kit file AND in the `status.md` `Genrupt preset ID` row of every product associated with that kit, which is the row every other room reads |
| Typical cost | Free. Interview, analysis, and preset creation cost no credits. Only the preset step touches the Genrupt machine at all |

## What this room does

A brand that already wrote its rules down should not have to say them again. This room READS the
owner's real Brand Book or Style Guide and carries what that document actually establishes into
two artifacts: the **kit file** (colors with real hex codes, font direction, tone, approved
claims, an explicit avoid list) and the **Genrupt branding preset** that carries the colors and font
direction into every generation. Built once per brand; every product of that brand reuses it.

**This room does not choose a style image.** The look of the set is chosen on Day 6, from real
generated frames, when the owner picks a style and sends it to Refine (`/secondary-images`, mode 2).
Asking an owner to pick "the one image that says make it feel like this" before a single image
exists is a question nobody can answer well, so it is not asked here. `references.styleImage` stays
unset by this room.

**Two style concepts, two names.** The **Brand style image** is `references.styleImage`: brand-level,
persistent, one image for every product under the brand, and unset in the bootcamp flow. The
**Refine style reference** is what Day 6 chooses inside one product's Listing Builder set
(`/secondary-images`, `set_listing_builder_style_reference`), and the A+ of that product inherits it.
They are never the same thing and never called by each other's name. A Day 6 choice stays with its
set; it becomes the brand's style image only when the owner asks this room to promote it, explicitly,
and this room writes it then and only then.

**This room never writes a brand UNBIDDEN, and the trigger is the whole difference.** Wonka does not
raise branding on his own, does not offer this room downstream, and never treats a missing brand
system as homework. A seller without a documented brand is not behind; their images are styled by
the product itself, which is a real and measured outcome.

**But an owner who deliberately runs `/brand-kit` has asked for brand styling, and that is a
different act.** With no guide on file this room asks ONE question, and only an explicit yes lets it
propose a starting direction. That proposal is labelled a proposal everywhere it lands, so no later
room mistakes it for a fact about the brand. A no ends the room in one line.

**The logo is not in this room.** A real logo file is uploaded and wired into Genrupt by
`/reference-sheet`, whether or not any brand styling exists, and whether or not this room ever runs.
Genrupt happens to carry both a logo and brand styling on the same preset, but that is a transport
detail of the API, not a dependency between them: a logo needs no Brand Book, and a Brand Book needs
no logo.

One thing this room is quietly responsible for. It is the **compliance firewall**: when a kit exists, the approved claims table is the list of claims allowed onto an image (beside text on the real label and facts verified in the reference record and approved in the brief), decided once while calm instead of forty times in a hurry. The file and the claims work need no machine and no credits, so when Genrupt is down this is the work that still moves. Only the preset push waits for the machine, and it is recorded as waiting rather than skipped.

**The style contract (house decision 4, and it is absolute):** brand style travels ONLY through the branding preset, and the set's look is chosen later, on Day 6, through Refine. Generation rooms pass `brandingPresetId` inside `projectSetup`, and that is this room's whole delivery. Hex codes, font names, and style prose never appear in a brief, a header phrase, or a custom instruction. Design-dictating text overrides the brand engine and flattens the output, and a hex code in a text field is the classic symptom. The approved claims and avoid list travel a different road: they gate what `/creative-brief` may put into on-image text, they are compliance, not style.

## Before you start

- **Resolve the brand FIRST, before any file is opened, any preset is read, or any product is touched.** Every later step of this room, and every template it fills, runs against the one identity resolved here, and names it. Establish four things and say them out loud in one line:
  1. **The brand this run is about**, from the owner's words ("here is the brand book for [name]", "I'm adding another brand called [name]", "update [name]'s kit") or, with exactly one brand on the floor and nothing said, that brand. With more than one kit on the floor and no brand named, ask the one question ("which brand is this for?") before anything else.
  2. **Its kit file**: `factory/Brand/brand-kit.md` for the first brand on the floor; `factory/Brand/brand-kit-[brand-slug].md` for every later one. An existing kit whose `Brand name` row matches is THIS brand's file and is updated in place; no match means a new file, and the existing files are not touched.
  3. **Its products**: every `factory/Products/*/status.md` whose `Brand kit` row names this kit file, plus, on a new brand, the products the owner named as belonging to it (re-pointed on the owner's word, one line each), plus the product this run is being invoked on when its `Brand kit` row is still empty (it is re-pointed to this kit in the Update status.md step). A product whose row is empty or names another kit is NOT this brand's product, and this room never guesses it in.
  4. **Its preset**: the `Branding preset` id in THIS kit's `## Style engine` table, confirmed against the `Genrupt preset ID` row of this brand's products. A new brand has no preset yet, whatever ids other products carry.
  Then hold to that identity through steps 0 to 14 and the Update status.md section: the same kit file, the same product list, the same preset id, and the owner's request read once (a request that already named the brand and its products is never re-asked field by field).
- Open the resolved kit file. The kit SHIPS with `factory/Brand/brand-kit.md` as an unfilled template (placeholders like `[filled by /brand-kit]` and `#______`), so its existence alone means nothing.
  - **Still unfilled, or a new `brand-kit-[slug].md` that does not exist yet**: this is a FIRST RUN for this brand. Read the supplied guide, then fill the template's sections IN PLACE (for a later brand, copy the shipped template's section structure into the new file first), keeping its `##` headers exactly. Do not invent new sections. Every extra field below lives inside an existing table or in the footer.
  - **Already filled with real values for THIS brand**: do NOT rebuild from scratch. Show the current kit, ask what changes, edit only those fields, and follow step 13.
- Multiple brands: one brand per file, never merged, each with its OWN branding preset id, and which kit applies is recorded in the **`Brand kit` row of each product's `status.md` identity table**. The preset itself is looked up from the neighbouring **`Genrupt preset ID`** row, which is the canonical lookup for every generation room.
- **When more than one `brand-kit*.md` exists, no room may assume the default.** Every room that reads a brand kit resolves it from the product's own `status.md` first. If that product has no kit recorded, STOP and ask which brand it belongs to; never fall back to `factory/Brand/brand-kit.md` just to have something. The failure this prevents is silent and expensive: the second brand's product generated in the first brand's colors, carrying the first brand's approved claims, with no error anywhere.
- A second brand NEVER overwrites the first brand's kit or preset: it gets its own file and its own preset id. See "Several brands, one factory" below.
- **Check for the one input next.** Read `factory/Products/[product]/2-reference/brand/` and anything the owner attached to Claude in this session. A real Brand Book or Style Guide is what this room reads; without one, the owner's explicit yes to the one question in step 0 is the only other thing that lets it write anything. If no document is there, ask ONCE, plainly, whether the brand has one: "do you have a brand book or a style guide document?" A no, with no request for a proposal, ends the room in one line (step 0), with nothing owed and nothing proposed.
- **"I have nothing" is a finished answer.** It never triggers an interview or a second offer later. Inside this room it earns exactly one question (step 0); outside this room the subject never comes up again. An owner who already asked for a proposal in the same breath ("I have no brand book, propose me a direction") has answered that question; do not ask it again.

## Several brands, one factory

One Wonka can serve several brands. The brands stay apart in their files; the owner explains the business, and Wonka does the filing. Three situations, and the owner describes each in plain words (the Day 10 guide gives them the exact sentences):

**Another product under the same brand** ("I have another product for [brand]. Use that brand's kit and start a separate product project."):
- `/meet-my-product` registers the product in its own folder and writes the existing kit's path into its `Brand kit` row and the brand's preset id into `Genrupt preset ID`. Nothing in the kit is rebuilt.
- What carries over is the brand identity: colors, fonts, tone, logo rules, the `brand-wide` rows of the approved-claims table and the avoid list.
- What never carries over: the previous product's claims, dimensions, materials, research conclusions, reference sheets or tested set. Rows in the approved-claims table marked with another product's name are not this product's claims. The new product gets its own research, its own reference and its own brief, on its own facts.

**Another brand** ("I'm adding another brand called [name]. Help me create a separate brand kit and connect its products to it."):
- This room runs again for the new brand and writes `factory/Brand/brand-kit-[brand-slug].md`, with its own `Owner approval` line and its own Genrupt branding preset (a new preset, never an update of the first brand's). The first brand's file and preset are not touched.
- Each of the new brand's products gets the new kit's path in its `Brand kit` row when it is registered. Products that already exist and belong to the new brand are re-pointed on the owner's word, one line each in their `status.md`, and the owner never moves a folder.
- From the moment a second kit exists, the standing rule in CLAUDE.md applies everywhere: every room resolves the kit from the product's own `Brand kit` row. **If a product's row is empty or names a kit that does not exist, the room stops and asks the one question ("which brand does [product] belong to?") and never picks the first, the newest or the default.** `none (owner declined branding for this product) [date]` is a decision, not a gap, and is never asked about.

**Related brands, such as a personal brand and a product brand** ("My skincare brand is connected to my personal brand. Help me define what they share and what stays separate, then associate each product with the right brand kit."):
- Two kits, one per brand, each with its own preset. The relationship is RECORDED, in the owner's words, as rows in the `## Brand identity` table of BOTH kits: `Related brand | [name] (brand-kit-[slug].md)`, `Shares with it | [what the owner said: e.g. the founder's name and photo, the palette]`, `Kept separate | [what the owner said: e.g. the product brand's own logo and tone]`, `Recorded | [date], owner's words`. Ask about any relationship the owner has not made clear, one question at a time; never assume the two must merge, and never assume everything inherits from the personal brand.
- What is shared is applied by reading it into the other kit as a value with its source named ("from [personal brand] kit, shared by the owner [date]"). There is no inheritance engine: a shared value is copied on the owner's say-so and changed in both places when it changes.
- **A founder's profession, credentials or reputation verify no product claim.** A personal brand may say who the founder is; the product brand's approved-claims table still needs proof for every row, product by product, under the two tests in step 6. Nothing about claims moves between kits because the brands are related. No medical claim enters any table on a credential.
- Each product is then associated with exactly one kit in its `Brand kit` row, on the owner's word.

## Process

0. **Decide which of three states this run is in, and say which, out loud.** The owner is here
   because they typed `/brand-kit`; nothing about this room is ever raised by Wonka first. The
   brand this state applies to is the one resolved in "Before you start".
   - **A REAL BRAND BOOK OR STYLE GUIDE EXISTS.** The owner supplied a document their brand already
     owns. Read it, extract what it establishes, and the owner confirms. The steps below are that run.
   - **NO DOCUMENT, AND THE OWNER WANTS A PROPOSAL.** Ask the one question first, plainly, once, unless the owner's request already asked for a proposal (then that request is the yes and the question is never asked):
     "you have no brand book or style guide on file. Do you want me to propose a starting direction
     for colors, typography and tone that you approve, or run this product unbranded?" On an explicit
     yes, build a complete reasoned proposal from three sources in this order: (a) the product itself,
     its real materials, colors and finish from `2-reference/`, because a kit that fights the product
     loses; (b) what the category actually looks like on Amazon today, from `research/competitors.md`;
     (c) what would flatter this product and this buyer, from `research/persona.md`. One line of WHY
     per decision, and the owner accepts, changes one thing, or rejects.
     - **Every value carries `wonka proposal` as its source, and `Kit basis` records
       `wonka proposal (owner requested [YYYY-MM-DD], reasoned from [what])`.** A proposal that reads
       like a fact is what this labelling exists to prevent.
     - **A proposal may invent a palette. It may never invent a fact.** No claim enters the approved
       table without proof (step 10), and no logo is ever drawn (step 8).
   - **NO DOCUMENT, AND NO PROPOSAL WANTED.** A no, or an owner who never asked: say it in one line
     ("running unbranded, which is a real choice, not a downgrade. Your images take their look from
     the product itself."), write `none` into the product's `status.md` `Brand kit` row, and END THE
     ROOM. Then, specifically:
     - Do NOT propose anything anyway, and do NOT ask a second time.
     - Do NOT recommend inventing a brand with AI as a separate suggestion.
     - Do NOT run an interview whose purpose is to manufacture a brand system.
     - Do NOT leave a pending marker, and do NOT offer this room again downstream. `none` is a
       COMPLETED choice, and every later room reads it as one.
     - **A logo is untouched by all of this.** If the owner has a real logo it is already uploaded
       and wired by `/reference-sheet`, and the product may carry a logo-only Genrupt preset while
       `Brand kit` reads `none`. Those two rows are independent; never clear one because of the other.
     - Measured 27 August 2026: with no preset at all, nine smoke-test frames still came back sharing
       one coherent look that Genrupt's own enhancer drew from the product. Unbranded is a real path.
     - It is reversible without ceremony: if a Brand Book turns up later, run `/brand-kit` then.
   - The two rules that survive either state, because they are compliance and not taste: **no logo is
     ever drawn, approximated or invented**, and **no claim enters the approved-claims table without
     proof** (step 10).

1. **Read the guide, and take only what it actually establishes.** The Brand Book or Style Guide is
   the source; the room's job is extraction, not authorship.
   - Read every page you can open. If a page cannot be opened, say so in one line and ask for a
     screenshot or pasted text of that page.
   - What may be taken from it: colors, typography, tone of voice, layout rules, approved claims,
     avoids, and any explicit visual guidance it gives. Logo-USE instructions (placement, clear
     space, what may not be done to it) may be recorded as supplied rules; they never turn into a
     requirement for a logo FILE, and they never control whether a logo is uploaded.
   - **An incomplete guide is normal.** Use exactly what it establishes, leave the rest unset, and
     leave the matching preset fields unset too. Do NOT fill a gap from the product, the category,
     the buyer, the website, the packaging, or personal taste. In the file, extracted facts and
     absent information are visibly different things: a value carries `from brand book (p. N)`, and
     an absent one carries the literal `not established by the guide`.
   - **Never write "sampled" for a value you did not actually see.** A guessed hex code wearing a
     "sampled from the guide" label is a faked artifact, and every future session will trust it.
   - Record the outcome item by item; the footer carries one line,
     `Sources used: [the guide, by name]. Not established by it: [list].`

2. **Establish the KIT BASIS and write it as a row in `## Brand identity`.** One of `brand book: [filename]`, `style guide: [filename]`, or `wonka proposal (owner requested [YYYY-MM-DD], reasoned from [what])`. The third value is lawful ONLY on the requested-proposal path of step 0, and it changes nothing about the method while changing everything about how much authority the values carry.

3. **COLORS. Up to five roles, real hex codes, all of them out of the guide.** Primary, secondary, accent, background, text on light.
   - **On the guide path:** take the actual values the guide states or shows. If it names fewer than five roles, fill only those and write `not established by the guide` in the rest. Never invent the missing ones.
   - **On the requested-proposal path:** propose the full five, each with a one-line why, and never say "you decide" to an owner who already told you they have nothing.
   - Every row's Notes column names the source: `from brand book (p. N)` / `sampled from the guide's swatch page` / `not established by the guide` / `wonka proposal: [why]`.
   - Accent is for highlights and for real on-product seals. It is never permission to invent a badge.
   - **Name the text-safe pairs, if the guide names them.** One Notes line saying which colors may carry text and which may never ("headline text on background or primary only; never white text on the accent"). If the guide is silent, say so rather than deciding it here.

4. **FONTS. A direction, not a file, and read off the guide's own typography.** Map what the guide specifies onto one of exactly three tokens, written literally, once for headlines and once for supporting text (a guide naming a specific serif maps to `editorial serif`, and the mapping is stated out loud). If the guide establishes no typography, both tokens read `not established by the guide` and the preset's font fields stay unset: `editorial serif` (premium, wellness, heritage), `clean sans` (modern, tech, minimal), `bold display` (value, energy, impulse). Add the one-sentence overall look. If the brand owns a licensed font, record its name and note that it serves human design work only. Image models cannot load font files; they follow a described look reliably. These two tokens later become the preset's header and supporting font direction (step 12), so they are decided here once and typed into prose nowhere, ever.

5. **TONE, from the guide's own voice section.** Three to five words for `Sounds like`, each with a sentence of what it means for imagery ("warm: natural light, soft shadows, no clinical white sweep"), and three to five for `Never sounds like`. If the guide has no voice section, write `not established by the guide` and move on.

6. **APPROVED CLAIMS. Two tests, and a claim must pass both.** This is the compliance backbone and the most valuable table in the file.
   - **Test 1, TRUE.** Certifications actually printed on the label (name the certifying body), documented press mentions or awards, and factual product attributes the owner confirms: dimensions, capacity, material, part count, warranty, country of manufacture. Every row needs a proof entry. No proof, no row.
   - **Test 1b, WHOSE.** Every row also records `Applies to`: `brand-wide`, or the name of the ONE product it was verified for. The attributes in Test 1 are the reason this column exists: capacity, part count, material and warranty belong to a product, not to a brand, and this kit is reused by every product the brand sells. Day 9's second product is where an unscoped table shows up as product one's "4 tiers" printed on product two. A claim verified for one product is never licensed for another; a new product uses `brand-wide` rows plus its own, and earns the rest with its own proof. The same scoping applies to the avoid list: a promise the reviews of ONE product disputed is recorded against that product, not against the brand.
   - **Test 2, ALLOWED.** True is not enough. Sales rank, Best Seller status, star ratings, review counts, "thousands of happy customers", and anything else pointing at reviews or rank is TRUE and still barred from images. Move it to the avoid list marked `true, not allowed on images`, and tell the owner why in one line: this is the category that gets listings pulled, and rank changes week to week anyway. Sell the reason for the rank instead.
   - **Disputed promises go to the avoid list too.** If the product has research on disk, read `factory/Products/*/research/product-report.md` (and the raw `1-inputs/reviews.txt` where it exists) and move any promise buyers routinely dispute into the avoid list, naming the review evidence. Example from the bootcamp's demo product, a chocolate fondue fountain: buyers report the flow is weak at the capacity the listing states, so no image may promise a cascading flow. A promise the images made is the cheapest complaint to prevent and the most expensive to inherit.
   - For every approved row, record HOW it may appear: as it appears on the physical label, as plain printed text, as a physical hang tag. Never as an invented graphic badge, never as a third-party logo rendered by the model.
   - **An empty table is a lawful outcome.** If nothing passes both tests, write the literal line `No claims approved. Images carry only what is physically printed on the product.` and move on. Never pad this table to make it look finished. An invented certification is the single most expensive thing this skill could produce.

7. **AVOID LIST.** Restate the full Golden Standards compliance set: no medical or disease claims, no invented percentages or statistics, no star ratings or review references, no fake badges or awards, no third-party logos rendered as graphics, no flag graphics. Then add, each with a one-line reason: brand-specific avoids (colors that clash, styles the owner rejects, competitor names, a discontinued label), every item moved here by test 2, and every disputed promise from the reviews.

8. **LOGO-USE RULES, if the guide states any. This room does not own the logo FILE.** The real logo
   is uploaded and wired into Genrupt by `/reference-sheet`, and whether one exists is read from the
   product's `status.md` `Logo source` row, never decided here. What this room may record is what the
   guide SAYS about using a logo: placement, minimum clear space, one logo per image maximum, what
   may never be done to it. Write them as supplied rules, attributed to the guide.
   - The guide says nothing about logo use: write `Logo-use rules: not established by the guide`.
   - No logo file exists at all: write nothing about it here and ask nothing. It is not this room's
     subject, it does not block this room, and it never becomes a task.
   - The standing compliance rule holds everywhere regardless: **no logo is drawn, approximated,
     spelled out or invented.**

9. **No Brand style image here.** Earlier versions of this room picked a `styleImage` on Day 4. That is retired: the set's look is chosen on Day 6 from real generated frames as the Refine style reference (Restyle and Send to Refine). Do not propose one, do not ask for one, and leave `references.styleImage` unset. The one lawful write to it is a later, explicit request from the owner to promote a product's Day 6 reference into the brand's style image; record the request and the image id when that happens.

10. **Write the file, then self-check before showing it.** Fill in place, then verify mechanically that none of these survive anywhere in the file: `#______`, `[filled by /brand-kit]`, `[e.g. `, `[add your own]`, `[your brand name]`, `[date]`. Every `[URL or n/a]` reads as a real URL or the literal `n/a`. A file with a placeholder left in it is not a kit, it is the template with extra steps.

11. **Present, then get the verdict.** Show a compact summary: each color described in words with its hex and source, the two font tokens, the tone words, the claim count, the avoid count, and any logo-use rules the guide stated. Say plainly which fields the guide did not establish. Then ask plainly for "yes, that's my brand". Three lawful outcomes, and the footer records which one happened:
    - **Yes** to `Owner approval: APPROVED [YYYY-MM-DD] by [name]`.
    - **Changes** to edit exactly what they named, state the change in words, ask again. Never mark approved off a "looks fine" or a silence.
    - **Owner not in the session** (an assistant run, a rehearsal, a team member without authority) to `Owner approval: PENDING . built [YYYY-MM-DD] from [sources], awaiting owner confirmation`. See the PENDING contract below. The kit is usable and the line does not stop.

12. **Push the kit into the Genrupt branding preset, and record the id.** The preset is how the colors and font direction actually reach a generation; a kit that lives only in markdown styles nothing. One preset per brand.
    - Find the branding tools (list, create, update, apply branding preset). If they are not directly visible, discover them with `search_capabilities` and call them with `execute_capability`.
    - **Resolve the preset for THIS brand (the identity fixed in "Before you start"), then confirm with `list_branding_presets {includeDetails: true}`.** The lookup is the `Genrupt preset ID` row of a product on this brand's product list (the list resolved in "Before you start"). A preset already exists there in two ordinary cases: this brand was set up before, or `/reference-sheet` created a **logo-only preset** for a supplied logo on one of this brand's products. **UPDATE that exact preset. Never spawn a twin.** Two presets this room never updates: an id recorded in ANOTHER kit's `## Style engine` table, and an id sitting on a product whose `Brand kit` row names another kit or is unresolved, because that preset belongs to that brand (or to nobody yet), and restyling it dresses the wrong products. On a new brand with no preset of its own, CREATE one, even when every other product on the floor carries an id.
    - **A preset update is a MERGE, and the logo half is not yours to touch.** Before writing: read the existing preset in detail. Then update ONLY the style fields the guide established, and leave `logoUrl` and `logoThumbnailUrl` exactly as they are. Clearing a logo because this room did not supply one is the specific failure this paragraph exists to prevent.
    - Map in only what the guide established: primary, secondary, accent, and background hex into the preset's color fields; the two font tokens as the header and supporting font direction; the style notes field carries the one-sentence look, the text-safe pairs, and the text-on-light hex. **Fields the guide did not establish stay unset**; never send a value invented to fill a slot. Hex codes live HERE and only here. They never travel in brief text.
    - **Read the preset back after the write and verify BOTH halves survived**: the style fields you just sent are present, AND a logo that was there before is still there (`hasLogo: true`, `logoUrl` unchanged). Then read the Listing Builder plan back and confirm the same `brandingPresetId` is attached, the slot plan is unchanged, and `approved: true` still holds.
    - Record the id the tool returns in the kit's `## Style engine` section: `Branding preset: [id], updated [YYYY-MM-DD]`, **and write the same id into the `status.md` `Genrupt preset ID` row of every product associated with this kit** (the product list from "Before you start"), which is where every generation room reads it. Never write an id the tool did not return, and never write it onto a product of another brand or of no brand.
    - Genrupt down or MCP not connected: do not fake it, do not stall the kit. Write `Branding preset: PENDING . Genrupt unavailable [YYYY-MM-DD]` and say plainly that no generation for this brand should run until the preset exists. The kit file is done; the wiring is a recorded gap, filled next session the machine is up.
    - A kit whose approval is PENDING may still get its preset (the kit is usable); downstream provenance carries the pending state either way.
    - **Then attach it to any plan that is already waiting, if it is not attached already, on THIS brand's products only.** The brief is written and sent BEFORE this room runs (Day 3 sends, Day 4 dresses), so a saved listing-builder plan usually already exists; on a logo-only product `/reference-sheet` has already attached the preset, in which case there is nothing to attach and the read-back is the whole job. For each product associated with this kit, check its `brief/creative-brief.md` `## Send log`: if it records a saved plan, apply this preset to that set (the apply-branding-preset capability, targeting the listing builder set; discover it with `search_capabilities` if it is not directly visible) and record `applied to [product] plan [YYYY-MM-DD]` under `## Style engine`. A preset that exists but was never attached dresses nothing, and the failure is silent because the images generate anyway, just generic.
    - **READ THE PLAN BACK AFTER THE ATTACH, every time.** Attaching a preset is a setup-level write. On the current server a setup write preserves a saved approval (measured 26 August 2026), but earlier builds silently reset it to `approved: false` with nothing in the response saying so (CLAUDE.md, Genrupt contract rule 6). The free read-back is correct either way: confirm the preset shows attached AND `approved: true`, and re-save the approval if it dropped.

13. **Updating an existing kit.** Change only what was named, in THIS brand's file, and touch no other kit. Any change to a color, a font token, a claim or the avoid list RESETS approval: write a fresh `Owner approval:` line and one note under `Last updated` naming what changed and the old value ("Primary was #1E3D34, now #14332B, owner approved"). A new claim faces the same two tests. A kit approved once does not grandfather anything in. And any change to a color or font token is pushed to THIS brand's branding preset in the SAME session (step 12), with a fresh date on the `Branding preset:` line, and its products' `status.md` rows re-read. A kit and preset that disagree is drift, and the preset is the one the images obey. Products of other brands are not re-pointed, re-dressed or re-read by an update to this one.

14. **Backfill, on this brand's products only.** For each product associated with this kit (the product list from "Before you start": its `Brand kit` row names this kit file, or the owner assigned it to this brand in this run), search its artifacts (briefs, A+ plans, variation plans) for the marker `pending brand kit`. Fill each field from the finished kit and list the files updated. If a marker cannot be resolved from the kit, because it needs a value the kit does not hold, name the file and the field and LEAVE the marker in place. Never delete a marker you did not resolve. **A `pending brand kit` marker on a product of ANOTHER brand, or on a product whose `Brand kit` row is empty, is not this run's to fill**: it stays as it is, and the empty-row product is reported in one line ("[product] carries pending markers and no brand; tell me which brand it belongs to and I will fill them") rather than guessed into this brand.

## Output format

Fill the resolved brand's kit file in place (the SHIPPED template `factory/Brand/brand-kit.md` for the first brand; a copy of its section structure at `factory/Brand/brand-kit-[brand-slug].md` for a later one). Keep its exact section headers: `## Brand identity`, `## Colors`, `## Fonts and typography direction`, `## Tone words`, `## Logo rules`, `## Style engine`, `## APPROVED CLAIMS . the only claims allowed on images`, `## Avoid list`. Replace every placeholder with a real value, add the `Kit basis` row, and stamp the full footer.

```markdown
## Brand identity
| Field | Value |
|---|---|
| Brand name | [real name] |
| One-line positioning | [real line] |
| Website / storefront | [URL or n/a] |
| Kit basis | brand book: [filename] OR style guide: [filename] OR wonka proposal (owner requested [YYYY-MM-DD], reasoned from [what]) |

## Colors
| Role | Hex | Notes |
|---|---|---|
| Primary | #XXXXXX | [description. Source: from brand book (p. N) / not established by the guide] |
| Secondary | #XXXXXX | |
| Accent | #XXXXXX | [highlights and real on-product seals only] |
| Background | #XXXXXX | [typical backdrop tone] |
| Text on light | #XXXXXX | |

Text-safe pairs: [which colors may carry text, which may never]

## Fonts and typography direction
- Headline style: editorial serif | clean sans | bold display
- Supporting text style: [same three tokens]
- Overall look in one sentence: [summary]
- Licensed font on file: [name, human design work only] or n/a
(plus the template's standing note: image models cannot load font files; this describes the LOOK)

## Tone words
- Sounds like: [3 to 5 words, each with what it means for imagery]
- Never sounds like: [3 to 5 words]

## Logo rules
Logo-USE rules as stated by the supplied guide, or the literal `not established by the guide`. The
logo FILE itself belongs to `/reference-sheet`; this section never requires one to exist.
- Placement: [placement, size, clear space, as the guide states it]
- One logo per image maximum.
- Standing compliance rule: no logo is drawn, approximated, spelled out or invented.

## Style engine
How this brand reaches Genrupt. Style travels ONLY through these two; hex codes, font names and style prose never go into brief text.
| Field | Value |
|---|---|
| Branding preset | [id], updated [YYYY-MM-DD] . or PENDING with the reason |
| Carries a logo | yes (wired by /reference-sheet) | no . this room never sets it either way |

## APPROVED CLAIMS . the only claims allowed on images
| Claim | Proof | Where it may appear |
|---|---|---|
| [e.g. 4 tiers] | [product spec and listing] | [as plain printed text] |
(or the literal line: No claims approved. Images carry only what is physically printed on the product.)

## Avoid list
- [full Golden Standards compliance set, restated]
- [true, not allowed on images: rank, star ratings, review references] . reason
- [disputed promise from reviews] . reason
- [brand-specific avoids] . reason

---
Sources used: [the brand book or style guide, by name]. Not established by it: [list].
Owner approval: APPROVED [YYYY-MM-DD] by [name]   |   PENDING . built [YYYY-MM-DD] from [sources], awaiting owner confirmation
Last updated: [YYYY-MM-DD] by /brand-kit. [on an update, one line naming what changed and the old value]
```

## Owner approval, and the PENDING contract

A kit may legitimately be built while the owner is not in the room. In that case extract everything honestly from the supplied guide, mark every reading that needed judgement as a reading, and write the `Owner approval: PENDING` footer line instead of blocking. That line is the contract:

- The kit is USABLE. Briefs and generations may proceed on it.
- Every downstream room that reads the kit names the pending state in its own `Built from:` provenance line (`factory/Brand/brand-kit.md, owner approval PENDING`), so nobody downstream mistakes a proposal for a decision.
- The approved-claims table carries the pending state hardest. A PENDING kit's claims are readings of what the guide proves, so anything unverified stays out of images until the owner confirms.
- Clearing it takes one sentence from the owner. Then rewrite the line to APPROVED with the date and the name, and say which rooms were waiting.

Never write APPROVED because the kit looks correct. Correct and approved are different states, and only the owner can move between them.

## Golden Standards check

Before presenting, verify:
- [ ] `Kit basis` names the source: a real Brand Book or Style Guide that was read, or `wonka proposal (owner requested ...)`. **A proposal exists only because the owner ran this room and said yes to the one question**; nothing here was reasoned from the product, the category or the buyer without that yes.
- [ ] Every color present is a concrete hex code with a recorded source in the guide. No "greenish". No value labeled `sampled` that was not actually seen. Anything the guide did not establish reads `not established by the guide`, not a filled-in guess.
- [ ] Text-safe pairs named: which colors may carry text and which may not.
- [ ] Both font tokens locked from the three allowed and written literally, or recorded as not established.
- [ ] Every approved claim passed BOTH tests and has a proof entry. Anything true-but-barred sits on the avoid list, marked, not quietly kept. An empty table carries the literal no-claims line.
- [ ] The avoid list holds the full Golden Standards compliance set, plus brand specifics, plus every true-but-barred item and disputed promise, each with a reason.
- [ ] The logo file was NOT touched by this room. If a preset already carried a logo, the read-back proves `hasLogo: true` and the same `logoUrl` survived this room's update.
- [ ] `## Style engine` carries a branding preset id that a tool actually returned (with its date), or an honest `PENDING . Genrupt unavailable` line. Never an invented id, never blank. The same id is written into the `status.md` `Genrupt preset ID` row of every product associated with this kit, and of no other product.
- [ ] No style image was chosen or proposed here. That decision is Day 6's, inside Refine.
- [ ] Nothing in this kit is destined for brief text: no hex code, font name, or style sentence is queued for any `contentBrief`, header phrase, or custom instruction. Style ships by preset only; the set's look is chosen on Day 6 in Refine.
- [ ] No placeholder survives anywhere in the file (the step 10 check ran and passed).
- [ ] Footer carries `Sources used` / `Not available` and an `Owner approval:` line reading APPROVED or PENDING. Never blank, never absent.
- [ ] The brand was resolved before anything was opened (name, kit file, product list, preset), said in one line, and held through every step; on an update, only that brand's file, preset and products changed.
- [ ] On a second or later brand: the run wrote its OWN `brand-kit-[slug].md` and its OWN preset (created new, never an update of an id found on another brand's product or in another kit); the first brand's kit file and preset are byte-for-byte what they were. Every product the owner named is associated with exactly one kit in its `Brand kit` row, on their word; nothing was associated by default, and no other brand's or unassigned product's `pending brand kit` markers were filled.
- [ ] On related brands: the shared and separate items are recorded in both kits' `## Brand identity` tables in the owner's words, with a date; no claim moved between kits, and no credential was treated as proof of a product claim.

## Wonka lines

Openers:
- "The Brand Room. The candy may be perfect, but the wrapper is what they see first on the shelf."
- "Every factory has its colors. Show me yours, hex codes and all."
- "No brand book, no style guide? Then I have nothing to read. I can propose a direction if you want one, or your product styles itself. Both are real answers."

On the claims table:
- "True and allowed are two different tests, and only one of them keeps your listing standing."
- "No proof, no claim. I have never met a regulator who enjoyed theater."

On the preset:
- "The wrapper is not a memo, it is a machine setting. We set it once and every image comes out wearing it."
- "The wrapper is decided here. Which picture the whole set should feel like, you decide on Day 6, with real pictures in front of you."

Closers:
- "Wrapped, approved, and wired into the machine. Every image from here on wears these colors or it doesn't leave the building."
- "One kit, one preset, every product. That's the economy of a good wrapper."
- "Your brand now fits in one file and one preset id. The generation rooms pass the id, Genrupt does the dressing."

## Definition of Done

- A real Brand Book or Style Guide was supplied, OR the owner ran this room without one and answered the single question. A no ends it at step 0 with `Brand kit: none` written to `status.md`, nothing proposed and nothing pending: that is a complete, correct run of this skill.
- The resolved brand's kit file (`factory/Brand/brand-kit.md`, or `brand-kit-[brand-slug].md` for a later brand) is filled IN PLACE with what the guide established: hex colors each carrying a source, the text-safe pairs where named, the font tokens, tone words both ways, any logo-use rules, a `## Style engine` section, an approved-claims table where every row has proof (or the literal no-claims line), and an avoid list. Everything the guide did not establish reads `not established by the guide`.
- Zero placeholders remain. The step 10 self-check ran.
- The Genrupt branding preset is created or updated with the kit's colors and font direction, and its returned id is recorded in `## Style engine` with a date. If Genrupt was unreachable, the line reads `PENDING . Genrupt unavailable [date]` instead. **Both are recorded states; a silent skip is neither.**
- The `Kit basis` row names the guide, and the footer carries `Sources used` / `Not established by it` plus an `Owner approval:` line reading APPROVED with a date and a name, or PENDING with what it awaits. **Both are done states. A missing, blank or assumed approval line is not.**
- Any logo already on the preset survived this room untouched, proven by the read-back.
- The `status.md` of every product associated with this kit carries the returned preset id in `Genrupt preset ID`, and each `Logo in preset` row is unchanged by this room.
- Every `pending brand kit` marker on THIS brand's products is either resolved or reported by file and field; markers on other brands' products and on unassigned products were left in place, the unassigned ones reported.
- The brand resolved in "Before you start" is the brand every step used: one kit file written, that brand's preset created or updated, its products' rows written, and nothing of another brand's touched.

## Update status.md

Brand kit is brand-level, not product-level, so this section writes the `status.md` of EVERY product
associated with this kit (the list from "Before you start"), and no other product's. On a step 0
`none` ending it writes only the product the owner ran the room on. For each: set the `Brand kit` row
(this kit's path, or `none` when the owner declined), set the `Genrupt preset ID` row to the id the
tool returned for THIS brand's preset, and **leave the `Logo source` and `Logo in preset` rows exactly
as they are** . they belong to `/reference-sheet`. Then add a Log line:
`[YYYY-MM-DD] Brand kit built/updated at factory/Brand/[brand-kit.md | brand-kit-[slug].md] from [guide filename | wonka proposal]. Branding preset: [id] | PENDING. Owner approval: APPROVED | PENDING.`
On a step 0 ending: `[YYYY-MM-DD] No brand book or style guide. Brand kit: none. Nothing proposed, nothing pending.`
Nothing downstream waits for this room, so there is no station to unblock. Repeat any pending state (approval or preset) so the next session sees it.

If no product exists yet, because the kit was built before the first product, there is nothing to log. Say so and let `/meet-my-product` pick it up at the Front Gate. Never create a product folder just to have somewhere to write.

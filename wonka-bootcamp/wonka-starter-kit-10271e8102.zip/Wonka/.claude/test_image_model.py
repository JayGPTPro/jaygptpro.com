"""WONKA_IMAGE_MODEL resolves the same way in every machine: environment, then the nearest .env
upward, then the default. The helper is copied into each script on purpose (the kit has no shared
module), so this test runs the SAME rows against every copy; a fix must land in all of them."""
import os, sys, importlib, tempfile, contextlib
HERE = os.path.dirname(os.path.abspath(__file__))
MODS = [("main-image", "openai_blast"), ("fix-faces", "face_fix"), ("variations", "variations_run")]
DEFAULT = "gpt-image-2.5-sunburst"

def load(skill, mod):
    sys.path.insert(0, os.path.join(HERE, "skills", skill))
    m = importlib.import_module(mod); importlib.reload(m); sys.path.pop(0); return m

@contextlib.contextmanager
def cwd(path):
    old = os.getcwd(); os.chdir(path)
    try: yield
    finally: os.chdir(old)

def run():
    fails = 0
    for skill, mod in MODS:
        with tempfile.TemporaryDirectory() as tmp, cwd(tmp):
            os.environ.pop("WONKA_IMAGE_MODEL", None)
            m = load(skill, mod)
            got = m.image_model()
            ok = got == DEFAULT; fails += not ok; print("ok  " if ok else "FAIL", mod, "default ->", got)
            open(".env", "w").write("OPENAI_API_KEY=x\nWONKA_IMAGE_MODEL='gpt-image-2'\n")
            got = m.image_model()
            ok = got == "gpt-image-2"; fails += not ok; print("ok  " if ok else "FAIL", mod, ".env ->", got)
            os.environ["WONKA_IMAGE_MODEL"] = "gpt-image-2.5-flare"
            got = m.image_model()
            ok = got == "gpt-image-2.5-flare"; fails += not ok; print("ok  " if ok else "FAIL", mod, "env beats .env ->", got)
            os.environ.pop("WONKA_IMAGE_MODEL", None)
            # what people actually type into a .env (review of 17.9.2026): every row must read gpt-image-2
            rows = {"spaces around =": b"WONKA_IMAGE_MODEL = gpt-image-2\n",
                    "leading space": b"  WONKA_IMAGE_MODEL=gpt-image-2\n",
                    "export prefix": b"export WONKA_IMAGE_MODEL=gpt-image-2\n",
                    "BOM": b"\xef\xbb\xbfWONKA_IMAGE_MODEL=gpt-image-2\n",
                    "trailing comment": b"WONKA_IMAGE_MODEL=gpt-image-2  # newest\n",
                    "CRLF": b"WONKA_IMAGE_MODEL=gpt-image-2\r\n",
                    "non-UTF-8 byte above": b"OPENAI_API_KEY=x\xe9\nWONKA_IMAGE_MODEL=gpt-image-2\n"}
            for label, raw in rows.items():
                open(".env", "wb").write(raw)
                try: got = m.image_model()
                except Exception as e: got = "CRASH " + type(e).__name__
                ok = got == "gpt-image-2"; fails += not ok; print("ok  " if ok else "FAIL", mod, label, "->", got)
            open(".env", "wb").write(b"# WONKA_IMAGE_MODEL=gpt-image-2\n")
            got = m.image_model(); ok = got == DEFAULT; fails += not ok; print("ok  " if ok else "FAIL", mod, "commented out ->", got)
            # the nearest .env UPWARD, the way the key loader already works
            open(".env", "w").write("WONKA_IMAGE_MODEL=gpt-image-2\n"); os.makedirs("factory/Products/demo")
            with cwd("factory/Products/demo"):
                got = m.image_model(); ok = got == "gpt-image-2"; fails += not ok; print("ok  " if ok else "FAIL", mod, "from a product folder ->", got)
    print("RESULT", "FAIL" if fails else "PASS", fails)
    return fails

if __name__ == "__main__":
    sys.exit(1 if run() else 0)

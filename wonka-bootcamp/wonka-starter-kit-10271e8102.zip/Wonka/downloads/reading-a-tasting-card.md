# Reading a Tasting Card

A Tasting Card is the report of a synthetic panel: about a hundred AI shopper profiles built from your buyer research, each shown the candidates and asked to choose and explain. It is a way to examine the logic of your images before you spend on a real survey or an Amazon experiment. It is not a prediction of real shoppers.

## The count and the label

| What you see | What it is |
|---|---|
| **Chosen by** | How many of the simulated profiles picked that candidate in a forced choice. A count of preferences inside the simulation, never a market share. |
| **Purchase intent** | An average of simulated ratings. The differences are usually small; read them as close or not close, not as a ranking. |
| **Clear lead / Lean / Toss-up** | How stable the direction was when the recorded votes were resampled. A Lean or a Toss-up is a normal result and does not require another run. |

A main race carries two gaps: the gap over the live image, and the gap among your own candidates. A card can be confident that your candidates beat the live image while unable to separate them from each other. Both are real results.

When the two galleries hold a different number of images, the result also reflects differences in content and coverage. Read it as feedback on the individual frames, not as a measured margin.

## The part worth more than the score

Every profile says why, in its own words. That is the useful part: comments about unclear text, missing information, or a step that is hard to understand. Read them against the actual image and your product research. Some comments point at something real. Some do not. Some point at things that are simply part of the product and should stay.

A compound objection is two objections in one sentence. "Cannot judge tip quality or durability" is a picture question (fineness can be shown) and a promise question (durability cannot). Answer the half a picture can answer, and note the other half as a listing or copy question.

## Racing again

Never re-race unchanged images: the panel is seeded, so the same images replay the same verdict at full price. A second run is an option when something changed and you have a concrete question to answer. It is not required to finish the day, and a report you already read still describes the images that were tested at the time.

## What a card never is

Proof. The panel is synthetic, matched to your buyer demographics, and directional. For a decision that matters, a real-shopper survey and an A/B test on Amazon outrank every card.

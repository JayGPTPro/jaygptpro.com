# Turning Objections into Changes

Read the comments, then sort them into three piles. Split a compound objection first: "cannot judge tip quality or durability" is two comments that land in different piles.

## Pile 1: an image can answer it

They could not tell the size. They thought it was plastic. They did not see that it comes apart for cleaning. These are images that did not communicate, and they are the ones worth a change: a hand for scale, a material close-up, a simpler layout. Tell Wonka which image and what to keep; the edit runs on the image you chose.

## Pile 2: the listing can answer it, but not with an image

A question about what is in the box. A spec nobody could find. A compatibility doubt. That belongs in your bullets or your A+, not in the gallery. Write it down and route it there.

## Pile 3: nobody can answer it

"Too expensive." "I would not use it often enough." Real, and no photograph answers it. Let it go; a gallery that argues with this pile wastes frames the first two piles needed.

## Two rules for weighing them

- **Comprehension comments outrank preference comments.** "I could not tell how big it is" is information regardless of who said it. "I liked the other one more" is a nudge.
- **Repetition is a reason to look, not an order.** A comment that appears many times, or in both races, deserves a careful look at the image and the research. It does not have to be acted on, and it does not prove a gap on its own. Keep product facts and instructions accurate; do not remove a true instruction or add a reassuring claim to make a comment disappear.

You do not have to change something because the panel said so, and you do not have to keep editing until no profile objects. Your research and your judgment decide.

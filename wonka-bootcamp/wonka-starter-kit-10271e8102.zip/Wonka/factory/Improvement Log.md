# The Improvement Log

This is how the factory gets better. One file, written by `/improvement-loop`, read by Wonka at the
start of every session and again whenever he writes a brief.

It holds **two kinds of lesson**, because the factory learns twice:

- **What the market taught us.** Which images actually win, and why, in the tasters' own words.
  That is about the candy.
- **What the factory taught itself.** How Wonka works better: what he missed, what he should
  front-load, what he should stop repeating. That is about the factory worker.

**This log ships empty on purpose.** On your first product Wonka opens the brief by saying so out
loud: the log is empty, so this brief runs on research and best practice alone. Nothing here is
seeded, guessed, or borrowed from someone else's market. Your first real row lands after your first
Tasting Round, and from then on every brief starts by reading it.

One test teaches you about one image. A full log teaches you about your customers. That is how the
factory compounds: your third product starts smarter than your first.

---

# PART 1: What the market taught us

## Patterns

| Pattern | Evidence | Niche | Strength | Source test |
|---|---|---|---|---|
| | | | | |

Strength values: **USE** (won clearly, apply by default) / **MIXED** (won somewhere, lost elsewhere,
apply with judgment) / **AVOID** (lost clearly, do not repeat).

**Evidence weight, and be strict about it.** A Tasting Room result comes from a synthetic panel, so
it is directional evidence plus mined objections, never a purchase. One round is a weak signal. A
second gate-passed test on the SAME claim can make a usable prior, written as a judgement with both
results named; two tests on different questions do not add up, and two Leans stay MIXED. A loss is
recorded at the strength its race carries: AVOID after a clear loss, a hypothesis after a Lean. A real shopper poll outranks any synthetic panel, and a real
Amazon A/B result outranks everything on the same question because it is money instead of opinion.
Every row says which kind of evidence it rests on, and every row names the niche: a pattern proven
in one niche is only a hypothesis in the next one.

**A row from a Lean race is a hypothesis, and it says so.** It opens with `HYPOTHESIS:`, sits at
MIXED, and is a thing to test in the next brief, never a rule to apply and never an AVOID. A winner
among candidates that differed in several ways does not isolate the cause; a ranking of frames inside
one set does not prove a slot order; a mention count is a count of reactions, not of people or
purchases. The row keeps those limits in its evidence cell.

Example rows (delete once you have a real one):

| (example) A savoury frame, queso and wings, beats a second dessert frame in the gallery | set won 57 votes to 31 and this frame ranked strongest of 6, 100 synthetic tasters, round 1, Clear lead | [niche] | MIXED (1 round = weak signal) | Tasting Round 1, gallery race, [YYYY-MM-DD] |
| (example) HYPOTHESIS: a main showing the product in use read less like a novelty than the product-alone mains | preferred by 60 of 100 synthetic tasters vs 20, main race, round 1, Lean, not proof; the candidates also differed in prop and background, so the cause is not isolated | [niche] | MIXED (hypothesis from 1 Lean race; test it, do not apply it as law) | Tasting Round 1, main race, [YYYY-MM-DD] |

## Owner creative preferences

Creative and taste calls from the human who runs this factory: what the images should look like.
Working-style preferences (how Wonka should work) go in Part 2. Wonka respects these in every brief,
even before any test confirms them, and never pretends taste is data. Besides `/improvement-loop`,
the generation rooms (`/main-image`, `/secondary-images`) append here at pick time, whenever an
owner's pick or rejection reason names a rule that outlives the batch. Dated bullets:

- [YYYY-MM-DD] [e.g. "I never want purple backgrounds"]
- [YYYY-MM-DD] [e.g. "Keep the stainless base in frame, it is the part that looks expensive"]

## Conflicts on record

Contradicting results are logged with both sides and dates, confidence downgraded, never silently
overwritten.

- [YYYY-MM-DD] [pattern] : [old evidence] vs [new contradicting evidence]. Downgraded to MIXED.
  Difference suspects: [niche / n / image quality].

## Lessons log

One dated line per processed result: what was recorded, or the honest no-result. Objections that
recurred without a tested pattern land here too, with their mention counts, so the next brief still
reads them. Example lines (delete once you have real ones):

- [YYYY-MM-DD] tasting : no usable pattern from [test folder, race]. Toss-up, models disagreed.
  Objections kept, counts dropped.
- [YYYY-MM-DD] tasting : objection, "will it actually flow", raised by 14 tasters in [test folder,
  race]. Recorded as an objection, not a tested pattern.

---

# PART 2: What the factory taught itself

How Wonka works better: what he missed, what he should front-load, what he should stop repeating.
Read at the start of every session, so the lessons compound.

The line between the two parts is simple. A market pattern ("shoppers prefer a texture close up")
belongs in Part 1. A process lesson ("I should have confirmed the real variation list before
planning") belongs here.

## Process lessons

| Date | Trigger | Lesson | How to apply | Status |
|---|---|---|---|---|
| [YYYY-MM-DD] | (example, delete once you have a real one) The owner had to remind Wonka to run the reference smoke test before a generation batch | Never open a generation batch without a passed smoke test on record | Treat "Smoke test: PASS" in the reference sheet as a hard precondition and check it before estimating any batch cost | active |

## Factory trend

One row per product, per full run through the line. This is the only place the Factory proves it
is actually getting better rather than just claiming to. Every number is COUNTED from disk, never
remembered: fix rounds are the `edits/vN/` folders, QA fails are the FAIL verdicts in
`scorecards/`, and the verdict is the tier printed on the main race Tasting Card.

A run that took fewer rounds to reach the same tier is the loop working. A run that took more is
worth a Process lesson explaining why, and "the second product was harder" is a legitimate answer
as long as somebody wrote it down.

| Date | Product | Fix rounds | QA fails | Tasting verdict | Lessons added |
|---|---|---|---|---|---|
| [YYYY-MM-DD] | (example, delete once you have a real one) [product slug] | 3 | 5 | Clear lead | 2 |

## Owner working-style preferences

How this owner likes Wonka to work: process, how to walk through decisions, how much to decide
alone. Creative taste goes in Part 1. Dated bullets:

- [YYYY-MM-DD] (example, delete once you have a real one) Owner prefers two options to choose
  between, and does not want Wonka to decide the winner alone.

---

# PART 3: The experiments ledger

Every test the factory runs, one row per race.

**Who writes what.** `/tasting-room` appends a `tasting-room` row when the panel runs (it returns in
the same session, so the row lands complete). `/ready-to-upload` appends an `amazon-ab` row (Status
`planned`, then `running` at launch). `/improvement-loop` records the final status once the lesson
has been distilled into Part 1. An optional real-shopper poll (the Pro Move bonus, any tool) may be
logged MANUALLY as Type `shopper-poll`; no skill writes or finalizes those rows.

**One row per race, not one per sitting.** A Tasting Room sitting holds two races: the main race
(your main candidates against the live incumbent) and the gallery race (your new secondary set
against the live gallery). Each race is its own experiment and gets its own row. A full run through
the factory therefore ends with two `tasting-room` rows, one per race; an optional Round 2 adds two more.

**The `amazon-ab` row belongs to a listing you control.** You file it on your own listing once you
launch the test in Manage Your Experiments. The bootcamp's demo product is not our listing, so the
demo run ends with tasting rows and no `amazon-ab` row at all. That absence is the honest state of
things, not a gap: never log a test nobody ran.

| Date | Product | Type | Candidates | Winner | Margin | Key why | Status |
|---|---|---|---|---|---|---|---|
| | | | | | | | |

Column notes:

- **Date**: the day the test ran, as YYYY-MM-DD.
- **Product**: the product slug, matching its folder name under `factory/Products/`.
- **Type**: `tasting-room` (the synthetic panel via `/tasting-room`), `amazon-ab` (Manage Your
  Experiments in Seller Central), or `shopper-poll` (the optional Pro Move real-shopper poll).
- **Candidates**: how many images competed and which, always including the incumbent, plus which
  race it was, e.g. "4 (3 ours + incumbent), main race" or "6-frame set vs live gallery, gallery race".
  Not live yet: the benchmark is named instead of the incumbent, e.g. "4 (3 ours + benchmark: competitor [name]), main race".
- **Winner**: the winning file for a main race, the winning set for a gallery race, or `incumbent`
  when the live one held. The incumbent holding is a result worth logging, not a failure worth hiding.
- **Margin**: winner vote count vs runner-up count, plus the intent gap, plus the panel context and the stability label, e.g.
  "preferred by 54 of 100 synthetic tasters vs 27, intent +0.31 of 5, round 1, Clear lead".
- **Key why**: one line, from taster comments or A/B data, on WHY the winner won.
- **Status**: planned / running / won / lost / inconclusive / logged. Use `inconclusive` whenever the
  label was not Clear lead, or the panel's models disagreed on the winner. `logged` means the lesson
  has been distilled into Part 1.

Example rows (delete once you have real ones):

| [YYYY-MM-DD] | [product-slug] | tasting-room | [N] ([N] ours + incumbent), main race | [file] | preferred by [N] of 100 synthetic tasters vs [N], intent +[0.00] of 5, round 1, [stability label] | "[one line from the taster notes on why it won]" | logged |
| [YYYY-MM-DD] | [product-slug] | tasting-room | [N]-frame set vs live gallery, gallery race | our set | preferred by [N] of 100 synthetic tasters vs [N], intent +[0.00] of 5, round 1, [stability label] | "[one line from the taster notes on why it won]" | logged |

---

Updated by `/improvement-loop`. Review it once a month and prune anything stale.

# Day 9: The Variations Room

**If your product is a single SKU, today is optional.** Say so and Wonka records `Variations: skipped
(owner, [date])` in your words; that line is what lets the Shipping Room open on Day 10. A silent skip is
not a skip: with nothing on record, Day 10 waits. A skip is a past answer, not a lock: ask for a
variation later and the room reopens.

**How today opens.** You resume, or you ask to continue. Wonka reuses whatever `status.md` already holds
about your family (the child list, where each child came from, how it was produced). With nothing on
record he asks one question and nothing else:
"Do you have any product variations you'd like to create images for?"
Answer with ASINs or links, with photos, or with a written change including a colour the listing
does not carry yet, in any combination. Or answer no, and he writes the skip.

Watch it for the knowledge, because you will have a variant product eventually and this is a good
thing to know exists. Or take the day back. **Day 10 is the last day and it is the one everybody
runs.**

If you DO have variants, or you are thinking about one, this is probably the highest-value day in
the bootcamp.

**The sentence for the day: eight variants used to be eight jobs. Today it is a plan, a first look, and
a button.**

## What you will have by the end of today

- Your **confirmed child list**, with where each child came from (an ASIN, a sentence, your photos)
  and whether it is a real SKU or a labelled concept
- The **frame table** (what each frame of your selected source carries, and what gets REUSED) and
  the **truth table** (each child's printed facts, checked against that child's own source)
- **The first images, reviewed before the rest of the batch**: one child per kind of change (shape,
  colour, count), on the frames that carry the difference, checked against its source and its
  reference, with your look as the gate
- The **whole family** propagated on the instructions that worked, unchanged, with untouched frames
  reused rather than regenerated, the people and props of your approved frames kept
- Swatches only if you asked for them; concepts kept out of every upload package unless you later
  confirm them for sale
- Every file's path, one line per child, and a plan that lists them all

**Time needed:** 45 to 75 minutes, most of it on the tables and the first images.

## What you will need at hand

- Your family, in whatever form you have it: the ASINs or listing links, or a sentence, or photos
- Your recorded picks from Day 8 (the `Main pick:` and `Gallery pick:` rows), untouched
- Your OpenAI key alive (Day 1's `/machines-check`). Today's edits run on it, for cents

---

## One lesson: the room, the three ways in, the demo

The idea first; the terminal starts a few paragraphs down.

### What this room does

Eight colours. Seven images each. **Fifty-six images.** Until very recently that meant fifty-six
pieces of design work, or a photoshoot where somebody swapped a product eight times under the same
lights and hoped nothing moved. Which is why most listings have **one beautiful main SKU and seven
neglected siblings** with two images each.

**Most of your variant family already exists.** You spent eight days building a tested set. Your
blue version differs from it in a way you can name in one line: a colour, a shape, a printed number.
Everything else is finished work. Wonka classifies your set frame by frame:
frames that carry the **SHAPE** of the thing that varies, frames that print a **VALUE** (a count, a
size, a fit claim), and frames that carry **nothing variant-specific**, which are **REUSED**, copied
into every child's set untouched.

The frames that do change get edited in **two separate layers, never one prompt**: the shape is one
edit against a reference image, the printed text is another. A shape child changes the product's
geometry under its new reference; a colour child changes the finish only. The two never share a
prompt. Each edit costs cents on your OpenAI key.

Whether your family comes back as cheap edits of your tested photograph or as fresh generations on
the same brief is written down once, with its reason. Wonka reuses that recorded answer; on a first
family he asks you once and writes down what you said.

**The first images, in two lines.** Wonka does not build the whole family at once. He comes back
first with ONE child per kind of change (a colour round proves nothing about a shape), on the frames
that carry the difference, the main and whatever prints the changed facts. In the demo the family
was two children, one design each, so both appeared. Your look at those images is the decision:
complete the rest, or a named correction.
A family you have run before goes straight through unless you ask for the first round.

**Same brief, but not same claims.** A variant that needs a different brief is a different product.
But the printed facts may differ per child, and they usually do: the small size fits a smaller
basket, the eight pack prints a different count. Those facts are checked against each child's own
source, never carried across. A number nobody can confirm is removed from the frame, and the plan
says so. The machine never invents a spec.

### Three ways to tell Wonka what the family is

You can use one, or any mix of the three. Nothing has to be demonstrated; pick whatever you have.

**ASINs or links.** Paste the variant ASINs or listing URLs, several at once. Wonka fetches each
child's images himself, starting with its main and adding gallery frames when the main does not show
the difference, and files them under the child. He checks the image is really that child's and not
the parent's shared main; when two children resolve to the same picture he says so and takes the
next frame that differs. One warning from the field: **the picker labels lie.** Amazon's colour axis
has been seen carrying the SHAPE. He reads the values, not the labels, and reads the differences
back to you before accepting them. The one question he may ask: when a child has no picture of its
own on the listing, he asks you for one or for a description.

**A sentence.** "Make this in black, white and red." "The 5-tier model." "A 2-pack." No listing
required. A colour, finish, shape, size or count your listing does not sell becomes a **concept** child:
generated, labelled `concept` on the folder, the filenames and the plan, no approval step, and never
a product claim. A concept is a picture of a possible product, and the plan says so in one line. The
one question he may ask: a shape described in words still needs a shape reference, because geometry
cannot be described reliably, so he asks for the ASIN or a photo once. Another seller's ASIN can be
that reference: it lends the shape only, never its facts.

**Uploaded images.** Attach the files. Wonka maps each to a child and files them; you file nothing.
The one question he may ask, only when the filenames and your words leave it genuinely open: "Are
these three files three colours, or three angles of one colour?"

However it came in, the confirmed list is written down with, per child, where it came from and
whether it is real or a concept. Every recorded decision (the type, the list, your Day 8 picks) is
reused from `status.md`; a question answered on disk is never asked again.

### The demo, narrated

The demo product is the Stainless fountain tested on Days 2 to 8. Day 9 adapts the tested set to two
other fountain designs.

**Two designs, from two ASINs.** Jay sends B011RBDCJQ and B000FZ4TZC after `/variations`, with one
instruction: use these as shape references, and for the demo assume the features and the core
selling points stay the same. Wonka opens both and reads the live variation picker back: both ASINs
are this listing's own children, not outside designs. B011RBDCJQ is the Stainless Cascading 4 Tier,
B000FZ4TZC the Black Fountain 3 Tier, beside the tested parent B09BDGFKXB. So both are **real
children**, not concepts. The assumption is recorded verbatim and then split where it matters: every
NUMBER is read from that child's own listing, and only the FEATURE claims nothing confirms stay
marked `assumed` (the two adjustable front legs, and that it lifts apart into four parts). Wonka
fetches each ASIN's images, confirms in one line that the fetched main shows the shape being
borrowed, and keeps it as the shape reference. He names the source: the recorded picks, `Main pick:
main-13` and the `Gallery pick:` frames from `edits/v9`, with `sec-03-v3` marked `revised after
test, no re-run`.

**What changes is more than the outline of the tower.** The frame table and the truth table come
back on one screen. The cascading design keeps four tiers and 32 ounces but measures differently;
the black one has three tiers, 24 ounces, and is much shorter. Both swap the original's two switches
for a knob. The tested set already prints those facts: the main carries a tag with the tier count and
the capacity, another frame carries the height and the base. Replace only the fountain and you ship
the new product beside the old numbers. Then the scope line: "2 children (2 real, 0 concept), frames
MAIN, PT02, 7 edit calls on your OpenAI key, about $0.14 (cap $10 per run), swatches not made". No
question. The first images run.

**The first images, checked against source and reference.** They come back for BOTH designs, on the
two frames that carry the difference: the main and the dimensions frame. Each is shown three ways,
the source frame, the result, the reference listing's own picture. Three questions: is the requested
change there, is only that changed, is the product still itself. The hero keeps the hands and the
food the tested main carries. The tags read four tiers and 32 ounces on the cascading, three and 24
on the black, each one its own truth-table row. One thing is wrong: the black fountain is shorter,
but its measurement line still starts where the tall one's did. The number followed the child and
the line did not. Jay names that in one sentence and lets the rest of both galleries run.

When an image is wrong, the fix is the instruction, never the image. The failures have shapes that
repeat: the hero that refuses to change (name what it IS before what it becomes), the group frame
where only one of them changed (count them: "ALL FOUR"), the label card that melted (declare it a
RIGID OBJECT). Two or three genuinely different phrasings, not five nudges. Three failing the same
way means the problem is upstream: a missing reference, or a variant that is really a different
product. **And there is one failure a fourth phrasing never solves.** A small element, an icon, an
inset, a diagram detail, sits below what a whole-frame edit will redraw, so it is repaired by cutting
out its REGION, enlarging it, editing it at full resolution and compositing it back, leaving every
pixel outside that box as it was (`/fix`, step 7d). It is an edit like any other: it counts as an
attempt under the same limits, and when two whole-frame edits have already failed, the room stops
and tells you instead of trying another phrasing. Your word is what starts it. The correction it
reveals still goes back into the instruction, so the next batch carries it. It is worth checking the
diagrams, insets and little product drawings whenever the photograph itself looks right; they keep
the old design quietly.

**The whole family, and the icon that held out.** Eighteen images: a main and eight secondary frames
per design. The colours, the headlines, the food, the people and the image concepts still read as one
family. The frames that needed attention got it: the controls close-up shows the right controls, the
parts diagram the right parts, a frame carrying two views of the product has both updated, and a
pouring jug that had disappeared came back. One detail held out. The little FLOW icon in PT04 still
drew the original tower on both children and survived two whole-frame edits. Wonka stopped there and
said so rather than trying a third phrasing; Jay answered "regenerate the PT04 frames to fix the
icon", and the region route landed it on both, first try.

**The inspection, and where the files are.** `/inspect` runs over all eighteen, `/fix` repairs what
it confirms, and the corrected images are checked again. It found four defects, all in the black
set: three pieces of small lettering around the controls (one read HEAT where it should read MOTOR,
one spelled MOTOR with an H, one panel had smeared) and a woman holding an empty skewer where the
tested frame had a chocolate-dipped strawberry. Invisible at gallery size, obvious at full size. All
four repaired, eighteen passed, nothing left open, and Jay still opens the finished images himself,
because the report finds problems and does not decide which images he wants to keep. Then the paths,
one line per child: both children in `variations/`, as `main-[child].png` and `[slot]-[child].png`,
and they travel to Day 10. A concept, if you make one, is labelled and stays out of the upload pack.
`variations/variations-plan.md` lists every path with its status. No original was overwritten:
`images/` is write-once, and each fix round wrote a complete new snapshot, so the current set is the
newest `edits/vN/variations/`. The reported estimates for the whole run come to about $0.68, before
upscaling.

**What the demo did not do.** The A+ content was not adapted: the original page carries the original
product and its measurements, so it needs a review of its own. And the feature claims resting on the
demo assumption stay marked `assumed`; on a real listing they are confirmed or removed before a
shopper sees them. When Jay ends the session, Wonka writes the `Children:` record and the `Next
stage:` line and invokes nothing after it; Day 10 belongs to the next session.

**The same room explores a colour you have not launched.** Describe the colour and exactly which part
should change (on the fountain, the tiers and bowl take the colour, the stainless base, controls and
jug keep their finish). No Amazon link is needed for that, and no approval step: what comes back is a
labelled concept to review, never a product claim. A new SHAPE is different, because geometry cannot
be described reliably; that one needs a reference, an ASIN or clear photos.

### And before anything goes near Amazon

The edit drafts are review size. **Nothing is upscaled in this room.** Wonka records `upscale: owed`
against the family, and the Shipping Room on Day 10 upscales it once, with the mains, on the files
that ship. Then the gate, like everything else:

```
/inspect all images in the current variation sets, then /fix any confirmed defects and recheck the corrected images.
```

He opens every child, checks each frame against that child's own truth-table row, and checks the
family reads as one product rather than five photoshoots. The Shipping Room extends your upload pack
only with gate-passed variation files.

---

## MISSION 1: Choose your variations

Start a new session in your Wonka project. Then:

```
/variations
```

Send what you have, in any combination: the variation ASINs or links, your reference photos with a
word on which version each one shows, or the change written in a sentence. Wonka uses what is already
saved and confirms what needs to change, so **listen to the read-back** and correct it if it is
wrong. Read the scope line too: the children, the frames, the calls, the estimate.

No variations to create today? Say so, and tick the skip box on the day page:

```
No variations to create today. Record Day 9 as skipped and save our progress.
```

He records `Variations: skipped (owner, [date])`, then asks once: "Ready for the Shipping Room?" Say
yes and Day 10 opens; say not now and it waits until you ask. Change your mind later and the
Variations Room reopens.

## MISSION 2: Review the first images

They come back for one child per kind of change, on the frames that carry the difference. Check the
product's shape, colour and proportions against your references. Check every printed detail against
that child's own numbers, the ones on the tag, the measurement lines, the labels. Check the layout
and the styling still belong with your approved set. Name any correction now, before the rest is
built. Name the child, the frame, what is wrong, and what happens next:

```
In the black fountain's PT02, fix the vertical measurement line so it runs from the actual top of the fountain to the bottom of its feet. Then complete both galleries for review. Don't start packaging yet.
```

When they are right:

```
These look good. Complete the remaining images for the variations we agreed on.
```

## MISSION 3: Inspect and correct

Look at the completed sets together, then look closely: small labels, diagrams, insets, and every
appearance of the product in a frame that shows it more than once.

```
/inspect all images in the current variation sets, then /fix any confirmed defects and recheck the corrected images.
```

Open the paths he gives you, one line per child, and read the Outputs section of
`variations/variations-plan.md`: every file, real or concept. After a fix round the current set is
the newest `edits/vN/variations/` folder, so look at those files and not at the pre-fix ones.

## MISSION 4: Approve and save

Open the finished images yourself first. A clean report means Wonka found nothing left to fix; it does
not mean these are the images you want to keep. When they are:

```
Approve the current variation sets. Save everything and finish Day 9. We'll do Day 10 in a new session.
```

He writes your decision, the child record and the `Next stage:` line, and stops there. Day 10 brings
the approved work together, runs the owed upscale, packs it, and runs the Improvement Loop.

**Share it:** send Jay your family as one grid, one review sheet, and the phrasing that cracked your
hero frame, because everybody's will be different and the shapes are genuinely interesting.

## Common mistakes

- **Generating the whole family first.** An untested instruction across eleven children is eleven
  children regenerated.
- **Regenerating frames that carry nothing variant-specific.** They are reused. That is the whole
  economics of the day.
- **Editing the first images into shape by hand.** The instruction is what the rest of the family
  runs on, so a patched image propagates nothing.
- **Describing a new shape in words.** Geometry needs a reference. Give the ASIN or a photo.
- **Selling a concept.** A concept is a picture of a possible product. It is labelled, and it is
  never a claim.
- **Describing only the target shape to the hero.** Name its CURRENT shape first, then order the
  redraw.
- **"Every plate" in a group frame.** Count them. ALL FOUR.
- **Letting the label card follow the new shape.** The card is a RIGID OBJECT and the instruction
  says so.
- **Carrying the source's claims into a child.** Each child's printed facts are checked against its
  own source. Unknown means removed, never guessed.
- **Trusting the drift numbers alone.** They are blind to a melted label. Open every hero.
- **Judging a swatch at full size.** Swatches are made only when you ask for one, so a family
  without them is finished work, not a gap. If you did ask, judge it at picker size: they all look
  lovely at full size and nobody sees them there.
- **Re-running the family to fix one child.** Re-run the child on its fixed prompt.
- **Uploading draft-resolution files.** The upscale is owed, not done here. The Shipping Room runs
  it once on Day 10, reused frames included.

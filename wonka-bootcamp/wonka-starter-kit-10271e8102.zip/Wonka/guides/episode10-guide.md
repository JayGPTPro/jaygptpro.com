# Day 10: Your Next Product Starts Here

The last day. Three lessons: get your final files ready for Amazon, make the next product better
with what this one taught Wonka, and keep working with him from here, on the next product, the next
brand, and the work beyond Amazon.

**The sentence for the day: by the end you know where your files are, what still needs your
attention, and how to come back to Wonka with the next assignment.**

## What you will have by the end of today

- Your finished package in `output/`, with a handoff document that names the exact files to upload,
  says whether the package is ready or which assets are held, and lists everything still pending
- Every enlarged file checked against the file you approved
- Your Improvement Log written, with every lesson labelled at the strength the evidence carries, and
  a clear picture of where the next product's research and brief read it. A run with nothing new to
  record is a valid result
- Any working preference you chose to save, so you stop repeating it
- The sentences to copy for more products and more brands, when you need them, and a clear idea of
  what belongs in a separate employee

## What you will need at hand

- Your Day 8 decision recorded, and Day 9 done or skipped in writing

---

## Lesson 1: Get Your Files Ready for Amazon

### Today we finish the job

You did the research, made the images, tested your choices and worked through the fixes. Today the
final files get ready for Amazon. Then you save what you learned, so Wonka can use it when you bring
in your next product.

### Ask for the final package

Open your Wonka project and run:

```
/ready-to-upload
```

This command opens the Shipping Room, and it runs when YOU ask for it: nothing packages off an
approval you gave on an earlier day. The Shipping Room collects the versions you selected, checks
the export dimensions and formats, and puts the package together. If something needs enlarging, he handles that
through the available tool, within the budget you agreed to.

Once that is done, ask him to open the folder:

```
Open the final upload folder for this product.
```

Inside your Wonka folder, open `output/`. Each finished product has its own package there, named
`output/[product-slug]-package/`. In the recorded project it is
`output/chocolate-fondue-fountain-package/`.

The project also keeps the matching source at `factory/Products/[product]/final/`. The package in
`output/` is an exact copy of it. For the files you are taking to Amazon, start with the package in
`output/` and its upload instructions, `upload-pack.md`.

Inside the package, `upload-pack.md` names the exact delivery file for every slot, by path, so you
never have to work out which is which. Where a file was enlarged for delivery, the enlarged copy is
the upload and the version that was raced and inspected stays beside it as the record; the handoff
tells the two apart by filename. Your package's folders and sizes come from its own manifest, not
from anyone else's project, so read the list rather than assuming a layout.

You do not need to search through the earlier versions or download every image from the chat.

**What Wonka does:** resolves the source you actually chose for each class of asset, including a
revision you approved after the test; reads every file's real pixel size; runs the one owed
enlargement, on the files that ship, at a cost read live from your account and inside the budget you
agreed; assembles `final/`, copies it to `output/`, and checks the copy file by file.

**What you check:** that the main is the one you decided on, that the gallery order is the one you
want, and that every open item in the handoff is one you recognise.

### One final look

Give the final files a quick look before you upload, especially the small text and details of the
product.

We caught an example in our run: enlargement changed some lettering that was already correct in the
source. Wonka fixed that region. That is why the exported file gets checked as well as the original
image. Wonka does this read for every enlarged file and records the outcome in the handoff; your eyes
are the second check, on the files that matter most to you.

If anything is still flagged, deal with it before using that file. Use the upload list in the
package to find the selected final versions.

For variations, check that the image and its claims match that particular product. The parent's A+
does not automatically apply to every variation; each one needs its own review.

A packaged folder is a packaged folder. It does not verify a product claim, and it does not make a
listing compliant. Anything the handoff lists as assumed or unreviewed is yours to resolve before
you use that file.

### Take the files to Amazon

Once the final checks are done, these are the files to upload to Amazon. Follow the upload
instructions in the package: which main, the gallery order, and which files belong to each product,
by filename. The record files sit beside the delivery files, so selecting the whole folder would mix
the two.

The handoff's `Upload readiness` line tells you which of two states you are in. `Ready` means
nothing is held: follow the list. `Assembled with upload blockers` means one or more named assets
wait on a specific step (a claim to source, a tag to confirm, a file to enlarge) while everything
else uploads as listed. Notes marked informational hold nothing back. Wonka writes the blocker down;
writing it down does not resolve it, and that asset stays held until the step is done.

Our demonstration product belongs to another seller, so nothing was uploaded and no Amazon
experiment was started. Its handoff still carries named open items, and that is what an honest
handoff looks like. For your own product, this is where you put the work to use.

Next, save what you want Wonka to remember from the project.

---

## Lesson 2: Make the Next Product Better

### Save the useful part of the experience

Every product gives you feedback. You find a look you like, correct something Wonka missed, or
discover that an idea did not work as well as you expected. The Improvement Loop is how that
experience helps with the next product.

```
run /improvement-loop
```

Wonka goes through the available test results, corrections and decisions, then saves the useful
lessons in the Improvement Log, `factory/Improvement Log.md`. You do not need to write a recap of
the project yourself.

### What gets saved

Some lessons are about the images: a style you prefer, a detail customers need to understand, or an
idea worth testing again.

Others are about how Wonka works. For example, our enlargement issue became a reminder to check
printed text against the source after an upscale. That is something specific the next job can use.

You can save your working preferences too. If you prefer short updates or want to see visual options
first, tell him and ask him to save it, so you do not have to repeat it. Nothing to save is a fine
answer; nobody has to invent a preference or a mistake to finish the day.

The evidence behind a creative lesson matters. Our AI-panel results were labelled Lean. They gave us
ideas to test, not proof of what customers will buy, and Wonka writes them that way: as hypotheses
to test, never as rules. Take a moment to read what he saves. In our run I asked him to soften a few
conclusions because they were too broad for the evidence we had. You can say the same:

- "Keep this as a hypothesis to test."
- "That was a problem in this image; don’t turn it into a rule for every product."

You can correct the lesson just as you would correct an image.

### Where it helps next time

Here is where this becomes useful. When you bring in your next product, Wonka reads these notes
during the research (that is `/meet-my-product`, the room you ran on Day 2). He uses the relevant
lessons alongside the new product information, and he reads them again when he writes the brief
(`/creative-brief`, Day 3).

So if you already explained what feels right for your brand, or corrected a mistake in the way he
researches, that information is there for the next job.

The new product still gets its own research. What you learned helps guide it, and each lesson stays
in its own lane: a working preference is general, your taste belongs to that brand, a product fact
belongs to that product, and a hypothesis from the panel is something to test on the next product,
not a rule to apply to it.

As you work on more products and give more feedback, Wonka has more of your preferences and
experience to work with. That is how you make him a better fit for you over time. This is saved
context, not training: there are files he reads, and you can always open `factory/Improvement
Log.md` and see what you taught him. If you change your mind, tell him to update the note.

### Bring back new results

Later, if you get customer feedback or results from an image experiment, bring those back too:

```
Here’s the feedback on these images. Review it and update the relevant lessons for our next project.
```

Wonka compares them with the earlier notes and updates what he learned. You do not need to write a
long explanation every time. Show him what happened and tell him what matters.

### You can finish here

Once the lessons are saved and you know where the work stands, you can finish the session. Wonka
recognises the work, tells you what was saved and what is still open, and lets the session end. He
does not send you into another room, offer a report, or ask you an administrative question. I simply
wrote, "We’re done. Thanks, Wonka!"

Come back to the Improvement Loop when there is something new to learn from. With nothing new, Wonka
says so and leaves the log as it is.

Finishing the course and finishing a product are two different things. You can complete these
lessons while your own project still has open work in its handoff. That work stays written down,
honestly, and course completion never turns into a claim that every asset passed every check.

---

## Lesson 3: Your Creative Employee, From Here On

### Come back with the next assignment

The next time you need images for Amazon, open this Wonka project and start the conversation here.
You can say, "I have another product. Let's get started." The research, the brief, the image work
and your feedback all have a place already. Wonka gets to work on that product; there is no
graduation conversation to have first, and he does not walk you through the ten lessons again.

Wonka organises a separate folder for that product. Give him its details and references, and tell
him which brand it belongs to.

Think beyond Amazon images too. Wonka is the employee to come to for creative work: website images, a
campaign, a storyboard, a product video. If the job needs a tool or skill he does not have yet, ask
him to help you add it.

### More products and more brands

You explain the business relationship. Wonka does the filing. You never need to learn internal paths
or move project folders yourself.

**Same brand, new product:**

```
I have another product for [brand name]. Use that brand’s kit and start a separate product project. Here are its product details and references.
```

Wonka reuses that brand's kit: the visual direction, logo and tone you established. The product gets
its own research, references and brief. You are reusing the brand identity; you still check what is
true about this particular product.

**Another brand:**

```
I’m adding another brand called [name]. Help me create a separate brand kit and connect its products to it. Here are the brand materials I have.
```

Stay in Wonka and ask for a separate brand kit. Provide a website, logo, existing images or whatever
guidelines you have. Make the brand name clear when you start a product, so one brand's colours,
tone or product claims do not spill into another. The first brand's kit and preset are left exactly
as they were. If Wonka ever cannot tell which brand a product belongs to, he asks you one question
rather than guessing. If you have one brand, or none, none of this applies to you: nobody needs a
second brand to finish the course.

**Connected brands:**

A participant asked about a skincare brand connected to her personal brand. That is a useful
distinction to explain to Wonka: how are the two related, what should they share, and what should
stay separate?

```
My skincare brand is connected to my personal brand. Help me define what they share and what stays separate, then associate each product with the right brand kit. Ask me about any relationship that isn’t clear.
```

You do not have to design the folder structure yourself. Explain the relationship and ask Wonka to
confirm how he will organise the work. He records your answer in both kits, in your words. Each
product's claims still need their own supporting facts; a founder's credentials do not verify a
product claim, and nothing about claims moves between brands because they are related.

### Make the kit yours

If you want to make product videos, ask Wonka what tools and skills that would take, then build on
the setup you already have:

```
I want to make short product videos. Help me add the tools and skills we need.
```

You can also adapt an existing skill: a different style of brief, another export format, a
particular review step before a batch runs. Explain the change, have Wonka help you make it, and try
it on a small task. You may need another connection, access to a service, or a budget for that work.

Wonka does not rewrite his own kit off a passing remark; a clear request from you is the route. A new
capability goes in its own skill, which later kit updates leave alone. A change to one of the kit's
own skills gets overwritten by the next update, so Wonka tells you that first and offers the durable
form: a new skill beside the original, or a note you re-apply.

Do not feel limited to the kit you were given. Use it, notice what your business needs, and keep
making your version more useful.

### Let the tools change

The models will change too. The tool we used for one job may not be the one to choose six months
from now. Ask Wonka to check what is available through your connected tools, including Genrupt, and
whether another option is worth trying:

```
Check which image models we can access now. Is there a useful comparison to try for this task?
```

Give it a real question. Can this model preserve the product better? Can it handle the text we need?
Is the result worth the cost? Try a relevant example, look at the output, and save what works. You
can change the tool for one step while keeping the research, the brief and the direction you have
developed.

Saved instructions and context are what give Wonka continuity. There is no retraining, no perfect
memory, and no automatic access to every new model; there are files he reads and connections you
give him.

### One employee for each role

Separate brands can belong to the same creative employee. A different job is a different employee.

Take customer service. Give that employee a separate project, its own instructions, your policies,
the right tone and the tools it needs. Define which decisions it can handle and which come back to
you. You open that folder in Claude Code and work with the instructions, knowledge and tools you set
up for that role.

Keep Wonka focused on creative work and give the other role its own context. You can ask Claude to use
Wonka's structure, or Donna's if you have her, as a starting point and adapt it. Adapting a structure
copies the layout, not the keys: the new employee gets its own connections, its own permissions and
none of Wonka's product history.

Start with a job you actually need help with. Give it a clear role, work with it, and improve it
through feedback.

Optional example, not a course assignment:

```
Help me build a customer service employee in a new folder, using Wonka’s structure as a starting point. Give it the instructions and skills that role needs.
```

### One useful optional command

When you're working on several products, you can ask Wonka for a status report with
`/factory-report`, to see where each product stands and what comes next.

### Finish with a useful next step

Today, get your final files ready, use them on your listing once the checks are complete, and save
what you want Wonka to carry into the next project.

If you are still working through an earlier day, continue from where you are. If your product does
not have variations, you do not need to invent them to finish the course.

Once you are ready, bring Wonka the next real assignment. That is how this becomes part of your
business.

If you would like another employee alongside him, you can also join the Donna Challenge. Donna is
where the day-to-day side gets handled: inbox, calendar, meetings and routines.
https://jaygptpro.com/claude-code-challenge-launch/

---

## MISSION 1: Get your files ready

```
/ready-to-upload
```

Open `output/[product-slug]-package/`. Check the main, the gallery order, the exact upload filenames
in `upload-pack.md`, the `Upload readiness` line, and every open item. Then use the files on your
listing once the checks are complete, holding back only what the handoff holds back.

## MISSION 2: Save the lessons

```
run /improvement-loop
```

Read what was saved. Soften anything broader than the evidence. If there is a working preference
you want kept, say it in your own words and ask him to save it. Then close the session; a "We're
done" is enough.

If you want to, send Jay the one line from your own Improvement Log that surprised you. Not
required.

---

## Course completion

Three things, and you are done with the course:

- I know where my final files are and what, if anything, still needs attention.
- I have reviewed the useful lessons saved from this project, or confirmed there was nothing new to
  record.
- I know how to start another product or add another brand.

`guides/graduation-checklist.md` carries the same three lines, with the longer production checks
underneath as an optional reference.

## What good looks like

- You can open `output/[product-slug]-package/` and the handoff names the exact file for every
  upload slot, delivery told apart from record, and says whether the package is ready or which
  assets are held
- Every enlarged file was read against its source, and any repair is named
- Every open item is written in, not left as an absence
- Every creative lesson carries its evidence and its label; a Lean reads as a hypothesis, and a
  loss earns AVOID only when it lost clearly
- Where something went wrong, the mistake is recorded and the practice it taught is kept; a clean
  run says so and invents nothing
- Any working preference you wanted kept is saved in your own words
- You know that the next research and the next brief read the log
- The session ended when the work ended

## Common mistakes

- **Uploading the whole folder.** The record files sit beside the delivery files. Follow the list.
- **Treating the package as a compliance check.** It is not one. Claims and placement requirements
  are yours to resolve.
- **Handing the parent's A+ to a variation.** Each child needs its own review.
- **Turning one Lean result into a rule.** Keep it a hypothesis, keep its source, test it next time.
- **Running the Improvement Loop again for a fresh summary.** With nothing new, there is nothing to
  write.
- **Building the next brand as a new Wonka.** Same employee, separate kit. A new employee is for a
  new job, not a new brand.

---

## And that is the bootcamp

Thank you for spending these ten days here. You brought the product knowledge, made the choices, and
spoke up when something was not right. That work shows in the result.

Take a moment to enjoy what you have made. The day, and the course, end on the Wonka film. Then
bring Wonka the next one.

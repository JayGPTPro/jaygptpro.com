# Day 8: The Tasting Room

Seven days of making things. Today the making stops and the finding-out starts.

**The sentence for the day: this replaces asking an AI to score your images, and it is several
levels above that.**

## What you will have by the end of today

- **Two Tasting Cards**: your shortlist against the image that is live now, and your whole gallery
  against the whole live gallery
- A result in one of three tiers, and the knowledge of what each tier tells you
- **A list of objections in the tasters' own words**, sorted into what creative can fix, what the
  listing can fix, and what nobody can fix
- **A list of proposed changes, with the evidence behind each one, and YOUR decision on them.** Wonka
  proposes; you decide; then the changes you named run. Whether the final set should replace what is
  live is your call, and all three panel answers are legitimate: one of yours takes a **Clear lead**
  and the decision is easy; your **live image holds** and you just avoided downgrading a working
  listing for the price of lunch; or the read is **Lean or a Toss-up**, a hint, and you decide what
  to do with it
- **Nothing uploaded.** Day 8 tests, Day 10 ships. No file leaves the factory today
- Two rows in your Improvement Log

**Time needed:** 90 minutes to two hours, and a chunk of that is waiting rather than working. Start
the races and go and do something else.

## What you will need at hand

- Your gate-passed candidates, already recorded: the `Main pick:` row `/inspect` wrote on Day 5 and
  the `Gallery pick:` row when it is there, or the set on disk when it is not. Wonka reads those; he
  does not ask you to choose again. **Your CURRENT live main image and gallery** are fetched by Wonka at the opening of the room
  (`/tasting-room`, step 0b) into `incumbent/` as `main-live.png` and `live-01..NN.png`. You save
  them by hand only if the fetch is refused, and he will say so
- Your `OPENAI_API_KEY` in the factory root `.env`. **This spends your own money**, a few dollars per
  race. Wonka prints the estimate before each race and runs. He stops before running for three
  things only: a missing selection, a technical blocker, or an estimate above the $10 cap

---

## Lesson 1: What This Test Can Tell You

Lesson 1 is the idea and the start of the run: `/tasting-room` is typed inside this lesson, and the
missions below are the checklist for it.

### What everybody else does

You have five candidates. The obvious move is to paste them into a chat and ask which is best.

You will get an answer, confidently, with a number on it.

Now think about what produced that answer. **One model, with no age, no income, no shopping history,
and no reason to prefer anything, having a single opinion.** That is not analysis. It is a confident
guess with a decimal point attached.

It is better than nothing. It is not much better than nothing.

### What this does instead

It builds a **panel**.

**About a hundred distinct shopper personas**, each one conditioned on YOUR buyer: the age, gender,
income and shopping habits that came out of your research on Day 2. Not generic people. Yours.

**Each is shown the candidates the way a shopper meets them**, in random order, without knowing which
is the incumbent and which is new.

**And none of them is asked to score anything.** They react, in their own words. Because people, and
models playing people, are genuinely bad at scoring and genuinely good at reacting. Ask for a number
and you get a number. **Ask for a reaction and you get the truth, plus a number.**

Then a separate pass reads a hundred free-text reactions for purchase intent, runs a blind forced
choice, and produces a result with a **stability tier** attached, so you know whether the gap is real
or whether it is noise.

That is several layers of work, and each one exists because the layer under it was not good enough.

### What it is NOT

**This does not replace a paid survey with real people.**

Real humans, recruited and paid, remain the gold standard, and there is an optional lesson after
Day 10 on running one cheaply. Not in your ticket, not required. **When a decision carries real money,
a hero SKU, a rebrand, a packaging run, that is what you should reach for**, and you should decide
that for yourself rather than take anyone's word.

These tasters are language models playing a role. They can be wrong, and they can be collectively
wrong in the same direction, which is worse. Synthetic preference is not real-shopper behaviour or
conversion evidence.

**What it absolutely does replace is "Claude, tell me which of these is best."** That is the
comparison that matters, because that is the thing you were actually going to do.

### And what it is FOR

**One more round of sharpening, before this goes anywhere expensive.**

Not a verdict. A refinement step, sitting between your own eyes (compromised, because you have looked
at these for seven days) and the two places where being wrong actually costs: Amazon, and a paid survey.

By the end of today you have read what a hundred reactions noticed, decided what you agree with, and
changed what deserved it, which may be nothing. That is the whole point of the room.

### Two races, and no listing yet

**The mains:** what is live on your listing now, against the new ones you made.

**The gallery:** your set against the live set, in order.

**And if nothing is live yet**, because you are launching, the benchmark is **the strongest
competitor's** main and gallery from `1-inputs/competitors/`. Wonka copies them into `incumbent/` as
`competitor-main.png` and `competitor-01..NN.png` and records `benchmark: competitor [name]`. Say
which competitor and why, because "beats the category leader" and "beats my old image" are different
claims and your Card should not blur them.

### Invoking the room runs it

`/tasting-room` is the authorisation. There is no "proceed?" and no second confirmation of a choice
you already made on Day 5 and Day 6.

Wonka resolves four things and prints ONE block: the main lineup by exact filename, in the order of
your `Main pick:` row; the gallery order by exact filename, with its frame count printed next to the
live gallery's count; the benchmark, named; and the estimated cost of each race. Then both races run.

**Read the block.** It is the one place today where a wrong file would be caught. The set you would
upload TODAY, after a fix round, is not the one in `images/`: the factory writes each fix round as a
complete copy of the set into `edits/v1/`, then `edits/v2/`, keeping the same filenames, so the
current `main-13.png` is the one in the highest `edits/` folder. Wonka races that copy and the block
says which folder each file came from. Racing the superseded set and then acting on the result wastes
the whole run, and because both copies carry the same filename, nothing downstream can tell you it
happened.

Wonka stops before running for three things only: a missing selection (no `Main pick:` row and nothing
on disk that records your choice; he asks one question, writes your answer as the row, and continues),
a technical blocker (no key, a file missing), or an estimate above the $10 cap. If you want to see the lineup without running, say so:
"show me the lineup" or "prepare but do not run" is honoured as asked.

### The cap

Every race is priced before the first request, from what the engine already knows: how many tasters,
how many candidates and frames, which models, at their list prices. The line reads
`Estimated: about $2.97 for this race (cap $10 per sitting)`, which is what three mains plus your
incumbent print. A standard sitting (three or four mains, a gallery of six to eight frames) lands
under the cap, about $7 to $9 for both races. The largest lawful selection (five mains, a nine-frame
gallery against nine live frames) estimates just over it, and Wonka asks once, "Run it anyway?"; a
yes raises the cap for that sitting only. Under the cap he does not ask; he says the number and runs.

### The incumbent is not optional

Without your current live image in the race, you find out which of YOUR images the panel prefers,
which is interesting and useless. The decision is not "which of mine". **It is "is any of mine better
than what I already have".**

### The gallery goes in as a stack, in order, as it is

Not frame against frame. A shopper does not compare your image three to your image five, **they swipe
a sequence and form an impression**, so the sequence is the unit.

Order is part of what is being tested. Your strongest frame leading is a different gallery from your
strongest frame at position five, using the same images.

Your gallery will usually have a different frame count from the live one. That is normal, and nothing
is dropped to make them match. The block prints both counts, the Card prints both counts, and the
read says plainly that count and content differences (a frame type one set has and the other lacks,
another model of the product in the live gallery) limit what can be attributed to your creative
changes. If you know the live gallery shows another model, write `other model: live-04` in
`incumbent/notes.md` and Wonka prints it with the result.

### It takes a while, and that is fine

This is not instant. It is a hundred personas reacting, twice.

**A live page opens by itself and refreshes on its own**, showing which phase it is in and how far
through, and telling you honestly if it has stalled. If the page does not open, `progress.json` in
the round folder has the same information.

**Then go and do something else.** Genuinely. Watching the bar is not participation and it will not
make it faster. Make a coffee, answer an email, come back when it is done.

---

## Lesson 2: Read the Insights Behind the Numbers

Nothing is generated or changed in this lesson. Wonka reads both Cards, summarises each race in a
few lines, lists what the notes propose, and stops. The decisions are yours.

### How to read a result

| Tier | What it means | What it tells you |
|---|---|---|
| **Clear lead** | Two things at once: the panel agreed on a direction, AND purchase intent separates them by at least +0.25 of 5 | A strong signal. Even a strong count is a count inside the simulation, and the comments are where the time goes |
| **Lean** | Ahead but not by enough, OR stable with a difference too small to act on. A card saying **"Consistent, not decisive"** landed here | A hint. Hold it loosely |
| **Toss-up** | Nothing separated them | **A real answer.** That decision does not matter. Spend the attention elsewhere |

**A hundred synthetic tasters leaning a handful of votes is not a fact about the world.** It is a nudge.

### Start at the tier

See the table. And the sentence to carry out of the room: **a hundred synthetic tasters leaning
three points is not a fact about the world.**

**A toss-up is a result**, not a failed test. It told you where NOT to spend attention.

### Then per candidate, in their words

Not a score. **What a hundred simulated shoppers thought was going on in the picture**, which is a completely
different kind of information from "7.2 out of 10".

### Then the objections. This is the part that pays

Every taster says WHY, in their own words, unprompted.

A result tells you candidate three won. **The objections tell you that eleven tasters could not tell
how big it is, four thought it was plastic, and two assumed it needed assembly.**

Those are not opinions about your images. They are the questions your listing is failing to answer,
handed to you in a list, before you have spent a cent on advertising.

Read all of them. Verbatim. Sort as you go into three piles:

**Creative can fix it.** They could not tell the size. They thought it was plastic. Images that
failed to communicate.

**The listing can fix it, but not with an image.** A question about what is in the box, a spec nobody
could find. That belongs in your bullets or your A+.

**Nobody can fix it.** "Too expensive." "I would not use it often enough." Real, and no photograph
solves them. **Writing them down as unfixable is what stops you trying to photograph your way out of
a pricing problem.**

### And a warning about taste

**Do not treat this panel's taste as authoritative.** It will sometimes prefer something you can see
is worse. It is a hundred models, not a hundred people.

**Do take its advice seriously when it sounds right to you.** "They could not tell the size" is
information regardless of who said it, because it is about comprehension rather than preference.

**Comprehension objections are the gold. Preference verdicts are the nudge.** Weigh them differently.

### The cross-read

Look for **the same objection appearing in BOTH races.** That is not about one image. It is a gap in
your listing that your creative has not closed anywhere.

### The proposals, and why they are proposals

Wonka groups the objections by theme **with counts** and lists the candidate changes. Every line says
which objection it answers, how many tasters raised it, and what he saw when he checked it against
the actual image and your product research. A proposal that contradicts the research is listed as
refused, with the reason, before you ever see it as a change.

**Three mentions is a reason to look, not an order.** One taster is noise; three is worth checking.
Checking is what Wonka does before the list reaches you. Acting is what you decide.

"Make it clearer that it is big" **is not a change, it is a wish**, and nothing can act on it.
"Add a hand holding it at the same scale as the size callout" **is a change.** Every proposal on the
list is physical, or it is not on the list.

**Then he stops.** He does not edit, regenerate, or start another race on his own. The Card's last
line says it: read the objections, then tell Wonka which changes to make.

### Your move: name the changes, if any

**You do not have to act on every objection.**

Some contradict each other. Some come from a taster who is not your buyer. Some ask you to promise
something your product does not always do, which is exactly what your brief spent Day 3 preventing.

Name the changes you want, which may be none. You do not have to agree with every suggestion, and
you do not have to keep editing until no simulated profile has an objection. When you do refuse one,
say so out loud with your reason, and it is recorded. A refusal with a reason is a decision. A
refusal you never mention is just something you ignored, and in three months you will not remember
which it was.

And decide what you approve; whether it ships is Day 10's question. A Clear lead makes it easy. A Lean or a
Toss-up makes it yours: you may approve your pick after either, and Wonka writes the decision on its own
line, with the label kept exactly as the panel gave it. He never talks a Lean up into a win, and he never talks you out of your listing.

---

## Lesson 3: Turn One Insight Into a Better Image

Now, if you found something worth doing, you do it. That is the part almost nobody does.

### The changes you named, and what each one costs

Once you have named them, the changes run the way fixes have run since Day 5, by one of two routes.
A new layout is a regeneration on Genrupt: your request named it, so Wonka says its credit cost and
runs it, and the new candidates land in the same conversation for you to pick from. A removal or an
added line is an edit for cents, run on a report without a per-operation approval prompt. The
routine-fix policy caps a round at 12 paid edit calls, $3.00, and 2 attempts per defect. Wonka stops
only for a crossed limit, or for a regeneration he proposed himself rather than one you asked for; the
three stops before a race (a missing selection, a technical blocker, over the cap) are behind you by now.

Same routing as Day 5: on the winner itself, take something away, swap a word, move a part back or
restore a marking is an edit for cents through the direct API with only that region changed; a bigger
text or a new composition is a regenerate built from the winner.

### And everything gets re-checked

**Everything touched gets re-inspected before you call it finished.** A fix introduces problems: you
enlarge the size callout and crowd the headline, you remove an element and unbalance the frame.
Catching that with a scorecard is free.

### The final set is recorded

Tested against what is actually live. Sharpened by the reactions you agreed with.
Re-checked afterwards. And written down: the files that are final, the label the panel gave, and your
decision line when the decision was yours. Files changed after the test are marked `revised after
test` when they are packed on Day 10, with the raced original named beside them.

**Your acceptance is written as its own line.** When you approve the set, Wonka writes `Owner decision:
approve the Day 8 image set ...` into `status.md`. That line completes Day 8 and nothing else: it does not
skip variations and it does not start the packaging. The approval, the panel's verdict and the finish of
the later days are three different records, and he keeps them apart.

**And when you say stop, he stops.** "We're stopping here", "mark Day 8 complete", "next is Day 9 in a
new session": he saves everything to disk, writes `Next stage: Day 9, variations (session ended at
the owner's word, [date])` as the last line of `status.md`, and ends. No room is opened after it, no question is asked for tomorrow. The new session
resumes from that line.

**Nothing is uploaded today.** Day 8 tests, Day 9 is variations, Day 10 ships. The Shipping Room is where
every file gets its pixel size measured and its one upscale before it leaves. It runs when you ask for it,
after Day 9, never on a label and never on your approval of the images.

### Another comparison, only when it answers a question

A second round is not a step in the method. It exists when it answers a concrete question, normally a
meaningful revision or a new candidate: "does the winner with the hand for scale beat the live image
by more than it did without?" is a question a round can answer. "Can I get a better number on the same
images?" is not; the panel is seeded, so unchanged images replay the same verdict at full price.

Wonka may suggest one when it would answer something. He never launches it. If you ask for it, that
is the authorisation: he states the estimate and runs within the cap.

---

## MISSION 1: Open the room

```
/tasting-room
```

The room opens by fetching your current live main image and gallery into `incumbent/` (step 0b).
If nothing is live, Wonka proposes the strongest competitor from your research and says why; you
confirm or name another. He copies that competitor's main and gallery into `incumbent/` and records
the benchmark by name.

Then read the block he prints: **is my current image (or my chosen competitor) in the race**, **are
these the filenames from my pick rows, from the right folder**, and **what does each race cost**.
Both races start on their own. If you would rather see the block first:

```
Show me the lineup, do not run yet.
```

## MISSION 2: Both races, then walk away

Open `live.html` when it appears, glance at it once, **and then go and do something else.**

## MISSION 3: Read both Cards against the images

Tier first. Then every objection, verbatim, sorted into the three piles, each one checked against the
actual image and your product research. Wonka records both races and checks the coverage himself; an
objection that appears in both races is your biggest gap, and he points at it.

## MISSION 4: Change an image, if you found something to improve

Changing an image is optional. If the feedback showed you something worth improving, stay in the same
conversation and tell Wonka which image to change and what to keep. Replace [image] with the image name:

```
Let's try a simpler layout for [image], keeping the same message. Leave the other images as they are.
```

Wonka routes it: a new layout is a regeneration on Genrupt (he says the credit cost and runs it, because
you asked for it); a removal or an added line is an edit for cents. The new version lands in the next
`edits/vN/` folder and the original stays where it was. Then review the result at full size and as a
small preview. Check the text, the product details, and the area around any edits. If nothing deserved a change, go straight to
Mission 5.

## MISSION 5: Approve and stop

```
I approve the current set. Save our progress and decisions, note any images revised after the test, and finish Day 8. Stop here. We'll do variations in a new session.
```

Approval closes Day 8 and opens nothing. Day 9 is variations; the Shipping Room comes after that, on
your word.

**Share it:** send Jay your most surprising objection. Not your result. Your objection.

---

## What good looks like

- It raced the files from your pick rows, from the right folder, and you read the block
- Your current live image, or a named competitor, was in both races
- Both stacks went into the gallery race in ORDER, as they are, both counts printed
- The estimate was printed for each race, and the sitting stayed under the cap (or you said yes once)
- You read the tier before the count, and treated a toss-up as an answer
- Every objection read verbatim and sorted into three piles
- Any objection appearing in both races is written down as your biggest gap
- Wonka listed proposals with their evidence and stopped; nothing ran that you did not name
- Every change you named is physical and cites the objection or the vote it answers, with a count where one exists
- Any objection you refused was refused out loud, with its reason recorded; refusing none is fine
- Everything changed was re-inspected, and changing nothing was a lawful answer
- **Your set is final, your decision is written down, and you can say in one sentence what the panel
  said about it**, including when the answer was your own live image
- Nothing was uploaded and nothing was packaged. Your `Owner decision:` line is written; Day 9 is
  variations; Day 10 packs when you ask for it

## Common mistakes

- **Racing an old version of your images.** Read the block; it names the folder.
- **Racing without the incumbent.** You learn which of yours the panel likes. Useless.
- **Answering a question nobody asked.** Wonka does not ask you to re-confirm your picks. If he asks
  which main is your primary, your `Main pick:` row is missing; answer once and he writes it.
- **Watching the progress bar.** It is not participation. Go and do something else.
- **Reading the count instead of the tier.** A handful of votes is a nudge.
- **Treating a toss-up as a failure.** It told you where not to spend attention.
- **Reading only the winner.** The objections are the part that pays.
- **Trusting its taste over your eyes.** Trust its comprehension objections instead.
- **Acting on every proposal.** Some contradict. You may refuse any of them; say why and it is recorded.
- **"Make it clearer" as an instruction.** Nothing can act on a wish.
- **Re-racing unchanged images for a better number.** The panel is seeded; you would pay full price
  for the same verdict.
- **Believing this is real shopper data.** It is not, and it never claims to be.

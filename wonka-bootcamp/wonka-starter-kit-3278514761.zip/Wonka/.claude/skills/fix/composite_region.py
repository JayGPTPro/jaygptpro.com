#!/usr/bin/env python3
"""Keep everything outside the fix byte-identical.

The OpenAI edit endpoint re-renders the WHOLE frame, so a local fix (a part moved, a marking
restored, an object reshaped) comes back with the rest of the picture slightly different: text
re-typeset, the other product resized, the framing drifted. Measured on the Day 6 secondary set,
7 September 2026: a tower re-centred on the left machine came back with both machines smaller
and the jug reshaped, and the whole edit was rejected for the drift.

This tool takes the changed REGION from the render and pastes it back onto the edit base, with a
feathered edge, so only the region changes and every other pixel is the base's own:

  python3 .claude/skills/fix/composite_region.py <base.png> <render.png> <out.png> x,y,w,h [x,y,w,h ...] [--feather 24]

Boxes are in the base's pixels. The render is resized to the base's size first (the endpoint
returns its own working size). The feather runs INWARD: the soft edge lives inside the box, and
the blurred mask is clipped to the union of the boxes, so no pixel outside that union can change.
Boxes are validated before anything is written (inside the image, non-empty, twice the feather
smaller than the box's short side, so the render still lands at full strength in the middle) and the tool exits non-zero with a plain message otherwise.

Prints how many pixels changed outside the boxes (must be 0) and inside them, so the log carries
a number instead of an impression. Both counts are measured against the plain box union, never
against the blurred mask the output was built from (v28 measured against the blurred mask, so
every pixel the blur leaked into counted as "inside" and the tool printed 0 outside while 10,125
pixels outside the box had changed). The eye still verifies the seam and the region afterwards
(fix skill step 9): a paste edge must never cross the object.
"""
import sys
import numpy as np
from PIL import Image, ImageDraw, ImageFilter

def parse_boxes(boxes, size, feather):
    """Return [(x, y, w, h)] or exit with a plain message. Nothing is written before this passes."""
    W, H = size
    if feather < 0: sys.exit(f"feather must be 0 or more, got {feather}")
    out = []
    for b in boxes:
        parts = b.split(",")
        if len(parts) != 4 or not all(p.strip().lstrip("-").isdigit() for p in parts):
            sys.exit(f"bad box {b!r}: expected x,y,w,h as four integers")
        x, y, w, h = [int(p) for p in parts]
        if w <= 0 or h <= 0: sys.exit(f"empty box {b!r}: width and height must be at least 1")
        if x < 0 or y < 0 or x + w > W or y + h > H:
            sys.exit(f"box {b!r} falls outside the {W}x{H} base image")
        if 2 * feather >= min(w, h):
            sys.exit(f"feather {feather} is too large for box {b!r} ({w}x{h}): twice the feather must be smaller than the box's short side; shrink the feather or grow the box")
        out.append((x, y, w, h))
    return out

def main():
    argv = sys.argv[1:]; feather = 24
    if "--feather" in argv:
        i = argv.index("--feather")
        if i + 1 >= len(argv) or not argv[i + 1].lstrip("-").isdigit(): sys.exit("--feather needs an integer")
        feather = int(argv[i + 1]); del argv[i:i + 2]
    args = argv
    if len(args) < 4: sys.exit(__doc__)
    base_p, render_p, out_p, *raw_boxes = args
    base = Image.open(base_p).convert("RGB"); render = Image.open(render_p).convert("RGB")
    boxes = parse_boxes(raw_boxes, base.size, feather)
    if render.size != base.size: render = render.resize(base.size, Image.LANCZOS)

    # The allowed area: a plain binary union of the boxes as given. This is the contract.
    W, H = base.size
    allowed = np.zeros((H, W), bool)
    for x, y, w, h in boxes: allowed[y:y + h, x:x + w] = True

    # The blend mask: boxes inset by the feather, blurred, then clipped to the allowed area so the
    # soft edge lives inside the box and nothing outside it can change.
    mask = Image.new("L", base.size, 0)
    d = ImageDraw.Draw(mask)
    for x, y, w, h in boxes:
        d.rectangle([x + feather // 2, y + feather // 2, x + w - 1 - feather // 2, y + h - 1 - feather // 2], fill=255)
    if feather: mask = mask.filter(ImageFilter.GaussianBlur(feather / 2))
    m = np.asarray(mask).copy(); m[~allowed] = 0
    mask = Image.fromarray(m, "L")

    out = Image.composite(render, base, mask)
    a, o = np.asarray(base), np.asarray(out).copy()
    o[~allowed] = a[~allowed]                     # belt and braces: outside the union is the base, byte for byte
    out = Image.fromarray(o, "RGB")
    changed = (np.abs(a.astype(int) - o.astype(int)).sum(2) > 0)
    outside = int(changed[~allowed].sum()); inside = int(changed[allowed].sum())
    if outside:
        sys.exit("composite touched pixels outside the boxes; nothing written. Check the boxes and the feather")
    out.save(out_p)
    print(f"wrote {out_p}: {inside} pixels changed inside the region, {outside} outside (must be 0)")

if __name__ == "__main__":
    main()

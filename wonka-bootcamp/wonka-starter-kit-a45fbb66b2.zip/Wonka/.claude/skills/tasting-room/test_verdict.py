"""Regression tests for the two reporting rules the panel gets wrong by default.

Both assert on RENDERED output, not on source text, so a behaviour-preserving
refactor keeps passing and a behaviour-changing one fails. Every test here was
watched to fail against the pre-fix code before it was kept.

Run: python3 test_verdict.py
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from panel import MIN_INTENT_GAP, bootstrap_stability, intent_magnitude  # noqa: E402

FAILURES = []


def check(name, cond, detail=""):
    if cond:
        print(f"  PASS  {name}")
    else:
        print(f"  FAIL  {name}  {detail}")
        FAILURES.append(name)


def agg_of(win_votes, lose_votes, win_intent, lose_intent):
    return {
        "new": {"choice_votes": win_votes, "ssr_mean": win_intent, "label": "new"},
        "live": {"choice_votes": lose_votes, "ssr_mean": lose_intent, "label": "live"},
    }


print("\n1. A near-unanimous vote on a hair of intent is NOT a clear lead")
# The real shape of the problem: 76-4 on the vote, +0.06 of 5 on intent.
agg = agg_of(76, 4, 3.430, 3.367)
stab = bootstrap_stability([("new", 76), ("live", 4)])
gap, decisive, _, _ = intent_magnitude(agg, ["new", "live"])
check("bootstrap alone says clear", stab["tier"] == "clear", f'got {stab["tier"]}')
check("intent gap is tiny", gap == 0.063, f"got {gap}")
check("magnitude gate refuses it", not decisive, f"gap {gap} vs bar {MIN_INTENT_GAP}")

print("\n2. The same vote WITH a real intent gap stays top tier")
agg = agg_of(76, 4, 4.10, 3.36)
gap, decisive, _, _ = intent_magnitude(agg, ["new", "live"])
check("large gap is decisive", decisive, f"gap {gap}")

print("\n3. An unstable vote is never rescued by a big intent gap")
stab = bootstrap_stability([("new", 42), ("live", 38)])
agg = agg_of(42, 38, 4.50, 3.20)
gap, decisive, _, _ = intent_magnitude(agg, ["new", "live"])
check("bootstrap says not clear", stab["tier"] != "clear", f'got {stab["tier"]}')
check("gap is decisive on its own", decisive)
check(
    "direction is checked FIRST, so it cannot be promoted",
    stab["tier"] != "clear",
    "the downgrade must only ever lower a tier the bootstrap already earned",
)

print("\n4. Missing intent data does not silently downgrade")
agg = {"new": {"choice_votes": 76, "ssr_mean": None, "label": "n"},
       "live": {"choice_votes": 4, "ssr_mean": None, "label": "l"}}
gap, decisive, _, _ = intent_magnitude(agg, ["new", "live"])
check("gap is None, not 0", gap is None, f"got {gap}")

print("\n5. No percentage survives on the choice metric, in any rendered surface")
src_panel = Path(__file__).with_name("panel.py").read_text()
src_card = Path(__file__).with_name("tasting_card.py").read_text()
banned = [
    ("Choice share", "the markdown verdict table header"),
    ("delta_pts", "the round-over-round comparison"),
    ("winner_vs_incumbent_pts", "the vs-incumbent line"),
]
for needle, where in banned:
    check(f"gone: {where}", needle not in src_panel and needle not in src_card, f'found "{needle}"')

# STRUCTURAL, not a hand-written list. Hand-listing missed five surfaces on the
# first pass; the whole point of item 1 is that ONE survivor undoes the rest.
# A percent inside a style="" attribute is bar geometry and is allowed. A
# percent anywhere else is a number somebody reads.
import re as _re  # noqa: E402
leaks = []
for lineno, line in enumerate(src_card.splitlines(), 1):
    for m in _re.finditer(r"\{[^{}]*\bshare\b[^{}]*\}%", line):
        before = line[: m.start()]
        if "style=" in before and before.rindex("style=") > before.rfind('"</'):
            continue                      # inside a style attribute: geometry
        leaks.append(f"tasting_card.py:{lineno}: {m.group(0)}")
check("no share is rendered as a percent outside bar geometry", not leaks, "; ".join(leaks[:4]))

print("\n6. The threshold is documented as provisional, with a refit trigger")
check("PROVISIONAL is written next to the constant", "PROVISIONAL" in src_panel)
check("the refit trigger is named", "Improvement Log" in src_panel)
check("standardising is explicitly ruled out", "Cohen" in src_panel)


# ---------------------------------------------------------------- item 4
print("\n7. The live page does not say FINISHED until the last artifact exists")
import json as _json, subprocess as _sp, tempfile as _tf  # noqa: E402
from progress import Progress, mark_finished  # noqa: E402

with _tf.TemporaryDirectory() as d:
    pr = Progress(d, title="t", open_browser=False)
    pr.update("reactions", 10, 10)
    pr.handoff("results written", "rendering the Tasting Card...")

    html = Path(d, "live.html").read_text()
    state = _json.loads(Path(d, "progress.json").read_text())
    check("handoff does not claim finished", state["finished"] is False)
    check("handoff sets awaiting", state["awaiting"] is True)
    check("bar is not 100", state["pct"] == 95, f'got {state["pct"]}')
    check("page renders the pending step", "rendering the Tasting Card" in html)
    check("awaiting gets its own stall window", "awaiting ? 600 : 120" in html)
    check("page does NOT say FINISHED yet", "const awaiting = true" in html and "{finished}" not in html)

    # closed by a DIFFERENT process, which is the whole point
    rc = _sp.run([sys.executable, "-c",
                  "import sys; sys.path.insert(0,%r);"
                  "from progress import mark_finished; print(mark_finished(%r))"
                  % (str(Path(__file__).resolve().parent), d)],
                 capture_output=True, text=True)
    check("a separate process can close the run", rc.stdout.strip() == "True", rc.stderr[-200:])
    state = _json.loads(Path(d, "progress.json").read_text())
    check("now finished", state["finished"] is True)
    check("now 100", state["pct"] == 100)

    check("idempotent on retry", mark_finished(d) is True)
    n_close = sum(1 for ph in _json.loads(Path(d, "progress.json").read_text())["phases"]
                  if ph["name"] == "tasting card rendered")
    check("a retry does not duplicate the closing phase", n_close == 1, f"got {n_close}")

with _tf.TemporaryDirectory() as d2:
    check("safe when no progress files exist", mark_finished(d2) is False)

# The checks above prove the Progress class behaves. They do NOT prove panel.py
# USES it correctly, and reverting panel.py to done() left them all green. So
# this one asserts the wiring. It is a source-level check and therefore weaker:
# it would false-fail on a rename. Kept anyway, because the alternative is no
# coverage of the actual regression, which is panel.py claiming completion.
print("\n8. panel.py hands off; it does not close the run itself")
src_panel_p = Path(__file__).with_name("panel.py").read_text()
check("panel.py calls handoff", "prog.handoff(" in src_panel_p)
check("panel.py never calls done", "prog.done(" not in src_panel_p)
src_card_p = Path(__file__).with_name("tasting_card.py").read_text()
check("the card process closes the run", "mark_finished(" in src_card_p)


# ---------------------------------------------------------- items 5 and 6
print("\n9. Coverage ACCUMULATES across the two races of a sitting")
import scope as _scope  # noqa: E402

def _mk(root, name, n=1, paths=None):
    d = Path(root) / name
    d.mkdir(parents=True, exist_ok=True)
    imgs = [{"id": f"i{k}", "label": "x", "path": p} for k, p in enumerate(paths or [])] if paths else []
    return d, imgs

with _tf.TemporaryDirectory() as root:
    prod = Path(root) / "prod"
    (prod / "images").mkdir(parents=True)
    (prod / "incumbent").mkdir(parents=True)
    for f in ["main-01.png", "main-02.png", "sec-01.png", "sec-02.png"]:
        (prod / "images" / f).write_bytes(b"x")
    (prod / "incumbent" / "main-live.png").write_bytes(b"x")

    s = _scope.derive(prod)
    check("derives the main candidates", s["main"] == ["main-01.png", "main-02.png"], str(s["main"]))
    check("derives the gallery frames", s["gallery"] == ["sec-01.png", "sec-02.png"], str(s["gallery"]))

    # race 1: main
    r1, _ = _mk(root, "r1-main")
    (r1 / "config.json").write_text(_json.dumps({"round": 1, "race": "main", "images": [
        {"id": "a", "path": str(prod / "images" / "main-01.png")},
        {"id": "b", "path": str(prod / "images" / "main-02.png")}]}))
    (r1 / "results.json").write_text("{}")
    _scope.cmd_record(str(prod), str(r1))
    check("gate blocks after only the main race", _scope.cmd_check(str(prod)) == 1)

    # race 2: gallery, posted after. THE bug: this used to erase race 1.
    r2, _ = _mk(root, "r1-gallery")
    (r2 / "config.json").write_text(_json.dumps({"round": 1, "race": "gallery", "images": [
        {"id": "ours", "paths": [str(prod / "images" / "sec-01.png"), str(prod / "images" / "sec-02.png")]}]}))
    (r2 / "results.json").write_text("{}")
    _scope.cmd_record(str(prod), str(r2))

    cov = _json.loads((prod / "tests" / "coverage.json").read_text())
    check("both races are in the coverage", set(cov["races"]) == {"r1-main", "r1-gallery"}, str(set(cov["races"])))
    check("race 1 was not erased by race 2", "main-01.png" in cov["races"]["r1-main"]["tested"])
    check("gate passes once both races are in", _scope.cmd_check(str(prod)) == 0)

    # a second ROUND registers its own row rather than reusing round 1's
    r3, _ = _mk(root, "r2-main")
    (r3 / "config.json").write_text(_json.dumps({"round": 2, "race": "main", "images": [
        {"id": "a", "path": str(prod / "images" / "main-01.png")}]}))
    _scope.cmd_record(str(prod), str(r3))
    cov = _json.loads((prod / "tests" / "coverage.json").read_text())
    check("round 2 keyed separately from round 1",
          set(cov["races"]) == {"r1-main", "r1-gallery", "r2-main"}, str(set(cov["races"])))

print("\n10. An untested approved frame blocks, and a waiver with a reason releases it")
with _tf.TemporaryDirectory() as root:
    prod = Path(root) / "prod"
    (prod / "images").mkdir(parents=True)
    for f in ["main-01.png", "sec-01.png"]:
        (prod / "images" / f).write_bytes(b"x")
    r1, _ = _mk(root, "only-main")
    (r1 / "config.json").write_text(_json.dumps({"round": 1, "race": "main", "images": [
        {"id": "a", "path": str(prod / "images" / "main-01.png")}]}))
    _scope.cmd_record(str(prod), str(r1))
    # This test used to pass BECAUSE of a bug: it never wrote a results.json,
    # and the gate counted the race as tested anyway. A run that crashed after
    # writing its config satisfied the coverage gate.
    check("a race with no results.json does not count as tested",
          _scope.cmd_check(str(prod)) == 1)
    (r1 / "results.json").write_text("{}")
    _scope.cmd_record(str(prod), str(r1))
    check("silent gap still blocks once it really did run", _scope.cmd_check(str(prod)) == 1)
    check("a waiver needs a reason", _scope.cmd_waive(str(prod), "sec-01.png", "   ") == 1)
    _scope.cmd_waive(str(prod), "sec-01.png", "gallery race skipped: nothing live to race against")
    check("waived with a reason releases the gate", _scope.cmd_check(str(prod)) == 0)

print("\n11. A quality FAIL is attached at the moment the scope is read")
with _tf.TemporaryDirectory() as root:
    prod = Path(root) / "prod"
    (prod / "images").mkdir(parents=True)
    (prod / "scorecards").mkdir(parents=True)
    (prod / "images" / "sec-03.png").write_bytes(b"x")
    (prod / "scorecards" / "scorecard-secondary-2026-07-29.md").write_text(
        "| sec-03.png | 4.1 | FAIL: text unreadable at thumbnail size, needs the regenerated version |")
    s = _scope.derive(prod)
    check("the FAIL is on the frame it is about", "sec-03.png" in s["quality_notes"],
          str(s["quality_notes"]))

print("\n12. Two races cannot silently claim the same coverage key")
with _tf.TemporaryDirectory() as root:
    prod = Path(root) / "prod"
    (prod / "images").mkdir(parents=True)
    (prod / "images" / "main-01.png").write_bytes(b"x")
    a, _ = _mk(root, "race-a")
    b, _ = _mk(root, "race-b")
    for d in (a, b):                       # no "race" key: both auto-detect to main
        (d / "config.json").write_text(_json.dumps({"round": 1, "images": [
            {"id": "x", "path": str(prod / "images" / "main-01.png")}]}))
        (d / "results.json").write_text("{}")
    check("the first records", _scope.cmd_record(str(prod), str(a)) == 0)
    check("the second REFUSES rather than overwriting", _scope.cmd_record(str(prod), str(b)) == 1)
    cov = _json.loads((prod / "tests" / "coverage.json").read_text())
    check("the first race survived",
          Path(cov["races"]["r1-main"]["out_dir"]).resolve() == a.resolve(),
          cov["races"]["r1-main"]["out_dir"])
    check("re-recording the SAME race is still idempotent",
          _scope.cmd_record(str(prod), str(a)) == 0)

print("\n13. A corrupt coverage file is refused, never silently reset")
with _tf.TemporaryDirectory() as root:
    prod = Path(root) / "prod"
    (prod / "tests").mkdir(parents=True)
    (prod / "tests" / "coverage.json").write_text("{not json")
    try:
        _scope._load_cov(str(prod))
        check("refuses a corrupt coverage file", False, "it loaded without complaint")
    except SystemExit:
        check("refuses a corrupt coverage file", True)
    (prod / "tests" / "coverage.json").write_text('{"races": {}}')
    cov = _scope._load_cov(str(prod))
    check("a partial coverage file does not KeyError", "waived" in cov)

print("\n14. The card reads the ENGINE's verdict, and casing does not break the handshake")
# panel.py records the tier in sentence case ("Clear lead"); the card displays it
# shouty ("CLEAR LEAD"). They are two dicts in two files, so a literal lookup
# between them silently misses, the card falls back to recomputing from bootstrap
# stability alone, and a verdict the engine DOWNGRADED for thin purchase-intent
# gets re-promoted on the one file the owner opens. /ready-to-upload gates
# shipping on that label, so the miss is worth a test.
import importlib.util as _ilu
_spec = _ilu.spec_from_file_location("_tcard", str(Path(__file__).parent / "tasting_card.py"))
_tcard = _ilu.module_from_spec(_spec)
_spec.loader.exec_module(_tcard)
from panel import TIER_LABEL as _ENGINE_LABEL  # noqa: E402

for _key, _label in _ENGINE_LABEL.items():
    check(f"engine's {_label!r} maps back to {_key!r}",
          _tcard.tier_key_from_label(_label) == _key,
          f"got {_tcard.tier_key_from_label(_label)!r}")
check("an unknown label maps to None, never to a tier",
      _tcard.tier_key_from_label("nonsense") is None
      and _tcard.tier_key_from_label(None) is None)

print("\n15. An unreadable vote is DROPPED, never mined out of the JSON key names")
# Both vote parsers used to salvage a letter by scanning the whole raw reply.
# The reply is JSON, so it opens {"choice": ... and the word CHOICE contains a
# C: every unparsed forced choice became a vote for shuffled position C in any
# race with 3+ candidates. The within-set parser scanned from up.find("BEST"),
# which starts ON the B of the key, so it always answered B.
# The second half is what made it dangerous: a salvaged letter is non-empty, so
# choice_parse_rate counted it as PARSED. The rate read 1.0, the sub-90%
# warning never printed, and the card's red banner never rendered. Wrong votes
# on the decision metric, under a gate reporting perfect health. A dropped vote
# is the correct outcome: it lowers the rate, which is what the gate is for.
import random as _rnd, tempfile as _tmp2, zlib as _z, struct as _st
from panel import choose as _choose, rank_within_set as _rank  # noqa: E402
import panel as _panel  # noqa: E402

def _png(path, w=8, h=8):
    """A real decodable PNG, so the image encoder is genuinely exercised."""
    raw = b"".join(b"\x00" + bytes([200, 200, 200] * w) for _ in range(h))
    def _ch(t, dd):
        c = t + dd
        return _st.pack(">I", len(dd)) + c + _st.pack(">I", _z.crc32(c) & 0xFFFFFFFF)
    path.write_bytes(b"\x89PNG\r\n\x1a\n"
                     + _ch(b"IHDR", _st.pack(">IIBBBBB", w, h, 8, 2, 0, 0, 0))
                     + _ch(b"IDAT", _z.compress(raw)) + _ch(b"IEND", b""))


_d = Path(_tmp2.mkdtemp())
for _i in range(5):
    _png(_d / f"i{_i}.png")
_P = {"id": 1, "age": 40, "gender": "F", "income": "mid income",
      "shopping_style": "careful shopper", "skepticism": "read reviews first",
      "attention": "skim quickly", "familiarity": "regular buyer"}
_CFG = {"product_context": "p"}


def _vote(reply, n):
    _panel.chat = lambda *a, **k: reply
    imgs = [{"id": f"img{i}", "label": f"L{i}", "path": str(_d / f"i{i}.png")} for i in range(n)]
    return _choose(_P, imgs, _CFG, _rnd.Random(1))[0]


def _best(reply, n):
    _panel.chat = lambda *a, **k: reply
    st = {"id": "s", "label": "S", "paths": [str(_d / f"i{i}.png") for i in range(n)]}
    return _rank(_P, st, _CFG, _rnd.Random(1))[0]


check("a reply with no readable choice is dropped, not turned into a vote",
      all(_vote('I think the second photo is strongest.', n) is None for n in (3, 4, 5)),
      [_vote('I think the second photo is strongest.', n) for n in (3, 4, 5)])
check("an out-of-range choice is dropped",
      all(_vote('{"choice":"none of them","why":"x"}', n) is None for n in (3, 4, 5)))
check("a truncated reply still yields the letter it actually named",
      all(_vote('{"choice":"B","why":"the second shows the scale of the fountain and the', n)
          is not None for n in (3, 4, 5)))
check("within-set: an unreadable best is dropped, not answered B",
      all(_best('I think the best is C and the worst is A.', n) is None for n in (3, 4, 5)),
      [_best('I think the best is C and the worst is A.', n) for n in (3, 4, 5)])
check("within-set: a truncated reply still yields the letter it named",
      all(_best('{"best":"C","worst":"A","note":"the third frame explains the size best but the', n)
          is not None for n in (3, 4, 5)))

print()
# --- magnitude sentence: sign and threshold must both be honoured -------------
# Regression, 23 August 2026. The old else-branch printed a hardcoded "+" and claimed
# the gap was "at or above" the bar whenever the CLEAR-tier downgrade had not
# fired. A real card printed "+-0.057 of 5, at or above the +0.25
# bar" on a run that failed the bar. Watched failing 4/5 on the old logic.
from panel import magnitude_sentence as _msent  # noqa: E402

def _sentence(gap, downgraded=False, decisive=False):
    return _msent({"intent_gap": gap, "tier_downgraded_for_magnitude": downgraded,
                   "intent_gap_decisive": decisive, "label": "Toss-up"}) or ""

_neg = _sentence(-0.057)
check("negative gap never prints as a plus", "+-0.057" not in _neg, _neg[-80:])
check("negative gap says the vote leader is behind", "behind on intent" in _neg, _neg[-80:])
_small = _sentence(0.057)
check("sub-threshold gap does not claim the bar", "at or above" not in _small, _small[-80:])
check("sub-threshold gap says under the bar", "under the" in _small, _small[-80:])
_big = _sentence(0.400, decisive=True)
check("decisive gap still claims the bar", "at or above" in _big, _big[-80:])


# --- one-candidate refusal names BOTH benchmarks (kit v37, 11 September 2026) --
# A pre-launch product has no live incumbent. The old message named the live
# incumbent as the only second entry, which read as "you cannot race" to a
# student whose product is not on Amazon yet. The refusal must name the
# strongest competitor's file as the other lawful benchmark.
from panel import preflight_config as _preflight  # noqa: E402

def _one_candidate_refusal():
    cfg = {"images": [{"id": "only", "path": __file__}], "out_dir": "x", "product_context": "y"}
    try:
        _preflight(cfg)
    except SystemExit as e:
        return str(e)
    return ""

_msg = _one_candidate_refusal()
check("one candidate is refused before any spend", "only 1 candidate" in _msg, _msg[:120])
check("the refusal names the incumbent as one lawful benchmark", "plus the incumbent" in _msg, _msg[:200])
check("and the strongest competitor's file as the other (pre-launch)",
      "strongest competitor" in _msg and "nothing is live yet" in _msg, _msg[:300])


if FAILURES:
    print(f"{len(FAILURES)} FAILED: {', '.join(FAILURES)}")
    sys.exit(1)
print("all green")

#!/usr/bin/env python3
"""Which files a Tasting Round actually races.

The Fixing Room writes each round as a complete set snapshot into `edits/vN/`
and surgical edits KEEP the filename, so the same name exists in `images/` and
in every round. Before this was fixed, `scope.derive()` returned bare names,
every caller joined them to `images/`, and a round run after a fix round raced
the SUPERSEDED files while the pack shipped the fixed ones.

Nothing caught it in review, and no name-based guard ever could: the two sets
have identical filenames by design, so comparing names compares equal. That is
why this test compares FILE CONTENT.

Run: python3 test_scope.py
"""
import sys
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

FAILURES = []


def check(name, cond, detail=""):
    print(("  PASS  " if cond else "  FAIL  ") + name + ("  " + str(detail) if not cond and detail else ""))
    if not cond:
        FAILURES.append(name)


def build(rounds_spec):
    """A product folder whose every file carries its own origin as content."""
    tmp = (Path(tempfile.mkdtemp()) / "fondue").resolve()
    (tmp / "images").mkdir(parents=True)
    (tmp / "incumbent").mkdir(parents=True)
    for n in ("main-01.png", "sec-01.png", "sec-02.png"):
        (tmp / "images" / n).write_bytes(b"OLD")
    (tmp / "incumbent" / "main-live.png").write_bytes(b"x")
    for rnd, names in rounds_spec.items():
        d = tmp / "edits" / rnd
        d.mkdir(parents=True)
        for n in names:
            (d / n).write_bytes(rnd.encode())
    return tmp


def run():
    import scope

    def origin(s, name):
        return Path(s["paths"][name]).read_bytes().decode()

    t = build({"v1": ["main-01.png", "sec-01.png", "sec-02.png"]})
    s = scope.derive(t)
    check("after a fix round, the race reads edits/v1 and not images",
          origin(s, "main-01.png") == "v1", origin(s, "main-01.png"))

    t = build({"v2": ["main-01.png"], "v10": ["main-01.png"]})
    check("v10 beats v2, so rounds are ordered numerically and not as strings",
          origin(scope.derive(t), "main-01.png") == "v10",
          origin(scope.derive(t), "main-01.png"))

    t = build({"v1": ["sec-01.png"]})
    s = scope.derive(t)
    got = (origin(s, "main-01.png"), origin(s, "sec-01.png"), origin(s, "sec-02.png"))
    check("a round that touched one frame moves ONLY that frame",
          got == ("OLD", "v1", "OLD"), got)

    t = build({})
    check("a product with no edits/ still resolves to images/",
          origin(scope.derive(t), "main-01.png") == "OLD")

    t = build({"v1": ["main-01.png"]})
    s = scope.derive(t)
    check("every raced name carries a resolved path",
          set(s["paths"]) == set(s["main"]) | set(s["gallery"]), sorted(s["paths"]))

    print()
    # --- a main is whatever is not the gallery ------------------------------
    # Draft Blast winners arrive carrying the short pick id they won under
    # (m26, m51). Filtering FOR names starting with "main" dropped the entire
    # main race and printed "MAIN RACE owes nothing" over four gate-passed
    # candidates. Measured 27 August 2026 on the live student run.
    import tempfile as _tf
    from pathlib import Path as _P
    t2 = (_P(_tf.mkdtemp()) / "brushes").resolve()
    (t2 / "images").mkdir(parents=True)
    (t2 / "incumbent").mkdir(parents=True)
    for n in ("m26.png", "m51.png", "sec-01.png", "sec-02.png"):
        (t2 / "images" / n).write_bytes(b"x")
    (t2 / "incumbent" / "main-live.png").write_bytes(b"x")
    sc2 = scope.derive(t2)
    check("pick-id mains are raced, not dropped",
          sorted(sc2["main"]) == ["m26.png", "m51.png"], sc2["main"])
    check("and the gallery is still exactly the sec files",
          sorted(sc2["gallery"]) == ["sec-01.png", "sec-02.png"], sc2["gallery"])

    # Mains still sitting in the pick folder are found rather than reported absent.
    t3 = (_P(_tf.mkdtemp()) / "brushes2").resolve()
    (t3 / "images" / "pick" / "shortlist").mkdir(parents=True)
    (t3 / "incumbent").mkdir(parents=True)
    (t3 / "images" / "sec-01.png").write_bytes(b"x")
    (t3 / "images" / "pick" / "shortlist" / "m37.png").write_bytes(b"x")
    (t3 / "incumbent" / "main-live.png").write_bytes(b"x")
    sc3 = scope.derive(t3)
    check("a main left in the pick folder is still raced",
          sc3["main"] == ["m37.png"], sc3["main"])

    # --- the Day 5 close decides the main race (kit v23) ---------------------
    # status.md's `Main pick:` row names the primary and the alternatives. Every
    # other promoted main was passed over by the owner and is not owed a race.
    # The on-request 2048 upscale and a v22 -faces-fixed file are versions of a
    # candidate, never candidates. Reproduced 7 September 2026: six "owed" files
    # for a two-file pick.
    t4 = (_P(_tf.mkdtemp()) / "fondue4").resolve()
    (t4 / "images").mkdir(parents=True)
    (t4 / "incumbent").mkdir(parents=True)
    for n in ("main-03.png", "main-06.png", "main-06-faces-fixed.png", "main-13.png",
              "main-13-2048.png", "main-130.png", "sec-01.png"):
        (t4 / "images" / n).write_bytes(b"x")
    (t4 / "incumbent" / "main-live.png").write_bytes(b"x")
    (t4 / "status.md").write_text(
        "- Main pick: main-13 (primary); alternatives: main-06; backup: vanilla-control.png\n")
    sc4 = scope.derive(t4)
    check("the main race is the Main pick row, primary first",
          sc4["main"] == ["main-13.png", "main-06-faces-fixed.png"], sc4["main"])
    check("a -2048 upscale is never a candidate",
          "main-13-2048.png" not in sc4["main"] and "main-13-2048.png" not in sc4["superseded"], sc4)
    check("the row's source is reported", "Main pick" in sc4["main_source"], sc4["main_source"])
    (t4 / "status.md").write_text("- Main pick: [main-NN (primary); alternatives: main-NN]\n")
    sc4b = scope.derive(t4)
    check("a template placeholder row falls back to everything on disk",
          sorted(sc4b["main"]) == ["main-03.png", "main-06-faces-fixed.png", "main-13.png", "main-130.png"],
          sc4b["main"])
    (t4 / "status.md").write_text("- Main pick: main-99 (primary)\n")
    sc4c = scope.derive(t4)
    check("a pick that is not on disk is NAMED, and the race falls back",
          sc4c["pick_missing"] == ["main-99"] and len(sc4c["main"]) == 4, sc4c)

    # --- an empty incumbent/ names BOTH ways to fill it (kit v37) -------------
    # "MISSING: a main race without the live image proves nothing" told a
    # pre-launch product it could never race. The plan must say: live product,
    # fill incumbent/ (step 0b); pre-launch, copy the strongest competitor's
    # main in as competitor-main.png (step 4b).
    import contextlib as _cl
    import io as _io
    t5 = (_P(_tf.mkdtemp()) / "prelaunch").resolve()
    (t5 / "images").mkdir(parents=True)
    (t5 / "incumbent").mkdir(parents=True)
    (t5 / "images" / "main-01.png").write_bytes(b"x")
    buf = _io.StringIO()
    with _cl.redirect_stdout(buf):
        scope.cmd_plan(str(t5))
    out = buf.getvalue()
    check("an empty incumbent/ is reported MISSING", "MISSING: no live image on file" in out, out[-400:])
    check("and the live route is named (step 0b)", "fill incumbent/ (step 0b)" in out, out[-400:])
    check("and the pre-launch route is named (competitor-main.png, step 4b)",
          "competitor-main.png" in out and "step 4b" in out, out[-400:])

    if FAILURES:
        print(f"FAILED ({len(FAILURES)}): " + ", ".join(FAILURES))
        return 1
    print("SCOPE: all green")
    return 0


if __name__ == "__main__":
    sys.exit(run())

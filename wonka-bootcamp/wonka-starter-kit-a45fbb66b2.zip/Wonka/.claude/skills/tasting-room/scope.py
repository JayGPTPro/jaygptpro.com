#!/usr/bin/env python3
"""What this sitting OWES, what it actually tested, and a gate on the gap.

The failure this exists to prevent: eight frames approved, the panel run on
one, seven never tested including one already flagged as a quality failure,
and no surface mentioning it. The scope lived in prose ("the approved
candidates"), bound to no field and checked by nothing. Two records that must
agree, with no code comparing them, drift; and the drift is invisible.

So scope is derived from disk rather than asserted:

  images/main-*   the main-race candidates the owner picked
  images/sec-*    the gallery frames
  incumbent/      the live image and gallery to beat

Three commands:

  plan   <product_dir>              what each race owes, before you author a config
  record <product_dir> <race_dir>   fold one finished race into the coverage
  check  <product_dir>              the gate: refuse to close on a silent gap

Coverage ACCUMULATES across the races of a sitting. A sitting is two races
(main and gallery) that finish minutes apart, and each one writing its own
record would erase the other's; then no pair of races could ever satisfy the
gate. Keyed on (round, race) so a second round registers its own row instead
of overwriting the first.

Stdlib only, cross-platform. No network.
"""
import json
import re
import sys
import time
from pathlib import Path

IMG_EXT = {".png", ".jpg", ".jpeg", ".webp"}
COVERAGE = "coverage.json"

# Working documents that live in images/ but are never candidates, so the gate
# must not demand a race for them: the diagnostic vanilla control (tactics off,
# never ships), pick contact sheets, and pool sheets. Anything else a run wants
# excluded is still an explicit `waive` with a reason; this list is only for
# files the FACTORY ITSELF puts there as non-candidates by construction.
_NON_CANDIDATE = re.compile(
    r"^(vanilla-control([-_].*)?|.*[-_](shortlist|picksheet|pick-sheet|contact-sheet)s?([-_].*)?"
    r"|.*-(1024|1536|2048|3072|4096))$",
    re.I,
)
# The trailing size forms (`main-13-2048.png`) are the on-request Day 5 upscales that
# /main-image saves BESIDE the original. They are a finish of a candidate, not a
# candidate: racing them alongside the 1024 original raced the same image twice and
# then blocked the gate on the copy (reproduced 7 September 2026).


# A regeneration or an edit lands BESIDE the file it replaces, and the original
# is kept on purpose (house rule: never delete the source). So images/ holds
# main-02.png next to main-02-v2.png, and main-04.png next to main-04_fix1.png.
# Only the newest of each family is owed a test. Without this the gate blocks
# on every superseded original, which is a gate crying wolf on a correct run.
_VERSION_SUFFIX = re.compile(
    r"^(?P<base>.+?)[-_](?:v(?P<v>\d+)|fix(?P<f>\d+)|faces-fixed(?:-v(?P<fv>\d+))?)$", re.I)


def _family(stem):
    """('main-02', 2) for main-02-v2; ('main-01', 0) for an unversioned original.
    A kit v22 Face Clinic output (`main-06-faces-fixed.png`) is a version of
    main-06 too, never a second candidate."""
    m = _VERSION_SUFFIX.match(stem)
    if not m:
        return stem, 0
    if m.group("fv") is not None or stem.lower().endswith("faces-fixed"):
        return m.group("base"), int(m.group("fv") or 1)
    n = m.group("v") or m.group("f")
    return m.group("base"), int(n)


_PICK_NAME = re.compile(r"\b(main-\d+|m\d+)\b", re.I)


def main_pick(product_dir):
    """The names on status.md's `Main pick:` row, primary first, backup excluded.

    `/inspect` writes `Main pick: main-13 (primary); alternatives: main-03, main-06;
    backup: vanilla-control.png` at the Day 5 close. That row IS the main race:
    the owner already passed over every other promoted main, and Day 8 never
    pays for a verdict on a candidate the owner did not pick. Returns [] when the
    row is missing or still the template placeholder, and the caller falls back
    to everything on disk."""
    f = Path(product_dir) / "status.md"
    if not f.is_file():
        return []
    for line in f.read_text(errors="ignore").splitlines():
        if "main pick:" not in line.lower():
            continue
        body = line.split(":", 1)[1]
        body = re.split(r"backup\s*:", body, flags=re.I)[0]
        names = [n.lower() for n in _PICK_NAME.findall(body)]
        seen, out = set(), []
        for n in names:
            if n not in seen:
                seen.add(n); out.append(n)
        return out
    return []


def _imgs(d, latest_only=False):
    if not d.is_dir():
        return []
    files = sorted(
        p for p in d.iterdir()
        if p.suffix.lower() in IMG_EXT
        and not p.name.startswith(".")
        and not _NON_CANDIDATE.match(p.stem)
    )
    if not latest_only:
        return files
    best = {}
    for p in files:
        base, n = _family(p.stem)
        if base not in best or n > best[base][0]:
            best[base] = (n, p)
    return sorted((p for _, p in best.values()), key=lambda p: p.name)


def superseded(d):
    """The originals a newer version replaced, so they can be NAMED rather than
    silently dropped. A gate that quietly stops asking about a file is the same
    failure as one that never asked."""
    live = {p.name for p in _imgs(d, latest_only=True)}
    return [p.name for p in _imgs(d) if p.name not in live]


def rounds(product_dir):
    """Every `edits/vN/` round, HIGHEST first. Sorted numerically, because a
    string sort puts v10 before v2 and would race a stale set the moment a
    product reaches ten rounds."""
    e = Path(product_dir) / "edits"
    if not e.is_dir():
        return []
    out = []
    for d in e.iterdir():
        if d.is_dir() and re.fullmatch(r"v(\d+)", d.name):
            out.append((int(d.name[1:]), d))
    return [d for _, d in sorted(out, reverse=True)]


def current_path(product_dir, name):
    """WHERE the current version of `name` actually lives.

    The Fixing Room writes each round as a complete set snapshot into
    `edits/vN/`, and surgical edits KEEP the filename, so the same name exists
    in `images/` and in every round. The newest copy wins, and it is resolved
    per FILE rather than per folder because a round may have touched only some
    of the set.

    This is the same resolution `/inspect` and `/ready-to-upload` already do.
    Until 26 August 2026 this module did not do it at all: it returned bare names,
    every caller joined them to `images/`, and a Tasting Round after a fix
    round therefore raced the SUPERSEDED files while the pack shipped the
    fixed ones. Nothing caught it, because the two sets have identical
    filenames by design, so a name-based guard compares equal."""
    p = Path(product_dir)
    for r in rounds(p):
        c = r / name
        if c.is_file():
            return c
    return p / "images" / name


def derive(product_dir):
    """The approved scope, read off the disk that holds it."""
    p = Path(product_dir).resolve()
    images = _imgs(p / "images", latest_only=True)
    # Classify by what the GALLERY is called, never by what a main is called.
    # `sec-NN` is the firm half of the naming contract; a main may arrive as
    # main-NN.png, or carrying the short pick id it won under (m26, m51) when
    # the owner chose it out of the pick folder. Filtering FOR "main" silently
    # dropped every Draft Blast winner and printed "MAIN RACE owes nothing"
    # over four gate-passed candidates (measured 27 August 2026).
    gallery = [f for f in images if f.name.lower().startswith("sec")]
    main = [f for f in images if f not in gallery]
    picks = main_pick(p)
    main_source = "images/ (no Main pick row in status.md)"
    pick_missing = []
    if picks:
        def _base(f):
            return _family(f.stem)[0].lower()
        pool = list(main)
        for sub in ("pick/shortlist", "pick"):
            pool += [f for f in _imgs(p / "images" / sub, latest_only=True)
                     if not f.name.lower().startswith("sec")]
        chosen = []
        for name in picks:
            hit = [f for f in pool if _base(f) == name]
            if hit:
                if hit[0] not in chosen:
                    chosen.append(hit[0])
            else:
                pick_missing.append(name)
        if chosen:
            main = chosen
            main_source = "status.md Main pick row (primary + alternatives)"
    if not main:
        # Mains promoted from the pick folder may still be sitting there.
        for sub in ("pick/shortlist", "pick"):
            found = _imgs(p / "images" / sub, latest_only=True)
            found = [f for f in found if not f.name.lower().startswith("sec")]
            if found:
                main = found
                break
    inc = _imgs(p / "incumbent")
    inc_main = [f for f in inc if "main" in f.name.lower()]
    inc_gallery = [f for f in inc if f not in inc_main]
    return {
        "product_dir": str(p),
        "main": [f.name for f in main],
        "gallery": [f.name for f in gallery],
        "incumbent_main": [f.name for f in inc_main],
        "incumbent_gallery": [f.name for f in inc_gallery],
        "main_source": main_source,
        "pick_missing": pick_missing,
        "superseded": superseded(p / "images"),
        "quality_notes": scorecard_notes(p),
        # The RESOLVED path for every name above. Callers must build the
        # tasting config from this, never by joining a name to images/.
        "paths": {f.name: str(current_path(p, f.name)) for f in main + gallery},
    }


def scorecard_notes(p):
    """Any FAIL a scorecard already recorded, attached to the filename it is about.

    Printed at the moment the scope is READ, which is the moment it is cheap.
    A frame that has already failed inspection should not reach the panel and
    find out afterwards that a round was spent on it.
    """
    notes = {}
    sc = p / "scorecards"
    if not sc.is_dir():
        return notes
    for f in sorted(sc.glob("*.md")):
        try:
            text = f.read_text(errors="ignore")
        except Exception:
            continue
        for line in text.splitlines():
            low = line.lower()
            if not re.search(r"\bfail(?:ed|s|ure)?\b", low) or re.search(r"no fail|0 fail|zero fail", low):
                continue
            for name in [x.name for x in _imgs(p / "images")]:
                # Match the FULL filename, or the stem followed by a boundary.
                # A bare stem match let a line about sec-10.png attach itself to
                # sec-1.png.
                stem = Path(name).stem.lower()
                if name.lower() in low or re.search(rf"\b{re.escape(stem)}\b", low):
                    notes.setdefault(name, line.strip()[:160])
    return notes


def cmd_plan(product_dir):
    s = derive(product_dir)
    n = s["quality_notes"]

    def block(title, items, extra=""):
        print(f"\n{title}  ({len(items)})")
        if not items:
            print("   nothing on disk")
            if extra:
                print(f"   {extra}")
            return
        for i in items:
            flag = f"   <-- {n[i]}" if i in n else ""
            print(f"   {i}{flag}")
        if extra:
            print(f"   {extra}")

    src = {Path(v).parent.name for v in s.get("paths", {}).values()}
    print(f"SCOPE for {Path(s['product_dir']).name}")
    print(f"  current set reads from: {', '.join(sorted(src)) or 'images'}"
          "   (a fix round moves this; the race must follow it)")
    # No hint on an empty main race: the live path prints exactly what it did
    # before v37. The extra-on-empty print exists for the benchmark MISSING hint.
    block("MAIN RACE owes", s["main"], f"from: {s['main_source']}" if s["main"] else "")
    if s.get("pick_missing"):
        print("   NAMED IN THE PICK ROW BUT NOT ON DISK: " + ", ".join(s["pick_missing"])
              + "  (check images/ and images/pick/; a pick that cannot be found cannot race)")
    block("  benchmark", s["incumbent_main"],
          ("MISSING: no live image on file. Live product: fill incumbent/ (step 0b). "
           "Pre-launch: copy the strongest competitor's main into incumbent/ as "
           "competitor-main.png (step 4b).") if not s["incumbent_main"] else "")
    block("GALLERY RACE owes", s["gallery"])
    block("  benchmark", s["incumbent_gallery"])
    if s["superseded"]:
        print(f"\nSuperseded, NOT owed a test ({len(s['superseded'])}): " + ", ".join(s["superseded"]))
        print("   a newer -v2 or _fixN sits beside each. The newest of each family is what is owed.")
    if n:
        print("\nQUALITY FLAGS already on record. Do not spend a race on a known failure:")
        for k, v in n.items():
            print(f"   {k}: {v}")
    print("\nRaces this sitting owes: "
          + ", ".join(x for x in (["main"] if s["main"] else []) + (["gallery"] if s["gallery"] else []))
          + ".  A race you skip on purpose is fine; record it with `waive`.")


def _cov_path(product_dir):
    return Path(product_dir).resolve() / "tests" / COVERAGE


def _load_cov(product_dir):
    f = _cov_path(product_dir)
    if f.exists():
        try:
            cov = json.loads(f.read_text())
            cov.setdefault("races", {})
            cov.setdefault("waived", {})
            return cov
        except Exception:
            # NEVER silently reset: the next save would destroy accumulated
            # coverage with nobody told. Refuse instead.
            raise SystemExit(f"{f} is not readable JSON. Fix or delete it; do not let a run overwrite it.")
    return {"races": {}, "waived": {}}


def _save_cov(product_dir, cov):
    f = _cov_path(product_dir)
    f.parent.mkdir(parents=True, exist_ok=True)
    f.write_text(json.dumps(cov, indent=1))
    return f


def cmd_record(product_dir, race_dir):
    """Fold ONE finished race into the coverage. Never replaces the other race."""
    rd = Path(race_dir).resolve()
    cfg_f, res_f = rd / "config.json", rd / "results.json"
    if not cfg_f.exists():
        print(f"no config.json in {rd}")
        return 1
    cfg = json.loads(cfg_f.read_text())
    tested = []
    for img in cfg.get("images", []):
        for path in (img.get("paths") or ([img["path"]] if img.get("path") else [])):
            tested.append(Path(path).name)

    rnd = cfg.get("round", 1)
    race = cfg.get("race") or ("gallery" if any(len(i.get("paths") or []) > 1 for i in cfg.get("images", []))
                               else "main")
    key = f"r{rnd}-{race}"                      # (round, race), never round alone

    cov = _load_cov(product_dir)                # LOAD then merge: accumulate, never reset
    prev = cov.get("races", {}).get(key)
    if prev and str(Path(prev.get("out_dir", ""))) != str(rd):
        # A re-run of the SAME race replaces its own row, which is what makes
        # this idempotent. A DIFFERENT folder claiming the same key is two races
        # that auto-detected to the same name, and silently overwriting one is
        # the bug this whole file exists to prevent.
        print(f"REFUSING: {key} is already recorded from {prev['out_dir']}.")
        print("Two races cannot share a key. Put an explicit \"race\" in each config")
        print('   (for example "race": "main" and "race": "gallery") and record again.')
        return 1
    cov["races"][key] = {
        "round": rnd, "race": race, "tested": sorted(set(tested)),
        "out_dir": str(rd), "completed": res_f.exists(),
        "at": time.strftime("%Y-%m-%d %H:%M"),
    }
    f = _save_cov(product_dir, cov)
    print(f"recorded {key}: {len(set(tested))} images. coverage now holds {', '.join(sorted(cov['races']))} -> {f}")
    return 0


def cmd_waive(product_dir, name, reason):
    if not reason.strip():
        print("a waiver needs a reason. That is the whole point of it.")
        return 1
    cov = _load_cov(product_dir)
    cov.setdefault("waived", {})[name] = reason.strip()
    _save_cov(product_dir, cov)
    print(f"waived {name}: {reason.strip()}")
    return 0


def cmd_check(product_dir):
    """The gate. A deliberate skip stays possible; a silent one does not."""
    s = derive(product_dir)
    cov = _load_cov(product_dir)
    tested = set()
    incomplete = []
    for k, r in cov.get("races", {}).items():
        if not r.get("completed"):
            # A run that crashed after writing its config used to satisfy the
            # gate. Coverage means TESTED, and a race with no results.json
            # tested nothing.
            incomplete.append(k)
            continue
        tested |= set(r.get("tested", []))       # UNION across completed races
    owed = set(s["main"]) | set(s["gallery"])
    waived = set(cov.get("waived", {}))
    gap = sorted(owed - tested - waived)

    print(f"races recorded: {', '.join(sorted(cov.get('races', {}))) or 'none'}")
    if incomplete:
        print(f"NOT counted, no results.json: {', '.join(sorted(incomplete))}")
    print(f"approved on disk: {len(owed)} | tested: {len(owed & tested)} | waived: {len(owed & waived)}")
    for name in sorted(owed & waived):
        print(f"   waived  {name}: {cov['waived'][name]}")
    if gap:
        print("\nGATE: BLOCKED. Approved but neither tested nor waived:")
        for name in gap:
            note = s["quality_notes"].get(name)
            print(f"   {name}" + (f"   <-- {note}" if note else ""))
        print("\nTest them, or waive each with a reason:")
        print(f'   python3 scope.py waive "{product_dir}" "{gap[0]}" "why it is not being tested"')
        print("\nDeciding on a partial round is the wrong question to put to the owner.")
        return 1
    print("\nGATE: PASS. Everything approved was tested or waived with a reason.")
    return 0


def main():
    if len(sys.argv) < 3:
        print(__doc__)
        return 1
    cmd, pdir = sys.argv[1], sys.argv[2]
    if cmd == "plan":
        cmd_plan(pdir); return 0
    if cmd == "record":
        if len(sys.argv) < 4:
            print('usage: scope.py record "<product_dir>" "<race_out_dir>"')
            return 1
        return cmd_record(pdir, sys.argv[3])
    if cmd == "waive":
        if len(sys.argv) < 5:
            print('usage: scope.py waive "<product_dir>" "<filename>" "<reason>"')
            return 1
        return cmd_waive(pdir, sys.argv[3], " ".join(sys.argv[4:]))
    if cmd == "check":
        return cmd_check(pdir)
    print(f"unknown command: {cmd}")
    return 1


if __name__ == "__main__":
    sys.exit(main())

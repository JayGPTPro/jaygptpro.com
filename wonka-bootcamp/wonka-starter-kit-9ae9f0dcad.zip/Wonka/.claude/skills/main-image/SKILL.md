---
name: main-image
description: Run the MAIN image generation for the hero slot as a DUAL BLAST. The main image is briefed in the creative brief but CHOSEN here. The three main-image controls (tactic, hang-tag text, packaging preference) are decided in the brief and confirmed with the owner, then TWO machines bake candidates side by side. Genrupt runs its Draft Blast, and the OpenAI Blast authors its own wide pool from the same owner answers, on a conservativeness ladder, with competitor inspiration. The human picks ONE shortlist from the union. Slot 1 is protected and round-trips unchanged in every plan save. Either machine down, the day still runs on the other. No faces ever; hands only under an owner-enabled human-contact tactic; no overlay text; cost reported rather than gated. Also produces the Round 2 challenger and any regeneration a scorecard or a tasting note orders. Use when the brief, the locked reference, and the brand kit are done and the user wants the hero image. Triggers: /main-image, "make the main image", "hero image", "generate the mains", "main image room", "openai blast", "round 2 challenger", "regenerate main-02".
---

# The Main Image Room

| Meta | Value |
|------|-------|
| Room | The Main Image Room |
| Station | INVENT (the main image is one of the four Invent sub-parts) |
| Taught | Day 5. Reused on Day 8 for any regeneration the tasting notes order |
| Needs | brief/creative-brief.md (the MAIN section with the three main-image decisions answered and the selection criteria), 2-reference/reference-sheet.md (LOCKED, smoke test PASS), factory/Brand/brand-kit.md (branding preset + styleImage, built by /brand-kit), at least one working generation machine (both = the normal dual blast) |
| Saves to | factory/Products/[product]/images/ (main-01.png .. main-NN.png; the OpenAI pool under images/openai-blast/[date]/) + images/batch-log.md |
| Typical cost | Genrupt: a few credits per candidate, read off the live balance. OpenAI Blast: quality low, a few dollars for the whole pool on the owner's key. **Reported, not gated:** the brief approval authorises the run. A Draft Blast (100 credits list price; quote the live cost preview) is the one exception that gets named before it runs. |

## The contract this room lives under

**The main image is briefed in the brief, but chosen here.** `/creative-brief` writes a real main-image brief: what the shot must show and prove. That brief is the standard the human picks against in step 8 and the prompt source for the OpenAI Blast, and it is never sent to Genrupt.

**Two machines bake heroes side by side, from ONE set of owner answers.** Path A is Genrupt's Draft Blast (about a hundred drafts on the saved plan). Path B is the OpenAI Blast (step 6): this room authors its own wide pool on the owner's key, on a conservativeness ladder derived from the SAME tactic answers, so the owner answers the three controls once and both machines obey them. The dual blast is the default whenever both machines are alive: it is nearly free, it is a real backup (either machine down, the day still runs), and the pick is human anyway, so a bigger pool only helps. The human picks ONE shortlist from the union of both pools.

On the Genrupt path our side owns a small set of structured controls, and nothing else touches slot 1:

1. **Which tactics are enabled.** `enabledMainImageTactics` is an ARRAY, not a single choice, and there are FOUR values: `hang_tag` (a physical tag attached to the product), `human_contact` (avatar interaction, a person's hands or presence), `packaging_expansion` (the real retail box in frame), and `genrupt_choice` (the planner decides). **Enabling several is the normal case**, because a hundred drafts spread across four strategies is worth far more than a hundred drafts of one. A fresh plan arrives with all four enabled.
   **A warning that goes with `human_contact`, said to the owner when they enable it:** on the Genrupt path this tactic has produced full smiling FACES on main-image drafts (verified on a real blast), and a face on a main fails the law check every time, so some or all of that tactic's share of the blast may arrive pre-disqualified. That is wasted spread, not a compliance risk, because the law screen pulls them before the pick. The owner's real choices: keep it and accept the waste (the tactic sometimes yields lawful hands-only frames too), or drop it from Path A and let the OpenAI Blast's tier 3 carry the hands-only idea, where this room's own prompts enforce hands-without-faces correctly. Reported to Genrupt as a hands-only mode request; until then, this is the trade.
2. **The vanilla control is NOT a fifth value in that array** (confirmed by Genrupt, 27 July 2026). Vanilla means every tactic off, requested as `enabledMainImageTactics: []`, so it cannot ride along inside a run that has any tactic enabled. **It is a SECOND, separate job**, small and cheap, run right after the blast, and tactics are a PLANNING control rather than a blast parameter, so step 5 looks up how to ask for it rather than assuming a field. It is the compliant swap-in the whole risk doctrine depends on, so never let it be skipped for convenience and never accept a plan that promises it "inside the same run". The one lawful way to finish without it is to find that no capability on this connection can produce it, say so plainly, and record `vanilla control: not available on this connection` in the batch log. Silence is not that.
3. **Mix and match.** Whether one image may COMBINE two tactics. Turning it off does **not** collapse the run onto one tactic: images still distribute across every enabled tactic either way. It only stops two tactics appearing in a single image.
4. **Hang-tag text.** The exact words on the tag, **28 characters maximum**. Leave it empty and Genrupt writes one from the buyer signal, which is a legitimate choice but a silent one. **If the brief decided a hang-tag phrase, that phrase goes in this field**; a brief that specified the words and a run that auto-generated them is a quiet, expensive disconnect.
5. **Use actual packaging.** `alwaysIncludePackaging`. **Turn it ON whenever the product has real packaging photos in the bucket.** With it off, a packaging tactic has to invent a box, and an invented box on a hero image is a returns problem wearing a design problem's clothes.

These are decided in the creative brief and CONFIRMED with the owner before generation. **Never enable a tactic the owner has not answered for, and never silently drop one they wanted.** An unanswered control is a stop, not a default.

**Removing a tactic is a first-class answer.** "My product has nothing to do with packaging" or "no people anywhere near my hero" are common and correct, and the fix is to drop that value from the array rather than to generate images nobody wants. Say which tactics are in and which are out, and why, before anything runs.

**Slot 1 is protected.** In every `save_listing_builder_plan_review`, slot 1 round-trips byte-for-byte unchanged: no contentBrief, no headerPhrases, no customInstructions, no slot referenceImages, ever. The hero is shaped only by the three controls, the locked reference, and the branding preset. Rules pasted as prose into the slot stop behaving like rules and start competing with Genrupt's own direction, and the big prohibitions are enforced system-side anyway.

The machines generate MANY main candidates from those controls. This room's job is to run both generations, collect the candidates, and then support the HUMAN choice against the selection criteria the brief wrote down. The human picks. This room never does.

## What this room does

The Main Image Room produces the single most important asset on the listing: the hero shot the shopper sees in search results, at the size of a postage stamp, in a row of competitors, for well under a second. It confirms the three main-image decisions from the brief with the owner, runs the dual blast (Genrupt's Draft Blast and the OpenAI Blast), collects every candidate that comes off either machine, and lays them out beside the brief's selection criteria so the human can choose with clear eyes. Scope of THIS room is the MAIN image only. Secondary images, A+ modules, and variation imagery are generated in their own rooms (`/secondary-images`, `/aplus`, `/variations`). Nothing that comes out of this room is a winner; the shortlist the human picks goes to the Inspection Room next.

## What this room never does

- Never writes a brief, header phrase, custom instruction, or slot reference onto slot 1. The main is edited only through tactic, hang-tag text, and packaging preference.
- Never picks a tactic, hang-tag text, or packaging preference the owner has not answered for. Silence is not a default.
- Never picks the winner, scores, or ranks. The human picks; `/inspect` gates.
- Never edits an existing image. Removals, word swaps, and shortenings are `/fix`.
- Never invents a product fact. Every attribute comes from the Reference Sheet and the brief.
- Reports every spend in one line before and after, and never uses cost as a gate on work the approved brief already authorised. The exception: a Draft Blast is a whole blast on ONE slot (100 credits list, and it has billed 29 in practice), so that one gets named out loud first, quoting the live preview.
- Never presents output as final, approved, ready, or "the best one".
- Never drops a candidate silently. Every candidate is ACCOUNTED FOR: the OpenAI pool and the selected Genrupt candidates on disk, the unselected Genrupt drafts alive in the app with their spread logged, every pull and failure named in the batch log.

## Before you start

Check ALL FOUR preconditions. Open the files; do not take `status.md`'s word for them. Any miss = station **BLOCKED**, with the exact ask and a pointer.

1. `brief/creative-brief.md` exists and its MAIN section carries the three main-image decisions (tactic, hang-tag text, packaging preference) and the selection criteria the human choice will be judged against. Missing section: point to `/creative-brief`. Section present but a decision unanswered: the room does not guess, see the table below.
2. `2-reference/reference-sheet.md` exists and reads `Reference status: LOCKED` and `Smoke test: PASS`. An approved reference WITHOUT a passed smoke test does not count; the smoke test is the only proof the lock actually holds. Missing or unpassed: point to `/reference-sheet`.
3. `factory/Brand/brand-kit.md` exists, with the branding preset id and the styleImage that `/brand-kit` built. Style comes ONLY from there; this room never describes style, colors, or fonts in prose. Missing: point to `/brand-kit`.
4. At least one generation machine is alive: Genrupt MCP connected (Path A) and/or an OpenAI key (Path B, the OpenAI Blast). Both alive is the normal case and runs the dual blast; one alive runs alone, announced as such. Never switch or drop a path silently, and never assume a machine is alive because it was alive on the last run.

**"I don't have it" is a real answer, and most of the time the run proceeds.** What blocks is missing EVIDENCE and missing DECISIONS, never missing convenience.

| The owner says | What happens |
|---|---|
| "No Genrupt" | The OpenAI Blast runs alone, with the weaker-fidelity warning said out loud, one probe image generated and viewed before the pool. The run proceeds. |
| "No OpenAI key" (or org verification missing) | The Genrupt Draft Blast runs alone. Say plainly which half is missing and what it would have added, point to `guides/mcp-setup-guide.md`, and proceed. |
| "No Genrupt and no OpenAI key" | Both machines down: the room is CLOSED. Say exactly what is missing, point to `guides/mcp-setup-guide.md`, record `blocked: no generation machine` in `status.md`, and stop. Never fake, never "describe" images instead. |
| The brief has no answered tactics | STOP. Present the five in the owner's language: a hang tag on the product, a person interacting with it, the real retail box in frame, let the planner decide, or a plain control shot. Ask which are IN and which are OUT, and why. Never pick, never default, never infer from enthusiasm. Record the answer back into the brief. |
| "No hang tag" / "no packaging" / "no people near my hero" | All fine, and all common. Drop that value from the enabled tactics array, record WHY in one line, and proceed. A dropped tactic is a decision; a forgotten one is a defect. |
| "Just pick one image for me" | Refused, gently. Ask for one to five. The Tasting Room needs candidates to race, and the A/B doctrine wants challengers queued rather than a single favourite that never gets tested. |
| "I can't afford the full batch" | Run the smallest batch the tactic supports and name the trim in the batch log as a conscious cut. A named cut is fine; a silent one is not. |
| "Skip the smoke test, just go" | Refused. The lock and its smoke test are evidence, not paperwork, and skipping them is what turns one wrong reference into a whole wrong batch. Back to `/reference-sheet`. |
| No answer on the cost line | Nothing runs. Park the station as `in progress`, say what is waiting, and stop. |

## Process

1. **Read the MAIN section and confirm every control, out loud, one line each.** From the brief: which tactics are enabled and which were deliberately dropped, mix and match on or off, the hang-tag text (or "auto"), and whether actual packaging is in play. If any is missing or marked open, stop and ask (see the table). Two checks that cost seconds and save a run:
   - **The hang-tag text actually reaches the field.** If the brief decided a phrase, it goes in `hangTagText`, within 28 characters. If it does not fit, shorten it WITH the owner rather than truncating it silently. If the brief said "none", leave the field empty and say out loud that Genrupt will write one from the buyer signal, so nobody is surprised by words they did not choose.
   - **Packaging is real before a packaging tactic runs.** If `packaging_expansion` is enabled, confirm the packaging bucket actually has images in it and that `alwaysIncludePackaging` is on. Enabled tactic plus empty bucket equals an invented box.

   The brief also carries the SELECTION CRITERIA: what a winning main must do for THIS product, the mechanism that beats the incumbent. Read those back too; they are the instrument for the pick, and reading them BEFORE the images exist is what stops the pick becoming a beauty contest.

2. **The main-image laws. Non-negotiable, every product, every candidate.** These laws now serve two jobs: they are the FILTER every candidate is checked against before the human sees it (the OpenAI pool in step 6, everything again in step 10), and they are the AUTHORING rules on the OpenAI Blast (step 6). On the Genrupt path they are never pasted into the slot as prose; the big prohibitions are enforced system-side, and a violation that comes off the machine anyway is a bug to report and a candidate to pull, not something to argue with in a brief.
   - **The product is the hero, and faces NEVER appear.** No faces, ever, on any candidate, from either machine. Hands and natural product-in-use moments (a hand dipping, a hand holding the product toward its use) are lawful ONLY when the owner enabled the human-contact tactic, and then the hands must read as real photographed hands: natural skin texture, no waxy glow. With that tactic dropped, candidates are product only: no people, no hands, no product-in-use.
   - **NO overlay text or graphics.** No headlines, callouts, arrows, or floating seals. The ONLY marks allowed are what physically exists on the product, its label or box, and the hang-tag the owner approved. Best Seller flags, star ratings, review counts, and award graphics are never allowed: Amazon draws its own on the search tile, and a drawn one is a fake badge.
   - **The product is the real product.** Real material, true proportions, and every part present and countable (a four tier machine shows all four tiers, steel reads as metal and not plastic), matching the locked reference exactly.
   - **Never promise what the product cannot deliver as sold.** This is the most expensive mistake in this room: an over-promising hero wins the click and buys the one-star review. If the research names a gap between what the category's pictures suggest and what buyers report actually happens, the winning candidate must show the buyer's reality, not the fantasy.
   - **No new product facts.** If an attribute is not in the Reference Sheet or the brief, it does not exist and must not be depicted.

3. **Report the cost against the live balance, then run.** Read the balance first (a free read, the same fuel gauge `/machines-check` uses) so the number is real; if the connection does not expose a gauge, say "balance not available on this connection" rather than guessing. One line before: "Main candidates on [path], tactic [name], about [credits/dollars], balance [X]." One line after: what it actually cost. **This is a report, not a gate.** The owner approved the brief and this room executes it; stopping for permission on every batch only delays work they already said yes to.
   Three things still stop and get named FIRST, because they are decisions and not execution: a **Draft Blast** (100 credits list price for a single slot; quote the live cost preview, which may bill less), a **retry or Round 2 that re-spends on a slot which already produced candidates**, and a **balance that will not cover the run** (say the exact shortfall, then stop, because a half-spent batch is worse than an unspent one). The OpenAI Blast's dollar estimate rides in the same one-line report; at quality low it is a few dollars for the whole pool and never needs its own stop.

4. **Generate. Path A: Genrupt (primary).** **The plan already exists.** `/creative-brief` saved it when the owner approved the brief, with the main-image controls answered at setup time (its `## Send log` records the date and the cast). Open that plan, confirm the controls read back as the owner answered them, and generate. Never plan from the ASIN again and never re-plan: that wipes the whole approved gallery to make one hero.
   - **The hero runs as a Draft Blast: about 100 drafts for this one slot** (100 credits list price; quote the live preview's `finalCreditsCost`, which has billed 29). That is the point rather than an extravagance. **The best five of a hundred beat the best five of ten**, and the main image is the one asset where that difference compounds into rank, reviews and everything downstream.
   - **Confirm the spread before it runs.** With several tactics enabled, those hundred drafts should cover all of them, **whether mix and match is on or off**: the setting only governs whether two tactics may share one image, never whether the run distributes. Say what you expect ("four tactics, so roughly twenty-five each") and check it against what actually comes back in step 5. A hundred near-identical drafts of one tactic is a failed run wearing a successful one's clothes, and it is worth catching immediately.
   - **The blast call carries almost nothing, and that is by design.** It identifies the set and the slot and confirms the plan is approved; the model, the aspect ratio, the tactics and the cast were all decided at PLANNING time and live in the saved plan. Read the tool's schema and pass only its declared fields. Do not attach a model or an aspect-ratio field here: those belong to other capabilities, the schemas are strict, and an undeclared field fails the call instead of being ignored. `planApproved: true` is lawful only because the owner's approval was already saved.
   - **Edit the existing plan; never re-plan.** Fix through the plan-review and save path only.

5. **Do NOT drag a hundred drafts onto the disk. Verify the spread, then hand the picking to the app.** A Draft Blast produces about a hundred images and they live in Genrupt, where there is a proper grid and a Compare view. Dumping all hundred into `images/` helps nobody and buries the ones that matter.
   - Read the blast back (`get_listing_builder_blast_images`) and report the SPREAD. **Know the limit before you promise a number: the API returns NO per-draft tactic label on a Draft Blast** (verified 21 August 2026; reported to Genrupt), so an exact drafts-per-tactic count is not available. The honest version of this check: open an even SAMPLE across the blast (about 20 drafts, spaced through the batch), classify each by eye (tag visible, hands or person, packaging, plain), and report the spread as a judged sample, labelled as such. If the sample reads lopsided or single-tactic, say so plainly and stop before the owner wastes an hour picking from a failed run. Mix and match being off is **not** an explanation for a lopsided spread.
   - **Then run the vanilla control, as its own job, before the owner starts picking.** ONE main image with every tactic OFF, same locked reference, same preset. That is the decision; the mechanics belong to Genrupt and you look them up rather than remembering them. Tactics are a PLANNING control, not a blast parameter, so the control does not come from the blast call: find the capability that can produce a single main with tactics cleared (`search_capabilities`, then read its input schema), and if the only lawful route is a plan edit, edit through the plan-review and save path and restore the tactic settings afterwards. **If no capability on this connection can do it, say so plainly and carry on without it**, recording `vanilla control: not available on this connection` in the batch log. What is forbidden is re-planning from the ASIN, which wipes the approved plan, and inventing a parameter that the schema you just read does not declare. It cannot be part of the blast (see control 2 above). Report it in the same line as the spread so the owner sees it landed. **Do not offer to skip it because the hundred look good**: it is the compliant swap-in that makes the ToS advice in Day 5 lesson 1 safe, and its whole value is existing before it is needed.
   - **RE-APPROVE THE PLAN AFTER THE CONTROL, always.** The control's route is two setup writes (tactics cleared, then restored), and a setup write silently drops the saved plan back to `approved: false` (`CLAUDE.md`, Genrupt contract rule 6). Nothing in either response says so. Skip this and the damage lands TOMORROW, in another room: Day 6's Theme Blast refuses to run and the error says nothing about a vanilla control. So: read the plan back, confirm the tactics restored AND `approved: true`, and re-save the approval if it dropped. Free check, and it is the difference between a working Day 6 and a mystery.
   - Then point the owner at the app and say what to do there: work through the grid, use **Compare** when torn between two, and **select between one and five**. Not one. Say plainly that this app selection is the SEMI-FINAL: the final shortlist of one to five is chosen in step 8 across BOTH machines' pools, and an app pick may lawfully lose its seat there. The Tasting Room needs candidates to race, and the A/B doctrine wants a queue of tested challengers ready rather than a single favourite.
   - **The owner selects in the app. Nothing needs to be copied back to you.** The selection state is readable, so when they say they are done, that is the whole handoff.

6. **Generate. Path B: the OpenAI Blast. A first-class second machine, not a spare tire.** This path runs BY DEFAULT beside Path A whenever the key is alive: this room AUTHORS a wide pool of mains on `gpt-image` (`images.edit`, the product's real photos attached as references), and the owner picks from the union of both pools. When Genrupt is down it runs alone, with the honest note that product fidelity holds less tightly than on the locked path, so inspection matters double.
   - **Machinery.** Confirm the key: if `$OPENAI_API_KEY` is not set, load it from the `.env` in the Factory root before the first call. Attach the reference images from `2-reference/photos/` (or the Reference Sheet itself) to EVERY call. Prepend the product spec from `2-reference/reference-sheet.md` (exact size, material, parts and their count, label text) so the model cannot drift. **Quality low, always**: low is a tenth of high's price and the pick happens at thumbnail size anyway. The picked winners are NEVER re-rendered (no seed control exists, so a re-render is a DIFFERENT image than the one the owner chose); they are finished by the precision upscale in step 8. Run the calls in parallel, one attempt per image, and generate ONE probe image first, VIEW it, and only continue if the product renders faithfully. If it does not, stop and tighten the reference rather than burning the pool.
   - **Volume.** Wide by default: about 40 prompts at low, up to 100 when the owner wants the full mirror of the Draft Blast. Quote the money from the run itself (roughly one to two cents per low image; say the total for the planned count before running). Only 1 to 5 finals are ever needed, so width costs little and buys variety, which is the entire point.
   - **The conservativeness ladder.** Prompts are authored across TIERS, from safest to boldest, and the enabled tiers come from the SAME tactic answers the owner already gave (never a second interview):
     - **Tier 1, ultra-safe** (always on; this is the vanilla control's sibling): product only, pure white, zero text, several angles, lighting moods and shadow strategies.
     - **Tier 2, the tag** (on when `hang_tag` is enabled): the brief's tag phrase, inside 28 characters, on varied physical tags, including CREATIVE DIE-CUT SHAPES that carry one claim or one piece of social proof (a leaf-shaped tag, a silhouette tag reading a real award), never a drawn badge, always a physical object. **If the brief left the tag phrase on auto, ask the owner ONCE before the blast**: "Do you have a phrase for the tag (your main keyword, a real award, a set count, a true quantity or duration), or shall I choose?" One phrase, chosen or approved, rides on EVERY tag-tier image in the pool, so the tag candidates differ in tag style and never in message. **The tag must say something the label does not already say at thumbnail size**: a tag repeating the label's headline wastes the one extra message the shopper gets.
     - **Tier 3, dynamic-honest**, in two halves with different gates. CONTENTS IN MOTION (on for any product whose contents or accessories can move, under any tactic set): the product's own contents frozen mid-air falling into it, a pour or splash of what it actually holds, or the full contents laid out as physical objects beside it (the what's-inside shot, a proven winner for consumables). HANDS (ONLY when `human_contact` is enabled): hands using it naturally, including one hand-for-scale variant that shows the product's true size in a real grip. Hands only, faces never, real skin texture on the hands.
     - **Tier 4, packaging** (on when `packaging_expansion` is enabled AND real packaging photos are in the bucket): the real box beside or behind the product. No packaging photos = this tier does not exist; no box is ever invented.
     - **Tier 5, creative-artistic** (on when `genrupt_choice` is enabled, read as "the owner welcomes bolder ideas"): one dramatic art-directed element per image: a motion freeze, a splash crown, a floating composition. Still white background, still the product dominant, still zero invented product facts.
   - **Competitor inspiration, before authoring.** Read the competitor mains already sitting in the research (`research/competitors.md` and the gallery screenshots in `1-inputs/`): what every rival's hero does, what none of them does, and 2 to 3 concrete beat-moves. Write the moves down in the batch log and let prompts cite the move they are beating. This is where "more interesting than everyone else's hero" actually comes from; without it the ladder produces pretty images that look like the category.
   - **Sets and bundles.** A product sold as a set shows EVERY component in its mains: at least one Tier 1 layout where each piece is identifiable and countable, and one hero-with-supporting-cast arrangement. The component count comes from the Reference Sheet and is checked in step 10 like any product fact. **Sets get their extra width in Tier 1, not Tier 5**: scattered or floating compositions make loose lids and parts read as extra pieces at thumbnail size, so creative-tier prompts on a countable set keep the set grouped and countable.
   - **The pool lands locally, through the bundled engine, under one naming contract.** Run `python3 .claude/skills/main-image/openai_blast.py run [prompts.json] [pool dir]` from the kit root; the pool dir is `images/openai-blast/[date]/`. Pool files are named `pool-NN_TIER_vV.png` and NN is the id the owner speaks. The engine is resumable (re-running skips finished files) and prints the reconciliation arithmetic itself.
   - **Screen the pool BEFORE the owner sees it.** Open every pool image and run law classes (a) through (c) from step 10 plus the tag-letter zoom NOW, pre-sheet. Violators stay in the folder, marked in the batch log, and never reach a sheet; the owner never wastes attention on a candidate the law already killed.
   - **Then build the pick sheets:** `python3 .claude/skills/main-image/openai_blast.py sheet [pool dir]` produces `pick-sheet-N.jpg` pages of 20 labeled tiles each, so every tile stays big enough to judge. The owner picks by printed id ("07, 19 and 31"). Winners get PROMOTED into the `main-NN.png` sequence in step 7, and the pool folder stays as the archive.
   - All the laws of step 2 are authoring rules here, and the tag tier obeys the same 28-character limit as Genrupt's field.
   - **Every prompt, every tier, closes with the fidelity sentence.** Beyond opening with the product spec, each prompt ENDS with an explicit reminder: "The product itself must remain EXACTLY as in the reference images: same design, proportions, colors, parts and label; change nothing about the product." Measured runs showed the product drifting in a minority of frames when the spec appeared only once at the top; saying it twice, start and end, is free and cuts the drift.
   - **Two more authoring guards, learned from measured runs.** (1) REFERENCE BLEED: when the reference photos show a retail box, the model sneaks it into tiers that never asked for it; every NON-packaging prompt therefore states plainly "no retail box in frame". (2) TAG TEXT AT LOW QUALITY can typo or truncate ("WIRELESSS"): every tag-tier candidate gets its tag text read at full zoom in step 10, letter by letter against the brief's phrase, and a typo pulls the candidate like any law violation. A tag typo is healed by regenerating THAT candidate (a new candidate, law-checked again), never by pretending an upscale will fix words.

7. **Save to `images/` under one flat naming contract.** Never overwrite, never delete, never renumber.
   - New candidates: `main-01.png` .. `main-NN.png`, numbered in the order the selection read-back names them (Genrupt path) or in the order the owner promotes them from the OpenAI pool (Path B; the full pool stays archived in `images/openai-blast/`). Every later room and every later day refers to these images by filename, so the numbering is a promise: never renumber after the fact.
   - A REGENERATION of an existing candidate keeps its number and gains a suffix: `main-02-v2.png`, saved beside an untouched `main-02.png`. Keeping the number keeps candidate ids stable, which is what lets a round-over-round tasting comparison line up.
   - A NEW candidate that is not a re-bake of an existing one (a challenger built from a tasting objection) takes the NEXT FREE number in the same sequence: `main-09.png`. There is no separate series.
   - Surgical edits are `/fix`'s work and land as complete set snapshots in `edits/vN/` (same filenames, the round in the folder name), never in `images/` and never by this room.

8. **Support the human choice, then read the selection back and bring it home.** This is the second half of the room's job and it is service, not judgment.
   - **Before they pick**, give them the instrument: the brief's SELECTION CRITERIA restated as a short list, the incumbent read (what the current live main does and fails to do), and the reminder that a shopper sees these at postage-stamp size in a row of rivals. Offer to show any candidate downscaled to thumbnail size on request. A criteria list read before the grid is judgment; the same list read after is a rationalisation.
   - **While they pick**, stay out of the way. On a dual blast the pick runs over the UNION: Genrupt's candidates in the app's grid and Compare view, the OpenAI pool on its contact sheet, one shortlist of one to five across both. The human is better at "which would I click" than any scorer.
   - **When they say they are done, read the selection state back BEFORE downloading anything.** Name what you found selected, count included: "four selected, here they are." That two-second read-back catches a stray click, a selection left over from an earlier round, and the case where nothing actually saved. Never assume a selection took, exactly as with a plan save.
   - **Then bring them home, and FINISH the OpenAI winners.** Download the Genrupt selections and promote the OpenAI picks into `images/` under the naming contract in step 7. An OpenAI winner is 1024 pixels and Amazon zoom wants 1600 and up, so each promoted winner gets a PRECISION upscale: Genrupt `upscale_image` with model `High Fidelity V3`, factor 2, face enhancement off (about 2 credits; measured to keep tag text letter-crisp). Never a generative model (Redefine, Bloom) on a winner: those redraw. Save the 2048 file as the promoted `main-NN.png` and keep the 1024 original in the pool archive. Then mark the slot completion and update `status.md`. This step is not optional and it is easy to forget: `/inspect`, `/fix` and the Tasting Room all read the local folder, so a selection that stays in Genrupt is a Day 6 that opens on an empty directory.
   - **Never pick, score, or rank on the owner's behalf**, and never quietly drop a selected candidate because you disagree with it.

9. **Handle failures out loud, and reconcile the count.** Every planned candidate ends in exactly one of three states: **generated**, **failed** (record the exact error), or **skipped** (record the reason, e.g. the owner's approved trim from the cost table). State the arithmetic before handing off: planned N = generated M + failed K + skipped S. If the numbers do not add up, the batch is not done. On a mid-batch tool error, retry once; generation resumes from saved slots, so what already landed is not paid for twice. If a machine is down for good, keep what landed, record the failure, and offer the other machine for the rest with its own cost line. A quietly shorter batch is the one thing that must never happen.

10. **Run the fidelity and law check on every collected candidate, then stop judging.** Open every file and look. This room checks four catastrophic classes only, each with a fixed action:
    - **(a) Not the product** (wrong part count, wrong material, wrong shape). On a set or bundle, COUNT the pieces on every candidate, out loud, against the Reference Sheet's count; generators miscount sets more than anything else. ONE candidate drifted: pull it from the choice set, log it, and regenerate if the owner wants the slot refilled. ALL of them drifted: STOP, spend nothing more, and go back to `/reference-sheet` to re-lock with a fresh smoke test. On the Genrupt path a wholesale drift with the reference confirmed attached is also a bug to report, not a prompt to write.
    **The attachment reality (verified 21 August 2026, reported to Genrupt):** on the current MCP connection an APPROVED reference sheet CANNOT be attached to the listing-builder set at all: every route returns 403 or 404 (the asset saves to the product profile only). So "confirm the reference is attached" resolves honestly in one of two ways: a connection where an attach path exists and was verified, or the recorded line `reference attach: not possible on this connection (403)` plus the working substitute, which is the MATERIAL LOCK: the reference's decisive physical facts (material, part count, one auger) written as short ADDITIVE `customInstructions` on the drift-prone slots. That lock held across a 100-draft blast and a 60-image theme blast in practice. Never let the unsatisfiable check silently pass, and never let it block the day either.
    - **(b) A face, anywhere, always. A hand or a person when the human-contact tactic was NOT enabled.** Never enters the choice set. Pull and log it. (With human-contact enabled, hands are lawful and are judged instead for realism: waxy, glowing, or anatomically wrong hands are pulled under class (a).)
    - **(c) Overlay text, a drawn badge, a star rating** (anything beyond the product, its label, and the approved hang-tag). Never enters the choice set. Pull and log it.
    - **(d) A failed or blank render.** Log it with its error and retry or record per step 9.
    A pulled candidate stays on disk and in the log (never delete), it just does not get shown as a choice. Then STOP. Scores, the squint test, the compliance verdicts, and the deep ranking belong to `/inspect`, and duplicating them here just gives the owner two opinions to referee.

11. **Post-tasting: the challenger and the ordered regenerations (Day 8).** Two different jobs arrive here after the Tasting Room, and both must be traceable:
    - **The challenger.** ONE only, and optional. Build it only when the tasting notes handed you a thesis that Round 1 never tested. On the Genrupt path a challenger is a NEW generation under a DIFFERENT control setting, usually a different tactic, confirmed with the owner like any tactic; it is never a prose brief on slot 1. On the OpenAI Blast it may be authored from the thesis directly. It must be a different STRATEGY, not different decoration: two shades of the same idea split votes and teach nothing. It carries the honesty law from step 2 even harder, because a challenger born from a praise theme is exactly where over-promising creeps in. Write its provenance into the batch log: the theme it came from, how many tasters said it, and which control changed. Then hand it straight to `/inspect`; no image enters the Tasting Room ungated, not even one born from data. If no theme reached enough mentions to build on, SAY SO and skip it. An uncited challenger is a reroll wearing a costume.
    - **Regenerations ordered by `/fix` MODE B.** When a taster objection routes to REGENERATE (framing, size in frame, layout, anything spatial), it comes back here. On the Genrupt path that means a fresh generation under the same or an owner-adjusted control setting, with the objection recorded; on the OpenAI Blast the tighter sentence is carried in the prompt. Save it as `[winner]-v2.png` and record which note drove it. Same rule for scorecard-driven regenerations in MODE A.
    - **Otherwise the mains stay frozen.** Do not re-run this room just because a later room is open. After the batch passes the gate, a main changes only when a scorecard flag or a tasting note orders it.

12. **Log the batch** in `images/batch-log.md` (append, never overwrite) using the format below: the candidate map with the controls that produced it, the batch row, the reconciliation, the human shortlist with reasons, and any Round 2 provenance.

    **Then feed the GENERALIZABLE reasons forward.** Read the shortlist reasons back once more. A reason that names a look, an element, or a rule ("nothing on a marble countertop", "the steel base must stay in frame", "that angle hides the tiers") is a creative preference that outlives this batch: append it as a dated bullet under **Owner creative preferences** in `factory/Improvement Log.md`, in the owner's words, and say out loud that it was recorded so the next brief starts already knowing it. A reason that only compares candidates ("this one is better", "cleaner") stays in the batch log and goes no further. Without this step the reasons die in the batch log, and the owner ends up re-rejecting the same idea in three products, each time from scratch.

13. **Hand off.** Tell the owner: "The mains are out of the machines and your shortlist is named. Nothing here is approved yet. Next stop is the Inspection Room: run `/inspect` before you fall in love with anything." Then name the rest of the INVENT station: `/secondary-images` for the gallery, `/aplus` for the modules, `/variations` if the product sells variants. The full package goes to Inspection together.

## Output format

`factory/Products/[product]/images/` after a run:

```
images/
  main-01.png
  main-02.png
  ...
  main-08.png
  main-02-v2.png       (a regeneration, beside its untouched original)
  main-09.png          (post-tasting challenger, next free number)
  batch-log.md
```

`images/batch-log.md`:

```markdown
# Batch Log . [Product Name]

## Controls confirmed (before spend)
Tactic: [name, as the setup flow names it] (owner confirmed [date])
Hang-tag text: [text, or "none"]
Packaging preference: [choice, or "none"]

## Candidate map
| File | Path | Produced by | Law check | Result |
|---|---|---|---|---|
| main-01.png | genrupt | tactic [name] | pass | generated |
| main-02.png | genrupt | tactic [name] | pass | generated |
| main-03.png | genrupt | tactic [name] | PULLED: [law class + one line] | generated |
| main-04.png | genrupt | tactic [name] | . | failed: [exact error] |
| main-05.png | openai-blast | tier [N] "[variant name]" (promoted from pool-NN, upscaled 2048) | pass | generated |

## OpenAI pool summary (one row per tier; explicit rows ONLY for pulls and promotions)
| Tier | Planned | Generated | Failed | Pulled (law) | Promoted |
|---|---|---|---|---|---|
| t1-pure | 10 | 10 | 0 | 0 | pool-03 -> main-05 |
| t2-tag | 10 | 9 | 1 | pool-14 (tag typo "[quoted]") | . |

## Batches
| Date | Room | Path | Model | Candidates | Est. cost | Approved | Notes |
|---|---|---|---|---|---|---|---|
| [date] | main-image | genrupt / openai-blast | gpt_image_2 | 8 | [est] | yes ([date]) | planned 8 = generated 7 + failed 1 + skipped 0 |

## Human shortlist
- Picked: main-02, main-05. Owner's reasons: main-02 "[one line, owner's words]", main-05 "[one line]".
- Criteria they were judged against: [the brief's selection criteria, one line].

## Post-tasting provenance (only when a challenger or an ordered regeneration ran)
- main-09.png . challenger. Theme: "[the taster theme, quoted]" ([N] tasters, Tasting Round 1 card). Control changed: [tactic X to tactic Y, owner confirmed]. Different strategy from the winner because: [one line].
- main-02-v2.png . regeneration ordered by /fix MODE B. Note that drove it: "[quoted note]" ([N] tasters). What changed: [control adjustment or the tightened prompt sentence].
```

## Golden Standards check

Before handing off, verify:
- [ ] All four preconditions were checked by opening the files, and any block was reported with its exact ask, not worked around.
- [ ] All three main-image decisions (tactic, hang-tag text, packaging preference) came from the brief and were confirmed with the owner BEFORE spending. No control was defaulted, guessed, or inferred.
- [ ] Slot 1 round-tripped unchanged in every plan save: zero brief text, zero headers, zero custom instructions, zero slot references on the main.
- [ ] Cost was read against the live balance and REPORTED in one line before and after, never used as a gate. A re-spend on a slot that already produced candidates, and an insufficient balance, were each named and stopped on before running.
- [ ] Every enabled tactic was confirmed with the owner, every dropped one carries a written reason, and the hang-tag text either came from the brief inside 28 characters or was left empty with that consequence said out loud.
- [ ] If a packaging tactic ran, the packaging bucket was confirmed non-empty and `alwaysIncludePackaging` was on. No box was ever invented.
- [ ] The blast SPREAD was reported per tactic before the owner started picking, and a lopsided or single-tactic spread was called out rather than passed along.
- [ ] The VANILLA CONTROL was generated as its own job with `enabledMainImageTactics: []`, and it is on disk. Never tick this from an intention.
- [ ] The owner picked between one and five, in the app, holding the selection criteria. The selection was READ BACK by name and count before anything downloaded.
- [ ] The selected candidates are on disk in `images/` and the slot completion is marked. Nothing important was left living only inside Genrupt.
- [ ] EVERY candidate is accounted for: the OpenAI pool and the selected Genrupt candidates on disk, the unselected Genrupt drafts still readable in the app with the spread logged, and every pull and failure named. None dropped silently.
- [ ] No candidate shown to the owner carries a face, ever. Hands appear only under an owner-enabled human-contact tactic, and only real-looking ones.
- [ ] No overlay text or graphics on any shown candidate, and no drawn badge, star rating, or review reference. Only the product, its label, and the approved hang-tag.
- [ ] Nothing shown over-promises what the product delivers as sold, and no product fact appears that is not in the Reference Sheet or the brief.
- [ ] Genrupt path: every call was made against a schema that was READ first, with no field the schema does not declare; the model is pinned wherever a schema accepts one and inherited from the plan elsewhere; plan edited not re-planned; reference attachment verified OR its absence recorded (see the attachment reality below); style only via the branding preset and styleImage.
- [ ] OpenAI Blast: key confirmed, references attached and product spec prepended on EVERY call, quality low, the probe image viewed before the pool ran, tiers derived from the owner's tactic answers (no tier invented, none silently dropped), competitor beat-moves written down before authoring, the pool archived in `images/openai-blast/` with its contact sheet, and promotions into `main-NN` recorded. Running alone (Genrupt down), the weaker-fidelity warning was given.
- [ ] Naming contract held: machine order (or promotion order from the OpenAI pool), `-v2` beside an untouched original for regenerations, next free number for the challenger, no overwrites, no renumbering.
- [ ] The reconciliation adds up (planned = generated + failed + skipped) and every failure carries its exact error, every skip its named reason.
- [ ] The human choice was supported, never made: criteria restated, candidates laid out, thumbnail view offered, no ranking or recommendation given, the owner's picks and reasons recorded.
- [ ] Post-tasting only: the challenger cites its theme and mention count, changed a control rather than adding prose, and went to `/inspect` before any tasting.
- [ ] Batch log written with the confirmed controls, the candidate map, the batch row, the reconciliation, and the shortlist.
- [ ] Generalizable shortlist reasons were appended to the Improvement Log's Owner creative preferences (dated, in the owner's words), and the recording was said out loud; compare-only reasons stayed in the batch log.
- [ ] The owner was pointed to the Inspection Room, and no image was called final, approved, ready, or best.

## Wonka lines

Openers:
- "The Main Image Room. One square inch of shelf, and the machines will offer you many ways to win it."
- "The hero shot is the product. Full stop. We set three dials, the machines do the rest, and YOU do the choosing."
- "Come in, come in. Today the factory bakes a whole tray of heroes, and you pick the one the shop window gets."
- "Money first, because this factory never spends silently. Here is the number. Say the word."

Closers:
- "A tray of contenders, out of the machines, every last one collected. Your shortlist is noted. Inspection Room, next."
- "Fresh mains, still warm. Whether your pick is THE main is a question for the shoppers, not for either of us."
- "I laid them out and held the yardstick. The choosing was yours, as it always is in this room."
- "A challenger born from what a hundred tasters told us, with its parentage written on it. Now let them judge their own child."

## Definition of Done

- The three main-image decisions are confirmed with the owner and recorded in the batch log before any spend.
- Every candidate is accounted for: promoted winners in `images/` per the contract, the OpenAI pool in `images/openai-blast/`, unselected Genrupt drafts alive in the app with the spread logged, or a recorded failure with its exact error, or a named conscious skip. Planned = generated + failed + skipped, stated per machine.
- `images/batch-log.md` exists with the confirmed controls, the candidate map, path, model, count, approved cost, the reconciliation, and the human shortlist with the owner's reasons. Round 2 runs also carry their provenance lines.
- The fidelity and law check ran on every file, and no image with a person, overlay text, or a wrong product was shown as a choice.
- The human named the shortlist; this room recorded it without ranking or recommending.
- `status.md` updated per below.
- The owner was explicitly handed to `/inspect`, with `/secondary-images`, `/aplus`, and `/variations` named as the rest of the INVENT station, and no output was presented as final.

## Update status.md

In the INVENT sub-status block, set `Main image (/main-image): done` (or `in progress` if the batch is partial, waiting on a named decisionhead, or waiting on the owner's shortlist, or `blocked: [precondition or unanswered control]`). Artifact `images/main-01..NN.png` + `images/batch-log.md`. Then check the whole INVENT sub-status block: when all four sub-parts (Main image, Secondary images, A+, Variations) are `done` or `n/a` with a reason (variations may be n/a or a lawful trailing marker), set the INVENT station row to `done`; otherwise leave it `in progress`. Log line: `[date] Main candidates generated: [M] of [N] planned on [path], tactic [name], cost approved [est], [K] failed, [S] skipped, [P] pulled by the law check. Owner shortlisted [files]. Awaiting inspection.` For a Round 2 run: `[date] Round 2 challenger main-[NN] generated from the "[theme]" tasting note ([N] tasters), control change [X to Y]. Inspected before tasting.` Name the remaining INVENT rooms as next steps, with INSPECT to follow once the full package exists.


**Then roll the station up, because whichever sub-part finishes last owns this.** Check the whole INVENT sub-status block: when all four (Main image, Secondary images, A+, Variations) read `done`, or `n/a` with a reason, set the INVENT station row to `done`; otherwise leave it `in progress`. A single-SKU product never runs `/variations`, so if only that room rolled up, INVENT would sit unfinished forever on exactly the simplest products.
# 2-reference/

The Reference Sheet is the locked reference of your REAL product. It is what stops the AI from inventing a bottle you do not sell.

What lives in this folder:
- `photos/`: your real product photos and your packaging photos. All angles (front, back, both sides, top), one hand-for-scale shot, label close-ups, plus box and label panels.
- `logo/`: your real logo file, if you have one. Independent of everything else: a logo needs no brand book, and no logo is needed to run. `/reference-sheet` uploads it and wires it into Genrupt when it is there, and simply continues when it is not.
- `brand/`: a real Brand Book or Style Guide, if your brand has one. `/brand-kit` reads it. Optional, and nothing waits for it.
- `reference-sheet.md`, the lock record ("Reference status: LOCKED" plus the smoke test result) and the smoke test control image. Written by `/reference-sheet`.

No generation batch runs before the smoke test image in this folder has been looked at and approved.

You never have to file anything here yourself. Attach what you have to Claude and Wonka sorts, saves and routes it.

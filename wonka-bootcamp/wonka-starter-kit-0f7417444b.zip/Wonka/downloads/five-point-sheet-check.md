# The Sheet Check: Two Layers

**"Nice" is not a check.** The Reference Sheet is the mold every image is poured from, so judge it
like a mold, not like a picture. The check has two layers, in this order, and the order matters.

## Layer one: the anatomy check, at magnification

Zoom first. Crop the same region from the sheet and from your source photo, put them side by side,
and walk the product part by part: shape, proportion, color, material, printed text. **Never judge
a sheet at gallery size.** The defects that poison generations, a wrong neck proportion, a chrome
part that is really brass, live below full-frame resolution and sail through a full-frame glance.

Two laws inside this layer:

- **A part that is present but HIDDEN fails its row.** A cap, a wrap, or an angle that covers a
  part the sheet exists to lock means the sheet locks NOTHING about that part. Hidden is a fail,
  exactly like missing.
- **A fact is measured on at least two photos, in different light.** One photo lies about color
  and about ratio; a fact only one photo supports gets marked single-source, and it is the first
  suspect when a sheet round fights the measurements.

## Layer two: the five panel checks

1. **Coverage.** Are there enough angles to understand the product? Front, back, both sides, top.
   Whatever is not in this picture, the machine gets to invent forever. And was any view invented
   without a source photograph? A panel with no photo behind it is a guess, however clean it looks.
2. **Scale.** Is there a scale cue? Can you tell how big it really is without reading anything?
3. **Panel quality.** Is every panel clear AND attractive? A blurred or ugly panel does not merely fail to help,
   it POISONS everything poured from this mold.
4. **Material truth.** Are the materials honest? Steel reads as metal, plastic as plastic, glass as translucent
   glass. If a mixed-material product renders as one gleaming metal object, every image after it is
   selling something that does not arrive in the box.
5. **Product integrity.** Has anything been added, removed, duplicated, reshaped or invented? No text, no captions, no arrows, no badges. This sheet locks
   identity and nothing else.

## When it fails

- **Name the defect in NOUNS, and give a proportion a NUMBER.** "The tower reads as chrome, the
  base is brushed stainless." "The tube is 4 to 5 times taller than it is wide." Not "it looks
  off"; a machine cannot act on a mood, and "too short" just buys another guess.
- **Revise the sheet you have, never start a new one.** Starting over throws away everything that
  was already right.
- **If the same defect survives two rounds, stop rewording.** The problem is upstream, and there
  are two suspects: a missing photo (go take it), or an instruction that contradicts the product's
  true geometry (re-measure your own claim against the magnified source). Check both.

And remember the order of the day: pass both layers, say **"Approve all"**, let Wonka sweep the
plan's wording against what the sheet measured, and stop. Approved is not locked. In the second
lesson you say **"run the smoke test"**, and only when every frame passes both reads do you say
**"The smoke test passes. Lock the reference and mark the smoke test as passed."** A sheet locked
on a look rather than a passed smoke test is the one failure Day 4 exists to prevent.

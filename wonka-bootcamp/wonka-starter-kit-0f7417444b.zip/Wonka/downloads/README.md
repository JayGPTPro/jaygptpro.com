# downloads/

Short reference one-pagers. The Genrupt and OpenAI guides are Day 1 setup; the shot list and the shopping list belong to Day 2, when your product walks through the gate.

- `genrupt-account-setup.md`, the image machine, click by click
- `openai-key-and-verification-walkthrough.md`, the key, the verification, and the error table
- `product-photo-shot-list.md`, the six shots, on your phone, in twenty minutes
- `front-gate-shopping-list.md`, what goes into the one ZIP you hand Wonka on Day 2

They ship inside the kit on purpose: setup has to be possible from the folder alone, before you
have opened a single portal room.

The other WORKSHEETS (reading a Tasting Card, edit versus regenerate, the approved-claims
worksheet, and the rest) arrive in their own day's room, on the day each is useful. That pacing
applies to worksheets and day materials only. The INSTRUCTIONS are different: all ten day guides
ship in the kit's `guides/` folder from day one, so Wonka can read any of them on demand whenever
you ask.

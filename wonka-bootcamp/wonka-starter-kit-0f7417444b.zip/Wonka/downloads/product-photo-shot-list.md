# The Product Photo Shot List

Five to ten phone photos, each adding information the others did not, so Wonka never has to guess.

## The four things to cover

1. **Angles.** Front, back, both sides, top, and any angle that reveals a shape the others do not.
2. **States.** If it opens, folds, extends, connects or comes apart, show the states that matter.
3. **Scale.** A hand or a familiar object beside the product.
4. **Important details.** Buttons, stitching, textures, materials, labels, hinges, mechanisms. Anything expensive to get wrong.

## The checklist

```
ANGLES
[ ] Front
[ ] Back
[ ] Left side
[ ] Right side
[ ] Top down

STATES (if it changes shape)
[ ] Closed / folded / apart
[ ] Open / extended / assembled

SCALE
[ ] A hand or a familiar object, no face

DETAILS
[ ] Label or logo, readable
[ ] Texture or material, up close
[ ] Buttons, hinges, mechanisms, stitching

[ ] Each photo adds something new
[ ] Nothing edited or filtered
[ ] No faces
[ ] One folder, ready to zip
```

## Three exceptions

- **Multi-part products.** Shoot the complete set together from several angles, then every important part alone. Never a pile. The count can pass ten.
- **Packaging.** If it may appear in your images, shoot it as its own object: front, back, main label, and the product inside.
- **No product in hand.** Realistic customer photos from the reviews are the approved fallback. Tell Wonka that is what they are.

## The rules

- Every photo adds new information. Ten of the same angle is one photo.
- No filters, no reshaping, no auto enhance, no background removal. Evidence, not marketing.
- No faces unless the product genuinely needs a person. A hand for scale is fine.

*The Wonka Creative Bootcamp. Day 2 and Day 4.*

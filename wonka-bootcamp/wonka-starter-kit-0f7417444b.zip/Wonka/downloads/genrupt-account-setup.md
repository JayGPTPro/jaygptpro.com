# Genrupt Account Setup

**Machine 1. The one that makes every image your product.**

Genrupt is the image engine Wonka drives. What makes it worth having a dedicated machine for
is one thing: **it locks your real product.** Generic image models will happily draw a
product that looks a lot like yours, which is the failure that ruins Amazon creative. Genrupt
holds your actual item, so every image the factory makes is your item, not a cousin of it.

**Your ticket covers your first month of Genrupt: 1,000 credits.** You claim it with a coupon at
signup, so you do open a plan and you do enter a card, and month one costs you nothing. Cancel any
time during that month and it will not renew. Keep it and you stay at **$49 a month**, the Wonka
rate; the cheapest plan on open sale is $99.

**Already paying for Genrupt?** Do not open a second plan. Message Jay or Michael and the 1,000
credits go onto the account you already have.

Wonka drives it through an **MCP**, a direct line that lets him operate an outside tool
himself from inside Claude. In practice that means you almost never open the Genrupt website.
You talk to Wonka, and he does it.

---

## Part 1: Create the account

**1.** **No Genrupt account yet?** Create one first: open **genrupt.com/l/aivault** and click
**Apply for Beta Access**, with the email you want the factory tied to. Already have a Genrupt
account? Skip straight to step 2.

**2.** Open **genrupt.com/wonka** (the link is in your Day 1 room) and enter code **WONKA49** at
checkout. **Use that link and that code, not a general signup**, because together they are what
make the first month free.

**3.** Confirm your email if asked.

**4.** Sign in and land on the dashboard. You do not need to build anything here. Look
around for thirty seconds and leave.

---

## Part 2: Connect it to Claude

**The connection values are fixed and known.** The connector is named `Genrupt`, and the server
URL is `https://genrupt.com/api/agent/mcp`. There is no Genrupt API key to create or paste
anywhere in this flow; you authenticate by signing in to Genrupt in the browser window that opens.

**In Claude Desktop:**

**1.** Open **Connectors**, then **Manage connectors** (or the **+** button in the chat box, then
Connectors).

**2.** Click **Add custom connector**.

**3.** Name it exactly `Genrupt` and paste `https://genrupt.com/api/agent/mcp` as the server URL.

**4.** Click **Add**, then **Connect**, and complete the Genrupt sign-in in the browser window
that opens.

**5.** Quit Claude Desktop **completely** and reopen it. On Mac, **Cmd+Q**. On Windows, quit from
the **system tray**. Closing the window is not enough: Claude only loads a connector on a full
restart, and this step gets skipped constantly.

**6.** Reopen your kit and ask Wonka to run `/machines-check`.

---

## Part 3: Let Wonka verify it

Do not verify by eye. Ask for it:

```
/machines-check
```

Wonka runs three checks, all free:

1. **Python**, the free local process some of his scripts run on. Not a machine to pay for
2. **A handshake with Genrupt**, confirming the line is actually live rather than merely
   configured, plus **a credit fuel gauge** reading your balance so you always know where you stand
3. **A handshake with OpenAI**, the other machine

A connector that appears in a settings list is not the same as a connector that answers. The
handshake is the proof.

---

## When something goes wrong

| What you see | What to do |
|---|---|
| Connector added, Wonka cannot see it | Quit Claude completely (Cmd+Q on Mac, system tray on Windows) and reopen. This is the answer most of the time |
| Handshake fails | Reload the Genrupt site in your browser, then retry. The bridge can go stale |
| Says connected, tools do nothing | Remove the connector, add it again with the values above, and finish the sign-in in the browser window that opens |
| Credits show zero | Message Michael with your ticket details. Access is included, so a zero balance is a mismatch, not a purchase decision |
| Generations come out as the wrong product | Not a connection problem. That is the reference lock, which is Day 4 |

---

## If Genrupt is down or unavailable

The bootcamp does not stop. Wonka has a fallback: he generates directly on OpenAI's image
model using the key you already set up in Part 2 of the other guide.

**What it costs you:** product reference accuracy is meaningfully lower. Without the lock,
the model works from description rather than from your actual item, and the look alike
problem comes back.

**What Wonka does about it:** he marks it honestly in your files rather than quietly
producing weaker images and calling them the same thing. Every day except Day 7 remains doable on the fallback path. The A+ Room has no fallback:
A+ is hands-off by design, Genrupt authors the page, and there is no second engine to hand that
to. If Genrupt is out on Day 7, that room stays shut until it is back.

---

## The checklist

```
[ ] Account created using the bootcamp link
[ ] Email confirmed
[ ] Connector added in Claude: name Genrupt, URL https://genrupt.com/api/agent/mcp, signed in
[ ] Claude Desktop restarted
[ ] /machines-check run
[ ] Genrupt handshake passed
[ ] Credit balance visible
```

Two machines, both green, and the factory is open.

---

*The Wonka Creative Bootcamp. Day 1, The Front Gate.*

# Give Your Employee Hands: The OpenAI Key

**You do this once.** Claude is not an image model. Connect one to Claude Code and
"make me an image" starts working.

This is the text of the page at **jaygptpro.com/openai**, kept word for word so the guide you
read in a browser and the guide Wonka reads here never drift apart. Edit the page, rerun
`scripts/build_kit_download_pages.py`, and update this file in the same pass.

You need Claude Code installed and a folder to work in. The folder is whichever one you open
Claude Code inside: your AI employee, a course project, a client, anything. The key goes in
that folder.

> **Fifteen minutes of clicking, and one wait you do not control.** If your account is asked to
> verify before it can generate images, that review can take longer than the rest of this guide
> put together. That is why it is step 1: start it, then do everything else while it processes.

---

## Step 1: Create the account and start verification

**1.** Go to **platform.openai.com** and sign in, or create an account. This is the developer
platform, a separate place from ChatGPT even though the login is the same. **Paying for ChatGPT
Plus does not give you this**, so if you already have ChatGPT you still need everything here.

**2.** Go to **platform.openai.com/settings/organization/general** and look for a
**Verifications** section.

**3.** **If a verification option is offered, start it now.** In OpenAI's own words, it "may ask
you to complete verification before you can use certain products, features, models, or
programs", and image models are one of the places this shows up. If your organization is
already verified, you are done with this step. Do not start another one.

**4.** Identity verification asks for an original government-issued ID and, if requested, a
selfie. It takes a few minutes of your time. Approval is often quick, but it is not guaranteed
to be instant, and that is the whole reason this is step 1.

> **Your ID verifies one account, and only one.** OpenAI states it plainly: "for identity
> verification, individuals can verify only one account or organization", and attempting more
> than one can cost you access. So do not spend yours on an account belonging to a partner, a
> spouse or a client. Verify your own, and have them verify theirs with their own ID.

> **If it clears and images still refuse**, give it a moment. Approval does not always reach
> every surface at once, so refresh, or sign out and back in, and retry before you conclude
> something is wrong. *Do not start a second verification unless OpenAI specifically asks you
> to retry.*

---

## Step 2: Put $10 to $20 on the account

**1.** Go to **platform.openai.com/settings/organization/billing**.

**2.** Add a payment method.

**3.** Load **$10 to $20** to start. Exploring at low quality costs cents an image, so that goes
a long way.

> **Two things about prepaid credit that are easy to miss.** OpenAI's billing documentation says
> purchased credits **expire after one year and are non-refundable**, and that the expiry date
> cannot be extended. So buy what you expect to use, not a big balance "to be safe".
>
> The purchase screen also offers **auto recharge**, which buys more credit on its own whenever
> your balance falls under a threshold you set. That is useful for a business and a surprise for
> everyone else. If you do not want it, leave it switched off.

> **Set a spend limit while you are here.** It lives on its own page, not with billing:
> **platform.openai.com/settings/organization/limits**, under **Organization spend limit**. It is
> a ceiling that protects you from a runaway loop, and $30 is a sensible place to put it. The
> same page takes a spend *alert* if you would rather be warned than stopped.

---

## Step 3: Create an API key

**1.** Go to **platform.openai.com/api-keys**. It is also in the left sidebar, as **API keys**.

**2.** Click **Create new secret key**.

**3.** Name it after the project or employee it belongs to, so you know later what it is paying
for. Leave **Project** on Default and **Permissions** on **All**. Restricted keys can work, but
only when the image endpoints have write access, and All is the simplest thing that works for
this setup.

**4.** **Copy it now.** It starts with `sk-` and OpenAI shows it exactly once. Close that box
without copying and the key is gone for good, and you make a new one.

**5.** Paste it somewhere safe immediately. A password manager is right. A sticky note on your
monitor is not.

> **Trust the address, not the screenshot.** Menu labels and layouts move every few months. The
> addresses in this guide do not, so if a screen looks different from a picture you saw
> somewhere, go by the address.

> **One key per project is worth the extra minute.** Separate keys mean you can revoke one
> without breaking everything else, and the usage page shows you which project spent what.
> Reusing a single key everywhere works, and costs you both of those.

> **A key is a credit card.** Never paste it into a chat, never put it in a screenshot, and
> never read it out loud on a recording. It goes into one file on your own machine and nowhere
> else. If that folder is a git repository, add a line saying `.env` to its `.gitignore` first,
> or the key rides along the next time you push.
>
> *If you ever think a key leaked*, go back to the API keys page, revoke it and make a new one.
> It takes thirty seconds and costs nothing. A revoked key stops working for everyone, including
> you, so replace it in your `.env` at the same time.

---

## Step 4: Put it in one file in your folder

In the folder you work in, create or open a file called `.env` and add a single line:

```
OPENAI_API_KEY=sk-proj-your-key-here
```

That is the whole integration. The key stays inside that folder, and the scripts Claude runs
load it from `.env` when they need to call OpenAI. You never type it again.

> **The file name starts with a dot, and that is where most people get stuck.** A Mac hides dot
> files: in Finder press `Cmd + Shift + .` to show them. On Windows, File Explorer -> View ->
> Show -> Hidden items. If your editor will not save a file with no name before the dot, let
> Claude Code make it for you and then paste the key in yourself:

```
Prepare the .env file for my OpenAI key and open it for me. I will paste the
key into the file myself.
```

Paste the key into the file it opens, replacing the placeholder, save, close, and type `done`
back in the chat.

> **Notice what that prompt does not do.** It never asks you to type the real key into the chat.
> Claude makes an empty file with a placeholder, you open it and paste the key in yourself, and
> the key never appears in a conversation.

---

## Step 5: Ask for an image

Open Claude Code in that folder and ask in plain words:

```
Generate a test image with gpt-image-2 using the OpenAI key in .env: a red apple
on a white studio background. Save it to a folder called test/.
```

Claude writes the small script, calls the model and saves the file. If an apple lands in
`test/`, it has hands. From here you ask for the image you actually need, in your own words,
and it keeps the script for next time.

> **You do not need to write or understand any code.** If a package is missing on your machine,
> the error says which one and Claude installs it for you when you ask.

> **Two habits that keep the bill in cents.** Generate at **low quality while exploring** and
> full quality only for the finalists. And always generate **one image before a batch**: a
> minute of looking catches the wrong colour before it costs you a hundred images.

---

## Every error you are likely to see

| What you see | What it usually means | What to do |
|---|---|---|
| `401 Incorrect API key` | The key is wrong, or carries a stray space or line break | Re-copy it into `.env`. Check for a trailing space |
| `403`, or an image model access error | Verification, or the key's own permissions | Check verification first, then that the key may generate images |
| Text works but images do not | Usually verification, sometimes image permissions | Check verification status, then the key's permissions |
| `credit_balance_exhausted` | No prepaid credit remains | Add credit, step 2 |
| `organization_spend_limit_exceeded` | The organization spend limit was reached | Raise or review the limit on the limits page |
| `project_spend_limit_exceeded` | That project's own limit was reached | Raise or review the project limit |
| `429 rate limit` | Too many requests in a short period | Wait a minute and retry. Nothing is broken |
| Claude will not read the file | Some setups block reading `.env` by default | If it asks for permission, allow it once for this folder |
| It says there is no key at all | The `.env` is in the wrong folder | It must sit in the folder Claude Code was opened in. Ask Claude *which folder are you in right now* |

A billing error and a rate limit can both arrive as a 429, so read the error code itself rather
than the number. Anything else, paste the error into Claude Code and ask it to fix the
connection. Debugging its own tools is part of the job description.

---

## The checklist

```
[ ] Account created at platform.openai.com
[ ] Verification started, or confirmed already done
[ ] $10 to $20 of credit loaded
[ ] Auto recharge is set the way I actually want it
[ ] Spend limit set (optional, sensible)
[ ] Secret key created and saved somewhere safe
[ ] .env created in the right folder, with the key in it
[ ] .env added to .gitignore, if the folder is a git repo
[ ] A test image actually generated
```

When that last box is ticked, this is done and you never think about it again.

---

## Inside the bootcamp

Two extra things exist only in here, and they are how the factory proves the machine works.

`/machines-check` confirms the key is present without ever printing it back to you. It reports
only that it is there, how many characters it is, and its last four. That is deliberate: Day 1
is a lesson you may well be screen recording yourself, and a key on screen is a key in the world.

**First Candy** closes Day 1: a deliberately tiny print that costs a few cents and exists for
one reason, to prove on Day 1 that your key can actually generate an image. If First Candy
prints, your setup is real. If it errors, you found out on the cheapest possible day, and the
table above tells you which step to go back to.

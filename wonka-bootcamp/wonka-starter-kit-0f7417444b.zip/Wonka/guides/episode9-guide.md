# Day 9: The Variations Room

**If your product is a single SKU, today is optional.**

Watch it for the knowledge, because you will have a variant product eventually and this is a good
thing to know exists. Or take the day back. **Tomorrow is the last day and it is the one everybody
runs.**

If you DO have variants, this is probably the highest-leverage day in the bootcamp.

**The sentence for the day: eight variants used to be eight jobs. Today it is a plan, a pilot, and a
button.**

## What you will have by the end of today

- Your **confirmed child list**, derived from real evidence and read back to you before it was used
- The **frame table** (what each frame of your tested set actually carries, and what gets REUSED)
  and the **truth table** (each child's real printed facts, from its own listing)
- A decision on **which of the two variation types** you want, with your reason recorded
- **One pilot child, the hardest one, done properly**, and every failed phrasing recorded with what
  was tried
- The **whole family** propagated on the instructions that worked, unchanged, with untouched frames
  reused rather than regenerated
- **Drift sheets read and every hero frame opened by eye**
- Swatches judged at real picker size rather than at full size

**Time needed:** 45 to 75 minutes, most of it on the tables and the pilot.

## What you will need at hand

- Your real variant list: the ASINs, or a folder of real colour references and swatch photos
- Your tested set from Day 8, untouched
- Your OpenAI key alive (Day 1's `/machines-check`). Today's edits run on it, for cents

---

## Lesson 1: Eight variants used to be eight jobs

Slides. No terminal, no Wonka.

### What this used to cost

Eight colours. Seven images each. **Fifty-six images.**

Until very recently that meant either fifty-six pieces of design work, or a photoshoot where somebody
physically swapped a product eight times under the same lights and hoped nothing moved.

Which is why most listings you have ever seen have **one beautiful main SKU and seven neglected
siblings** with two images each. Not because those sellers did not care. Because the arithmetic was
brutal.

### The idea that kills the cost

**Most of your variant family already exists.**

You spent eight days building a tested set. Your blue version differs from it in a way you can name
in one line: a colour, a shape, a printed number. Everything else is finished work.

So nothing gets rebuilt. Wonka classifies your set frame by frame:

- Frames that carry the **SHAPE** of the thing that varies
- Frames that print a **VALUE**: a count, a size, a fit claim
- Frames that carry **nothing variant-specific**, and those are **REUSED**. Copied into every
  child's set untouched, because nothing in them changed

The frames that do change get edited in **two separate layers, never one prompt**: the shape is one
edit against a reference image, the printed text is another. A frame that needs both gets them
chained. Ask for both in one breath and both drift.

Each edit costs cents on your OpenAI key. Not credits. Cents.

### The two types, which is today's real decision

Decide this before anything runs. Deciding afterwards means doing the family twice.

**TYPE A: identical, except the variant.**

Same photograph. Same pose, same room, same light, same layout. **Only the thing that varies,
varies.** With the edit method that is literally true: the pixels that did not change are the same
pixels. Runs as cheap edits on your OpenAI key.

**TYPE B: regenerated on the same brief.**

Same brief, same message and same job, but generated fresh on Genrupt. The model may be a different
person, the styling may shift, the composition may move.

| | Gives you | Costs you |
|---|---|---|
| **Type A** | A family that reads as one product in several colours. Obviously related | Can feel repetitive across a lot of variants |
| **Type B** | Variety. The gallery feels alive | Can start to feel like different products wearing the same brand |

**Neither is right in general**, and that is why you are asked. Apparel and colourways usually want
A. A range where each variant has its own personality often wants B.

You know your category. Decide, and know why you decided.

### Same brief. But not same claims

**A variation is the same brief.** Same message, same job. If a variant needs a different brief, it
is not a variant. **It is a different product**, and it goes back through the pipeline.

But **the printed facts MAY differ per child, and they usually do.** The small size fits a smaller
basket; the eight pack prints a different count. Those facts come from each child's OWN listing,
never carried across. A family that swaps the shape and keeps the old size claim ships a lie,
beautifully. The truth table catches this before anything runs.

### The pilot rule

**You do one first.** One child, properly, looked at honestly, fixed until it is right.

Not because the machine is unreliable. Because **a family generated in one go on an untested
instruction is a family regenerated in one go.**

---

## Lesson 2: The plan and the pilot

### Two ways to tell him what the family is

**Give him the ASINs.** He reads each variant's listing and works out what actually differs. On a
live family the listing's own variation picker names every child. One warning: **the picker labels
lie.** Amazon's colour axis has been seen carrying the SHAPE. He reads the values, not the labels.

**Or give him a folder.** Your real colour references, swatch photos, label variants, dropped into
the reference folder. Slower to prepare, more accurate, and the right choice when you have the
material.

**Either way, he reads the differences BACK to you before accepting them.** A misread attribute
propagates into every single child. Ten seconds of listening against a family you would otherwise
redo.

### The two tables, which are the plan

**The frame table.** Wonka opens every frame of your tested set and classifies it: shape, printed
value, or nothing variant-specific (REUSED). While he is in there **he counts the products in every
frame**, because a four-panel grid holds four product instances and that number goes in the prompt
later. Then he says the arithmetic out loud: this child touches three frames, that one touches six,
the whole family is this many edits at cents each.

**The truth table.** Per child, from that child's OWN listing: shape, count, size label, every
printed claim. Never carried across from the source.

**Read both tables and correct them.** These sixty seconds are the plan.

### Pick your type, out loud, with a reason

The reason goes in the file. Six months from now, that line is the only thing that explains why the
family looks the way it does.

### One variant. The hardest one. Then look at it properly

He picks **the hardest child, not the easiest**, usually the one that changes shape. A pilot that
proves nothing hard proves nothing.

Four checks, in this order:

**Is the varying attribute actually right?** If you asked for round and got rounded-square,
everything downstream is rounded-square.

**Is every printed value THIS child's value?** Against the truth table, not against memory.

**Is it the ONLY thing that changed?** Same layout, same light, same food. The Type A check, and the
one that fails quietly.

**Is the product still itself?** Same proportions, same materials, every part present.

### When it is wrong, fix the INSTRUCTION

**Do not edit the pilot into shape.** An edited pilot cannot propagate.

**The thing that is wrong is the instruction.** He changes it and regenerates. The failures have
shapes, and the shapes repeat:

- **The main image that refuses to change.** Every lifestyle frame converts and the hero keeps its
  old shape, because the hero's label card dominates the frame. The fix is wording: name what it IS
  before what it becomes. "The hero is a stack of SQUARE plates. Redraw it as perfectly circular."
- **The group photo where only one of them changed.** "Replace every plate" reads as satisfied after
  one. The fix is counting: "this is a FOUR-PANEL grid, redraw ALL FOUR." This is why the frame
  table counted.
- **The label that melted.** Ask for a new product shape and the model reshapes the label card to
  match. The instruction declares the card a RIGID OBJECT: same shape, same size, same position,
  only the product behind it changes.

**Try two or three genuinely DIFFERENT phrasings rather than five nudges of the same one.** Prompt
failures are structural, so three different attempts find the structure faster.

**If three different phrasings all fail the same way, stop.** The problem is upstream: a missing
shape reference, a reference that does not show the part that varies, or a variant that is genuinely
a different product.

---

## Lesson 3: The button

### The rest of the family

Everything that made this work happened in the last lesson: the right child list, the right tables,
and instructions already proven on one child.

**This step is arithmetic**, and he says the arithmetic before he runs it. The instructions do not
change. The exact ones that landed, unchanged, which is the whole reason the family will be
consistent. And the frames that carried nothing variant-specific were not generated at all. They
were copied.

### The machine shows its work, and you still look

**He measures what moved.** Every generated frame gets compared against its source, tile by tile,
and you get a contact sheet: original, new frame, and a heat map of what changed.

Read it like this: **drift where the edit lives is the job. Drift anywhere else is a defect.** A
text edit should light up the text band and nothing else. A shape swap lights up the product, and
that is expected; the sheet shows you WHERE.

Then the check no number replaces: **open every hero frame at full size.** The heat map cannot see
that the label card became an egg. Three things per hero: the card kept its shape, the product has
the right silhouette, every word is this child's truth.

He also **counts every child's folder against the plan**, because one frame can quietly die in the
middle of a batch of successes.

### The swatch is its own job

Every child needs its swatch: the little image in the variation picker.

**A swatch is not a small version of the main image.** It is read at about the size of a fingernail,
next to five others, by somebody deciding which one they want.

**Judge your swatches at picker size.** Not at full size, where they all look lovely.

### Check the family as a family

**Is the varying attribute right on every child?** Not just the ones you looked at.

**Did anything else drift?** Eleven identical photographs and one where the light is different is far
more noticeable than eleven that were never meant to match.

**Are they distinguishable at picker size?**

**A single child that failed goes back on its own, on its fixed prompt. Never re-run the family to
fix one.**

### And before anything goes near Amazon

The edit drafts are review size. **Before upload, the family gets upscaled past Amazon's zoom
threshold, including the reused frames.** Wonka does that after the Inspection Room signs the
family, not before. Nothing ships at draft resolution.

---

## MISSION 1: Define the family

```
/variations
```

Give him your ASINs or point him at your folder. Then **listen to the read-back** of what differs,
and correct it if it is wrong.

## MISSION 2: Read the two tables

He will show you the frame table and the truth table. **Correct them.** A wrong row propagates into
every child.

## MISSION 3: Choose your type

```
Type [A/B]. [Your reason.]
```

## MISSION 4: The pilot

```
Do just one first. The hardest one.
```

Run the four checks. When it is wrong:

```
[The defect, in nouns.] Change the instruction and try again.
```

Two or three different phrasings, not five nudges. Then stop and look upstream.

## MISSION 5: The button

```
That is right. Do the rest.
```

Then read the drift sheets, open every hero at full size, judge your swatches at real picker size,
and check the family as a family.

**Share it:** send Jay your family as one grid, one drift sheet, and the phrasing that finally
cracked your hero frame, because everybody's will be different and the shapes are genuinely
interesting.

---

## MISSION 6: Gate it, like everything else

The family is not finished because it looks finished. Nothing leaves this factory ungated, and
variation imagery is no exception:

```
/inspect scoped to the variations
```

He opens every child and every swatch, runs the squint test on them, checks each frame against that
child's truth-table row (not a neighbour's), and checks the family reads as one product rather than
five photoshoots. Fix what he flags, then re-inspect.

**This is a hard gate, not a formality.** The Shipping Room extends your upload pack only with
gate-passed variation files, and the upscale to shipping resolution runs only after the gate. An
uninspected family simply does not reach `final/`.

- The child list came from real evidence and you heard it read back
- The frame table and the truth table were read and corrected
- Type A or B chosen deliberately, with the reason in the file
- **One pilot done first, the hardest child**, with every failed phrasing recorded
- The family ran on the exact instructions that worked, unchanged; untouched frames were reused
- Drift sheets read, every hero opened at full size, every folder counted
- Swatches judged at picker size, beside each other
- The family checked as a family, not just child by child

## Common mistakes

- **Generating the whole family first.** An untested instruction across eleven children is eleven
  children regenerated.
- **Regenerating frames that carry nothing variant-specific.** They are reused. That is the whole
  economics of the day.
- **Editing the pilot into shape.** An edited pilot cannot propagate.
- **Describing only the target shape to the hero.** Name its CURRENT shape first, then order the
  redraw.
- **"Every plate" in a group frame.** Count them. ALL FOUR.
- **Letting the label card follow the new shape.** The card is a RIGID OBJECT and the instruction
  says so.
- **Carrying the source's claims into a child.** Each child's printed facts come from its own
  listing. That is the truth table.
- **Five nudges of one phrasing.** Try three different ones, then look upstream.
- **Trusting the drift numbers alone.** They are blind to a melted label. Open every hero.
- **Judging swatches at full size.** They all look lovely there. Nobody sees them there.
- **Re-running the family to fix one child.** Re-run the child on its fixed prompt.
- **Uploading draft-resolution files.** Upscale past the zoom threshold after the gate, reused
  frames included.

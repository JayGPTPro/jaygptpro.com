# Day 6: The Secondary Images Room

Your main image wins the click. Today you build everything that wins the sale afterwards.

This is the best-looking day of the bootcamp, and it is the payoff of a promise your brief made on Day 3.
In the smoke test you were told three times not to judge the fonts, the colors or the composition.
Today you get ten complete versions of your entire gallery and you choose.

**The sentence for the day: every frame answers a need, and it should land even with the sound off.**

## What you will have by the end of today

- **Ten complete style directions** across your whole gallery, and one of them chosen
- That style **sent to Refine**, so everything you generate afterwards carries it
- Multiple Refine rounds, because the first blast finds the direction and Refine finds the frames
- **Your finished gallery on disk**, one frame per slot, every slot marked complete
- A set-level scorecard, and your coverage map closed against what actually exists

**Time needed:** 75 to 100 minutes, most of it choosing rather than waiting.

## What you will need at hand

- Your brief's slot list, open on a second screen. You will read the rows against it
- Your main candidates from Day 5, untouched
- Genrupt open. **Two of today's four lessons happen there**
- Your Theme Blast either finished or ready to launch. If nobody started one for you, Lesson 2
  starts it with `/secondary-images` and that is the ordinary path, not a fallback

---

## Lesson 1: What a gallery image is for

Slides. No terminal, no Wonka. The counterpart to Day 5's main-image doctrine.

### Every frame answers a NEED

The hero earns the click. Everything after it answers the questions standing between someone
interested and someone buying.

So every frame gets ONE need. Not one feature, one **need**.

"Stainless steel base" is a feature. "Is this going to look cheap on my table" is a need, and they
are answered by very different pictures.

**If you cannot say out loud what worry a frame removes, that frame is decoration**, and you only
have six or seven of them.

### The test: cover the text

Here is the check that most gallery images fail.

**Cover the text. Does the image still say the thing?**

Take the words away from a typical listing image and you are left with a product on a background that
could be arguing anything at all. The words were doing all the work, and the words are the part
nobody reads.

Because here is what actually happens: they are scrolling on a phone, at speed, with one thumb. The
picture lands in about half a second. The text lands only if the picture already earned it.

**Build the picture to carry the message and let the text confirm it.** Not the reverse.

### Big text, few words, mobile first. And the switch behind it

This is the most opinionated default in the whole factory, and it is a default rather than a law.

One headline you can read at thumbnail size beats four labels nobody can. And every extra element on
a frame makes every other element smaller, so **you win legibility by SUBTRACTION** rather than by
asking for bigger fonts.

Your machine ships with this baked in. There is a **mobile-friendly setting and it is ON**, and it is
what produces the restrained, readable frames you are about to see.

**And you can turn it off.** If you are in a category where buyers genuinely read dense,
comparison-style images, and some categories are exactly like that, tell Wonka to turn off mobile
friendly and you will get more text and more density.

Most products should keep it on. But it is your listing, and it is better to disagree on purpose than
to follow by accident.

### Volume, again

Same arithmetic as Day 5, because it does not stop being true: the best of many beats the best of
few. Today you are not making seven images, you are making seventy or more and then choosing.

What changes is what the volume is FOR. On the hero, a hundred drafts explored one frame deeply.
**Today the volume goes sideways first:** ten complete versions of your entire gallery, so you are
choosing a direction rather than a picture.

### Where the day is going

1. **The blast lands.** Ten rows, each one a different style applied across every frame you planned
2. **You choose a style and a composition, and send it to Refine.** From that moment every new image
   carries your look, and you generate more inside it. More than once, usually. **This is where a
   gallery actually gets good**
3. **The loop you already know**, plus what changes when you judge a set instead of an image
4. Pointed fixes through the OpenAI API for cents, exactly like on Day 5

Direction, then frames, then judgment, then repair.

---

## Lesson 2: Ten galleries

### Where it lives

If your blast was launched after Day 5's session, it ran while you were away and nothing is
generating while you watch. Ask:

```
Did the theme blast finish?
```

Wonka confirms it, reports how many rows and how many frames in total, and names the settings it ran
with.

**If he says nothing was ever launched, that is the normal answer for anyone working at their own
pace.** The Theme Blast is the Secondary Images Room's opening move, so start it now:

```
/secondary-images
```

He reads your slot briefs, your coverage map and your restated avoid list first, states the cost
against your live balance, and runs ten style directions across every slot you planned. It takes a
while, so start it and go do something else; the rest of this day is choosing, not waiting.

Then back to Genrupt, for the same reason as on Day 5: seventy images need a grid, not a chat window.

### Read ACROSS, not down

This is the thing to understand about what you are looking at.

**Every ROW is one style, applied to your whole gallery.** Row one is your gallery in one look. Row
two is the same gallery in a completely different look.

So the unit of choice here is a row, not a picture.

### Two passes, and Compare

**First pass, fast, horizontal.** One question per row: would I believe this brand? Not do I like it.
Would I believe it. Kill three or four rows in ninety seconds.

**Second pass, slow, with your brief open.** Does this look SERVE the jobs you wrote? A soft editorial
pastel look can be genuinely beautiful and completely wrong for a product whose main job is proving
it holds four pounds of chocolate.

**Compare** works on rows exactly as it did on hero candidates. Side by side, the difference you could
not name gets a name, and once it has a name you can check it against the brief instead of against
your mood.

### Do not shop across rows

You will want the third frame from row two and the fifth from row seven, because each is the prettiest
in its column. **Do not.**

**A row is a look. Frames from four rows is four looks.** Your shopper will not think "ah, mixed
themes". They will feel something is slightly off and never be able to say what. It is exactly the
storefront problem a brand kit exists to prevent, if you have one.

**The coherent row you like second best beats a shopping trip through your favourites.** And you are
not stuck with the row as it stands anyway, which is the whole next lesson.

---

## Lesson 3: Restyle, refine, and refine again

### Two choices, not one

**The style** is the look: palette, typography, finish.

**The composition** is how a frame is built: where the product sits, how much air there is, whether
text is over the image or beside it.

You can love a style and want a different composition. **This is the moment to say so** rather than to
compromise silently.

### Send it to Refine

**Restyle and Send to Refine** is the action that changes everything downstream.

From that moment, **every new image carries that look.** Not as a suggestion in a text field. As the
machine's new starting point. Ask Wonka to confirm it took rather than assuming.

You can see it rather than take it on trust: put a fresh Refine output beside a frame from a row you
rejected. Same slot, same brief, same product. The only difference is that the style is now locked.

### Then generate more. This is the part people skip

Now that the look is locked, **generate MORE inside Refine. And then more again.**

Every round is cheap, and every round raises your ceiling, because you are no longer exploring
directions. **You settled the big question, so all the variation is now happening inside an answer you
already like.**

**How many rounds?** Until a round stops giving you anything better than what you already have. Not a
fixed number. Some slots settle in one, a stubborn one takes three.

This is where seventy becomes a hundred and forty, and the top of that is genuinely good rather than
merely the least bad of what showed up first.

### Pick the top of the top

One frame per slot. **One, not five.** There is nothing to A/B test in a gallery slot, so unlike the
hero you are looking for the single best rather than a shortlist.

Same method: fast elimination, slow pass against each slot's JOB from the brief, Compare when stuck,
and look at everything small because that is how it gets seen.

### Bring the gallery home

```
Selected. Bring the whole set in.
```

Wonka reads the selection rather than making you type it, downloads every chosen frame, and marks
each slot complete.

**That download is not bookkeeping.** Tomorrow's A+ reads that folder. The inspection reads that
folder. The tasting room on Day 8 reads that folder. A gallery living only inside Genrupt is a
tomorrow that opens on an empty directory.

---

## Lesson 4: Judging a team, and repairing it

You already know inspection from Day 5: describe first, score, squint at thumbnail size, flag
compliance. **None of that changes and it is not repeated here.**

What changes is that **a gallery is a TEAM. And a team can be made entirely of good players and still
be a bad team.**

### Three faults you cannot see one image at a time

**Two frames saying the same thing.** Each one is fine. Together they are a wasted slot out of seven.
The comparison is on MEANING, not wording: "a little goes a long way" and "one drop is enough" are the
same message in different clothes.

**The same face in every people frame.** Nothing screams AI louder. The system varies appearance
within your cast automatically, but automatic is not a guarantee, so this gets checked mechanically
rather than trusted. The repair is upstream, in the cast: a second avatar with an explicit age and
gender, then that one slot re-runs. Never an edit. And if a face reads as AI rather than as a
person, `/fix-faces` is the walk-in clinic for exactly that, on any image, factory or not.

**No emotional frame anywhere.** Seven specs in a row is a data sheet. One frame has to sell the
feeling rather than the feature, or the whole gallery reads as a manual.

And the test from this morning, applied properly: **cover the text on each one.** Does it still say
the thing? That catches a frame where the words were doing all the work.

### The coverage map, closing

On Day 3 you listed everything that had to be shown, and every item got either an image or a
written reason it was dropped. Now you check it against what actually exists.

This is the check nobody does, and it is why most galleries are missing a table stake nobody noticed.
It goes unnoticed because there is nothing to notice: **an absence is invisible unless you wrote down
what should have been there.**

### Repair, and one new routing rule

Same routing as Day 5 for blemishes: take something away or swap a word is an edit for cents, make it
bigger or move it is a regenerate.

**One thing that IS new: a frame that is failing its job is not a fix, it is a Refine round.** If the
picture is wrong rather than blemished, go back into Refine and generate more of that slot inside the
look you already chose. It is cheap and it is the right instrument. **Editing a frame whose whole idea
is off just gets you a tidier version of the wrong idea.**

### Then stop

This set is not going to be perfect and it is not supposed to be. Next week a panel of
demographic-matched AI tasters reacts to it in plain words, and it will tell you things no scorecard
can.

Polishing a frame for another hour before it has met a single buyer is the most expensive kind of
comfortable.

---

## MISSION 1: The doctrine, on your own product

Before you look at a single image, write down for each of your slots the ONE need it removes. If you
cannot, that slot is decoration and it needs a different job.

Then open your CURRENT listing images and cover the text on each. Do they still say the thing?

## MISSION 2: Read the rows

```
Did the theme blast finish?
```

In Genrupt: first pass fast and horizontal, kill three or four rows. Second pass with your brief open.
Compare when two survive and you cannot separate them.

## MISSION 3: Restyle and refine

Choose your style AND your composition, then Restyle and Send to Refine. Confirm it took.

Then generate more inside Refine. **More than one round.** Stop when a round stops improving things,
not at a number.

Pick one frame per slot, then:

```
Selected. Bring the whole set in.
```

## MISSION 4: Judge the set

```
/inspect the set
```

Check the three set-level faults yourself as well: repeated messages, repeated faces, and whether
there is one emotional frame anywhere.

```
/fix
```

And before you fix anything, ask whether it is a blemish or a wrong idea. Wrong ideas go back to
Refine.

**Share it:** send Jay your chosen row, and the one you nearly chose instead. The near-misses are
where the interesting arguments are.

---

## What good looks like

- Every slot has a NEED written next to it, not a feature
- You read the blast in rows, not columns, and you did not shop across rows
- Style and composition were two separate decisions
- Refine ran more than one round, and stopped for a reason rather than at a number
- One frame per slot on disk, every slot marked complete
- The set-level faults were checked: no repeated messages, no repeated faces, one emotional frame
- Your coverage map is closed against what actually exists

## Common mistakes

- **Cherry-picking across rows.** Four looks reads as four people. Nobody can say what is wrong, but
  they feel it.
- **Stopping after one Refine round.** This is where most of the quality is left on the table.
- **Fixing a frame whose idea is wrong.** That is a Refine round. A fix gets you a tidier bad idea.
- **Judging fonts you have not chosen yet.** Style is lesson 3. Do not pre-judge it in lesson 2.
- **Leaving your gallery in Genrupt.** Tomorrow reads the local folder.
- **Polishing past the point of usefulness.** The tasters race on Day 8. Let them tell you.

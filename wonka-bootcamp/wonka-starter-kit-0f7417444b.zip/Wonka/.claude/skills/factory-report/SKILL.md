---
name: factory-report
description: The Factory status report. Scans every product's station tracker and its artifacts on disk, reports where each product stands, what is blocked and on whom, and the ONE next action per product, plus the experiments check, a factory-wide summary and a single priority for the week. Read-only, free, and safe to run at any moment. Written so it can also run as a recurring scheduled task. Use for any status question. Triggers: /factory-report, "status", "where are we", "walk the floor", "factory report", "what's on the line", "what should I do this week", "weekly report".
---

# The Factory Floor

| Meta | Value |
|------|-------|
| Room | The Factory Floor |
| Station | All stations (read-only overview) |
| Taught on | Day 10, as the weekly habit. Runs on any day, at any hour, even Day 1's empty floor |
| Needs | `factory/Products/*/status.md` plus each product's artifact folders; `factory/Improvement Log.md`. On an empty floor also `factory/Factory Log/machines-log.md` and `output/first-candy.png` |
| Saves to | factory/Factory Log/[YYYY-MM-DD]-report.md |
| Typical cost | Free. Read-only; this room touches nothing on the line. |

## What this room does

The owner walks the floor. This skill reads the actual state of the Factory from disk every single time, never from memory of an earlier session, because the floor changes while nobody is watching. It reports each product's station, its finished artifacts by name, its blockers and who owns each one, and the single next action that moves it forward. It ends with a factory-wide view and one concrete priority for the week.

Everything here is evidence. A station is where its FILES say it is, not where a tracker claims it is, and never where a previous conversation remembers it being.

## Before you start

- **Get today's real date from the system** (run `date`). The report filename and every age figure depend on it. Never write a date from memory. If the shell is unavailable, ask the user for today's date in one line; if they cannot give one, save the report as `factory/Factory Log/undated-report.md` and say plainly at the top that it carries no date. Never invent one.
- **This room is read-only.** It never edits a `status.md`, never generates, never fixes, never finalizes an experiment row. If the scan reveals a wrong status, REPORT the mismatch. Do not silently correct it.
- **Disk is the truth.** A file on disk outranks any claim in a tracker, and a tracker claim with no file behind it is a mismatch to report, not a fact to repeat.
- **Two template traps, and both will fool a careless scan:**
  1. **Folder READMEs are not artifacts.** Every product folder is copied from `TEMPLATE/`, so `research/README.md`, `images/README.md` and the rest exist from the first minute. When counting artifacts, ignore `README.md`, dotfiles (`.DS_Store`, `.gitkeep`), zero-byte files, and any filename still carrying a placeholder (`[product]`, `[YYYY-MM-DD]`). Count what remains, and name it.
  2. **Example rows are not results.** `factory/Improvement Log.md` ships with example rows in every part, and those examples use the bootcamp demo product's own name. A row counts as real only if its Date is a real date (not `[YYYY-MM-DD]`) and it does not sit under an "Example row" line. Never count an example as an experiment or as a pattern.
- **The report always ships.** Missing inputs never stop this room: a product with no tracker, an Improvement Log that was never created, a log with no dates, a user who answers "I don't have that" about a blocker. Each unknown is recorded as an unknown, in the Gaps line, with what it would take to close it. A gap named in the report is honest; a gap papered over with a guess is a lie in a file the owner trusts.
- **If the user asks about ONE product** ("where is the fountain?"), still scan the whole floor (it is free), lead with that product's full card, give the others one line each, and save the full-floor report as usual. A partial scan must never be saved as the floor report.

## The empty floor

A Factory with no products yet is not an error and not a short answer. Report it properly, because it is the owner's first look at their own factory:

- State the floor is empty: `factory/Products/` holds only `TEMPLATE/`, zero products on the line.
- Report the setup evidence that DOES exist, from disk: the newest line in `factory/Factory Log/machines-log.md` (which machines passed, the credit reading) and whether `output/first-candy.png` exists. If neither exists, say so and make `/machines-check` the next action.

**The machines line is reported on EVERY floor, not just an empty one.** Read the newest line of `factory/Factory Log/machines-log.md` and give one factory-wide line: `Machines: [that line], checked [N] days ago`. If it is more than about a week old, or it recorded a FAIL, a MISSING key or a zero balance, and this week's priority involves a generation batch or a Tasting Round, put `run /machines-check first` at the front of the Next action. No new checks run here; this room stays read-only and free. A week's plan that opens with a batch on a dead machine is the cheapest avoidable loss in the factory.
- Give exactly one next action: the Front Gate, `/meet-my-product`, with an ASIN or URL and the ZIP of materials it will ask for.
- Save the report like any other. An empty floor on record is how the owner sees the line fill up later.

## Process

1. **Date and floor list.** Get today's date. List `factory/Products/`, excluding `TEMPLATE/`. State the count out loud in the report, and scan every one of them. The number of product cards in the report must equal that count; a skipped product is a broken report.

2. **Scan each product against disk.** For each folder:
   - Read `status.md`: the identity table, the stations table (RESEARCH / BRIEF / INVENT / INSPECT / PROVE), the INVENT sub-status block, `## Owner intel`, `## Blocked on`, `## Research gaps` (waivers and "I don't have that" answers recorded at the Front Gate), and the `## Log`.
   - List the real files in `research/`, `brief/`, `2-reference/`, `images/`, `edits/`, `aplus/`, `variations/`, `scorecards/`, `tests/`, `final/`, applying the artifact rule above.
   - Note the newest dated Log line, which is what age figures are computed from.
   - **No `status.md`, or one that does not match the TEMPLATE format?** Do not skip the product and do not stop. Rebuild its station picture from disk alone, report it with `tracker missing or unreadable` as its first mismatch, and make the next action rebuilding the tracker in the room that owns the furthest completed station.

3. **Place each product on the station ladder.** The current station is the first one that is not `done`. A station is `done` only on this evidence:

   | Station | `done` requires |
   |---|---|
   | RESEARCH | all five written files present: `research/insights.md`, `reviews.md`, `persona.md`, `competitors.md`, `selling-points.md`, plus `research/product-report.md` on top |
   | BRIEF | `brief/creative-brief.md` present |
   | INVENT | `2-reference/reference-sheet.md` present, plus all four INVENT sub-parts resolved (see below) |
   | INSPECT | a scorecard in `scorecards/` that covers every image currently in `images/`, `aplus/` and `variations/`, **AND no FAIL left standing in it**. Open the newest scorecard; a FAIL with no later `edits/vN/` file and no later scorecard clearing it is UNRESOLVED. Images newer than the newest scorecard means `in progress`, and say how many are uninspected. Coverage is not the same as passing: a product that ran `/inspect`, saw FAILs and carried on is `in progress` with the line "covered, [N] FAILs unresolved", never done |
   | PROVE | `tests/upload-pack.md` present, or the tracker records the cycle closed by `/improvement-loop` with its Improvement Log entry as the artifact (report that as "tested, no upload pack yet"). Tasting round folders alone are `in progress`, and say how many races have landed |

   **INVENT sub-status, four lines, reported for any product at or past INVENT:** Main image (`/main-image`), Secondary images (`/secondary-images`), A+ (`/aplus`), Variations (`/variations`). Images alone is `in progress`, never `done`. A sub-part resolves as `done` (artifacts on disk), `n/a` with a written reason (a conscious skip, e.g. `Variations: n/a, single SKU`), or the lawful trailing marker `Variations: pending (Day 9)`. With that trailing marker, report the product at its TRUE furthest station (INSPECT or PROVE) and add one line noting variations are still owed. It is a marker, not a blocker.

   Also read `2-reference/reference-sheet.md` for `Reference status: LOCKED` and `Smoke test: PASS`. Generated images sitting beside an unlocked reference or a missing smoke test is an integrity flag worth one line in Mismatches. Report it; the Reference Room fixes it.

4. **Resolve every status-versus-disk disagreement in the open.** Never adjust a file, always report the pair:

   | What you find | What the report says |
   |---|---|
   | Tracker says `done`, artifact missing | Report the product at the LOWER station. Mismatch: "status says [station] done, no artifact on disk" |
   | Artifact present, tracker says `pending` | Report the product at the TRUE (higher) station. Mismatch: "artifacts exist, tracker not updated by [room]" |
   | Tracker says `blocked`, the blocking input has since arrived | Report as unblocked-on-disk. Mismatch, and the next action is the room that was waiting |
   | Tracker missing entirely | Station picture rebuilt from disk, flagged as reconstructed |

5. **Name every blocker and its owner.** Each blocked item is on exactly one of two people:
   - **On the user:** missing reviews file, missing competitor links or gallery screenshots, missing product photos, a fix direction not yet chosen, a cost go-ahead pending, an A/B not launched.
   - **On Wonka:** an artifact promised and not produced, a fix batch not run, a scorecard not written.

   Say it plainly, with its age: "waiting on YOU for the product photos, 6 days" or "waiting on ME: the scorecard, I owe it this session." **Age comes from dated evidence only.** Use the newest dated Log line or a date on the blocker itself. If nothing in the file carries a date, write `age unknown, no dated log entry` and never estimate a number. Recorded research gaps and waivers get one line each, because a gap the owner accepted at the Front Gate still shapes what the images can claim.

6. **Pick THE ONE next action per product.** Exactly one, concrete, and runnable: the command that does it (`Run /inspect on the 8 new images`) or the exact thing to hand over (`Drop the top 10 positive and 10 critical reviews into research/, then /meet-my-product continues`). It must be the FIRST thing that unblocks the product, not the most interesting thing on the list. A list of five next steps is a way of choosing none.

7. **Check the experiments, and be honest about absence.** Read `factory/Improvement Log.md`, counting real rows only:
   - Every row with Status `running` gets a line with its type, its start date and when a verdict is due.
   - **Overdue:** a `running` row of Type `amazon-ab` whose Date is more than 10 weeks old gets a nudge: check Manage Your Experiments, bring the verdict back, and run `/improvement-loop` to close it.
   - **Anomaly:** a `running` row of Type `tasting-room` is a row somebody forgot to finalize, because the panel returns its verdict in the same sitting. Flag it, and the fix is `/improvement-loop`.
   - `planned` rows are reported as planned, never as running.
   - **A product at PROVE with no `amazon-ab` row gets a stated reason, not silence.** Read `tests/upload-pack.md` for what it records: not requested, pending launch, launched, or not applicable because the listing belongs to someone else. On the bootcamp demo product the honest line is that this listing is not the owner's, so there was never anything to launch. Never log a test nobody ran and never imply one is running.

8. **Build the factory-wide summary:** products in flight (count and names, matching step 1), experiments running, Improvement Log size (real pattern rows, how many at USE strength, and the owner-preference count), and every product idle more than 7 days by its newest dated log line.

9. **Write one priority for the week.** ONE, chosen in this order: the product closest to a finished upload pack, then the longest-stuck product, then the one whose blocker sits with the owner (only they can move it). One short paragraph: what, why it is first, and the first command to run. Never a list.

10. **Save the report, then prove it saved.** Write `factory/Factory Log/[YYYY-MM-DD]-report.md`. If a file already exists for today, write `[YYYY-MM-DD]-report-2.md` (then `-3`); never overwrite an earlier walk. Confirm the file exists on disk after writing and state its path in the reply. A report that was spoken and not saved does not count as done.

11. **Deliver the five-line summary**, then stop. When this runs as a scheduled task with the owner away, the saved file IS the deliverable and the summary is all that is spoken.

12. **Offer the recurring run once.** If the user ran this by hand and no weekly schedule exists yet, offer ONCE: a scheduled task on this folder if their setup supports one, otherwise a recurring reminder plus this one command. Say the honest version out loud: this is a habit with a reminder attached, and it does not run while the machine is off. Never promise a service, and never name a day of the week or a date. The owner picks the day.

## The five-line spoken summary

Five lines, in this order, whatever the floor looks like:

1. Products on the line and where each one stands.
2. What is blocked, on whom, and for how long.
3. Experiments: running, overdue, or honestly none, with the reason.
4. The one priority, in one sentence.
5. Where the report is saved.

## Output format

`factory/Factory Log/[YYYY-MM-DD]-report.md`:

```markdown
# Factory Report . [YYYY-MM-DD]

Products scanned: [n] (TEMPLATE excluded)

## Products on the line

### [Product Name] . station: [INSPECT]
- Done: RESEARCH (research/: insights.md, reviews.md, persona.md, competitors.md, selling-points.md), BRIEF (brief/creative-brief.md), INVENT (2-reference/reference-sheet.md LOCKED + smoke test PASS; images/: 8 files, aplus/: 6 modules, variations/: 6 files or "n/a, single SKU")
- INVENT sub-status: Main image (/main-image) done, Secondary images (/secondary-images) done, A+ (/aplus) done, Variations (/variations) done | n/a, [reason] | pending (Day 9)
- In progress: INSPECT (3 of 8 images not covered by scorecards/scorecard-[scope]-[date].md)
- Blocked: [none / waiting on USER: pick the fix direction for the Round 1 winner, 3 days / waiting on WONKA: the scorecard, owed this session]
- Recorded gaps: [none / no Brand Registry demographics, waived at the Front Gate: persona age is estimated]
- Idle: [n] days since the last dated log entry [or: age unknown, no dated log entry]
- Mismatches: [none / status says INVENT pending, images/ holds 8 files / tracker missing, station rebuilt from disk]
- NEXT ACTION: [one line + the command]

[...repeat per product, one card each, none skipped...]

## Experiments
- [product]: [type] launched [date], verdict due ~[date]. [on track / OVERDUE by [n] weeks: fetch the verdict, then /improvement-loop]
- [product]: no amazon-ab row. [reason, e.g. "this listing is not yours, so there was nothing to launch"]
- [none at all: "No experiments on record. Nothing has been tested yet."]

## Factory-wide
- Products in flight: [n] ([names])
- Experiments running: [n]
- Improvement Log: [n] real patterns ([n] at USE strength), [n] owner preferences
- Idle over 7 days: [none / [product], [n] days]
- Gaps in this report: [none / Improvement Log.md still holds its example rows, not counted / [product] has no dated log, ages unknown]

## The priority
[ONE priority, one short paragraph: what, why it is first, and the first command to run.]
```

## Golden Standards check

Before presenting, verify:
- [ ] Today's date came from the system, and the report file carries it (or is honestly marked undated).
- [ ] Every product folder was scanned, TEMPLATE excluded, and the card count matches the stated scan count.
- [ ] Every `done` claim names a real artifact file verified on disk this session. No README, dotfile, zero-byte or placeholder-named file was counted as an artifact.
- [ ] Each station's `done` test from the ladder table was actually applied, including INSPECT coverage and PROVE requiring `upload-pack.md`.
- [ ] INVENT sub-status is reported for every product at or past INVENT, and `Variations: pending (Day 9)` was treated as a lawful marker, not a block.
- [ ] Every mismatch is reported with both sides, and nothing on disk was edited.
- [ ] Every blocker names its owner and an age backed by a dated entry, or says the age is unknown. No estimated days.
- [ ] Each product has exactly ONE next action, with the command or the exact handover.
- [ ] Experiments counted real rows only; overdue A/B rows are nudged, a `running` tasting row is flagged as unfinalized, and a missing A/B row is explained rather than left silent.
- [ ] The priority is a single priority, not a list.
- [ ] The report file exists in `factory/Factory Log/`, its path was stated, and no earlier report was overwritten.
- [ ] Nothing in the report is unverifiable: every gap is in the Gaps line instead of being filled with a guess.

## Wonka lines

Openers:
- "Walking the floor. Every belt, every kettle, every excuse."
- "Ah, inspection day for the Factory itself. Let us see who has been napping."
- "Status, you say. I read the shelves, not my memory. One moment."

Closers:
- "That is the floor walked. One priority this week; the rest is noise and nougat."
- "Two products humming, one waiting on you, and the book grows fatter. A decent week ahead."
- "The Factory never sleeps. It naps, occasionally. The fondue fountain has napped six days; wake it."

## Definition of Done

- `factory/Factory Log/[YYYY-MM-DD]-report.md` exists on disk, its path was stated, and it holds a card for every product scanned, the experiments check, the factory-wide summary with its Gaps line, and one priority.
- Every claim in it traces to a file read this session; every unknown is recorded as an unknown.
- The user, or the scheduled-run transcript, has the five-line summary and the single priority.

## Update status.md

This room does not edit product status files. It is read-only, and that is the point: a status report that quietly rewrites the thing it is reporting on cannot be trusted twice. If a mismatch was found, name the product whose `status.md` disagrees with its folder, say which way it disagrees, and offer to reconcile it in the room that owns that station on its next run.

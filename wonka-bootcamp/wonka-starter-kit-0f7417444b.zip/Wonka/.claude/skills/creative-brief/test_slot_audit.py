"""Regression tests for slot_audit.py.

The failure this guards: on 2 September 2026 a new S4 was inserted into a seven-slot brief.
The brief, its coverage map and selling-points.md were renumbered; brief_lint passed; and
brief/owner-review.md plus the brief's own Promise check still carried the old numbers
("S7 REWRITTEN ... Lifts apart", "The seven buyer questions"). Nothing mechanical saw it.

Every failing case here was watched to PASS against a checker that skipped the rule.
Run: python3 test_slot_audit.py
"""
import subprocess
import sys
import tempfile
from pathlib import Path

AUDIT = Path(__file__).parent / "slot_audit.py"
FAILURES = []


def run(brief, review=None, points=None):
    with tempfile.TemporaryDirectory() as d:
        root = Path(d)
        (root / "brief").mkdir(); (root / "research").mkdir()
        (root / "brief" / "creative-brief.md").write_text(brief, encoding="utf-8")
        if review is not None:
            (root / "brief" / "owner-review.md").write_text(review, encoding="utf-8")
        if points is not None:
            (root / "research" / "selling-points.md").write_text(points, encoding="utf-8")
        r = subprocess.run([sys.executable, str(AUDIT), str(root)], capture_output=True, text=True)
    errors = [ln.strip() for ln in r.stdout.splitlines() if "ERROR" in ln]
    return r.returncode, errors


def check(name, cond, detail=""):
    print(f"  {'PASS' if cond else 'FAIL'}  {name}" + ("" if cond else f"  {detail}"))
    if not cond:
        FAILURES.append(name)


def slot(sid, job, q, msg, people="no"):
    return (f"### S{sid} . {job}\n- Buyer question: \"{q}\"\n- Message: \"{msg}\" (source: reviews)\n"
            f"- In frame, the content brief: the product on a counter.\n- People: {people}\n\n")


def fb(sid, q, msg):
    return (f"- Slot for S{sid} (imageType from the returned plan):\n  - buyerQuestion: \"{q}\"\n"
            f"  - contentBrief: \"The product on a counter.\"\n  - headerPhrases: [\"{msg}\"]\n"
            f"  - customInstructions: none\n")


def brief(slots, cov, extra=""):
    """slots: list of (job, question, message, people). cov: list of (SP, point, mapped, reason)."""
    struct = "| Slot | Job | Message (max 6 words) | People |\n|---|---|---|---|\n| MAIN | product hero | briefed here | NO. Never. |\n"
    struct += "".join(f"| S{i} | {j} | \"{m}\" | {p} |\n" for i, (j, q, m, p) in enumerate(slots, 1))
    covt = "| ID | Selling point | Mapped to (MAIN criterion / S# / A+ / Variation) | Skipped because |\n|---|---|---|---|\n"
    covt += "".join(f"| {sp} | {pt} | {mp} | {rs} |\n" for sp, pt, mp, rs in cov)
    return ("# Creative Brief . Test Product\nOwner review: PENDING\n\n## Strategy summary\nProve it.\n\n"
            f"## Selling-points coverage map (full package)\n{covt}\n## Promise check\n{extra}\n"
            f"## Set structure\n{struct}\n## Main image\nProduct only.\n\n## Secondary slots\n"
            + "".join(slot(i, j, q, m, p) for i, (j, q, m, p) in enumerate(slots, 1))
            + "## Genrupt handoff\n\n### Funnel B blocks (saved OVER Genrupt's planned text, in priority order)\n- Slot 1 (MAIN): round-trip unchanged. Carries nothing.\n"
            + "".join(fb(i, q, m) for i, (j, q, m, p) in enumerate(slots, 1))
            + "- If the returned plan has fewer slots than jobs listed here: merge S3 into S2 first\n\n## Send log\n- not sent\n\n## Revisions\n- none\n")


def review(rows, promise=(), intro="All buyer questions, in gallery order"):
    t = f"# Owner review\n\n## 1. {intro}\n\n| Slot | The question this image answers |\n|---|---|\n"
    t += "".join(f"| S{i} | {q} |\n" for i, q in rows)
    if promise:
        t += "\n## 4. What the promise test rewrote\n\n| Slot | Before | After | Why |\n|---|---|---|---|\n"
        t += "".join(f"| S{i} | \"{b}\" | \"{a}\" | reason |\n" for i, b, a in promise)
    return t


def points(rows):
    t = "# research/selling-points.md\n\n| ID | Selling point | Source | Mapped to | Skipped because |\n|---|---|---|---|---|\n"
    return t + "".join(f"| {sp} | {pt} | reviews | {mp} | {rs} |\n" for sp, pt, mp, rs in rows)


THREE = [("Benefit hero", "What does it look like running?", "Anything dipped", "yes"),
         ("Scale", "How big is it?", "Four tiers, eighteen inches", "no"),
         ("Material proof", "What comes apart to wash?", "Lifts apart into washable parts", "no")]
COV3 = [("SP1", "four tiers", "S2", ""), ("SP2", "washable parts", "S3", ""), ("SP3", "120 volts", ".", "A+ owns it")]
REV3 = review([(1, THREE[0][1]), (2, THREE[1][1]), (3, THREE[2][1])], promise=[(3, "Easy to clean", THREE[2][2])])
PTS3 = points(COV3)

print("slot_audit regression")
code, errs = run(brief(THREE, COV3), REV3, PTS3)
check("a consistent three-slot product passes", code == 0 and not errs, f"{errs}")

# The real failure: a new S2 is inserted. Brief, coverage map and selling points are renumbered
# (old S2 -> S3, old S3 -> S4). The owner review is left as it was.
FOUR = [THREE[0], ("How-to", "Where does the chocolate go?", "Fill the base bowl", "no"), THREE[1], THREE[2]]
COV4 = [("SP1", "four tiers", "S3", ""), ("SP2", "washable parts", "S4", ""), ("SP3", "120 volts", ".", "A+ owns it"), ("SP4", "fill depth", "S2", "")]
PTS4 = points(COV4)
code, errs = run(brief(FOUR, COV4), REV3, PTS4)
blob = " ".join(errs)
check("an inserted S2 with a stale owner review fails", code == 1 and errs, "passed")
check("  ... names the missing row", "review-slot-missing" in blob and "S4" in blob, blob)
check("  ... names the drifted question", "review-question-drift" in blob, blob)
check("  ... names the misattributed promise row", "review-promise-drift" in blob or "misattributed-slot" in blob, blob)

# The brief's OWN promise check still says S3 for the message that now lives on S4
STALE_PROMISE = "- **S3 REWRITTEN.** Draft was \"Easy to clean in minutes\". Kept the job, dropped the promise, showed the\n  mechanism: \"Lifts apart into washable parts\".\n"
REV4 = review([(i, FOUR[i - 1][1]) for i in range(1, 5)], promise=[(4, "Easy to clean", FOUR[3][2])])
code, errs = run(brief(FOUR, COV4, extra=STALE_PROMISE), REV4, PTS4)
blob = " ".join(errs)
check("a wrapped promise-check bullet still naming the old slot fails", "misattributed-slot" in blob and "S3" in blob and "S4" in blob, blob or "no error")

# A stale count word
REV4_SEVEN = review([(i, FOUR[i - 1][1]) for i in range(1, 5)], promise=[(4, "Easy to clean", FOUR[3][2])], intro="The three buyer questions, in gallery order")
code, errs = run(brief(FOUR, COV4), REV4_SEVEN, PTS4)
check("a review that still counts the old gallery size fails", "stale-slot-count" in " ".join(errs), " ".join(errs) or "no error")

# selling-points.md left on the old numbers
code, errs = run(brief(FOUR, COV4), REV4, PTS3)
blob = " ".join(errs)
check("selling-points.md on the old numbering fails", "mapping-drift" in blob or "point-unaccounted" in blob, blob or "no error")

# a Funnel B block missing for the new slot
b4 = brief(FOUR, COV4).replace(fb(2, FOUR[1][1], FOUR[1][2]), "")
code, errs = run(b4, REV4, PTS4)
check("a slot without its Funnel B block fails", "funnel-b-missing" in " ".join(errs), " ".join(errs) or "no error")

# everything updated after the insertion: clean, and no fixed slot count anywhere
code, errs = run(brief(FOUR, COV4), REV4, PTS4)
check("the same insertion with every file updated passes", code == 0 and not errs, f"{errs}")

# a gallery of five works the same way (nothing hardcodes the size)
FIVE = FOUR + [("Lifestyle", "What will my party look like?", "The star of the snack table", "yes")]
COV5 = COV4 + [("SP5", "party centerpiece", "S5", "")]
REV5 = review([(i, FIVE[i - 1][1]) for i in range(1, 6)])
code, errs = run(brief(FIVE, COV5), REV5, points(COV5))
check("a five-slot gallery passes when consistent", code == 0 and not errs, f"{errs}")

print()
if FAILURES:
    print(f"{len(FAILURES)} FAILED: {', '.join(FAILURES)}")
    sys.exit(1)
print("all passed")

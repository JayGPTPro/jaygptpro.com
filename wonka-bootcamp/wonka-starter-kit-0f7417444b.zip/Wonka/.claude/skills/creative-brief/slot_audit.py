#!/usr/bin/env python3
"""slot-audit. After a STRUCTURAL revision of a creative brief (a slot inserted, deleted,
merged, split or reordered), prove that every file still agrees on which slot is which.

brief_lint.py reads one file and passed on 2 September 2026 while brief/owner-review.md and the
brief's own Promise check still carried the numbering from BEFORE a new S4 was inserted. This
reads three files and compares them:

  brief/creative-brief.md      the set-structure table, every secondary block, every Funnel B
                               block, the coverage map, and every S-number in prose
  brief/owner-review.md        the question table, the promise table, and every S-number in prose
  research/selling-points.md   the "Mapped to" column

Usage:
    python3 slot_audit.py factory/Products/[product]
    python3 slot_audit.py <creative-brief.md> [<owner-review.md>] [<selling-points.md>]

Exit 0 when clean, 1 on any error. Nothing here assumes a gallery size: the set-structure
table is the source of truth for which slots exist, whether that is five or twelve.
Stdlib only.
"""
from __future__ import annotations
import re
import sys
from pathlib import Path

SLOT = re.compile(r"(?<![A-Za-z])S(\d{1,2})(?!\d)")     # S1..S99; never SP1, never inside a word
NUMBER_WORDS = {"one": 1, "two": 2, "three": 3, "four": 4, "five": 5, "six": 6, "seven": 7,
                "eight": 8, "nine": 9, "ten": 10, "eleven": 11, "twelve": 12}


def norm(t: str) -> str:
    return re.sub(r"[^a-z0-9]", "", (t or "").lower())


def split_sections(md: str) -> dict:
    out, current, buf = {}, None, []
    for line in md.splitlines():
        m = re.match(r"^##\s+(.+?)\s*$", line)
        if m:
            if current:
                out[current.lower()] = "\n".join(buf)
            current, buf = m.group(1), []
        elif current:
            buf.append(line)
    if current:
        out[current.lower()] = "\n".join(buf)
    return out


def find_section(sections: dict, *needles):
    for key, body in sections.items():
        if any(n in key for n in needles):
            return body
    return None


def table_rows(body: str) -> list:
    rows = []
    for line in body.splitlines():
        if line.count("|") < 2:
            continue
        cells = [c.strip() for c in line.strip().strip("|").split("|")]
        if all(re.fullmatch(r"[-: ]*", c) for c in cells):
            continue
        rows.append(cells)
    return rows


def slot_id(cell: str):
    m = re.fullmatch(r"\**\s*S(\d+)\s*\**", cell.strip())
    return int(m.group(1)) if m else None


def parse_brief(md: str) -> dict:
    sections = split_sections(md)
    struct = find_section(sections, "set structure") or ""
    slots = {}
    for cells in table_rows(struct):
        sid = slot_id(cells[0]) if cells else None
        if sid is None or len(cells) < 3:
            continue
        slots[sid] = {"job": cells[1], "message": cells[2].strip().strip('"'),
                      "people": cells[3].strip().lower() if len(cells) > 3 else ""}
    sec = find_section(sections, "secondary slot") or ""
    blocks = {}
    heads = list(re.finditer(r"(?m)^###\s+S(\d+)\s*[.:\-]?\s*(.*)$", sec))
    for i, m in enumerate(heads):
        body = sec[m.end(): heads[i + 1].start() if i + 1 < len(heads) else len(sec)]
        bq = re.search(r"Buyer question\s*:\s*\"([^\"]+)\"", body, re.I)
        msg = re.search(r"Message\s*:\s*\"([^\"]+)\"", body, re.I)
        people = re.search(r"People\s*:\s*(yes|no)", body, re.I)
        blocks[int(m.group(1))] = {"job": m.group(2).strip(),
                                   "question": bq.group(1) if bq else "",
                                   "message": msg.group(1) if msg else "",
                                   "people": people.group(1).lower() if people else ""}
    hand = find_section(sections, "genrupt handoff") or ""
    fb = {}
    fheads = list(re.finditer(r"(?m)^-\s+Slot for S(\d+)\b.*$", hand))
    for i, m in enumerate(fheads):
        end = fheads[i + 1].start() if i + 1 < len(fheads) else len(hand)
        body = hand[m.end(): end]
        stop = re.search(r"(?m)^-\s+If the returned|^###\s", body)
        if stop:
            body = body[: stop.start()]
        bq = re.search(r"buyerQuestion\s*:\s*\"([^\"]+)\"", body)
        hp = re.search(r"headerPhrases\s*:\s*\[([^\]]*)\]", body)
        fb[int(m.group(1))] = {"question": bq.group(1) if bq else "",
                               "headers": re.findall(r'"([^"]+)"', hp.group(1)) if hp else []}
    cov = find_section(sections, "coverage map") or ""
    cmap = {}
    for cells in table_rows(cov):
        if not cells or not re.fullmatch(r"SP\d+", cells[0]):
            continue
        mapped = cells[2] if len(cells) > 2 else ""
        reason = cells[3] if len(cells) > 3 else ""
        unmapped = mapped in ("", ".") or bool(re.fullmatch(r"[-. ]+", mapped))
        cmap[cells[0]] = {"refs": sorted({int(x) for x in SLOT.findall(mapped)}),
                          "unmapped": unmapped, "reason": reason}
    return {"sections": sections, "slots": slots, "blocks": blocks, "fb": fb, "cmap": cmap}


def logical_lines(md: str) -> list:
    """(line number, text) pairs where an indented continuation line is folded into the bullet
    above it. Real briefs wrap every bullet, and a slot number on the first line with its quoted
    message on the second is exactly the case that hid the S7 -> S8 residue."""
    out = []
    for n, line in enumerate(md.splitlines(), 1):
        if out and line.startswith((" ", "\t")) and line.strip() and not line.lstrip().startswith(("-", "*", "|", "#")):
            out[-1] = (out[-1][0], out[-1][1] + " " + line.strip())
        else:
            out.append((n, line))
    return out


def stale_refs(md: str, canonical: set, label: str, errors: list):
    """Every S-number anywhere in the file must name a slot that exists."""
    for n, line in logical_lines(md):
        bad = sorted({int(x) for x in SLOT.findall(line)} - canonical)
        if bad:
            errors.append(f"{label} line {n}: refers to S{', S'.join(map(str, bad))}, which is not "
                          f"in the set structure (current slots: S1..S{max(canonical)}) [stale-slot-ref]")


def misattributed(md: str, owners: dict, label: str, errors: list):
    """A line that names ONE slot and quotes a message or question that belongs to ANOTHER slot
    is the exact residue an insertion leaves behind ('S7 REWRITTEN ... "Lifts apart"' after the
    old S7 became S8)."""
    for n, line in logical_lines(md):
        refs = {int(x) for x in SLOT.findall(line)}
        if len(refs) != 1:
            continue
        (ref,) = refs
        for q in re.findall(r'"([^"\n]{3,})"', line):
            owner = owners.get(norm(q))
            if owner is not None and owner != ref:
                errors.append(f"{label} line {n}: says S{ref} but quotes \"{q[:50]}\", which belongs "
                              f"to S{owner} [misattributed-slot]")
                break


def number_word_mismatch(md: str, n: int, label: str, errors: list):
    for m in re.finditer(r"\b(one|two|three|four|five|six|seven|eight|nine|ten|eleven|twelve|\d{1,2})\s+"
                         r"(?:buyer\s+questions|secondary\s+(?:slots|jobs|headlines))\b",
                         re.sub(r"\s+", " ", md), re.I):
        word = m.group(1).lower()
        val = NUMBER_WORDS.get(word) or (int(word) if word.isdigit() else None)
        if val is not None and val != n:
            errors.append(f"{label}: says '{m.group(0)}' but the set structure has {n} secondary "
                          f"slots [stale-slot-count]")


def audit(brief_md: str, review_md, points_md) -> tuple:
    errors, warnings = [], []
    b = parse_brief(brief_md)
    slots, blocks, fb, cmap = b["slots"], b["blocks"], b["fb"], b["cmap"]
    if not slots:
        errors.append("no secondary slots in the set-structure table; nothing to audit against [no-set-structure]")
        return errors, warnings
    canonical = set(slots)
    n = len(canonical)
    if sorted(canonical) != list(range(1, n + 1)):
        errors.append(f"set structure numbers the slots {sorted(canonical)}; after a structural "
                      f"revision they must run S1..S{n} with no gap [slot-numbering]")

    owners = {}
    for sid, s in slots.items():
        if s["message"]:
            owners.setdefault(norm(s["message"]), sid)
    for sid, blk in blocks.items():
        if blk["question"]:
            owners.setdefault(norm(blk["question"]), sid)
        if blk["message"]:
            owners.setdefault(norm(blk["message"]), sid)

    # secondary blocks vs the table
    for sid in sorted(canonical - set(blocks)):
        errors.append(f"S{sid} is in the set structure but has no '### S{sid}' block under Secondary slots [slot-block-missing]")
    for sid in sorted(set(blocks) - canonical):
        errors.append(f"'### S{sid}' exists under Secondary slots but the set structure has no S{sid} [slot-block-extra]")
    for sid in sorted(canonical & set(blocks)):
        s, blk = slots[sid], blocks[sid]
        if norm(s["job"]) != norm(blk["job"]):
            errors.append(f"S{sid}: the set structure says job '{s['job']}' but the block heading says "
                          f"'{blk['job']}' [slot-job-drift]")
        if blk["message"] and norm(s["message"]) != norm(blk["message"]):
            errors.append(f"S{sid}: the set structure carries \"{s['message']}\" but the block says "
                          f"\"{blk['message']}\" [slot-message-drift]")
        if s["people"] and blk["people"] and s["people"][:3] != blk["people"][:3]:
            errors.append(f"S{sid}: People is '{s['people']}' in the set structure and '{blk['people']}' "
                          f"in the block [slot-people-drift]")
    # Funnel B blocks
    for sid in sorted(canonical - set(fb)):
        errors.append(f"S{sid} has no 'Slot for S{sid}' block in the Funnel B handoff [funnel-b-missing]")
    for sid in sorted(set(fb) - canonical):
        errors.append(f"the Funnel B handoff carries 'Slot for S{sid}' but the set structure has no S{sid} [funnel-b-extra]")
    for sid in sorted(canonical & set(fb) & set(blocks)):
        f, blk = fb[sid], blocks[sid]
        if f["question"] and blk["question"] and norm(f["question"]) != norm(blk["question"]):
            errors.append(f"S{sid}: the Funnel B buyerQuestion differs from the block's Buyer question [funnel-b-question-drift]")
        if f["headers"] and blk["message"] and norm(f["headers"][0]) != norm(blk["message"]):
            errors.append(f"S{sid}: the Funnel B first header \"{f['headers'][0]}\" is not the block's "
                          f"message \"{blk['message']}\" [funnel-b-header-drift]")
    # coverage map
    if not cmap:
        warnings.append("no selling-points coverage map rows found; skipped the mapping checks")
    for sp, row in cmap.items():
        bad = sorted(set(row["refs"]) - canonical)
        if bad:
            errors.append(f"coverage map {sp} is mapped to S{', S'.join(map(str, bad))}, which does not exist [stale-slot-ref]")
        if row["unmapped"] and not row["reason"]:
            errors.append(f"coverage map {sp} is neither mapped nor skipped with a reason [point-unaccounted]")
    stale_refs(brief_md, canonical, "creative-brief.md", errors)
    misattributed(brief_md, owners, "creative-brief.md", errors)
    number_word_mismatch(brief_md, n, "creative-brief.md", errors)

    # owner review
    if review_md is not None:
        rsec = split_sections(review_md)
        qrows, prows = {}, {}
        for body in rsec.values():
            for cells in table_rows(body):
                sid = slot_id(cells[0]) if cells else None
                if sid is None:
                    continue
                if len(cells) == 2:
                    qrows[sid] = cells[1]
                elif len(cells) >= 3 and "before" not in cells[1].lower():
                    prows[sid] = cells[2]       # | Slot | Before | After | Why |
        if not qrows:
            warnings.append("owner-review.md: no question table found (| S1 | question |); skipped its checks")
        else:
            for sid in sorted(canonical - set(qrows)):
                errors.append(f"owner-review.md: the question table has no row for S{sid} [review-slot-missing]")
            for sid in sorted(set(qrows) - canonical):
                errors.append(f"owner-review.md: the question table lists S{sid}, which the brief no longer has [review-slot-extra]")
            for sid in sorted(canonical & set(qrows)):
                want = blocks.get(sid, {}).get("question", "")
                got = re.sub(r"\s*\([^)]*\)\s*$", "", qrows[sid]).strip().strip("*").strip('"')
                if want and norm(got) != norm(want):
                    errors.append(f"owner-review.md: S{sid}'s question reads \"{got[:50]}\" but the brief's S{sid} "
                                  f"asks \"{want[:50]}\" [review-question-drift]")
        for sid, after in prows.items():
            if sid in canonical:
                want = slots[sid]["message"]
                if want and norm(after.strip('"')) != norm(want):
                    errors.append(f"owner-review.md: the promise table says S{sid} now reads \"{after[:40]}\" but "
                                  f"the brief's S{sid} carries \"{want}\" [review-promise-drift]")
        stale_refs(review_md, canonical, "owner-review.md", errors)
        misattributed(review_md, owners, "owner-review.md", errors)
        number_word_mismatch(review_md, n, "owner-review.md", errors)

    # selling points
    if points_md is not None:
        prow = {}
        for cells in table_rows(points_md):
            if cells and re.fullmatch(r"SP\d+", cells[0]) and len(cells) >= 4:
                prow[cells[0]] = cells[3]
        if not prow:
            warnings.append("selling-points.md: no SP rows with a Mapped to column found; skipped")
        else:
            for sp in sorted(set(prow) - set(cmap), key=lambda x: int(x[2:])):
                errors.append(f"selling-points.md lists {sp} but the coverage map has no row for it [point-unaccounted]")
            for sp in sorted(set(cmap) - set(prow), key=lambda x: int(x[2:])):
                errors.append(f"the coverage map has {sp} but selling-points.md does not [point-unaccounted]")
            for sp in sorted(set(cmap) & set(prow), key=lambda x: int(x[2:])):
                mine = sorted({int(x) for x in SLOT.findall(prow[sp])})
                if mine != cmap[sp]["refs"]:
                    errors.append(f"{sp}: selling-points.md maps it to {['S%d' % x for x in mine] or 'nothing'} but "
                                  f"the coverage map says {['S%d' % x for x in cmap[sp]['refs']] or 'nothing'} [mapping-drift]")
        stale_refs(points_md, canonical, "selling-points.md", errors)
    return errors, warnings


def main() -> int:
    args = sys.argv[1:]
    if not args:
        print(__doc__)
        return 1
    p = Path(args[0])
    if p.is_dir():
        brief = p / "brief" / "creative-brief.md"
        review = p / "brief" / "owner-review.md"
        points = p / "research" / "selling-points.md"
    else:
        brief = p
        review = Path(args[1]) if len(args) > 1 else None
        points = Path(args[2]) if len(args) > 2 else None
    if not brief.exists():
        print(f"ERROR  brief not found: {brief}")
        return 1
    brief_md = brief.read_text(encoding="utf-8")
    review_md = review.read_text(encoding="utf-8") if review and review.exists() else None
    points_md = points.read_text(encoding="utf-8") if points and points.exists() else None
    errors, warnings = audit(brief_md, review_md, points_md)
    if review is not None and review_md is None:
        warnings.append(f"owner-review.md not found at {review}; its checks were skipped")
    if points is not None and points_md is None:
        warnings.append(f"selling-points.md not found at {points}; its checks were skipped")
    print(f"\nslot-audit: {brief.parent.parent.name if p.is_dir() else brief.name}")
    print("=" * 52)
    for w in warnings:
        print(f"  WARN    {w}")
    for e in errors:
        print(f"  ERROR   {e}")
    if not errors and not warnings:
        print("  clean. Every file names the same slots.")
    print("=" * 52)
    print(f"{len(errors)} error(s), {len(warnings)} warning(s)\n")
    if errors:
        print("A structural revision moved the slot numbers. Fix every file the errors name,")
        print("then run this again; brief_lint alone cannot see across files.\n")
    return 1 if errors else 0


if __name__ == "__main__":
    sys.exit(main())

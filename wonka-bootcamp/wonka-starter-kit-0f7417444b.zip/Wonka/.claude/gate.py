#!/usr/bin/env python3
"""The factory gate. Says whether a bootcamp day's room is open yet.

Usage:  python3 .claude/gate.py <day 1-10>     is this day's room open?
        python3 .claude/gate.py update         self-update the kit from the server


The schedule lives on the server, never in this file and never in Wonka's
head. The server's own clock (the HTTP Date header) is what the schedule is
compared against, so a wrong clock on this computer cannot open a door early.

Verdicts (first word of the last line, and the exit code):
  OPEN    exit 0  the room is open, continue
  CLOSED  exit 3  the room is not open yet; the line names the opening moment
  WARN    exit 0  the schedule could not be checked; continue, but say so

The schedule file format, one day per line: "N YYYY-MM-DDTHH:MMZ" (UTC).
A line consisting of the single word "all" opens every door at once.
Lines starting with # are comments.

Update mode reads the kit manifest (line 1 = version, line 2 = zip filename), and when the
server holds a NEWER version it downloads the zip, verifies the md5 prefix embedded in the
filename, backs the current kit code up to _pre-upgrade-<date>/, replaces ONLY the kit code
(CLAUDE.md, README, QUICK_START, guides/, downloads/, .claude/skills/, gate.py, the character
file), writes VERSION last so a crash mid-install retries cleanly next session, and NEVER
touches factory/, output/, .env, or any local settings. Verdicts on the last line:
  CURRENT   up to date (or the server holds nothing newer)
  UPDATED   the new version is installed
  SKIPPED   could not check or fetch safely; nothing was changed
  FAILED    an install started and did not finish; the backup folder is named
"""
import os
import random
import sys
import urllib.request
from datetime import datetime, timezone
from email.utils import parsedate_to_datetime

GATE_URL = os.environ.get(
    "WONKA_GATE_URL", "https://jaygptpro.com/wonka-bootcamp/day-gate.txt"
)
TIMEOUT = 8  # seconds; a dead network must never hang the session


def fetch():
    """Return (schedule_text, server_now_utc). Raises on any failure."""
    url = GATE_URL + ("&" if "?" in GATE_URL else "?") + "cb=%d" % random.randrange(10**9)
    req = urllib.request.Request(url, headers={"User-Agent": "wonka-gate/1"})
    with urllib.request.urlopen(req, timeout=TIMEOUT) as resp:
        if resp.status != 200:
            raise RuntimeError("HTTP %s" % resp.status)
        text = resp.read(65536).decode("utf-8", "replace")
        now = None
        date_hdr = resp.headers.get("Date")
        if date_hdr:
            try:
                now = parsedate_to_datetime(date_hdr)
                if now.tzinfo is None:
                    now = now.replace(tzinfo=timezone.utc)
            except (TypeError, ValueError):
                now = None
    return text, now or datetime.now(timezone.utc)


def parse(text):
    """Return ('all', None) or ('schedule', {day: open_at_utc})."""
    sched = {}
    for line in text.splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        if line.lower() == "all":
            return "all", None
        parts = line.split()
        if len(parts) != 2:
            continue
        try:
            day = int(parts[0])
            when = datetime.fromisoformat(parts[1].replace("Z", "+00:00"))
        except ValueError:
            continue
        if when.tzinfo is None:
            when = when.replace(tzinfo=timezone.utc)
        sched[day] = when
    if not sched:
        raise RuntimeError("schedule file held no readable lines")
    return "schedule", sched


MANIFEST_URL = os.environ.get(
    "WONKA_KIT_MANIFEST_URL", "https://jaygptpro.com/wonka-bootcamp/kit-latest.txt"
)
MAX_ZIP_BYTES = 30 * 1024 * 1024

# What an update is allowed to REPLACE. Everything else in the folder is the owner's:
# factory/, output/, .env, settings, backups, and anything they added themselves.
REPLACE_PATHS = [
    "CLAUDE.md",
    "README.md",
    "QUICK_START.md",
    "guides",
    "downloads",
    ".claude/skills",
    ".claude/gate.py",
    ".claude/wonka-character.md",
]


def _fetch_bytes(url, timeout, cap):
    req = urllib.request.Request(
        url + ("&" if "?" in url else "?") + "cb=%d" % random.randrange(10**9),
        headers={"User-Agent": "wonka-gate/1"},
    )
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        if resp.status != 200:
            raise RuntimeError("HTTP %s" % resp.status)
        data = resp.read(cap + 1)
        if len(data) > cap:
            raise RuntimeError("response larger than the %d byte cap" % cap)
        return data


def cmd_update():
    import hashlib
    import re
    import shutil
    import time
    import zipfile
    from pathlib import Path

    root = Path(__file__).resolve().parent.parent

    # one updater at a time; a stale lock (a crashed session) expires after 10 minutes
    lock = root / ".claude" / ".update-lock"
    try:
        lock.mkdir()
    except FileExistsError:
        if time.time() - lock.stat().st_mtime < 600:
            print("SKIPPED another session is already checking")
            return 0
        try:
            lock.rmdir()
            lock.mkdir()
        except OSError:
            print("SKIPPED could not take the update lock")
            return 0

    started_install = False
    bak = None
    try:
        try:
            local = int((root / "VERSION").read_text().strip())
        except (OSError, ValueError):
            local = 0

        try:
            lines = _fetch_bytes(MANIFEST_URL, TIMEOUT, 4096).decode("utf-8", "replace").split("\n")
            remote = int(lines[0].strip())
            zip_name = lines[1].strip()
        except Exception as e:
            print("SKIPPED could not read the manifest (%s)" % e)
            return 0

        m = re.fullmatch(r"wonka-starter-kit-([0-9a-f]{10})\.zip", zip_name)
        if not m:
            print("SKIPPED manifest zip name looks wrong (%s)" % zip_name)
            return 0
        if remote <= local:
            print("CURRENT v%d" % local)
            return 0

        base = MANIFEST_URL.rsplit("/", 1)[0]
        try:
            data = _fetch_bytes(base + "/" + zip_name, 90, MAX_ZIP_BYTES)
        except Exception as e:
            print("SKIPPED could not download the update (%s)" % e)
            return 0
        if hashlib.md5(data).hexdigest()[:10] != m.group(1):
            print("SKIPPED download did not match its checksum; will retry next session")
            return 0

        tmp = root / ".claude" / ".update-tmp"
        if tmp.exists():
            shutil.rmtree(tmp)
        tmp.mkdir(parents=True)
        zpath = tmp / zip_name
        zpath.write_bytes(data)
        with zipfile.ZipFile(zpath) as z:
            for n in z.namelist():
                if n.startswith("/") or ".." in n:
                    raise RuntimeError("unsafe path in zip: %s" % n)
            z.extractall(tmp)
        inner = None
        for cand in tmp.iterdir():
            if cand.is_dir() and (cand / "CLAUDE.md").exists():
                inner = cand
                break
        if inner is None or not (inner / ".claude" / "skills").is_dir():
            print("SKIPPED the downloaded kit is not shaped like a kit; nothing was changed")
            return 0
        try:
            inner_v = int((inner / "VERSION").read_text().strip())
        except (OSError, ValueError):
            inner_v = -1
        if inner_v != remote:
            print("SKIPPED the downloaded kit says v%s but the manifest says v%d" % (inner_v, remote))
            return 0

        # ---- point of no return: back up, replace, stamp VERSION last ----
        started_install = True
        stamp = time.strftime("%Y-%m-%d")
        bak = root / ("_pre-upgrade-" + stamp)
        if bak.exists():
            bak = root / ("_pre-upgrade-" + stamp + time.strftime("-%H%M%S"))
        bak.mkdir()
        # VERSION is backed up too (though replaced LAST, not in the loop), so a
        # restore after a FAILED install can put the old number back beside the old code
        for rel in REPLACE_PATHS + ["VERSION"]:
            src = root / rel
            if not src.exists():
                continue
            dst = bak / rel
            dst.parent.mkdir(parents=True, exist_ok=True)
            if src.is_dir():
                shutil.copytree(src, dst)
            else:
                shutil.copy2(src, dst)
        for rel in REPLACE_PATHS:
            src = inner / rel
            if not src.exists():
                continue
            dst = root / rel
            dst.parent.mkdir(parents=True, exist_ok=True)
            if src.is_dir():
                shutil.copytree(src, dst, dirs_exist_ok=True)
            else:
                shutil.copy2(src, dst)
        shutil.copy2(inner / "VERSION", root / "VERSION")
        shutil.rmtree(tmp, ignore_errors=True)
        print("UPDATED v%d -> v%d" % (local, remote))
        return 0
    except Exception as e:
        if started_install:
            print("FAILED the install did not finish (%s); the previous code is in %s" % (e, bak.name if bak else "the backup folder"))
        else:
            print("SKIPPED %s; nothing was changed" % e)
        return 0
    finally:
        try:
            lock.rmdir()
        except OSError:
            pass


UPDATE_STAMP = ".update-checked"   # beside this file; mtime = last quiet check
UPDATE_EVERY = 3600                # seconds between quiet checks at the gate


def _maybe_update_quietly():
    """Run the self-update from the gate at most once an hour, printing its verdict
    line BEFORE the gate's own, so the gate verdict stays the last line. Any failure
    here is swallowed: a broken update check must never close or jam a door."""
    import time
    stamp = os.path.join(os.path.dirname(os.path.abspath(__file__)), UPDATE_STAMP)
    try:
        if time.time() - os.stat(stamp).st_mtime < UPDATE_EVERY:
            return
    except OSError:
        pass
    try:
        with open(stamp, "w") as f:
            f.write(datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ") + "\n")
    except OSError:
        pass
    try:
        cmd_update()
    except Exception as e:  # noqa: BLE001
        print("SKIPPED quiet update check failed (%s)" % e)


def main(argv):
    if len(argv) == 2 and argv[1] == "update":
        return cmd_update()
    if len(argv) != 2 or not argv[1].isdigit():
        print("usage: python3 .claude/gate.py <day 1-10>  |  update")
        return 2
    day = int(argv[1])
    if day < 1:
        print("usage: python3 .claude/gate.py <day 1-10>")
        return 2
    if day == 1:
        print("OPEN day=1 (Day 1 is never gated)")
        return 0

    # The gate is the one thing that runs at every room door, so it is also where a
    # session that spans days picks up a newer kit. Session start runs the update
    # explicitly; this quiet pass covers the owner who never opened a new session.
    # Throttled to once an hour, and never allowed to break the gate itself.
    _maybe_update_quietly()

    # A local override for the instructor's own recording copy: a file beside this
    # script holding the single word "all". Not part of any student instruction, and
    # not in the self-update's replace list, so it survives upgrades.
    override = os.path.join(os.path.dirname(os.path.abspath(__file__)), "gate-override")
    try:
        with open(override) as f:
            if f.read().strip().lower() == "all":
                print("OPEN day=%d (local override)" % day)
                return 0
    except OSError:
        pass

    try:
        text, now = fetch()
        mode, sched = parse(text)
    except Exception as e:
        print("WARN could not check the schedule (%s)." % e)
        print("WARN continue, and tell the owner the schedule could not be verified.")
        return 0

    if mode == "all":
        print("OPEN day=%d (every door is open)" % day)
        return 0

    open_days = [d for d, when in sched.items() if when <= now]
    # day 1 is never gated, so the floor of "what is open" is always day 1
    highest = max(open_days) if open_days else 1

    if day in sched and sched[day] <= now:
        print("OPEN day=%d (open through day %d)" % (day, highest))
        return 0

    if day not in sched:
        # a day the schedule does not know is treated as not yet scheduled
        print("CLOSED day=%d opens=not-yet-scheduled open_through=day-%d" % (day, highest))
        return 3

    local = sched[day].astimezone()
    print(
        'CLOSED day=%d opens_local="%s" open_through=day-%d'
        % (day, local.strftime("%A %d %b %Y, %H:%M"), highest)
    )
    return 3


if __name__ == "__main__":
    sys.exit(main(sys.argv))

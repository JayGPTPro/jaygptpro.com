#!/usr/bin/env python3
"""brief-lint. Check a creative brief BEFORE it costs you credits.

Wonka checks his own work, and that is usually fine. This is the part that does
not get tired: one command, mechanical rules, no opinions. It catches the
failure modes that are cheap to fix in a text file and expensive to fix in a
batch of generated images.

Reads `brief/creative-brief.md` (the markdown Wonka writes) and checks it
against the Genrupt intake contract plus the house rules.

Usage:
    python3 brief_lint.py factory/Products/[product]/brief/creative-brief.md

Exit code 0 when clean, 1 when there are errors. Warnings never fail the run:
a missing section is a WARNING (briefs differ per product), a broken rule
inside a section that IS present is an ERROR.

Stdlib only. Nothing to install.
"""

from __future__ import annotations   # PEP 604 (`Path | None`) in annotations
# is a runtime TypeError on Python 3.9, the version macOS ships. This makes
# annotations lazy strings so the kit runs on a stock Mac.
import re
import sys
from pathlib import Path

# ---------------------------------------------------------------- patterns

# A person actually in frame. "customer" and "shopper" are abstractions a brief
# may reason about without showing anyone, so they are not in this list.
PEOPLE = re.compile(
    r"\b(woman|women|man|men|model|models|person|people|mother|father|family|"
    r"girl|boy|guy|lady|couple|child|children|kid|kids|baby|host|hostess)\b"
    r"|\bhands?\b(?!-)",  # "a hand holding it" is a person. "hand-poured" is not
    re.I,
)

# CASTING is describing WHO the person is. Person-anchored on purpose, so that
# ordinary product language ("for all ages", "a mature finish") never trips it.
_PERSON = (r"(?:woman|women|man|men|model|person|people|mother|father|lady|guy|"
           r"girl|boy|couple|child|kid|baby|host|hostess|she|he|they)")
_DECADE = r"(?:twenties|thirties|forties|fifties|sixties|seventies|eighties)"
_ETHNIC = (r"(?:black|white|caucasian|asian|hispanic|latina|latino|"
           r"african[- ]american|middle[- ]eastern|south[- ]asian|east[- ]asian)")
CASTING = re.compile(
    r"\bcasting\b"
    r"|\bcast(?:s|ing)?\s+(?:a|an|the|one|two|her|him|them)\b"
    r"|\b\d{1,3}[-\s]year[-\s]old\b"
    rf"|\b(?:in\s+(?:her|his|their)\s+(?:early\s+|late\s+|mid[-\s]?)?{_DECADE})\b"
    rf"|\b(?:a|an|one)\s+(?:{_ETHNIC})\s+{_PERSON}\b"
    rf"|\b{_PERSON}\s+(?:aged|around|about)\s+\d{{2}}\b"
    r"|\b(?:silver|grey|gray)[-\s]haired\b"
    rf"|\bdifferent\s+{_PERSON}\b"
    rf"|\bsame\s+{_PERSON}\s+(?:again|in every|across)\b",
    re.I,
)

# Design direction. The look belongs to the branding preset, never to brief text.
DESIGN = re.compile(
    r"#[0-9a-fA-F]{6}\b"                                    # hex codes
    r"|\b(?:serif|sans[- ]serif|typeface|font family|bold sans|editorial serif)\b"
    r"|\b(?:cream|ivory|beige|forest green|navy|charcoal|gold|copper|plum)\s+"
    r"(?:background|backdrop|headline|type|text|accent|palette)\b",
    re.I,
)

BANNED_CLAIMS = re.compile(
    r"\b(?:\d(?:\.\d)?\s*(?:out of|/)\s*5|star rating|five[- ]star|5[- ]star|"
    r"verified buyer|best ?seller badge|as seen on|clinically proven|"
    r"FDA[- ]approved|doctor recommended)\b",
    re.I,
)

PLACEHOLDERS = re.compile(r"\b(?:TBD|TODO|XXX|lorem ipsum|FILL IN|\[insert)\b", re.I)

# Placeholders this skill declares on purpose, so they are lawful.
LAWFUL = re.compile(
    r"pending brand kit|variations: unconfirmed|incumbent: none \(pre-launch\)|"
    r"Owner review: PENDING|upload first|none given|source: estimated",
    re.I,
)

HEADER_MAX = 120        # Genrupt cap on a header phrase
BRIEF_MAX_SENTENCES = 6  # "2 to 5 sentences" with one sentence of slack
# The hang tag has TWO caps and the schema documents only one. 28 characters is in the
# schema; a 5-WORD cap (whitespace-separated tokens) lives on the server and is written
# nowhere: measured 2 September 2026, "4 TIERS - 32 OZ BOWL" (20 chars) was rejected with
# "Hang tag text must be 5 words or fewer (received 6)" because the standalone dash counts
# as a word, and "4 TIERS, 32 OZ BOWL" took. So: count both, and prefer a comma to a dash.
HANG_TAG_MAX_CHARS = 28
HANG_TAG_MAX_WORDS = 5

# A brief is REQUIRED to restate its avoid list and its compliance rules, and
# doing so means naming the forbidden thing ("no star ratings", "never write
# FDA-approved"). Scanning that text for banned words fails the brief for
# obeying the method. Two guards, both taken from the same lesson:
#   GUARDRAIL_SECTION . whole sections that exist to quote the forbidden.
#   NEGATED . a ban stated inline anywhere else ("no five-star badges").
# "note" is NOT in this list on purpose: a plain "## Notes" section is ordinary
# brief prose, and exempting it let a banned claim through (audit 23.8, item 5).
GUARDRAIL_SECTION = re.compile(
    r"avoid|compliance|caveat|guardrail|constraint|do not|forbidden", re.I)
NEGATED = re.compile(
    r"\b(?:no|not|never|without|avoid(?:ing|ed)?|exclude|excluding|"
    r"don'?t|refuse|ban(?:ned)?|drop|remove|omit)\b[^.;:!?\n]{0,70}$", re.I)


def is_negated(text, match_start):
    """True when the words just before the hit turn it into a prohibition."""
    line_start = text.rfind("\n", 0, match_start) + 1
    return bool(NEGATED.search(text[line_start:match_start]))


# ---------------------------------------------------------------- helpers

def split_sections(md: str) -> dict:
    """Map '## Heading' -> body text."""
    out, current, buf = {}, None, []
    for line in md.splitlines():
        m = re.match(r"^##\s+(.+?)\s*$", line)
        if m:
            if current:
                out[current.lower()] = "\n".join(buf)
            current, buf = m.group(1), []
        elif current:
            buf.append(line)
    if current:
        out[current.lower()] = "\n".join(buf)
    return out


def find_section(sections: dict, *needles) -> str | None:
    for key, body in sections.items():
        if any(n in key for n in needles):
            return body
    return None


def slot_blocks(body: str) -> list:
    """Split a secondary-slots section into (label, chunk) pairs.

    The label is what the brief itself calls the slot, so an error message
    points at 'Slot 5' and not at 'the third block I happened to parse'.
    """
    parts = re.split(r"^###\s+|^\*\*Slot\s", body, flags=re.M)
    out = []
    for part in parts:
        if not part.strip():
            continue
        m = re.match(r"\s*(?:Slot\s*)?([0-9]+|[A-Za-z][\w \-]{0,30})", part)
        label = f"slot {m.group(1).strip()}" if m else f"slot {len(out) + 1}"
        out.append((label, part))
    return out


def sentences(text: str) -> int:
    text = re.sub(r"\s+", " ", text).strip()
    return len([s for s in re.split(r"[.!?]+(?:\s|$)", text) if s.strip()])


def line_no(md: str, fragment: str) -> int:
    idx = md.find(fragment[:60])
    return md[:idx].count("\n") + 1 if idx >= 0 else 0


# ---------------------------------------------------------------- checks

def main() -> int:
    if len(sys.argv) < 2:
        print("usage: python3 brief_lint.py <brief/creative-brief.md>")
        return 1
    path = Path(sys.argv[1])
    if not path.exists():
        print(f"ERROR  brief not found: {path}")
        return 1
    if path.is_dir():
        print(f"ERROR  that is a folder, not a brief: {path}")
        print("       point me at the file, usually brief/creative-brief.md")
        return 1

    # A brief is markdown. Anything else gets a plain sentence rather than a
    # traceback: this runs in front of a beginner on Day 3, and the linter's
    # own closing line tells them to fix the BRIEF, which is useless advice
    # next to a Python stack trace.
    try:
        md = path.read_text(encoding="utf-8")
    except UnicodeDecodeError:
        print(f"ERROR  cannot read {path} as text. A creative brief is a markdown")
        print("       file; this looks like a binary or a different encoding.")
        return 1
    sections = split_sections(md)
    errors, warnings = [], []

    def err(msg, frag=""):
        n = line_no(md, frag) if frag else 0
        errors.append(f"line {n}: {msg}" if n else msg)

    def warn(msg):
        warnings.append(msg)

    # 1) MAIN IMAGE IS CHOSEN, NOT BRIEFED --------------------------------
    main_sec = find_section(sections, "main image")
    if main_sec is None:
        warn("no 'Main image' section found; skipped the main-image checks")
    else:
        # The template MANDATES the main section say "product only, no people,
        # zero overlay text". Reading that as a people mention fails every
        # compliant brief, so strip the prohibitions before looking.
        #
        # And the check runs on the BRIEF subsections only, never on
        # "### The controls": the controls MUST name all four tactics,
        # human_contact included, each with a reason, so a compliant line like
        # "human_contact stays OFF: a hand in a main is a compliance risk" is
        # exactly what belongs there. The first version scanned the whole
        # section and punished the sentence that forbids the very thing the
        # check enforces (measured on a live run; the runner had to reword a
        # correct brief to get past its own linter).
        chunks = re.split(r"(?m)^###\s+(.*)$", main_sec)
        scan_src = chunks[0]                       # preamble before any ###
        for head, body in zip(chunks[1::2], chunks[2::2]):
            if "control" not in head.lower():
                scan_src += "\n" + body
        main_scan = re.sub(
            r"\b(?:no|not|never|without|avoid(?:ing)?|zero|excluding)\b[^.;:!?\n]{0,70}",
            " ", scan_src, flags=re.I)
        hit_m = PEOPLE.search(main_scan)
        if hit_m:
            err(f"main image mentions a person ('{hit_m.group(0)}'). The main is "
                f"product only, always [no-people-in-main]", main_sec)
        for banned in ("contentbrief", "content brief", "headerphrase",
                       "header phrase", "custominstruction"):
            if banned in main_sec.lower():
                err(f"main image section carries '{banned}'. Slot 1 is protected: "
                    f"it is decided by tactic, hang-tag text and packaging "
                    f"preference only [slot-1-protected]", main_sec)
        # 1b) THE HANG TAG FITS BOTH CAPS, before Genrupt gets to reject it ------
        ht = re.search(r"Hang-?\s?tag text[^:\n]*:\s*[\"`\u201c]([^\"`\u201d\n]+)[\"`\u201d]", main_sec, re.I)
        if ht:
            tag = ht.group(1).strip()
            if tag and not re.match(r"(?i)^(auto\b|none\b|\[|exact words)", tag):
                toks = tag.split()
                bare = [t for t in toks if not re.search(r"[A-Za-z0-9]", t)]
                if len(tag) > HANG_TAG_MAX_CHARS:
                    err(f"hang-tag text '{tag}' is {len(tag)} characters; the cap is "
                        f"{HANG_TAG_MAX_CHARS} [hang-tag-limits]", ht.group(0))
                if len(toks) > HANG_TAG_MAX_WORDS:
                    why = (f", and the standalone '{bare[0]}' is one of them: a comma costs no word"
                           if bare else "")
                    err(f"hang-tag text '{tag}' is {len(toks)} words; Genrupt rejects more than "
                        f"{HANG_TAG_MAX_WORDS} whitespace-separated tokens (the 28-character cap is "
                        f"not the binding one){why} [hang-tag-limits]", ht.group(0))
                elif bare:
                    warn(f"hang-tag text '{tag}': the standalone '{bare[0]}' counts as a word on "
                         f"the server; a comma is safer [hang-tag-limits]")

    # 2) A+ IS HANDS-OFF --------------------------------------------------
    aplus = find_section(sections, "a+ content", "a+ ")
    if aplus is not None:
        body = aplus.lower()
        for banned in ("module 1", "module 2", "headline:", "copy points",
                       "module plan"):
            if banned in body:
                err(f"A+ section carries '{banned}'. A+ is hands-off: Genrupt "
                    f"plans it alone and inspection is the gate [aplus-hands-off]",
                    aplus)

    # 3) SECONDARY SLOTS ---------------------------------------------------
    sec = find_section(sections, "secondary slot")
    messages = []
    if sec is None:
        warn("no 'Secondary slots' section found; skipped the slot checks")
    else:
        for label, block in slot_blocks(sec):
            if CASTING.search(block):
                hit = CASTING.search(block).group(0)
                err(f"{label}: casting text in the brief ('{hit}'). Casting is a "
                    f"structured field: it belongs in customAvatars, never in "
                    f"slot text [casting-is-structured]", block)
            if DESIGN.search(block):
                hit = DESIGN.search(block).group(0)
                err(f"{label}: design direction in the brief ('{hit}'). The look "
                    f"comes from the branding preset; briefs stay design-silent "
                    f"[briefs-are-design-silent]", block)
            comp = re.search(r"(?:composition|content brief)\s*[:\-]\s*(.+?)(?=\n\s*[-*]|\n\n|$)",
                             block, re.S | re.I)
            if comp and sentences(comp.group(1)) > BRIEF_MAX_SENTENCES:
                err(f"{label}: content brief runs {sentences(comp.group(1))} "
                    f"sentences. It is 2 to 5 sentences of visual direction, not a "
                    f"research summary [distill-dont-forward]", block)
            msg = re.search(r"(?:message|headline)\s*[:\-]\s*(.+)", block, re.I)
            if msg:
                text = msg.group(1).strip().strip('"')
                if len(text) > HEADER_MAX:
                    err(f"{label}: headline is {len(text)} chars, the cap is "
                        f"{HEADER_MAX} [header-phrase-cap]", block)
                messages.append((label, re.sub(r"[^a-z0-9 ]", "", text.lower()).strip()))

        # set-level: no two slots may carry the same message
        seen = {}
        for idx, m in messages:
            if not m:
                continue
            if m in seen:
                err(f"{seen[m]} and {idx} share the same message "
                    f"('{m[:40]}'). Every frame does a distinct job "
                    f"[set-level-variety]")
            seen[m] = idx

    # 4) REJECTED POINTS MAY NOT RESURFACE ---------------------------------
    cov = find_section(sections, "coverage map")
    if cov is None:
        warn("no coverage map found; skipped the skipped-points check")
    elif sec is not None:
        # Read the map by COLUMN, not by keyword. The template's own reasons
        # ("creative cannot fix it: ...", "tested loser (row ...)") never
        # contain the word "skipped", so a keyword scan silently found nothing
        # and the whole rule quietly did not exist.
        #   | ID | Selling point | Mapped to | Skipped because |
        # A row is skipped when "Mapped to" is empty or a bare dot, OR when
        # "Skipped because" carries a reason.
        skipped = []
        for line in cov.splitlines():
            if "|" not in line:
                continue
            cells = [c.strip() for c in line.strip().strip("|").split("|")]
            if len(cells) < 4:
                continue
            point, mapped, reason = cells[1], cells[2], cells[3]
            if not point or re.match(r"^[-: ]+$", point):
                continue                       # header or separator row
            if point.lower().startswith("selling point"):
                continue                       # the header itself
            unmapped = mapped in ("", ".") or re.match(r"^[-. ]+$", mapped or "")
            # A reason only marks a skip on an UNMAPPED row. A mapped row may carry
            # an annotation in the fourth cell, and that is not a skip (audit 23.8).
            if unmapped:
                skipped.append(point)
            elif re.search(r"\bskipped\b|\bnot mapped\b", line, re.I):
                skipped.append(point)          # hand-written variants still count
        for point in skipped:
            tokens = [t for t in re.findall(r"[a-z]{5,}", point.lower())
                      if t not in ("skipped", "because", "reason")]
            if not tokens:
                continue
            for label, block in slot_blocks(sec):
                low = block.lower()
                hits = sum(1 for t in tokens if t in low)
                if hits >= 2:
                    err(f"{label} asserts '{point[:45]}', which the coverage map "
                        f"lists as SKIPPED. A point rejected in research may never "
                        f"be claimed by a slot [skipped-is-a-negative-constraint]")
                    break

    # 4b) A PEOPLE SLOT NEEDS A PINNED AVATAR ------------------------------
    # The kit's own rule: casting is a structured field, never prose. A blank
    # avatar field pins nothing, and that blank was the named root cause of
    # the age drift. So if any slot says people appear, the handoff must carry
    # at least one avatar with a REAL age and a REAL gender.
    struct = find_section(sections, "set structure") or ""
    # The cast is an h3 INSIDE the Genrupt handoff, so the h2 splitter never
    # sees it. Pull the block straight out of the file, from its heading to
    # the next heading of any level.
    cast_m = re.search(r"^#{2,4}\s*Cast\b.*?$(.*?)(?=^#{2,4}\s|\Z)",
                       md, re.M | re.S | re.I)
    cast = cast_m.group(1) if cast_m else ""
    has_people_slot = any(
        re.search(r"\byes\b", cells[-1], re.I)
        for line in struct.splitlines() if line.count("|") >= 3
        for cells in [[c.strip() for c in line.strip().strip("|").split("|")]]
        if len(cells) >= 4 and not re.match(r"^[-: ]+$", cells[0])
    )
    if has_people_slot:
        pinned = 0
        partial = 0
        # An avatar entry WRAPS across lines in the template, so split on the
        # bullet that starts each one rather than reading line by line.
        entries = re.split(r"\n\s*[-*]\s+(?=Avatar\b|customAvatar)", "\n" + cast, flags=re.I)
        for entry in entries:
            if not re.search(r"avatar\s*\d|customAvatar", entry, re.I):
                continue
            age = re.search(r'age\s*[:=]?\s*"?([^",\n]*)', entry, re.I)
            gender = re.search(r'gender\s*[:=]?\s*"?([^",\n]*)', entry, re.I)
            age_ok = bool(age and re.search(r"\d", age.group(1))
                          and "[" not in age.group(1))
            gen_ok = bool(gender and gender.group(1).strip()
                          and "[" not in gender.group(1)
                          and gender.group(1).strip().lower() not in ("any", "n/a", "tbd"))
            if age_ok and gen_ok:
                pinned += 1
            elif age or gender:
                partial += 1
        if pinned == 0 and partial == 0:
            err("a slot carries people but the handoff has no cast. Casting is a "
                "structured field: 1 to 2 customAvatars with an explicit age and "
                "gender [casting-is-structured]")
        elif pinned == 0:
            err("the cast has avatars but none pins BOTH an explicit age and a "
                "gender. A blank avatar field pins nothing, and that is the "
                "cause of age drift, not weak prose [casting-is-structured]")

    # 5) BANNED CLAIMS + PLACEHOLDERS --------------------------------------
    # Skip the sections whose whole job is to quote the forbidden, and skip a
    # ban stated inline. What is left is the brief ASSERTING a banned claim.
    guardrail_bodies = [b for name, b in sections.items() if GUARDRAIL_SECTION.search(name)]
    for m in BANNED_CLAIMS.finditer(md):
        line_start = md.rfind("\n", 0, m.start()) + 1
        line_end = md.find("\n", m.start())
        line = md[line_start:line_end if line_end > 0 else len(md)]
        if any(line in b for b in guardrail_bodies):
            continue
        if is_negated(md, m.start()):
            continue
        err(f"banned claim in the brief: '{m.group(0)}' [compliance-avoid]", m.group(0))
    for m in PLACEHOLDERS.finditer(md):
        line_start = md.rfind("\n", 0, m.start()) + 1
        line_end = md.find("\n", m.start())
        line = md[line_start:line_end if line_end > 0 else len(md)]
        if not LAWFUL.search(line):
            err(f"unresolved placeholder: '{m.group(0)}'. An input is missing, "
                f"say which one [no-placeholders]", line)

    # 6) THE GENRUPT HANDOFF MUST EXIST ------------------------------------
    if find_section(sections, "genrupt handoff") is None:
        warn("no 'Genrupt handoff' section. The generation rooms read that "
             "section; without it they have nothing structured to send")

    # ---------------------------------------------------------------- out
    print(f"\nbrief-lint: {path.name}")
    print("=" * 52)
    for w in warnings:
        print(f"  WARN    {w}")
    for e in errors:
        print(f"  ERROR   {e}")
    if not errors and not warnings:
        print("  clean. Nothing to fix.")
    print("=" * 52)
    print(f"{len(errors)} error(s), {len(warnings)} warning(s)\n")
    if errors:
        print("Fix the BRIEF, never the linter. Every rule here exists because")
        print("skipping it once cost somebody a batch of images.\n")
    return 1 if errors else 0


if __name__ == "__main__":
    sys.exit(main())

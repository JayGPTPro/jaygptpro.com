# incumbent/

The reigning champion lives here: the images your listing shows on Amazon RIGHT NOW.

What lives in this folder:
- `main-live.png` (or .jpg), your current live MAIN image, downloaded from your own listing.
- `live-01.png`, `live-02.png`, and so on: your current live GALLERY, in the exact order Amazon shows it.

Filled at the opening of Day 8 by `/tasting-room` (Wonka downloads them once; if the download is refused, you save them by hand from the listing page, full size, in gallery order). `/inspect` uses the live main for its distinctiveness read when it is there, and `/tasting-room` puts these files in both races, because a winner only counts if it beats reality.

No live listing yet (pre-launch)? Save your strongest competitor's main image here instead, name it clearly (`competitor-main.png`), and tell Wonka. Beating a named rival is a different claim than beating your own live image, and the Tasting Card will say which one was made.

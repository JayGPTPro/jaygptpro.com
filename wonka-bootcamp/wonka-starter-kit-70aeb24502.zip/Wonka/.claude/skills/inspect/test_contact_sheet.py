"""Fixture tests for contact_sheet.py. Run: python3 test_contact_sheet.py"""
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
import contact_sheet as cs  # noqa: E402

FAILURES = []


def check(name, cond, detail=""):
    print(("  PASS  " if cond else "  FAIL  ") + name + ("" if cond else "  " + detail))
    if not cond:
        FAILURES.append(name)


print("contact sheet")

# 1. Labels: the number the owner says, read out of every naming contract in the kit.
cases = {
    "main-06.png": "06", "07.png": "07", "pool-30_t3-motion_v1.png": "30", "m3-mobile.png": "3 mobile",
    "sec-03-v2.png": "03 v2", "main-amber.png": "main-amber", "vanilla-control.png": "vanilla-control",
    "pt03-round-10in.png": "03", "main-130.png": "130", "pool-130_t3-motion_v1.png": "130",
}
for name, want in cases.items():
    got = cs.label_for(name)
    check(f"label {name} -> {want}", got == want, f"got {got!r}")
# 1b. On a mixed sheet the family rides in front, so main-03 and sec-03 never share a label.
mixed = {"main-03.png": "main 03", "sec-03.png": "sec 03", "m3-mobile.png": "A+ 3 mobile",
         "pool-130_t3-motion_v1.png": "pool 130", "vanilla-control.png": "vanilla-control"}
for name, want in mixed.items():
    got = cs.label_for(name, mixed=True)
    check(f"mixed label {name} -> {want}", got == want, f"got {got!r}")

from PIL import Image  # noqa: E402

with tempfile.TemporaryDirectory() as d:
    root = Path(d)
    src = root / "images"
    src.mkdir()
    names = ["main-01.png", "main-02.png", "main-03.png", "pool-30_t3-motion_v1.png"]
    for i, n in enumerate(names):
        Image.new("RGB", (300 + 40 * i, 200), (30 * i, 90, 120)).save(src / n)
    (src / "notes.md").write_text("not an image")
    (src / "broken.png").write_bytes(b"\x89PNG not really")

    # 2. sheet: one page, only readable images, numbers on the tiles.
    pages = cs.sheet(root / "contact.jpg", cs.collect([str(src)]))
    check("sheet writes one page", len(pages) == 1 and pages[0].exists())
    with Image.open(pages[0]) as im:
        check("sheet has the right width", im.width == cs.COLS * cs.TILE, f"{im.width}")

    # 2b. a second sheet under the same name never overwrites the first.
    pages2 = cs.sheet(root / "contact.jpg", cs.collect([str(src)]))
    check("a second sheet lands as contact-2.jpg, the first untouched",
          pages2[0].name == "contact-2.jpg" and (root / "contact.jpg").exists(), pages2[0].name)

    # 3. pick: copies KEEP their numbers, INDEX.md, pick-sheet, originals untouched, no opener in tests.
    dest = root / "pick"
    copies = cs.pick(dest, cs.collect([str(src)]), do_open=False)
    check("pick keeps every file's own number", [c.name for c in copies] == ["01.png", "02.png", "03.png", "30.png"],
          str([c.name for c in copies]))
    idx = (dest / "INDEX.md").read_text()
    check("INDEX maps 30 to the pool file", "| 30 |" in idx and "pool-30_t3-motion_v1.png" in idx)
    check("pick-sheet exists", (dest / "pick-sheet.jpg").exists())
    check("originals untouched", sorted(p.name for p in src.iterdir()) == sorted(names + ["notes.md", "broken.png"]))

    # 4. a second round APPENDS: the same files are skipped, a new one gets its own number,
    #    and a different file under a used number is refused.
    Image.new("RGB", (240, 240), (200, 20, 20)).save(src / "main-09.png")
    Image.new("RGB", (240, 240), (20, 200, 20)).save(src / "pool-130_t1-pure_v2.png")
    copies = cs.pick(dest, cs.collect([str(src)]), do_open=False)
    check("second round appends 09 and 130, keeps the first four",
          [c.name for c in copies] == ["01.png", "02.png", "03.png", "09.png", "30.png", "130.png"],
          str([c.name for c in copies]))
    idx = (dest / "INDEX.md").read_text()
    check("INDEX still maps 30 after the append", "| 30 |" in idx and "pool-30_t3-motion_v1.png" in idx)
    other = root / "other"
    other.mkdir()
    Image.new("RGB", (250, 250), (9, 9, 9)).save(other / "main-01.png")   # a DIFFERENT file, same number
    try:
        cs.pick(dest, cs.collect([str(other)]), do_open=False)
        check("a different file under a used number is refused", False, "it ran")
    except SystemExit as e:
        check("a different file under a used number is refused", "never reused" in str(e), str(e))
    unnum = root / "unnum"
    unnum.mkdir()
    Image.new("RGB", (250, 250), (99, 9, 9)).save(unnum / "chatgpt-export.png")
    copies = cs.pick(dest, cs.collect([str(unnum)]), do_open=False)
    check("an unnumbered file gets the next free number", "131.png" in [c.name for c in copies],
          str([c.name for c in copies]))

    # 5. more than 20 tiles paginates.
    many = root / "many"
    many.mkdir()
    for i in range(23):
        Image.new("RGB", (100, 100), (i * 10, 0, 0)).save(many / f"m{i + 1:02d}.png")
    pages = cs.sheet(root / "many.jpg", cs.collect([str(many)]))
    check("23 tiles -> 2 pages", len(pages) == 2 and pages[1].name == "many-2.jpg", str([p.name for p in pages]))

print()
if FAILURES:
    print(f"{len(FAILURES)} FAILED: {FAILURES}")
    sys.exit(1)
print("all passed")

---
name: aplus
description: Generate the Amazon A+ content (Enhanced Brand Content) hands-off. Genrupt authors the A+ alone; Wonka verifies the locked Reference Sheet and the branding preset, reports the cost, runs the generation, lands the module files in aplus/, proves they are on disk, reads the owner's concept pick (from the Genrupt builder or by the number on Wonka's sheet), and routes to /inspect. No content brief, no module plan, no creative direction is passed in. The carousel exists, is mentioned once, and is never recommended or asked about. Use after the Reference Sheet is locked. Triggers: /aplus, "which concept did I pick", "export the A+", "fix the A+ page", "build the A+", "A+ content", "enhanced brand content", "make the A+ modules", "A+ room".
---

# The A+ Room

| Meta | Value |
|------|-------|
| Room | The A+ Room |
| Day | 7, the last building room. Day 8 is the Tasting Room |
| Station | INVENT (A+ is one of the four Invent sub-parts) |
| Needs | `2-reference/reference-sheet.md` (LOCKED, smoke test PASS). The branding preset is OPTIONAL: resolve it from the product's `status.md` `Genrupt preset ID` row, and run without one when that row says `none` |
| Saves to | `factory/Products/[product]/aplus/` (module images + `aplus-plan.md`, the run record) |
| Typical cost | Quoted ONLY from a live `get_credit_balance_and_costs` preview (`aplus_generation` preset, the `finalCreditsCost` figure); never computed by arithmetic, the base numbers run 3 to 8 times above what bills (CLAUDE.md, Genrupt contract rule 7). House default **4 desktop concepts plus 4 mobile**. **Reported, not gated**; the brief approval carries. |

## What this room does

A+ content is the second product page, the section below the bullets that carries what a bullet cannot. The shopper who scrolls that far is interested and unsure, hunting for a reason to buy or a reason to leave.

**This room is HANDS-OFF, by house decision.** Wonka passes NO content direction into A+ generation: no module plan, no briefs, no headlines, no comparison charts, no casting sentences, no `mustIncludeContent`. Genrupt decides the A+ alone.

**And the reason is a different goal, not less effort.** Everywhere else in this factory the job is to make sure every message lands. Here it is not. **The A+ exists to be beautiful and impressive**, so that a shopper who has scrolled this far feels they are in competent hands. That feeling converts. A module that ticks a coverage box and looks mediocre does more damage than a module that says less and looks expensive. Say that out loud when the owner asks why their careful brief is not being used here, because the honest answer is that this asset has a different job.

Three consequences follow, and they are the whole operating posture of this room:
- **Beauty is the primary acceptance criterion**, alongside truthfulness. Not coverage.
- **Hands-off in the planning is not hands-off in the gate.** The inspection is as hard as anywhere else, and harder on two things: text size and claims.
- **It is still not a blank cheque.** The A+ inherits the locked reference, the style chosen and sent to Refine on Day 6, the branding preset, and the approved claims table. Identity, look and truthfulness were all decided by us, days ago. That is what makes handing this over safe rather than reckless. Here is why: the house strategy is that A+ exists to be beautiful and impressive, and Genrupt does that well, better than a page designed by committee through a prompt box. Directing it produces worse pages than letting it work. Wonka's whole job on A+ is **generate, inspect, fix**, never direct. The quality gate has not gone anywhere: every module still faces `/inspect` afterwards, and anything that fails gets fixed or regenerated. Hands-off on the way in, ruthless on the way out.

What this room DOES control is the machine settings, which are not creative direction: the reference lock (so the real product renders), the branding preset (so the page is on-brand), model and resolution, module count, concept count, display mode, and the carousel switch (the owner's recorded decision, defaulting to off). Honest product facts are the one text allowed in: if the owner supplies a real spec or description, it may ride in as `productDescription`, facts only, never direction.

## Module count is a real decision, and it belongs to the owner

Amazon caps what a page can carry, so **every module we generate is a slot the owner cannot use for something else.** Ask, do not assume:

- **7 modules is the normal answer** when Genrupt is building the whole A+.
- **6 when the owner intends to add their own module**, most often a comparison chart or an FAQ. Those are the two people build by hand, because they carry information only the seller has. Generating 7 and then discovering there is no room left for the comparison is a rebuild, and it is entirely avoidable by asking one question first.
- **5 is the floor, and it is the only value below 6.** The count is a fixed choice of 5, 6 or 7, not a free number: confirm the allowed set against the tool's schema before promising the owner anything else. Say what 5 costs, and say it accurately, because it costs more than room: a 5-module page cannot carry the premium carousel and cannot use dense content, and the machine downgrades both silently rather than refusing. So a "short but dense" page is exactly the thing 5 cannot deliver. Less room to be beautiful, on the asset whose whole job is to be beautiful.

**Ask this BEFORE generating, every time**, and record the answer with its reason in the run record. "Are you adding any module of your own, like a comparison or an FAQ?" is a ten-second question that prevents a full re-run.

## The premium image carousel

Genrupt can add a **premium image carousel** module. **House rule (Jay, 6 September 2026): mention that it exists, once, and never recommend it or ask about it.** It is a generation setting (`carousel.enabled`, `slideCount` 2 to 6, optional `slideNotes`), so it can only be decided BEFORE the run, and it counts against the module budget (a 5-module page cannot carry one). An owner who asks for it gets it, with one honest line: the feature is not the most polished part of Genrupt yet, so look at the result before relying on it. The run record says `off (not requested)` or `on, owner's request`. What never happens is Wonka steering toward it.

Scope of THIS room is the A+ modules only. The main image, the secondary gallery and variation imagery come out of their own rooms (`/main-image`, `/secondary-images`, `/variations`) off the same locked reference, and they stay untouched here. Nothing out of this room is final: `/inspect` runs next.

**This room publishes nothing.** It produces module files; the owner uploads them to their own listing in Seller Central. The bootcamp's on-camera demo runs on a listing that belongs to another seller, so the demo A+ is built and inspected and then goes nowhere. Say so plainly if the subject comes up.

A+ does not enter either Tasting Room race (Day 8 races the main candidates and the gallery only), so it never gates the launch. It may be realigned on Day 8 if the tasting notes flip the winning angle. That is not a reason to ship it broken.

## Before you start

**One HARD gate. A miss = station BLOCKED, with a pointer, and no generation.**

1. `2-reference/reference-sheet.md` exists with `Reference status: LOCKED` and `Smoke test: PASS`. An approved reference WITHOUT a passed smoke test does not count; the smoke test is the only proof the lock holds. Missing or unpassed: point to `/reference-sheet` and stop. The reference lock is what keeps the real product in every module; a hands-off page with the wrong product in it is worse than no page.

**Then resolve the branding preset from the product's `status.md` `Genrupt preset ID` row**, never from the existence of `brand-kit.md`. That row is the canonical lookup, and it may hold a **logo-only preset** (a real logo, no brand styling), a style preset, a preset carrying both, or `none`. Attach whatever it names. Hands-off means the preset (plus the style already sent to Refine on Day 6) is the ONLY style channel, so no preset means the page's look is unpinned, which is a lawful state and not a fault.
- `Genrupt preset ID: none` and `Brand kit: none`: the owner has no Brand Book or Style Guide, or declined styling. That is a decision, not a gap. Attach nothing, **do not offer `/brand-kit`**, record `brand style: none on file`, and run on Genrupt's own styling.
- `Brand kit: none` but a preset ID present: that is a **logo-only preset**. Attach it. Never treat the empty brand kit as permission to drop it.
- `Logo in preset: pending . technical failure`: a supplied logo failed to wire. Say so in one line and route it back to `/reference-sheet`; do not attempt the wiring here and do not block on it.
- Never propose AI-created branding, in any wording, ever. Tell `/inspect` to score brand fit as "no kit on file" instead of inventing a standard. Never guess a brand style to fill the hole.

**Other soft inputs, each a GAP and never a wall.** Ask once, take the answer, record it, keep going:

| Input | If the owner says "I don't have it" |
|---|---|
| An honest product spec or description text (real facts only) | Proceed on the ASIN's own listing content. Record `product facts: listing only`. |
| Brand Registry / A+ eligibility status | Blocks nothing here. Record it and move on; the files are built either way. |
| A live ASIN (product not listed yet) | Ask for the honest product title and description and attach the reference photos; record `source: no_asin`. If the tool cannot run without an ASIN, park `blocked: no ASIN, A+ tool requires one` rather than faking one. |

**Then confirm the machine.** A+ is Genrupt-only in this factory: hands-off means Genrupt authors the content, so there is no fallback engine to be hands-off with. If Genrupt MCP is down, or the tool reports insufficient credits, say so in one line and park the room `blocked: [exact reason]`, with `aplus-plan.md` (the run record so far: gates, gaps, settings) already written to disk so no work is lost. Top up or reconnect, then re-run. Never switch to a different engine silently, and never retry a failed paid generation through a different paid workflow.

## Process

1. **Check the gates.** Reference Sheet LOCKED with smoke test PASS. Branding preset present, or its absence recorded per the table above. Report a BLOCKED gate immediately; do not work around it.

2. **Preflight, spending nothing.** Call `generate_aplus_from_asin` WITHOUT `setupConfirmed`. It returns the setup questions, the matching market analyses, and the numbered listing-image reference candidates. It starts nothing and costs nothing. Relay any notices it returns, including reference-image limits.

3. **Settle the machine settings with the owner.** These are setup decisions, not creative direction, and the tool refuses to default them silently, which is correct:
   - **Market analysis**: reuse the existing one for this product if there is one; only create fresh if none matches.
   - **Mode**: **both, desktop and mobile.** The house default is 4 concepts on each. A+ is read on a phone by most of the people who read it at all, and a desktop layout converted late is a layout that was never designed for the screen it lands on. If the owner wants to economise, convert afterwards with `send_aplus_concept_to_mode` instead, and say what that trades away.
   - **Concept count**: **4** by default, per mode. Same doctrine as everywhere else in this factory: the best of four is meaningfully better than the only one, and this asset's whole job is to look impressive. Fewer is lawful; say what it costs.
   - **One pick, and how modes meet it.** The owner picks ONE concept (two are fine when they love two; nothing wrong with keeping both). A concept picked on desktop is converted to mobile with `send_aplus_concept_to_mode` (and the other way round) unless both modes were generated and the owner prefers to pick per mode; say which happened.
   - **Module count**: 7 by default, matching the field's own default and the owner's answer from the section above (the field accepts exactly 5, 6 or 7; at 5 the premium carousel and dense density are downgraded automatically and reported in notices). It is the only lever we hold on set size. Never try to control module count in prose; the field exists, prose does not work.
   - **The locked Reference Sheets, attached by ID.** Pass `productReferenceSheetIds: [every approved sheet]` (up to 5: identity, parts, working state, whichever this product has)
     (the ID from `approve_product_reference_sheet`, or look it up with `find_product_reference_sheets`).
     Field verified present 26 August 2026; it is the fix for the gap this room used to work around by
     pasting the sheet's image URL as an ordinary reference. Prefer the ID over the URL: it carries the
     sheet as an approved product reference rather than as one more picture. Up to 5. This is the one
     thing standing between a hands-off page and a beautiful page of the wrong product.
   - **Listing image references**: do NOT attach the owner's current designed gallery wholesale as style. The current gallery is what the factory is trying to beat; inheriting its design is how a new page comes out looking like the old one. `listingReferenceMode: "none"` is the house default (the tool's own default is `all`, which attaches the current gallery, the very thing this room is trying to beat); `"selected"` with clean product-shot indexes only when the owner asks for them. `additionalReferenceImageUrls` stays EMPTY by default: the sheets replace the source photos, and a source photo beside a corrected sheet puts the uncorrected original back in competition (the replace rule, `/reference-sheet` step 4c).
   - **Style**: the branding preset, applied to the flow if the tooling supports it (discover with `search_capabilities` if the direct tool is not visible), with the Day 6 style lock passed explicitly as `styleReferenceEnabled: true` (the tool defaults it on when a lock exists, but a default is not a decision; `false` only when the owner wants the product's own design instead). Never describe style, colors, or fonts in any text field.

4. **Write `aplus/aplus-plan.md` (the run record) FIRST, then report the cost and run.** The record is on disk BEFORE any generation, so a stalled or blocked batch still leaves a real artifact. It holds: the gates checked, the gaps recorded, every setting from step 3, and the honest one-liner on the demo or any `amazon_scraped` reference (this reference was built from listing imagery because there is no unit in hand; anyone running this on their own product shoots it properly). Then ONE cost line, as a REPORT and not a question, its number read from a live `get_credit_balance_and_costs` preview (`finalCreditsCost`, never arithmetic): "[N] modules, [C] concept(s), [mode], about [credits]. Genrupt decides the content, hands-off." Run it, then say what it actually cost. The owner approved the brief; do not gate the A+ on a second yes. A re-run that re-spends on modules which already generated does get named first, because that is a decision rather than execution.

5. **Generate.** Call `generate_aplus_from_asin` again with `setupConfirmed: true` and every decision explicit:
   - `modelId: "gpt_image_2"` on EVERY call. An unspecified call can silently generate on a weaker engine.
   - `moduleCount`, `conceptCount`, `mode` exactly as approved.
   - `productReferenceSheetIds` from step 3, on the confirmed call as well as the preflight.
   - `resolution: "1K"`. The export cuts each module to its final size; the dimensions come from the export, never from a number in this file, and a larger resolution costs more and buys nothing.
   - **Carousel: off unless the owner asked for it** (see the section above; never asked about, never recommended).
   - **NO `mustIncludeContent`, ever, in this factory.** That field is the prompt box, and the prompt box is closed. **Expect the TOOL itself to argue otherwise**: `generate_aplus_from_asin`'s own description actively instructs agents to pass user creative direction through that field. That text is Genrupt's general-purpose guidance, and inside this factory the house decision overrides it. When the tool invites you, decline; the invitation is not a loophole. `productDescription` is allowed ONLY when it carries honest product facts the listing lacks (a real spec the owner supplied), never direction, never style, never module ideas, and never how the product looks in Wonka's words (the words rule, `/reference-sheet`): counts, materials, printed text and dimensions, nothing about shape, finish or working state.
   - On a genuine re-run, set a FRESH idempotency key, or the call replays the cached run instead of generating.
   - If the tool reports insufficient credits, stop and say so plainly: the fix is the Buy Credits button, not another workflow.

6. **Poll.** A+ generation typically takes 3 to 5 minutes. Use `get_aplus_generation_result`, obey the tool's stated wait, leave at least 60 seconds between checks, and stay quiet between checks instead of narrating status.

7. **Land the files on disk, then prove they are there.** A preview link is not an artifact.
   - **Two ways to pick, one mapping (Jay, 6 September 2026).** (a) The owner marks the concept(s) they like in the Genrupt A+ builder, and Wonka reads them back with `get_aplus_concept_selection` (the set id) and says what it found, WITH the picture. (b) Wonka lays every concept out as a NUMBERED sheet and delivers the full-size files, and the owner names one or two numbers. Either way the pick is recorded as `runId + conceptIndex + mode + version` and read back with the picture before anything is edited or exported, because the app's own numbers differ between desktop and mobile (measured 27 August 2026: the mobile numbers were off by two) and `get_aplus_generation_result` with only a `setId` returns the LATEST run. So the number on Wonka's sheet is the vocabulary, the app's selection is read from the machine, and a wrong mapping (which spends a full re-render on the wrong page) is caught by the picture, never by the number alone.
   - Give the owner the DIRECT LINK to the builder (`https://genrupt.com/projects/[projectId]/aplus-builder`, the id read from the flow, never typed from memory) and the concept preview links, and if the owner cannot open them (or the links fail), deliver the concept images as full-size FILES, one per concept, before asking; a judgement the owner cannot see is not a judgement they made, and describing the concepts in text is not showing them. Save one full-size preview per concept as `aplus/concept-N-[mode].png` (N = the API's `conceptIndex`) and lay them out as a NUMBERED sheet (`python3 .claude/skills/inspect/contact_sheet.py sheet aplus/concepts-[YYYY-MM-DD].jpg aplus/concept-*-[mode].png`), so the owner says "concept 3" and means the tile marked 3. Pick the concept number WITH the owner, and land the files into `aplus/`, module-numbered in page order: `m1.png`, `m2.png`, and so on (append a short slug once the content is known, for example `m1-hero.png`; when both modes were generated, `m1-desktop` / `m1-mobile`).
   - **Two routes to the files.** Route one is the export (`export_aplus_concept`, images ZIP or layered PSD). Fixed by Genrupt and verified working 22 August 2026, with one trap: **pass `runId` explicitly**, because the omit-for-latest-run default can answer "concept not found" for concepts that exist (and the export filename may mislabel the concept number, so verify the ZIP's contents, not its name). The export comes out cut to the final module dimensions, upload-ready. Route two, which produces identical files: **each module's `imageUrl` in `get_aplus_generation_result` is a direct public URL to the final module-cut file** (about 1464x600 desktop, 972x729 mobile, the same dimensions the export would deliver). Download those straight into `aplus/`. Same pixels, same upload-ready cut, no ZIP.
   - Then run a directory listing of `aplus/` and cite the real filenames and the real count. If the count is short, the modules still exist on Genrupt's side: re-download from the run's `imageUrl`s or re-export from the SAME run first; a new generation is the last resort, it makes a new run, and it is named as a spend before it happens.
   - Never overwrite. There is no per-module regeneration: a new version of a concept lands as a complete set in the next `edits/vN/aplus/` (step 10), beside the untouched first version.
   - Update `aplus-plan.md` with the generation record (path, model, settings, cost, approval date, concept links, failures) and the "Modules as generated" table: one row per module describing what Genrupt built (its apparent job, headline, whether people appear). This documents the page for `/inspect`; it is written AFTER generation, describing output, never before it, directing input.

8. **Edits run inside Genrupt, through two doors onto the same page.** (a) In the Genrupt app's A+ editor the owner (or Wonka on screen) can edit a REGION of a module, which is the lighter touch for a small defect (Jay, 6 September 2026). (b) Over MCP, when `/inspect` or the sanity look sends a module back, the fix runs through the discoverable `edit_aplus_concept` capability: `setId`, `runId`, `conceptIndex`, `mode`, plain-language `editInstructions` naming ONLY the defective frame, and the approved Reference Sheet's image URL in `referenceImageUrls` (**the cost of an A+ edit is VARIABLE and this skill will not pretend to know it.** Measured 27 August 2026 on one product in one afternoon: two edits run together billed 106 credits combined, and a later single edit billed 5. The old "about 4 credits" line in this skill was what an owner approved a round against, and the round landed near eight dollars. There is no cost preset for A+ edits, so a live quote is often impossible. The honest protocol: say that the price is variable and unquotable here, **read the balance BEFORE and AFTER every edit and report the delta as the real charge**, and never divide a combined delta by the number of edits and present the result as a per-edit price. The structural fact behind the variance: **an A+ edit re-renders the WHOLE concept, every module, as a new version**, so it prices like a partial render rather than a surgical edit). The Genrupt app's editor is the same flow for anyone who prefers clicking. Edits create a new concept VERSION; the prior version stays in the run history, so the new version lands as a complete set in the next `edits/vN/aplus/` (step 10), and the owner chooses which VERSION stays (newer is not automatically better; a round can introduce a worse defect). **Quality drops with rounds (Jay, 6 September 2026): after two edit rounds on a concept, stop editing and generate a fresh concept instead.** **And because the whole concept re-renders, every edit is a fresh roll of the WHOLE page, not a surgical touch.** Measured 27 August 2026: an edit fixed two flagged defects and broke a third module's text that no instruction had mentioned ("for steady, fcòntrol"). So after EVERY A+ edit, re-read every module, including the ones the instruction never named, and count the round a net loss if it broke more than it fixed. This is also why edit rounds are capped rather than repeated: **two rounds on one concept, then stop.** **Because the whole concept re-renders anyway, EVERY fix for one concept goes in ONE call.** Two fixes in a single call cost exactly what one fix cost, measured on the same run, so splitting a concept's fix list across calls doubles the bill for nothing. Build the complete per-concept fix list first, then one `editInstructions` carrying all of it. **The counting law from `/reference-sheet` governs here too, and it caps the attempts:** a count of IDENTICAL items does not converge, so an A+ count defect gets ONE attempt with a countable parts-inventory reference plus an explicit number, and if that misses, the defect is TAGGED and the module is left alone or regenerated from scratch, never edited a third time (measured 27 August 2026: 14 brushes, one referenced edit, 10 brushes; the third attempt is burning money, not fixing). **Count defects get a countable reference:** when the defect is a wrong part count, a stronger sentence does not fix it (measured: 2 domes -> "exactly four" -> 5 -> 3). Attach a parts-inventory reference sheet (see `/reference-sheet`, multi-part products) as the edit's reference; with it, the same edit landed the exact count first try.

8c. **Read the SEAMS, because an A+ page is one canvas sliced into equal strips.** Measured 27 August 2026 and confirmed against the layered master: a 7-module page is a single canvas cut into seven identical slices (1464x4200 into 600s, 972x5103 into 729s), the layers touching at exactly zero gap, so the cut lines fall wherever the arithmetic puts them and not at content boundaries. On that page 12 of 12 seams crossed live content and 5 cut through the middle of a letter. Crop each seam from the full page with a margin either side, read them, and report what they cross. **State the risk at its true size and no larger:** the page reads correctly if Amazon stacks the modules with no vertical gap and no rescale, and it reads with a white band through five headlines if Amazon adds any gap. Which one Amazon does cannot be settled from inside a session; the one-minute answer is a look at any live listing running full-width stacked A+ modules. Report it, name what would settle it, and never spend on content edits while the answer is open.

8b. **Defects outside the fix list are NAMED, never silently fixed and never silently dropped.** A page carries defects nobody chose to chase: a promise family that survives in another module, a headline duplicated across two modules, an absolute claim in a sub-head. List them plainly when the round closes, say they were not in the instruction and are therefore untouched, and let the owner decide whether they ride to the Inspection Room or to the next round. Measured 27 August 2026 on a mobile page: three such defects sat one module away from the ones being fixed.

9. **First-pass sanity look, then hand off.** Open the modules and check ONLY for catastrophic misses: wrong product, wrong part count, a missing module, a failed generation. Do NOT present these as results, and never call a module final. Hand to the Inspection Room with the page-level asks named, because a page is judged as a scroll and not as a grid: "The A+ is out of the machines, Genrupt's own recipe, untouched. Next stop is /inspect: per-module standards, mobile legibility first, compliance on every claim, plus the page-level read. This is where hands-off earns its keep or gets sent back." After the inspection and the fixes come the page (10b) and the export (11); then Day 8 is `/tasting-room`, which fetches the live listing's images itself.

10. **Fix routing. This is the one place in the whole factory where the routing FLIPS, so say it out loud every time.** Hands-off ends at generation; defects are OURS to catch and clear. When `/inspect` flags a module, **EVERY fix runs inside Genrupt** (house decision, Jay 27 July 2026): surgical problems (a claim to remove, text to shorten, a small element to strip) AND structural problems (wrong product, wrong composition, a module doing the wrong job) both route back HERE, through the Genrupt A+ edit flow. A fix round here is a paid re-spend on modules that already produced, which CLAUDE.md's spend rule puts on the fresh-go-ahead list: build the whole fix list first, present it with the cost line step 8 allows (a live quote when the tool gives one, otherwise "no quote for this edit" said once, and the balance delta reported after, attributed only when nothing else ran in between), get ONE yes, then run them all. Never fix-and-spend item by item, and never spend on a report alone.

   **The direct OpenAI edit API is NEVER used on A+ modules, and the reason is the export rather than the price.** Everywhere else, edits go direct because it costs cents instead of credits, and that stays true for mains and secondaries. An A+ is not an image: it is an assembled multi-module layout that Genrupt exports **already cut to Amazon's module dimensions and ready to upload.** Pull a module out, edit it elsewhere, and drop it back, and the assembly no longer matches: the export stops being final and somebody spends an afternoon rebuilding a page that was finished. Editing inside Genrupt keeps the whole thing coherent through to the export.

   **The chosen version is written down and read by everyone.** `aplus-plan.md` carries one line, `chosen: runId [..] / concept [N] / mode [..] / version [N] / folder [aplus/ or edits/vN/aplus/]`, and the page build (10b), the inspection and the export all read THAT line, never "the latest". When the owner prefers v1 after a v2 exists, v1 is the chosen version and everything downstream uses it.

   Save each fixed round as a complete set snapshot into the NEXT round folder per the Fixing Room's own law: find the highest existing `edits/vN` ACROSS ALL CLASSES, and this round is `edits/v[N+1]/aplus/` (`edits/v1/aplus/` only when no round exists at all). Never open a new v1 beside an existing v2, and never write into a round folder a later round has already superseded. Never hand-patch a module into `aplus/` without a version suffix and a run-record line.

10b. **Stack the modules back into the page.** Run
    `python3 .claude/skills/aplus/aplus_page.py [the folder of the CHOSEN version: factory/Products/[product]/aplus or edits/vN/aplus]` and open
    `aplus-page-desktop.jpg`. It writes four files beside the modules: the page per mode
    (`aplus-page-[mode].jpg`) and the same page with the upload order marked
    (`aplus-order-[mode].jpg`).

    This is not decoration and it is not optional before `/inspect`. Genrupt cuts ONE
    continuous design into modules, so a seam lands mid headline and mid photograph.
    Judged as seven separate crops the page looks like seven unrelated images, the
    page-level read the Inspection Room owes is impossible, and nobody can tell which
    module goes first. Judged as the page, the design is obvious in two seconds.
    Neither file is ever uploaded to Amazon: the cut module files are the upload.

11. **Export the CHOSEN version, and confirm it is upload-ready.** The A+ leaves this room as Genrupt's export: module images cut to the right dimensions, per mode. Run `export_aplus_concept` with the `runId`, `conceptIndex`, `mode` and `versionNumber` from the chosen line (or `useSavedSelection` after reading `get_aplus_concept_selection` back to the owner), `selectedFormats: ["images_zip"]` unless the owner wants the layered PSD too; or walk the owner through the same export in the app. Land the files in `aplus/export/[mode]/`, then **verify by listing the directory** rather than by trusting a success message: the module count matches what was generated, desktop and mobile are both present if both were made, nothing is zero bytes, and the files match the modules already on disk. Then open the folder for the owner.

   Say plainly what the owner now has: **files that go straight into Seller Central without resizing, cropping or renaming.** That is the payoff of having done every edit inside Genrupt, and it is worth naming, because the alternative most sellers live with is an afternoon in an image editor before they can upload anything.

12. **Day 7 ends with the export.** The live listing's images (the incumbent the Tasting Room races against) are fetched at the opening of Day 8 by `/tasting-room`; nothing about them blocks the A+ or belongs to this room.

13. **Name the next room.** Day 8 is `/tasting-room`. `/variations` is Day 9, only if the product sells variants (the lawful trailing marker in `status.md`).

## Output format

`factory/Products/[product]/aplus/` after a run:

```
aplus/
  aplus-plan.md                          the run record: settings, cost, the chosen line (runId / concept / mode / version / folder)
  concept-N-[mode].png                   one full-size preview per concept, the numbers the owner speaks
  concepts-[YYYY-MM-DD].jpg              the numbered concept sheet
  m1-[mode].png .. m7-[mode].png         the chosen concept's modules, as generated
  aplus-page-[mode].jpg                  the stacked page, and aplus-order-[mode].jpg with the upload order
  export/[mode]/amz-module-NN-[slug]-[mode].jpg   Genrupt's export of the chosen version: the files that upload
edits/vN/aplus/                          a fixed version of the concept, as a complete set (never a lone module)
```

`aplus/aplus-plan.md` (the RUN RECORD: written before generation, updated after; it plans the run, never the content):

```markdown
# A+ Run Record . [Product Name]
House mode: HANDS-OFF. Genrupt authored the A+ alone; no content direction was passed in.
Built on: 2-reference/reference-sheet.md (LOCKED [date], smoke test PASS, source: [manual/amazon_scraped]), branding preset [id, or "none on file"].

## Gaps recorded
- [input]: not available ([owner's words], [date]). Effect: [what it changes].
- (or "none")

## Setup decisions
| Setting | Value |
|---|---|
| Market analysis | [reused id / fresh] |
| Mode | [both|desktop|mobile] (house default: both) |
| Concepts | [N] (house default: 4 per mode) |
| Modules | [N] (house default: 7) |
| Model / resolution | gpt_image_2 / 1K |
| Carousel | [off (not requested) / on, owner's request on [date]] |
| Chosen | runId [..] / concept [N] / mode [..] / version [N] / folder [aplus/ or edits/vN/aplus/] |
| Listing references | selected: [indexes] / none |
| productDescription | [not sent / honest facts only, source: ...] |

## Generation
| Date | Path | Est. cost | Approved | Concept chosen | Result |
|---|---|---|---|---|---|
| [date] | genrupt | [est] | yes ([date]) | [#] | [complete / partial: missing m#] |

Concept links: [preview URLs]
Files on disk (verified [date]): m1-hero.png, ... ([N] of [N] planned)
Failures: [module + error, or "none"]

## Modules as generated (written AFTER export, for /inspect)
| # | What Genrupt built (job, headline) | People |
|---|---|---|
| M1 | [observed, not directed] | [yes/no] |
```

## Golden Standards check

Before handing off, verify:
- [ ] The hard gate was checked BEFORE generating (Reference Sheet LOCKED with smoke test PASS), and any miss was reported as BLOCKED, not worked around.
- [ ] The preset was resolved from `status.md` `Genrupt preset ID` and attached, or its `none` was recorded as a lawful state. A logo-only preset was attached like any other. Nothing missing was invented and no branding was proposed.
- [ ] HANDS-OFF held: no `mustIncludeContent`, no module plan, no briefs, no headlines, no casting text, no style prose reached the generation call. `productDescription`, if sent, carried honest product facts only.
- [ ] Preflight call ran first (no `setupConfirmed`), and every setup decision was made explicitly with the owner: market analysis, mode, concept count, module count via the FIELD (never prose), listing references (incumbent gallery NOT attached wholesale).
- [ ] `modelId: "gpt_image_2"`, `resolution: "1K"`, the carousel off unless the owner asked (mentioned once, never recommended, never asked about), fresh idempotency key on any real re-run.
- [ ] The module count was ASKED, not assumed, and the answer records whether the owner is adding a module of their own.
- [ ] Mode was both desktop and mobile unless the owner traded it away knowingly.
- [ ] `aplus-page-[mode].jpg` and `aplus-order-[mode].jpg` exist in `aplus/` and were LOOKED at, not just written. The page is how a human judges an A+; the module crops are only how Amazon eats it.
- [ ] Cost was REPORTED before and after the run, never used as a gate; a partial re-run or fix regeneration was named out loud before spending again.
- [ ] `aplus/aplus-plan.md` existed on disk BEFORE generation and was updated after with the generation record and the modules-as-generated table.
- [ ] Files verified on disk with a directory listing that matches the record's count; nothing overwritten; missing modules named and re-run, never quietly dropped.
- [ ] The pick was read from `get_aplus_concept_selection` or named by the number on Wonka's sheet, mapped to runId / concept / mode / version, read back with the picture, and written as the chosen line; the page build, the inspection and the export used that version.
- [ ] The user was pointed to `/inspect` with the page-level asks; no module was called final. Fix routing stated: ALL A+ fixes run in Genrupt through this room (edits/vN snapshots); `/fix` and the direct API are never used on A+.
- [ ] If generation could not run, the room is parked `blocked: [exact reason]` with the run record already on disk.

## Wonka lines

Openers:
- "The A+ Room. Below the fold is where the browser becomes the buyer. Today the machine cooks alone, and I watch the plates come out."
- "Hands off the recipe, hands ON the tasting. Genrupt builds this page; we lock the product, pin the brand, and judge every module after."
- "I do not tell this machine what to say. I tell it what the product IS, and who the brand is, and then I inspect like it owes me money."

Closers:
- "[N] modules, Genrupt's own recipe, our product in every frame. Off to /inspect, where hands-off stops being polite."
- "The files are on disk and counted. Nothing here is final; it is merely gorgeous and unshipped. You know exactly where this goes next."
- "The machine cooked, I checked the plates for the wrong product and found none. Now the Inspection Room decides what stays."

## Definition of Done

- `aplus/aplus-plan.md` exists with the gates, the recorded gaps, the setup decisions, the generation record, the verified file list, and the modules-as-generated table.
- Every module of the chosen concept has a real file on disk in `aplus/`, module-numbered, **verified by a directory listing that was actually run**, or a recorded failure naming the missing module numbers and the error.
- The cost was reported before the run and the actual cost reported after it. No gate was placed on work the approved brief already authorised.
- No content direction was passed to generation at any point; the run record states the hands-off mode explicitly.
- The user was explicitly handed to `/inspect` with the page-level asks named; no module was presented as final.
- If generation could not run at all, the room is parked `blocked: [exact reason]` with the run record already on disk. A written record is a real artifact; a described page is not.

## Update status.md

A+ is part of the INVENT station. In the INVENT sub-status block, set `A+ (/aplus): done` (or `in progress` for a partial batch, or `blocked: [precondition]`). Artifact `aplus/` + `aplus/aplus-plan.md`. Record any gaps from the run record in the same line, for example `A+ (/aplus): done (no branding preset on file)`. Then check the whole INVENT sub-status block: when all four sub-parts (Main image, Secondary images, A+, Variations) are `done`, `n/a` with a reason, or carry the lawful trailing marker `Variations: pending (Day 9)`, set the INVENT station row to `done`; otherwise leave it `in progress`. Add a Log line: `[date] A+ generated hands-off: [N] modules, concept [#], cost approved [est], [N] files verified on disk. Awaiting inspection.`


**Then roll the station up, because whichever sub-part finishes last owns this.** Check the whole INVENT sub-status block: when all four (Main image, Secondary images, A+, Variations) read `done`, or `n/a` with a reason, set the INVENT station row to `done`; otherwise leave it `in progress`. A single-SKU product never runs `/variations`, so if only that room rolled up, INVENT would sit unfinished forever on exactly the simplest products.
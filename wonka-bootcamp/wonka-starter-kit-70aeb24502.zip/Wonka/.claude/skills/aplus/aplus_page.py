#!/usr/bin/env python3
"""Stitch the A+ modules into the page a shopper actually sees.

Genrupt hands back one file per module, cut to Amazon's upload dimensions.
That is exactly right for uploading and exactly wrong for LOOKING: nobody
reads an A+ page as seven separate crops, and a folder of m1..m7 says nothing
about which module goes first. So this builds two things beside them:

  aplus-page-<mode>.jpg   the modules stacked in page order, no gaps, no
                          labels. This is the page. Open it and you are
                          reading what the shopper reads.
  aplus-order-<mode>.jpg  the same page with a small badge on each module
                          and a rule at every seam, so the upload order is a
                          picture rather than a sentence somebody has to
                          follow correctly.

The badge is an OVERLAY and the seam rule is one pixel row, so the order
sheet is the same height as the page. That matters more than it sounds:
Genrupt cuts one continuous design into modules, so the seams fall mid
sentence and mid image. Inserting a numbered strip between them pushed the
halves apart and made a correct page look broken.

Neither is uploaded to Amazon. The cut module files are what gets uploaded;
these two are how a human checks the work and follows the order.

Usage:
    python3 aplus_page.py <folder> [--out <folder>]

Reads m<N>-desktop.* / m<N>-mobile.* (and plain m<N>.*) from <folder>,
writes the page and the order sheet per mode found. Module number comes from
the filename, so a re-generated module landed as m5-desktop-v2.jpg replaces
m5 in the page: the highest version of each number wins, which matches the
"land the new module beside the old one" rule in the room.
"""
import re
import sys
from pathlib import Path

try:
    from PIL import Image, ImageDraw
except ImportError:
    sys.exit("this needs Pillow: python3 -m pip install pillow")

EXT = (".jpg", ".jpeg", ".png", ".webp")
GAP = 0            # Amazon stacks modules flush; the page must not invent air
BADGE_H = 34       # the order sheet's overlaid badge, in pixels
MAX_PAGE_PX = 24000  # a JPEG taller than this is unopenable in most viewers


def modules(folder: Path, mode: str) -> list:
    """Every module file for one mode, in page order, one file per number.

    A module regenerated after an edit lands as m5-desktop-v2.jpg beside the
    original, so the same number can appear twice. The higher version wins:
    the page must show the module that is going to be uploaded, not the one
    that was sent back."""
    # Two naming worlds land in this folder, and reading only one of them made
    # the stitcher blind to the files /aplus's OWN export produces (measured
    # 27 August 2026): the room lands modules as m01-desktop.jpg at the top
    # level, while Genrupt's export writes export/<mode>/amz-module-NN-slug-
    # <mode>.jpg. Read both, and look one level down for the mode folders.
    candidates = [f for f in sorted(folder.iterdir()) if f.is_file()]
    for sub in ("export/" + mode, mode, "export"):
        d = folder / sub
        if d.is_dir():
            candidates += [f for f in sorted(d.iterdir()) if f.is_file()]
    entries = []
    for f in candidates:
        if f.suffix.lower() not in EXT:
            continue
        # The version comes off FIRST. Matching it inside one pattern looks
        # tidy and is wrong: the optional free-text slug happily swallows
        # "-v2", so m4-desktop-v2 parsed as version 1 and LOST the tie to the
        # m4 it was generated to replace. The page then showed the module the
        # Inspection Room had already sent back.
        stem = f.stem
        ver = 1
        vm = re.search(r"-v(\d+)$", stem, re.I)
        if vm:
            ver, stem = int(vm.group(1)), stem[: vm.start()]
        m = re.match(r"m(\d+)(?:-(.*))?$", stem, re.I)
        if not m:
            # Genrupt's export naming: amz-module-04-hero-image-desktop
            m = re.match(r"(?:amz-)?module-(\d+)(?:-(.*))?$", stem, re.I)
            if not m:
                continue
        num, rest = int(m.group(1)), (m.group(2) or "").lower()
        # The mode may sit ANYWHERE after the number (m1-desktop, m1-hero-mobile,
        # amz-module-01-hero-image-desktop). Reading it only right after the
        # number let m1-hero-mobile.png into the DESKTOP page (reproduced 6
        # September 2026 on a name fixture).
        mm = re.search(r"(?:^|-)(desktop|mobile)(?:-|$)", rest)
        f_mode = mm.group(1) if mm else ""
        if not f_mode:
            parent = f.parent.name.lower()
            f_mode = parent if parent in ("desktop", "mobile") else ""
        entries.append((num, f_mode, ver, f))
    tagged = any(e[1] for e in entries)
    found = {}
    for num, f_mode, ver, f in entries:
        # an unsuffixed m1.jpg belongs to whichever mode is the only one present;
        # in a folder that carries mode tags it belongs to NEITHER page rather
        # than silently to both
        if f_mode != mode and (f_mode or tagged):
            continue
        if num not in found or ver > found[num][0]:
            found[num] = (ver, f)
        elif ver == found[num][0]:
            print(f"  WARNING: two files claim module {num} version {ver} on {mode} "
                  f"({found[num][1].name}, {f.name}); keeping the first. Name the one that "
                  f"should ship, do not let sort order decide.")
    return [found[n][1] for n in sorted(found)]


def stack(files: list, numbered: bool) -> "Image.Image":
    ims = []
    for f in files:
        im = Image.open(f)
        ims.append(im.convert("RGB") if im.mode != "RGB" else im)
    width = max(i.width for i in ims)
    scaled = [i if i.width == width
              else i.resize((width, max(1, round(i.height * width / i.width))), Image.LANCZOS)
              for i in ims]
    total = sum(i.height for i in scaled) + GAP * (len(scaled) - 1)
    if total > MAX_PAGE_PX:
        s = MAX_PAGE_PX / total
        width = max(1, round(width * s))
        scaled = [i.resize((width, max(1, round(i.height * s))), Image.LANCZOS) for i in scaled]
        total = sum(i.height for i in scaled) + GAP * (len(scaled) - 1)
    page = Image.new("RGB", (width, total), "white")
    y = 0
    seams = []
    for im in scaled:
        page.paste(im, (0, y))
        y += im.height + GAP
        seams.append(y)
    if numbered:
        d = ImageDraw.Draw(page, "RGBA")
        y = 0
        for n, im in enumerate(scaled, 1):
            label = f" {n}  upload position {n} of {len(scaled)}  .  {files[n - 1].name} "
            # A badge is a label, never a lid. On a narrow module an unclamped
            # one covered the whole frame, which turns the order sheet into a
            # sheet of black bars.
            w = min(9 + int(d.textlength(label)), max(24, int(width * 0.55)))
            d.rectangle([0, y, w, y + BADGE_H], fill=(24, 20, 28, 232))
            d.text((10, y + BADGE_H // 2 - 6), label, fill=(240, 226, 200, 255))
            y += im.height + GAP
            if n < len(scaled):      # a seam, drawn ON the page rather than between
                d.rectangle([0, y - 2, width, y], fill=(216, 122, 46, 235))
    return page


def build(folder, out=None) -> list:
    folder = Path(folder)
    out = Path(out) if out else folder
    out.mkdir(parents=True, exist_ok=True)
    written = []
    for mode in ("desktop", "mobile"):
        files = modules(folder, mode)
        if not files:
            continue
        for numbered, name in ((False, f"aplus-page-{mode}.jpg"), (True, f"aplus-order-{mode}.jpg")):
            img = stack(files, numbered)
            p = out / name
            img.save(p, "JPEG", quality=88)
            written.append((p, len(files), img.size))
    return written


def main():
    args = [a for a in sys.argv[1:]]
    if not args:
        sys.exit(__doc__)
    folder = args[0]
    out = None
    if "--out" in args:
        out = args[args.index("--out") + 1]
    written = build(folder, out)
    if not written:
        sys.exit(f"no module files (m1..mN) found in {folder}. Nothing to stitch.")
    for p, n, size in written:
        print(f"wrote {p}  ({n} modules, {size[0]}x{size[1]})")


if __name__ == "__main__":
    main()

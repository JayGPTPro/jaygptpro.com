# Day 5: The Main Image Room

Today the factory makes its most valuable single asset, and then teaches you the loop that
everything else in this bootcamp passes through: generate wide, choose, inspect, improve, finish.

**The sentence for the day: the main image is the one thing a shopper sees before clicking that
you can actively work on, so it is the one thing always worth improving.**

## What you will have by the end of today

- **A wide pool of main-image candidates from TWO machines**: Genrupt's Draft Blast and the
  OpenAI route built into the kit, because the best five of a wide pool beat the best five of ten
- **One shortlist, numbered, from both collections**, chosen in the Genrupt app and the numbered
  OpenAI overview
- A scorecard on the shortlist: described literally, scored, squint tested at thumbnail size,
  gated for compliance
- Your own feedback applied: a plain-language fix, a `/fix` round, or a new version that combines
  ideas
- **The Day 5 close**: one primary main image, the alternatives you keep (if any), a simple
  product-only backup on disk, and the primary upscaled if you asked for it

## What you will need at hand

- Your approved `brief/creative-brief.md`, with its MAIN section fresh in your head
- Your locked reference with a **passed** smoke test, and any preset you have (brand styling, a
  logo, or both) attached. No preset at all is also a lawful start (both from Day 4)
- Genrupt open in a browser tab. **Lesson 2 happens there rather than in the terminal**, and
  that is on purpose

---

## Lesson 1: Create your main image options

### Why the main image gets the most time

Think about what a shopper sees before clicking: reviews, rating, maybe a Best Seller badge,
the price. You cannot decide to have better reviews tomorrow. You can change the price, and it
costs margin on every unit. **The main image is the one you can actively work on**: create a
different version, compare it, test it.

A better image helps more of the right shoppers click, and helps them understand what they are
buying. When conversion improves, the same traffic produces more orders, the return on your
advertising improves, and that supports further growth. Eight-figure businesses keep coming back
to this asset. So does this bootcamp.

### Jay's approach with AI

Generate a wide range of options, then put more work into the ones you like. The brief and the
references still matter, they give a good starting point, but nobody should spend the day
rewriting one prompt hoping the next image will be perfect.

On the OpenAI path the drafts are low quality on purpose: explore ideas at a lower cost, then
improve and upscale the selected images afterwards.

**Aim for three to five good candidates. One you like is enough to move forward. Never keep a
weak image just to fill a quota.**

### Two routes, one pool

Wonka uses two routes: Genrupt's Draft Blast, and an OpenAI generation workflow built into the
kit. Genrupt has its own approach to Amazon main images; Jay loves its results for some products
and less for others, and it keeps improving. The OpenAI route explores strategies he wanted as
well. With both connections available you get options from both and choose from the combined
pool. **You do not need to pick a favorite tool. Pick the images that work for your product.**

### What steers both machines (the technical part, once)

Everything that decides how the pool comes out was decided on Day 3, in your brief. Today
confirms it. Wonka reads the controls back, one line each:

- **Which tactics are enabled**: a hang tag on the product, a person interacting with it, the
  real retail box in frame, or Genrupt's own choice. Enable several. Drop what does not apply to
  your product, and say why.
- **The hang-tag words are YOUR words**, 28 characters and 5 words at most (a standalone dash
  counts as a word). Leave the field empty and the machine writes one from the buyer signal,
  which is lawful but silent.
- **A packaging tactic needs real packaging photos.** Enabled tactic plus empty bucket equals an
  invented box, and an invented box on a hero image is a returns problem wearing a design
  problem's clothes.

The OpenAI route writes its own prompts from the same answers, from the plainest product shot
up to one art-directed frame, with your approved reference sheets attached to every call so the
product stays your product. Quality low, a few dollars for the whole pool on your key.

The Draft Blast is the day's largest single spend. Wonka names it before it runs, quotes the
live preview, and reports the balance afterwards. Say yes.

### Run it

Open your product's Wonka folder in Claude. A fresh session is fine: the saved files carry the
work from the previous days.

```
/main-image
```

Wonka checks the brief and the approved references, then confirms the choices that guide this
run. Review anything that needs your answer, such as the tag wording, packaging, or people
interacting with the product. Check the generation cost it reports. Then:

```
Go ahead, run both.
```

For the fountain, Jay wanted shoppers to recognize the product quickly and see an appealing
chocolate fountain in use. Your criteria come from your own product and brief.

If one connection is not available, Wonka continues with the working one and tells you which
results to expect.

### Your task before lesson 2

Start the main-image run for your product. Let the drafts finish and make sure you can open the
results. You do not need to choose a winner yet.

---

## Lesson 2: Choose your main image candidates

They do not have to be finished yet. You are choosing the ideas worth developing.

### Open Genrupt itself

Until now you worked with Wonka inside Claude. Browsing a large collection, comparing pictures
and choosing favorites is more convenient in the Genrupt app, so this step happens there. Wonka
still generates from Claude.

```
Give me the direct link to my product's drafts in Genrupt.
```

The manual route: open Listing Builder, click Choose a project, select your product, then open
Draft Blast and choose Main Image.

The route today: select in Genrupt, send to Refine, back to Wonka, then the OpenAI collection.

### The risk conversation. Before you choose: how Jay thinks about main images

Give the more creative options a real chance. Relevant ingredients, a product being used, a
physical tag, or the actual packaging can make an image more interesting and give a shopper
another reason to notice it.

Amazon's image requirements are something to take into account. Jay's recommendation is to
explore the stronger ideas as well, rather than automatically choosing the plainest picture
because it feels like the safest option. The potential improvement is worth experimenting for:
we spent time on this asset because a stronger main image can make a meaningful difference to
how shoppers respond.

Not every graphic that fits. The product stays clear, with one thing that makes the image worth
looking at.

**The approach: develop a few different options and start with the one you believe will attract
the right shoppers. Keep a simple product-only image on white as a backup.** If an image ever
needs replacing, the replacement is already on your disk. That backup is the whole downside, and
it is the only thing you will hear about risk from Wonka.

### Look through the pictures

Start with a quick pass. Open the images that catch your attention. Compare two options side by
side when you are deciding between them.

Look for ideas you want to keep. An image can have a strong composition and still need a small
correction. A typo on a tag or a detail you want changed does not make you throw away the idea:
keep it as a candidate and note what needs attention.

**Packaging.** Jay did not photograph a box for his run, so no packaging option appears in his
example. If you supplied your real packaging, look for those versions too. When the box helps
explain the product or makes the presentation stronger, keep an option with it. If none
appeared, ask Wonka for a version from your packaging references.

### Listing Preview: a candidate beside competing products

Open Listing Preview on a candidate. It shows the image in a row of competitors, on desktop and
on a phone. Jay finds the simpler image with the bowls beautiful, and the version with
strawberries and marshmallows in the air catches his attention more. Your favorite piece of
design is not always your first choice for the job of making the right shopper stop and click.

Three questions for every candidate: Can you recognize the product quickly? Does the image stand
out for a useful reason? Does it make you want to look closer?

Use this view to choose what you want to try. Testing comes on Day 8.

### Send to Refine, then tell Wonka

Select the Genrupt images you like and click Send to Refine. Then return to Wonka:

```
I selected the main images on Genrupt. Show me which ones came through.
```

Wonka reads the selection back by count and shows the files. Check that they match what you
selected. Sending to Refine brings the selected drafts in; it does not mean generating them
again.

Not inspection yet: the OpenAI collection is still to look through, and your shortlist can
include images from both.

### The OpenAI collection, by number

```
Open the OpenAI image folder and show me a numbered overview.
```

Go through the whole collection and write down the numbers of the images you like. Open your
favorites at full size. The same principle applies: keep a promising idea even if you spotted a
detail to fix later. Jay chose number 20 for the strawberry-shaped tag and number 30 for the
movement around the fountain.

```
From the pool I like number [N] and number [N]. Bring both sets of choices together in one numbered sheet.
```

You get one numbered sheet with every candidate from both collections. Keep that overview
visible so you and Wonka always talk about the same picture.

**Numbers in your run versus the film.** In your kit the OpenAI pool is numbered from 101 upward
and a pick keeps its number (pool 130 becomes `main-130.png`), so an OpenAI candidate never
shares a number with a Genrupt-born `main-01` to `main-99`. The film was recorded on an earlier
kit where the pool started at 01 and the two picks became main-05 and main-06. The principle is
the same: one image, one number, everywhere.

### Nothing you want to develop?

1. Tell Wonka what is missing before asking for another round. Perhaps the product looks too
   small, or none of the ideas shows the use you wanted.
2. If the same product error keeps appearing, check the references first. Another large batch
   will not repair a wrong reference.
3. Still stuck? Work directly in an image chat such as ChatGPT or Gemini, using the approved
   product references, and bring the result back to Wonka for inspection. Keep that as a
   fallback for this one particularly important image.

### Your task before lesson 3

Choose candidates from the collections available to you and give Wonka one clear list. You do
not need to choose the final winner yet.

---

## Lesson 3: Inspect, develop, and finish your main images

You now have a shortlist. This lesson inspects it, makes useful changes, and finishes the
versions you choose. **All of it from Claude. You do not open an image editor.**

Two skills, and a third move. The Inspection skill checks the pictures and explains what needs
attention. The Fixing skill handles suitable corrections. When a change needs more than a small
edit, Wonka creates a new version.

### Wonka's inspection

```
/inspect
```

```
Inspect my shortlisted main images.
```

It carries out the inspection itself. You do not write a separate instruction for every check:
it looks at the product details, the text and markings, visible mistakes, and how clearly the
image reads at a small size. The findings are tied to the numbered pictures.

Read the findings and add anything you notice yourself. You know what you want the image to
show, and you may spot something the inspection missed. **The score judges execution. The
creative direction is yours.**

### Combine ideas, if you see potential

After the first inspection Jay had another idea. He liked different parts of different pictures:
the hands and the dipping moment from image one, the food arrangement from image three, the
strawberries and marshmallows in the air from image six, and the strawberry-shaped tag from image
five, placed lower down. He described those parts and asked Wonka to build the combination.

Wonka almost talked him out of it: too many ideas in one picture, better as a secondary image.
He wanted to see it anyway: "Build it as main-seven. Let's try." Two versions came back, one with
hands and one without, and the version with hands became the one he kept developing.

You can do more than choose a finished picture from the collection. You can combine ideas,
change the composition, and ask for something closer to what you have in mind. Listen to Wonka's
advice, but you do not have to accept every creative recommendation. If you see potential in an
idea, ask to try it and judge the actual result.

How Wonka builds it: the approved reference sheet first (so the product stays your product), the
pictures you named after it, each part by number with the job it does. The result is a NEW
candidate with the next free number, and it is inspected as a new image; the earlier inspection
does not cover it.

### Refine the idea: say what changes and what stays

Jay liked main-seven but wanted the food on the surface to look like image three (a dipped
strawberry beside the strawberry bowl, a dipped marshmallow beside the marshmallow bowl), and the
chocolate to flow like image one, as a smooth continuous layer. He named those changes and
asked to keep the rest.

```
I like main [N], but I want [what should change] to be like main [N]. [Any second change]. The rest, keep like main [N].
```

That is the pattern for every request: point to the image, say what should change, say what
should stay. Attach a reference when it makes the request clearer. The source pictures explain
the composition; the approved product references define the product itself.

### Your feedback still matters

The next version got closer, but a marshmallow in the top right had started to take on a
strawberry-like shape, and the front of the base was missing the logo and the text around the
controls. Jay pointed those out himself and asked for a proper cylindrical marshmallow and the
missing front markings. The result was main-thirteen, the version he chose.

```
In image [N], [what is wrong and what it should be]. Also [the second detail].
```

Plain language works, or `/fix` for the correction list. Wonka routes a small edit differently
from a new composition: a word swap or an element removed is an edit for cents; a reshaped object
or a restored marking is a new version from the base. You do not choose the tool.

**After a change, look at the new result, including the parts you did not ask to change. Then
have Wonka inspect the updated candidates.** The inspection of the first six pictures does not
cover a new image automatically.

How versions work, once, because Day 8 depends on it: `images/` holds the raw generations
forever. A new version (a combine, a develop from a base) is a new numbered file beside them.
Each surgical fix round writes a complete copy of the current set into `edits/v1/`, then
`edits/v2/`, fixed files fixed, untouched files copied in as-is. "The current set" always means
the highest `edits/` folder, or `images/` if no fix has run.

### Name the roles

```
main-[N] is my primary choice. Keep main-[N] and main-[N] as alternatives, and keep the simple backup.
```

Jay chose main-thirteen and kept main-six and main-three as alternatives (main-three still has a
missing wordmark, a detail to address). Aim for three to five useful options in total when you
have them. If you only have one you want to use, that is fine. You do not keep weak images to
reach a number.

Keep the simple backup separately. Jay found his among the existing Genrupt results. If you do
not have one, ask Wonka to make it. On disk it is `images/vanilla-control.png`, a diagnostic
file, never a candidate.

The alternatives are there for testing later. Jay likes to see an image win three proper A/B
tests before leaving it alone for a few months. Testing is Day 8. Today, save the choices and
their roles clearly: Wonka writes them into `status.md`.

### Finish the file: precision upscale

```
Upscale the primary.
```

Ask for it after the edits are settled. The goal is to enlarge the image you chose while
preserving its details; Jay's finished file is 2048 pixels square. Check the tag, the logo and
the small markings afterwards. Upscaling will not reliably repair a wrong word or a missing
detail, which is why those were fixed first. Keep the original files too.

### Your turn

Run the inspection, add your feedback, and develop an idea further if you want to. You do not
have to combine images just because Jay did. Choose your primary image, save the useful
alternatives and the simple backup, and finish the files that need upscaling. Make sure you can
see the selected pictures and know which version you are keeping.

That completes the main images. On Day 6, the secondary gallery.

---

## What good looks like

- Both machines ran (or the missing one was named), and the drafts landed where the lesson says
- You chose in the Genrupt app with Compare and Listing Preview, sent to Refine, and Wonka's
  read-back matched your selection
- The OpenAI picks were named by number and one numbered sheet holds the shortlist from both
  collections
- A scorecard on the shortlist with a literal description per candidate, not just numbers, and
  your own observations added
- Every change landed as a new numbered file or a new `edits/vN/` round, the originals intact,
  and the updated candidates inspected again
- The close recorded in `status.md`: primary, alternatives (if any), backup; the primary upscaled
  only if you asked, and checked at 2048

## Common mistakes

- **Choosing the plainest picture because it feels safest.** Explore the stronger ideas; the
  backup covers you.
- **Throwing away a strong composition over a typo.** Keep it, note the detail, fix it after the
  pick.
- **Skipping the OpenAI collection.** The shortlist is from both.
- **Talking about "the one with the strawberries".** Numbers. One image, one number, everywhere.
- **Accepting a new version without looking at what you did not ask to change.** Then inspect
  it again.
- **Keeping weak images to reach a number.** One you want to use is a lawful close.
- **Leaving your picks in Genrupt.** Day 6 opens on the local folder.

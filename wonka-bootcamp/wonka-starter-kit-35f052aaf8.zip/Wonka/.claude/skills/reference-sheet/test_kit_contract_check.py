"""Fixture tests for kit_contract_check.

Both directions, because a scanner that only ever prints "clean" is decoration:
each banned pattern is watched to FAIL on text that really asserts it, and the
shipped kit is asserted to PASS as it stands.

Run: python3 test_kit_contract_check.py
"""
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from kit_contract_check import scan, logical_lines  # noqa: E402

KIT_ROOT = Path(__file__).resolve().parents[3]
FAILURES = []


def check(name, cond, detail=""):
    print(("  PASS  " if cond else "  FAIL  ") + name + ("" if cond else "  " + detail))
    if not cond:
        FAILURES.append(name)


def scan_text(md, rel="guides/x.md"):
    """Scan a throwaway kit whose only file carries `md`. Returns violation ids."""
    with tempfile.TemporaryDirectory() as d:
        root = Path(d)
        f = root / rel
        f.parent.mkdir(parents=True, exist_ok=True)
        f.write_text(md, encoding="utf-8")
        violations, _missing = scan(root)
    return {v[2] for v in violations}


print("kit contract check")

# 1. The shipped kit passes as it stands.
violations, missing = scan(KIT_ROOT)
check("the shipped kit is clean", not violations and not missing,
      f"{violations[:2]} {missing[:2]}")

# 2. Every banned wording is caught when it is genuinely asserted.
cases = [
    ("proposes-a-brand-unasked", "With no brand files, Wonka proposes a complete kit from your category."),
    ("wonka-proposes-mode", "- **WONKA PROPOSES.** There are no brand files, so build a proposal."),
    ("logo-blocks", "A missing logo is a gap to record before Day 4 can close."),
    ("logo-needs-brand-kit", "A logo file is required for branding to work at all."),
    ("brand-book-required-for-logo", "A brand book is required before a logo may be used."),
    ("logo-into-packaging", "Send the logo with the packagingImages so it travels along."),
    ("logo-into-slot-refs", "Put the logo in that slot's referenceImages instead."),
    ("preset-only-from-kit-file",
     "The preset is resolved from `factory/Brand/brand-kit.md` in every generation room."),
    ("file-management-homework", "Please drop the actual files into `2-reference/photos/` yourself."),
    ("attach-403-era", "On this connection every route 403s, so carry the material lock as short customInstructions."),
    ("prop-as-defect", "A count off by one, a removable prop, or garbled text is tagged and shown."),
    ("typo-pulls", "Read the tag at zoom; a typo pulls the candidate like any law violation."),
]
for bid, text in cases:
    check(f"catches {bid}", bid in scan_text(text), f"got {scan_text(text)}")

# 3. The negation guard: a rule that FORBIDS the thing must not fire on itself.
compliant = (
    "Wonka does not propose a palette from the product, the category or the buyer.\n"
    "A logo is never routed into packagingImages or into a slot's referenceImages.\n"
)
# The lawful path: the owner ran the room and said yes. Consent words excuse the proposal
# rule and ONLY that rule.
asked = "On an explicit yes, Wonka proposes a starting direction for colors and tone.\n"
check("a proposal the owner explicitly asked for passes", not scan_text(asked), str(scan_text(asked)))
asked2 = "Do you want me to propose a starting direction for colors, typography and tone?\n"
check("  ... and so does the question that offers it inside the room", not scan_text(asked2), str(scan_text(asked2)))
unasked = "Seeing no brand files, he proposes a palette drawn from the category.\n"
check("  ... while an unasked proposal still fails", "proposes-a-brand-unasked" in scan_text(unasked), str(scan_text(unasked)))
consent_does_not_excuse_others = "The owner asked, so put the logo in packagingImages.\n"
check("  ... and consent never excuses a different rule",
      "logo-into-packaging" in scan_text(consent_does_not_excuse_others), str(scan_text(consent_does_not_excuse_others)))

dead = ("The old \"403, cannot attach\" workaround is dead; props are lawful and never tagged.\n")
check("naming the dead workaround and lawful props does not fire", not scan_text(dead), str(scan_text(dead)))
check("a rule that forbids the thing does not fire on itself", not scan_text(compliant),
      str(scan_text(compliant)))

# 4. Hard-wrapped prose is judged as one sentence, not two halves.
wrapped = ("Wonka does not\npropose a palette from the product, the category, the buyer or the\npackaging.\n")
check("a hard-wrapped negation still reads as a negation", not scan_text(wrapped),
      str(scan_text(wrapped)))
check("  ... and paragraphs are the scanning unit",
      list(logical_lines("a\nb\n\nc"))[0] == (1, "a b"), str(list(logical_lines("a\nb\n\nc"))))

# 5. A deleted contract line is a failure, not a silent pass.
with tempfile.TemporaryDirectory() as d:
    root = Path(d)
    (root / "guides").mkdir()
    (root / "guides" / "x.md").write_text("nothing to see", encoding="utf-8")
    _v, miss = scan(root)
from kit_contract_check import REQUIRED  # noqa: E402
check("a missing contract line is reported", len(miss) == len(REQUIRED), f"{len(miss)} reported")

print()
if FAILURES:
    print(f"{len(FAILURES)} FAILED: {', '.join(FAILURES)}")
    sys.exit(1)
print("all passed")

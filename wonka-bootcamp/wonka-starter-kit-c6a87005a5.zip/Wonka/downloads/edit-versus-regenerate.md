# Edit or Generate Another Option?

Choose the action based on what you want to change. You can ask Wonka in plain language.

| What you want | What to ask for |
| --- | --- |
| Keep the design and correct a detail | An edit to the selected image. |
| Improve an artificial-looking face | `/fix-faces` for that image. |
| Explore another scene, layout, or direction | A new option, keeping the current selection available. |
| Continue after an unsuccessful edit | Explain what still looks wrong and ask for another attempt or alternatives. |

## Fix the image you chose

```text
In [image or module], fix [problem and desired result]. Use the product references and keep the rest as close to the current version as possible.
```

Wonka handles clear routine fixes and checks the result. You do not need to approve every small repair. If you only want a report, say "Inspect only; do not edit yet."

Compare the before and after. Check the requested change, the product, text, and surrounding area. A narrow edit aims to preserve the rest; a broader edit may also change nearby elements.

You can choose another candidate if you prefer it. Wonka should not replace your chosen design merely to avoid fixing it.

## For A+ content

Choose the page first. Wonka exports it automatically, then inspection and repairs use the selected module files. Review the individual modules and assembled page, including transitions near an edited area.

A fresh Genrupt export will not contain later local corrections.

## Find the accepted result

```text
Open the folder containing my latest accepted files.
```

Use the version Wonka identifies. The highest folder number alone does not prove that every attempt inside it was accepted.

# Review the Whole Gallery or Page

After inspecting individual images, look at the selected gallery or A+ page in order.

| Check | What to look for |
| --- | --- |
| Messages | Each image contributes something useful. Repetition should reinforce a point deliberately, rather than use space without adding value. |
| People and scenes | The people, settings, and mood fit the brief. A recurring person is fine when intentional. |
| Product and style | Product details, colors, materials, and visual style remain consistent where they should. |
| Use and context | The set helps the customer understand the product in use, where that matters to the brief. A lifestyle image is a choice, not a quota. |
| Coverage | The important points selected in the brief are covered or deliberately left out. Tell Wonka if a priority is missing. |

## For A+ pages

Scroll the assembled desktop and mobile pages you selected. Check readable text, consistent wording, and smooth transitions between modules. Look again around any edited area. Use the matching template's preview in Seller Central before publishing.

## Tell Wonka what needs attention

```text
Inspect [the selected gallery / the selected A+ pages] as a whole. Check consistency, unnecessary repetition, readability, and coverage of the important points in the brief.
```

Choose the scope you need. If you already see a problem, name the image or module and describe it; you do not need to create a separate manual report.

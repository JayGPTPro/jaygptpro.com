#!/usr/bin/env python3
"""The Face Clinic's engine: replace AI-looking people with real-looking ones,
without letting the model touch anything else.

Why this exists as code rather than as one API call. The obvious approach,
one whole-frame images.edit pass, was measured failing: the model does not
EDIT a frame, it re-renders it. On one A+ module it fixed the
people beautifully and added a fifth tier to a four-tier product; on another
it moved the subject's face and aged her a decade. A repair that can break
the product is not a repair.

So the contract here is different:
  1. The FULL frame still goes to the model (context: lighting, palette,
     what the scene is), with a prompt that asks for new real faces.
  2. The result is resized back onto the original's grid.
  3. Only the PEOPLE BOXES are taken from it, through a feathered mask.
     Every pixel outside those boxes is the original file, by construction.
     Headlines, product, layout cannot drift because they are never replaced.

The boxes come from the agent LOOKING at the image, not from a detector: the
kit has no face-detection dependency, and the operator drawing two rectangles
is more reliable than a model guessing. Draw them TIGHT: the head and its
hair, nothing more. Everything inside a box is surrendered to the re-render,
and the first run proved what a generous box costs: one that reached into the
layout composited back a ghost microphone and a floating letter, because the
re-render had moved those things and the box carried the moved copies home.
Never let a box touch on-image text or the product. The feather plus the
ring-based tone match below handle the seam; margin does not need to.

Usage:
    python3 face_fix.py <image> --boxes "x1,y1,x2,y2;x1,y1,x2,y2" [--quality high]
                                [--out <path>] [--prompt-file <txt>]

Where the result lands (kit v23): INSIDE a product folder (an ancestor that
holds images/ and status.md) the fix follows the Fixing Room's round law: a new
edits/v[N+1]/ is opened as the ADOPTED SET (kit v28: every original in images/
that is not an evidence file, each replaced by its newest same-name copy from an
earlier round when one exists; files generated after the last round are in too,
files named -rejected / -render / -faces-fixed are not) and the fixed file takes
its CANONICAL name there (main-06.png, never main-06-faces-fixed.png; a
generation's own -v2 stays: sec-03-v2.png fixes as sec-03-v2.png; the format
stays too: sec-02.jpg fixes as sec-02.jpg, one file per asset). The round
writes round.md naming where each file came from, so the Tasting Room, /inspect
and the Shipping Room resolve the current copy without guessing. OUTSIDE a
product folder (a loose file) it lands beside the source as <name>-faces-fixed.<ext>.
--out overrides both. An A+ MODULE (aplus/export/<mode>/mN.png, or its adopted
copy in edits/vN/aplus/<mode>/) lands in the round's aplus/<mode>/ under its own
name, and the input is always the module's adopted copy. When a head box sits
within EDGE_MARGIN of the module's top or bottom edge, or runs past it, the
person continues into the neighbouring module (an A+ page is one canvas cut
into strips; measured 10 September 2026 on the Day 7 hero: the face in m1, the
neck in m2, a fix inside m1 alone cut the neck at the module edge while every
count passed). So the clinic stacks the neighbour(s), edits ONCE on the joined
image with the box grown to hold head, neck and shoulders across the seam,
composites with the same inward feather, re-cuts at the original boundaries
and writes every touched module into the same round, plus two seam crops
(seam-<a>-<b>-2x.png, seam-<a>-<b>-1x.png) for the eyes. The counts are
technical: a visible seam fails the fix even at 0 outside.
Never touches the source. Cost: one images.edit call at quality HIGH by default (about 100
seconds; low is about 20). High is deliberate and it is the one place in this
factory that does not economise: this room only ever runs on an image whose
faces are ALREADY wrong, one image at a time, on an asset the owner has
already paid to generate. Cheap pools, expensive repairs.
"""

from __future__ import annotations   # PEP 604 (`Path | None`) in annotations
# is a runtime TypeError on Python 3.9, the version macOS ships. This makes
# annotations lazy strings so the kit runs on a stock Mac.
import base64
import os
import re
import shutil
import sys
from pathlib import Path

try:
    from PIL import Image, ImageDraw, ImageFilter
except ImportError:
    sys.exit("this needs Pillow: python3 -m pip install pillow")

# Replacement, not restoration. Asking the model to "make the same face
# realistic" keeps the doll geometry and adds texture ON it, which reads as a
# skin disease at low quality (measured). Asking for a NEW person of the same
# casting in the same pose lets it draw a face it actually knows how to draw.
PROMPT = (
    "This is a product marketing photo. Keep the composition, the product, all on-image text, "
    "the clothing, the poses, the framing and the lighting direction exactly as they are. "
    "Replace each person's face with a DIFFERENT real human face: same gender, same approximate "
    "age, same hairstyle and hair color, a natural candid version of the same expression. "
    "Every person must stay in EXACTLY the same position, size and crop as in the original "
    "image; do not move, rescale or duplicate anyone. "
    "The new faces must look like real photographed people, not AI renders: natural skin with "
    "faint pores and small imperfections, slight facial asymmetry, normal teeth that are not "
    "uniform veneers, realistic eyes with catchlights, individual hair strands. "
    "No beauty-filter glow, no airbrushed skin, no orange tan, no added makeup. Neutral, "
    "believable skin tones with natural variation between regions of the face. "
    "The result should read as a candid lifestyle photograph shot on a professional camera."
)

FEATHER = 40   # px of Gaussian falloff on the mask edge; hides the seam


def _tone_match(orig, edit, box, pad=60):
    """Align the edited box's tone to the original, spatially.

    Version 1 applied ONE per-channel offset per box, computed on the ring
    around it. Measured result: the box still printed as a faint bright
    rectangle, because the render's exposure shift is not constant across the
    box, so a single number under-corrects one edge and over-corrects the
    other. This version builds an offset MAP instead: wherever the two images
    still agree (background the render left alone, within 30 levels), the
    difference is trusted; where they disagree (the new face), it is not; the
    trusted differences are blurred into a smooth field and added. The
    correction therefore follows the background's own gradient and fades to
    the interpolated value under the face."""
    import numpy as np
    from PIL import ImageFilter
    w, h = orig.size
    x1, y1 = max(0, box[0] - pad), max(0, box[1] - pad)
    x2, y2 = min(w, box[2] + pad), min(h, box[3] + pad)
    o = np.asarray(orig.crop((x1, y1, x2, y2)), dtype=np.float64)
    e = np.asarray(edit.crop((x1, y1, x2, y2)), dtype=np.float64)
    d = o - e
    agree = (np.abs(d).max(axis=2) < 30).astype(np.float64)
    if agree.sum() < 500:
        return edit          # nothing trustworthy to anchor on; leave it be
    blur = lambda a, r: np.asarray(
        Image.fromarray(np.clip(a + 128, 0, 255).astype("uint8")).filter(
            ImageFilter.GaussianBlur(r)), dtype=np.float64) - 128
    field = np.stack([
        blur(d[..., c] * agree, 40) / np.maximum(blur(agree * 255, 40) / 255, 1e-3)
        for c in range(3)], axis=2)
    # The field repairs EXPOSURE seams; it must never repaint a face. Uncapped,
    # a green foliage ring bled a visible green tint onto a cheek (measured on
    # the roast-together frame). +-18 is plenty for a seam and too little to
    # recolor skin.
    field = np.clip(field, -18, 18)
    fixed = np.clip(e + field, 0, 255).astype("uint8")
    out = edit.copy()
    out.paste(Image.fromarray(fixed), (x1, y1))
    return out


def parse_boxes(spec: str):
    out = []
    for part in spec.split(";"):
        part = part.strip()
        if not part:
            continue
        nums = [int(v) for v in part.replace(" ", "").split(",")]
        if len(nums) != 4 or nums[0] >= nums[2] or nums[1] >= nums[3]:
            sys.exit(f"bad box '{part}': need x1,y1,x2,y2 with x1<x2 and y1<y2")
        out.append(tuple(nums))
    if not out:
        sys.exit("no boxes given. The clinic edits people; with no people boxes there is no edit.")
    return out


# size is ALWAYS "auto". Forcing a fixed size looked harmless and was not:
# a 1.86-ratio banner pushed through 1536x1024 (ratio 1.5) re-composed at the
# wrong aspect, and squashing it back moved every head out of its box, so the
# composite printed bright off-register rectangles. "auto" renders at the
# source's own aspect (measured: a 1464x600 input came back 1958x803, ratio
# preserved), which keeps the geometry aligned with the boxes.


IMG_EXT = {".png", ".jpg", ".jpeg", ".webp"}
# Temporary FIX suffixes only. A generation's own version (`sec-03-v2.png`, a
# regenerated slot) is a different asset with its own identity and stays. Kit
# v27 stripped `-v2` too, so a fix on sec-03-v2 landed as sec-03.png: one file's
# repair written onto another file's name (reproduced 9 September 2026).
_FIX_SUFFIX = re.compile(r"^(?P<base>.+?)[-_](?:fix\d+|faces-fixed(?:-v\d+)?)$", re.I)
# Evidence names the Fixing Room leaves inside a round on purpose: a failed
# attempt (`-rejected`, `-rejected-2`), the whole-frame render kept for the log
# (`-render`), a loose-file clinic output. None of them is a gallery member.
# The separator is `[-_]` here as in _FIX_SUFFIX: the two regexes must agree,
# or `sec-05_fix2.png` is adopted as a gallery member by one and stripped to
# `sec-05.png` by the other (reproduced 9 September 2026).
_EVIDENCE = re.compile(r".+[-_](?:rejected(?:-\d+)?|render|fix\d+|faces-fixed(?:-v\d+)?)$", re.I)
# The seam crops the A+ path writes beside the fixed modules (kit v33).
_SEAM = re.compile(r"^seam-\d+-\d+-\d+x$", re.I)


def canonical_name(src: Path) -> str:
    """main-06-faces-fixed.png -> main-06.png; edits/v2/main-06.png -> main-06.png;
    sec-03-v2.png -> sec-03-v2.png (a generation's version is its identity).

    The suffix is the source's own, verbatim. Kit v28 wrote every fix as .png,
    so a `sec-02.jpg` original was adopted into the round under its own name
    AND its fix landed beside it as `sec-02.png`: two files for one asset, and
    every name-based resolver kept serving the unfixed jpg (reproduced
    9 September 2026). One asset, one name, one file per round."""
    m = _FIX_SUFFIX.match(src.stem)
    return (m.group("base") if m else src.stem) + src.suffix


def is_evidence(name: str) -> bool:
    stem = Path(name).stem
    return bool(_EVIDENCE.match(stem) or _SEAM.match(stem))


def _gallery_files(folder: Path):
    """The adoptable image files in one folder: images, not hidden, not evidence."""
    if not folder.is_dir():
        return []
    return sorted(f for f in folder.iterdir()
                  if f.is_file() and f.suffix.lower() in IMG_EXT
                  and not f.name.startswith(".") and not is_evidence(f.name))


def rounds(product: Path):
    """[(1, edits/v1), (2, edits/v2), ...] in order."""
    edits = product / "edits"
    if not edits.is_dir():
        return []
    return sorted((int(d.name[1:]), d) for d in edits.iterdir()
                  if d.is_dir() and re.fullmatch(r"v\d+", d.name))


def adopted_set(product: Path):
    """name -> the ADOPTED copy of every gallery asset: the original in images/,
    replaced by its newest same-name copy from a round when one exists. An
    asset that exists only in images/ (generated after the last round) is in;
    an evidence file is never in. This is the one rule every room reads."""
    adopted = {f.name: f for f in _gallery_files(product / "images")}
    for _, d in rounds(product):
        for f in _gallery_files(d):
            adopted[f.name] = f
    return adopted


def product_dir(src: Path):
    """The product folder an image belongs to, or None for a loose file."""
    for a in src.resolve().parents:
        if (a / "images").is_dir() and (a / "status.md").is_file():
            return a
    return None


def open_round(product: Path) -> Path:
    """Open edits/v[N+1] as the ADOPTED SET (the Fixing Room's law, step 6).

    Kit v27 copied the previous round folder whole. Reproduced 9 September
    2026: Day 5 fixed the main into edits/v1, Day 6 generated eight secondaries
    into images/, and the next fix opened v2 holding only the main. The round
    is now built from adopted_set(): every asset, at its adopted version, and
    no evidence file. round.md records where each copy came from."""
    prev = rounds(product)
    n = (prev[-1][0] + 1) if prev else 1
    new = product / "edits" / f"v{n}"
    new.mkdir(parents=True)
    lines = [f"# edits/v{n}: the adopted set when this round opened", "",
             "| file | adopted from |", "|---|---|"]
    for name, src in sorted(adopted_set(product).items()):
        shutil.copy2(src, new / name)
        lines.append(f"| {name} | {src.relative_to(product)} |")
    # The A+ classes ride along, per mode, so the round is the full current set
    # (the Fixing Room's law: the latest edits/vN/ holds everything current).
    for mode in APLUS_MODES:
        modules = aplus_adopted_set(product, mode)
        if not modules:
            continue
        (new / "aplus" / mode).mkdir(parents=True)
        for name, src in sorted(modules.items()):
            shutil.copy2(src, new / "aplus" / mode / name)
            lines.append(f"| aplus/{mode}/{name} | {src.relative_to(product)} |")
    (new / "round.md").write_text("\n".join(lines) + "\n")
    return new


def default_dst(src: Path) -> Path:
    prod = product_dir(src)
    if prod is None:
        dst = src.with_name(src.stem + "-faces-fixed" + src.suffix)
        n = 2
        while dst.exists():
            dst = src.with_name(f"{src.stem}-faces-fixed-v{n}{src.suffix}")
            n += 1
        return dst
    rnd = open_round(prod)
    print(f"opened {rnd.relative_to(prod)} as the adopted set; the fix takes its canonical name there")
    ctx = aplus_context(src)
    if ctx:
        return rnd / "aplus" / ctx[1] / canonical_name(src)
    return rnd / canonical_name(src)


# ---- A+ modules: one canvas cut into strips ---------------------------------
APLUS_MODES = ("desktop", "mobile")
EDGE_MARGIN = 0.12    # of the module height: a head this close to an edge continues past it
NECK_RATIO = 0.8      # neck and upper shoulders below a head box, in head heights
TOP_RATIO = 0.5       # hair and crown above a head box that meets a module's top edge
SHOULDER_RATIO = 0.35 # how far shoulders run past the head box, per side, in head widths
SEAM_BAND = 300       # px of page around a seam in the evidence crops
EDGE_BAND_LIMIT = 20  # mean levels the render may differ from the base where the feather lands
_MODULE = re.compile(r"^(?:m|(?:amz-)?module-)0*(\d+)(?:[-_].*)?$", re.I)
LAST_JOINT = {}       # what the last joined run did (the box, the modules, the crops); for the log and the tests


def module_num(name):
    """m1.png -> 1, m07-desktop.jpg -> 7, amz-module-04-hero-desktop.jpg -> 4, main-06.png -> None."""
    m = _MODULE.match(Path(name).stem)
    return int(m.group(1)) if m else None


def aplus_context(src: Path):
    """(product, mode, module number) when src is an A+ module: a module-named
    file under aplus/export/<mode>/ or edits/vN/aplus/<mode>/ in a product
    folder. None for a gallery frame or a loose file, which never stack."""
    prod = product_dir(src)
    if prod is None:
        return None
    rel = src.resolve().relative_to(prod).parts
    ok = ((len(rel) == 4 and rel[0] == "aplus" and rel[1] == "export" and rel[2] in APLUS_MODES)
          or (len(rel) == 5 and rel[0] == "edits" and re.fullmatch(r"v\d+", rel[1])
              and rel[2] == "aplus" and rel[3] in APLUS_MODES))
    num = module_num(rel[-1]) if ok else None
    return (prod, rel[-2], num) if num else None


def aplus_adopted_set(product: Path, mode: str):
    """name -> the adopted copy of every module of one mode: the export in
    aplus/export/<mode>/, replaced by its newest same-name copy from a round's
    aplus/<mode>/ (a flat round file tagged -<mode> counts too). Seam crops and
    anything not named as a module are never in."""
    adopted = {f.name: f for f in _gallery_files(product / "aplus" / "export" / mode) if module_num(f.name)}
    for _, d in rounds(product):
        flat = [f for f in _gallery_files(d / "aplus") if f"-{mode}" in f.stem.lower()]
        for f in flat + _gallery_files(d / "aplus" / mode):
            if module_num(f.name):
                adopted[f.name] = f
    return adopted


def joined_modules(boxes, size, num, adopted):
    """The modules to stack for these head boxes, in page order: the module
    alone when every head sits clear of both edges, else with the neighbour(s)
    a head runs into (within EDGE_MARGIN of an edge, or past it)."""
    w, h = size
    margin = round(EDGE_MARGIN * h)
    need = {num}
    for (x1, y1, x2, y2) in boxes:
        if y1 <= margin:
            need.add(num - 1)
        if y2 >= h - margin:
            need.add(num + 1)
    have = {module_num(name): path for name, path in adopted.items()}
    return [(n, have[n]) for n in sorted(need) if n in have]


def joint_box(box, seams, size, module_h, grow=1.0):
    """Grow a head box (already in joined coordinates) to hold the person
    across the seam(s) it approaches: neck and shoulders below a head that
    meets a seam from above, crown above a head that starts at a seam,
    shoulders sideways, and at least EDGE_MARGIN of the module past every seam
    it meets. A box never ends on the seam. `grow` scales the vertical reach
    (the automatic retry passes 2)."""
    w, h = size
    x1, y1, x2, y2 = box
    hh, hw = y2 - y1, x2 - x1
    margin = round(EDGE_MARGIN * module_h)
    # read the seam relation off the box as DRAWN; growing y2 for one seam must
    # not make the same box look like a head starting at that seam
    down = any(y2 >= s - margin and y1 < s for s in seams)
    up = any(s - margin <= y1 <= s + margin and y2 > s for s in seams)
    for s in seams:
        if down and y1 < s:
            y2 = max(y2, s + margin)
        if up and y2 > s:
            y1 = min(y1, s - margin)
    if down:
        y2 += round(NECK_RATIO * hh * grow)
    if up:
        y1 -= round(TOP_RATIO * hh * grow)
    if down or up:
        x1 -= round(SHOULDER_RATIO * hw)
        x2 += round(SHOULDER_RATIO * hw)
    return (max(0, x1), max(0, y1), min(w, x2), min(h, y2)), (down, up)


def edge_band_disagreement(orig, edited, box, sides, band=FEATHER):
    """Mean levels the render differs from the base inside the box's edge
    band(s) on the grown side(s), where the feather lands. Quiet background
    reads near 0; a re-rendered shoulder reads high, and the fade would then
    print a soft line across the garment (the dark-hoodie failure)."""
    import numpy as np
    x1, y1, x2, y2 = box
    down, up = sides
    o = np.asarray(orig, dtype=int)
    e = np.asarray(edited, dtype=int)
    worst = 0.0
    if down:
        worst = max(worst, float(np.abs(o[max(y1, y2 - band):y2, x1:x2] - e[max(y1, y2 - band):y2, x1:x2]).mean()))
    if up:
        worst = max(worst, float(np.abs(o[y1:min(y2, y1 + band), x1:x2] - e[y1:min(y2, y1 + band), x1:x2]).mean()))
    return worst


def load_key():
    """OPENAI_API_KEY from the environment, else the nearest .env upward (the
    factory root .env is where /machines-check put it)."""
    if os.environ.get("OPENAI_API_KEY"):
        return
    for a in [Path.cwd()] + list(Path.cwd().parents):
        f = a / ".env"
        if f.is_file():
            for line in f.read_text(errors="ignore").splitlines():
                if line.strip().startswith("OPENAI_API_KEY="):
                    os.environ["OPENAI_API_KEY"] = line.split("=", 1)[1].strip().strip('"').strip("'")
                    return


def _edit(client, path: Path, prompt, quality, size):
    """One images.edit call on the file at `path`, returned on `size`'s grid."""
    r = client.images.edit(model="gpt-image-2", image=[open(path, "rb")],
                           prompt=prompt, size="auto", quality=quality, n=1)
    edited = Image.open(__import__("io").BytesIO(base64.b64decode(r.data[0].b64_json)))
    return edited.convert("RGB").resize(size, Image.LANCZOS)


def _composite(im, edited, boxes):
    """The render's boxes over the original, through the inward feather.
    Returns (result, allowed, inside, outside); refuses when outside is not 0."""
    w, h = im.size
    for b in boxes:
        edited = _tone_match(im, edited, b)
    # the mask IS the contract: white = the edit may land, black = original pixels.
    # Two masks, on purpose. `allowed` is the plain box union, the contract the
    # operator drew. `mask` is the feathered one the composite uses, CLIPPED to
    # `allowed`: kit v27 blurred outward, so a ring of up to FEATHER/2 px
    # outside every box took render pixels while the docstring promised
    # "original by construction" (measured 9 September 2026, 25,850 pixels on
    # a 256x256 test frame). The feather now falls off inward from the edge.
    allowed = Image.new("L", (w, h), 0)
    da = ImageDraw.Draw(allowed)
    mask = Image.new("L", (w, h), 0)
    d = ImageDraw.Draw(mask)
    for (x1, y1, x2, y2) in boxes:
        da.rectangle((x1, y1, x2 - 1, y2 - 1), fill=255)   # [x1, x2) x [y1, y2)
        d.rounded_rectangle((x1, y1, x2 - 1, y2 - 1),
                            radius=min(30, (x2 - x1) // 4), fill=255)
    mask = mask.filter(ImageFilter.GaussianBlur(FEATHER / 2))
    mask = Image.composite(mask, Image.new("L", (w, h), 0), allowed)

    result = Image.composite(edited, im, mask)
    inside, outside = outside_changed(im, result, allowed)
    if outside:
        sys.exit(f"REFUSED: {outside} pixels changed outside the head boxes; nothing written")
    return result, allowed, inside, outside


def _save(img, dst: Path):
    # The fix is written in the source's own format so the round holds ONE file
    # per asset. JPEG recompresses on save; 95 keeps the repaired faces intact.
    save_kw = {"quality": 95} if dst.suffix.lower() in (".jpg", ".jpeg") else {}
    img.save(dst, **save_kw)


def run(src: Path, boxes, quality="high", out: Path | None = None, prompt: str = PROMPT):
    from openai import OpenAI
    client = OpenAI()
    ctx = aplus_context(src)
    if ctx:
        prod, mode, num = ctx
        adopted = aplus_adopted_set(prod, mode)
        cur = adopted.get(src.name)
        if cur is not None and cur.resolve() != src.resolve():
            print(f"using the adopted copy {cur.relative_to(prod)} (newer than {src.relative_to(prod)})")
            src = cur
        parts = joined_modules(boxes, Image.open(src).size, num, adopted)
        widths = {Image.open(p).size[0] for _, p in parts}
        if len(parts) > 1 and len(widths) == 1:
            return run_joined(client, prod, mode, num, parts, boxes, quality, out, prompt)
        if len(parts) > 1:
            print(f"modules differ in width ({sorted(widths)}); not one canvas, so fixing {src.name} alone")
    im = Image.open(src).convert("RGB")
    w, h = im.size
    for (x1, y1, x2, y2) in boxes:
        if x1 < 0 or y1 < 0 or x2 > w or y2 > h:
            sys.exit(f"box ({x1},{y1},{x2},{y2}) falls outside the {w}x{h} image")
    edited = _edit(client, src, prompt, quality, (w, h))
    result, allowed, inside, outside = _composite(im, edited, boxes)
    dst = out or default_dst(src)
    _save(result, dst)
    print(f"{inside} pixels changed inside the boxes, {outside} outside")
    return dst


def run_joined(client, prod, mode, num, parts, boxes, quality, out, prompt):
    """The cross-module fix. `parts` is [(module number, adopted path)] in page
    order, two or three of them, the fixed module among them. One edit on the
    joined image, one composite, a re-cut at the original boundaries."""
    import tempfile
    ims = [(n, p, Image.open(p).convert("RGB")) for n, p in parts]
    ims_by = {n: im for n, _, im in ims}
    w = ims[0][2].size[0]
    offsets, y = {}, 0
    for n, _, im in ims:
        offsets[n] = y
        y += im.size[1]
    joined = Image.new("RGB", (w, y))
    for n, _, im in ims:
        joined.paste(im, (0, offsets[n]))
    seams = [offsets[n] for n, _, _ in ims[1:]]
    jh = joined.size[1]
    names = "+".join(f"m{n}" for n, _, _ in ims)
    print(f"the head meets a module edge: joined {names} ({w}x{jh}) and fixing across the seam")

    shifted = [(x1, y1 + offsets[num], x2, y2 + offsets[num]) for (x1, y1, x2, y2) in boxes]
    for (x1, y1, x2, y2) in shifted:
        if x1 < 0 or y1 < 0 or x2 > w or y2 > jh:
            sys.exit(f"box ({x1},{y1},{x2},{y2}) falls outside the joined {w}x{jh} image")
    tmp = Path(tempfile.mkdtemp()) / f"joined-{names}.png"
    joined.save(tmp)

    grow, attempt, note = 1.0, 0, ""
    while True:
        attempt += 1
        jboxes, sides = zip(*[joint_box(b, seams, (w, jh), ims_by[num].size[1], grow) for b in shifted])
        edited = _edit(client, tmp, prompt, quality, (w, jh))
        band = max(edge_band_disagreement(joined, edited, b, s) for b, s in zip(jboxes, sides))
        if band > EDGE_BAND_LIMIT and attempt == 1:
            note = (f"the feather landed on changed content (the render differs from the base by "
                    f"{band:.0f} levels in the box's edge band); one automatic retry with the box "
                    f"grown by the neck and shoulder height")
            print(note)
            grow = 2.0
            continue
        break
    result, allowed, inside, outside = _composite(joined, edited, list(jboxes))

    # re-cut at exactly the original boundaries; write every module the box union touches
    if out is not None:
        dest = {num: out}
        for n, p, _ in ims:
            dest.setdefault(n, out.parent / p.name)
    else:
        rnd = open_round(prod)
        print(f"opened {rnd.relative_to(prod)} as the adopted set; the fixed modules take their own names in aplus/{mode}/")
        (rnd / "aplus" / mode).mkdir(parents=True, exist_ok=True)
        dest = {n: rnd / "aplus" / mode / canonical_name(p) for n, p, _ in ims}
    touched = []
    for n, p, im in ims:
        y0, y1 = offsets[n], offsets[n] + im.size[1]
        if not allowed.crop((0, y0, w, y1)).getbbox():
            continue
        _save(result.crop((0, y0, w, y1)), dest[n])
        touched.append((n, dest[n]))
    written = ", ".join(f"{d.name} {ims_by[n].size[0]}x{ims_by[n].size[1]}" for n, d in touched)
    print(f"{inside} pixels changed inside the joint box, {outside} outside (technical only)")
    print(f"joint box {list(jboxes)} on the joined image; re-cut at the module boundaries: {written} in {touched[0][1].parent}")

    # the continuity read, produced for the eyes: the page rebuilt from the fixed set
    folder = touched[0][1].parent
    page_set = {n: p for n, p in ((module_num(f.name), f) for f in _gallery_files(folder)) if n}
    for n, d in touched:
        page_set[n] = d
    page_ims = [(n, Image.open(page_set[n]).convert("RGB")) for n in sorted(page_set)]
    pw = max(im.size[0] for _, im in page_ims)
    page_off, y = {}, 0
    for n, im in page_ims:
        page_off[n] = y
        y += im.size[1]
    page = Image.new("RGB", (pw, y), "white")
    for n, im in page_ims:
        page.paste(im, (0, page_off[n]))
    shift = page_off[ims[0][0]] - offsets[ims[0][0]]
    ux1 = min(b[0] for b in jboxes)
    uy1 = min(b[1] for b in jboxes) + shift
    ux2 = max(b[2] for b in jboxes)
    uy2 = max(b[3] for b in jboxes) + shift
    crops = []
    for (a, _), (b, _) in zip(touched, touched[1:]):
        s = page_off[b]
        band_im = page.crop((0, max(0, s - SEAM_BAND // 2), pw, min(page.size[1], s + SEAM_BAND // 2)))
        two_x = folder / f"seam-{a}-{b}-2x.png"
        band_im.resize((band_im.size[0] * 2, band_im.size[1] * 2), Image.LANCZOS).save(two_x)
        cw, ch = ux2 - ux1, uy2 - uy1
        ctx_box = (max(0, ux1 - cw // 2), max(0, uy1 - ch // 2), min(pw, ux2 + cw // 2), min(page.size[1], uy2 + ch // 2))
        one_x = folder / f"seam-{a}-{b}-1x.png"
        page.crop(ctx_box).save(one_x)
        crops += [two_x, one_x]
        print(f"evidence: {two_x} (the seam band at 2x), {one_x} (1:1, the whole person)")
    print("READ BOTH before calling this done: head, neck, hair and lighting must be continuous across the seam. "
          "The counts above are technical. A visible seam or an unnatural body join FAILS this fix even at "
          "0 outside; the answer is a wider joint box (grow it by the neck and shoulder height) and another run.")
    LAST_JOINT.clear()
    LAST_JOINT.update({"modules": [n for n, _, _ in ims], "box": tuple(jboxes[0]), "boxes": list(jboxes),
                       "attempts": attempt, "note": note, "written": [d for _, d in touched], "evidence": crops})
    return dest[num]


def outside_changed(original, result, allowed):
    """(inside, outside) pixel counts that differ, measured against the plain
    box union, never against the feathered mask the composite was built from.
    Measuring against the blurred mask counts every pixel the blur reached as
    inside, which is how a leak reports as zero."""
    import numpy as np
    a = np.asarray(original.convert("RGB"), dtype=int)
    b = np.asarray(result.convert("RGB"), dtype=int)
    changed = np.abs(a - b).max(axis=2) > 0
    box = np.asarray(allowed, dtype=bool)
    return int(changed[box].sum()), int(changed[~box].sum())


def main():
    args = sys.argv[1:]
    if not args or "--boxes" not in args:
        sys.exit(__doc__)
    src = Path(args[0])
    if not src.is_file():
        sys.exit(f"no such image: {src}")
    boxes = parse_boxes(args[args.index("--boxes") + 1])
    quality = args[args.index("--quality") + 1] if "--quality" in args else "high"
    out = Path(args[args.index("--out") + 1]) if "--out" in args else None
    prompt = PROMPT
    if "--prompt-file" in args:
        prompt = Path(args[args.index("--prompt-file") + 1]).read_text()
    load_key()
    if not os.environ.get("OPENAI_API_KEY"):
        sys.exit("OPENAI_API_KEY is not set. The clinic runs on Machine 2; add the key to the .env.")
    dst = run(src, boxes, quality, out, prompt)
    print(f"wrote {dst}")


if __name__ == "__main__":
    main()

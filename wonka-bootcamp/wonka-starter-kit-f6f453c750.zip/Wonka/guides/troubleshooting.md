# Troubleshooting

The most likely failures, in roughly the order people hit them across the ten days. Each one:
symptom, cause, fix.

Before anything else, two moves solve most of what lands here. Run `/machines-check`. Quit Claude
completely and reopen it. Then come back to this list.

---

## Setup and the kit (Day 1)

### 1. Wonka sounds like a generic chatbot

**Symptom:** flat answers, no character, no mention of the Factory.
**Cause:** the kit folder is not actually loaded, so `CLAUDE.md` and the character file never reached
Claude.
**Fix:** in Claude Desktop, confirm you are in the **Code** tab and the folder picker at the bottom
shows `Wonka`. Re open the folder if not. Then start a NEW conversation, because the
character loads at session start. If he drifts mid session, say:
`Reload .claude/wonka-character.md and stay in character.`

### 1b. Wonka sounds like somebody else

**Symptom:** he answers in a different character, or opens with a greeting protocol that is not his.
Common if you keep Wonka inside a folder for a wider set of AI assistants.

**Cause:** Claude Code loads `CLAUDE.md` from every folder ABOVE the one you opened, in full, and
concatenates them. Two files that both say "at the start of every conversation, do this" are a
genuine contradiction, and the documentation is blunt about what happens: Claude may pick one
arbitrarily. Wonka's file is read last, which helps, but it does not settle it.

**`/machines-check` catches this early:** its identity check walks the parent folders, flags any
`CLAUDE.md` above the Factory, and offers to write the exclude for you. Run it if you suspect this.

**Fix, and this one is definitive.** Tell Claude Code to skip the parent file. Create
`.claude/settings.local.json` inside your Wonka folder:

```json
{
  "claudeMdExcludes": ["**/NameOfTheParentFolder/CLAUDE.md"]
}
```

Patterns are matched against the full path, so the folder name is usually enough. Start a new
conversation afterwards. Your own `~/.claude/CLAUDE.md` is untouched by this and keeps applying,
which is what you want.

**To confirm it worked:** run `/context` and look at **Memory files**. The parent should be gone
from the list. That is the check, not how the next answer sounds.

**The other fix is to move the folder** so Wonka is a sibling of the other assistants rather than
sitting inside one of them. Nothing above him, nothing to inherit.

### 2. Slash commands do nothing

**Symptom:** you type `/creative-brief` and get a generic answer, or nothing skill shaped happens.
**Fix:** type the command as its own message, starting with the slash, exactly as named:
`/meet-my-product`, `/creative-brief`, `/main-image`. Describing it in prose ("run the brief thing")
sometimes works. The slash always works. If the command is not recognized at all, the
`.claude/skills/` folder did not come along. Re download the kit and re open it.

### 3. I cannot see the .claude folder

**Symptom:** the guides mention `.claude/` but your file browser does not show it.
**Cause:** folders starting with a dot are hidden by default.
**Fix:** Mac: in Finder, press **Cmd+Shift+.** (period). Windows: File Explorer, View tab, check
"Hidden items". Or skip the file browser entirely:
`Show me the contents of .claude/wonka-character.md`.

### 4. Genrupt MCP is not listed, or not responding

**Symptom:** Wonka says the Genrupt connection is missing, or calls fail.
**Fix, in order:** (1) Quit Claude COMPLETELY (Mac: Cmd+Q. Windows: quit from the tray icon) and
reopen, then run `/machines-check`. A full restart fixes most MCP visibility issues. (2) Check the
connector entry against Genrupt's current official instructions (see `mcp-setup-guide.md`, Part 1).
(3) Re generate the API key in Genrupt and re enter it. (4) Log in to genrupt.com in your browser
once, then retry. Still stuck: post the exact error in the group if your ticket includes one, or
email support. Genrupt has a fallback (Wonka generates via OpenAI directly), so nothing here blocks
the bootcamp.

---

## Research (Day 2)

### 5. The ASIN is valid, but it is the WRONG product

**Symptom:** the research reads oddly. Reviews mention features your product does not have,
competitors feel adjacent, the persona does not match anyone you have ever sold to.
**Cause:** a transposed or mistyped ASIN. This is the quiet one, because **a swapped ASIN passes
every format check.** Ten characters, starts with B0, looks perfect, and belongs to a stranger's
product. Format validation cannot catch it. Nothing downstream can either: the brief, the images and
the Tasting Room will all faithfully serve the wrong product.
**Fix:** the guard is the **title read back**. Wonka reads the listing title back to you before he
creates any folder, and your job is to actually read it rather than nodding it through. If you are
already deep in a run, say:
`Read back the exact listing title on file for this product.`
If it is not yours, stop. Do not patch the ASIN in place and continue, because research files built
on the wrong listing are contaminated all the way through. Start the product again with the correct
ASIN and delete or clearly park the wrong folder.

### 6. Only a handful of reviews, and they are all positive

**Symptom:** you can only find about eight reviews, they read like a highlight reel, and the pain
point map comes out thin and cheerful.
**Cause:** the **logged out review cap**. A public listing page shows only a small, positive skewed
sample and hides the critical ones. Research built on that sample tells you what is already working
and nothing about what is broken, and the broken part is where your images win.
**Fix:** log in to amazon.com, open the reviews page, and pull them properly: sort by **Most recent**,
then filter by **Critical**, and take roughly the top ten positive and the top ten critical. For your
own product, Seller Central gives you the full set. Critical reviews are the gold. If you genuinely
cannot get them, say so and Wonka records a waiver in writing, along with the weaker pain point map
that comes with it. What is not acceptable is a thin basket that nobody flagged.

### 7. Competitor prices are missing, or the page hides them

**Symptom:** the pricing landscape section is empty, or a competitor listing shows "cannot be shipped
to your location" instead of a price.
**Cause:** **geo blocked pricing**. Marketplaces hide prices and shipping for listings that cannot
ship to where you are browsing from. The listing still renders, so it looks like the data simply is
not there.
**Fix:** you supply what the page will not. Tell Wonka the prices you see from your own market, or
have him record the band as `estimated` and label it as such in `research/competitors.md`. Price band
matters because it sets how premium your images have to look, so an empty section is never
acceptable. An honest `estimated` is.

### 8. Competitor search returns mostly the wrong products

**Symptom:** you search your niche phrase and the results are accessories, adjacent formats,
different product types, and a few things that make no sense at all.
**Cause:** **search noise**. Amazon search is not a niche filter. Most of what comes back is off
niche by design, and picking from the top of the page gives you a competitor set that shares a
keyword with you and nothing else.
**Fix:** pick on product type, not on ranking. Choose the best sellers that are genuinely the same
kind of product as yours, the ones actually taking your sales, and expect the image level relevance
check to reject an impostor or two after Wonka looks at their galleries. That rejection is the system
working. If your set drops below three real rivals, widen the search phrase and try again rather than
padding it with near misses. A competitor set of the wrong products produces confident, useless table
stakes.

---

## Generation (Days 3 and 5 to 7, and Day 10)

### 9. Generated images show the WRONG product

**Symptom:** wrong colors, a part count that does not match (three tiers on a four tier machine),
glossy plastic where the real base is stainless steel, a label or buttons that never existed, or a
tabletop appliance rendered at wedding catering scale.
**Cause:** the Mold is not actually locked, or generation ran without it.
**Fix:** STOP generating. Do not spend more credits on a broken lock. Say:
`The mold isn't holding. Re-lock the product reference and give me a fresh smoke test.`
Only continue batching after a smoke test image passes YOUR eyes. This is exactly why the smoke test
is non skippable. And the reference is built from YOUR photos. If it was built from listing imagery
as a recorded fallback, expect weaker accuracy and check harder.

### 10. It was right, and then it REVERTED to the wrong product

**Symptom:** the smoke test passed, the first images were accurate, and then a later image, a later
slot, or the next room comes back with the old wrong product: a shape you fixed, a material you
corrected, a part count you already dealt with.
**Cause:** the lock silently stopped being applied. A re plan, a fresh planning pass, or a tool side
default can drop the approved reference and quietly fall back to whatever the model would have
guessed. The trap is the word **approved**. Approved is a status the tool writes. It is not evidence
that this generation used it.
**Fix, in order:**

1. **Stop the batch.** Every further image is spending against a broken lock.
2. Ask for proof rather than status:
   `Don't tell me it's approved. Generate one product-only control image on the current settings and show me.`
3. If the control is wrong, re lock the reference from your real photos and run a fresh smoke test
   before anything else.
4. **Re generate only the affected slots.** Keep the images that were right. Nothing needs to be
   thrown away wholesale.
5. Never repair a reverted product with an edit. Wrong product is structural, and structural means
   regenerate.

If it happens twice on the same product, that is a process lesson for the Improvement Log: "verify the lock with a control
image before every batch, not just the first one." That is exactly the kind of process lesson
`/improvement-loop` exists to record.

### 11. Text in images is garbled or misspelled

**Symptom:** broken letters, melted words, a brand name spelled almost right.
**Cause:** image models redraw text unreliably, especially during heavy edits.
**Fix:** do not try to edit the text into shape. Garbled text means regenerate. Say:
`Route this image to regenerate with a tighter brief; the text is garbled.`
For a single wrong word on an otherwise good image, a surgical text swap usually works: `/fix` and
describe the exact word change.

### 12. The image is too texty, or keeps failing the squint test

**Symptom:** legibility keeps failing even after fixes.
**Cause:** too many labels competing. Shrinking and nudging never fix crowding.
**Fix:** subtraction, not adjustment. `Remove the two weakest labels and enlarge the headline.`
One dominant message wins at 160 pixels. Fewer words means bigger words means a passing image.

### 13. Variation images look inconsistent

**Symptom:** your color, size or bundle images do not match each other: different light, angle, or
staging across the set.
**Cause:** the Mold was not held for all of them, so the model re staged each one independently.
**Fix:** the same fix that keeps your main image accurate keeps your variations consistent. Tell
Wonka `These variations aren't a matched set. Re-generate them against the locked Mold so only the variable changes.`
If a variation is a genuinely different physical product rather than a different color, it needs its
own Mold and its own smoke test. Say so and Wonka will set that up.

### 14. An A+ module is cluttered, or fails compliance

**Symptom:** a module has competing messages, tiny text, or renders a badge or third party logo as a
graphic.
**Fix:** A+ follows the same laws as every other asset. For clutter:
`Module [N] has too many messages. Cut it to one dominant message and enlarge the text.`
For a rendered badge or logo, which is a compliance fail:
`Remove the badge/logo graphic from module [N]; only real claims from the approved list.`
A comparison module is fine and often high converting, as long as every row is true, provable, and
about your own product. A wall of tiny icons is not fine.

---

## Testing and shipping (Days 8 and 9)

### 15. Tasting Room trouble (interrupted run, weak verdict, missing key)

**Three symptoms, three fixes:**

- **The tasting run stopped midway** (network hiccup, rate limit, closed laptop): run the SAME
  `/tasting-room` command again. It resumes where it left off. It does not start over and it does not
  double spend. Losing a partial run is not a thing here.
- **The Tasting Card shows a parse rate warning:** a chunk of the tasters' responses could not be
  scored, so the verdict rests on fewer votes than the panel size suggests. Treat that card as weaker
  evidence. Re run the round before acting on it, and if the warning repeats, tell Wonka so he can
  tighten the panel setup.
- **The run will not start at all, or "no API key":** the OpenAI key is missing or not loaded. Run
  `/machines-check`, and set the key per `mcp-setup-guide.md`, Part 2 (a `.env` file at the factory
  root is the easy path). If the key exists but calls fail, check billing credit and the one time
  organization verification at platform.openai.com.

### 16. I do not have Brand Registry, so I have no Manage Your Experiments

**Symptom:** the A/B path taught on Day 10 is unavailable for your account.
**Fix:** use the direct swap path. Upload the Tasting Room winner as your new main image, record the
swap date plus your before metrics (sessions, unit session percentage) in
`factory/Improvement Log.md`, and compare after a few weeks. It is weaker evidence than a
controlled A/B, with no control group, and price, ads, seasonality and competitors move the same
numbers. Label it as what it is. Your Tasting Round already de risked the change, and your
package is ready to upload either way. Consider starting Brand Registry enrollment in parallel. It
unlocks the proper A/B for product two.

### 17. Costs anxiety: what should this actually cost?

Genrupt access is included with your ticket. You bring your own Claude Pro or Max subscription and a
few dollars of OpenAI credit, which covers both the edits and the Tasting Rounds.

Typical spend for ONE product through the full line during the bootcamp:

| Item | Typical cost |
|---|---|
| Genrupt (generation, smoke test, full package) | $0 during the bootcamp, access included with your ticket |
| Tasting Room races via OpenAI (per race) | a few dollars each, two races in the bootcamp (one round: main + gallery); an optional Round 2 doubles it |
| Surgical fixes via OpenAI (per edit) | about $0.02 to $0.10, a few dollars in total |
| Claude subscription | your own Pro or Max, separate from tool costs |

And the money rule: Wonka states a cost line and waits for one go ahead before ANY paid run, edits
and tastings included. If money moved without you approving it, that is a bug. Tell him so.

---

## Anything, any day

### 18. Claude usage limits (Pro versus Max)

**Symptom:** "You've reached your usage limit" mid session.
**Fix:** limits reset every few hours. Note where the line stopped (`status.md` has it) and resume
after the reset. Wonka picks up exactly where he left off. Hitting limits often? Days 5 to 7 are the
heavy ones, since that is where the whole package gets generated and inspected. Run them in a fresh
usage window, or upgrade to Max for more headroom. The bootcamp fits comfortably in Pro for most
people.

### 19. Where are my files? Wonka says a file exists but I cannot find it

**Fix:** everything lives inside the kit folder. Products:
`factory/Products/[product-name]/` (your inputs in `1-inputs/`, photos and the Reference Sheet in
`2-reference/`, raw images in `images/`, edit rounds in `edits/vN/`, the approved package in `final/`,
scorecards in `scorecards/`, Tasting Cards in `tests/`, the live listing images you downloaded in
`incumbent/`). Brand kit: `factory/Brand/`.
Reports: `factory/Factory Log/`. Ready to ship exports: `output/`. Fastest way:
`Give me the full path to [the thing], and open its folder.`
And remember issue 3: dot folders are hidden.

### 20. Wonka refuses to do something

**Symptom:** he declines, charmingly but firmly. Skip the research, invent a badge, batch without a
smoke test, put people in the main image, build a variation you do not sell.
**Cause:** not a bug. The refusals ARE the method.
**Fix:** if you genuinely need an exception (no time for photos, so use listing images), say it
explicitly and he proceeds WITH the risk recorded in your files. If he refuses something that seems
clearly wrong to refuse, ask:
`Which rule are you applying here, and where is it written?`
Either you learn the reason, or you find a real bug worth reporting.

### 21. A session starts and Wonka has "forgotten" my product

**Symptom:** new conversation, no memory of the last session.
**Cause:** the folder was not open in this session, or `status.md` was never updated.
**Fix:** confirm the folder is open (issue 1), then say:
`Read factory/Products/ and each status.md, and tell me where every product stands.`
If the tracker was not updated after the last day's work, tell him what happened and have him update
it now. The rule that prevents this: every station updates `status.md` when it finishes.

### 22. Everything is broken and I am behind

Breathe. The bootcamp is built so a lost day is recoverable: every station's output is a file on
disk, so nothing you completed is ever lost. Post in the group if your ticket includes one, or email
support, with (a) the day you are on, (b) the exact error or symptom, (c) a screenshot. Then do the
smallest next step: one product, one station, one artifact. The Factory does not care that you were
late. It cares that the line moves.

# Day 1: The Front Gate

Today you meet your Creative Director, tour the factory he runs, cut five keys, warm up his two
machines, register your product at the gate, and pack the basket it walks in with.

**Do the first two lessons before you install anything.** They ask nothing of you. You watch, you
meet Wonka, you see all ten rooms, and then the setup in Lesson 3 has a point. Nothing here is hard.
One thing is easy to skip and expensive later, the OpenAI organization verification, so it is
flagged everywhere.

By the time you close the laptop tonight, the factory is live and your product is already
registered at the gate.

**The sentence for the day: you are not learning a tool today, you are hiring somebody.**

## What you will have by the end of today

- A clear picture of who Wonka is, where he lives, and what he does without asking you
- Claude installed, with the kit folder open, and Wonka answering in character
- A Genrupt account, activated (usage included with your ticket)
- An OpenAI API key created, funded, and its one time organization verification underway or done
- Your pilot product chosen and photographed properly
- Both machines connected and verified by Wonka himself, with your credit fuel gauge read out loud
- Your factory's First Candy printed: a welcome card that cost a few cents and proved your whole
  image pipeline works
- Your product registered with `/meet-my-product`: its folder open inside the factory, the owner
  interview started, and the shopping list in your hands
- The basket filled, or filling tonight: reviews, competitors and notes in `1-inputs/`, photos and
  brand files in `2-reference/`

**Time needed:** about two hours, and most of it is waiting for downloads and taking photos. The
video is 29 minutes across four lessons.

**A word on cost before you start.** Genrupt usage is included with your ticket. You bring your own
Claude Pro or Max subscription, which is separate, and your own OpenAI credit for the image edits
and the Tasting Rooms: cents per edit, a few dollars per race, and the bootcamp runs two races (one
Tasting Round: the main race and the gallery race). Ten to twenty dollars covers it. That is the entire bill. There is
no survey tool to buy and no research extension to install, because the Tasting Room runs inside the
factory and the Research Room runs on your own listing, reviews, and competitors.

---

---

## Lessons 1 and 2: Meet Wonka, and meet the factory

*Watch only, about 13 minutes. Nothing to do yet.*

**Do not install anything yet.** Lessons 1 and 2 are the two lessons where you sit back.

### Who you just hired

The single most useful idea in the whole bootcamp, and the one that confuses everybody at first:

> **Your employee is a folder.**

Not a metaphor. It is a folder on your Desktop. Inside it there is a character file that says who he
is, a set of skills that are things he knows how to do, and a factory of folders where his work
lives. **The folder you open in Claude Code is the employee you are talking to.** Open the Wonka
folder, you are talking to Wonka. That is the whole trick.

No app to log into. No dashboard, no website, no seat to buy. Copy the folder and you copy your
Creative Director.

The other thing to take from Lesson 1 is the working relationship, because it decides how this feels
all week:

| He does this on his own | He stops and waits for you |
|---|---|
| Research and analysis | Anything that spends money, with the cost shown first |
| Generating from an approved brief | Approving the brief itself |
| Quality checks on everything he makes | Choosing which candidates go to testing |
| Fixing small defects | Picking the final winner |
| The paperwork and the provenance | Anything that touches your live listing |

You talk to him the way you talk to your photographer and your graphic designer. **He does the work.
You approve it.**

### The building you now own part of

Ten rooms, one per day. Underneath them, five stations that are the actual method: **Research,
Brief, Invent, Inspect, Prove.**

| Day | Room | What comes out |
|---|---|---|
| 1 | The Front Gate | A live factory, both machines warm |
| 2 | The Research Room | What your buyers actually complain about |
| 3 | The Creative Brief | Your whole product page, planned |
| 4 | The Reference Room | The machines know YOUR product, proved by a test |
| 5 | The Main Image Room | A tray of candidates, your pick, and the quality loop |
| 6 | The Secondary Images Room | The gallery, built as a team |
| 7 | The A Plus Room | The second page under your bullets |
| 8 | The Tasting Room | A hundred tasters vote, twice |
| 9 | The Variations Room | One winner becomes a shelf |
| 10 | The Improvement Loop | Ship, and the factory gets smarter |

Two things repeat through the whole building. **The quality loop**, learned properly on Day 5 and
then running every day after. And **the learning loop**, which is why your second product costs a
fraction of your first.

---

---

## Lesson 3: The five keys

*About 45 minutes, most of it waiting.*

### Key 1: Claude Pro or Max, plus the app

The room your employee lives in. The free plan does not give you what this bootcamp needs, so
upgrade before going further. Install Claude Desktop.

Claude Code in the terminal works identically if you prefer it.

### Key 2: The kit, on your Desktop

1. Download `wonka-starter-kit.zip` from today's room
2. Unzip it to your **Desktop**, not Downloads
3. Open Claude Desktop, go to the **Code** tab, and open the `Wonka` folder
4. **Do not chat yet.** That is Part 3

Have a look inside while you are there. `.claude/` holds his character and his fifteen skills.
`factory/` is where all his work will live. `guides/` is this. That folder is the employee.

### Key 3: Your Genrupt account (signup only today)

Genrupt is the image machine, and the reason it gets a dedicated machine instead of any generic
image AI is one thing: **it locks your real product.** Generic models will happily draw something
that resembles your item. On Amazon that is worthless.

Use the bootcamp link from your welcome email or today's room, because that is what attaches your
included access. Confirm your email, sign in once, and leave. You connect it in Part 3.

Click by click: `downloads/genrupt-account-setup.md`.

### Key 4: Your OpenAI API key, and the verification that bites later

One key, two rooms: the Fixing Room where edits cost cents, and the Tasting Room where about a
hundred tasters cost a few dollars.

1. Go to **platform.openai.com** and sign in. This is a different thing from a ChatGPT subscription
2. **API keys**, then **Create new secret key**. Copy it immediately, it is shown once
3. Save it somewhere safe. Never paste it into a chat, a screenshot, or a screen recording
4. **Start organization verification NOW.** Settings, Organization, Verify. ID and a selfie check
5. Load **$10 to $20** of credit

> **Read this twice.** Until verification clears, your key works perfectly for text and silently
> refuses to make images. Everything looks fine. People skip it, then discover it on Day 5 with a
> main image batch stopped. It is the only item on this list that punishes you days later. Start it
> today, in this session, before you close the tab.

Click by click, plus an error table: `downloads/openai-key-and-verification-walkthrough.md`.

### Key 5: Your pilot product, and real photos of it

Pick **one** product. Not your catalogue. One you actually care about moving.

Then photograph it. Six shots, your phone, plain background, daylight, about twenty minutes:

1. **Front**
2. **Back.** Do not skip it. Skip it and the model invents one
3. **Left side**
4. **Right side**
5. **Top down.** This is what fixes proportions
6. **Your hand holding it.** Scale is the single thing AI gets most wrong about products

Plus two that pay for themselves: a **label close up** and a **texture close up**.

### And your PACKAGING, which most people forget

Photograph the box, pouch, sleeve or tin the same way: **front, back, and the label panel**.

This is not an optional extra and it is not the same as the product shots. Packaging travels in its
own separate channel inside the machine, and it drives one of the ways your hero image can be
built: a hero showing the real retail box is a legitimate and often high-converting strategy, and it
is simply unavailable to you if the box is not in the folder.

If your product genuinely has no packaging a buyer would ever see, say so and skip it. Just skip it
on purpose rather than by forgetting.

One rule explains all eight: **whatever your photos do not show, the model will invent.** Not maybe.
Always.

Full one pager: `downloads/product-photo-shot-list.md`.

**If the product is not in your hands.** Use your listing gallery images plus photos customers
posted inside their reviews, and tell Wonka plainly that is what they are. He records it as a real
limitation instead of pretending the reference is complete, and the smoke test on Day 4 becomes non
negotiable. Jay is in exactly this position with the demo product all week and shows you what it
costs him rather than editing around it.

---

---

## Lesson 4: Wire the machines, print the First Candy

*About 20 minutes, then 30 to 40 for the basket.*

### Say hello (this is also your kit test)

Open the `Wonka` folder in Claude's Code tab, start a **new** conversation, and type:

```
Hello! Who are you and what is this place?
```

He should answer in character, tell you the factory is empty, and point at the next step.

**If he answers like normal Claude, your folder is not really loaded.** Close it, reopen the
`Wonka` folder, and start a new conversation. This is the single most common Day 1
issue.

### Try to skip the line

Worth doing once, because it shows you what you actually bought:

```
Skip all the research stuff. Just make me 8 beautiful images for my
product right now.
```

He will refuse, politely and completely. Every generic AI tool would have handed you eight shiny
useless images. That refusal is the difference between a tool and an employee.

### Wire machine 1: Genrupt

Genrupt connects through an **MCP**, which means Wonka can operate the tool himself from inside your
chat. No tab switching, no copy paste. He drives.

Genrupt keeps the current connection values in their own docs. In Claude: **Settings**, then
**Connectors**, add it with those values.

> **Then quit Claude completely and reopen it.** Not just the window. Cmd+Q on Mac, tray icon quit
> on Windows. Nine out of ten missing connectors are exactly this.

### Wire machine 2: your OpenAI key

Ask Wonka to store it for you rather than pasting it into a settings page:

```
Here is my OpenAI API key, please store it in the kit's .env file: [your key]
```

He writes it and confirms. He will never print it back at you: when he checks it he reports only
that it is present, its length, and its last four characters.

### Let him check his own machines

The settings say connected. This factory has a rule you will hear all week: **we do not trust
labels, we verify.**

```
/machines-check
```

He runs a real handshake against Genrupt, reads your credit balance as a fuel gauge, checks the
OpenAI key is present, and gives a verdict per machine: PASS, FAIL, or SKIPPED, with the exact fix
attached to any failure.

**Every "it is not working" problem this bootcamp will ever hand you starts here.**
`/machines-check` first, then debug.

### The First Candy

A handshake cannot prove OpenAI will let your key actually make an image. Only generating can. So
when he offers it:

```
Yes, print the First Candy.
```

A few cents, one small welcome card, saved to `output/first-candy.png`. It proves the whole pipeline
end to end: key, billing, verification, generation.

**If it fails here, that is the good outcome.** Day 1, with the fix one click away, instead of Day 5
with a batch stopped. Almost always it is verification. Wonka names which machine is cold and what
to check.

---

### Register your product and pack the basket

Tomorrow your product walks through the gate, and Wonka will not move until he has material. So the
last stop of today is registering the product. One command:

```
/meet-my-product
```

Five things happen, and then he stops:

1. **He asks for the product identity in one message:** ASIN, full Amazon URL, marketplace, brand,
   and your niche in your own words ("chocolate fountain", "garlic press"). Answer all of it.
2. **He reads your listing title back to you.** Confirm it is really your product. One transposed
   character in an ASIN registers a stranger's listing, and this read-back is what catches it.
3. **He opens your product's folder inside the factory:** `1-inputs/` for your files,
   `2-reference/photos/` for your product photos, `2-reference/brand/` for your logo and brand
   files, plus the rooms every later day writes into. From now on everything about this product
   lives here. No Desktop folders, no hunting for files.
4. **He starts the owner interview:** what you know works, what must appear in the images, what to
   avoid. Answer from what you actually know. **"I don't have that" is a real answer** and Wonka
   records it rather than inventing it.
5. **He hands you the shopping list**, each item pointing at its destination folder, and stops.
   Day 1 ends there. Day 2 opens as an interview about what you brought.

Then fill the basket tonight, straight into the folders he opened:

**1. Your listing** into `1-inputs/`: the URL or the ASIN in a text file.

**2. `1-inputs/reviews.txt`. The most important file in the basket.** About 10 positive and about
10 critical.

> **Be logged in on amazon.com when you copy them.** Logged out, the page shows a handful and skews
> positive, and the whole value of tomorrow lives in the critical ones. Sort by **Most recent**,
> copy ten. Filter to **Critical**, copy ten more. Paste it all into one plain text file. Do not
> tidy, do not summarise, do not drop the angry ones. The angry ones are the material.

**3. `1-inputs/competitors/`.** Three to five competitors in the **same niche**, not the same
keyword. A search returns roughly 85 percent noise. The comparison strip on your own listing is the
best place to find real ones. Screenshot each of their **full galleries**, plus a text file of
their URLs.

**4. `2-reference/photos/`.** The six shots from Key 5, **plus your packaging shots**, or the
honest fallback. Name the packaging files so they read as packaging (`box-front.jpg`,
`box-back.jpg`, `label-panel.jpg`); they get routed to their own bucket later and clear names make
that routing obvious to you as well as to Wonka.

**5. `2-reference/brand/`.** Your logo file, brand colors or fonts, an existing brand guide if one
exists.

**Optional, skip without guilt,** into `1-inputs/`: Brand Registry demographics, search term data,
returns reasons.

**And `1-inputs/notes.txt` with your owner intel:** what customers ask you over and over, what
comes back in returns and why, what you tried before that failed, anything you are not allowed to
claim. If you are new to the product or it is not yours, write that.

Full one pager: `downloads/front-gate-shopping-list.md`.

---

## Common mistakes, and what they look like

| Symptom | Cause | Fix |
|---|---|---|
| Wonka sounds like a generic chatbot | The kit folder is not really loaded | Code tab, folder picker shows `Wonka`, re open it, start a NEW conversation |
| A slash command does nothing | It was described instead of typed | Type it as its own message, starting with the slash, exactly as named: `/machines-check` |
| The Genrupt machine does not appear at all | Claude was not fully quit | Cmd+Q on Mac, tray icon quit on Windows, reopen, run `/machines-check` again |
| Genrupt connects but calls fail | Session or key issue | Log in to genrupt.com in your browser once, retry. If it persists, regenerate the API key and re enter it |
| First Candy fails with a verification error | Organization verification has not cleared | platform.openai.com, Settings, Organization, Verify. Then `/machines-check` again. Nothing is blocked meanwhile |
| "No API key" | The key is not where Wonka looks | Re run the key step in Part 3, then `/machines-check` |
| You cannot see the `.claude` folder | Dot folders are hidden | Mac: Cmd+Shift+. in Finder. Windows: File Explorer, View tab, Hidden items. Or just ask Wonka to show you what is in it |
| Your listing shows only about eight reviews | You are logged out | Log in and sort by most recent and by critical, or pull from Seller Central |

The full list lives in `guides/troubleshooting.md`. And if something is genuinely stuck, post the
exact error in the group. Setup friction is the one thing worth interrupting anybody for.

---

## What good looks like

- [ ] Watched Lessons 1 and 2 before installing anything
- [ ] Claude Desktop or Claude Code installed, Pro plan or higher active
- [ ] `Wonka` on your Desktop and open in Claude's Code tab
- [ ] Wonka answered "who are you" in character, and refused to skip research when you pushed him
- [ ] Genrupt account created and activated
- [ ] OpenAI key created, $10 to $20 loaded, organization verification complete or underway
- [ ] Pilot product chosen
- [ ] Product photos taken: all angles, hand for scale, label close ups (or the fallback path taken
      knowingly)
- [ ] `/machines-check` run, with both machines reporting PASS and the credit fuel gauge read
- [ ] First Candy printed at `output/first-candy.png`, or consciously deferred until verification
      clears
- [ ] Your product registered with `/meet-my-product`: title read back and confirmed, folder
      created, owner intel answered (or "I don't have that" recorded honestly)
- [ ] The basket filled inside the product folder: your listing, `reviews.txt` (copied logged in),
      `competitors/` (galleries plus a URL file) and `notes.txt` in `1-inputs/`, your photos in
      `2-reference/photos/`, your logo and brand files in `2-reference/brand/`

**Do not open Day 2 until `/machines-check` passes.** Not because anyone is strict, because tomorrow
spends real credits and a cold machine wastes them.

Every day has a list like this one, and together they are the graduation checklist. Walk all ten
and you finish with a full, tested creative package ready to upload. No sales lift is promised.
Results vary by product and niche.

---

## What this bootcamp will cost

Genrupt usage is included with your ticket. You bring your own Claude subscription and your own
OpenAI credit.

| Item | When | Typical cost |
|---|---|---|
| Claude Pro or Max | ongoing | $20 per month and up. Your own subscription, separate from the bootcamp |
| Genrupt usage | included with your ticket | 1,000 credits. On average that is enough for 2 to 3 products; top up at Genrupt if you burn through it |
| OpenAI credit | the fixing and tasting days | $10 to $20 loaded. Cents per edit, a few dollars per race, two races across the bootcamp |

For scale: one professionally designed listing image runs $50 to $200, and a full untested set runs
$500 to $1500. You are building the factory, not paying per candy.

A standing rule you will hear all bootcamp: Wonka never spends your money silently. Every batch,
every Tasting Round, every paid call gets a one line cost estimate and waits for your go ahead.

---

## Common questions

**"Where does Wonka actually live? Is he installed somewhere?"**
He is the folder. Personality, skills, and memory are all files inside `Wonka`. Copy the
folder and you copy your Creative Director. Nothing else is installed.

**"Why do I watch two lessons before doing anything?"**
Because setup is boring and meaningless until you know what it is for. Meet the employee, see the
building, then cut the keys. It is fifteen minutes and it makes the rest of the day make sense.

**"Can I use Claude Code in the terminal instead of Claude Desktop?"**
Yes, fully. Open a terminal, `cd` into the kit folder, run `claude`. Every prompt in every guide
works identically. The guides describe Claude Desktop click paths because most participants use it.

**"I sell in a non US marketplace. Does this work?"**
Yes. The method is marketplace agnostic. Your reviews and competitors come from your marketplace, so
the research reflects your shelf, and the Tasting Room's panel is conditioned on your real buyer
whatever marketplace they shop in.

**"What if I have several products?"**
Pick ONE for the bootcamp. The factory happily runs a portfolio afterwards, and Day 9 shows you how
to multiply. Learning the line is a one product job.

**"Do I need Brand Registry?"**
No. It unlocks the demographics export and the optional Amazon A/B at the end. Without it, personas
are estimated and clearly labelled as estimated, and every room runs identically.

**"Why is there no survey tool to sign up for?"**
Because the Tasting Room runs inside the factory, on the same OpenAI key you already created. A few
dollars a round, results in minutes. To be straight with you about what it is: the tasters are
synthetic AI personas conditioned on your real buyer, so the verdict is directional and the real
value is the objections they hand you in their own words. It is not a panel of real shoppers, and
nowhere in this bootcamp will it be sold to you as one.

**"Can I use last week's product photos, or the ones from my listing?"**
You can, and Wonka will record the reference as built from listing imagery rather than real photos.
Expect weaker product accuracy. If the product is within reach, spend the twenty minutes.

---

## What Day 2 opens with

Exactly what you leave here holding: two warm machines, a registered product, and a full basket.

Day 2 is the Research Room, and it opens as an interview, not a lecture. You point at what landed
in `1-inputs/` and `2-reference/`, Wonka reads every file and confirms what he received, asks his
own questions back, and then derives your market picture himself: the table stakes, the pain points
in buyers' own words, your real buyer, the whitespace nobody in your niche is showing, and a
diagnosis of where your listing is actually losing sales.

As the man says: "Every great candy starts with knowing exactly who it is for."

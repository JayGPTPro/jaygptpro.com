# Day 6: The Secondary Images Room

Your main image wins the click. Today you build the gallery that wins the sale afterwards, and you
build it as a SET.

**The sentence for the day: the Blast finds the direction, Refine finds the frames, inspection finds
the problems.** And the idea behind it: Wonka runs the factory; Genrupt is the visual workstation.

## What you will have by the end of today

- **One visual direction**, locked as the style in Genrupt, so every new frame carries it
- **Three candidates per slot** in that look, and one frame chosen for every job
- **Your gallery home in the factory**, eight frames, each traced to its source
- **A scorecard** with every frame gate-passed, every defect you or Wonka found fixed on the chosen
  frame, and your coverage map closed against what actually exists

**Time needed:** most of it is choosing and looking, not waiting.

## What you will need at hand

- Your brief's slot list, open beside you. You will judge every frame against its job
- Your Day 5 main pick, untouched
- Genrupt open in the browser. You step into it for the visual decisions, and Wonka gives you the link each time
- Both machines connected

---

## Lesson 1: The gallery is a set

Lesson 1 is the idea; the terminal starts in lesson 2.

### One frame, one job

A secondary image does not exist to show a feature. It exists to answer one buyer need. What does
it look like running. How big is it. What does a party around it look like. How hard is it to
clean.

**If two frames say basically the same thing, one of them is probably wasting a slot.** You only
have a handful.

### The cover-the-text test

Cover the headline. If the picture stops making the point, the image is asking the text to do too
much work. Buyers scroll on a phone with one thumb; the picture lands first, and the words land
only if the picture already earned them.

### What we judge in a set

Coverage (every buyer question has a frame), separation (no two frames make the same point),
coherence (one visual language), product truth (the real machine in every frame), and mobile
readability (the message survives at thumbnail size).

The creative brief already gave every slot a job. Today turns the approved plan into an actual
gallery. It does not invent selling points.

### Two connected workspaces

You will see Jay move between Claude Code and Genrupt today. You do not have to. You can stay in
Claude, talk to Wonka, and let him run the entire process.

Some of today's decisions are very visual. With twenty images in front of you it is faster to
browse, compare and choose inside Genrupt. So Jay uses both: Wonka runs the process, and Genrupt
is the visual workstation he steps into when it makes the job easier. When a decision is easier in
the app, Wonka gives you the direct link to the exact place. Open it, choose, come back, and he
reads your choice from the machine.

### The route today, and where each step happens

Start `/secondary-images` in Claude (Wonka runs the Theme Blast), look at it in Genrupt and choose
a direction, tell Wonka (he runs Refine), choose the frames in Genrupt, back to Wonka: `/inspect`,
`/fix` what fails, lock the set.

---

## Lesson 2: Start /secondary-images

### Start the job with Wonka, not in Genrupt

**Start Day 6 in a fresh Claude Code session**, in your product's Wonka folder, and type:

```
/secondary-images
```

Wonka already knows the product, the research, the approved brief, the locked reference and the
slots, so you do not brief the gallery again. He reads the saved plan and runs two checks before he
spends anything: every job in your approved brief is still in the plan the machine holds (a job can
go missing between the brief and the machine, and a gallery of good frames can still miss a buyer
question), and every number that could be printed on a frame comes from your own product data,
never from a competitor's image. A plan repair at this point is normal. Then he launches the Theme
Blast, ten visual directions applied across every slot, posts every row as one sheet, and posts the
direct link to the grid in Genrupt.

### Read across, not down

Open the grid from Wonka's link: this decision is visual. A row is a visual system: your whole gallery in one look. First decide what world the listing
should live in. Do not hunt vertically for your favorite isolated frame; a gallery shopped across
rows reads like eight different brands.

### Style is not composition is not message

You may love the colors and typography of one frame and prefer the layout and the message of
another. Separate decisions. Lock the style first; Refine then brings the stronger ideas into
that visual language.

In Genrupt every frame has a style icon. Pick a frame, choose its style, and every new image
carries that look. Then select a frame whose composition you like, Restyle it, and Send to Refine.
It keeps the text and design and puts on the look you chose.

**Your best style reference may already exist.** Jay used a frame from the Day 4 smoke test
instead of a row from today's blast. The factory does not care which day the good idea came from.

**So the rule about rows is a rule about raw frames.** Never ship un-restyled frames from different
rows together; that is the eight-brands gallery. A composition you Restyle into the locked look is
inside the family, whichever row it came from. Style, composition and message are three decisions.

### A precaution about people in the style image

Jay's style image had a person in it. He removed her in Genrupt's editor and kept the lighting,
palette and typography as the style reference. Not a rule; a precaution, so the person does not
become part of what the model thinks you mean by style.

### Back to Wonka: close the loop

```
Hey Wonka, I actually decided to choose a different style. I did it through the Genrupt. Let me know if you can see it for me.
```

Wonka pulls the frame down, confirms it is new to him, checks the product on it and records it as
the style anchor. You can run the whole factory by talking to Wonka; Genrupt is faster for a visual
job because you see twenty options at once. What you choose there, Wonka reads back here. That is the whole relationship: a visual decision in the app, read back by Wonka, who is still running the process.

---

## Lesson 3: Refine the set

### Three per slot

```
run option 2, three per slot
```

One image is a result. Three images are a choice. AI has variance; do not ask one generation to
carry the whole decision.

### Judge inside Refine

The window changes because the next decision is easier to make visually, not because the workflow
changed. The style is already established; do not reopen it on every slot. Five questions per slot: does it do the job, is the product accurate, is the composition clear, is
the text useful and readable, is it stronger than the other two. Select the one you want; whatever
you click, Wonka reads the selection from the machine.

**Select, complete, reopen.** Selecting a candidate is your current pick; marking a slot complete
closes it with a final image, and that is what tells the app which slots a "generate more" still
touches. So select while you are exploring, and mark a slot complete only when you are done
generating for it. Wonka reads all three states from the machine and can reopen a slot if you
change your mind.

Not polishing yet. Inspection comes next. Jay kept one frame he knew had a problem to see whether
inspection would catch it. In your real workflow, if you already have a clean winner, take the
clean winner.

### More for one slot, not for all

If seven frames are good and one is weak, keep the seven. Two ways to get more for that slot: tell
Wonka the slot needs more options, or use the Genrupt controls for that slot when that is faster.
Mark every other slot complete first, then generate more for that slot only. Stay inexpensive to explore; step the quality up only for a
frame that keeps failing. The winners are upscaled on Day 10.

### Bring the set home

```
I chose all the images on Genrupt
```

Wonka reads the picks off the machine, pulls all eight into your factory, traces each one to its
source, and looks at every frame at full size. Eight images on disk is not done. Now we try to
break them.

---

## Lesson 4: Inspect and fix the set

### Run the inspection

```
run /inspect
```

You learned the quality loop on Day 5; today it runs on an entire gallery. It checks product
accuracy, the message and the job, readability at thumbnail size, factual claims, compliance,
duplication across the set, coverage, and whether each selected frame still deserves its place.
Squint copies, a numbered sheet and the scorecard go to disk.

### /fix is its own skill

Two ways a fix enters the system. **Wonka-led:** he inspects, finds a problem, explains it and
performs the fix. **Owner-led:** Wonka may have passed something, or you simply do not like it. Say
it in plain English: the headline is weak, the product is wrong here, remove that person, this
object needs to move, make this easier to read.

**You do not need to know how to edit the image. You need to know what you want changed.**

For many normal edits Wonka does not buy another Genrupt batch. He routes the surgical edit
through the direct OpenAI connection, for cents. Genrupt gives volume, ideas, variation and the
Amazon-specific environment; `/fix` gives cheap, targeted work on the winners.

Not every defect is an edit. Wonka decides the route: a wrong word is an edit, a small local defect
is often an edit, a wrong or missing concept is a regeneration of the frame. The original
generation is never touched: a repair is saved as a new version in the next `edits/` round, and
Wonka verifies that the file actually changed.

### Look yourself, and say what you see

The real story shows both modes at once. Wonka passed Jay's melt-it-first frame at five out of
five. Jay looked at it and the tower was leaning relative to the base. Inspection is powerful, but
you are still the owner: if something looks wrong to you, say it. He said so in plain language:

```
In sec-03, the left fountain's tower looks off-center relative to its bowl and base. Compare it with the reference photos. Explain what was missed before fixing anything.
```

Wonka measured it instead of arguing: a centreline through the base and bowl, a centreline
through the column. About ten percent of the bowl width off the axis. The rubric had checked
materials, part count and label text and had never tested assembly geometry. The scorecard was
corrected, not defended.

### Fix the chosen frame, with before and after

```
Fix it on my chosen image and show me before and after. I want to repair this frame, not replace it with another candidate.
```

The first attempt froze everything and moved the machine; the rest of the frame drifted, so it
was rejected. The attempt that held allowed a little freedom, a lower pour and a slightly different
angle, and the tower came back onto the axis: from about ten percent off to under two.

A higher-quality version was tested in the same round and did not beat the low-quality repair in
this case. That does not make low better than high. The expensive setting does not solve the
thinking problem by itself. Test it.

**A defect you name is a fix order.** Wonka verifies it on the pixels, edits the chosen frame with
the references attached, keeps everything outside the region unchanged, compares before and after,
and adopts only what verified. The originals in `images/` are never overwritten; the current set
moves to the next `edits/` round.

Wonka also records what happened, so the factory has the lesson on disk.

### Two more findings on the set

A wrong fact: the dimensions frame printed 8.5 inches for the base. The listing's own product
table says 8. One word swap through the direct connection, for cents. **A beautiful image with the
wrong fact is still a failed image.** That is exactly where `/fix` shines.

The coverage map found one buyer question still unanswered: how deep the chocolate should be in
the base bowl. The evidence for an exact quantity conflicted, so the replacement frame shows the
fill depth (cover the foot of the column) and prints no number. That one is not a `/fix` problem, because the job of the frame was missing:
it is a regeneration in the secondary images room. Wrong word, edit. Small local defect, often an
edit. Wrong or missing concept, regenerate the frame. Then the set-level check runs again.

### Then stop

These are not the upload files yet. Day 10 upscales what needs it and builds the ready-to-upload
folder. Tomorrow is Day 7, the A+ Room (`/aplus`).

---

## MISSION 1: The doctrine, on your own product

Write next to each slot the ONE buyer need it answers. Cover the text on your current listing
images and see which still make the point.

## MISSION 2: Start the job, find the direction

```
/secondary-images
```

Open the grid from Wonka's link and read it in rows. Lock your direction as the style in Genrupt (a frame from today's blast or
from an earlier smoke test both count), then tell Wonka and confirm he can see it.

## MISSION 3: Refine the set

```
run option 2, three per slot
```

Pick one frame per slot in Refine, mark every slot complete, then:

```
I chose all the images on Genrupt
```

## MISSION 4: Inspect and fix the set

```
run /inspect
```

Read the scorecard, then look at every frame yourself at full size. If something looks wrong, say
it in plain language and have it fixed on that frame, with before and after. Walk your coverage
map against the eight frames.

**Share it:** send Jay your chosen direction and the row you nearly chose instead.

---

## What good looks like

- Every slot has a NEED written next to it, not a feature
- You read the blast in rows and locked one direction as the style
- Style and composition were two separate decisions
- Three candidates per slot, one chosen for every job, every slot marked complete
- All eight frames home in the factory with their sources traced
- The scorecard is on disk, every frame gate-passed, and every defect you or Wonka found was fixed on the chosen frame
- Printed specs were checked against your own listing data
- The coverage map is closed against the eight frames that exist

## Common mistakes

- **Shipping raw frames from different rows.** Eight looks reads as eight brands. Restyle first; then it is one family.
- **Confusing the style with the image.** Lock the look, then bring the stronger composition into it.
- **Regenerating the whole gallery for one weak slot.** Keep the seven; generate more for one.
- **Outsourcing your eyes.** The scorecard is a second opinion, not the last word. Look at every frame at full size.
- **Accepting a fix that moved the rest of the frame.** A repair keeps everything outside the region as it was.
- **A beautiful frame with a wrong spec.** Facts outrank design; every printed number comes from your own listing data, and a competitor's frame is never a source.
- **Marking a slot complete while you still want more for it.** Complete closes the slot; select until you are done.
- **Calling a set done because every file passed.** Walk the coverage map; an absence is invisible unless you wrote down what should be there.

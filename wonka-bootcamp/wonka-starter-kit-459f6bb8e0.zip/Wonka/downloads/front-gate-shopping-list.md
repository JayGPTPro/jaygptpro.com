# Pack the ZIP: everything Wonka needs from you on Day 2

**One folder, zipped, dragged into the chat. That is the whole handover.**

You do not build the factory's folder structure and you do not drag files into hidden
folders. You gather what you have into ONE folder on your Desktop, zip it, and drop the ZIP
into the chat when `/meet-my-product` asks. Wonka extracts it, reads every file, sorts each
one into its right place inside the factory, and reads you back a receipt of exactly what he
received and where it now lives.

Wonka collects everything public himself: the title, the price, the bullets, the gallery, the
reviews, the competitors. **The ZIP is for what only you have.**

---

## 1. Your listing

Not for the ZIP, just ready to paste: the product URL, or the ASIN.

```
[ ] Product URL or ASIN, ready to paste when the room opens
```

**Read the title back when Wonka repeats it.** A single wrong character in an ASIN still
passes a format check and sends the whole factory off to research somebody else's product.
This has happened. Ten seconds of reading now saves a day.

---

## 2. Reviews. The machine reads them for you

**This section asks nothing of you.** Day 2's market analysis runs a review deep dive:
hundreds of reviews across the top products in your niche, mined into pain points, themes and
use cases, for a few credits (Wonka quotes the cost before he runs). That is more reviews
than any human copies, and it finds your organic competitors on the way.

One nice-to-have, only if it costs you a minute: if this is YOUR listing, Seller Central
hands you the full review set in one export. Drop the file into the ZIP. Have it or skip it;
nobody is waiting.

**Copy by hand ONLY if you run without Genrupt.** Then: be logged in (logged out, the page
shows a handful of reviews and skews positive), sort by **Most recent** and copy about ten,
filter to **Critical** and copy about ten more, all into one plain text file in the ZIP. Do
not summarise, do not tidy, do not drop the angry ones. The angry ones are the material.

---

## 3. Competitors. Wonka's errand, not yours

Wonka surfaces the candidates himself, from the market analysis and from your own listing
page, filters them to 3 to 5 that genuinely sell in your niche, and checks their galleries.
You will be asked exactly one question:

> Anyone important to add or remove? You know who actually steals your sales.

If you know that competitor, say so; it is gold. If you do not answer, the research runs
anyway. Nothing here goes in the ZIP unless Wonka later asks for gallery screenshots, which
only happens if the machines cannot reach a gallery on their own.

---

## 4. Your product photos, AND your packaging

**The heart of the ZIP, and the one thing that blocks the day if it is missing.**

```
into the ZIP
[ ] five to ten product photos that each add information (see the Product Photo Shot List)
[ ] box-front.jpg, box-back.jpg, label-panel.jpg   . your packaging
```

**The packaging is a separate job and people skip it.** Photograph the box, pouch, sleeve or
tin: front, back, and its label panel. Packaging travels in its own channel inside the
machine and it unlocks a real hero-image strategy: a main image built around your actual
retail box. That option is simply unavailable if the box is not in the ZIP. Name the files so
they read as packaging.

If your product genuinely has no packaging a buyer ever sees, skip it on purpose rather than
by forgetting.

If you do not have the product in hand, put the realistic customer photos from the reviews in
instead (the listing gallery only as a last resort), and tell Wonka that is what they are. He records the limitation rather
than pretending the reference is complete.

---

## 5. Your brand files

```
into the ZIP
[ ] logo file, brand colors or fonts, an existing brand guide
```

**Empty is a real answer.** If you have no brand files at all, Wonka proposes a complete kit
from your product, your category and your buyer on Day 4. You argue with the proposal rather
than filling in a blank form.

---

## 6. Owner intel. The slot only you can fill

A text file in the ZIP, or just talk to him in the interview. Things worth saying:

- What customers email or message you about, over and over
- What comes back in returns, and the reason they give
- What you tried before that failed, and what you think went wrong
- Your margin room, if it affects what you can promise
- Anything you are legally not allowed to claim
- What you privately believe your product is actually best at

**"I don't have that" is a real answer.** If you are new to the product, or it is not yours,
say so. Wonka records it as none given and proceeds. He never invents it, and he never
quietly pretends he had it.

---

## 7. Optional, if you have it

```
into the ZIP
[ ] Brand Registry demographics export  . real buyer age and gender, if you own the brand
[ ] Search term or funnel data          . if you have it in Seller Central
[ ] Returns reasons                     . the single most underused input in ecommerce
```

Skip all three without guilt. Wonka derives an estimated buyer picture from reviews and
competitors and labels it `estimated`, which is honest and good enough to work from.

---

## The whole thing, in one box

```
my-product-stuff/          <- any name you like
├── photos of the product  (five to ten, angles, states, scale, details)
├── photos of the packaging
├── logo + brand files
├── notes.txt              (owner intel, or skip it and talk instead)
└── anything optional      (review export, demographics, search data, returns)
```

Right-click the folder, compress it, drag the ZIP into the chat. Wonka sorts it into the
factory, reads everything, and reads you back the receipt. If the ZIP is too big to attach,
drop it into the `Wonka` folder instead and tell him it is there; a file on disk is a file on
disk.

Twenty to thirty minutes of gathering. It is the difference between a factory that guesses
and a factory that knows.

---

*The Wonka Creative Bootcamp. Day 2, the Front Gate.*

# The Product Photo Shot List

**Five to ten useful photos. Your phone. Each one adds information the others did not.**

Many bad AI product images are a reference problem, not a prompting problem. If the model cannot see a part of your product, it invents that part. So the job is coverage, not beauty. Do not make Wonka guess.

---

## Not the listing images

The polished images on your Amazon listing are not references. They may be retouched, composited or AI-generated, with parts hidden, proportions adjusted, materials changed, and the product sitting in a scene the AI will copy instead of learning it. If you have the real product, your own plain phone photos are the primary reference.

---

## The four things to cover

**1. Multiple angles.** Front, back, both sides, top, and any angle that reveals a shape the others do not.

**2. Different states.** If it opens, folds, extends, connects or comes apart, show the states that matter. An umbrella: closed, partly open, fully open, and from underneath.

**3. Real-world scale.** A model can recognise a shape without knowing six inches from six feet. A hand or a familiar object pins the size down.

**4. Important details.** Buttons, stitching, textures, materials, connectors, labels, hinges, mechanisms. Anything expensive to get wrong.

---

## The one rule

**Each photo answers a question the previous photos did not.** Five to ten is a great starting point. Ten versions of the same angle is one photo. When a new shot adds nothing, you are done.

---

## Multi-part products

The count can go above ten. Shoot the complete set together from several angles, so Wonka sees how the pieces relate. Then shoot every important part separately. Never a pile: the AI cannot count a pile.

---

## Packaging

If the box, pouch, sleeve or tin may appear in your images, photograph it as its own object: front, back, the main label, and the product inside when that matters. Packaging the AI has never seen clearly gets invented. If a buyer never sees it, skip it on purpose.

---

## How to shoot

- A phone, a clean surface, neutral light, a simple background.
- No filters. No reshaping. No auto enhance. No background removal.
- These are evidence, not marketing images. Sharp and accurate beats beautiful.

---

## No faces

A hand for scale is fine. A face is not: the image model may treat that person as part of the reference and reuse the same face in later images. A person makes sense only when the product needs one, a face cream for instance. Otherwise keep people out.

---

## The checklist

```
ANGLES
[ ] Front
[ ] Back
[ ] Left side
[ ] Right side
[ ] Top down

STATES (if it changes shape)
[ ] Closed / folded / apart
[ ] Open / extended / assembled
[ ] Underneath, if ever seen

SCALE
[ ] A hand or a familiar object, no face

DETAILS
[ ] Label or logo, readable
[ ] Texture or material, up close
[ ] Buttons, hinges, mechanisms, stitching

MULTI-PART
[ ] The complete set, several angles
[ ] Every important part alone

PACKAGING (if it may appear)
[ ] Front
[ ] Back
[ ] Main label
[ ] Product inside

[ ] Each photo adds something new
[ ] Nothing edited or filtered
[ ] No faces
[ ] One folder, ready to zip
```

---

## If you do not have the product

The fallback: realistic customer photos from the reviews. They show the product in real light, from angles the listing never shows. Still a fallback, because you cannot control which details are missing. Tell Wonka that is what they are; he records the source, and the Day 4 smoke test becomes the one you never skip. Shoot the real thing as soon as a unit is in reach.

---

## Then stop

You are not making the Amazon images yet. These photos go into the Day 2 ZIP, Wonka files them in `2-reference/photos/`, and Day 4 builds the reference sheet from them.

*The Wonka Creative Bootcamp. Day 2 and Day 4.*

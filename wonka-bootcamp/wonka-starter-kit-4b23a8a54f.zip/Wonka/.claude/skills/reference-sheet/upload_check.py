#!/usr/bin/env python3
"""Run before a SHEET image leaves this disk for Genrupt. Says whether the file may be uploaded.

Why (Michael, 14 October 2026): Genrupt found the same reference sheet attached twice in a large
share of Wonka projects. Approving a sheet already attaches it to the project; Michael's reading is
that Wonka then uploaded the sheet file it had on disk (the faithfulness loop downloads every
version to judge it) and attached it again, and both copies are sent on every generation. So a
Genrupt sheet is attached by its ID, and only when the read-back shows it missing; its file is
never uploaded.

The one lawful sheet upload is a CORRECTION of the primary sheet on a single-sheet product: pixels
Wonka changed (step 4a3), built by the loop and approved by the owner as that exact picture. That
upload takes the generated sheet's place in the bucket; it never sits beside it. A correction of an
additional sheet (parts, a working state) is not uploaded: no write is verified that swaps an
additional sheet's entry while the primary stays, and an upload beside it is the duplicate.

The verdict is decided by where the file came from, never by how alike two pictures look. Measured
14 October 2026 on three real sheets, the worst 16 px block of a JPEG re-save moved 6 to 26 levels
and a real local smoothing 1.4 to 33: the ranges overlap, so no similarity threshold separates a
copy from a correction.

  upload_check.py --product factory/Products/[p] --file 2-reference/sheet-corrected-1.png
  upload_check.py --product factory/Products/[p] --file [png] --by-hand "[the pixels changed, one line]"

--by-hand is for a correction of the primary made outside the loop (a product older than it), on
Wonka's word. Every file named like a Genrupt sheet and every exact pixel copy of one on disk is
refused, with or without it; a lossy copy under another name is not caught, which is why the flag
is Wonka's word. Name such a file sheet-corrected-[N].png.

The verdict is the LAST line: `ALLOW ...` (exit 0) or `REFUSE ...` (exit 1). Usage errors exit 2.
numpy and pillow only.
"""
from __future__ import annotations

import json
import os
import re
import sys
from pathlib import Path, PureWindowsPath

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from sheet_loop import file_sha  # noqa: E402  (the loop's own identity: a hash of the decoded pixels)

IMAGE_EXT = {".png", ".jpg", ".jpeg", ".webp"}
NOT_SHEETS = {"loop", "photos", "logo", "brand"}       # 2-reference/ subfolders that hold no Genrupt sheet
CORRECTION_WORDS = ("corrected", "fixed")


def _name(p) -> str:
    """The file name of a ledger path, whichever OS wrote it."""
    return PureWindowsPath(str(p or "")).name


def is_sheet_name(name: str) -> bool:
    """A Genrupt sheet saved by this room: 'sheet' in the name (sheet-v3.png, parts-inventory-sheet.png,
    state-running-sheet-v4-fresh.png), never a correction (sheet-corrected-1.png, sheet-v1-fixed.png)."""
    low = name.lower()
    return "sheet" in low and not any(w in low for w in CORRECTION_WORDS)


OTHER_SHEET = re.compile(r"^[a-z0-9]+(?:[-_][a-z0-9]+)*-sheet(?:-v\d[^.]*)?$", re.I)
NOT_A_SHEET_WORDS = re.compile(r"review|contact|compar|\bvs\b|check|board|crop|grid|collage", re.I)
ADDITIONAL_RECORD = re.compile(r"sheet:\s*built\s*\d|Sheet id:\s*`?[A-Za-z0-9]{12,}", re.I)


def is_other_sheet(name: str) -> bool:
    """A sheet beside the primary, by this room's naming: the primary's versions are sheet-v[N].png and every
    other sheet is [name]-sheet[-v[N]].png in 2-reference/ itself (parts-inventory-sheet.png,
    packaging-sheet-v2.png, state-running-sheet-v5.png). A review board or a contact sheet is not one."""
    stem = Path(name).stem
    return bool(OTHER_SHEET.match(stem)) and not stem.lower().startswith("sheet") and not NOT_A_SHEET_WORDS.search(stem)


def additional_on_record(ref: Path):
    """The 'Additional sheets' section of reference-sheet.md, filled in: the line that says so, or None."""
    md = ref / "reference-sheet.md"
    if not md.exists():
        return None
    section = re.split(r"(?m)^## Additional sheets", md.read_text(errors="ignore"))
    if len(section) < 2:
        return None
    body = re.split(r"(?m)^## ", section[1], maxsplit=1)[0]
    m = ADDITIONAL_RECORD.search(body)
    return m.group(0).strip() if m else None


def _ledgers(ref: Path) -> list:
    loop = ref / "loop"
    out = [("main", loop / "ledger.jsonl")] + [(p.parent.name, p) for p in sorted(loop.glob("*/ledger.jsonl"))]
    return [(n, p) for n, p in out if p.exists()]


def _events(path: Path) -> list:
    out = []
    for line in path.read_text(errors="ignore").splitlines():
        if line.strip():
            try:
                ev = json.loads(line)
            except json.JSONDecodeError:
                continue
            if isinstance(ev, dict):
                out.append(ev)
    return out


def inventory(ref: Path) -> dict:
    """What this product's disk knows. genrupt: sha -> {file, id, loop}; local (loop-built corrections):
    sha -> {file, loop}; approved: shas the owner approved and has not since withdrawn; named: every
    image named like a Genrupt sheet (path -> sha); multi: more than one sheet's loop exists."""
    prod = ref.parent
    genrupt, local, approved = {}, {}, set()
    for loop_name, led in _ledgers(ref):
        names_to_id, ok = {}, set()
        evs = _events(led)
        for ev in evs:
            kind = ev.get("event")
            if kind == "ids":
                names_to_id.update({_name(k): v for k, v in (ev.get("ids") or {}).items()})
            elif kind == "start":
                ok = set()                                 # a new loop: approvals of the old one lapse
                a = ev.get("anchor") or {}
                if a.get("sheet_id"):
                    names_to_id[_name(a.get("file"))] = a["sheet_id"]
            elif kind == "owner_defect":
                ok = set()                                 # the owner named a flaw: no earlier approval stands
            elif kind == "owner_approve" and ev.get("sha"):
                ok.add(ev["sha"])
            sha = ev.get("sha")
            if not sha:
                continue
            gk = ev.get("kind") if kind == "judge" else ("generator" if kind == "generator" else None)
            if gk in ("version", "generator"):
                g = genrupt.setdefault(sha, {"file": ev.get("file"), "id": None, "loop": loop_name})
                g["id"] = ev.get("sheet_id") or g["id"]     # the latest id written wins
            elif gk == "local":
                local.setdefault(sha, {"file": ev.get("file"), "loop": loop_name})
        for g in genrupt.values():                         # the loop's latest name -> id mapping beats an older judge id
            if g["loop"] == loop_name and names_to_id.get(_name(g["file"])):
                g["id"] = names_to_id[_name(g["file"])]
        approved |= ok
    named = {}
    for p in sorted(ref.rglob("*")):
        if p.suffix.lower() not in IMAGE_EXT or not p.is_file() or not is_sheet_name(p.name):
            continue
        top = p.relative_to(ref).parts[0]
        if top in NOT_SHEETS or top.lower().startswith("smoke-test"):
            continue
        try:
            sha = file_sha(p)
        except Exception:
            continue                                       # an unreadable file is nobody's sheet
        named[str(p.relative_to(prod))] = sha
        if sha not in local:
            genrupt.setdefault(sha, {"file": str(p.relative_to(prod)), "id": None, "loop": None})
    for sha in [s for s in local if s in genrupt and genrupt[s]["loop"] is not None]:
        local.pop(sha)                                     # a "candidate" with a generated version's pixels is no correction
    # more than one sheet: another sheet's loop, or another sheet's file on disk (a product whose extra
    # sheets never had a loop of their own, or one older than the loop)
    primary = {sha for r, sha in named.items() if not is_other_sheet(Path(r).name)}
    primary |= {sha for sha, g in genrupt.items() if g["loop"] == "main"}
    multi = None
    for n, led in _ledgers(ref):
        if n != "main":
            multi = f"another sheet's loop ({led.parent.name})"
    for r, sha in named.items():
        if not multi and len(Path(r).parts) == 2 and is_other_sheet(Path(r).name) and sha not in local and sha not in primary:
            multi = f"another sheet on disk ({r})"
    if not multi and additional_on_record(ref):
        multi = f"reference-sheet.md records an additional sheet ({additional_on_record(ref)})"
    return {"genrupt": genrupt, "local": local, "approved": approved, "named": named, "multi": multi}


def _attach_line(sid) -> str:
    who = f"this sheet's id {sid}" if sid else "the approved id recorded for THIS sheet in reference-sheet.md (never the primary's id for another sheet)"
    return (f"Read the bucket back and match each 'Product Reference Sheet' entry to its sheet by URL. Only if this "
            f"sheet's entry is missing, attach it ONCE by {who}: the primary alone, an additional sheet with mode "
            "\"merge\" (CLAUDE.md 6c). On an uploaded_source_image lock nothing is attached.")


def check(ref: Path, f: Path, by_hand: str | None = None) -> tuple:
    """(verdict, lines). verdict is 'ALLOW' or 'REFUSE'."""
    inv = inventory(ref)
    prod = ref.parent
    try:
        rel = str(f.resolve().relative_to(prod.resolve()))
        parts = f.resolve().relative_to(ref.resolve()).parts
    except ValueError:
        rel, parts = str(f), ()
    source = parts[0] if parts and parts[0] in ("photos", "logo") else None
    named_like_sheet = [
        f"{f.name} is named like a Genrupt sheet. A sheet is attached by its id and never uploaded; a correction "
        "is saved as sheet-corrected-[N].png.",
        _attach_line(None),
        f"REFUSE {f.name}: named like a Genrupt sheet; do not upload it. Attach by id only if the read-back shows it missing"]
    try:
        sha = file_sha(f)
    except Exception:
        if is_sheet_name(f.name):
            return "REFUSE", named_like_sheet
        if source:                                         # an SVG logo, a HEIC photo: not a picture this check can read, and no sheet
            return "ALLOW", [f"ALLOW {f.name}: in {source}/, not a raster image; its own upload step applies"]
        raise
    lines = []

    if sha in inv["genrupt"]:
        g = inv["genrupt"].get(sha) or {"file": rel, "id": None}
        same = "is" if g["file"] in (rel, None) else f"is the same picture as"
        lines.append(f"{f.name} {same} the Genrupt sheet {g['file']}" + (f" (id {g['id']})" if g["id"] else "") + ".")
        lines.append("Approving a sheet already attaches it. The file on disk is for looking at, never for uploading.")
        lines.append(_attach_line(g["id"]))
        return "REFUSE", lines + [f"REFUSE {f.name}: a Genrupt sheet; do not upload it. Attach by id only if the read-back shows it missing"]

    if is_sheet_name(f.name):                              # wherever it sits, whatever its pixels
        return "REFUSE", named_like_sheet

    if sha in inv["local"]:
        c = inv["local"][sha]
        if c["loop"] != "main" or inv["multi"]:
            lines.append(f"This product has more than one sheet: {inv['multi'] or 'this correction belongs to another sheet'}. "
                         "No write is verified that swaps one sheet's entry for an upload while the other sheets stay, and an "
                         "upload beside the sheet is the duplicate. The owner approves the best generated version (step 4c); the "
                         "correction stays on disk as the target the smoke test and /fix's paste route check frames against (step 4a3).")
            return "REFUSE", lines + [f"REFUSE {f.name}: a correction on a product with more than one sheet; do not upload it"]
        if sha not in inv["approved"]:
            lines.append("The loop built this correction, but the owner has not approved this exact picture. Send the owner "
                         "the file; only after their yes, record it with "
                         f"sheet_loop.py owner --product factory/Products/[product] --approve --file {c['file']}, "
                         "then run this check again.")
            return "REFUSE", lines + [f"REFUSE {f.name}: a correction the owner has not approved yet; do not upload it"]
        lines.append("Upload it, then REPLACE the generated sheet's entry in productImages with it and read back: ONE "
                     "product entry, never two (step 4a3).")
        return "ALLOW", lines + [f"ALLOW {f.name}: a correction the loop built and the owner approved"]

    if source:
        what = "source photo" if source == "photos" else "logo"
        return "ALLOW", [f"ALLOW {f.name}: in {source}/, treated as a {what}; its own upload step applies"]

    if by_hand:
        if inv["multi"]:
            lines.append(f"This product has more than one sheet: {inv['multi']}. A correction is uploaded only on a "
                         "single-sheet product (step 4a3).")
            return "REFUSE", lines + [f"REFUSE {f.name}: a correction on a product with more than one sheet; do not upload it"]
        lines.append(f"by hand: {by_hand}")
        lines.append("Record that line in reference-sheet.md beside the sheet version it corrects. Upload it, then REPLACE the "
                     "generated sheet's entry in productImages with it and read back: ONE product entry, never two.")
        return "ALLOW", lines + [f"ALLOW {f.name}: a correction made by hand, on Wonka's word; not pixel-identical to any Genrupt sheet on disk"]

    lines.append(f"{f.name} is neither a correction the faithfulness loop built nor a source photo. A Genrupt sheet "
                 "(downloaded, renamed, re-saved or resized) is attached by its id; a correction comes from the loop "
                 "(sheet_loop.py build, then report), or names its change with --by-hand.")
    lines.append(_attach_line(None))
    return "REFUSE", lines + [f"REFUSE {f.name}: not a correction on record; do not upload it. Attach the sheet by id only if the read-back shows it missing"]


def main(argv) -> int:
    opts, i = {}, 0
    while i < len(argv):
        if argv[i].startswith("--") and i + 1 < len(argv):
            opts[argv[i]] = argv[i + 1]; i += 2
        else:
            print(__doc__); return 2
    if not opts.get("--file"):
        print(__doc__); return 2
    if opts.get("--product"):
        prod = Path(opts["--product"])
        if not (prod / "2-reference").is_dir():
            print(f"--product {prod}: no 2-reference/ folder there"); return 2
        os.chdir(prod)
    ref = Path("2-reference")
    if not ref.is_dir():
        print("run from the product folder or pass --product factory/Products/[product]"); return 2
    f = Path(opts["--file"])
    if not f.is_file():
        print(f"{f}: no such file"); return 2
    try:
        verdict, lines = check(ref, f, opts.get("--by-hand"))
    except Exception as e:                                 # unreadable or not an image: never a silent ALLOW
        print(f"{f}: cannot be read as an image ({e.__class__.__name__}); nothing is uploaded"); return 2
    print("\n".join(lines))
    return 0 if verdict == "ALLOW" else 1


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))

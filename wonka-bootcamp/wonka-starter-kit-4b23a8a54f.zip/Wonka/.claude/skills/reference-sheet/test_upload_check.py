"""Fixture tests for upload_check: a Genrupt sheet is never uploaded, in any disguise; an approved
correction of the primary on a single-sheet product is.

Both directions, because a guard that only ever refuses blocks the one lawful upload (step 4a3),
and one that only ever allows is the duplicate Michael found. Every case the four reviews of
14 October 2026 reproduced is here, each watched to fail on the code it was found in.

Run: python3 test_upload_check.py
"""
import io
import json
import subprocess
import sys
import tempfile
from pathlib import Path

import numpy as np
from PIL import Image

sys.path.insert(0, str(Path(__file__).parent))
from upload_check import check, inventory  # noqa: E402
from sheet_loop import file_sha  # noqa: E402

HERE = Path(__file__).resolve().parent
FAILURES = []


def ok(name, cond, detail=""):
    print(("  PASS  " if cond else "  FAIL  ") + name + ("" if cond else "  " + str(detail)))
    if not cond:
        FAILURES.append(name)


def sheet(seed, size=(600, 300)):
    rng = np.random.default_rng(seed)
    a = np.full((size[1], size[0], 3), 235, np.uint8)
    for _ in range(12):
        x, y = rng.integers(0, size[0] - 60), rng.integers(0, size[1] - 60)
        a[y:y + 50, x:x + 50] = rng.integers(0, 255, 3)
    return Image.fromarray(a)


def write_ledger(path: Path, events):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\n".join(e if isinstance(e, str) else json.dumps(e) for e in events) + "\n")


def judge(ref, rel, kind, **extra):
    return dict({"event": "judge", "file": rel, "sha": file_sha(ref.parent / rel), "kind": kind}, **extra)


def single_product(root: Path) -> dict:
    """One sheet, the main loop only: the one place a correction may be uploaded."""
    prod = root / "single"
    ref = prod / "2-reference"
    (ref / "photos").mkdir(parents=True)
    (ref / "logo").mkdir()
    v1, v2 = sheet(1), sheet(2)
    v1.save(ref / "sheet-v1.png"); v2.save(ref / "sheet-v2.png")
    fixed = np.asarray(v1).copy(); fixed[100:140, 200:240] = (20, 200, 20)       # a paste: pixels Wonka changed
    (ref / "loop").mkdir()
    Image.fromarray(fixed).save(ref / "loop" / "cand-1.png")
    other = np.asarray(v2).copy(); other[10:30, 10:30] = 0
    Image.fromarray(other).save(ref / "loop" / "cand-2.png")
    Image.fromarray(fixed).save(ref / "sheet-corrected-1.png")
    sheet(9).save(ref / "photos" / "front.jpg")
    (ref / "logo" / "logo.svg").write_text("<svg xmlns='http://www.w3.org/2000/svg'/>")
    events = [
        judge(ref, "2-reference/sheet-v1.png", "version", sheet_id="cmOLDTYPO0001"),
        judge(ref, "2-reference/sheet-v2.png", "version"),
        {"event": "start", "anchor": {"file": "2-reference/sheet-v1.png", "sheet_id": "cmOLDTYPO0001"}},
        judge(ref, "2-reference/sheet-v1.png", "version", sheet_id="cmRIGHTV10002"),
        {"event": "start", "anchor": {"file": "2-reference/sheet-v1.png", "sheet_id": "cmRIGHTV10002"}},   # a --restart with the right id
        {"event": "ids", "ids": {"2-reference\\sheet-v2.png": "cmSHEETV20003"}},                        # written on Windows
        judge(ref, "2-reference/loop/cand-1.png", "local"),
        judge(ref, "2-reference/loop/cand-2.png", "local"),
        "null",                                                                                          # a damaged line
        {"event": "owner_approve", "file": "2-reference/sheet-corrected-1.png", "sha": file_sha(ref / "sheet-corrected-1.png")},
    ]
    write_ledger(ref / "loop" / "ledger.jsonl", events)
    (ref / "reference-sheet.md").write_text("- Approved reference asset id: **`cmPRIMARYMD004`** (v1)\n")
    return {"prod": prod, "ref": ref, "v1": v1, "fixed": fixed, "events": events}


def multi_product(root: Path) -> dict:
    """An identity sheet plus a parts sheet, one loop each."""
    prod = root / "multi"
    ref = prod / "2-reference"
    ref.mkdir(parents=True)
    sheet(11).save(ref / "sheet-v1.png")
    parts = sheet(12); parts.save(ref / "parts-inventory-sheet.png")            # the template's own name, no -vN
    pfix = np.asarray(parts).copy(); pfix[50:90, 50:90] = 3
    (ref / "loop" / "parts").mkdir(parents=True)
    Image.fromarray(pfix).save(ref / "loop" / "parts" / "cand-1.png")
    mfix = np.asarray(sheet(11)).copy(); mfix[0:40, 0:40] = 250
    Image.fromarray(mfix).save(ref / "loop" / "cand-1.png")
    write_ledger(ref / "loop" / "ledger.jsonl", [
        judge(ref, "2-reference/sheet-v1.png", "version", sheet_id="cmIDENTITY0005"),
        {"event": "start", "anchor": {"file": "2-reference/sheet-v1.png", "sheet_id": "cmIDENTITY0005"}},
        judge(ref, "2-reference/loop/cand-1.png", "local"),
        {"event": "owner_approve", "file": "2-reference/loop/cand-1.png", "sha": file_sha(ref / "loop" / "cand-1.png")},
    ])
    write_ledger(ref / "loop" / "parts" / "ledger.jsonl", [
        judge(ref, "2-reference/parts-inventory-sheet.png", "version"),
        {"event": "start", "anchor": {"file": "2-reference/parts-inventory-sheet.png", "sheet_id": None}},
        judge(ref, "2-reference/loop/parts/cand-1.png", "local"),
    ])
    (ref / "reference-sheet.md").write_text("- Approved reference asset id: **`cmIDENTITY0005`** (identity)\n")
    return {"prod": prod, "ref": ref}


def main():
    with tempfile.TemporaryDirectory() as d:
        t = single_product(Path(d))
        ref, prod = t["ref"], t["prod"]

        # ---- the duplicate, in every disguise: REFUSE
        v, lines = check(ref, ref / "sheet-v1.png")
        ok("the downloaded sheet itself is refused", v == "REFUSE", lines)
        ok("the refusal names the LATEST id after a restart, never the typo", "cmRIGHTV10002" in " ".join(lines)
           and "cmOLDTYPO0001" not in " ".join(lines), lines)
        ok("the last line says attach only if missing", "only if the read-back shows it missing" in lines[-1], lines[-1])
        ok("the guidance says approval already attached it", any("already attaches" in l for l in lines), lines)

        v, lines = check(ref, ref / "sheet-v2.png")
        ok("an id from an ids event written with Windows paths is found", v == "REFUSE" and "cmSHEETV20003" in " ".join(lines), lines)

        t["v1"].save(ref / "approved-sheet.png", compress_level=1)          # renamed, re-encoded, same pixels
        v, lines = check(ref, ref / "approved-sheet.png")
        ok("a renamed re-saved copy is refused as the Genrupt sheet", v == "REFUSE" and "same picture as" in lines[0], lines)

        buf = io.BytesIO(); t["v1"].save(buf, "JPEG", quality=85)
        (ref / "for-upload.jpg").write_bytes(buf.getvalue())             # a lossy copy: no pixel match
        v, lines = check(ref, ref / "for-upload.jpg")
        ok("a JPEG copy (no pixel match) is refused by provenance", v == "REFUSE", lines)
        ok("  ... and no id is guessed from reference-sheet.md", "cmPRIMARYMD004" not in " ".join(lines), lines)

        t["v1"].resize((300, 150)).save(ref / "small.png")
        ok("a resized copy is refused by provenance", check(ref, ref / "small.png")[0] == "REFUSE")

        sheet(77).save(ref / "_NEW-sheet-from-genrupt-cmxyz.png")          # a real download under its own name
        v, lines = check(ref, ref / "_NEW-sheet-from-genrupt-cmxyz.png", by_hand="fixed the spout")
        ok("--by-hand never launders a file named like a sheet", v == "REFUSE", lines)
        (ref / "_NEW-sheet-from-genrupt-cmxyz.png").unlink()
        (prod / "edits").mkdir()
        buf3 = io.BytesIO(); t["v1"].save(buf3, "JPEG", quality=80)
        (prod / "edits" / "sheet-v1.png").write_bytes(buf3.getvalue())    # a lossy copy outside 2-reference, sheet-named
        v, lines = check(ref, prod / "edits" / "sheet-v1.png", by_hand="x")
        ok("a sheet-named file outside 2-reference is refused even with --by-hand", v == "REFUSE", lines)
        ok("approved-sheet.png, an exact copy of the primary, does not make the product multi-sheet",
           (ref / "approved-sheet.png").exists() and not inventory(ref)["multi"])
        v, lines = check(ref, ref / "sheet-v1.png", by_hand="moved the port")
        ok("--by-hand never launders the sheet itself", v == "REFUSE", lines)

        t["v1"].save(ref / "photos" / "sneaky.png")
        ok("an exact sheet copy dropped into photos/ is refused", check(ref, ref / "photos" / "sneaky.png")[0] == "REFUSE")
        buf2 = io.BytesIO(); t["v1"].save(buf2, "JPEG", quality=90)
        (ref / "photos" / "sheet.jpg").write_bytes(buf2.getvalue())
        ok("a lossy copy named like a sheet in photos/ is refused", check(ref, ref / "photos" / "sheet.jpg")[0] == "REFUSE")

        Image.fromarray(t["fixed"]).save(ref / "photos" / "fix-as-photo.png")    # an unapproved route: candidate copied to photos
        events = t["events"]
        write_ledger(ref / "loop" / "ledger.jsonl", [e for e in events if not (isinstance(e, dict) and e.get("event") == "owner_approve")])
        v, lines = check(ref, ref / "photos" / "fix-as-photo.png")
        ok("a correction copied into photos/ does not skip the owner's approval", v == "REFUSE" and "not approved" in lines[-1], lines)
        v, lines = check(ref, ref / "sheet-corrected-1.png", by_hand="x")
        ok("--by-hand does not skip the owner's approval of a loop correction", v == "REFUSE" and "not approved" in lines[-1], lines)
        ok("  ... and the approval command is offered only after the owner's yes",
           any("only after their yes" in l and "--approve --file 2-reference/loop/cand-1.png" in l and "--product" in l for l in lines), lines)
        write_ledger(ref / "loop" / "ledger.jsonl", events)

        # ---- the lawful uploads: ALLOW
        v, lines = check(ref, ref / "sheet-corrected-1.png")
        ok("the owner-approved correction is allowed", v == "ALLOW", lines)
        ok("  ... and told to REPLACE, never sit beside", any("REPLACE" in l and "never two" in l for l in lines), lines)
        Image.fromarray(t["fixed"]).save(ref / "sheet-v1-fixed.png")
        Image.fromarray(t["fixed"]).save(ref / "sheet-v1-view.png")            # the same pixels under a view name
        v, lines = check(ref, ref / "sheet-corrected-1.png")
        ok("a copy of the correction under a sheet-like name does not demote it", v == "ALLOW", lines)

        ok("a loop correction the owner has not approved is refused",
           check(ref, ref / "loop" / "cand-2.png")[0] == "REFUSE")

        write_ledger(ref / "loop" / "ledger.jsonl", events + [{"event": "owner_defect", "words": "the green patch is wrong"}])
        v, lines = check(ref, ref / "sheet-corrected-1.png")
        ok("a defect the owner named after approving withdraws the approval", v == "REFUSE", lines)
        write_ledger(ref / "loop" / "ledger.jsonl", events + [{"event": "start", "anchor": {"file": "2-reference/sheet-v2.png"}}])
        ok("a restarted loop withdraws the old loop's approval", check(ref, ref / "sheet-corrected-1.png")[0] == "REFUSE")
        write_ledger(ref / "loop" / "ledger.jsonl", events)

        changed = t["fixed"].copy(); changed[0:20, 0:20] = 7
        Image.fromarray(changed).save(ref / "hand-fixed.png")
        v, lines = check(ref, ref / "hand-fixed.png", by_hand="panel redrawn to the photo")
        ok("a by-hand correction with its change named is allowed", v == "ALLOW" and "on Wonka's word" in lines[-1], lines)
        ok("the same file without --by-hand is refused", check(ref, ref / "hand-fixed.png")[0] == "REFUSE")

        ok("a source photo is not this check's business", check(ref, ref / "photos" / "front.jpg")[0] == "ALLOW")
        v, lines = check(ref, ref / "logo" / "logo.svg")
        ok("an SVG logo gets a verdict, not a traceback", v == "ALLOW", lines)

        inv = inventory(ref)
        ok("the corrected copy is never counted as a Genrupt sheet",
           file_sha(ref / "sheet-corrected-1.png") not in inv["genrupt"], list(inv["genrupt"].values()))

        # ---- more than one sheet: no correction is uploaded, and no wrong id is printed
        m = multi_product(Path(d))
        v, lines = check(m["ref"], m["ref"] / "loop" / "parts" / "cand-1.png")
        ok("a parts-sheet correction is refused", v == "REFUSE" and "more than one sheet" in lines[-1], lines)
        v, lines = check(m["ref"], m["ref"] / "loop" / "cand-1.png")
        ok("an approved primary correction on a multi-sheet product is refused", v == "REFUSE" and "more than one sheet" in lines[-1], lines)
        v, lines = check(m["ref"], m["ref"] / "parts-inventory-sheet.png")
        ok("a parts sheet named without -vN is a Genrupt sheet", v == "REFUSE" and "Genrupt sheet" in lines[-1], lines)
        ok("  ... and is never handed the identity sheet's id", "cmIDENTITY0005" not in " ".join(lines), lines)
        ok("  ... and the guidance says merge for an additional sheet", any('mode "merge"' in l for l in lines), lines)

        # ---- more than one sheet with NO loop for the extra sheets (the fondue shape): still multi
        Image.fromarray(t["fixed"]).save(ref / "loop" / "keep.png")
        sheet(31).save(ref / "parts-inventory-sheet-v4.png")
        v, lines = check(ref, ref / "sheet-corrected-1.png")
        ok("an approved correction beside a parts sheet with no loop is refused", v == "REFUSE" and "more than one sheet" in lines[-1], lines)
        ok("  ... and the refusal names the file that made it multi-sheet", "parts-inventory-sheet-v4.png" in " ".join(lines), lines)
        v, lines = check(ref, ref / "hand-fixed.png", by_hand="barrel smoothed")
        ok("  ... and so is a by-hand correction there", v == "REFUSE" and "more than one sheet" in lines[-1], lines)
        (ref / "parts-inventory-sheet-v4.png").unlink()
        # ---- files that only carry the word: a single-sheet product stays single
        (ref / "smoke-r1").mkdir(); sheet(41).save(ref / "smoke-r1" / "contact-sheet.jpg")
        sheet(42).save(ref / "owner-review-sheet.jpg")
        sheet(43).save(ref / "_NEW-sheet-from-genrupt-cmabc.png")              # a newer primary version, fondue's naming
        (ref / "_check-crops").mkdir(); sheet(44).save(ref / "_check-crops" / "fitted-sheet-pocket.png")
        v, lines = check(ref, ref / "sheet-corrected-1.png")
        ok("contact sheets, review boards and a product named 'sheet' do not make it multi-sheet", v == "ALLOW", lines)
        md = ref / "reference-sheet.md"; base_md = md.read_text()
        md.write_text(base_md + "\n## Additional sheets (multi-part, bundle, or packaging-slot products only)\n"
                      "- Parts-inventory sheet: built [YYYY-MM-DD] | not needed (single-piece product)\n"
                      "  - File: 2-reference/parts-inventory-sheet.png | Sheet id: [returned id]\n\n## Reference lock\n")
        ok("the template's unfilled Additional sheets section is not a second sheet", check(ref, ref / "sheet-corrected-1.png")[0] == "ALLOW")
        md.write_text(base_md + "\n## Additional sheets\n- Parts-inventory sheet: built 2026-10-01\n"
                      "  - File: 2-reference/parts.png | Sheet id: cmt4yji32000xe7wvyz30pke4\n")
        v, lines = check(ref, ref / "sheet-corrected-1.png")
        ok("an additional sheet recorded in reference-sheet.md makes it multi-sheet, file or no file",
           v == "REFUSE" and "records an additional sheet" in " ".join(lines), lines)
        md.write_text(base_md)
        Image.fromarray(t["fixed"]).save(ref / "sheet-v2-copy.png")
        v, lines = check(ref, ref / "sheet-v2-copy.png")
        ok("an approved correction saved under a sheet name is refused by its name", v == "REFUSE" and "named like" in lines[-1], lines)
        (ref / "sheet-v2-copy.png").unlink()
        (ref / "photos" / "sheet-v9.png").write_bytes(b"not an image")
        ok("an unreadable sheet-named file in photos/ is refused, not waved through",
           check(ref, ref / "photos" / "sheet-v9.png")[0] == "REFUSE")

        # ---- no loop at all (a product older than v54): the downloaded sheet is still refused
        bare = Path(d) / "bare" / "2-reference"; bare.mkdir(parents=True)
        sheet(5).save(bare / "sheet-v1.png")
        v, lines = check(bare, bare / "sheet-v1.png")
        ok("without a ledger, a sheet-v file is still a Genrupt sheet", v == "REFUSE" and "Genrupt sheet" in lines[-1], lines)
        ok("without a ledger, --by-hand cannot launder a downloaded sheet",
           check(bare, bare / "sheet-v1.png", by_hand="nothing really")[0] == "REFUSE")

        # ---- the command line: exit codes and the verdict on the last line
        def run(*a):
            p = subprocess.run([sys.executable, str(HERE / "upload_check.py"), *a], capture_output=True, text=True)
            return p.returncode, p.stdout.strip().splitlines()
        code, out = run("--product", str(prod), "--file", "2-reference/sheet-v1.png")
        ok("CLI: refuse exits 1, verdict last", code == 1 and out[-1].startswith("REFUSE"), (code, out[-1:]))
        code, out = run("--product", str(prod), "--file", "2-reference/sheet-corrected-1.png")
        ok("CLI: allow exits 0, verdict last", code == 0 and out[-1].startswith("ALLOW"), (code, out[-1:]))
        code, out = run("--product", str(prod), "--file", "2-reference/nope.png")
        ok("CLI: a missing file is a usage error", code == 2, (code, out))
        code, out = run("--product", str(prod), "--file", "2-reference")
        ok("CLI: a folder is a usage error", code == 2, (code, out))
        (ref / "broken.png").write_bytes(b"\x89PNG\r\n\x1a\n" + b"\0" * 40)
        code, out = run("--product", str(prod), "--file", "2-reference/broken.png")
        ok("CLI: an unreadable image exits 2, never ALLOW", code == 2 and not any(l.startswith("ALLOW") for l in out), (code, out))
        code, out = run("--product", str(prod), "--file", "2-reference/hand-fixed.png", "--by-hand", "panel redrawn")
        ok("CLI: --by-hand takes its words", code == 0, (code, out[-1:]))

    print()
    if FAILURES:
        print(f"{len(FAILURES)} FAILED: {', '.join(FAILURES)}")
        return 1
    print("all upload_check tests passed")
    return 0


if __name__ == "__main__":
    sys.exit(main())

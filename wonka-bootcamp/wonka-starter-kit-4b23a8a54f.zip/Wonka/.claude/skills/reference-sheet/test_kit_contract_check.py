"""Fixture tests for kit_contract_check.

Both directions, because a scanner that only ever prints "clean" is decoration:
each banned pattern is watched to FAIL on text that really asserts it, and the
shipped kit is asserted to PASS as it stands.

Run: python3 test_kit_contract_check.py
"""
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from kit_contract_check import scan, logical_lines  # noqa: E402

KIT_ROOT = Path(__file__).resolve().parents[3]
FAILURES = []


def check(name, cond, detail=""):
    print(("  PASS  " if cond else "  FAIL  ") + name + ("" if cond else "  " + detail))
    if not cond:
        FAILURES.append(name)


def scan_text(md, rel="guides/x.md"):
    """Scan a throwaway kit whose only file carries `md`. Returns violation ids."""
    with tempfile.TemporaryDirectory() as d:
        root = Path(d)
        f = root / rel
        f.parent.mkdir(parents=True, exist_ok=True)
        f.write_text(md, encoding="utf-8")
        violations, _missing = scan(root)
    return {v[2] for v in violations}


print("kit contract check")

# 1. The shipped kit passes as it stands.
violations, missing = scan(KIT_ROOT)
check("the shipped kit is clean", not violations and not missing,
      f"{violations[:2]} {missing[:2]}")

# 2. Every banned wording is caught when it is genuinely asserted.
cases = [
    ("proposes-a-brand-unasked", "With no brand files, Wonka proposes a complete kit from your category."),
    ("wonka-proposes-mode", "- **WONKA PROPOSES.** There are no brand files, so build a proposal."),
    ("logo-blocks", "A missing logo is a gap to record before Day 4 can close."),
    ("logo-needs-brand-kit", "A logo file is required for branding to work at all."),
    ("brand-book-required-for-logo", "A brand book is required before a logo may be used."),
    ("logo-into-packaging", "Send the logo with the packagingImages so it travels along."),
    ("logo-into-slot-refs", "Put the logo in that slot's referenceImages instead."),
    ("preset-only-from-kit-file",
     "The preset is resolved from `factory/Brand/brand-kit.md` in every generation room."),
    ("file-management-homework", "Please drop the actual files into `2-reference/photos/` yourself."),
    ("attach-403-era", "On this connection every route 403s, so carry the material lock as short customInstructions."),
    ("prop-as-defect", "A count off by one, a removable prop, or garbled text is tagged and shown."),
    ("typo-pulls", "Read the tag at zoom; a typo pulls the candidate like any law violation."),
    ("policy-recital", "Main slot rules: pure white background, no text, logos, watermarks, props, or borders."),
    ("safely-compliant", "Keep one candidate that is safely compliant as the swap-in."),
    ("packaging-after-approval", "After the owner's approval of the set, invoke /ready-to-upload and package the winner."),
    ("packaging-after-approval", "The approval opens the Shipping Room the same day."),
    ("next-room-ready-to-upload", "Recorded the approval. Next room: /ready-to-upload."),
    ("concept-number-banned", "The owner identifies a pick by screenshot, and A+ carries no \"selected\" field at all."),
    ("stale-upscale-step8", "The picked winners are finished by the precision upscale in step 8."),
    ("incumbent-on-day-7", "The live main and gallery are saved at the end of Day 7 for the races."),
    ("pick-sheet-in-images", "Lay the choice set out with contact_sheet.py sheet images/pick-[slot].jpg [files]."),
    ("weekday-name", "Day 6 opens on Tuesday at four."),
    ("weekday-name", "`/factory-report` is your Monday. Ten minutes, one command."),
    ("student-downloads-incumbent",
     "incumbent/     Your LIVE Amazon main + gallery, downloaded by you before the Tasting Room"),
    ("student-downloads-incumbent",
     "Tasting Cards in `tests/`, the live listing images you downloaded in `incumbent/`."),
    ("day8-cannot-start-without",
     "Your live main image and gallery are saved into `incumbent/`. Day 8 cannot start without them."),
    ("go-ahead-on-cents", "Then refuse one. Approved. Do those."),
    ("lean-ships", "A kind of Lean ships if you squint at it."),
    ("slides-no-terminal", "Slides. No terminal, no Wonka."),
    ("your-monday", "`/factory-report` is your Monday."),
    ("this-week", "Upload it this week. Start an A/B on your main."),
    ("this-week", "It has been empty all week, on purpose."),
    ("ab-alternates", "The Day 5 close is the primary plus its A/B alternates."),
    ("safe-spare", "Keep the plain frame as the safe spare."),
    ("faces-fixed-name", "Saves `[name]-faces-fixed.png` BESIDE the original, wherever it lives."),
    ("secondary-count-hardcoded", "Generate the SECONDARY image set (5 to 7 slots) from the creative brief."),
    ("secondary-count-hardcoded", "Files are named `sec-01.png` through `sec-07.png`, matching the brief."),

    ("smoke-test-decides", "Extra sheets (parts inventory, packaging): NOT built, owner-approved evidence-first route; the smoke test decides."),
    ("smoke-test-decides", "Skip the parts sheet for now; the smoke test will decide whether one is needed."),
    ("no-route-for-corrected-sheet", "NOT uploaded to Genrupt (no route exists for a hand-edited sheet); it is the visual target for /fix panel repairs."),
    ("no-route-for-corrected-sheet", "A locally corrected sheet cannot be attached, so keep it as the answer key."),
    ("exact-feature-third-edit", "Send a third sheet edit for the control panel with the new crops attached."),
    ("sister-of-the-latest", "Send the next revision with baseReferenceSheetId set to the latest draft."),
    ("sister-of-the-latest", "Make the new sister based on the previous sister so the panel fix carries over."),
    ("retry-until-right", "Keep revising the sheet until it looks right, however many rounds that takes."),
    ("retry-until-right", "Continue sending sisters with the finish note until the finish is right."),
    ("rows-absolute", "Do not shop across rows. A row is the unit of choice."),
    ("upload-a-genrupt-sheet", "After the approval, download the sheet and upload the approved sheet to the project so it is attached."),
    ("upload-a-genrupt-sheet", "Wonka uploads the primary reference sheet into productImages beside the photos."),
    ("upload-a-genrupt-sheet", "If the read-back shows no productReferenceSheetIds key, attach the sheet again by uploading sheet-v3.png."),
    ("upload-a-genrupt-sheet", "If the bucket looks short, re-upload the sheet and attach it."),
    ("upload-sheet-again", "If the read-back does not show the sheet, upload the approved sheet again."),
    ("stale-default-primary-alone", "Omitted, the blast uses the primary sheet alone."),
    ("stale-default-primary-alone", "A blast uses the sheets you select, and it starts with the primary alone."),
    ("stale-per-slot-no-selection", "`generate_listing_builder_image` has no reference-selection field at all, so plan around it."),
    ("stale-per-slot-no-selection", "So a per-slot rerun reaches only what is already selected."),
    ("stale-no-selection-in-app", "There is no selection control in the app, so ask Wonka."),
    ("stale-slot-refs-unverified", "Whether a per-slot rerun honors a slot's own `referenceImages` is unverified."),
    ("stale-approval-replaces-gallery", "Approving the primary sheet replaces the listing photos in productImages."),
    ("upload-a-genrupt-sheet", "Wonka uploads the sheet it downloaded so the plan has it."),
    ("aplus-keeps-the-pool", "Read what it reports as ALREADY selected and keep it; the candidate list is an inventory."),
    ("aplus-keeps-the-pool", "Read what it reports as ALREADY selected and keep it, the candidate list is an inventory, not a prompt to pick."),
    ("aplus-keeps-the-pool", "Keep everything already on the flow for the next run."),
    ("aplus-keeps-the-pool", "Whatever is already in the pool, keep it, never dropping anything."),
    ("aplus-every-approved-sheet", "Pass `productReferenceSheetIds: [every approved sheet]` (up to 5)."),
    ("aplus-every-approved-sheet", "Pass `productReferenceSheetIds: [all approved sheets]` on both calls."),
    ("aplus-every-approved-sheet", "Send productReferenceSheetIds: [every approved sheet id] and nothing else."),
    ("ready-today", "By the end of Day 6 your images are ready to upload today."),
]
for bid, text in cases:
    check(f"catches {bid}", bid in scan_text(text), f"got {scan_text(text)}")

# 2a. Day 6 scoped rules: the Day 6 guide may not hand lessons to Genrupt or name the learning loop.
handed = "Genrupt open. Two of today's four lessons happen there. If your blast was launched after Day 5's session, it ran while you were away.\n"
check("lessons handed to Genrupt in the Day 6 guide fail",
      "genrupt-owns-lessons" in scan_text(handed, rel="guides/episode6-guide.md"), str(scan_text(handed, rel="guides/episode6-guide.md")))
check("  ... and the Day 7 guide is out of that rule's scope",
      "genrupt-owns-lessons" not in scan_text(handed, rel="guides/episode7-guide.md"), str(scan_text(handed, rel="guides/episode7-guide.md")))
loop = "Then the learning loop closes: Wonka writes the lesson into the Improvement Log.\n"
check("the learning loop named in the Day 6 guide fails",
      "learning-loop-day6" in scan_text(loop, rel="guides/episode6-guide.md"),
      str(scan_text(loop, rel="guides/episode6-guide.md")))
check("  ... and is lawful in the Day 10 guide",
      "learning-loop-day6" not in scan_text(loop, rel="guides/episode10-guide.md"),
      str(scan_text(loop, rel="guides/episode10-guide.md")))
lawful_rows = "Never ship un-restyled frames from different rows together; a Restyled composition from another row is lawful.\n"
check("the softened row rule passes", "rows-absolute" not in scan_text(lawful_rows), str(scan_text(lawful_rows)))
eight = "The demo product carries eight secondaries, sec-01.png through sec-08.png; the brief owns the count.\n"
check("eight secondaries pass the count rule", "secondary-count-hardcoded" not in scan_text(eight), str(scan_text(eight)))

# 2a2. Kit v55: the lawful sheet sentences pass; only the upload of a Genrupt sheet fails.
for lawful in ("Do not download and re-upload a Genrupt sheet merely to use it in the same project.\n",
               "Upload the corrected PNG as a source image, after upload_check.py prints ALLOW.\n",
               "Wonka never uploads the same sheet a second time.\n",
               "A missing sheet is attached once by id, never by uploading its file.\n"):
    check(f"lawful sheet wording passes: {lawful[:40]}", "upload-a-genrupt-sheet" not in scan_text(lawful), str(scan_text(lawful)))

# 2a3. The pool rule: counting the pool and keeping the sheets alone passes.
for lawful in ("Read what it reports as already on the flow and COUNT it. Keep the approved sheets and nothing else.\n",
               "Pass `productReferenceSheetIds: [the approved sheets]` (normally two).\n"):
    found = scan_text(lawful)
    check(f"lawful pool wording passes: {lawful[:40]}",
          not found & {"aplus-keeps-the-pool", "aplus-every-approved-sheet"}, str(found))
aplus = ".claude/skills/aplus/SKILL.md"
omit = "Omit `selectedReferenceImageUrls` and use the shared project pool.\n"
check("the A+ room may not omit the selection", "aplus-omits-selection" in scan_text(omit, rel=aplus), str(scan_text(omit, rel=aplus)))
rule = "On A+ an omitted `selectedReferenceImageUrls` uses the WHOLE pool, so step 5 selects the sheets.\n"
check("CLAUDE.md may describe the omitted selection", "aplus-omits-selection" not in scan_text(rule, rel="CLAUDE.md"), str(scan_text(rule, rel="CLAUDE.md")))

# 2b. The strict rules fire even though their own wording carries a negator.
strict = "Get the images into `incumbent/` tonight, because Day 8 does not work without them.\n"
check("a negator inside a strict rule's own wording is no defence",
      "day8-cannot-start-without" in scan_text(strict), str(scan_text(strict)))
# Wonka doing the fetch is the lawful path and is not the student downloading.
wonka_fetch = "Wonka downloads them once into `incumbent/` at step 0b; you save by hand only if refused.\n"
check("Wonka downloading into incumbent/ is lawful", "student-downloads-incumbent" not in scan_text(wonka_fetch),
      str(scan_text(wonka_fetch)))
# 2b2. The v41 rule names what it bans; the lawful sentences carry a negator and pass.
lawful_pack = "An approval completes Day 8 and never starts packaging; /ready-to-upload runs only when the owner invokes it.\n"
check("the lawful packaging sentence passes", "packaging-after-approval" not in scan_text(lawful_pack), str(scan_text(lawful_pack)))
lawful_brief = "Approving the brief was the approval for the planned batches; the reference sheet and the smoke test follow it.\n"
check("brief approval wording is not a packaging violation", "packaging-after-approval" not in scan_text(lawful_brief), str(scan_text(lawful_brief)))

# 2c. Scoped rules stay out of the paths they do not cover.
weekly = "One priority this week; the rest is noise and nougat.\n"
check("'this week' inside a skill is out of scope",
      "this-week" not in scan_text(weekly, rel=".claude/skills/factory-report/SKILL.md"),
      str(scan_text(weekly, rel=".claude/skills/factory-report/SKILL.md")))
check("  ... and in scope inside a guide", "this-week" in scan_text(weekly), str(scan_text(weekly)))

# 3. The negation guard: a rule that FORBIDS the thing must not fire on itself.
compliant = (
    "Wonka does not propose a palette from the product, the category or the buyer.\n"
    "A logo is never routed into packagingImages or into a slot's referenceImages.\n"
)
# The lawful path: the owner ran the room and said yes. Consent words excuse the proposal
# rule and ONLY that rule.
asked = "On an explicit yes, Wonka proposes a starting direction for colors and tone.\n"
check("a proposal the owner explicitly asked for passes", not scan_text(asked), str(scan_text(asked)))
asked2 = "Do you want me to propose a starting direction for colors, typography and tone?\n"
check("  ... and so does the question that offers it inside the room", not scan_text(asked2), str(scan_text(asked2)))
unasked = "Seeing no brand files, he proposes a palette drawn from the category.\n"
check("  ... while an unasked proposal still fails", "proposes-a-brand-unasked" in scan_text(unasked), str(scan_text(unasked)))
consent_does_not_excuse_others = "The owner asked, so put the logo in packagingImages.\n"
check("  ... and consent never excuses a different rule",
      "logo-into-packaging" in scan_text(consent_does_not_excuse_others), str(scan_text(consent_does_not_excuse_others)))

dead = ("The old \"403, cannot attach\" workaround is dead; props are lawful and never tagged.\n"
        "Wonka never recites the image requirements page, and nothing is called safely compliant in front of the owner.\n")
check("naming the dead workaround and lawful props does not fire", not scan_text(dead), str(scan_text(dead)))
check("a rule that forbids the thing does not fire on itself", not scan_text(compliant),
      str(scan_text(compliant)))

# 4. Hard-wrapped prose is judged as one sentence, not two halves.
wrapped = ("Wonka does not\npropose a palette from the product, the category, the buyer or the\npackaging.\n")
check("a hard-wrapped negation still reads as a negation", not scan_text(wrapped),
      str(scan_text(wrapped)))
check("  ... and paragraphs are the scanning unit",
      list(logical_lines("a\nb\n\nc"))[0] == (1, "a b"), str(list(logical_lines("a\nb\n\nc"))))

# 5. A deleted contract line is a failure, not a silent pass.
with tempfile.TemporaryDirectory() as d:
    root = Path(d)
    (root / "guides").mkdir()
    (root / "guides" / "x.md").write_text("nothing to see", encoding="utf-8")
    _v, miss = scan(root)
from kit_contract_check import REQUIRED  # noqa: E402
check("a missing contract line is reported", len(miss) == len(REQUIRED), f"{len(miss)} reported")

# 6. The pre-launch track (kit v37, 11 September 2026): one test per new needle, and the
#    old "park blocked, no ASIN" sentence is banned so nobody can put it back. (The literal is
#    assembled here so a grep of the kit for it finds only shipped prose, never this fixture.)
_parked = "blocked: no " + "ASIN"
check("catches no-asin-blocked",
      "no-asin-blocked" in scan_text(f"If the tool cannot run without an ASIN, park `{_parked}, A+ tool requires one`."),
      str(scan_text(f"park `{_parked}, A+ tool requires one`")))
check("  ... and STRICT: a negator does not excuse it",
      "no-asin-blocked" in scan_text(f"Never park `{_parked}` again."),
      str(scan_text(f"Never park `{_parked}` again.")))
for rel, needle in [
    ("factory/Products/TEMPLATE/status.md", "Anchor ASIN"),
    (".claude/skills/aplus/SKILL.md", "listingReferenceMode"),
    (".claude/skills/creative-brief/SKILL.md", "flowAction"),
    (".claude/skills/meet-my-product/SKILL.md", "Anchor ASIN"),
]:
    check(f"{rel} must say {needle!r}", (rel, needle) in REQUIRED, "needle not in REQUIRED")
    with tempfile.TemporaryDirectory() as d:
        root = Path(d)
        f = root / rel
        f.parent.mkdir(parents=True, exist_ok=True)
        f.write_text((KIT_ROOT / rel).read_text(encoding="utf-8").replace(needle, "REMOVED"), encoding="utf-8")
        _v, miss6 = scan(root)
    check(f"  ... and its removal from {Path(rel).name} is reported", (rel, needle) in miss6, str(miss6[:3]))

# 7. Kit v38 (12 September 2026): invocation runs the sitting, Round 2 is never required, the
#    Shipping Room opens on the owner's recorded decision. One needle per new contract line and
#    one ban per sentence that would bring the old policy back.
_ask = "Proceed" + "?"
check("catches proceed-question inside the Tasting Room skill",
      "proceed-question" in scan_text(f'Quote the cost, then stop: "a few dollars per race. {_ask}"',
                                      rel=".claude/skills/tasting-room/SKILL.md"),
      str(scan_text(f"{_ask}", rel=".claude/skills/tasting-room/SKILL.md")))
check("  ... STRICT: a negated mention is still banned there",
      "proceed-question" in scan_text(f'Never ask "{_ask}" before a race.', rel=".claude/skills/tasting-room/SKILL.md"))
check("  ... and the same word is lawful in another skill",
      "proceed-question" not in scan_text(f"{_ask}", rel=".claude/skills/fix/SKILL.md"))
_weaker = "required after anything " + "weaker"
check("catches round-2-required kit-wide",
      "round-2-required" in scan_text(f"a second tasting is optional after a Clear lead and {_weaker}"),
      str(scan_text(_weaker)))
_gate = "Never opens on a verdict weaker " + "than Clear lead"
check("catches clear-lead-gate",
      "clear-lead-gate" in scan_text(f"- **{_gate}**, and never talks a Lean up into a decision.",
                                     rel=".claude/skills/ready-to-upload/SKILL.md"),
      str(scan_text(_gate, rel=".claude/skills/ready-to-upload/SKILL.md")))
for rel, needle in [
    (".claude/skills/tasting-room/SKILL.md", "spend_cap_usd"),
    (".claude/skills/inspect/SKILL.md", "Gallery pick:"),
    (".claude/skills/ready-to-upload/SKILL.md", "Owner decision:"),
]:
    check(f"{rel} must say {needle!r}", (rel, needle) in REQUIRED, "needle not in REQUIRED")
    with tempfile.TemporaryDirectory() as d:
        root = Path(d)
        f = root / rel
        f.parent.mkdir(parents=True, exist_ok=True)
        f.write_text((KIT_ROOT / rel).read_text(encoding="utf-8").replace(needle, "REMOVED"), encoding="utf-8")
        _v, miss7 = scan(root)
    check(f"  ... and its removal from {Path(rel).name} is reported", (rel, needle) in miss7, str(miss7[:3]))

# 8. Kit v40 (12 September 2026): the Variations Room takes three kinds of input, labels
#    concepts, and never asks "Proceed?". A concept is allowed; a CLAIM is what is never invented.
_invent = "Never invent " + "a variant"
check("catches never-invent-a-variant inside the Variations skill",
      "never-invent-a-variant" in scan_text(f"Either way, the confirmed list gets written down. **{_invent}**, and never write none on a guess.",
                                            rel=".claude/skills/variations/SKILL.md"),
      str(scan_text(_invent, rel=".claude/skills/variations/SKILL.md")))
check("  ... STRICT: a negated mention is still banned there",
      "never-invent-a-variant" in scan_text(f"Do not say {_invent} any more.", rel=".claude/skills/variations/SKILL.md"))
check("  ... and the same words are lawful in another skill",
      "never-invent-a-variant" not in scan_text(_invent, rel=".claude/skills/fix/SKILL.md"))
check("catches proceed-question inside the Variations skill too",
      "proceed-question" in scan_text(f'Say the cost. {_ask}', rel=".claude/skills/variations/SKILL.md"),
      str(scan_text(_ask, rel=".claude/skills/variations/SKILL.md")))
for rel, needle in [
    (".claude/skills/variations/SKILL.md", "status: real | concept"),
    (".claude/skills/variations/SKILL.md", "spend_cap_usd"),
    ("guides/episode9-guide.md", "Three ways"),
]:
    check(f"{rel} must say {needle!r}", (rel, needle) in REQUIRED, "needle not in REQUIRED")
    with tempfile.TemporaryDirectory() as d:
        root = Path(d)
        f = root / rel
        f.parent.mkdir(parents=True, exist_ok=True)
        text = (KIT_ROOT / rel).read_text(encoding="utf-8") if (KIT_ROOT / rel).exists() else ""
        f.write_text(text.replace(needle, "REMOVED"), encoding="utf-8")
        _v, miss8 = scan(root)
    check(f"  ... and its removal from {Path(rel).name} is reported", (rel, needle) in miss8, str(miss8[:3]))

print()
if FAILURES:
    print(f"{len(FAILURES)} FAILED: {', '.join(FAILURES)}")
    sys.exit(1)
print("all passed")

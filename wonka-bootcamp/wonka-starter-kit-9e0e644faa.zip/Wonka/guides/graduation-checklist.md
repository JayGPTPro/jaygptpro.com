# Graduation Checklist

This is the canonical checklist. If any other page in this kit, the portal, or an email lists
graduation items differently, this file wins.

Every item below is verifiable: a file that exists, a Tasting Round that ran, a habit that is set.
Go top to bottom. Ask Wonka to help you verify any of it:

```
Run me through the graduation checklist and verify each file exists.
```

The list comes in two parts. The **Package checklist** is the core: everything a finished bootcamp
should have produced, on disk, for your product.

The **Factory Owner extras** are what turn a completed bootcamp into a running factory. Recommended,
not required.

Each day's guide ends with its own Definition of Done. Those track the day. This list tracks the
package: it is the cross run check that everything actually exists on disk.

**Four things people expect to find here and will not.** All four are deliberate:

- **Uploading is not required.** The promise is a package that is ready to upload. When it goes live
  is your call and your timing.
- **Posting in the group is not required.** Worth doing, never a condition, and not every ticket
  includes a group.
- **Day 9, variations, is entirely optional** for a single-SKU product.
- **Improvement Log entries are extras.** They sit in the Factory Owner section on purpose.
  They make your next product better.

This list is about the work, never about a sales number. Results vary by product and niche.

---

## Package checklist (what a finished run produces)

### Day 1: The Front Gate

- [ ] Claude Pro (or Max) active; the kit folder opens in the Code tab
- [ ] Wonka answers "Who are you?" in character, and refuses when you push him to skip research
- [ ] Genrupt connected and verified by Wonka with a live read only call (or the fallback path
      consciously chosen and recorded)
- [ ] OpenAI API key created, funded, organization verification complete, key saved per
      `guides/mcp-setup-guide.md` (one key, four rooms: the Main Image Room's second blast, the Fixing Room, the Tasting Room, and the Variations edit path)
- [ ] Pilot product chosen; real photos taken (all angles, hand for scale, label close ups), or the
      listing gallery fallback consciously chosen and recorded
- [ ] First Candy printed at `output/first-candy.png`, proving the OpenAI pipeline end to end (or
      consciously declined)
- [ ] Inputs folder packed: reviews, competitors, photos, your owner intel, and your niche phrase
      decided word for word

### Day 2: Wonka, Meet My Product

- [ ] `/meet-my-product` ran: `factory/Products/[your-product]/` exists with its full folder structure
      (`1-inputs`, `2-reference`, `research`, `brief`, `images`, `edits`, `final`, `incumbent`,
      `aplus`, `variations`, `scorecards`, `tests`) plus `status.md`, verified by listing it
- [ ] The listing title was read back to you and confirmed, so the ASIN in your folder is the right
      product and not just the right format
- [ ] `status.md` exists with the station tracker and your owner intel recorded verbatim (or
      explicitly marked as none given)
- [ ] All five research files exist with real content: `insights.md`, `reviews.md`, `persona.md`,
      `competitors.md`, `selling-points.md`
- [ ] `research/product-report.md` exists, the one unified report the Day 3 brief is built from
      (its absence is a hard block tomorrow)
- [ ] Reviews were collected while logged in, critical ones included (or the thin basket recorded as
      a waiver, in writing)
- [ ] 3 to 5 competitors confirmed as genuinely your niche, and the check is stated in
      `competitors.md`, with table stakes, their strong frames, and the whitespace
- [ ] Buyer persona and funnel diagnosis exist, each honestly labelled where it is estimated
- [ ] You read the selling points checklist and corrected or confirmed it
- [ ] You sent at least one correction and Wonka recorded it
- [ ] RESEARCH shows `done` in `status.md`

### Day 3: The Creative Brief

- [ ] `brief/creative-brief.md` exists covering the full package: main image, secondaries, cast,
      variations
- [ ] The three main image controls (tactic, hang tag text, packaging preference) answered by YOU,
      plus an incumbent read, a written main-image brief, and 3 to 5 ranked selection criteria
- [ ] Every asset has one job and one dominant message, and no two assets share a message
- [ ] Every selling point mapped to an asset, or consciously skipped in writing with a real reason
- [ ] The cast is 1 to 2 custom avatars with explicit age and gender, and no slot text describes a
      person
- [ ] The promise check ran, and no headline promises something your reviews do not support
- [ ] Variations planned from your real SKU list, or stated as none, in writing
- [ ] You asked all three review questions, overruled Wonka at least once, and your reason is
      recorded in the file in your own words
- [ ] `Owner review: approved`, a written `## Send log`, and `status.md` shows BRIEF done
- [ ] The saved Genrupt plan carries YOUR text in every secondary slot, and slot 1 is untouched

### Day 4: The Reference and Brand Rooms

- [ ] Your product photos are in `2-reference/photos/`; the Mold is built from them (or from an
      explicit, recorded fallback written as `source: amazon_scraped` with a date)
- [ ] The reference sheet was judged against all FIVE criteria before approval: every angle, a scale
      cue, every panel clear and attractive, honest materials, nothing added
- [ ] Every sheet version is still on disk as `sheet-v[N].png`. Nothing was overwritten
- [ ] `2-reference/reference-sheet.md` carries the line `Reference status: LOCKED`, and the spec is
      accurate: size, materials per part, parts counted, label text
- [ ] Smoke test run as ONE image per slot, EVERY frame opened and looked at, and PASSED before any
      blast
- [ ] Read one passed: parts and count, materials, scale, nothing invented, on every frame
- [ ] Read two happened: you were asked whether any frame is one you do not want, and any change
      went into the BRIEF rather than into a re-rolled image
- [ ] `factory/Brand/brand-kit.md` filled: colors with hex, typography direction, tone, and the
      approved claims table, which you read yourself. No logo and no claim was invented
- [ ] The branding preset exists and is ATTACHED to the plan you saved on Day 3, not just created
- [ ] `status.md` records the passed smoke test and the brand kit

### Day 5: The Main Image Room

- [ ] The line was confirmed ready (brief, brand kit, locked reference, passed smoke test) before any
      spending. Cost was REPORTED rather than gated: approving the brief was the approval
- [ ] Every enabled tactic was confirmed by you and every dropped one carries a written reason.
      **The vanilla control ran as its own small job** (it is not a tactic and never rides inside the blast), so a safely compliant candidate exists
- [ ] The hang-tag text is YOUR words, inside 28 characters and 5 words, or you decided knowingly to leave it
      auto. If a packaging tactic ran, real packaging photos were in the bucket
- [ ] **Both machines blasted** (or the missing one was named out loud with what it would have
      added): Genrupt's Draft Blast ran on the saved plan, and the OpenAI Blast's pool sits in
      `images/openai-blast/` with its contact sheet
- [ ] **The SPREAD was reported per tactic before you started picking.** A single-tactic run was
      caught and fixed rather than picked from
- [ ] You read your selection criteria BEFORE opening the grid, not after
- [ ] **Between one and five mains chosen, genuinely different from each other, one of them safely
      compliant.** Not one
- [ ] The selection was read back to you by name and count, then downloaded or promoted into
      `images/` with the slot completion marked. Nothing important was left living only inside
      Genrupt, and the shortlist was picked from the union of both pools
- [ ] No candidate carries a face, and hands appear only if you enabled the human-contact tactic.
      No overlay text or graphics on anything
- [ ] `/inspect` ran: scorecard in `scorecards/` with the literal description per candidate, the
      dimension scores, the separate compliance gate, and a ranking with its tie break
- [ ] `scorecards/squint/` holds a 160 pixel copy of every inspected image, and you personally opened
      one and looked at it
- [ ] `/fix` ran on everything flagged, each item ROUTED correctly (take away or swap a word is an
      edit, make it or move it is a regenerate), the round saved as a complete `edits/v1/` snapshot,
      every original intact, everything re inspected
- [ ] No winner picked, nothing uploaded. **Unless you deliberately started a weekend A/B test, in
      which case you saved your current main first**

### Day 6: The Secondary Images Room

- [ ] For each slot you can say the ONE NEED it removes, not the feature it shows
- [ ] You decided consciously whether to keep mobile-friendly on, rather than never noticing it
- [ ] The Theme Blast was read as ROWS. **You did not cherry-pick frames across different rows**
- [ ] Style AND composition were two separate decisions, both made deliberately
- [ ] The chosen style was sent to Refine, and Wonka read the lock back rather than reporting success
- [ ] **Refine ran more than one round**, and stopped because a round stopped improving things rather
      than at a fixed number
- [ ] One frame per slot chosen, against its job in the brief, and brought home to `images/` with
      every slot completion marked
- [ ] Your main candidates and their scorecard are untouched
- [ ] A NEW secondary scorecard sits in `scorecards/` beside the main one, and `scorecards/squint/`
      holds a 160 pixel copy of every frame
- [ ] All four set level checks green: no message overlap judged on MEANING, no repeated face, one
      emotional frame present, selling points covered
- [ ] The cover-the-text test was run on every frame: it still says the thing without its words
- [ ] Anything not covered is recorded as a conscious skip, in writing, with a reason
- [ ] Anything whose IDEA was wrong went back to Refine rather than to `/fix`
- [ ] `/fix` ran on the remaining blemishes, saved as a new complete `edits/vN/` snapshot with
      originals untouched, whole set re inspected clean

### Day 7: The A+ Room

- [ ] **The module count was decided BEFORE generating**, and it records whether you are adding your
      own comparison chart or FAQ. Seven normally, six if you are
- [ ] The carousel decision was made deliberately, after seeing a real one, **with its reason recorded
      either way**
- [ ] `/aplus` ran HANDS-OFF: no content direction passed in. It inherited the locked reference, the
      style you sent to Refine, the branding preset and the approved claims table
- [ ] **Four concepts on desktop and four on mobile**, or a knowing trade-off recorded instead
- [ ] `aplus/aplus-plan.md` (the run record) was written BEFORE generation, not after
- [ ] You picked your concept on BEAUTY rather than on coverage, and said why
- [ ] `/inspect` ran scoped to the A+: text size squint-tested mechanically, and every claim checked
      against your approved claims table
- [ ] **Every fix ran INSIDE Genrupt, not through the OpenAI API.** This is the only place the routing
      flips, and the reason is the export
- [ ] The round saved as a new complete `edits/vN/` snapshot, originals intact, re inspected to green
- [ ] **The export was run and then VERIFIED by listing the folder**: module count matches, both modes
      present, nothing zero bytes. The files are upload-ready without resizing or renaming
- [ ] You read the complete page top to bottom like a stranger, and answered all three page questions:
      does the story hold, does anything contradict, does the A+ just repeat the gallery
- [ ] The A+ column of your coverage map is CLOSED. Anything expected there and missing was named
- [ ] Your live main image and live gallery are downloaded into `incumbent/`, and `tests/` is still
      empty
- [ ] `status.md` shows the full package built and gate passed, testing next

### Day 8: The Tasting Room

- [ ] It raced your **FINAL** images, and you heard the filenames read back before it started
- [ ] **Your CURRENT live main image and gallery were IN both races.** Nothing live yet? A named
      competitor was used instead, and you know that is a different claim
- [ ] Both races ran: the main race, and the gallery race with both stacks in GALLERY ORDER
- [ ] Two Tasting Cards exist under `tests/`, each with `tasting-card.html`, `tasting-card.md`,
      `results.json` and `config.json`
- [ ] **You read the TIER before the count** and called it honestly: clear lead, lean, or
      toss-up. A toss-up was treated as a result rather than a failed test
- [ ] **Every objection read verbatim and sorted into three piles:** creative can fix it, the listing
      can fix it but not with an image, and nobody can fix it
- [ ] Any objection appearing in BOTH races is written down as your biggest gap
- [ ] Every change Wonka proposed is **physical rather than a wish**, and cites the objection it
      answers with its taster count
- [ ] **At least one objection consciously REFUSED, with its reason recorded**
- [ ] Everything changed was RE-INSPECTED before you called the set final
- [ ] **Your set is final, and you know what the panel actually said about it.** Both races are
      logged in the Improvement Log. The verdict itself is not a checklist item and cannot be,
      because this list is about the work and never about the result. Three honest endings,
      all of them a pass:
      - **One of yours took a Clear lead.** The Shipping Room opens on Day 10 and packages it.
      - **The verdict was Lean or Toss-up.** You refined off the notes and you know exactly what
        the next round tests. Say it plainly rather than talking it up.
      - **Your live image won.** That is the cheapest good news in the factory: a working listing
        was not downgraded, for the price of lunch, instead of finding out over months of lost
        traffic. Keep the live images, keep the teardown of WHY they hold, and build from it.

### Day 9: The Variations Room

**Skippable.** If your product is a single SKU, none of this applies and you have not
fallen behind.

- [ ] The child list came from real evidence, ASINs or a folder, and **you heard it read back** and
      corrected anything misread
- [ ] **The FRAME TABLE and the TRUTH TABLE were read and corrected.** Every frame classified
      (shape / printed value / nothing, which is REUSED untouched), products counted per frame, and
      each child's printed facts taken from its OWN listing, never carried across
- [ ] **Type A or Type B chosen deliberately, with the reason recorded.** Not discovered halfway
- [ ] **ONE pilot child done first, the hardest one**, with the four checks run: right attribute,
      this child's printed values, only that changed, product still itself
- [ ] Every failed pilot attempt is still recorded with what was tried
- [ ] When the pilot was wrong, the **INSTRUCTION** was fixed rather than the image
- [ ] Two or three genuinely different phrasings were tried, not five nudges of one. If all three
      failed the same way, the upstream cause was named rather than a fourth phrasing attempted
- [ ] The family ran on the **exact instructions that worked, unchanged**, and frames carrying
      nothing variant-specific were reused rather than regenerated
- [ ] The drift sheets were read (drift where the edit lives is the job, anywhere else a defect) and
      **every hero frame was opened at full size**
- [ ] **Swatches judged at real picker size**, beside each other
- [ ] The family checked as a family: right attribute on every child, nothing else drifted
- [ ] A failed child was re-run alone on its fixed prompt, never the whole family
- [ ] `/inspect` ran scoped to the variations, and the upscale past the zoom threshold (reused
      frames included) happened only after the gate

### Day 10: The Improvement Loop

- [ ] `/improvement-loop` ran and `factory/Improvement Log.md` has real entries in all three parts
- [ ] **Every market pattern CITES the test that produced it.** No citation, no pattern
- [ ] **At least one honest MISTAKE is recorded**, not only the things that worked
- [ ] Every gap in the experiments ledger is written IN as a gap rather than left as an absence
- [ ] You walked your own folders and can say what each one holds
- [ ] The shipping decision matches your Day 8 verdict: on a **Clear lead**, `/ready-to-upload` ran
      and `tests/upload-pack.md` explains every choice to a stranger, **including what you
      consciously did not fix**. On a Lean, a Toss-up, or a live-image win, the written Round 2
      plan (or the recorded keep-the-live-set decision) stands in its place, dated
- [ ] `/factory-report` ran, and **every blocked item names an OWNER**
- [ ] The three next actions are decided and dated: upload it this week, start an A/B on your main
      and keep one running, and an honest answer on whether your stakes justify a paid survey

## Factory Owner extras (recommended, not required)

These are Day 10's closing missions plus the habits that turn a finished run into a running factory.

- [ ] Amazon A/B launched in Manage Your Experiments, or the direct upload done, or either one
      consciously scheduled
- [ ] Improvement Log has its first real pattern entries from both Tasting Rounds, main race and gallery
      race (`factory/Improvement Log.md`, Part 1), written by `/improvement-loop`, and you have read them once
- [ ] the Improvement Log has its first process entries (`factory/Improvement Log.md`, Part 2), written by
      `/improvement-loop`, and you read his answer to "what will you do differently on product two?"
- [ ] Product two continued past the Day 10 speed run: its research approved, or its next station
      dated
- [ ] Weekly `/factory-report` habit set: a scheduled task if your Claude setup supports one on this
      folder, or a recurring reminder to run the command yourself
- [ ] At least one factory report exists in `factory/Factory Log/`
- [ ] All 5 stations in `status.md`: resolved

## All checked?

Package checklist done by the end of the bootcamp: you are a graduate with a full, tested creative
package ready to upload. Extras done too: you did not finish a course, you commissioned a factory.

---

# Your Factory After the Bootcamp

The operating rhythm that keeps it compounding:

**Weekly (one command and 10 minutes of you):**
- `/factory-report` runs weekly, by scheduled task or by your own reminder. Read it. Unblock whatever
  it says is blocked.
- If an Amazon A/B is running, glance at Manage Your Experiments. No decisions before the test
  matures (8 to 10 weeks). Peeking is fine, flinching is not.

**Every week or two (one production run):**
- Put the next product through the full line, the same ten day sequence you just learned. One product
  every week or two is a sustainable pace that most brands' entire creative calendars cannot match.
- Never skip stations to go faster. The line IS the speed. Rework is what is slow.

**Monthly (30 minutes):**
- Review Part 1 of `factory/Improvement Log.md`: which patterns are hardening into USE, which went MIXED, what should
  be pruned.
- Review Part 2 of the same file: the process lessons Wonka has recorded, so you know how he is
  getting better at his own job.
- Review the experiments log: any matured A/B results to record? Run `/improvement-loop` on each one.
- Ask Wonka: `Read the Improvement Log and tell me the three strongest patterns we've proven so far.`
  That answer is your creative strategy, written by your own customers.

**When a test result lands, always:**
- `/improvement-loop` the same day: what converted in your market (Part 1 of the Improvement Log) and how
  Wonka can work better next time (Part 2), both from one command. An unrecorded result is a lesson the
  Factory never receives.

"Same factory, next candy. Bring a product worth inventing for."

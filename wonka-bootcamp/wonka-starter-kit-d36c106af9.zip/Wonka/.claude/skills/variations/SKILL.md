---
name: variations
description: Build the variation imagery for a product sold in more than one child SKU (colors, sizes, shapes, scents, flavors, counts, bundles). Classifies the tested set frame by frame, builds a per-child truth table from each child's own listing, then propagates the family in two edit layers (shape, then printed text) off the tested winner so the family reads as one brand, measures what drifted, and writes the Amazon parent/child embedding map. Refuses to invent a child the product does not sell. Use when the package is briefed, referenced and tested, and the owner can name the real children. Triggers: /variations, "make the variation images", "color swatches", "size variants", "bundle images", "multipack images", "variation set", "variation family", "parent child listing images", "variations room".
---

# The Variations Room

| Meta | Value |
|------|-------|
| Room | The Variations Room |
| Station | INVENT (variations are one of the four Invent sub-parts) |
| Day | Day 9 in the bootcamp, run after the tested set is final. Also runs any time a child is added or a single child is sent back |
| Modes | MODE 1: the PILOT, one child done properly first. MODE 2: the rest of the family, propagated once the pilot is right. MODE 3: one child re-run, driven by an inspection flag or a new child |
| Needs | brief/creative-brief.md (its VARIATIONS section), 2-reference/reference-sheet.md (LOCKED, smoke test PASS), the REAL child list from the owner, the `Genrupt preset ID` row of status.md (optional), the tested set on disk, a live machine for the chosen path |
| Saves to | Finals: factory/Products/[product]/variations/ (main-[child].png, swatch-[child].png, per-child propagated frames [slot]-[child].png, variations-plan.md). Machinery: factory/Products/[product]/variations-work/ (manifest.json, source/, refs/, working/, qa/) |
| Typical cost | Type A edit path: cents per edit call on the OpenAI key (an image edit is a fraction of a cent to a few cents). Type B / fallback: Genrupt credits per image. No upscale here: the Shipping Room upscales the family once, with the mains. **Reported, not gated.** The brief approval authorises the run; re-runs get named before they spend again. |

## What this room does

Until now, a product with eight variants meant eight separate photoshoots or eight separate design
jobs. **This room takes one tested set and propagates it across the whole family**, and the work
drops from days to a plan, a pilot, and a button.

The economics rest on one idea: **most of a variant family already exists.** The tested set was
briefed, referenced, inspected and tasted. A child differs from it in a bounded, nameable way: a
shape, a color, a printed count, a printed size. So the room never regenerates what did not change.
It classifies every frame, EDITS the frames that carry the difference, and REUSES the rest
untouched. A frame that carries nothing variant-specific is reused, not regenerated. That single
rule is what turns "eight children times seven frames" into a bounded number of cheap calls.

### Two kinds of variation, and the owner picks

This is the first question, and getting it wrong means redoing the family.

**TYPE A, identical except the variant.** Everything in the frame stays byte-for-byte the same
intent: the same model, the same pose, the same background, the same props, the same layout. **Only
the varying attribute changes.** A red shirt becomes a blue shirt on the same person in the same
room. Choose this when the family should read as one product in several colours, which is what most
apparel, most packaging colourways and most scent ranges want. **Type A runs as EDITS of the tested
set**, two layers per frame (shape, then text), on the OpenAI key with this room's bundled scripts.
That is what makes "identical except the variant" literally true: the pixels that did not change
are the same pixels.

**TYPE B, regenerated on the same brief.** The image is generated again from the same brief and the
same prompt, so it carries the same message and the same job, but the model may be a different
person, the styling may differ, and the composition may shift. Choose this when the owner WANTS
visual variety across the family, so the listing gallery does not feel like the same photograph
recoloured eight times. **Type B runs as GENERATION on Genrupt** off the locked reference, exactly
like the other Inventing rooms.

**Neither is correct in general.** Ask, record the answer with its reason, and say the tradeoff out
loud: Type A is coherent and can feel repetitive; Type B feels alive and can feel like a different
product. Nobody should discover this preference after the whole family is generated.

### The pilot rule

**Do ONE child properly first, and only then propagate.**

A family generated in one go on an untested prompt is a family regenerated in one go. Doing a single
variant, looking at it honestly, and fixing the prompt until it is right costs one image; discovering
the same problem across eleven costs eleven.

Once the pilot is right, the rest is one confirmation.

### And the brief does not change

Variations are the SAME brief. Same message, same job, same claims where the claims are shared. **A
variant that needs a different brief is not a variant, it is a different product**, and it goes back
through the pipeline rather than through this room.

Two lawful nuances, both recorded rather than discovered:
- A specific variant may earn a specific extra image (a size chart that only applies to the large, a
  use case that only applies to one scent). That is an addition, not a divergence.
- **Claims MAY differ per child, and that is the truth table's job.** A smaller size fits a smaller
  basket; an eight pack prints a different count. Same story, different printed facts. Every changed
  claim is named up front in the truth table, never left for the machine to guess.

## Before you start

Check these in order and report what you found out loud before spending anything.

1. **Brief. HARD.** `brief/creative-brief.md` exists. Read its VARIATIONS section and say back what it currently claims. Three lawful states, all workable: a real child list, `variations: none (single SKU)`, or `variations: unconfirmed`. Missing brief entirely: station **BLOCKED**, point to `/creative-brief`, stop. What is never lawful is generating a family while the brief on disk says something else; that is resolved in Process step 3, before any credit is spent.
2. **Locked reference. HARD.** `2-reference/reference-sheet.md` exists with `Reference status: LOCKED` and `Smoke test: PASS`. An approved reference WITHOUT a passed smoke test does not count. Missing or unpassed: **BLOCKED**, point to `/reference-sheet`, stop. Also read the sheet's `source:` field: if it records `amazon_scraped`, say so plainly once ("this reference was built from listing and review images, not from photos of the unit, so product likeness is the weaker path here"), tighten the fidelity check in step 11, and carry the source into the plan.
3. **The tested set. HARD for Type A, SOFT for Type B.** Type A edits an existing set, so name the exact folder it edits: the highest `edits/v[N]/` (the Fixing Room's contract says it holds the complete current set), or `images/` when no round ran. If `tests/` holds a Tasting Card with a winning main, say which file the family inherits from. For Type B with no tested set, the family inherits the Reference Sheet's shot language plus the brief's main-image direction, and the plan records `inherits from: reference sheet (no tested winner yet)`. Never build a family from scratch when a tested set exists; that is the whole economic point of this room.
4. **The branding preset. OPTIONAL, and resolved from `status.md`.** Read the `Genrupt preset ID` row, not `brand-kit.md`'s existence. An id there is attached, including a **logo-only preset**; `none` there is a complete state: PROCEED, record `brand: none on file` in the plan and the status line, and score brand fit accordingly at inspection. Do not offer `/brand-kit`, and never invent a palette, a font or a brand to fill the hole. On the Type A edit path this bites less anyway: the edits inherit the tested set's brand treatment pixel for pixel.
5. **A machine for the chosen path.** Type A needs Machine 2, the OpenAI key (the same key the Fixing Room and the Tasting Room run on), plus Python with `openai` and `Pillow` installed; `/machines-check` verifies the key. Type B needs Genrupt MCP. If the Type A machine is missing, offer the fallback explicitly: the same family through Genrupt's variations flow, equal in quality and dearer per image; never switch paths silently. If NEITHER machine is available, the room is closed: mark `blocked: no generation machine` in `status.md`, point to `/machines-check` and `guides/mcp-setup-guide.md`, and stop.

## The child list, and the three honest answers

This is the spine of the room, so it happens before planning and before any estimate. **And it starts with Wonka's own hands, per the spare-the-owner ladder**: the live listing's variation picker is ON the product page, so when this session can reach the page (or `/meet-my-product` already recorded the picker), Wonka FETCHES the family Amazon shows and STATES it, "here is the family your listing sells today", and the owner's question shrinks to the one only they can answer: **which of these are actually saleable today, and what exists that the listing does not show yet.** Only with no page access does the question start from zero. Never read a child list off a competitor's listing, off the category, or off your own assumption that a product "probably comes in other colors", and take the owner's final answer literally: the picker is evidence of what the listing SHOWS, the owner is the authority on what is REAL.

**Answer 1: a real list.** Write down the theme and every real child, in the owner's own words, with the attribute value for each. That list is the batch plan; nothing outside it is generated, ever.

**Answer 2: "none, it is a single SKU."** A complete and common answer, not a failure. Do not generate anything. Then offer one option, once, without pushing: a **multipack of the identical unit** is the only variation type that invents zero product facts, because two of the same real unit is still the same real unit, only the count changes, and it is the child a single SKU seller genuinely adds first. Say plainly that a bundle is a SKU the owner would have to really create and really stock, so it is a business decision and not an image decision. If they take it, that IS a real child list and the run continues at Answer 1, with the brief amendment in Process step 3. If the answer is still no, `n/a` is the finished state of this room, recorded with the date, and the rest of the package is unaffected.

**Answer 3: "I don't know."** Do NOT guess and do NOT write `none` on a guess. Record `child list: unconfirmed` and name the two places the truth lives: the live listing's own variation picker, and the parentage or variation view in Seller Central. Then park this sub-part only: `Variations (/variations): blocked: child list unconfirmed` in `status.md`, with the exact question to answer. Say clearly that nothing else is held up, because variations are the one sub-part allowed to trail the rest of the package; INSPECT and PROVE continue on the main, the gallery, and the A+.

**And measure each child against ITS OWN photos before any parent law is applied to it.** A child is not always the parent in another colour: measured 27 August 2026, two children of a brush set had no separate ferrule neck at all (a painted continuous shaft tapering straight into the ferrule) while the parent's reference sheet carried the law "warm brass neck, never chrome". Propagating that law would have rendered both children wrong, confidently. So before the truth table is written, compare each child's real photos to the parent's anatomy table and record which parent facts DO NOT apply to which child. A structural difference is not a variation layer, it is a different mold, and it may need its own reference.

Two standing rules for whatever comes back. **Real means saleable:** a child the owner "might add later" is not a child today. **A variation must not create a product claim:** if a proposed child asserts a capacity, a material, a finish, or a count that the Reference Sheet and the research files do not support, stop and say so; the fix is upstream, in the brief and the reference, never in the prompt.

## Process

1. **Establish the MODE, and settle the two questions before anything generates.**

   **Question one: the real child list.** Sizes, colours, shapes, scents, counts, bundles. Two lawful ways in:
   - **From ASINs.** The owner gives the variant ASINs; read each one's main image and listing to
     derive what actually differs between them. On a live family the listing's own variation picker
     is the best evidence: it names every child with its dimension values. One warning from the
     field: **the dimension labels lie.** Amazon's `color` axis has been observed carrying the
     SHAPE. Read the values, not the axis names. Read the differences BACK to the owner before
     accepting them: a list derived from images can misread a difference, and a misread attribute
     propagates into every child.
   - **From a folder.** The owner points at the variant assets (swatch photos, colour references,
     label variants), as files or as a folder, and names the family. Wonka copies them into
     `2-reference/variations/[child]/`, one folder per child; the owner files nothing. Faster and
     more accurate when the owner has the real material. **Check each asset belongs to the child it is filed
     under** before it feeds anything: piece count, colourway, size or format against the child's
     own listing entry. A neighbouring variant's photo sitting in the wrong child is how a whole
     family comes back subtly wrong, and nothing errors. Anything that disagrees moves to
     `_other-variant/` with a one-line reason, same as the Reference Room does.
   Either way, the confirmed list gets written down. **Never invent a variant**, and never write
   `none` on a guess: if the owner does not know, that is `unconfirmed` plus the one line on how to
   check (the listing's variation picker, or Seller Central).

   **Question two: TYPE A or TYPE B** (see above). Ask, record the answer and the reason, and say the
   tradeoff out loud. This decides which machine runs and how every call is built, so it cannot be
   discovered halfway.

   Then the mode:
   - **MODE 1, the PILOT.** One child, done properly, before anything else. This is the default entry
     and it is not skippable on a first family.
   - **MODE 2, the rest of the family.** Only after the pilot is approved. One batch, one
     confirmation.
   - **MODE 3, one child re-run.** A child coming back from `/inspect`, from `/fix` as a
     REGENERATE-class defect, or a newly added variant. Name the driver in writing first.

2. **Lock the theme and the child list.** Name the dimension or dimensions the children vary on and confirm each child's attribute value. One theme is the norm; some categories allow two (Size plus Color), in which case say out loud how many children the grid actually produces, because a 3 by 4 grid is twelve children, not seven.

3. **Reconcile the brief, and amend it BEFORE any credit is spent.** Compare the confirmed child list against the brief's VARIATIONS section.
   - They match: continue, and note the match in the plan's provenance.
   - They differ, including the common case where the brief says `none (single SKU)` or `unconfirmed` and the owner has now named a real family: **amend `brief/creative-brief.md` first.** Replace the VARIATIONS section with the confirmed plan, stamp it with today's date, record the reason in one line, show the amended section to the owner, and only then continue. Never generate past a document that contradicts the plan, and never edit the section silently. Six weeks later, the answer to "why are there bundle images for a single SKU product" has to be in the file.

4. **Write the FRAME TABLE and the TRUTH TABLE.** These two tables are the whole plan, and neither can be guessed.
   - **The frame table.** Open every frame of the tested set with the Read tool, one by one, and record per frame: does it carry the varying attribute's SHAPE, does it print a variant-specific VALUE (a count, a size, a fit claim), or does it carry nothing variant-specific at all. **While looking, COUNT the products in each frame** and write the count down; a frame holding four product instances needs that number in its prompt later, and the count cannot be read off a filename. A frame that carries nothing variant-specific is marked REUSED and appears in no child's edit list.
   - **The truth table.** Per child, from that child's OWN listing or the owner's own words: shape, count, size label, fit range, and every printed claim. **Never carry the source's claim across.** The classic silent failure: a smaller child that keeps the source's fit range, or a shape child that keeps the source's size text. A family that swaps the shape and keeps a wrong claim ships a wrong claim, beautifully.
   - Read both tables back to the owner in one screen. The frame table decides how many calls the family costs; say that arithmetic out loud ("a text-only child touches 3 frames, a shape child touches 6, so this family is [N] calls").

5. **Plan the per-child imagery.** Three file classes per child, driven by the tables.
   - **The per-child main.** The product in that child's form, **product-only, no people, no overlay text or graphics beyond what the tested main already carries on its own label**, inheriting the tested winner's composition. Every child holds the same angle, lighting, background family, and framing; only the target attribute moves.
   - **The per-child propagated frames.** Every gallery frame the frame table marked as variant-carrying, edited for this child. Frames marked REUSED are shared by the whole family and copied, never re-generated.
   - **The swatch.** The small picker thumbnail, and it has ONE job: telling the shopper at a glance which child she is choosing. Its job differs by theme:

     | Theme | What the swatch must carry | The failure to avoid |
     |---|---|---|
     | Color or finish | the actual color, filling the frame | a full product photo where the color is a detail |
     | Size or capacity | the size, as very large legible text | tiny numerals nobody can read at picker size |
     | Count or bundle | the count, as very large legible text plus the true number of units | one unit standing in for a multipack |
     | Scent or flavor | the name plus one honest cue (the real botanical, the real fruit) | a generic near-miss ingredient |

     Swatches render tiny, so win legibility by subtraction: fewer elements means bigger elements. A swatch is not a shrunken product photo. Say one honest thing about them out loud: **whether the picker draws an image swatch or a plain text button depends on the theme and the category template.** Color, pattern, and style themes classically get image swatches; size and count themes are often text buttons. Produce the swatch either way, because where it does render it is the whole decision, and where it does not it still serves as a gallery or A+ frame. Never state which one a specific category will draw as if it were checked; the owner sees the truth in the listing itself. Swatches are GENERATED (Genrupt, or gpt-image on the key), not edited; they are new small compositions, not crops of the main.
   - **Counts and arrangements are structural, not scale.** A bundle child is a different ARRANGEMENT of real units, never one unit photographed larger. Every unit in frame keeps its true proportions and its true parts, and the count in the image equals the count in the child's name.
   - **Derived likeness, named as such.** If a child's real-world appearance appears NOWHERE in the reference set (the classic case: a color the reference photos never showed), ask for one photo or one exact description of that child. The cheapest lawful shape reference is the child's own current live main image, used as SHAPE TRUTH ONLY (rule in step 6). If the answer is "I don't have that", that is a real answer: PROCEED, record `likeness: derived (no reference for this child)` against that child in the plan, warn once that it is the weakest thing in the family, and never present it as verified accurate.
   - **Map shared versus per child.** The frame table already made this map: which assets serve the whole family (the REUSED frames, usually most of the gallery and the A+) and which are per child (the main, always; the swatch, always; the variant-carrying frames). The map goes in the plan and later into the upload pack.

6. **Type A: write the manifest.** The plan becomes ONE JSON file, `variations-work/manifest.json`, and the manifest is the artifact worth reviewing: it holds every prompt, so a bad output traces to a sentence, and re-running one child after a prompt fix is one flag. Start from `example-manifest.json` in this skill's folder and rewrite it for the real family. Set up `variations-work/` first: copy the tested set into `source/` (from the folder named in precondition 3), and one shape reference per target silhouette into `refs/`.

   **When a child differs by COUNT (a multipack, a bundle, a different piece count), the right
   shape reference is the parts-inventory sheet**, the countable-panels additional sheet from
   `/reference-sheet` (`2-reference/parts-inventory-sheet.png`). It exists because the machines
   cannot count from a beauty shot: measured on the demo product, count edits against the beauty
   sheet landed 2, then 5, then 3, and the same edit against the parts sheet landed exactly 4,
   first try. If the family has a count child and no parts sheet exists yet, build it now via
   `/reference-sheet` (its "One product, up to five sheets" section) before writing the manifest.

   The manifest carries: the frame list, the shape references, `shape_prompts` (the normal frames), `hero_shape_prompts` (the MAIN's own wording), `frame_shape_prompts` (per-frame overrides for multi-object frames), and per child the frames to touch with their exact text instruction from the truth table.

   **The prompt rules.** Each one exists because the naive version shipped a wrong frame. Over all of them sits the words rule: the prompt names the CHANGE, never the product's existing look (no material, finish, colour or rim words for what stays); identity comes from the reference image in the chain, so say "keep everything else as the first image shows it".
   - **State the target geometry positively AND forbid the source geometry.** "A true circle with no corners and no straight sides, and no square or rounded-square silhouette anywhere." A soft target-only description gets read as "already close enough".
   - **The hero names its CURRENT geometry first, then orders the redraw.** "The hero product is a stack of SQUARE [things]. Redraw that product as..." The MAIN's label card dominates the frame and the model preserves the layout it sees; target-only wording leaves the MAIN unchanged while every lifestyle frame converts.
   - **Any card, badge or band on the product's label is a RIGID OBJECT, and the prompt says so.** Same shape, same size, same position, every band exactly as wide as it is now and fully inside its border. Left unsaid, the model reshapes the card to follow the new product silhouette.
   - **A frame holding several products gets its count named, and each instance located.** "This is a FOUR-PANEL grid and EVERY ONE of the four panels shows... redraw ALL FOUR." "Every [thing]" reads as satisfied after one. This is why step 4 counted.
   - **The reference is SHAPE TRUTH ONLY, and the prompt says so.** The cheapest reference (the child's live main) carries its own old label design, and without the instruction that design leaks into the output.
   - **Pin the SOURCE's camera angle by name.** Measured on a pilot child: even with "do not copy the reference's composition" in the prompt, the output drifted from the source's frontal pose toward the reference's three-quarter angle. Say it positively: "keep the SOURCE image's exact camera angle and product position; the reference supplies only the product's shape and color".
   - **Where the product sits inside a container, the container must fit it.** The basket, the drawer, the box is part of the swap.
   The script appends a preserve-everything-else block to every call on its own; do not restate it.

7. **The pilot, and the prompt loop when it does not land.** Report the cost first, in one line: "[N] children, [M] edit calls total on the OpenAI key, cents per call; the pilot is [K] calls." **The planned family is REPORTED, not gated:** the owner approved the brief, the child list is the one they confirmed in step 3. What DOES stop for its own go-ahead is anything beyond that approved batch: a re-run, a second attempt, or a balance that will not cover the run.

   Then run the pilot child only:
   ```bash
   python3 .claude/skills/variations/variations_run.py \
       "factory/Products/[product]/variations-work/manifest.json" --dry-run
   python3 .claude/skills/variations/variations_run.py \
       "factory/Products/[product]/variations-work/manifest.json" --only [pilot-child]
   ```
   Always `--dry-run` first and read the call list out loud; that is the arithmetic check on the frame table. Pick the pilot deliberately: **the hardest child, not the easiest**, usually a shape child, because a pilot that proves nothing hard proves nothing.

   Open the pilot's frames beside their sources. **What to check, in this order:** is the varying attribute actually correct and actually the only thing that changed, is every printed value the TRUTH TABLE's value for this child, is the product still itself, does it match the tested composition it came from.

   **When it is wrong, the fix is the PROMPT in the manifest, not the image.** An edited pilot cannot propagate. Adjust the instruction and regenerate: **edit the manifest, then re-run with `--force`**, because without it the script keeps the old frame and reports `skip (exists)`, and a fixed prompt gets silently credited to an unfixed image. Try two or three distinct phrasings rather than nudging one repeatedly; prompt failures are structural, and three different attempts find the structure faster than five variations of one. Keep every attempt on disk with what was tried. **If three phrasings all fail the same way, the problem is upstream:** a missing shape reference, a reference that does not show the varying part, or a variant that is genuinely a different product. Say which you believe it is and ask for that input rather than trying a fourth phrasing.

   Lay the pilot's frames out as a NUMBERED sheet first (`python3 .claude/skills/inspect/contact_sheet.py sheet "factory/Products/[product]/variations-work/pilot-sheet.jpg" "factory/Products/[product]/variations-work/working/[pilot child]"`, both paths from the kit root) and open the folder, so the approval is given on tiles the owner can point at.
   **Only an owner-approved pilot unlocks MODE 2.** Then the rest of the family runs on the exact manifest that worked, unchanged:
   ```bash
   python3 .claude/skills/variations/variations_run.py \
       "factory/Products/[product]/variations-work/manifest.json"
   ```
   The script skips the finished pilot, resumes a rate-limited batch on re-run, chains shape into text per frame, pads non-square frames with headroom, and **measures edge contact on every frame, retrying smaller when the product touches an edge**. The MAIN is the fragile frame: padded and asked to redraw its product, the model fills the square canvas and the crop back cuts the sides. The guard fires in practice; never ship a hero frame without its edge number.

8. **Type B, or no OpenAI key: the Genrupt path.** Use the Genrupt product-variations flow off the locked reference. Find it with `search_capabilities` and READ ITS INPUT SCHEMA before the first call: the fields below are DECISIONS, and the schema you just read decides how each one is spelled and whether that call carries it at all. Never add a field the schema does not declare; these schemas are strict and reject the whole call. All of these are mandatory as decisions:
   - **Pin the model wherever that call's schema accepts one.** An unspecified model is a model that can change under you, and a weaker engine renders text badly, which is fatal for swatches. Where a call has no model field, the engine came from the flow's own setup: say which, in the run record, rather than assuming.
   - Use the lowest resolution the tool exposes unless the owner asks otherwise.
   - Attach the approved reference asset id from `2-reference/reference-sheet.md` to every call, so every child inherits the product lock. Read the flow's references FIRST: an attached sheet shows as a `productImages` entry noted "Product Reference Sheet" (contract since September 2026). Attach only if it is missing, by id in `productReferenceSheetIds` with `mode: "merge"` and no `productImages` key, and never re-send the primary id once it is there (it re-runs the replacement). Wire the child's own slot `referenceImages` where the schema offers one without touching the plan-level ids; then read the plan back and count. There is no material-lock prose: describing the material or the shape in `customInstructions` is the words rule's failure, and the old "403, cannot attach" workaround of 21 August is dead (superseded 5 September 2026).
   - **Style and brand fit come from the branding preset (resolved from `status.md`) and the tested set's own look**, passed as structured fields where the flow accepts them. Never describe style, colors, graphics, or fonts in prompt prose, and never paste hex codes into a text field.
   - Variation imagery is product-only, so no casting applies here. If a request ever tries to put a person into a variation image, the answer is no.
   - **Vary ONLY the target attribute per call.** Composition, angle, lighting, and background are held constant across the family. If the tool exposes a seed or a base image, reuse the same one across the children.
   - Never instruct a third-party logo or an award badge render; the content checker fails the whole image.
   - Keep the whole compliance avoid-list off the swatches too: no star ratings, no review references, no invented percentages, no fake badges. A swatch is a label, not an ad.
   The pilot rule and the truth table apply on this path exactly as on Type A. Say the cost difference out loud once, with a REAL number from a live `get_credit_balance_and_costs` preview (`finalCreditsCost`, never a typed estimate): equal quality, credits instead of cents, and the Type B batch gets its own one-line pre-run report exactly like step 7's edit report.

9. **Run the measuring QA, then the two checks no number replaces.**
   ```bash
   python3 .claude/skills/variations/variations_qa.py \
       "factory/Products/[product]/variations-work/manifest.json"
   ```
   Per frame it reports a `drift_score` over a 6x6 tile grid plus a source | generated | drift-overlay contact sheet in `variations-work/qa/[child]/`. Read it correctly: **drift where the edit lives is the job; the same drift in the product, the logo, or an untouched claim is a defect.** Text edits drift low with no strong tiles; shape swaps drift high with many, and that is expected. The sheet's job is showing WHERE.

   Then, by hand, because every automated number in this room is blind to specific failures:
   - **Count the frames per child against the manifest.** One frame can die mid-batch on a one-off upstream error, and that line sits among dozens of successes. `working/[child]/` must hold exactly the planned frame list. A missing frame re-runs with `--only [child]`; the finished ones skip.
   - **OPEN every hero frame at full size and look at it.** This is the blocking gate, and it exists because it was skipped once: hero frames have shipped with the label card reshaped into an egg and its bands bleeding past the border while drift and edge contact both read fine. Check the label card (rigid, bands inside the border), the product (target silhouette, correct stack or count), and the words (every value is this child's truth-table value, nothing else reworded). A hero frame that fails any of these regenerates; it never ships with a note.

10. **Land the finals in `variations/`, and write nothing else there.** Copy each child's approved frames from `working/[child]/` into `variations/` with child-tagged names: `main-[child].png`, the propagated frames as `[slot]-[child].png` (`pt03-round-10in.png`), and generate the swatches as `swatch-[child].png`, using the owner's own child names slugified. This room writes ONLY `main-*`, `swatch-*`, `[slot]-*` and `variations-plan.md` into `variations/`; the machinery stays in `variations-work/`. Never overwrite, never delete, never move: a regenerated child saves as `main-[child]-v2.png` beside its untouched first attempt, and surgical edits from `/fix` live in `edits/vN/variations/` snapshots, never inside `variations/`. Every original stays on disk, which is the point.

11. **Verify with evidence, not with confidence.** Open EVERY file you just landed with the Read tool and write ONE literal line per image (what is actually in frame). An image you did not open was not checked. For swatches, also make a picker-size copy and read THAT, because a swatch judged at full size is a swatch never judged at all:
    ```bash
    mkdir -p "factory/Products/[product]/scorecards/picker"
    sips --resampleWidth 60 "factory/Products/[product]/variations/swatch-[child].png" --out "factory/Products/[product]/scorecards/picker/swatch-[child]-60.png"   # macOS
    # Windows/ImageMagick: magick convert "factory/Products/[product]/variations/swatch-[child].png" -resize 60x "factory/Products/[product]/scorecards/picker/swatch-[child]-60.png"
    ```
    The copies live OUTSIDE `variations/` on purpose: that folder is inventoried by `/inspect` and its gate-passed files travel into `final/`, and downscaled proofs are neither deliverables nor candidates.

    You are looking for five catastrophic misses only:
    1. **Wrong or drifted product** against the Reference Sheet spec, part by part. Every part the spec lists must be present and countable.
    2. **Wrong count, wrong attribute, or wrong printed claim for that child** against the truth table. A two pack showing one unit, a size child at the wrong size, a shape child keeping the source's fit range.
    3. **A failed or empty generation, or a missing frame.**
    4. **The family does not read as siblings.** Put the mains side by side: a child at a different angle, height, light, or background is a family break.
    5. **A swatch that does not do its job at 60px.** If you cannot tell which child it is from the downscaled copy, it failed, whatever it looked like at full size.

    Do NOT score, do NOT rank, do NOT run the full 160px squint pass: that is the Inspection Room's job and duplicating it here just does it worse. Route what you find: wrong claims and family breaks are REGENERATE class (a manifest fix plus `--only [child] --force`), and enlarging swatch text is regenerate class too; product drift or a wrong count on ONE child goes to `/fix` first as a focused edit on that child's region under the routine-fix policy in `CLAUDE.md`, and drift across several children is a manifest fix. Removing a stray element or swapping a word is a surgical edit. Offer any re-run with a fresh cost line.

12. **Write `variations/variations-plan.md`** in the Output format below: provenance, the confirmed real child list, the frame table and the truth table, the shared-versus-per-child map, the Amazon embedding map, and the generation record. On a MODE 2 run, APPEND a generation row; never rewrite the file and never touch an earlier row.

13. **Verify the artifacts exist before you claim anything.** List `variations/` and confirm one main, one swatch, and every planned propagated frame per confirmed child, with earlier files still present, plus `variations-plan.md`. Re-read the plan from disk to confirm it wrote. If a child is missing an image, the family is NOT complete: retry that image once (with its own cost line), and if it fails again, record the failure with its error in the plan, name the missing child to the owner, and leave the sub-status at `in progress`. Never fill a hole with another child's image, never rename to hide a gap, and never call the family done because most of it landed.

14. **Hand off to the Inspection Room.** Tell the owner: "The family is out of the machines. Next stop is the Inspection Room: run /inspect before you fall in love with it." Ask for the variation checks by name (per child fidelity against the reference, truth-table values on every frame, family consistency, swatch legibility at picker size). Nothing here is final and nothing is a candidate yet.

15. **Only AFTER the family is gate-passed: record the owed upscale and hand off.** This step never runs on uninspected images, and this room never upscales.
    - **The family ships at the Shipping Room's resolution, not this room's.** The edit path outputs 1024px on the long edge (a padded hero crops back smaller still), a review artifact, not a shipping asset, and the REUSED frames copied from the live listing sit at 1024 to 1500 too. Record `upscale: owed` for the whole family (every propagated frame, every reused frame, once per shared frame) in `variations-plan.md` and on the Variations line of `status.md`: `Variations: family of [N], upscale: owed`. Note there that the owner's original masters are preferable for reused frames if they exist. Never present 1024px files as upload-ready.
    - **Hand off:** the Shipping Room upscales the family once, with the mains, on the files that ship. Say that sentence to the owner as-is.
    - If the Shipping Room has already run (`final/` exists), copy the gate-passed family into `final/variations/` beside the rest of the approved package so its re-run finds the class in place. Otherwise leave the family in `variations/`; the Shipping Room resolves it from there.
    - This room never writes `tests/upload-pack.md`. The Shipping Room is its only writer: its re-run replaces the `Variations: pending (Day 9)` line with the real family, the embedding map and the finished upscale. Say so in the plan.
    - Say once more, plainly: this room produces the files and the map. The owner uploads them and wires the parentage in Seller Central. Wonka never touches the live listing, and the plan records what was produced, never a predicted result.

## Output format

`factory/Products/[product]/` after a run:

```
variations/
  main-round-10in.png
  swatch-round-10in.png
  pt01-round-10in.png
  pt03-round-10in.png
  main-square-10in-8set.png
  swatch-square-10in-8set.png
  main-round-10in-v2.png    (a regenerated child, beside its untouched first attempt)
  variations-plan.md
variations-work/
  manifest.json             (the whole plan: frames, refs, every prompt, per-child deltas)
  source/                   (the tested set the family was built from)
  refs/                     (one shape reference per target silhouette)
  working/[child]/          (1024px drafts + [FRAME]_shape.png intermediates)
  qa/[child]/               ([FRAME]_qa.png contact sheets)
  qa-report.json
```

`variations/variations-plan.md`:

```markdown
# Variations Plan . [Product Name]

Built from: brief/creative-brief.md ([date], VARIATIONS section [matched / amended [date]: [reason]]),
2-reference/reference-sheet.md (LOCKED, smoke test PASS, source: [manual / amazon_scraped]),
factory/Brand/brand-kit.md ([on file / not available (owner)]),
edits source: [edits/v2/ / images/],
inherits composition from: [tests/tasting-r2-[date]-main/ winner, file main-01-v2.png / reference sheet (no tested winner yet)].

Variation theme: [Color / Size / Shape / Scent / Flavor / Count or bundle]. Confirmed real by the owner [date].
Type: [A (edit path, OpenAI key) / B (regenerated, Genrupt)] . reason: [owner's reason, date].

## Frame table (from the tested set)
| Frame | Carries | Product count in frame | Per child? |
|---|---|---|---|
| MAIN | shape + count text + size text | 1 stack | yes, edit (shape + text) |
| PT01 | shape + count badge | 1 | yes, edit (shape + text) |
| PT02 | shape only | 1 | yes, edit (shape) |
| PT03 | shape only | 4 (four-panel grid) | yes, edit (shape, counted prompt) |
| PT05 | nothing variant-specific | 2 | REUSED, shared by the family |

## Truth table (per child, from each child's own listing)
| Child | Shape | Count | Size label | Fit / claims | Likeness |
|---|---|---|---|---|---|
| round-10in | round | set of 4 | 10" | [claims] | ref: live child main (shape truth only) |
| square-10in-8set | square (source) | set of 8 | 10" | [claims] | from source set |

## Children (real SKUs only)
| Child | Attribute value | Main | Swatch | Propagated frames |
|---|---|---|---|---|
| round-10in | shape: round | main-round-10in.png | swatch-round-10in.png | pt01, pt02, pt03, pt04 |
| square-10in-8set | count: 8 | main-square-10in-8set.png | swatch-square-10in-8set.png | pt01 |

## Shared versus per child
- Per child (must exist for every child): the main image, the swatch, every frame the frame table marks variant-carrying.
- Shared across the family: the REUSED frames, the A+ modules. Shared frames are listed once here, upscaled once by the Shipping Room, and copied into each child's upload set.

## Amazon embedding
- Theme: [the one dimension, or two if the category allows]. Children: [N].
- Structure: a non-buyable parent holds the child SKUs; the shopper lands on the parent and picks a child.
- Per-child images: each child SKU carries its own main and its own gallery (mapped above), so the gallery updates when the shopper switches. A buyer who picks the two pack and sees one unit was told something untrue before she paid.
- Swatches: one picker thumbnail per child, mapped to its SKU. Whether this category draws an image swatch or a text button is visible in the live listing; the file is produced either way.
- Wiring: the exact theme names and the parentage screens live in the category's own template in Seller Central. This map says WHAT to produce; the owner wires it there.

## Generation
| Date | Mode | Path | Model | Calls/Images | Est. cost | Approved | Notes |
|---|---|---|---|---|---|---|---|
| [date] | pilot | edit (OpenAI key) | gpt-image | 6 calls | cents | brief ([date]) | pilot: round-10in; 2 prompt rounds on the MAIN, winning phrasing in manifest |
| [date] | full family | edit (OpenAI key) | gpt-image | 14 calls | cents | brief ([date]) | [failures, retries, derived likeness, edge-contact retries] |
| [date] | upscale | owed to the Shipping Room | - | [N] frames | 0 here | - | `upscale: owed`, reused frames included; runs once in /ready-to-upload with the mains |
```

## Golden Standards check

Before handing off, verify:
- [ ] Brief, locked reference (with a PASSED smoke test), and the tested-set source folder were confirmed BEFORE generating; any hard miss was reported as BLOCKED, not worked around. A missing brand kit was recorded as an explicit gap, never invented.
- [ ] The child list is REAL, confirmed by the owner in this run, and nothing outside it was generated. "None" and "I don't know" were handled as first-class answers, not papered over.
- [ ] Where the confirmed list differed from the brief, the brief was AMENDED first, dated and reasoned, before a single cent was spent.
- [ ] The frame table was written by OPENING every source frame (with its product count), and the truth table from each child's OWN listing; no claim was carried across from the source. Frames carrying nothing variant-specific were REUSED, not regenerated.
- [ ] Cost was REPORTED before and after the batch, never used as a gate. Re-runs were named out loud before spending again.
- [ ] The pilot ran FIRST, on the hardest child, checked against the truth table, and only an approved pilot unlocked the family. Prompt fixes were made in the manifest and re-run with `--force`, never by editing the pilot image.
- [ ] Every child has a product-only main, a swatch that does its one job, and every planned propagated frame. Only the target attribute varies across the family, and a bundle is a true arrangement of real units.
- [ ] No image asserts a capacity, material, finish, count, or fit the truth table does not support. The compliance avoid-list holds on swatches too.
- [ ] Type A path: dry-run read before the batch, edge contact measured on every frame, drift QA run and read as located drift, frames counted per child against the manifest, and EVERY hero frame opened at full size (card rigid, silhouette right, words right). Genrupt path: every call made against a schema that was READ first, model pinned, reference asset attached, one attribute varied per call.
- [ ] Every landed file was opened with Read and has a literal one-line description; every swatch was read at 60px; the mains were compared side by side for family consistency.
- [ ] Only `main-*`, `swatch-*`, `[slot]-*` and `variations-plan.md` were written into `variations/`; the machinery stayed in `variations-work/`. No original overwritten, deleted, or moved; picker proofs live outside the folder.
- [ ] `variations/` was listed and matches the confirmed child list and the frame table, or the missing images are named to the owner and recorded with their errors; `variations-plan.md` was re-read from disk.
- [ ] The owner was pointed to the Inspection Room with the variation checks named, and no child was called final. Upscaling (including the reused frames, to 1600px+) ran only AFTER the gate passed, and `output/` and the upload pack were extended only after that.

## Wonka lines

Openers:
- "The Variations Room. One brief, many flavors, and every one must taste like the same factory made it."
- "Before anything else: tell me which children truly exist. I invent candy, not flavors you do not sell."
- "Nine days bought you one tested winner. This is the room where that stops being expensive."

Refusals (say them plainly, without drama):
- "Your brief says single SKU, in writing, on [date]. I will not contradict my own document to please a prompt."
- "A colorway that does not exist is a return, a bad review, and a listing problem. Give me the real list and I will give you a real family."
- "If the plan changed, the plan gets rewritten. Dated, with the reason. Then, and only then, the machines run."
- "I will not guess what the eight pack claims. Its own listing knows. We read, then we print."

Closers:
- "Same light, same angle, same composition that won. One family, one visual language, and not a stranger among them."
- "Every frame that did not need to change did not change. That is not laziness, that is the whole trick."
- "Mains, swatches and the frames that carry the difference, one set per child, mapped to their SKUs. Look at the swatch at the size it actually renders; that is the only size that matters."
- "Consistent to the last chip. Nothing ships until the Inspection Room signs it. Onward to /inspect."

## Definition of Done

One of two honest end states, never a third.

**Generated:**
- Every confirmed child has a per-child main, a swatch, and every frame the frame table marked variant-carrying, in `variations/`, verified by listing the folder; any image that failed twice is named to the owner and recorded with its error, and the family is NOT called complete.
- `variations/variations-plan.md` exists and was re-read from disk, carrying provenance (brief state, reference source, brand kit state, edits source, inherited composition, TYPE with its reason), the frame table, the truth table, the confirmed real child list with likeness notes, the shared-versus-per-child map, the Amazon embedding map, and the generation record.
- Where the plan changed, `brief/creative-brief.md` carries the dated, reasoned amendment.
- On the edit path: the manifest is on disk in `variations-work/` with every prompt that ran, the QA report and contact sheets exist, frames were counted per child, and every hero frame was opened at full size.
- Every landed file was opened and described, every swatch was read at picker size, and the five catastrophic-miss checks ran with anything found routed correctly.
- Every original is untouched on disk, and the owner was explicitly handed to `/inspect` with nothing presented as final. `upscale: owed` was recorded only after the gate passed; nothing was upscaled here and `tests/upload-pack.md` was not touched.

**Not applicable or blocked:**
- `n/a`: the owner confirmed the product is a single SKU. Recorded in `status.md` with the date, no folder faked, no child invented, the rest of the package unaffected.
- `blocked`: the child list is unconfirmed. Recorded with the exact question and the two places to answer it, and the owner told plainly that nothing else is held up.

## Update status.md

In the INVENT sub-status block, set `Variations (/variations): done` (or `in progress` if the family is partial or a child is still owed, or `n/a (product has no variations)` with the owner's confirmation date, or `blocked: [precondition or "child list unconfirmed"]`). Artifact `variations/` + `variations/variations-plan.md`.

Then check the whole INVENT sub-status block: when all four sub-parts (Main image, Secondary images, A+, Variations) are `done` or `n/a` with a reason, set the INVENT station row to `done`; otherwise leave it `in progress`. If an earlier run left the lawful trailing marker `Variations: pending (Day 9)`, this run replaces it.

Log lines, one of:
- `[date] Variation family generated: [N] children, type [A/B] on [edit path / genrupt], [M] calls, cost reported [est], edits source [folder], inherits [winner file], reference source [manual/amazon_scraped][, brand kit not available]. Awaiting inspection.`
- `[date] Child [name] regenerated ([driver]) via manifest fix + --force, cost reported [est]. Awaiting re-inspection of the family.`
- `[date] Variation family gate-passed: [N] frames, upscale: owed (reused frames included). The Shipping Room upscales it with the mains and extends the pack.`
- `[date] Variations: n/a, owner confirmed single SKU. INVENT sub-part consciously skipped.`
- `[date] Variations: blocked, child list unconfirmed. Owner to check the listing's variation picker or Seller Central parentage. Rest of the package proceeds.`

# Listing Builder MCP. Research Intake Guide for External Agent Skills

> Source: Genrupt, intake guide v2, received 27 July 2026. This copy ships in the kit because Wonka's
> skills implement it. The authoritative source is the MCP tool schemas returned at call time: if a
> cap, field name, or semantic here ever disagrees with the live schema, the schema wins.
>
> **So read the schema BEFORE the call, not after it fails.** This is an operating instruction, not
> a disclaimer. Genrupt exposes a few always-visible tools plus capabilities found with
> `search_capabilities`, each field belongs to exactly one of them, and the schemas are strict: a
> field the tool does not declare REJECTS the call rather than being ignored. Two things follow.
> Fields drift to different tools as Genrupt ships, so a name remembered from another room is a
> guess. And the decision is never the same thing as the parameter that carries it: pin the
> decision (tactics off, one image per slot, square) and look up the spelling every time.

The core idea: **Genrupt owns planning, prompting, billing, and generation. Your agent owns
distillation.** Your job is never to write image prompts. It is to sort research into the small set
of structured fields the MCP accepts, then let Genrupt plan, and then edit the plan it returns.
Agents that try to "prompt through" the tools (dumping research prose into every field) get worse
images than agents that distill.

---

## 1. The two funnels

All research ends up in exactly two places. Triage every artifact into one of them, or discard it.

**Funnel A. Product facts (`projectSetup`)**: things that are true about the product regardless of
which images get made. Sent on `create_listing_builder_flow` or `plan_listing_builder_from_asin`.
Casting (who appears in the images) is decided at the same time, see section 2.1.

**Funnel B. Creative decisions (plan review)**: things that shape individual images. Sent on
`save_listing_builder_plan_review` AFTER Genrupt returns its plan, as edits to that plan, never as a
replacement for it.

This ordering matters. Genrupt's planner is good; it produces per-slot buyer questions, briefs, and
header phrases from the market analysis on its own. Your research should **correct and enrich** the
returned plan, not pre-empt it.

---

## 2. Funnel A: `projectSetup` (product facts)

One optional object, identical on both setup tools:

```jsonc
{
  "projectSetup": {
    "product": {
      "title": "string",
      "description": "string",
      "bulletPoints": ["string", "..."]
    },
    "references": {
      "productImages": [{ "url": "https://...", "note": "optional, <=500 chars" }],  // <=24
      "styleImage": { "url": "https://..." },   // exactly one; null clears it
      "packagingImages": [{ "url": "https://..." }],                                 // <=24
      "productReferenceSheetIds": ["..."],       // approved sheet ids, <=5; the primary applies itself on approval, send it at most once
      "reimportListingImages": false,            // true + merge + URLs (no primary id) is the ONLY way listing photos come back
      "mode": "merge"                            // the default; the approved primary sheet already replaced the product photos
    },
    "brandingPresetId": "string or null"
  }
}
```

Mapping messy research to Funnel A:

| Research artifact | Destination |
|---|---|
| Product spec sheets, material lists, dimensions, factual claims | `product.description` (rewritten as one clean description, not pasted verbatim) |
| Finalized or draft Amazon copy | `product.title`, `product.bulletPoints` |
| Photos of the actual product (any angle, any quality) | `sourceImageUrls` / `sourceAssetIds` on `create_product_reference_sheet`: they BUILD the sheet. Once the primary sheet is approved it replaces the product photos by itself (read back as a `productImages` entry noted "Product Reference Sheet"); additional sheets attach by id with `mode: "merge"`. The ASIN's own listing gallery is sheet input only, never a generation reference |
| Box, label, pouch photos | `references.packagingImages` |
| One aesthetic north-star image ("make it feel like this") | `references.styleImage`, the **Brand style image**: brand-level and persistent. Exactly one if used. **The bootcamp flow leaves it unset**: the look is chosen on Day 6 from real frames as the **Refine style reference** (`set_listing_builder_style_reference`, set-level), which is the better version of the same idea. Two names, never interchanged; `source: project_setup` on that capability pulls the brand image DOWN into a set, and nothing pushes a set's choice UP into the brand |
| A real LOGO FILE | Upload it as a Genrupt asset (`create_reference_asset_upload`), then set the preset's `logoUrl` and `logoThumbnailUrl` to the completed HTTPS URL and attach the preset. **There is no plan-level logo bucket**, so this is the only route |
| Brand Book / Style Guide decisions (colors, fonts, style notes) | Create or reuse a **branding preset** via the branding tools, then pass `brandingPresetId`. **Do not paste hex codes into text fields** |
| Buyer personas, demographic research, "our customer is a woman around 50" | **Not projectSetup.** `customAvatars` / `selectedAvatarIds` on the planning tool. See section 2.1 |

**The logo and the brand styling share one carrier, and that is an API fact, not a workflow rule.**
Genrupt offers exactly one place to declare a logo, the branding preset, and that same preset is
where colors and fonts live. In the Wonka workflow they stay independent inputs: a logo needs no
Brand Book, a Brand Book needs no logo, a **logo-only preset is lawful** (`name` is the preset's
only required field), and so is a style-only preset, a preset carrying both, or no preset at all.
Whichever room writes second MERGES rather than replaces: read the preset in detail, change only
its own fields, read back and prove both halves survived.

**Where a logo must NEVER go.** Not `productImages` and not `packagingImages` (those mean "this is
what the product looks like", so a logo dropped there gets rendered as part of the product). Not
`styleImage` (that is the set's whole aesthetic north star). Not a slot's `referenceImages` (that is
per-image inspiration; it is not the normal logo route and it declares nothing). A logo PRINTED on
the real product is a different thing: it is product truth, it arrives inside the product photos,
and it stays there.


Rules:

- **URLs only, HTTPS only.** Already-uploaded Genrupt asset URLs or public HTTPS image URLs. Local
  file paths are rejected; upload local files first and wait for completed asset URLs. URLs with
  embedded credentials are rejected.
- `mode: "merge"` (default) adds deduplicated images to each bucket you provide; `"replace"` swaps a
  bucket wholesale. Buckets you omit are untouched. Re-sending the same payload is safe (idempotent,
  no duplicates). **Approving the primary sheet replaces the product photos by itself** (contract
  since September 2026; a primary id in a payload replaces regardless of mode): send its id at most once, only when the read-back shows it missing, because
  a primary id in a payload re-runs the replacement. Additional sheets attach by id with `merge` and
  no `productImages` key; merge scrapes nothing, and nothing re-imports the listing gallery on its own.
  Listing photos return only through `productImages` URLs + `reimportListingImages: true` + merge,
  without the primary id. The 5 September 2026 server (merge pulled the scraped gallery back in,
  hence the old "replace, never merge" rule) is gone. Read the bucket back and
  count it after every references write.
- The `note` on a reference image is the one place a sentence of research context belongs: what this
  image establishes ("shows the matte texture", "correct label revision, March 2026").

## 2.1 Casting: who appears in the images

**Casting is a structured field, not prose.** Age, gender, and persona belong in the avatar fields,
never in `contentBrief`, `headerPhrases`, or `customInstructions`. Genrupt applies the selected
avatar as casting direction on every supporting image, so it holds no matter how the brief is worded;
casting sentences written into a brief are ordinary creative input and can be re-scoped or dropped.
Skills that carry long casting paragraphs in every slot brief are working around a problem that no
longer exists, and the extra text competes with the brief that actually needs to land.

Two top-level arguments, accepted by `plan_listing_builder_from_asin` and again by
`save_listing_builder_plan_review` (they are NOT part of the `projectSetup` object, and
`create_listing_builder_flow` does not take them):

```jsonc
{
  "selectedAvatarIds": ["market-avatar-2"],        // IDs from the plan's selectedAvatars entries
  "customAvatars": [                                // <=8, your own personas
    {
      "label": "Home cook, empty-nester",
      "description": "Cooks daily for two, values durability over gadgetry",
      "age": "50",
      "gender": "female",
      "ethnicity": "varied",                        // omit or "varied" to let Genrupt vary it
      "location": "US suburban",
      "income": "$90k household"
    }
  ]
}
```

How the fields behave:

| Field | Behavior |
|---|---|
| `age` | An exact number ("50") holds that age across every image. A range ("45-55") or a decade phrase ("early 50s", "middle-aged") is spread deterministically across the set. Blank pins nothing |
| `gender` | Held as given, protected against drift. Blank pins nothing |
| `ethnicity` | A specific value is held. Blank, "varied", or "mixed" opts into per-image variation |
| `label` / `description` | The persona itself: occupation, life stage, what they are doing with the product |
| `income` / `location` | Lifestyle and setting cues; held as given |

**Per-image variety is automatic and always on** for MCP runs: within the constraints you set,
Genrupt varies appearance across the set so the same face does not repeat image after image. Your
selected demographics win over that variation. You do not need to ask for variety, and you cannot
get it by describing different people in different briefs.

Selection defaults, which are easy to get wrong:

- Send NEITHER argument and Genrupt casts from the FIRST market-analysis avatar. If that avatar has
  no age or gender (many do not), those attributes are unconstrained. This is the usual cause of
  "the model ignored our casting": nothing was ever specified.
- Send `customAvatars` WITHOUT `selectedAvatarIds` and the market-analysis avatars are dropped; your
  personas are the whole cast. This is the right call for a single locked persona.
- Send ONE avatar for one persona across the set. Send several and slots rotate through them.
- On `save_listing_builder_plan_review`, sending `customAvatars` alone also clears
  `selectedAvatarIds`. Re-send both if you want to keep a market avatar alongside a custom one.

Scope limits worth telling the user about:

- Casting applies to SUPPORTING slots. The main image uses avatar details only under the Avatar
  Interaction main-image strategy.
- Casting is CONDITIONAL: it decides who appears IF a person appears. It never forces a person into
  a product-only image. Whether a slot has a human is the brief's job.
- Read back what is actually cast: `get_listing_builder_plan_review` returns `selectedAvatars`. Show
  that to the user rather than assuming your request applied.

## 3. Funnel B: plan review (creative decisions)

After setup, Genrupt plans. Read the plan with `get_listing_builder_plan_review`: it returns the
full editable snapshot (product fields, references, branding summary, selected avatars, and per-slot
state), along with an `editableFields` map naming exactly what this tool accepts back. Show it to
the user, collect edits, then save with `save_listing_builder_plan_review`.

Each slot entry accepts:

```jsonc
{
  "slotNumber": 2,
  "imageType": "BENEFITS",           // required, from the returned plan
  "buyerQuestion": "string",         // required
  "contentBrief": "string",          // required, the primary creative brief
  "alternateCreativeBriefs": ["..."],            // <=2, each <=700 chars
  "headerPhrases": ["..."],                      // <=24, each <=120 chars
  "customInstructions": { "text": "...", "mode": "ADDITIVE" },   // text <=4000, null clears
  "referenceImages": { "images": [{ "url": "https://..." }], "mode": "ADDITIVE" }  // <=24
}
```

Mapping messy research to Funnel B:

| Research artifact | Destination |
|---|---|
| Review mining: top complaints, objections, purchase hesitations | `buyerQuestion` (one question per slot, phrased as the shopper would ask it) |
| Voice-of-customer language, benefit angles, differentiators | `contentBrief`: a 2 to 5 sentence visual direction, not a research summary |
| A second credible creative angle you do not want to lose | **Its own slot, or the test hypotheses. Never `alternateCreativeBriefs`.** Genrupt can generate from an alternate (measured 27 August 2026: one won and shipped a frame carrying four jobs), so alternates are live production inputs, not a parking spot: on every save overwrite each one with the slot's approved `contentBrief` and read it back; if the save refuses them, record their exact text in the send log as a live risk and treat them as the first suspect when a frame does not match its slot |
| Headline ideas, keyword-informed hooks, claim phrasing | `headerPhrases`: these become the **mandatory on-image headline text**, so write them as finished on-image copy (<=120 chars, no placeholder text, no keyword stuffing) |
| Hard constraints from the client ("never show hands", "must include the scoop") | `customInstructions` with `mode: "ADDITIVE"`. Keep it to a couple of short sentences, and only for things no structured field covers |
| Who should appear in the image (age, gender, persona, "a different model each time") | **Not here.** `customAvatars` / `selectedAvatarIds`, see section 2.1 |
| Physical product accuracy ("glass bottle, not plastic", exact silhouette) | **Not in prose, anywhere.** The approved sheets selected in Project Setup are the fidelity authority (a blast reads only that selection; slot-level `referenceImages` never reach it). `product.description` carries facts (counts, materials, printed text). A silhouette, a taper, a finish or a working state written into ANY text field is rendered as written, over the photos: the words rule, `/reference-sheet` |
| A fully-specified image the client already designed | Use a CUSTOM slot with `customInstructions` `mode: "OVERRIDE"`. This is the app's "Custom prompt" behavior and replaces the planned direction |
| Inspiration or competitor screenshots for one specific image | that slot's `referenceImages`. ADDITIVE combines them with the product references; OVERRIDE uses them instead of the product references |

Semantics your agent must implement exactly:

- **Always send the full `slotAssignments` array**, even to change one slot. Partial arrays are
  rejected, deliberately, so a sloppy call cannot erase other slots. Read, modify, send back
  everything.
- **Omit a field to preserve it. Send `[]` to clear a list. Send `text: null` to clear an
  instruction.** Never "helpfully" resend empty arrays for fields you did not mean to touch.
- **Slot 1 (main image) is protected.** Round-trip it unchanged. It is edited only through the
  main-image controls the setup flow exposes (tactic, hang-tag text, packaging preference), never
  through briefs, headers, custom instructions, or slot references.
- **ADDITIVE vs OVERRIDE is a user decision.** Default to ADDITIVE; use OVERRIDE only when the user
  explicitly wants to replace Genrupt's planned direction. Preserve whichever mode the user approved.

---

## 4. Call sequence

1. `get_current_work_context` if the user says "this product" without an ASIN.
2. Triage the research bundle into Funnel A / Funnel B / discard (see section 5).
3. Upload any local assets; collect completed HTTPS URLs.
4. `plan_listing_builder_from_asin` with the ASIN plus gathered `projectSetup`. Omit
   `setupConfirmed` on the first call; answer the returned setup questions (market analysis, listing
   style, main-image scope and tactics) with the user.
5. `plan_listing_builder_from_asin` again with `setupConfirmed: true`, plus the cast
   (`selectedAvatarIds` / `customAvatars`) if the images should show people. Casting set here shapes
   the plan; setting it later means re-saving the plan review.
6. `get_listing_builder_plan_review`, then show the user the full plan **with your Funnel-B edits
   proposed, not silently applied**.
7. `save_listing_builder_plan_review` with the user-approved full slot array.
7b. Read the reference selection back before any generation: the plan's `productImages` must hold
   the approved sheet entries (noted "Product Reference Sheet") plus any photo the owner asked for,
   and nothing else. Before a blast, quote it for free (`get_credit_balance_and_costs`, the blast
   preset, the setId) and show the `selection` and `totalCredits`: up to three selected references
   cost nothing extra, four or five raise every blast's price.
8. Only after explicit approval is saved: generate (single slot, or full set only when the user
   clearly asked for the full set). Poll with `get_listing_builder_slot_results`.

Most tools beyond the planning entry point are discoverable: if a tool is not directly visible, find
it with `search_capabilities` and invoke it with `execute_capability`.

## 5. Triage discipline for messy bundles

- **Distill, do not forward.** A 40-page review-mining doc becomes: about 7 buyer questions, one
  rewritten product description, a shortlist of header phrases, a cast of 1 to 2 avatars, and 2 to 3
  constraint sentences. If a field's content reads like research notes, it is not done.
- **Route constraints before you write them.** Sort every "must / must never" by what enforces it:
  casting goes to avatars (2.1); physical product accuracy goes to product reference images; brand
  color goes to the branding preset, and so does a real logo file (as an uploaded asset URL on
  `logoUrl`); on-image wording goes to `headerPhrases`. Only what is
  left belongs in `customInstructions`. A constraint sitting in the wrong field is weaker than the
  same constraint in its own field, and it crowds the brief.
- **Every claim that reaches a brief or header must be defensible.** Research bundles contain
  competitor claims and speculation; on-image text is publishing.
- **Deduplicate before sending.** The MCP dedupes URLs, but semantic duplicates ("BPA-free"
  appearing in five artifacts) should be merged by your agent, not sent five ways.
- **When research conflicts** (two different ingredient lists), surface the conflict to the user
  instead of picking one.
- **Discard freely.** SEO backend keywords, PPC data, pricing research, and fulfillment notes have
  no destination here. Dropping them is correct, not lossy.

## 6. Hard don'ts

- Do not ask for or attempt to reconstruct Genrupt's compiled prompts, generation context, or
  internal scoring. The API never returns them and skills must not probe for them.
- Do not infer approval from silence or enthusiasm; approval is an explicit save.
- Do not pick a main-image tactic the user has not answered for.
- Do not write casting instructions into briefs, header phrases, or custom instructions, and do not
  ask for per-image variety in prose. Use the avatar fields (2.1) and let the system vary appearance.
- Do not exceed the caps (24 refs per bucket, 2 alternates, 24 header phrases, 8 custom avatars,
  700/120/4000 char limits). Trim at triage time rather than letting validation reject the call.
- Do not retry a failed paid generation through a different paid workflow; on insufficient credits,
  send the user to the Buy Credits button.

---

## 7. Wonka house decisions layered on top (Jay, 27 July 2026)

These are OUR calls for the bootcamp, not Genrupt's rules:

1. **A+ is hands-off.** Wonka does not feed a content brief into A+ generation. Genrupt decides the
   A+ alone; the house strategy is that A+ exists to be beautiful and impressive, and Genrupt does
   that well. Wonka's job on A+ is generate, inspect, and fix, never direct.
   **1b. A+ edits also run inside Genrupt**, through the A+ edit flow, never the direct OpenAI edit
   API: Genrupt's editor is built for A+ and the export comes out final. Main and secondary edits
   stay on the direct API, where cents beat credits.
2. **The main image is chosen, not briefed.** Our brief never writes main-image content. We decide
   the three controls (tactic, hang-tag text, packaging preference) with the user, Genrupt generates
   the main candidates, and the human picks from them.
3. **Casting comes from the persona in The Product Report**, translated into 1 to 2 customAvatars.
   The old practice of writing casting paragraphs into slot contentBriefs is retired, per 2.1.
4. **Style comes from the branding preset, and the set's look from Day 6's Refine.** The preset is
   resolved from the product's `Genrupt preset ID` row and may carry a logo, brand styling, or both.
   `references.styleImage` (the Brand style image, brand-level) is left unset in the bootcamp
   flow; the Refine style reference (set-level, Day 6) is a different object with a different
   lifetime, and a gallery choice never becomes the brand's style image by itself. The brief
   never describes style, graphics, colors, or fonts in prose, and never a logo.

## Known intake frictions (verified on real runs)

- **`PLAN_SETUP_MISMATCH` (409) can be a FALSE NEGATIVE: read the plan back before any retry.** Measured 2 September 2026: the server reported four setup fields not applied while the read-back showed every field applied and the plan already created. So on a 409: do not retry; read the plan back with the current plan-review capability; compare its setup fields and slot count against what was sent; if they are already there, continue and say the 409 was a false negative; retry once only when the read-back proves the setup did not apply; after a second mismatch, read back again before stopping or spending; and report what the read-back showed, never the error text alone. (The older observation that an identical retry "heals" a reused-flow 409 is consistent with this: the retry looked like a heal because the first call had already applied.)
- **`hangTagText` has TWO caps and the schema shows one.** 28 characters (schema) AND 5 whitespace-separated words (server, undocumented); a standalone dash counts as a word. `4 TIERS - 32 OZ BOWL` (20 characters) was rejected as six words on 2 September 2026; `4 TIERS, 32 OZ BOWL` took. Count both before the save and prefer a comma to a standalone dash.
- **A cost preview is a forecast; a rejected planning attempt may or may not bill.** Read the balance before and after the whole operation and report the measured difference; if another session spent on the account meanwhile, say the difference is unreliable. Never promise that every failed attempt bills, and never quote a range that assumes it.
- **Any setup-level write silently clears the plan's approval** (preset attach, tactic change, avatar edit, the vanilla control's clear-and-restore). Read the plan back and re-approve before the next paid call. See the Genrupt contract in CLAUDE.md, rule 6.
- **The `genrupt` CLI runs in a DIFFERENT account scope from the MCP connection.** Set lookups 404 and uploads land in another scope, so the CLI is never a workaround for an MCP gap. When MCP cannot do something, the answer is the Genrupt app in the owner's browser, not the CLI.
- **Reused flows append rather than rebuild.** Old slots keep their jobs and their slot-level `referenceImages`, the approved reference selection is preserved, nothing re-imports, concept numbering continues. Reuse is a decision the owner makes with that named, never a default.

# Day 2: Wonka, Meet My Product

Today your product walks into the factory. Three lessons, one room. First you photograph the product so that Wonka never has to guess what it looks like. Then you hand him one link and one ZIP, check that he has the right product and the right niche, and tell him the things only you know. Then he goes to work alone and comes back with The Product Report.

No images today. This is the floor everything else stands on, and it is the day a lot of sellers discover that a complaint sitting in their reviews was caused by their own images.

**The sentence for the day: you are not showing him a product, you are teaching him one.**

## What you will have by the end of today

- A set of reference photos, five to ten or more, each one adding information the others do not
- A product room on disk at `factory/Products/[your-product]/` with every folder inside it and a `status.md` station tracker
- Your files sorted and filed by Wonka himself, with a receipt naming each one and where it went. You never move a file
- Your owner intel recorded word for word in `status.md`
- Five research files in `research/`: `insights.md`, `reviews.md`, `persona.md`, `competitors.md`, `selling-points.md`
- `research/product-report.md`, The Product Report, the one document tomorrow's brief is built from

---

## Lesson 1: Don't Make Wonka Guess

*Reference photos. Five to ten useful ones, and the rule behind them.*

### A reference problem, not a prompting problem

Many bad AI product images are not a prompting problem. They are a reference image problem. If the model cannot see a part of the product, it has to invent that part.

So the rule for this lesson is simple: **do not make the AI guess.**

By the end of the lesson you want roughly five to ten photos that teach Wonka what your product actually looks like. Not five to ten beautiful photos. Five to ten useful photos, where every image adds new information.

### The listing images are not references

One of the most common mistakes is handing the AI the existing images from your Amazon listing as product references. Professional is not the same as accurate: they may be retouched, composited from several photographs, or generated with AI, with parts hidden, proportions adjusted, materials changed, and the product already sitting inside a scene the AI will copy instead of learning the product. A reference photo exists to inform, not to impress. If you have the real product, your own plain phone photos are the primary reference. (Genrupt does pull your listing gallery in when the plan is made on Day 3. That is a stand-in. On Day 4 your approved sheet replaces it.)

### The four things to cover

An umbrella is the film's example. One photo of a closed umbrella says almost nothing about it open: the canopy, the underside, the real diameter, the ribs, the mechanism, how the handle relates to the rest.

For most products, focus on four things.

1. **Multiple angles.** Front, back, sides, top, and any angle that reveals a shape the other photos do not show.
2. **Different states.** If the product opens, folds, extends, connects, changes shape or comes apart, show the important states. For the umbrella: closed, partly open if that teaches something, fully open, and from underneath.
3. **The product doing its job.** If it flows, lights up, mists, spins or inflates, one photo of it actually running. On Day 4 Wonka builds a working-state sheet from that photo, and no description can stand in for it.
4. **Real-world scale.** A model can recognise a shape without knowing whether it is six inches tall or six feet tall. A hand or a familiar object makes the size clear.
4. **Important details.** Buttons, stitching, textures, materials, connectors, labels, hinges, mechanisms, and any small feature that would be expensive to get wrong.

### Each photo answers a question the others did not

Five to ten strong images is a great starting point for most products. But do not shoot ten versions of the same angle. Each image should answer a question the previous images did not answer. When a new photo adds nothing, you are done.

### Multi-part products

If your product contains several pieces, the count can go above ten. Photograph the complete set together from several useful angles, so Wonka understands how the pieces relate to one another. Then photograph every important part separately. Do not throw countable pieces into a pile and expect the AI to work out how many there are or what each one looks like.

### Packaging is a different object

If the packaging may appear in your images, photograph that too: the front, the back, the main label, and, when relevant, how the product sits inside the package. Packaging is a separate object. If the AI has never seen it clearly, it will invent it. If a buyer never sees a box, skip it on purpose rather than by forgetting.

### How to shoot

You do not need a studio. A phone, a clean surface, neutral light and a simple background are enough. Do not add filters. Do not reshape the product. Do not try to turn these into marketing images. These photographs are evidence, and sharp and accurate matters more than beautiful.

### No faces

Unless a person is genuinely necessary, keep faces and full people out of your references. A hand for scale is fine. A face is not, because the image model may treat that person as part of the reference and reuse the same face in future images. A face cream, where the application area matters, can justify a person. Otherwise let the reference focus on the product.

### If you do not have the physical product

There is a fallback. Look for realistic customer photos inside the reviews. They often show the product in ordinary light, on a real table, next to familiar objects, from angles the listing never shows. They are still a fallback, because you cannot control which details are missing, but they are usually more informative than a polished marketing image. Tell Wonka plainly that this is what your photos are. He records the source as the fallback rather than pretending the reference is complete, and Day 4's smoke test becomes the one you do not skip.

### Then stop

Cover the shape, the scale, the details, the states, the included parts, and the packaging when it matters. Then stop. You are not creating the Amazon images yet, only making sure Wonka will not have to guess.

The printable version of this lesson is `downloads/product-photo-shot-list.md`.

---

## Lesson 2: Wonka, Meet My Product

*One link, one ZIP, one approval, and a conversation.*

### What Wonka reads himself, and what only you can bring

The product link lets Wonka find the title, the brand, the price, the listing and the rest of the public information by himself. There is no reason for you to copy anything he can already read. What you bring is everything that is not on the product page, and it comes in two kinds.

**Files.** Product photos, packaging photos, a logo file if you have one, a brand book or style guide if your brand owns one, instruction manuals, research, return data, customer-service notes, previous test results, anything that might be relevant. **You do not need all of these, and most sellers have only some.** A missing logo and a missing brand guide are both completely normal; Wonka never asks for either. Upload whatever already exists and he sorts it.

**The knowledge in your head.** What has worked, what customers ask, what must appear in the images, which claims you are allowed to make, what to avoid. That does not go into a special document. You tell Wonka in the conversation.

Upload the files, type the notes. That is the whole handover.

### Why a ZIP

A photo pasted into Claude is visible in the conversation, but it never lands on disk. A ZIP attached to the chat arrives as a real file with a path. Wonka opens it, reads each file's content rather than just its name, files each one in its right place inside the product room, and reads you back a receipt: every file, where it now lives, product photos and packaging counted separately, and anything that failed to open or did not belong. One ZIP or several, it does not matter. Too big to attach? Drop it into the Wonka folder and tell him it is there. The one-pager `downloads/front-gate-shopping-list.md` (Pack the ZIP) lists what goes in.

### Run the room

Open Claude Desktop, go to the Code tab, and make sure the Wonka folder is open. Start a new conversation and run the skill:

```
/meet-my-product
```

Attach the ZIP, then type:

```
Amazon URL: https://www.amazon.com/dp/B09BDGFKXB/?th=1

The attached ZIP contains my product reference images and other relevant files.
```

That is the demo product's URL; yours goes in its place. A bare ASIN works too: Wonka defaults the marketplace to amazon.com and says so, so correct him if your listing lives elsewhere. A product that is not live yet gets a plain description, recorded as `live: no`.

### The preflight card: read it, then approve it

Wonka reads the listing and makes sure he is about to work on the right product. He shows one card before anything is created or spent:

- **The listing title, verbatim.** The wrong-product guard: a transposed character in an ASIN passes every format check and registers a stranger's product, and a human reading the title is the only thing that catches it. Read it properly.
- **The marketplace, the brand, and the current price.** Fetched facts, stated for you to correct, never asked back as questions.
- **The proposed niche.** In the film it should be chocolate fountain. Not fondue pot, and not a broad category like party appliance. The niche decides which products count as competitors and which reviews are relevant. If the niche is wrong, even excellent research studies the wrong market.
- **The review machine needs the Genrupt Chrome extension.** The deep review analysis reads live Amazon reviews through it. Install it in desktop Chrome from genrupt.com/extension (unzip, `chrome://extensions`, Developer Mode, Load unpacked), pin it, and sign in on an Amazon listing until it shows the green indicator and `Logged in - Full review access available`. If Wonka says the extension is offline, open the listing in Chrome, open the extension, sign in, and ask him to check again; a queued job usually continues on its own.
- **The live cost of the paid research.** The one thing on this floor that spends anything is the Genrupt market analysis with its review deep dive, and its cost is quoted from a live preview, never from memory.

Check the product, the marketplace, the niche and the cost on your screen. Correct anything wrong in plain words. Then approve:

```
Confirmed. Proceed.
```

One approval covers the identity, the marketplace, the niche and the research spend.

### The room opens and the ZIP is filed

Wonka creates the product room at `factory/Products/[your-product]/`, lists the folders back, opens the ZIP, files everything and reads back the receipt. You never open or arrange any of it yourself; the receipt tells you what he received and where it went.

Then he names the gaps, and only the gaps:

- **Real product photos are the one thing that blocks the day.** If they were not in the ZIP, he says so and waits. Shoot them, ZIP them, come back. Whether you return in an hour or in a new conversation, he reads `status.md` and picks up at the interview.
- **Competitors are his job.** Candidates come from the market analysis and from your own listing page. He filters them to three to five that genuinely sell in your niche, checks each gallery, and asks you once whether anyone important should be added or removed. An answer is gold. Silence never blocks the research.
- **Optional data never blocks.** Brand Registry demographics, Search Query Performance, return reasons, past tests. Recorded as `not provided` when absent, and the run continues.

### Owner intel: talk, do not write a document

After Wonka reads the materials, he wants the things only you can tell him. Talk to him the way you would talk to the professional about to plan your image brief. Tell him anything that could affect his decisions: what has worked, what has failed, what customers ask, what causes returns, what must appear, what you cannot promise, and what you want the customer to feel when they see the product.

In the film the product is not Jay's, so the notes are examples, written exactly as he would write them for his own product or a client's:

```
A few important things from our side:

- The main use case is birthdays and family parties. We want the product to feel like the centerpiece everyone remembers, not like professional catering equipment.

- A recurring customer-service issue is uneven chocolate flow. The images should set realistic expectations and make it clear that the machine must be level and the chocolate must be properly prepared.

- Do not imply that users can add solid chocolate and the machine will do everything. The chocolate should be melted before it is poured into the fountain.
```

The first teaches Wonka who the buyer is and what the images should make them feel. The second is real customer-service intelligence and a problem the images may help prevent. The third protects you from a promise the product cannot keep. Even two or three strong notes give him information no public research could find.

Do not write marketing copy for him. And only claim what is genuinely printed on your product or documented in your account. An invented certification here becomes an invented badge in an image later, and that is a suppression risk rather than a style problem. If you are not sure a claim is real, say so; he marks it `unverified` and it stays off the checklist until you confirm it.

Wonka reads what you wrote and asks only the follow-up questions he still needs. He never asks a question whose answer already sits in a file you gave him. Answer from what you genuinely know. If you do not know something, say that you do not know. A clearly recorded gap beats a plausible answer that is not true, and "I have none" is a first-class answer: he records it in your words, names what it costs in one line, and proceeds.

When he has what he needs, he summarises what he learned and names anything still missing or estimated. If something is wrong, correct it now.

### The sentence to wait for

The interview ends when Wonka says, in so many words:

> "I have what I need. The interview is closed. The analysis begins."

Silence is not a close, and your "continue" is not a close; he declares it himself once he has enough. When you see that sentence, the product has officially entered the factory. Now let him work.

### If the listing is not yours

An agency run, a client's product, a demo. Say so, in your own words. Wonka does not fake the interview; he reroutes it. What a buyer needs to feel is derived from the reviews and tagged with its source. The claim gate defaults shut, so nothing unverifiable enters the checklist as yours, and a claim already live on the listing does not inherit approval because somebody typed it. Owner intel stays `none given (not the owner)`. If you do supply notes and answers, you are the owner for every purpose in this room.

---

## Lesson 3: The Product Report

*No new assignment. Understand what he learned, and catch any big misunderstanding.*

### Six sources, cross-referenced

Wonka did not summarise the listing. He cross-referenced six sources: what you told him as the owner, the current listing, the reviews, the competitors, Genrupt's market analysis, and the factory's Improvement Log. On your first product the Log is nearly empty, and he says so out loud rather than papering over it. As you work through more products, what he learned on the earlier ones becomes part of the process.

### Five files, and one report on top

From those sources he wrote five research files:

- `insights.md`: the wider market picture and the funnel diagnosis
- `reviews.md`: the reviews mined, pain points, objections, moments of delight
- `persona.md`: the buyer you actually need to speak to
- `competitors.md`: how the rivals present themselves, and their best frame
- `selling-points.md`: every selling point to consider when the image package is built

You can open any of them and go deeper, but start above them, at `research/product-report.md`, The Product Report: the detailed research turned into one readable document holding the conclusions that will affect your images.

### The Must-Haves

The things shoppers expect from any product in this category. Wonka did not pick them by instinct. He checked what competitors repeatedly show and what customers repeatedly demand, and he marks every one as confirmed by multiple sources or resting on a single one. You will also hear these called table stakes. They are rarely your most exciting messages, and the image package cannot afford to forget them: no points for showing one, elimination for missing one.

### The pains, ranked

The shoppers' pain points and objections, ranked by patterns that repeated rather than by the angriest review he found, with the count behind each rank. What frustrates buyers, what they did not understand before buying, what stops them purchasing, and which problems clearer images could have prevented.

### The expectation gap

The most interesting finding in the demo report. The listing shows a full, continuous chocolate cascade and states a capacity of thirty-two ounces. In the reviews, shoppers reported that getting the result they saw in the pictures took more chocolate, sometimes oil, and proper chocolate preparation.

That does not make the product bad. It means the images made a promise without explaining what it took to achieve it. That is exactly why this research exists. The aim is images that sell the product while setting the right expectation. An image that attracts the wrong buyer, or promises what the product cannot deliver, is not a good image, even if more people click it.

Somewhere in your own critical reviews there is probably a complaint your own creative caused. Finding it is worth more than any lighting decision you will make in this bootcamp. And one rule about how it may be used: a finding from reviews is a review finding, what buyers report. It never goes onto an image as if it were a claim on your box. We close expectation gaps, we do not open new ones.

### The whitespace, and their best frame

Whitespace is what matters to shoppers that the competitors fail to explain clearly. Maybe everyone shows a beautiful party, but almost nobody explains how to prepare the chocolate. Maybe everyone promises easy cleanup, but nobody shows which parts actually come apart. Here you do not need to be creative for the sake of looking different; you can be different by giving the shopper information they genuinely need.

Wonka also picks the single strongest image he found across all the competitor galleries, in `competitors.md` under THEIR BEST FRAME. Not to copy. It sets the standard to beat: what that image does well, and what you can say more clearly, more credibly and more accurately for your product.

### The persona

Not a fictional story about a woman named Sarah who hikes on weekends. A useful picture of the person buying: the occasion, the result they want, and what worries them before the purchase, each anchored to review lines he can point at. If you did not provide Brand Registry data, the demographics are labelled `estimated`. He does not present a guess as a fact, and the label upgrades the day real data arrives.

### The funnel diagnosis

Three questions, in order. Is the main problem getting shoppers to click the listing? Are they landing but not convinced enough to buy? Or is the real problem traffic, meaning the product is not showing up where shoppers search, and images are not the first bottleneck? A click problem points at the main image, a convince problem at the gallery and the A+, and a traffic problem means the first effort goes to visibility while the package is built to be ready when the shoppers arrive. The diagnosis states its evidence and its confidence, and it steers where you invest tomorrow.

### Customer language, and the checklist

Wonka collects the language shoppers use themselves: real words and phrases from the market that may become copy on the images, not slogans he invented.

Then everything becomes the selling-points checklist. Every point has an ID (SP1, SP2, and so on) and a source. Must-haves, genuine advantages, pains the product solves, quality signals, and openings the competitors left. Tomorrow, when he writes the brief, every one of these points gets assigned to a specific image or left out with a written reason. Nothing important disappears on the way.

### How much to review today

You do not need to edit every sentence. The goal is not hours per product. Review the summary, check the main findings, and make sure there is no major misunderstanding about the product, the buyer, or anything you are not allowed to claim. Wonka names the lines he is least sure about and asks you to correct them. If something important is wrong, say so now, in your own words:

```
Correction: [what he got wrong, and what is actually true]
```

He revises the file, records the correction and its source, and tells you in one line what it changes downstream. Then save most of your review time for tomorrow, inside the brief. That is where the research becomes decisions: which message goes in, which image carries it, what order they follow, what you deliberately leave out. The goal is not to give up your judgment. It is to spend it where it is worth the most.

### Session hygiene: land the plane before the fuel runs out

Claude's context meter fills as the conversation grows. Do not wait for it to reach the top. When roughly 25% remains, tell Wonka:

```
Prepare me for compact.
```

He stops at a safe boundary, saves the current state of the work inside the factory, and hands you a complete `/compact` command to paste. You never write the summary yourself. Paste his command, let Claude compact, and Wonka rereads the factory files and continues from the same point. Do it before the context runs out, and never in the middle of a generation that is still running.

---

## Common mistakes, and what they look like

| Symptom | Cause | Fix |
|---|---|---|
| A later image shows a part of your product that does not exist | A reference gap. No photo showed that part, so the model invented it | Shoot the missing angle or state, add it to `2-reference/photos/`, and tell Wonka it is there |
| The preflight card names a product you do not recognise | A mistyped or transposed ASIN. It passes every format check and belongs to a stranger | Say so. He creates nothing. Give him the correct URL and start again |
| The proposed niche is a neighbour (fondue pot for a chocolate fountain) | He read the category, not your market | Correct it on the card in plain words before you approve. The niche decides which competitors and reviews count |
| He "received" photos you pasted, and the photos folder is empty two days later | Pasted images never reach the disk | Attach the actual image files, or a ZIP of them. Wonka files them himself |
| He filed the ZIP and then stopped, asking for photos | Real product photos are the one thing that blocks the day | Shoot them, ZIP them, come back. A new conversation is fine; he reads `status.md` and resumes at the interview |
| He asks you for the title or the price | The listing did not open in his session | Paste the exact title and price from your screen. He records the title as confirmed by your paste |
| He is stuck waiting and will not move | A required item is missing and nobody waived it | Name it in plain words: "I have no critical reviews, proceed without them." That is a waiver. A generic "just go" is not |
| The report reads like a generic category article | Thin review input | Ask what the deep dive returned and have him re-run it. Without Genrupt, paste more critical reviews and ask for a re-run |
| The Must-Haves feel oddly broad | An off-niche competitor got in | Ask him to list the competitors he analysed. He drops the impostor and pulls a replacement himself |
| The whitespace list is vague | He did not actually see the galleries | Screenshot them into `1-inputs/competitors/` and ask him to redo the teardown from the images |
| The persona could be anyone | No demographics and thin reviews | Push back with what you know. If you have Brand Registry, hand over the demographics export as a top-up |
| A confident claim you cannot place | It is untraceable | Ask `Where did that come from?` Untraceable gets deleted, not softened |

Anything else: `guides/troubleshooting.md`.

## What good looks like

- [ ] Five to ten reference photos (more for a multi-part product), each adding information, no faces, no filters, packaging shot separately if it may appear
- [ ] `/meet-my-product` ran on one link and one ZIP; you read the title on the preflight card and it is your product
- [ ] The niche on the card is your exact market, confirmed or corrected before you approved
- [ ] The product room exists at `factory/Products/[your-product]/` with the full folder set, and the receipt names every file and where it lives
- [ ] Your owner intel is recorded word for word in `status.md`, or explicitly `none given` with your reason
- [ ] Every gap is written down: waived in your words, or `not provided (optional)`
- [ ] Wonka closed the interview in his own words before any analysis began
- [ ] All five research files exist with real content, plus `research/product-report.md`
- [ ] Every Must-Have says whether it is double-confirmed or single-source
- [ ] The expectation gap section holds a finding, or says none was found in this sample
- [ ] Exactly one best frame is named in `competitors.md`, with a move to beat it
- [ ] The persona and the funnel diagnosis carry their source label, `estimated` where no Brand Registry data was given
- [ ] Every selling point has an ID and a source, and the Mapped to column is still empty
- [ ] You read the summary and corrected anything fundamentally wrong
- [ ] RESEARCH shows `done` in `status.md`

## Common questions

**"Do I have to build the factory folders myself?"**
No. Gather what you have into one folder, zip it, attach it. Wonka creates the room, files each item, and reads you the receipt.

**"One ZIP or several? And if it is too big to attach?"**
Either. If your files already sit in a few groups, send a few ZIPs; he opens each in the order they arrived. Too big? Drop it into the Wonka folder and tell him it is there. A path is a path.

**"I do not have the product in my hands."**
Use realistic customer photos from the reviews, and tell Wonka that is what they are. He records the fallback, and the Day 4 smoke test becomes the one you do not skip. Shoot the real thing as soon as a unit is in reach and rebuild the reference.

**"My product is not live yet, or it is new with almost no reviews."**
With no listing, give a product description instead of a URL and he records `live: no`. Either way the market analysis mines the competitors' reviews for you, recorded as competitor reviews, and everything else runs the same way. Buyer pain in the niche is buyer pain in the niche.

**"Do I need to find my competitors?"**
No. He surfaces the candidates himself and asks you once whether anyone should be added or removed. If you know who actually steals your sales, say so; that answer is gold. If you say nothing, the research runs anyway.

**"I have no Brand Registry."**
That is a first-class answer. The persona, the demographics and the diagnosis get labelled `estimated`, and they upgrade the day real data exists.

**"I have Search Query Performance, return reasons, or old test results. Where do they go?"**
In the ZIP, or handed over later as a top-up; he re-runs only the parts of the research they touch and upgrades the labels. Return reasons are the most underused input in ecommerce: "smaller than expected" becomes a scale frame, "not as described" points at an image that over-promised, and "arrived cracked" is packaging, which no image fixes. He sorts them.

**"I am running without Genrupt."**
The kit still runs. The one manual job is reviews: log in to Amazon, sort by Most recent and copy a batch, then filter to Critical and copy a batch more, into one plain text file in the ZIP. Do not drop the angry ones; they are the material.

**"He cannot open a competitor listing."**
Screenshot the full gallery into `1-inputs/competitors/` and tell him it is there. He reads images with vision. He never analyses a competitor from memory, and if he offers to, stop him.

**"Can I stop halfway and come back tomorrow?"**
Yes. Everything he learned is on disk. A new conversation starts with him reading `status.md` and picking up where the room stopped. The one thing never to do is let the context run out mid-generation; say `Prepare me for compact.` first.

---

## What Day 3 opens with

The Brief Room. Wonka takes everything the Research Room learned and writes one creative brief for your whole package: the main image, the full secondary set, your cast, your variation plan. Every selling point on today's checklist gets mapped to an image or skipped in writing with a reason, and you edit the document like the owner you are.

Bring your `research/` folder with `product-report.md` on top, your photos already sitting in `2-reference/photos/`, your real SKU list if the product sells in colours, sizes or counts, and your own opinions. Re-read the whitespace section and the checklist before you go in. You will be a far better editor for having slept on the research.

Measure twice, invent once.

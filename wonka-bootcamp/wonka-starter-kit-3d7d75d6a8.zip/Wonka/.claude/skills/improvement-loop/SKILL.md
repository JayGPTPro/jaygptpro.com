---
name: improvement-loop
description: Close BOTH learning loops in one command. PART A writes what wins in the MARKET (Tasting Card verdicts from every race, an Amazon A/B verdict, a real shopper poll, owner creative preferences) into the Improvement Log with honest evidence strength and visible conflicts. PART B reviews the run itself and writes how WONKA works better (corrections, recurring QA flags, rework, owner working-style preferences) into the Improvement Log. Run after every Tasting Round, upload pack, or A/B verdict, and at the end of any big session. Triggers: /improvement-loop, "record the lesson", "update the improvement log", "the tasting card is in", "the A/B results are in", "remember that I hate...", "review this session", "close the loop", "get better at your job".
---

# The Improvement Loop

| Meta | Value |
|------|-------|
| Room | The Improvement Loop |
| Station | PROVE (step 3 of 3, and always-on) |
| Day | Day 10 of the bootcamp, after `/ready-to-upload`. It is the last command of the day and the last command of a project; nothing runs after it unless the owner asks. Outside the bootcamp, run it the same day any result lands. |
| Needs | Today's real date; every result not yet recorded (`tests/tasting-r[N]-[date]-[race]/tasting-card.md` plus `results.json`, an Amazon A/B verdict the owner pastes, a real shopper poll, or a stated owner preference); the run or session to review; `factory/Improvement Log.md` (all three parts), and the product's `status.md` |
| Saves to | factory/Improvement Log.md (all three parts of the one file) |
| Typical cost | Free. Reading and writing only. No credits, no API spend, nothing to approve. |

## What this room does

A Factory that forgets its results is an expensive random number generator. This is ONE command that feeds ONE file, `factory/Improvement Log.md`, in two loops, and the difference between them is the whole point:

- **PART A . the MARKET loop (Part 1 of the log).** What wins with buyers: creative patterns, evidence-weighted, carrying the numbers that earned them ("a savoury frame, queso and wings, beat a second dessert frame in the gallery, preferred by 57 of 100 synthetic tasters, chocolate fountain niche"). It is about the CANDY. `/creative-brief` reads this part before writing a word, so lesson one shapes brief two and the third product starts smarter than the first.

**Where the lessons are read next (the loop only closes if a later room reads the file).** Two rooms read `factory/Improvement Log.md` on the next product, in this order: `/meet-my-product` reads it during research (step 19 of Phase C, source 6 of six) and applies the lessons that touch research beside the new product's own evidence; `/creative-brief` reads it again before writing a word (its step 1) and runs the rejection pre-flight against Part 1. Both rooms read it by scope: a working preference is general only when the owner said so; brand taste applies to the brand named in the row; a product fact stays with its product; a `HYPOTHESIS:` row is something the next product TESTS, never a rule it applies. Part 2 is also read at the start of every session. Write every row so that those two reads can use it without guessing: name the product, the niche, the brand and the label.
- **PART B . the PROCESS loop (Part 2 of the log).** How Wonka works better as an employee: what he missed, what he should have front-loaded, the rework he caused, and how this owner likes to work. It is about the FACTORY WORKER, not the candy. It is read at the start of every session, which is exactly why it must stay short and true.

The same file also carries **Part 3, the experiments ledger**, one row per race; this room finalizes those rows once the lessons are distilled.

One question routes everything: **is this about the candy or about the worker?** "Shoppers preferred X" is candy, so PART A. "I should have confirmed the real variation list before planning" is worker, so PART B. Run BOTH parts every time. Either may honestly come back empty, and an honest empty is a result.

The Improvement Log is read by a machine that spends money. Every row in it becomes an instruction in a future brief, so a row that overstates its evidence quietly buys the wrong images months from now.

**The owner's rule for this room: soften the finding, keep the practice.** A finding is what one test or one run showed, and it is written at the strength that test can carry, usually as a hypothesis to try next time. A practice is a check worth running regardless (read printed text against its source after an enlargement, confirm the real variation list before planning), and it is kept as a practice even when the finding behind it was small. The two are never confused: a small finding does not cancel a good practice, and a good practice does not inflate a small finding into a law.

## What one sitting can and cannot say

Most Improvement Loops run on ONE Tasting Room sitting. Its two races are two questions asked of the same panel on the same day, not two independent replications, and everything written from them carries that limit:

- **A Lean is a hypothesis, in those words.** A single Lean race produces rows labelled `HYPOTHESIS:` at strength MIXED, with "Lean, not proof" in the evidence cell. It never produces a categorical USE or AVOID about a whole creative approach.
- **A winner among different compositions does not isolate the cause.** When the candidates differed in several ways at once (a prop, a cast, a background, a tag), the win belongs to the whole frame. Write which frame won and what the tasters said; do not write "hands win" or "white backgrounds lose" as if one variable had been tested alone.
- **Ranking gallery frames inside one set does not prove a slot order.** "Most convincing" and "weakest" within a set say which frames carried it. They do not say that a different order would have done better, because no order was raced against another.
- **Mention counts are mentions.** "Raised by 14 tasters" is fourteen reactions from a synthetic panel. They are not fourteen people, fourteen votes or fourteen lost purchases, and the row never converts one into another.
- **Two Leans stay MIXED.** Agreement between the main race and the gallery race of the same sitting is worth noting in the evidence cell as corroboration inside one sitting; it does not promote the row. What promotes a row is evidence relevant to the actual claim: a later gate-passed test on the same question, a real shopper poll, or an Amazon A/B. Two tests do not automatically make a law either; the second test has to be about the same claim.
- **Nobody ran an Amazon experiment because the product was packaged.** A packaged folder is not an A/B, and the owner shipping their own pick after a Lean does not change what the panel said.

Everything that follows applies these limits. Where an older sentence in this file reads stronger, this section wins.

## Before you start

Read every input first, then handle each one exactly as this table says. An honest gap beats an invented lesson, every time.

| Input | If it is missing |
|---|---|
| **Today's real date**, from the shell (`date`) | Run it once, before writing anything. Every row in the Improvement Log is dated and the whole evidence ladder rests on those dates. If the shell is unavailable, use the date printed inside the Tasting Card header and write `date from card` beside it. Never guess a date from memory. |
| **The result artifacts**: `factory/Products/[product]/tests/tasting-r[N]-[date]-[race]/tasting-card.md` and `results.json` | **PROCEED with PART B only.** If no result exists, say so plainly ("no new result to record, so the Improvement Log stays as it is") and review the run for process lessons. Never write a Patterns row without a card to cite. |
| **The product folder**, when the input is a pasted result rather than a card | **ASK which product.** Derive it from the card path when there is one (`factory/Products/[product]/tests/...`). With more than one product in the Factory and no path, ask. Never guess a product, because the niche and the status file come from it. |
| **The exact niche phrase**, from that product's `status.md` | **ASK for it in the owner's own words** and record it. Copy it word for word; do not paraphrase it into a tidier category. A pattern with the wrong niche on it gets applied to the wrong product later. |
| `factory/Improvement Log.md` | **RECREATE and PROCEED.** The log ships with the kit, so a missing one usually means the command is running outside the Factory folder. Check that first and say so. If the file is genuinely gone, recreate it with the canonical headers from the Output format below, tell the owner the history was lost, and carry on. Never invent headers, and never append to a file you have not read in THIS run. |
| **An Amazon A/B verdict** the owner promised | **"I do not have it yet" is a complete answer.** Leave that `amazon-ab` row at `running`, note the date it was asked for, proceed with everything else. Never estimate an A/B outcome and never mark a row won or lost on a feeling. |
| **A/B numbers pasted without the metric, both arms, or the duration** | **ASK once** for the missing piece (CTR or CVR, version A and version B, how long it ran, and what Amazon called the result). If the owner does not have it, record the row as `inconclusive` with the reason, and record no Patterns row. A one-sided number is not evidence. |
| **Anything that moved during the A/B or the swap** | **ASK ONCE, always:** "did price, coupons, ad spend, stock, or any other listing image change while this ran?" A yes does not void the result, it re-labels it: name the confound in the row's Key why, cap any Pattern it produces at MIXED, and add one dated line to the Lessons log ("win recorded with confound: price cut in week 3"). An unasked confound is how a price cut gets written into the log as an image lesson and then shapes every future brief. |
| **A result the owner got by SWAPPING the image and watching** (`method: swap_with_monitoring` in the upload pack, the path taught to owners without Brand Registry) | **PROCEED, and grade it BELOW a real shopper poll, never as an A/B.** There is no control arm: seasonality, price, ads and competitors move the same numbers, which is what the Shipping Room's own caveat says. Log it on the `amazon-ab` row with `swap, uncontrolled` written into the Margin cell, cap any resulting Pattern at MIXED, and never let it supersede a Tasting Round row the way a true controlled A/B does. Ask the confound question above, where it matters more here than anywhere. |
| **A real shopper poll** result (the optional Pro Move) | **PROCEED.** Use it in PART A at its true weight (real people, above any synthetic panel). Do NOT create or finalize a `shopper-poll` row in `Improvement Log.md`; no skill writes those. Hand the owner the exact row text to paste if they want it logged. |
| **The session to review** for PART B | If the run happened in an earlier session (a verdict that arrived weeks later), say so and review the ARTIFACTS instead: `status.md` Log lines, the scorecards, the `edits/vN/` round folders and `edits/fixes-log.md`, the brief's gaps. If there is genuinely nothing to review, PART B reports "no run to review" and adds nothing. |

## Process

### Step 0. Inventory every result, then check what is already recorded

1. **List every unrecorded result, not just the newest one.** One Tasting Room sitting holds TWO races (the main race and the gallery race), and the bootcamp runs ONE sitting, so a Day 10 run typically has TWO tasting results waiting plus whatever fixes followed them. Name them out loud before processing any of them. **Processing one card and calling the loop closed is the most common way this room lies.** If a product genuinely ran a second sitting, say so and process all four.
2. **Check each one against the log before writing.** A result is already recorded when its test folder appears in a row's Source test cell and the ledger row reads `logged`. A repeated run on the same evidence UPDATES or REFERENCES the existing rows; it never adds twins, never writes a second ledger row, and never writes a second completion line. **When nothing new exists, say so in one line ("nothing new since [date]; the log stands as it is") and stop.** No duplicate lessons, no fictional completion record, no ceremony.

### PART A . market patterns (Part 1 of the log)

1. **Read the card properly, by section.** Open `tasting-card.md` (and `results.json` when a number needs checking) and read, in this order: `## Verdict` (the shares, the standardized label, the models-disagree line, the vs current listing line), `## What the tasters keep saying (ranked objections)` with its mention counts, `### Per-candidate themes` (what worked and what hurt, per candidate), `## Strongest frame in each set` for a gallery race, and `## Round comparison` when it is a Round 2. The vote count only says a pattern exists. The objections say WHAT it is.

2. **Apply the evidence gate BEFORE writing any pattern.** The Tasting Room grades its own reliability, and this room obeys that grade:
   - **Clear lead**: the counts plus the intent gap are usable evidence. Write the pattern.
   - **Lean**: usable only as a lean. Write the pattern at strength MIXED (the book's "apply with judgment" slot, which is exactly what a lean is), open the Pattern cell with the word `HYPOTHESIS:`, and say "Lean, not proof" inside the evidence cell. A Lean never earns USE and never earns AVOID.
   - **Toss-up, or the base models disagreed on the winner, or the card carries the parse-rate quality warning (under 90%)**: **NO pattern row from the shares.** Record an honest no-result line in the Lessons log instead. The counts from a coin flip are noise, and noise in this book becomes an instruction later.
   - Whatever the tier, the recurring OBJECTIONS are still real material. An objection is not a tested pattern, so it goes to the Lessons log with its mention count and the race it came from, where the next brief still reads it.

3. **Extract the pattern, and test that it is one.** A pattern is a reusable creative claim a future brief can act on. Not "option B won" but "a savoury frame, queso and wings, beat a second dessert frame in the gallery." Three checks before it earns a row:
   - **Pointable**: it names a visible creative choice (a composition, a message, a prop, a frame job, a color decision) that you could point at in an image. If you cannot point at it, it is a note, not a pattern.
   - **One step of generalization, no further**: from the tasters' stated reason, generalized once. Two steps and you are inventing.
   - **No result promises**: a pattern says what won a test. It never says what it will do to sales, ranking, or conversion. That promise is not ours to make.

4. **Record what LOST too, in its own row, at the strength the race can carry.** A losing candidate with clear objections in a **Clear lead** race earns an AVOID row ("three stacked callouts on the main lost to a single headline"). In a **Lean** race the same loss is a `HYPOTHESIS:` row at MIXED ("the most dramatic main did worse than a calmer one; lost once, which is not losing clearly; worth testing, not worth banning"). Losing one race is not losing clearly, and banning a whole approach on one Lean costs more than it saves. Losses still teach faster than wins, so a run that only records winners has thrown away half of what it paid for.

5. **Attach the evidence in this exact shape**: shares, panel size in words, race, round, stability label, date, niche, and the source folder. Example: `won 57 votes to 31, 100 synthetic tasters, gallery race, round 1, Clear lead (2026-08-14)`. Write "100 synthetic tasters", never a bare "n=100": a number with no panel type reads like real shoppers to whoever opens this book next year. The niche is the exact phrase from `status.md`, because a pattern proven in one niche is only a HYPOTHESIS in the next one.

6. **Record a round-over-round move as its own pattern IF a second round ever ran.** By default the bootcamp runs ONE sitting, so this usually does not apply.** If the same candidate was refined between rounds and its share moved, the `## Round comparison` delta is evidence about the FIX, which is the strongest thing a two-round run produces: "enlarging the headline and dropping two callouts moved the same candidate up 13 votes between rounds, 100 synthetic tasters, rounds 1 and 2." Cite both rounds. If the share fell, that is an AVOID row about the fix, and it counts just as much.

7. **Grade the strength honestly, on the full evidence ladder.** Higher evidence outranks lower evidence on the same question:
   1. **Amazon A/B** (real buyers, real money, controlled). Outranks everything.
   2. **Real shopper poll** (real people, no purchase). Outranks any synthetic panel.
   3. **Tasting Room** (synthetic panel, directional plus objections).
   Then the count: **one test = weak signal**, recorded and used as a lean, never as a law. **A second, gate-passed test on the SAME claim makes a usable prior**, applied by default; two tests on different questions do not add up, and only tests that CLEARED the gate count. Two Leans do not add up to a law; they stay MIXED. Stronger decisions need evidence relevant to the actual claim, not more rows. Strength labels are the three the book defines and no others: **USE** (apply by default), **MIXED** (conflicting or lean evidence, judge per case), **AVOID** (lost clearly).

8. **Check for conflicts, and make them visible.** If a new result contradicts an existing row: LOWER the old row (USE becomes MIXED), keep both results side by side in the evidence cell, add a dated line under `## Conflicts on record` naming what differed (niche, panel type, round, image quality), and never silently overwrite. When the contradiction comes from HIGHER evidence (an A/B against a tasting round), the higher one sets the new strength and the older evidence stays in the cell marked `superseded by [source]`. A visible conflict is information. A hidden one is a lie in a book that spends money.

9. **Write Part 1.** Add or update the rows under `## Patterns`, append preferences and conflicts and log lines to their own sections. Append to evidence cells, never erase them: the history of a row is part of its value.

10. **Finalize the experiments ledger (Part 3), one row per race.** Find each matching row (Type `tasting-room` or `amazon-ab`) and complete Winner / Margin / Key why / Status. Status is `won` / `lost` / `inconclusive` (`inconclusive` whenever the label was not Clear lead or the models disagreed), and it becomes `logged` once that result's patterns are actually in the Improvement Log. When the owner shipped their own pick after an inconclusive or unfavourable result, Status stays as it was and Key why ends with the suffix `owner-shipped`; the schema stays at eight columns and a Lean or a Toss-up is never relabelled as a win. If a row is genuinely missing, create it in the canonical 8-column schema:

    `| Date | Product | Type | Candidates | Winner | Margin | Key why | Status |`

    Two things this room never does: it never invents an `amazon-ab` row (a test nobody ran, on a listing that may not even be the owner's, is a fabrication), and it never writes or finalizes a `shopper-poll` row (those are logged by hand, by the owner).

11. **Handle owner CREATIVE preferences.** When the owner states taste ("I hated that layout", "never use purple", "keep the stainless base in frame"), record it as a dated bullet under `## Owner creative preferences`, quoting them closely. It binds future briefs like a pattern does, and it is labeled a preference, because the book never dresses taste up as data. A WORKING-STYLE preference (how Wonka should operate) is not creative taste; it belongs in PART B.

### PART B . process lessons (Part 2 of the log)

Review the run for these five signals. Do not review from memory alone: the evidence is on disk.

**Where to look:** this session's conversation (the corrections are in it, verbatim), the product's `status.md` Log lines, `scorecards/scorecard-[scope]-[date]-[run].md` (recurring flags are countable), the `edits/vN/` round folders and `edits/fixes-log.md` (rework is countable: a file fixed across three rounds cost three rounds), the brief's `## Gaps carried forward`, and the Tasting Card's objections read against what the brief actually planned.

1. **Corrections and re-asks.** Where did the owner correct Wonka, override a recommendation, or ask the same thing twice? Quote the correction, then distill the rule ("when the product has variants, confirm the real list before planning, never assume").
2. **Recurring QA flags.** Which defect appeared on MORE THAN ONE image in the Inspection Room? A repeat is a planning failure, not a QA failure: it should have been prevented upstream ("text kept failing the squint test, so plan fewer labels per slot and the headline renders bigger").
3. **What the tasting revealed that the brief never anticipated.** If tasters reacted to something no slot was planned for, that is a gap in how Wonka plans. The market fact goes to PART A; the planning lesson ("plan a scale frame whenever size questions are plausible") lives here.
4. **Wasted effort and rework.** Edits that should have been regenerations, failed batches, generations on the wrong path, steps run out of order. Each is a method lesson ("enlarging text is a regenerate, not an edit; I burned two rounds proving it again").
5. **Owner working-style preferences.** How the owner likes Wonka to operate: how to walk through a decision, how much to decide alone, pacing, how to report. These go under `## Owner working-style preferences`, separate from process lessons. Creative taste is NOT working style; route it to PART A.

**The bar, so this book stays worth reading at every session start:**
- A defect that hit two or more images, or cost a re-run, a re-generation, or a correction, is a lesson. A one-off that cost nothing is not.
- **At most five process lessons per run**, ranked by what they cost. If more qualify, keep the five most expensive and say plainly that the rest were minor. A lessons table nobody finishes reading teaches nothing.
- **If a lesson is already in the book, do NOT add a twin.** Append the new date to the existing row's Trigger cell as a recurrence, and ESCALATE its How to apply from advice into a precondition ("check this before estimating a batch, every time"). A lesson that recurred is the most important line in the book.

For each lesson that clears the bar, write three parts:
- **Trigger**: what actually happened, concrete, from this run.
- **Lesson**: the general rule, one careful step of generalization, no further.
- **How to apply**: a specific change to a future brief, generation, or inspection, so the next session can act on it. "Do better" is not a How to apply.

**Keep the measurement inside its observation.** A number seen on one run, with one model, at one setting, is written as exactly that ("on this run, two of twenty-six enlargements changed small printed lettering; the affected lettering was estimated at a few pixels tall"). It is never written as a universal threshold ("text under 8 pixels always breaks"). The PRACTICE that follows from it (compare every text-bearing export against its source after an enlargement) is kept as a standing check, and the repair that worked is recorded as one method that worked, never as the only method allowed.

Then append: process lessons to the `## Process lessons` table, working-style notes to `## Owner working-style preferences`. Retire a lesson (Status `retired`) only when a later run proved it wrong or made it obsolete, and note why. History is never deleted.

**Last, COUNT the run into the `## Factory trend` table.** Every number comes off the disk, never off memory, and the counting takes a minute:

| Column | Counted from |
|---|---|
| Fix rounds | how many `edits/vN/` folders the product has |
| QA fails | FAIL verdicts across `scorecards/` for this run |
| Tasting verdict | the tier printed on the main race Tasting Card |
| Lessons added | process lessons this run just wrote |

Then say the trend out loud in one sentence, comparing against the product above it ("the second product needed three fix rounds where the first needed six"). This table is the only evidence the loop actually closes. Without it, a factory that is getting worse reads exactly like a factory that is getting better, because both keep adding lessons. **One product on the floor is not a trend**: write the row anyway, say plainly it is the baseline, and compare from the next run on.

## Routing examples (which book gets what)

| The raw observation | Book | Where |
|---|---|---|
| "The savoury frame beat the second dessert frame, 57 vs 31, 100 synthetic tasters, Clear lead" | Improvement Log | Patterns row (weak signal until a second test) |
| "The hands frame won the main race, 100 synthetic tasters, Lean" | Improvement Log | Patterns row opening `HYPOTHESIS:`, strength MIXED, "Lean, not proof" in the evidence cell |
| "The dramatic main came last of three, Lean" | Improvement Log | `HYPOTHESIS:` row at MIXED, never AVOID: it lost once, not clearly |
| "Slot 3 was most convincing inside our set" | Improvement Log | Evidence about the frame; never a claim that this slot ORDER beats another, because no order was raced |
| "Enlargement changed small lettering on two frames" | Part 2 | Process lesson: the observation as observed, plus the standing practice of reading text against its source after any enlargement |
| "My skincare brand shares a founder with my personal brand" | Brand kit, not this log | Recorded by `/brand-kit` in the owner's words. A founder's profession or credentials verify no product claim, so nothing about claims moves between kits |
| "The panel came back Toss-up and the models disagreed" | Improvement Log | Lessons log, honest no-result. No Patterns row. |
| "Fourteen tasters asked whether it actually flows" | Improvement Log | Lessons log as an objection with its count, not a Patterns row |
| "Never use purple, I hate it" | Improvement Log | Owner creative preferences |
| "The A/B contradicted last month's Tasting Round on white backgrounds" | Improvement Log | Conflicts on record, the tasting row downgraded and marked superseded |
| "Tasters kept asking about size and the brief never planned a scale frame" | BOTH | Market fact to Patterns; "plan a scale frame when size questions are plausible" to Process lessons |
| "I edited when I should have regenerated and burned two rounds" | Part 2 | Process lessons |
| "Same squint-test fail on 4 of 8 images" | Part 2 | Process lessons (front-load legibility into the brief) |
| "Give me two options and let me pick, do not decide alone" | Part 2 | Owner working-style preferences |

## Where each lesson belongs (scope)

A lesson saved in the wrong scope gets applied to the wrong product later. Before writing, decide which of four it is:

- **A working preference** ("short updates, result first") is general only when the owner says it is general. It goes under `## Owner working-style preferences`.
- **Brand taste** ("never purple", "warm light") belongs to THAT brand. Under `## Owner creative preferences` the bullet names the brand (or the product, when there is one brand). It is shared across brands only when the owner says so.
- **A product fact or claim** ("32 oz", "lifts apart into four parts") belongs to that product's own records (its brief, its reference sheet, its status file), never to a brand kit and never to this log as a general pattern.
- **A panel observation** keeps its product, its niche, its race and its evidence label in the row. A pattern proven in one niche is a hypothesis in the next one, and the row says so.

## When to run

- After every Tasting Round lands, on ALL of that sitting's races, not just the main one.
- After `/ready-to-upload`, and again when an Amazon A/B verdict arrives, however many weeks later.
- At the end of any big working session, even with no test result. PART B may still have lessons while PART A honestly stays empty.
- On Day 10 of the bootcamp it runs once across the whole run, so expect several results in the queue.
- Not again just to produce another summary. With no new evidence the honest answer is one line, and the owner is told so rather than handed a second copy of the same lessons.

## When something is missing or broken

- **The log is not where it should be**: the command is probably running outside the Factory folder. Say that first, check, and only then recreate the file from the canonical headers.
- **No result and no session to review**: report "nothing to record today" and stop. That is a legitimate outcome of this room, not a failure of it.
- **The owner does not have the A/B numbers yet**: record the ask with today's date, leave the row `running`, and continue. Never estimate.
- **The card carries the parse-rate quality warning**: no pattern from those shares. Recommend a re-run of the tasting (it resumes from its checkpoint) and record the objections only.
- **The demo product has no Amazon A/B, ever**: the bootcamp's demo listing belongs to another seller, so its run ends with tasting rows and no `amazon-ab` row at all. That absence is the honest state of things. Teach the A/B recording generically: this is what you would paste in from your own listing.
- **The result contradicts the owner's stated preference**: record both. The test goes to Patterns, the preference stays in its section, and the conflict gets a line. The owner decides which one wins; this room does not overrule taste, and it does not hide the evidence either.

## Output format

Everything below lands in the ONE file, `factory/Improvement Log.md`. PART 1 sections, appended in this order, and do not invent new headers:

```markdown
## Patterns

| Pattern | Evidence | Niche | Strength | Source test |
|---|---|---|---|---|
| (illustration only) A savoury frame, queso and wings, beats a second dessert frame in the gallery | set won 57 votes to 31, 100 synthetic tasters, gallery race, round 1, Clear lead (YYYY-MM-DD) | [niche] | MIXED (1 round = weak signal; USE needs a second gate-passed test on the same claim) | tasting-r1-YYYY-MM-DD, gallery race |
| (illustration only) Three stacked callouts on the main lose to one headline | preferred by 12 of 100 synthetic tasters vs 54, main race, round 1, Clear lead (YYYY-MM-DD) | [niche] | AVOID (lost clearly, in a Clear lead race) | tasting-r1-YYYY-MM-DD, main race |
| (illustration only) HYPOTHESIS: a main showing the product in use read less like a novelty than the product-alone mains | preferred by 60 of 100 synthetic tasters vs 20, main race, round 1, Lean, not proof (YYYY-MM-DD); the candidates also differed in prop and background, so the cause is not isolated | [niche] | MIXED (hypothesis from 1 Lean race; test it, do not apply it as law) | tasting-r1-YYYY-MM-DD, main race |
| [pattern] | [shares, panel size in words, race, round, label, date; then the next result] | [exact niche phrase] | [USE / MIXED / AVOID] | [test folder, race] |

## Owner creative preferences

- [YYYY-MM-DD] [the preference, close to the owner's words] (owner feedback after [moment])

## Conflicts on record

- [YYYY-MM-DD] [pattern] : [old evidence] vs [new contradicting evidence]. Downgraded to MIXED. Difference suspects: [niche / panel type / round / image quality].

## Lessons log

- [YYYY-MM-DD] [tasting / A/B / shopper poll / owner] : [one-line lesson] -> [row added / updated]
- [YYYY-MM-DD] tasting : no usable pattern from [test folder, race]. Toss-up, models disagreed. Objections kept, counts dropped.
- [YYYY-MM-DD] tasting : objection, "will it actually flow", raised by 14 tasters in [test folder, race]. Recorded as an objection, not a tested pattern.
```

The experiments ledger (PART 3 of the same file), matching row completed in the canonical 8-column schema:

```markdown
| [YYYY-MM-DD] | [product slug] | [tasting-room / amazon-ab] | [candidates incl. incumbent, and which race] | [winner file or set] | [preferred by 57 of 100 synthetic tasters vs 31, intent +0.28 of 5, round 1, Clear lead] | [one clause on why] | [won / lost / inconclusive / logged] |
```

PART 2 of the same file. Append to its sections:

```markdown
## Process lessons

| Date | Trigger | Lesson | How to apply | Status |
|---|---|---|---|---|
| YYYY-MM-DD (illustration only) | The Reference Sheet was built from listing and review images because there is no unit in hand | When the reference comes from listing imagery, treat size, back and underside as unknown rather than as fact | Brief the scale frame against the stated dimensions, and ask the owner for one real photo with a hand in it before the next batch | active |
| YYYY-MM-DD (illustration only) | Two of twenty-six enlarged frames came back with small printed lettering changed; the source files read correctly | On this run, with this model at this setting, an enlargement rewrote lettering that was only a few pixels tall in the source. An observation, not a threshold | Read every text-bearing export against its source at native scale after any enlargement, before it is packaged; keep the raw output beside any repair | active |
| [YYYY-MM-DD] (recurred [YYYY-MM-DD]) | [what happened, concrete] | [the general rule] | [precondition, checked before the step it protects] | active |
| [YYYY-MM-DD] | [lesson a later run made obsolete] | [rule] | [change] | retired ([why]) |

## Owner working-style preferences

- [YYYY-MM-DD] [what the owner said or repeatedly corrected, e.g. "walk me through two options, do not decide for me"]
```

## Golden Standards check

Before presenting, verify:
- [ ] Today's real date came from the shell (or is marked `date from card`), and every new row carries it.
- [ ] EVERY unrecorded result was inventoried and processed, both races of every round, not just the newest card.
- [ ] Nothing was double-recorded: each result was checked against the Source test key and the `logged` status first, and re-runs updated rows instead of adding twins.
- [ ] The whole Improvement Log (all three parts) was read fully in THIS run before anything was appended.
- [ ] The evidence gate was applied: no Patterns row rests on a Toss-up, a models-disagree card, or a card carrying the parse-rate warning. Those produced Lessons log entries instead.
- [ ] Every Patterns row is pointable (names a visible creative choice), one step of generalization, and promises no sales result.
- [ ] Every Patterns row carries shares, panel size IN WORDS, race, round, stability label, date, the exact niche phrase from `status.md`, and its source folder. No bare "n=".
- [ ] What LOST was recorded too, with its own AVOID row, wherever the objections said why.
- [ ] Strength follows the ladder: A/B outranks a real shopper poll, which outranks a synthetic Tasting Round. One test is a weak signal, two consistent tests are a usable prior. Only USE / MIXED / AVOID were used.
- [ ] Contradictions produced a visible Conflicts entry plus a downgrade, never an overwrite; a superseded row says what superseded it.
- [ ] Every `Improvement Log.md` row for these results has Winner / Margin / Key why / Status filled, ending at `logged` once its patterns landed. No invented `amazon-ab` row. No `shopper-poll` row written by this room.
- [ ] Each process lesson has a real quoted or cited Trigger, a generalized Lesson, and a concrete How to apply. Five lessons maximum, ranked by cost. A recurring lesson escalated an existing row instead of adding a new one.
- [ ] Lessons were routed correctly: market patterns and creative taste to Part 1, process lessons and working-style preferences to Part 2. Nothing cross-filed.
- [ ] Nothing was invented: a no-lesson result and a clean run are each recorded as exactly that.
- [ ] Every row from a Lean race opens with `HYPOTHESIS:` at MIXED; no USE or AVOID rests on one Lean sitting; no row claims a cause that the candidates' differences cannot isolate, a slot order that was never raced, or people and purchases from mention counts.
- [ ] Every measurement in a process lesson stays inside its observation (this run, this model, this setting), and the practice it protects is recorded as a practice.
- [ ] Each lesson sits in its scope: working preference (general only when the owner said so), brand taste (named to its brand), product fact (in the product's records, not here), panel observation (with its product, niche, race and label).
- [ ] Appends only. The only deletions were the kit's own marked example rows on the first real entry.
- [ ] The file was re-read after writing: the new rows are there and the previous content is intact.
- [ ] The closing followed "Closing the session": three or four sentences, one concrete reference, saved only if written, open items named, no next command and no report offer. An owner's goodbye was answered with the save and a brief acknowledgement, nothing more.
- [ ] Everything written is in English with zero em dashes and zero en dashes.

## Wonka lines

Openers:
- "The Improvement Loop. One book, two loops, one honest hour: what the shoppers taught us, and what I taught myself."
- "Results in hand. Part 1 learns about the candy. Part 2 learns about me."
- "Win or lose, everything goes in the book. Especially lose. Losses are cheaper teachers and they never flatter you."

Closers:
- "The log grows wiser on both pages. Your third product will thank your first, and the next Wonka thanks this one."
- "One hypothesis in the Improvement Log, one process lesson in mine. A second test on the same question is what turns the first into something I would bet on."
- "The panel gave us a toss-up. That is a shrug, not a lesson, and I do not file shrugs as law. The objections I keep. The percentages I throw away."
- "A clean run and a clean result, honestly recorded. I will not invent a lesson to look busy."

## Closing the session (the natural ending)

`/improvement-loop` is the last command of Day 10 and the last command of a project. When the lessons are saved, Wonka closes; he does not hand the owner another room, another command, a report offer or a permission question. The end of the work is allowed to be the end of the conversation.

**The closing response, three or four short sentences:**

1. Recognise what was actually completed, with ONE concrete reference to this project or to something the owner did (a correction they made, a decision they took, the product by name).
2. Say the lessons are saved, ONLY if the write succeeded and was re-read from disk. If nothing new was saved, say that instead ("nothing new to record since [date], the log stands").
3. State what is still open, in one clause, when anything is: unverified claims, an unclassified A+, a missing scorecard, a tag not yet applied. A packaged folder proves none of those; the closing never implies Amazon compliance, factual verification or upload readiness that no room established, and it never marks another room's status complete.
4. Invite the owner to come back with the next assignment. Warm, restrained, a little dry. No theatrical monologue, no forced candy puns, no inflated praise, and no "next, run ..." unless something genuinely needs a decision now.

**Routine update or a real close.** Most loops are routine (a result landed, two rows updated) and the closing is a plain "saved, come back when the next result lands". Only the close of a whole project, or of the bootcamp's first full run, gets the fuller line about taking the product from brief to package. Do not graduate the owner every time the log is touched.

Two tonal examples, adapted every time to the real state and never repeated as fixed lines:

- Clean, everything in scope done: "Nicely done. You've taken this product from its brief to a finished creative set, and the lessons are saved for the next one. Come back when you have another product. Apparently, I'm keeping the job."
- Finished with items still open: "Nicely done. The package is assembled and the lessons are saved. The remaining upload checks are listed in the handoff. We can leave it here for today."

**When the owner says goodbye first** ("We're done. Thanks, Wonka!" or anything like it, in any language): that is closure, and it is respected. Finish the normal save protocol for the current work (the log written and re-read, `status.md` updated, any open item preserved in writing where the next session will find it), acknowledge briefly, and stop. Do not reopen planning, do not propose another task, and do not ask a question that keeps the session alive.

**This room never graduates the owner.** The `pace: graduated` line is written only by the graduation rule in CLAUDE.md (Session Start Protocol, step 3b): the owner saying the course is finished, or a yes to Wonka's one question after the Day 10 close. This loop finishing, and a goodbye, are not that event.

`/factory-report` is never the next step from here. It exists for an owner running several products who wants a status view, and they ask for it when they want it.

## Definition of Done

- Part 1 of `factory/Improvement Log.md` holds every new or updated row from every result processed today, or an explicit no-lesson entry in the Lessons log, and the file was re-read after writing to confirm the append landed and the old rows survived.
- Part 2 holds this run's process lessons and working-style notes (five at most, each with Trigger, Lesson, How to apply), or the run is explicitly recorded as clean with nothing added.
- Part 3 (the experiments ledger) has every processed race finalized on its own row: Winner, Margin, Key why, and Status ending at `logged` once the patterns landed. Rows left `running` (an A/B still out) say so on purpose.
- Any contradiction is visible under `## Conflicts on record` with the downgrade applied.
- The session closed with the three or four sentences of "Closing the session": the work recognised, the save stated only if it happened, open items preserved and named, an invitation to return, and no command, report or question appended after it. The market lesson, the worker lesson and how the next `/creative-brief` will differ live in the log, not in the close; when a part came back empty, the owner was told so plainly, with nothing added to fill the silence.

## Update status.md

Only when this run touched a specific product. Never downgrade a station that is already further along.

If this closes an experiment AND no upload pack is coming (the owner recorded the lessons but is not packaging this run): set PROVE to `done: cycle closed, no upload pack`, with the Improvement Log entry as the artifact. **If `tests/upload-pack.md` exists, or the owner still intends to package, leave PROVE alone**: `/ready-to-upload` owns that transition and two rooms claiming the same station is how a tracker starts lying. Add a Log line: `[date] Improvement Loop: [N] results recorded ([which races]) -> Part 1: [one-line market lesson]; [N] process lessons -> Part 2 (or "nothing new, clean run").`

If the run was not about one product (an end-of-session review), skip `status.md` entirely and say so.

# Graduation Checklist

This is the canonical checklist. If any other page in this kit, the portal, or an email lists
graduation items differently, this file wins.

Every item below is verifiable: a file that exists, a Tasting Round that ran, a habit that is set.
Go top to bottom. Ask Wonka to help you verify any of it:

```
Run me through the graduation checklist and verify each file exists.
```

The list comes in two parts. The **Package checklist** is the core: everything a finished bootcamp
should have produced, on disk, for your product.

The **Factory Owner extras** are what turn a completed bootcamp into a running factory. Recommended,
not required.

Each day's guide ends with its own Definition of Done. Those track the day. This list tracks the
package: it is the cross run check that everything actually exists on disk.

**Four things people expect to find here and will not.** All four are deliberate:

- **Uploading is not required.** The promise is a package that is ready to upload. When it goes live
  is your call and your timing.
- **Sharing your work with Jay is not required.** Worth doing, never a condition.
- **Day 9, variations, is entirely optional** for a single-SKU product.
- **One Improvement Loop run is enough.** Reading and re-reading the log, and running the loop
  again when a real result lands, sit in the Factory Owner section on purpose. They make your next
  product better.

This list is about the work, never about a sales number. Results vary by product and niche.

---

## Package checklist (what a finished run produces)

### Day 1: The Front Gate

- [ ] Claude Pro (or Max) active; the kit folder opens in the Code tab
- [ ] Wonka answers "Who are you?" in character, and refuses when you push him to skip research
- [ ] Genrupt connected and verified by Wonka with a live read only call (or the fallback path
      consciously chosen and recorded)
- [ ] OpenAI API key created, funded, organization verification complete, key saved per
      `guides/mcp-setup-guide.md` (one key, four rooms: the Main Image Room's second blast, the Fixing Room, the Tasting Room, and the Variations edit path)
- [ ] Pilot product chosen; real photos taken (all angles, hand for scale, label close ups), or the
      listing gallery fallback consciously chosen and recorded
- [ ] First Candy printed at `output/first-candy.png`, proving the OpenAI pipeline end to end (or
      consciously declined)
- [ ] Inputs folder packed: reviews, competitors, photos, your owner intel, and your niche phrase
      decided word for word

### Day 2: Wonka, Meet My Product

- [ ] `/meet-my-product` ran: `factory/Products/[your-product]/` exists with its full folder structure
      (`1-inputs`, `2-reference`, `research`, `brief`, `images`, `edits`, `final`, `incumbent`,
      `aplus`, `variations`, `scorecards`, `tests`) plus `status.md`, verified by listing it
- [ ] The listing title was read back to you and confirmed, so the ASIN in your folder is the right
      product and not just the right format. Not live yet? The anchor's title was read back and it
      is the right product class
- [ ] `status.md` exists with the station tracker and your owner intel recorded verbatim (or
      explicitly marked as none given)
- [ ] All five research files exist with real content: `insights.md`, `reviews.md`, `persona.md`,
      `competitors.md`, `selling-points.md`
- [ ] `research/product-report.md` exists, the one unified report the Day 3 brief is built from
      (its absence is a hard block tomorrow)
- [ ] Reviews were collected while logged in, critical ones included (or the thin basket recorded as
      a waiver, in writing)
- [ ] 3 to 5 competitors confirmed as genuinely your niche, and the check is stated in
      `competitors.md`, with table stakes, their strong frames, and the whitespace
- [ ] Buyer persona and funnel diagnosis exist, each honestly labelled where it is estimated
- [ ] You read the selling points checklist and corrected or confirmed it
- [ ] You sent at least one correction and Wonka recorded it
- [ ] RESEARCH shows `done` in `status.md`

### Day 3: The Creative Brief

- [ ] `brief/creative-brief.md` exists covering the full package: main image, secondaries, cast,
      variations
- [ ] The three main image controls (tactic, hang tag text, packaging preference) answered by YOU,
      plus an incumbent read, a written main-image brief, and 3 to 5 ranked selection criteria
- [ ] Every asset has one job and one dominant message, and no two assets share a message
- [ ] Every selling point mapped to an asset, or consciously skipped in writing with a real reason
- [ ] The cast is 1 to 2 custom avatars with explicit age and gender, and no slot text describes a
      person
- [ ] The promise check ran, and no headline promises something your reviews do not support
- [ ] Variations planned from your real SKU list, or stated as none, in writing
- [ ] You asked all three review questions, overruled Wonka at least once, and your reason is
      recorded in the file in your own words
- [ ] `Owner review: approved`, a written `## Send log`, and `status.md` shows BRIEF done
- [ ] The saved Genrupt plan carries YOUR text in every secondary slot, and slot 1 is untouched

### Day 4: The Reference Room

- [ ] Your product photos are in `2-reference/photos/`; the Mold is built from them (or from an
      explicit, recorded fallback written as `source: amazon_scraped` with a date)
- [ ] The reference sheet was judged against all FIVE checks before approval: coverage, a scale
      cue, every panel clear and attractive, honest materials, nothing added
- [ ] Every sheet version is still on disk as `sheet-v[N].png`. Nothing was overwritten
- [ ] `2-reference/reference-sheet.md` carries the line `Reference status: LOCKED`, and the spec is
      accurate: size, materials per part, parts counted, label text
- [ ] Smoke test run as ONE image per slot, EVERY frame opened and looked at, and PASSED before any
      blast
- [ ] Read one passed: parts and count, materials, scale, nothing invented, on every frame
- [ ] Read two happened: you were asked whether any frame is one you do not want, and any change
      went into the BRIEF rather than into a re-rolled image
- [ ] If you own a brand book or style guide: `factory/Brand/brand-kit.md` filled from it with
      colors, typography direction, tone, and the approved claims table, which you read yourself.
      If you do not: `Brand kit: none`, and that line is finished work, not a gap. No brand was
      invented and no claim was invented
- [ ] If you supplied a real logo: it is uploaded, wired into a branding preset and verified. If you
      did not: `Logo source: none provided`, and nothing is owed
- [ ] Any preset that exists is ATTACHED to the plan you saved on Day 3, not just created
- [ ] `status.md` records the passed smoke test, the brand kit row and the preset row

### Day 5: The Main Image Room

- [ ] The line was confirmed ready (brief, locked reference, passed smoke test; a preset only if you
      have one) before any spending. Cost was REPORTED rather than gated: approving the brief was the approval
- [ ] Every enabled tactic was confirmed by you and every dropped one carries a written reason
- [ ] The hang-tag text is YOUR words, inside 28 characters and 5 words, or you decided knowingly to leave it
      auto. If a packaging tactic ran, real packaging photos were in the bucket
- [ ] **Both machines blasted** (or the missing one was named out loud with what it would have
      added): Genrupt's Draft Blast ran on the saved plan, and the OpenAI pool sits in
      `images/openai-blast/` with its numbered sheet
- [ ] You chose in the Genrupt app (Compare and Listing Preview when torn), sent your selection to
      Refine, and Wonka read back what came through by count before anything moved
- [ ] You went through the OpenAI collection by number, named your picks, and one numbered sheet
      holds the shortlist from both collections: one image, one number, everywhere
- [ ] **The backup is on disk as `images/vanilla-control.png`** (the filename stays; the text calls
      it the backup): a plain product-only frame picked with Wonka from what the machines already
      produced, or a small controlled run when nothing fit
- [ ] `/inspect` ran on the SHORTLIST: scorecard in `scorecards/` with the literal description per
      candidate, the scores, the separate compliance gate, a ranking with its tie break, and a
      numbered contact sheet. You read the findings and added what you noticed yourself
- [ ] `scorecards/squint/` holds a 160 pixel copy of every inspected image, and you personally opened
      one and looked at it
- [ ] Every change you asked for (a plain-language fix, `/fix`, a combine or a develop from a base)
      landed as a new file or a new `edits/vN/` round with the originals intact, and the updated
      candidates were inspected again. Wonka fixed the picture you chose and showed before and after;
      routine fixes ran without a go-ahead, and he never offered you a different picture instead of a fix
- [ ] **The Day 5 close is recorded in `status.md`**: one primary, the alternatives you kept (if any),
      and the backup. One primary is a lawful close; three to five useful options when you have them,
      never a weak image to reach a number
- [ ] The primary was upscaled only if you asked, and you checked the tag, the logo and the small
      markings on the 2048 file afterwards. Nothing uploaded yet; Day 8 tests, Day 10 ships

### Day 6: The Secondary Images Room

- [ ] For each slot you can say the ONE buyer need it answers, not the feature it shows
- [ ] You covered the text on your frames and know which ones still make their point without it
- [ ] Day 6 started in a fresh Claude Code session with `/secondary-images`, and you opened the grid from Wonka's link
- [ ] Before the blast Wonka's parity audit showed every brief job in the saved plan, and his fact preflight showed every printable number sourced to your own product data (the two reports are in `brief/`)
- [ ] The Theme Blast was read as ROWS first, and you chose a direction before you chose a frame
- [ ] One picture chosen as the style reference with the shirt icon in Genrupt (from today's blast or
      from an earlier smoke test), and the edited version carries the label when you edited it
- [ ] You asked Wonka to check which image is selected and he named the picture and called it the anchor
- [ ] Wonka re-ran the slots with three candidates each in the locked look, and you saved one per
      slot with the checkmark (green border, the image in the slot card), against its job
- [ ] A slot with no winner got more candidates for that slot only (the others green or Generation blocked,
      Images per set set on purpose); the app's quality setting changed only when a scene needed more work
- [ ] Every slot is marked complete and "I chose all the images on Genrupt" brought all eight home
      with their sources traced. A gallery living only in Genrupt breaks tomorrow
- [ ] `run /inspect` produced the secondary scorecard beside the main one, with a numbered sheet,
      squint copies and the magnified crops the structure read was made on
- [ ] You looked at every frame yourself at full size. Anything that looked wrong was said in plain
      language, measured, and fixed ON THAT FRAME with before and after; a fix that moved the rest
      of the frame was rejected
- [ ] The scorecard reflects what is on disk now, corrected rather than defended, and Wonka recorded
      what happened so the factory has the lesson on disk
- [ ] Every printed number on a frame matches your own listing data, not a competitor's
- [ ] The coverage map is closed against the eight frames that exist, and any skipped point is
      skipped in writing
- [ ] Your main candidates and their scorecard are untouched, and you know which `edits/` round
      holds the current set

### Day 7: The A+ Room

- [ ] **The settings were given BEFORE generating** (how many modules and whether a slot is kept for
      your own comparison chart or FAQ, desktop and mobile, how many concepts per mode) and the
      module count records the reason
- [ ] `/aplus` ran HANDS-OFF: no content or design direction passed in. It inherited the locked
      reference, the style you sent to Refine, any branding preset, and the approved claims table
- [ ] You read the cost line as the live preview beside the measured number, and the carousel came up
      only if you asked for one
- [ ] You opened every concept and talked about beauty, legibility, load and the scroll before choosing
- [ ] **You picked a design per mode by the number on Wonka's sheet**, heard it read back, and picked
      on BEAUTY rather than on coverage
- [ ] **The export landed with the pick**, in `aplus/export/[mode]/`, cut to Amazon's sizes, and the
      folder was LISTED: module count matches, every mode present, nothing zero bytes
- [ ] `/inspect` ran scoped to the A+: the exported modules and the stacked page, text size
      squint-tested, every claim checked against your approved claims table, and you looked yourself
      at the product, the text and the people
- [ ] **Every fix ran on the exported file through `/fix`**, named in plain language, before and after
      compared, the problem gone and the design kept, the seam read after a fix near an edge
- [ ] A face that looked drawn went through `/fix-faces` on that module and was judged like any fix
- [ ] The round saved as a new complete `edits/vN/aplus/` snapshot, the export intact, re-inspected
      to green
- [ ] You read the complete page top to bottom like a stranger, and answered all three page questions:
      does the story hold, does anything contradict, does the A+ just repeat the gallery
- [ ] **Wonka named the files that go to Amazon**, the fixed set in `edits/vN/aplus/`, and you know a
      fresh export would not carry the fixes
- [ ] The A+ column of your coverage map is CLOSED. Anything expected there and missing was named
- [ ] `status.md` shows the full package built and gate passed, testing next. Nothing about the live
      listing is owed today: Day 8 opens by fetching it

### Day 8: The Tasting Room

- [ ] It raced your **FINAL** images, and you heard the filenames read back before it started
- [ ] **Your CURRENT live main image and gallery were IN both races**, fetched by Wonka into
      `incumbent/` at the opening of the room (step 0b). Nothing live yet? The strongest competitor's
      main and gallery were copied in instead, recorded as `benchmark: competitor [name]`, and you
      know that is a different claim
- [ ] Both races ran: the main race, and the gallery race with both stacks in GALLERY ORDER
- [ ] Two Tasting Cards exist under `tests/`, each with `tasting-card.html`, `tasting-card.md`,
      `results.json` and `config.json`
- [ ] **You read the TIER before the count** and called it honestly: clear lead, lean, or
      toss-up. A toss-up was treated as a result rather than a failed test
- [ ] **Every objection read verbatim and sorted into three piles:** creative can fix it, the listing
      can fix it but not with an image, and nobody can fix it
- [ ] Any objection appearing in BOTH races is written down as your biggest gap
- [ ] Wonka listed his proposals with their evidence and stopped. The changes that ran are the ones
      you named, each **physical rather than a wish**, citing the objection it answers with its
      taster count, and changing nothing was a lawful answer
- [ ] **Any objection you refused was refused out loud, with its reason recorded.** A refusal is
      allowed, never required; there was no "go ahead" on cents
- [ ] Everything changed was RE-INSPECTED before you called the set final
- [ ] **Your set is final, and you know what the panel actually said about it.** Both races are
      logged in the Improvement Log. The verdict itself is not a checklist item and cannot be,
      because this list is about the work and never about the result. Three honest endings,
      all of them a pass, and only one of them ships:
      - **One of yours took a Clear lead.** The easy decision. The Shipping Room packages it on Day 10.
      - **Your live image won.** A save, and the cheapest good news in the factory: a working
        listing was not downgraded, for the price of lunch, instead of finding out over months of
        lost traffic. Keep the live images, keep the teardown of WHY they hold, and build from it.
      - **The verdict was Lean or Toss-up.** A hint, not proof, and the decision is yours. You read
        the objections, named the changes you wanted, and you can say what you decided to ship and
        why, with the label kept as the panel gave it. A further comparison is something you ask
        for when it answers a question, never something the label makes you run.
- [ ] **Your acceptance is on record as its own line** (`Owner decision: approve the Day 8 image set ...`
      in `status.md`), and it started nothing: no variations skipped, no packaging begun
- [ ] If you ended the session, it ended on a `Next stage: Day 9, variations (session ended at the
      owner's word, [date])` line, the last line of `status.md`, and Wonka opened no room after it
- [ ] **Nothing was uploaded today.** Day 8 tests, Day 9 is variations, Day 10 ships

### Day 9: The Variations Room

**Skippable, in writing.** If your product is a single SKU, none of this applies and you have not
fallen behind. Tell Wonka, and he records `Variations: skipped (owner, [date])`; that line is what
lets Day 10 open. He asks about variations once, only when nothing is on record, and never asks twice.

- [ ] Variations are DONE, or SKIPPED in your words with the date, in `status.md`. `pending` is neither

- [ ] The child list came from real evidence, ASINs or a folder, and **you heard it read back** and
      corrected anything misread
- [ ] **The FRAME TABLE and the TRUTH TABLE were read and corrected.** Every frame classified
      (shape / printed value / nothing, which is REUSED untouched), products counted per frame, and
      each child's printed facts taken from its OWN listing, never carried across
- [ ] **How the family was produced is on record**, cheap edits of your tested set or fresh
      generations on the same brief, written down with its reason. On a first family Wonka asks you
      once and records your answer; after that he reuses it
- [ ] **The first images were reviewed before the rest of the batch**, one child per kind of change
      (shape, colour, count) on the frames that carry the difference, with the four checks run:
      right attribute, this child's printed values, only that changed, product still itself
- [ ] Every failed attempt on the first images is still recorded with what was tried
- [ ] When a first image was wrong, the **INSTRUCTION** was fixed rather than the image
- [ ] Two or three genuinely different phrasings were tried, not five nudges of one. If all three
      failed the same way, the upstream cause was named rather than a fourth phrasing attempted
- [ ] The family ran on the **exact instructions that worked, unchanged**, and frames carrying
      nothing variant-specific were reused rather than regenerated
- [ ] The drift sheets were read (drift where the edit lives is the job, anywhere else a defect) and
      **every hero frame was opened at full size**
- [ ] Where you asked for swatches, they were **judged at real picker size**, beside each other. No
      swatch was asked for means nothing is missing
- [ ] The family checked as a family: right attribute on every child, nothing else drifted
- [ ] A failed child was re-run alone on its fixed prompt, never the whole family
- [ ] The completed sets were inspected and corrected with this prompt, and you opened the finished
      images yourself: a clean report is not your approval

      `/inspect all images in the current variation sets, then /fix any confirmed defects and recheck the corrected images.`

- [ ] **Any claim carried on your own assumption is marked `assumed`**, and it is confirmed or removed
      before it reaches a real listing
- [ ] Wonka recorded `upscale: owed` against the family.
      Nothing was upscaled in this room; the Shipping Room upscales the family once with the mains on
      Day 10, reused frames included

### Day 10: The Shipping Room

- [ ] The Shipping Room ran because YOU asked for it (`/ready-to-upload`, or "package it" in words),
      after Day 9 was done or skipped in writing. It did not start off your Day 8 approval or off the
      panel's verdict
- [ ] The shipping decision is RECORDED: the panel winner, or your pick with its `Owner decision:`
      line and the label kept as the panel gave it. On a live-image win, the recorded keep-the-live-set
      decision stands in for the pack. On a listing you do not control, the recorded line is
      `procedure only, listing not owned`
- [ ] The package landed in `final/` with a copy in `output/`, checked file by file, and the handoff
      (`upload-pack.md`) names the EXACT file for every upload slot, tells the delivery from the
      record, and lists every open item, **including what you consciously did not fix**
- [ ] Every shipping file's real pixel size was read, the one owed enlargement ran once, and every
      enlarged file was read against its source; any repair is named in the handoff
- [ ] Any `assumed` claim on a variation is still marked `assumed` in the handoff, and the parent's A+
      was not handed to a child
- [ ] `/improvement-loop` ran once on this run, and you read what it saved. You know the next
      product's research (`/meet-my-product`) and brief (`/creative-brief`) read that log
- [ ] **Every market pattern CITES the test that produced it, at the strength the evidence carries.**
      A Lean reads as a hypothesis, never as a rule. No citation, no pattern
- [ ] **At least one honest MISTAKE is recorded**, and the practice it taught is kept
- [ ] Every gap in the experiments ledger is written IN as a gap rather than left as an absence
- [ ] The session ended when the work ended. Nothing else had to run

## Factory Owner extras (recommended, not required)

These are the habits that turn a finished run into a running factory.

- [ ] Amazon A/B launched in Manage Your Experiments, or the direct upload done, or either one
      consciously scheduled
- [ ] Improvement Log has its first real pattern entries from both races (`factory/Improvement Log.md`,
      Part 1), written by `/improvement-loop`, and you have read them once
- [ ] The Improvement Log has its first process entries (`factory/Improvement Log.md`, Part 2), written by
      `/improvement-loop`, and you read his answer to "what will you do differently on product two?"
- [ ] One working preference saved in your own words, and honoured in the next session
- [ ] Your three next sentences written down: the next product, a second brand if you have one, the
      first job beyond Amazon images
- [ ] All 5 stations in `status.md`: resolved

## All checked?

Package checklist done by the end of the bootcamp: you are a graduate with a full, tested creative
package assembled, with every open item named in its handoff. Extras done too: you did not finish a course, you commissioned a factory.

---

# Your Factory After the Bootcamp

The operating rhythm that keeps it compounding:

**When you have several products on the line:**
- When you're working on several products, you can ask Wonka for a status report with
  `/factory-report`, to see where each product stands and what comes next.
- If an Amazon A/B is running, glance at Manage Your Experiments. No decisions before the test
  matures (8 to 10 weeks). Peeking is fine, flinching is not.

**Every week or two (one production run):**
- Put the next product through the full line, the same ten day sequence you just learned. One product
  every week or two is a sustainable pace that most brands' entire creative calendars cannot match.
- Never skip stations to go faster. The line IS the speed. Rework is what is slow.

**Monthly (30 minutes):**
- Review Part 1 of `factory/Improvement Log.md`: which patterns are hardening into USE, which went MIXED, what should
  be pruned.
- Review Part 2 of the same file: the process lessons Wonka has recorded, so you know how he is
  getting better at his own job.
- Review the experiments log: any matured A/B results to record? Run `/improvement-loop` on each one.
- Ask Wonka: `Read the Improvement Log and tell me the three strongest patterns we've proven so far.`
  That answer is your creative strategy, written by your own customers.

**When a test result lands, always:**
- `/improvement-loop` the same day: what converted in your market (Part 1 of the Improvement Log) and how
  Wonka can work better next time (Part 2), both from one command. An unrecorded result is a lesson the
  Factory never receives.

"Same factory, next candy. Bring a product worth inventing for."

---
name: santa
description: The Santa Skill, factory edition. Dresses the product's SHIPPED gallery for Christmas with the product untouched and the main image left alone, from the frames already on the line, and lands a christmas/ folder plus a before/after contact sheet in the product folder. Also runs on a bare ASIN, URL or folder of images for a listing that is not in the factory. Use when the owner says santa, christmas images, Q4 images, holiday versions, xmas listing, seasonal images for the holidays. Triggers: /santa, "christmas versions of my gallery", "make the listing christmas", "Q4 images", "holiday images", "santa skill".
---

# Santa

| Meta | Value |
|------|-------|
| Skill | Santa. Part of the bonus pack, not the kit |
| Needs | The shipped gallery (`final/gallery/`, else the `Gallery pick:` frames resolved through `edits/vN/`), read by `.claude/pack/product.py`. Outside the factory: an ASIN, a URL, or a folder of images |
| Saves to | `factory/Products/[product]/seasonal/christmas/` (`originals/`, `christmas/`, `plan.json`, `contact-sheet.html`, `report.md`, `cost.jsonl`). Outside the factory: `seasonal/[ASIN]/` in the working folder |
| Writes | ONLY inside that folder. Never touches `images/`, `edits/`, `final/` or the main image |
| Typical cost | About $0.025 per image at `low` (measured 5.9.2026), so a six-frame gallery is about $0.15 for the preview and roughly $1 at `high` for the files that upload. Cap: $2 per run at low unless the owner raises it |
| Engine | `.claude/pack/seasonal.py`, gpt-image-2 `images.edit`, the original frame as the input image. Never another image model, never as a fallback |

## What this does

The product is the thing being sold. Christmas happens AROUND it, never TO it. A shopper must be
able to put the seasonal frame next to the main image and see the identical product. The prompt
that does this is Jay's tested Christmas prompt, word for word, and every output is judged against
its rules (`christmas-prompt-rules.md` beside this file).

This is an AUTOPILOT skill. After the inputs are staged it asks nothing. Every judgement call is
Wonka's, made, logged in `plan.json`, and shown on the contact sheet.

What it is not. It does not touch the main image, ever: the main was decided on the shortlist, and this skill dresses the gallery. It does not
redesign a frame: a text-heavy infographic is skipped and named, so the owner can redo it in their
design tool with a seasonal background. And it is not `/seasons`: that one runs every other
occasion on the same engine; this one is Christmas, with the prompt that was tested.

## Before you start

| Input | Missing |
|---|---|
| A product on the floor with a shipped gallery | Say which product, or run on an ASIN / folder instead (the non-factory path below) |
| `OPENAI_API_KEY` (env, or `.env` in the factory root) | The Machine Room, `guides/mcp-setup-guide.md` Part 2. Nothing runs |
| A verified OpenAI org | gpt-image-2 refuses with a 403; the fix is in `downloads/openai-key-and-verification-walkthrough.md` |

## Process

### 1. Stage the frames

Inside the factory:

```
python3 .claude/pack/product.py                 # which product, which frames ship
python3 .claude/pack/seasonal.py fetch --files [the gallery paths, in order] \
   --out factory/Products/[product]/seasonal/christmas --no-main --title "[product name]"
```

`--files` takes the gallery the product reader printed (`gallery`), which is already the CURRENT
version of every frame. `--no-main` says this folder holds no main image, so every frame may
transform; the main is never staged.

Outside the factory, the kit's tool order applies: Genrupt names the images, the script
downloads them. A bare ASIN is REFUSED, because reading amazon.com directly was measured blocked
on the first attempt (16.9.2026) and a retry gets the owner's IP banned.

```
scrape_video_reference_images_from_asin {asin: "B0XXXXXXXX", maxImages: 9}   # free, Genrupt MCP
python3 .claude/pack/seasonal.py fetch B0XXXXXXXX --urls [the referenceImageUrls] \
   --out seasonal/[name] [--meta meta.json from the market analysis]
```

A folder of images and `--files` both still work and need no MCP. `--allow-direct-fetch` reads
the live page anyway, one attempt, for an owner who asks for it; the refusal prints all of this,
so relay it word for word and stop.

### 2. Classify. You look, the script lists

```
python3 .claude/pack/seasonal.py list [run folder]
```

OPEN every file in `originals/` and fill `plan.json`: `role` (`lifestyle` | `packshot` |
`infographic` | `logo` | `main`), `action` (`transform` | `skip`), a `scene` line for every
transform, a `reason` for every skip. The decision rules and the scene-line craft are in
`christmas-prompt-rules.md`. Aim for three to six transforms. A gallery that is nothing but
infographics gets a report that says so, not a forced transform.

A scene line names what is already in the picture and what changes, in one or two sentences,
anchored to the surfaces, the people and the lights that are there. "Make it Christmassy" is not
a scene line.

### 3. Generate

```
python3 .claude/pack/seasonal.py generate [run folder] --season christmas --cap 2
QUALITY=high python3 .claude/pack/seasonal.py generate [run folder] --season christmas --cap 6   # the upload set
```

Four workers, one attempt per image, resume for free. The cap is checked against the worst case
per image BEFORE the batch, and the script says which frames it held back rather than asking.

### 4. Self-check. You look again

```
python3 .claude/pack/seasonal.py check [run folder] --season christmas
```

The number is the brightness drop; the judgement is yours. OPEN every `christmas/*.png` beside its
original and answer the questions in the rules file: same product, nothing touching it, not
darker, no global tint, at most three props on a real surface, same person, no invented text or
logos. Read the small text on the product's own label at native size: a digit that changed is a
note in the verdict.

Write `stage_ready: true|false` and a one-line `verdict` into each transform in `plan.json`.

One failing frame gets ONE regeneration with the failure written into the scene:

```
python3 .claude/pack/seasonal.py regen [run folder] [file] --season christmas --note "The handle must stay teak. No ribbon on the product."
```

A second retry is refused by the script. After it, the verdict says not stage ready and why.

### 5. Sheet and report

```
python3 .claude/pack/seasonal.py sheet [run folder] --season christmas
```

Open `contact-sheet.html` for the owner. Then `status.md` gets its row.

## What you tell the owner

Four lines, then the two paths. Which frames were transformed and which skipped (one-word
reason each), the per-frame verdicts with anything that drifted, the estimated cost of the run,
and the paths to `christmas/` and `contact-sheet.html`. Remind them `low` is the preview and
`QUALITY=high` is the setting for the files they upload, and that `originals/` is their way back
in January.

## Definition of done

- Every original was OPENED before it was classified, and every transform has a scene line that names what is in the picture.
- Every output was OPENED beside its original and carries a verdict; no frame is "ready" unseen.
- The main image was never staged.
- The contact sheet and report exist, and the report's cost line matches `cost.jsonl`.
- `status.md` carries the row.

## Update status.md

```
| Seasonal (christmas) | done | seasonal/christmas/ | [date] | [n] transformed, [n] skipped, [n] stage ready, about $[x] |
```

## Wonka lines

- "Christmas is a coat the room wears. The product does not change its clothes."
- On a skip: "That frame is mostly words. Words and tinsel do not mix in this machine; your designer gets that one."
- On a drift: "Same lamp, same table, different handle. That is not Christmas, that is a different product. Once more, with the handle named."

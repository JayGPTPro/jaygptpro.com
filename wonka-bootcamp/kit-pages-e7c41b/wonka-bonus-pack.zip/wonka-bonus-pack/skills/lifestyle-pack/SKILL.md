---
name: lifestyle-pack
description: Twenty scenes of the locked product in real life, with no text on them, in the three aspect ratios, for everything outside the listing: ads, email, social, the brand store, the landing page. Derived from the persona and use cases in the product's own research, generated on the locked reference sheet, checked for product fidelity at magnification, and landed as a folder sorted by context and ratio. Use when the owner needs images for ads or social, asks for lifestyle shots, wants the product in more settings, or has nothing to post. Triggers: /lifestyle-pack, "a picture for Facebook", "something for Instagram", "I need images for ads", "lifestyle images", "more scenes of my product", "images for social", "context shots", "something for the brand store".
---

# Lifestyle Pack

| Meta | Value |
|------|-------|
| Skill | Lifestyle Pack. Part of the bonus pack, not the kit |
| Needs | The LOCKED reference sheet (`2-reference/sheet-vN.png`, `Reference status: LOCKED`, `Smoke test: PASS`), `research/persona.md`, `research/product-report.md` (use cases, the buyer), `brief/creative-brief.md` (the avoid list, the cast), `status.md`. Read by `.claude/pack/product.py`. If `product.py` prints a `WARNING:` line (gallery not approved, reference not locked), STOP and ask the owner; those are candidates, and nothing here spends on candidates |
| Saves to | `factory/Products/[product]/lifestyle/` (`jobs.json`, one PNG per scene, `contact-sheet.html`, `cost.jsonl`, `lifestyle.md`) |
| Writes | ONLY inside `lifestyle/`. Never into `images/`, `edits/` or `final/` |
| Typical cost | Measured 21.9.2026: twenty frames at `low` with three reference sheets billed $1.08, about $0.055 a frame, most of it the references sent with every call (they cost the same at every quality). The engine's `cost` line is the quote; worst case about $1.60. Cap $3 per run. `high` only when the owner asks for a specific frame at upload quality |
| Engine | `.claude/pack/engine.py`, gpt-image-2 `images.edit` with the reference sheet as the identity input |

## What this does

The gallery sells a listing: seven frames, each with a job and most with words on them. The day
the owner finishes, they have those seven and nothing else, and then the ad manager asks for a
square, the newsletter wants a wide one, the brand store wants a person at a table, and every
answer is "we only have the listing images". This skill makes the raw material: the same locked
product in twenty real settings, with no added text or badges, so the frames can carry any words later. Text printed ON the product stays.

What it is not. Not a second gallery: the listing frames answer objections, these set scenes.
Not a stock-photo generator: every frame is built on the locked reference and inspected against
it, or it does not leave the folder. Not a people factory: the cast follows the persona and the
brief, with real-looking people, and the Shipping Room's disclosure step lists any frame with a person for the owner's
call, per file.

## Before you start

| Input | Missing |
|---|---|
| `Reference status: LOCKED` with `Smoke test: PASS` (both read by `product.py` from `2-reference/reference-sheet.md`) | STOP. A pack on an unlocked product is twenty wrong products. Point to `/reference-sheet` |
| `research/persona.md` and the use cases | Run on the brief's cast and the product's own listing use, and say the contexts are doctrine, not research |
| The brief's avoid list | Read `research/insights.md` for banned claims and props; a pack never shows what the listing may not |
| `OPENAI_API_KEY` | The Machine Room, `guides/mcp-setup-guide.md` Part 2 |

## Process

### 1. Read the product

`python3 .claude/pack/product.py [product]`. Open the newest reference sheet and read
`reference-sheet.md` for the anatomy: part count, materials, colours, what the working state
looks like. Every prompt below repeats the anatomy in words, because THE WORDS RULE holds here
as in the Reference Room: prose beats photos, and a prompt that does not name the parts gets a
different product.

### 2. Write the context map

Twenty contexts, in `lifestyle/lifestyle.md`, before anything is spent. Build them from three
sources, in this order:

1. **The persona's day.** Where this buyer actually is when the product matters: the morning
   kitchen, the campsite at dusk, the gift being unwrapped. From `persona.md` and the top use
   cases in `product-report.md`.
2. **The brief's cast and world.** The people and settings the brief chose, so the pack and the
   gallery are one brand, not two.
3. **The jobs a marketer needs covered**, filled in where the first two leave gaps: a hero on a
   clean surface, product in hand, product in use, product at rest in a room, the gift moment,
   the pack-shot with props, a close detail, an overhead flat lay, a doorway or window scene,
   an outdoor one if the product ever goes outside.

Each context is one line: a name, the setting, who is there (or nobody), the moment, the light,
and the RATIO it is made in. Ratios: `1024x1024` for feeds and thumbnails, `1536x1024` for
banners, headers and the brand store, `1024x1536` for stories and pins. Spread them roughly
ten, six, four. Write the avoid list under the map: what may never appear (competitor products,
unsafe use, the banned claims, anything the brief forbids).

**No added text, badges or logos on the frames.** The point of the pack is that words come later. The product's OWN printed text (a wordmark, an engraving, the labels on a control panel) is part of the product and stays exactly as in the reference. Measured 21.9.2026: "no text" alone erased the NOSTALGIA engraving from all twenty frames and put invented letters on the control panel; the three-part line below fixed both, four of four.

### 3. Write the jobs file

`factory/Products/[product]/lifestyle/jobs.json` for the engine (its format is in `engine.py`'s docstring; every path inside it is relative to the jobs file, so `out_dir` is `.` and `refs` is `../2-reference/sheet-vN.png`): `refs` is the
newest locked sheet (plus the parts sheet on a multi-part product), `quality` `low`, `cap_usd`
3, one job per context with the context's name as the job name. Every prompt has the same
skeleton, and every prompt says **one single photograph, not a collage** (the reference sheet is a
collage, and a close-up prompt copied its panel grid on 16.9.2026):

> [the product, named with its anatomy in one sentence from the reference sheet]. [The scene:
> setting, person or none, the moment, the light.] The product is the subject and is shown
> exactly as in the reference: [count, colour, material, state]. Photoreal, [camera and lens
> feel]. Keep every word printed on the product itself (its wordmark, engraving and control labels) exactly as in the reference; invent no letters. Add no other text, no logos, no labels, no badges. Nothing covers the product.

Then, from the factory root, `python3 .claude/pack/engine.py cost factory/Products/[product]/lifestyle/jobs.json` and say the number in one line.
The owner's invocation is the go-ahead inside the cap; a cap above $3 is the one thing to ask.

### 4. Generate

`python3 .claude/pack/engine.py run factory/Products/[product]/lifestyle/jobs.json`. Four workers, one attempt each,
resume for free, stops before the cap. A moderation block is logged and skipped, never retried.

### 5. Inspect, the pack's own gate

Every frame is OPENED and read against the reference sheet, the way `/inspect` reads product
accuracy: part count counted, material and colour judged at MAGNIFICATION (crop the product
region at 2x with PIL and look), people real-looking, nothing on or covering the product, no
added text, and the product's own printed text present and spelled as on the reference (read it at 2x). Write `stage_ready` and a one-line `verdict` into each job in `jobs.json`.

A frame that fails on the product gets ONE regeneration: tighten the anatomy sentence with the
thing that drifted, delete the file, run again (the engine skips finished files, so only that
one runs). A frame that fails twice is deleted and its context marked `not made` in
`lifestyle.md`, so the folder never holds a wrong product.

A frame that is right but dull is kept and marked so. Dull is a marketer's problem; wrong is ours.

### 6. Sheet and hand-off

`python3 .claude/pack/engine.py sheet factory/Products/[product]/lifestyle/jobs.json`. Open it. Write `status.md`'s row.

## What you tell the owner

The count made and the count held back (with why), the three ratios and how many of each, the
cost, the one path. Say that these frames carry no words on purpose, and that the frames with people are
listed for the Shipping Room's disclosure step, where the owner decides per file.

## Definition of done

- `lifestyle.md` holds twenty named contexts, their sources, the ratios and the avoid list, written before the first spend.
- Every frame on disk was opened and read against the reference at magnification; a wrong product is not on disk.
- No frame carries added text, a logo or a badge, and the product's own printed text is on every frame, spelled right.
- The sheet exists, the receipt matches the cost line, `status.md` carries the row.

## Update status.md

```
| Lifestyle pack | done | lifestyle/ | [date] | [n] of 20 made, [n] held back, ratios [a/b/c], about $[x] |
```

## Wonka lines

- "The gallery argues. These just live. Twenty rooms, one product, no words."
- On a held-back frame: "Lovely light, wrong spoon count. It does not leave the factory."
- On the no-text rule: "A frame with words on it can do one job. A frame without can do fifty."

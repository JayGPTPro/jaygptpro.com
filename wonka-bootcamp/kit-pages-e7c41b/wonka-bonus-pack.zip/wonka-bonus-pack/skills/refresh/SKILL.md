---
name: refresh
description: The quarterly return to the shelf. Snapshots the owner's live listing and every competitor the research named, plus the new competitors the search now shows, diffs them against the last visit (frames added, replaced, reordered; titles, ratings, review counts moved), and ends with ONE asset to make or replace, chosen only when the diff and a source already in the factory point at the same hole, routed to /fix, /steal-this-frame or /secondary-images. A gallery diff plus a rating and a count; it reads no reviews and buys no analysis. Use when the owner asks what changed, whether the listing still holds up, wants to check competitors again, or a season has passed. Triggers: /refresh, "is my listing still good", "what are my competitors doing", "what changed on the shelf", "check my competitors again", "are my images still good", "quarterly review", "anything new out there", "did anyone update their images".
---

# Refresh

| Meta | Value |
|------|-------|
| Skill | Refresh. Part of the bonus pack, not the kit |
| Needs | `status.md` (the ASIN), `research/competitors.md` (the roster C1 to C5 and the last teardown), `incumbent/` (what was live at the last visit), `research/reviews.md` (the objections already known), `brief/creative-brief.md`, the tasting cards and `upload/running-order.md` when they exist, the shipped gallery |
| Saves to | `factory/Products/[product]/refresh/[YYYY-MM-DD]/` (`own/`, `C1/`..`Cn/`, `new/`, `sheets/`, `refresh.md`) |
| Writes | ONLY inside `refresh/`. Never edits an image; the one asset it decides on is made by the room it routes to |
| Typical cost | Nothing. The Genrupt scrape and the diff spent nothing on 16.9.2026 and on 21.9.2026. This skill never runs a market analysis: it is meant to run alone once a quarter, and an approval for credits does not belong in it |
| Engine | `.claude/pack/refresh_fetch.py` for snapshots and diffs, the kit's `meet-my-product/contact_sheet.py` for the sheets |

## What this does

A package is finished on the day it ships and starts ageing the next morning. Competitors
replace frames, a new seller arrives with a better scale shot, a rating slips. The bootcamp
graduate has no way to notice any of that except by browsing, which nobody does. This skill is
the noticing: a visit to the shelf, a diff against the last visit, and one decision at the end:
which single asset to make or replace now, and why, when the diff and a source the factory
already holds agree on it.

What it is not. Not a research re-run: `/meet-my-product` built the picture, this checks what
moved. Not an advice memo: it ends with an asset order and the evidence for it. Not a competitor
copier: when a rival's new frame is the answer, `/steal-this-frame` takes the idea, never the
image.

## Before you start

| Input | Missing |
|---|---|
| `research/competitors.md` with a roster | Run on the live search results alone and say the roster is new, so the first diff has no "before" |
| `incumbent/` | The first visit snapshots the live listing and becomes the baseline; say so |
| A previous `refresh/` folder | None on the first visit, so step 1 builds `baseline/` from `incumbent/` and `1-inputs/competitors/`. Every later visit diffs against the newest earlier visit |
| Amazon blocks the fetch | Say so once, no retries; ask for the gallery as a folder or screenshots, or wait a day |

## Process

### 1. Snapshot the shelf

Tool order: Genrupt first, a plain fetch only when Genrupt cannot scrape, one attempt, never a retry
(a retry can get the owner's IP blocked). Every path below is from the factory root. `[R]` is
`factory/Products/[product]/refresh/[YYYY-MM-DD]`.

For the owner's ASIN (folder `own`) and every competitor in the roster (folders `C1`..`Cn`):

1. `scrape_video_reference_images_from_asin {asin, maxImages: 9}`, then `wait_for_operation` until
   `referenceImageUrls` land.
2. `python3 .claude/pack/refresh_fetch.py snapshot [ASIN] --out [R]/[folder] --urls [the URLs]`
3. Title, rating and review count come from the direct fetch ONLY, one attempt, and the
   snapshot records them when it gets them. If the direct route is blocked, the line in
   `refresh.md` is `rating and count: not read this visit`. Never a figure from the research
   folder or an old analysis: the ID a market analysis leaves in the research dies after
   nineteen days, and a number from March is not this visit's reading.
4. If Genrupt returned nothing: `python3 .claude/pack/refresh_fetch.py snapshot [ASIN] --out [R]/[folder]`,
   once. If that is blocked, write the block into `refresh.md` and ask the owner for a folder or
   screenshots; snapshot those with `--folder`.

New arrivals: the top ten results for the niche phrase in `status.md`, read from the search page
on the direct route (one attempt) or from the last search the research folder holds, labelled
with its date. Any ASIN not in the roster is snapshotted the same way into `[R]/new/[ASIN]`.

Two things the diff will tell you and you must not overrule: a **price** that is not a dollar
figure is `not comparable` (a fetch from another country returns that country's export price,
`ILS 176.58` on 21.9.2026, and that is not a move); and when the **route changed** between visits
(Genrupt one time, the direct fetch the next), a frame the direct route alone saw is not "added"
until you see it on the sheet as a gallery frame, because the direct fetch also collects the
style-selector images (7 against Genrupt's 5 on the same listing, 21.9.2026).

One contact sheet per snapshot, and read the sheets, not the files:
`python3 .claude/skills/meet-my-product/contact_sheet.py [R]/[folder]/frames --out [R]/sheets/[folder]-sheet.jpg`

First visit only: there is no earlier `refresh/` folder, so build the baseline from disk:
`python3 .claude/pack/refresh_fetch.py snapshot --folder factory/Products/[product]/incumbent --out [R]/baseline/own`
and the same for each folder under `1-inputs/competitors/` (the kit names them after the
competitor) into `[R]/baseline/C1`..`Cn`, in roster order. Step 2 diffs against `baseline/`.

### 2. Diff against the last visit

On the first visit the "last visit" is the `baseline/` you built in step 1 from `incumbent/` and
the competitor folders. On every later visit it is the newest earlier `refresh/` folder.

```
python3 .claude/pack/refresh_fetch.py diff [last visit]/[folder] [R]/[folder]
```

One diff per folder (`own`, `C1`..`Cn`): frames added, removed, replaced, reordered; title,
price, rating and review count moved; bullets changed. A competitor with no baseline gets no
diff, and `refresh.md` says so. Write every diff into `refresh.md` as the machine printed it.

### 3. Read what changed, with eyes

Open the sheet of every ASIN that moved and answer, per changed frame: what job does the new
frame do, and is it a job our gallery does not do? A competitor who added a scale shot after
their reviews complained about size has told you two things: what their buyers doubt, and what
ours might. A new arrival's whole gallery gets the Day 2 read (jobs per position, table stakes,
whitespace) in five lines, not a full teardown.

### 4. Decide ONE asset, or say there is none

**An asset is chosen only when two things point at the same hole:** the diff (a competitor added
or replaced a frame, a new arrival's gallery does a job ours does not) AND one source that already
lives in the factory (`research/reviews.md` from Day 2, the tasting cards, `/running-order`'s
ledger). Write both on the `Why now` line. A competitor's move on its own is evidence that they
think something, not an order to build; a refresh that generates from the shelf alone is
"follow the shelf", and the factory does not do that. This skill reads no new reviews: review
fetching was unreliable, and the factory's own reviews file is the source it trusts.

`refresh.md` ends with one order, in this shape, and the evidence that chose it over the others.
**"Nothing moved that a new image would answer" is a complete, legitimate ending**, written in
the same shape with `What: none` and the evidence for why. A refresh that invents an asset to
have something to say is worse than one that says the shelf is quiet.

Before the order, one short block that says what this visit actually looked at: which frames
were fetched on which route, which fetches failed, and whether the rating and count were read
this visit (direct fetch) or not. A conclusion is never drawn from a source this visit did not read. A snapshot with failed
downloads is marked partial, and a missing file in a partial snapshot is never reported as a
frame the competitor removed.

```
## The one asset to make now
- What: [a scale frame with a hand and the 13.5 inch spoon against a stockpot]
- Why now: [the diff: C2 replaced their frame 3 with a hand-for-scale shot on 2026-09-02] + [the factory source: reviews.md, 6 one-star quotes say "smaller than expected"; our gallery has no scale frame]
- Route: /secondary-images (a new frame)   |   /fix (a change to frame [n])   |   /steal-this-frame (C2 frame 3, the idea)
- Slot it takes: [3], which moves [the current frame 3] to [6] per /running-order's ledger
- Not chosen, and why: [C4's new lifestyle frame: the diff shows it, but no factory source names that doubt]
```

One asset. A list of six is a research memo; an order is what the factory runs. The owner
says go, and the routed room makes it under its own rules. When nothing moved, or something
moved that no factory source backs, say so in one line and close: "the shelf is where we left it" is a real result.

### 5. Record the visit

`status.md` gets the row. The new folder is the baseline for the next visit.

## What you tell the owner

What moved (in the diff's words, ASIN by ASIN, one line each), the one asset with the two
sources that chose it and its route, or that nothing moved, and the date of
the next visit if they want a cadence. Never a list of everything that could be improved.

## What comes next

End the report with the DATE OF THE NEXT VISIT (ninety days out unless the owner says
otherwise; a date to come back on, not a scheduled job) and the one asset, routed by name:
`/fix` when an existing frame is nearly right, `/steal-this-frame` when a competitor's idea is
the answer, `/secondary-images` when the slot needs a new frame, or `none` with the reason. A
report with no date is half a report.

## Definition of done

- Every ASIN in the roster was snapshotted (or its block recorded), and the diff for each is in `refresh.md` as the machine printed it.
- Every changed frame was read on a sheet, not guessed from a filename.
- No review was fetched and no market analysis was run; rating and count are from the direct fetch this visit or marked not read.
- A chosen asset names the diff line AND the factory source that agree; a diff line alone chose nothing.
- `refresh.md` ends with ONE asset, its evidence, its route and its slot, or with the line that nothing moved.
- Nothing was edited or generated by this skill.
- `status.md` carries the row.

## Update status.md

```
| Refresh | done | refresh/[date]/refresh.md | [date] | [n] ASINs read, [n] moved; asset: [what] via [route], or: nothing moved |
```

## Wonka lines

- "The shelf does not stand still because we finished. Let us go and look."
- On a quiet shelf: "Nothing moved. That is not nothing; that is a quarter we do not have to spend."
- On the one asset: "Six things could be better. One thing is costing us. We make the one."

---
name: refresh
description: The quarterly return to the shelf. Snapshots the owner's live listing and every competitor the research named, plus the new competitors the search now shows, diffs them against the last visit (frames added, replaced, reordered; titles, prices, ratings, review counts moved), reads the new reviews for objections the gallery does not answer yet, and ends with ONE asset to make or replace, with its evidence, routed to /fix, /steal-this-frame or /secondary-images. Use when the owner asks what changed, whether the listing still holds up, wants to check competitors again, or a season has passed. Triggers: /refresh, "what changed on the shelf", "check my competitors again", "are my images still good", "quarterly review", "anything new out there", "did anyone update their images".
---

# Refresh

| Meta | Value |
|------|-------|
| Skill | Refresh. Part of the bonus pack, not the kit |
| Needs | `status.md` (the ASIN), `research/competitors.md` (the roster C1 to C5 and the last teardown), `incumbent/` (what was live at the last visit), `research/reviews.md` (the objections already known), `brief/creative-brief.md`, the shipped gallery. Optional: a fresh Genrupt market analysis on the niche keyword, cost-consented |
| Saves to | `factory/Products/[product]/refresh/[YYYY-MM-DD]/` (`own/`, `C1/`..`Cn/`, `new/`, `sheets/`, `refresh.md`) |
| Writes | ONLY inside `refresh/`. Never edits an image; the one asset it decides on is made by the room it routes to |
| Typical cost | The Genrupt scrape and the diff spent nothing on 16.9.2026; quote it live if that changes. A fresh market analysis costs machine credits and is quoted live before it runs; it is optional and off by default |
| Engine | `.claude/pack/refresh_fetch.py` for snapshots and diffs, the kit's `meet-my-product/contact_sheet.py` for the sheets |

## What this does

A package is finished on the day it ships and starts ageing the next morning. Competitors
replace frames, a new seller arrives with a better scale shot, the reviews find an objection
nobody had at launch. The bootcamp graduate has no way to notice any of that except by
browsing, which nobody does. This skill is the noticing: a visit to the shelf, a diff against
the last visit, the new reviews read for what the gallery does not answer yet, and one decision
at the end: which single asset to make or replace now, and why.

What it is not. Not a research re-run: `/meet-my-product` built the picture, this checks what
moved. Not an advice memo: it ends with an asset order and the evidence for it. Not a competitor
copier: when a rival's new frame is the answer, `/steal-this-frame` takes the idea, never the
image.

## Before you start

| Input | Missing |
|---|---|
| `research/competitors.md` with a roster | Run on the live search results alone and say the roster is new, so the first diff has no "before" |
| `incumbent/` | The first visit snapshots the live listing and becomes the baseline; say so |
| A previous `refresh/` folder | None on the first visit. Every later visit diffs against the newest one, else against `incumbent/` and `1-inputs/competitors/` |
| Amazon blocks the fetch | Say so once, no retries; ask for the gallery as a folder or screenshots, or wait a day |

## Process

### 1. Snapshot the shelf

The kit's tool order holds here: **Genrupt first, browsing second, a plain fetch last.** Measured
16.9.2026: a plain curl of a product page was blocked on the first attempt; the image CDN was not.

For the owner's ASIN and every competitor ASIN in the roster:

1. `scrape_video_reference_images_from_asin {asin, maxImages: 9}` (a free background
   operation; `wait_for_operation` until `referenceImageUrls` land). Title, price, rating and
   review count come from the newest market analysis that lists the ASIN
   (`find_market_analyses` then `get_market_analysis_report`), written to a small `meta.json`.
2. ```
   python3 .claude/pack/refresh_fetch.py snapshot [ASIN] --out factory/Products/[product]/refresh/[date]/[own|C1..Cn] \
      --urls [the referenceImageUrls] --meta refresh/[date]/[same]/meta.json
   ```
3. Only when Genrupt cannot scrape an ASIN: the plain fetch (`snapshot [ASIN] --out ...`), ONE
   attempt. A block is recorded and the owner is asked for a folder or screenshots
   (`--folder`). Never retry a block. Then the new arrivals: read the top organic results for the niche phrase
in `status.md` (through a Genrupt market analysis if the owner wants the credits spent, else the
last analysis on record, else the roster only) and snapshot any ASIN in the top ten that the
roster does not hold, into `refresh/[date]/new/[ASIN]`. Build one contact sheet per snapshot with the kit's `contact_sheet.py` on the snapshot's
`frames/` folder (`python3 .claude/skills/meet-my-product/contact_sheet.py [snapshot]/frames --out [date]/sheets/[name]-sheet.jpg`), and READ the sheets, not the files.

### 2. Diff against the last visit

```
python3 .claude/pack/refresh_fetch.py diff [last visit folder] factory/Products/[product]/refresh/[date]/[same]
```

For every ASIN: frames added, removed, replaced, reordered; title, price, rating and review
count moved; bullets changed. The first visit has no diff for competitors unless
`1-inputs/competitors/C*/` holds their galleries from Day 2, in which case snapshot those folders
with `--folder` as the baseline. Write every diff into `refresh.md` as the machine printed it.

### 3. Read what changed, with eyes

Open the sheet of every ASIN that moved and answer, per changed frame: what job does the new
frame do, and is it a job our gallery does not do? A competitor who added a scale shot after
their reviews complained about size has told you two things: what their buyers doubt, and what
ours might. A new arrival's whole gallery gets the Day 2 read (jobs per position, table stakes,
whitespace) in five lines, not a full teardown.

### 4. Read the new reviews

Reviews come from one of two places, named in `refresh.md`: the newest Genrupt market analysis
that lists the ASIN (its themes and counts), or the product page when the plain fetch ran. When
neither is on hand this visit, write `reviews: not read this visit` and skip to step 5. Read what
there is against `research/reviews.md`: which objections are NEW since the research, which known ones grew.
An objection the gallery already answers is noted and dropped. An objection no frame answers is
the candidate for the asset order.

### 5. Decide ONE asset

`refresh.md` ends with one order, in this shape, and the evidence that chose it over the others:

```
## The one asset to make now
- What: [a scale frame with a hand and the 13.5 inch spoon against a stockpot]
- Why now: [C2 replaced their frame 3 with a hand-for-scale shot on 2026-09-02; 4 of the 11 newest reviews say "smaller than expected"; our gallery has no scale frame]
- Route: /secondary-images (a new frame)   |   /fix (a change to frame [n])   |   /steal-this-frame (C2 frame 3, the idea)
- Slot it takes: [3], which moves [the current frame 3] to [6] per /running-order's ledger
- Not chosen, and why: [the A+ refresh, because nothing moved on the page and the reviews do not mention it]
```

One asset. A list of six is a research memo; an order is what the factory runs. The owner
says go, and the routed room makes it under its own rules. When nothing moved and the reviews
are quiet, say so in one line and close: "the shelf is where we left it" is a real result.

### 6. Record the visit

`status.md` gets the row. The new folder is the baseline for the next visit.

## What you tell the owner

What moved (in the diff's words, ASIN by ASIN, one line each), what the new reviews say that the
gallery does not answer, the one asset and its route, the cost (usually zero), and the date of
the next visit if they want a cadence. Never a list of everything that could be improved.

## Definition of done

- Every ASIN in the roster was snapshotted (or its block recorded), and the diff for each is in `refresh.md` as the machine printed it.
- Every changed frame was read on a sheet, not guessed from a filename.
- The new reviews were read against `reviews.md`, and the objections are sorted into answered and unanswered.
- `refresh.md` ends with ONE asset, its evidence, its route and its slot, or with the line that nothing moved.
- Nothing was edited or generated by this skill.
- `status.md` carries the row.

## Update status.md

```
| Refresh | done | refresh/[date]/refresh.md | [date] | [n] ASINs read, [n] moved; asset: [what] via [route], or: nothing moved |
```

## Wonka lines

- "The shelf does not stand still because we finished. Let us go and look."
- On a quiet shelf: "Nothing moved. That is not nothing; that is a quarter we do not have to spend."
- On the one asset: "Six things could be better. One thing is costing us. We make the one."

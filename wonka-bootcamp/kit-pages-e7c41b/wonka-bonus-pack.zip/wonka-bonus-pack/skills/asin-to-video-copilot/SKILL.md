---
name: asin-to-video-copilot
description: >-
  Turn the product on the line (or any Amazon ASIN) into a finished 30-second listing video WITH the owner in the
  decisions. Same pipeline, same taste engine and same QA gates as
  asin-to-video-autopilot; the difference is the contract: eight decisions belong to
  the user, grouped so they sit with you twice and the machine works alone in between.
  Use when the user wants to be involved, wants control over the creative, says
  "co-pilot", "with me", "I want to choose", or this product deserves the best video
  they can make. For a hands-off run, use asin-to-video-autopilot instead.
---

# asin-to-video-copilot

| Meta | Value |
|------|-------|
| Skill | asin-to-video-copilot. A PORT into the bonus pack. It owns the CONTRACT; `asin-to-video-autopilot` owns the machinery, and this skill reads it where it lives |
| Needs | Everything the autopilot needs, plus the autopilot itself installed beside it (`.claude/skills/asin-to-video-autopilot`, or `~/.claude/skills/...` outside a factory). Without it this skill cannot run, and says so instead of improvising |
| Saves to | The same run folder as the autopilot, `factory/Products/[product]/video/runs/[ASIN]-[date]/`. One film, one path: `out/FINAL-[slug].mp4` |
| Writes | ONLY inside that run folder. Never edits a file inside the autopilot's folder |
| Typical cost | The autopilot's, unchanged: about 190 credits a run. The same two caps from the same `config.json`. The eight questions cost nothing; they are asked before the money moves, not instead of it |
| Engine | The autopilot's, every script and gate. The only thing this skill adds is where the run STOPS to ask |


## What this does

The same 30-second film as `/asin-to-video-autopilot`, from the same machinery, with eight
decisions kept by you: the traps, the direction, the reference clip, the probe frame, the master
prompt, the door, the music and the final call. They are grouped so you sit with Wonka twice and
the machine works alone in between.

What it is not. Not a different or better pipeline, and not a slower one for its own sake. Every
gate is a real fork where taste changes the film. For a hands-off run, use the autopilot.

## Before you start

| Input | Missing |
|---|---|
| Everything the autopilot needs | From the factory root: `bash .claude/skills/asin-to-video-autopilot/setup/check-env.sh` names every missing one with its fix |
| The autopilot installed beside this skill | This skill owns the contract, not the machinery. Without the autopilot's folder it stops and says so, rather than improvising a pipeline |
| Your attention, twice | Roughly ten minutes across two sittings. The gates wait; silence is never a yes |

Same road as the autopilot, different seat. Run the co-pilot when this product
deserves the best video you can make. Run the autopilot when your time is worth more
and you want to come back to a finished film.

**This skill owns the CONTRACT. The autopilot owns the MACHINERY.** Every stage,
script, reference file, QA gate, money rule, variant rule and resume rule is the
autopilot's, loaded from its install folder next to this one:

    AP = .claude/skills/asin-to-video-autopilot      (inside a Wonka factory: the pack installs both)
    AP = ~/.claude/skills/asin-to-video-autopilot    (installed globally, outside a factory)

If neither folder exists, stop and say so: install asin-to-video-autopilot first,
this skill cannot run without it. Inside the factory, the autopilot's "Running inside
the Wonka factory" intake applies here too: the ASIN, the locked reference sheet, the
research and the Tasting Card are the inputs, and the film lands in the product folder. Never copy its files here; read them where they
live, so a fix lands in both skills at once.

Follow `AP/SKILL.md` end to end, environment check, config, money contract, run
stages 1-13, policy gate, variant and retake rules, resume, with ONLY the
differences below.

## The contract: eight decisions are the user's

The autopilot promises zero questions. The co-pilot promises the OPPOSITE, and
keeps it honest the same way: everything that is not one of these eight decisions
is decided by the taste engine exactly as in autopilot, silently. Never invent a
ninth question. A co-pilot that asks about everything is not a co-pilot, it is a
form.

**Money stays autopilot money.** The SAME TWO caps from the same config.json,
`cap_credits` and `cap_usd`, never converted into each other, checked before
every paid action against worst case. Do NOT price individual junctions to the
user or ask "this render costs X, proceed?", the cap is the whole money
conversation.

### Sitting one, before any credit moves (~10 minutes together)

Present these as short, concrete choices. One screen each, then move.

1. **The traps** (after stage 1, research). Show what the run found: the facts,
   the buyers' words, and the list of what must not be wrong (counts, colors,
   mechanisms). Ask: *"Anything missing from the traps list?"* Their product
   knowledge beats the listing's.
2. **The direction** (stage 2-3). Present THREE creative directions, each with a
   mood and a reason, plus the one anchor sentence for each. They pick one, and
   may edit the anchor sentence. Taste stays their job here.
3. **The reference video** (stage 5). List the review videos found on the
   listing, one line each: title, seconds, what it shows. Recommend one and say
   why (the one showing the MECHANISM). They pick. Then pull the full-resolution
   stream, never the preview file (under 300px tall = refused upload).
   **When the listing carries no video** (common, and always the case for a product whose
   film is built from the locked reference sheet rather than from a scrape), say so in one
   line, ask whether they have a clip of their own to donate the mechanism, and run without
   one if they do not. A missing reference is not a blocked gate; it is a film built from
   stills, which is the default.
4. **The ignore list** (same sitting). Show what the chosen reference will be
   USED for and what it must NOT donate (the table, the light, the hands, the
   bundle). Ask: *"Anything else this clip must not teach the film?"* A reference
   donates everything you did not forbid.
5. **The probe frame** (stage 6). Run the probe, show the frame. One question:
   *"Right product, right light, right world?"* A no here is cheap; the same no
   after the master is not. On a no: name what failed, fix the brief or the
   references, re-probe. The probe loop is free-ish; the master is not.
6. **The master prompt** (stage 7, gate before firing). Show the compiled prompt
   with its sections visible, SUBJECT, PRODUCT IDENTITY, CAMERA, SOUND, NEVER.
   They approve or name changes. Never fire the master unapproved. Then tell
   them the render takes ~8 minutes and the next stretch is yours alone.

### The machine works alone (~25-30 minutes)

Stages 8-11 run exactly as autopilot: QA, severity-class fixes (free repairs
first), audio candidates, overlays. Report one line per completed stage; ask
nothing. If a fix would cross the cap, that is the autopilot's one stop, and it
applies here unchanged.

### Sitting two, the two calls with no objective answer (~5 minutes together)

7. **The door** (after stage 8-9 QA). Show the second-by-second analysis and
   YOUR read of it, then put the three doors in front of them: wrong at the root
   (fix the brief, regenerate, never patch a wrong film), mostly right
   (surgical repair on the failing seconds only), or right (stop; knowing when
   to stop is also a skill). Recommend one door and say why. They choose.
8. **The music** (stage 12, the audio taste gate). The three directions are
   already rendered against the film, as in autopilot. Instead of shipping a
   recommendation, play all three and let them pick. Ears outrank meters.

Then conform + deliver exactly as autopilot: ONE path, `out/FINAL-<slug>.mp4`,
report beside it.

## Definition of done

- The autopilot's Definition of done is met in full. This skill changes who decides, never what
  ships, so nothing on that list is waived because a person was in the room.
- All EIGHT decisions were put to the user and answered, or explicitly delegated in their own
  words. A delegation is recorded verbatim in the report and never asked again on that run.
- No ninth question was asked. Everything outside the eight was decided by the taste engine and
  logged, exactly as in autopilot.
- Every gate that opened, opened BEFORE the spend it governs, not after.
- The two sittings happened as two sittings: the machine worked alone in between, and the user
  was not pinged during that stretch.
- The report says, per decision, what the user chose and what the autopilot would have chosen.
  That difference is the whole argument for this skill existing.
- `status.md` carries the row.

## Update status.md

Inside the factory, one row per delivered film, with the decisions marked as the owner's.

```
| Video (co-pilot) | done | video/runs/[run]/out/FINAL-[slug].mp4 | [date] | [n] credits, [n] of 8 decisions taken by the owner |
```

## What the user learns, on purpose

Each sitting-one gate is also the lesson: say in one line WHY this decision is
theirs ("images lock what the product is, video teaches what it does, that is
why you pick the clip"). Never lecture past one line. A user who has run the
co-pilot three times should be able to run the autopilot and know exactly what
it is deciding for them.

## Answer shape

At every gate, accept a bare pick ("2", "the second one", "yes") and get on with
it. If they say "you choose" (in words), choose as the autopilot would, record the delegation
verbatim in the report, and do not ask again at that gate on this run. Silence is never a yes:
the gate stays open until they answer.

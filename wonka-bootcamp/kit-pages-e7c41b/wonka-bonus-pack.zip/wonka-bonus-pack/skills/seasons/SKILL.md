---
name: seasons
description: The santa engine for every other occasion. Dresses the product's shipped gallery for Valentine's Day, Mother's Day, Father's Day, Easter, Halloween, Thanksgiving, the Fourth of July, back to school, summer, New Year, or a custom occasion the owner names, with the product untouched and the main image left alone, and lands a per-season folder plus a before/after contact sheet. Christmas itself is /santa. Use when the owner names a holiday, a season, an occasion, a sale event with a look, or asks for seasonal versions of the gallery. Triggers: /seasons, "spring versions", "prime day images" (refused: a sale is not a season), "valentine's versions", "mother's day images", "halloween gallery", "summer versions of my images", "seasonal images for [occasion]", "dress the gallery for [event]".
---

# Seasons

| Meta | Value |
|------|-------|
| Skill | Seasons. Part of the bonus pack, not the kit |
| Needs | The shipped gallery via `.claude/pack/product.py`, and the season's name. Outside the factory: an ASIN, a URL or a folder. If `product.py` prints a `WARNING:` line (gallery not approved, reference not locked), STOP and ask the owner; those are candidates, and nothing here spends on candidates |
| Saves to | `factory/Products/[product]/seasonal/[season]/` (`originals/`, `[season]/`, `plan.json`, `contact-sheet.html`, `report.md`, `cost.jsonl`), one folder per season |
| Writes | ONLY inside that folder. Never touches `images/`, `edits/`, `final/` or the main image |
| Typical cost | The same as /santa. Typical: about $0.01 to $0.03 a frame at `low`, about $0.17 at `high`. The cap counts the WORST case, which is higher ($0.03 low, $0.30 high). The $2 default covers a seven-frame set at `low` with room to spare, but only SIX frames at `high`: pass `--cap 3` for a seven-frame upload set |
| Engine | `.claude/pack/seasonal.py` (`seasons` lists them), gpt-image-2 `images.edit` |

## What this does

The same rule as Christmas, for the rest of the calendar: the season happens around the product,
never to it. The prompt keeps the bones of Jay's tested Christmas prompt (product untouched, no
filter, at most three props far from the product, never darker, photoreal, no invented text) and
swaps in the occasion's own vocabulary, which is written into `seasonal.py` per season so the same
occasion reads the same way on every product.

The seasons on the menu: `valentines`, `mothers-day`, `fathers-day`, `easter`, `halloween`,
`thanksgiving`, `fourth-of-july`, `back-to-school`, `summer`, `new-year`. Anything else is
`custom` with a `--notes "Name: vocabulary"` line, written by Wonka after one question to the
owner about what the occasion looks like in their market. Christmas is `/santa`.

What it is not. Not a redesign, not a sale banner ("Prime Day" is a price event with no look, so
it is not a season here; say so), and not a colour filter.

## Before you start

| Input | Missing |
|---|---|
| The season | Ask once, with the menu. A custom occasion needs one sentence of vocabulary from the owner or from Wonka's knowledge of the market, written into `--notes` |
| A product with a shipped gallery | Say which product, or run on an ASIN / folder |
| `OPENAI_API_KEY` | The Machine Room, `guides/mcp-setup-guide.md` Part 2 |

## Process

**If the season is Christmas, stop and run `/santa`.** Same engine, but Christmas has its own
tested vocabulary and its own prompt rules file. One line to the owner and hand over.

### 1. Stage the frames

Inside the factory:

```
python3 .claude/pack/product.py [product]       # the shipped main and gallery, current versions
python3 .claude/pack/seasonal.py fetch --files [the gallery paths, in order] \
   --out factory/Products/[product]/seasonal/[season] --no-main --title "[product name]"
```

`--files` takes the gallery the product reader printed (`gallery`), already the CURRENT version of
every frame. `--no-main` says this folder holds no main image, so every frame may transform.

Outside the factory, the kit's tool order applies. **A bare ASIN is REFUSED**, because reading
amazon.com directly was measured blocked on the first attempt (16.9.2026) and a retry risks the
owner's IP. Genrupt names the images, the script downloads them:

```
scrape_video_reference_images_from_asin {asin: "B0XXXXXXXX", maxImages: 9}   # free, Genrupt MCP
python3 .claude/pack/seasonal.py fetch B0XXXXXXXX --urls [the referenceImageUrls] \
   --out seasonal/[season] [--meta meta.json from the market analysis]
```

A folder of images and `--files` both still work and need no MCP.

### 2. Classify. You look, the script lists

Run `python3 .claude/pack/seasonal.py list [run]`, then OPEN every original and fill `plan.json`, `seen` first (one line of what is in the picture; `generate` refuses a blank one). The skip rules are the Christmas ones
(infographics, logo cards, colour-variant plain-background shots, collages). The scene line names the surfaces
and lights that exist, and the one or two accents that arrive, from the season's vocabulary.

For Halloween and New Year, say in the scene line that the image stays BRIGHT. Those two seasons
pull toward dark, and dark fails the check.

### 3. Generate

Every run folder is the full `factory/Products/[product]/seasonal/[season]` path, and every command
runs from the factory root, where `.env` lives.

```
python3 .claude/pack/seasonal.py generate [run] --season [season] --cap 2
```

Add `--notes` on a custom season. For the upload set, `QUALITY=high` with `--cap 3` (the cap gates
by worst case, $0.30 a frame at high, so $2 would stop at six frames).

### 4. Check

```
python3 .claude/pack/seasonal.py check [run] --season [season]
```

Then OPEN every pair and write `stage_ready` and a verdict per frame, answering the questions in
`.claude/skills/santa/christmas-prompt-rules.md`. ONE `regen` per failing frame, with the failure written into
the note. Never a second.

### 5. Sheet

```
python3 .claude/pack/seasonal.py sheet [run] --season [season]
```

Open it for the owner, then write the `status.md` row.

Several seasons on one product are several runs, one folder each. Never mix two seasons in one
frame.

## What you tell the owner

The same four lines as `/santa`, plus one: which folder is which season, so the swap-in and the
swap-out are one move each.

## Definition of done

- The season was named before anything was staged, and a custom one carries its vocabulary line.
- Every original opened and classified; every output opened and judged; the main never staged.
- Sheet and report exist; `status.md` carries a row per season.

## Update status.md

```
| Seasonal ([season]) | done | seasonal/[season]/ | [date] | [n] transformed, [n] skipped, [n] stage ready, about $[x] |
```

## Wonka lines

- "Every occasion gets the same two rules. Around the product, never on it. Bright, never moody."
- On Halloween: "Pumpkins, yes. Cobwebs on a kitchen counter, no. We are decorating, not haunting."
- On a custom occasion: "Tell me what the day looks like where you sell, and I will dress the room in it."

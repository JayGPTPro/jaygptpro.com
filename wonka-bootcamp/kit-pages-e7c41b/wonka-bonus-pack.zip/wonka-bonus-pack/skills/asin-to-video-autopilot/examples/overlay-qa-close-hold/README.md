# CLOSE HOLD regression fixture (26.8.2026)

Proves `overlay_qa.py`'s CLOSE HOLD check catches what READ TIME structurally cannot.
The film is any clip >= 6s; generate one with:

    ffmpeg -y -f lavfi -i color=c=0x24352B:s=1280x720:d=8 -c:v libx264 -pix_fmt yuv420p film.mp4

Then:

    python3 ../../scripts/overlay_qa.py overlay-wordmark.html film.mp4 theme.json

- `overlay-wordmark.html` — a ONE-WORD close held 1.8s (still 0.90s). Read-time needs
  only 0.88s for one word, so READ TIME PASSES and **CLOSE HOLD must be the only
  timing failure**. This is the whole reason the check exists: the wordmark close is
  exactly the case the read-time floor cannot see.
- `overlay-long.html` — same shape, close held 2.2s (still 1.30s). CLOSE HOLD must be
  ABSENT. (Other checks still fail on both files — these fixtures are deliberately
  minimal and are not choreographed; grep for the CLOSE HOLD / READ TIME lines.)

Watched failing before the check was written, per the rule that a regression test you
never saw fail is a guess.

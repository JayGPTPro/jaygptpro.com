---
name: localize-gallery
description: The shipped gallery re-rendered for another marketplace: every headline and label on the frames rebuilt in the target language, the units converted where the frame shows them, and the people in the scene matched to the buyer there, with the product itself untouched. Not a translation file, a set of image files. Proofread at native resolution before it ships. Use when the owner is expanding to another Amazon marketplace, asks for the gallery in German, French, Spanish, Italian, Japanese or another language, or mentions amazon.de, .fr, .it, .es, .co.jp, .co.uk, .ca or .com.mx. Triggers: /localize-gallery, "the gallery in German", "images for amazon.de", "localize my images", "Japanese version of the listing images", "translate the gallery".
---

# Localize Gallery

| Meta | Value |
|------|-------|
| Skill | Localize Gallery. Part of the bonus pack, not the kit |
| Needs | The shipped gallery via `.claude/pack/product.py`, the locked reference sheet, `brief/creative-brief.md` (the approved claims behind each headline), `research/selling-points.md`, and the target marketplace |
| Saves to | `factory/Products/[product]/localized/[market]/` (`jobs.json`, one PNG per frame, `copy.md`, `contact-sheet.html`, `cost.jsonl`) |
| Writes | ONLY inside `localized/[market]/`. The English frames are never touched |
| Typical cost | One edit per frame at `low`, about $0.03 each; a seven-frame gallery is under $0.25 for the proof and about $1.20 at `high` for the upload set. Cap $2 per market at low, $3 at high (the cap gates by worst case) |
| Engine | `.claude/pack/engine.py`, an EDIT job per frame: the English frame is the source image and the only image sent |

## What this does

A seller who opens amazon.de has two choices today: pay an agency to rebuild seven frames, or
upload the English ones and let German shoppers squint at "10 PIECE SET". This skill rebuilds the
frames: the same picture, the same product, the words redrawn in the target language by the
image model, the units switched where a frame shows inches or ounces, and, when the owner wants
it, the person in the scene recast for the market.

What it is not. It does not write listing copy (title, bullets): that is text and it belongs
elsewhere. It does not change the product or the composition. And it does not trust the model
with the words: every rendered line is read back at native resolution against the copy sheet,
character by character, because a headline with one wrong letter is a listing in a language the
seller cannot read.

## Before you start

| Input | Missing |
|---|---|
| The target marketplace | Ask once: which marketplace (the domain settles the language, the units and the people). Several markets are several runs |
| The shipped gallery | Say which product, or which frames |
| The claims behind the headlines | The brief and `selling-points.md` hold them. A headline the brief does not back is not translated, it is flagged: the English frame carries a claim the factory never approved |
| A native reader | Not a machine input. Say to the owner, once, that the copy sheet should be read by someone who reads the language before the `high` run, and offer the sheet in a form they can forward |

## Process

### 1. Transcribe the English frames

OPEN every shipped frame and write `localized/[market]/copy.md`: one section per frame, every
piece of text on it transcribed exactly (headline, sub-line, labels, callouts, units, numbers),
with its position (top left, under the product, on the tag) and its size class (headline,
label, fine print). A frame with no text is listed as `no text: image passes through unchanged`
and is COPIED, not regenerated, unless the owner asked for a recast person.

### 2. Write the target copy

Under each transcription, the target-language line, written by Wonka with the same job in mind,
not word for word: a German headline runs longer, a Japanese one shorter, and the frame's space
is what it is. Rules: the meaning of the approved claim, never a new claim; the same number of
lines as the English where the space allows, fewer when it does not; units converted only where
the frame displays them (inches to cm, oz to g, °F to °C) with the converted figure computed and
shown in the sheet; brand names and product names unchanged; no idiom that needs a native
reader to rescue it. Mark every line whose length grew by more than a third, because the model
will shrink the type to fit and a shrunk headline fails the squint test.

**People.** Default: the person stays. If the owner asks for the cast to match the market, write
one line per frame with a person: the recast (age band and look, from the persona for that
market if the owner has one, else the same persona), and say the face changes, the pose and the
product do not.

### 3. Write the jobs

`factory/Products/[product]/localized/[market]/jobs.json` (paths inside relative to the file: `out_dir` `.`, `source` `../../final/gallery/[frame]`): one EDIT job per frame with text (`source` = the English frame),
**`refs` EMPTY**, `quality` `low`, `cap_usd` 2. The source frame is the product's identity here;
sending the reference sheet beside it made the model composite the sheet's panels INTO the frame
(measured 16.9.2026 on the ten-tools packshot). A text edit carries no reference. The prompt, per frame:

> Keep this exact image: same product, same composition, same colours, same lighting, same
> layout. Replace every piece of text with the following, in the same positions and the same
> style: [each line, quoted, with its position]. The text must be rendered exactly as written,
> in [language], with correct diacritics. Change nothing else. [If recasting: Replace the person
> with [description]; keep the pose, the hands on the product and the product itself identical.]

Say the cost line, then from the factory root `python3 .claude/pack/engine.py run factory/Products/[product]/localized/[market]/jobs.json`.

### 4. Proofread at native resolution, every line

This is the step that makes the skill worth having. OPEN every output at full size, crop each
text region at 2x with PIL, and compare it character by character to `copy.md`. Diacritics,
umlauts, the ß, the accents, every digit of every converted unit. A frame passes only when
every line matches. Write into each job: `stage_ready`, and a `verdict` that quotes any line that
rendered wrong.

A wrong line gets ONE regeneration with the exact rendered error named in the prompt ("the
headline rendered as 'Teakholz-Set 10 Teile' with a missing umlaut; render 'Teakholz-Set, 10
Teile' exactly"). A second miss is flagged `not stage ready`, and the owner's designer gets the
copy sheet for that one frame. Never ship a frame with a wrong word to save a dollar.

Then the squint: build the strip for the localized set with `python3 .claude/pack/strip.py`
and read it at thumbnail size. A headline that grew and shrank below legibility is a copy
problem: shorten the line in `copy.md` and regenerate that frame.

### 5. Sheet, copy sheet, hand-off

`python3 .claude/pack/engine.py sheet factory/Products/[product]/localized/[market]/jobs.json`. Open it. `copy.md` is the
second deliverable: the owner can forward it to a native reader before the `high` run.

## What you tell the owner

The market and language, how many frames were rebuilt and how many passed through unchanged, the
lines that rendered wrong and what happened to them, the converted units listed, the cost, and
the two paths. Say once that a native read of `copy.md` before the `high` run is worth the ten
minutes, and that the English frames are untouched.

## Definition of done

- `copy.md` holds every English line transcribed from the frames and every target line beside it, with unit conversions computed.
- Every output was proofread at native resolution, line by line; no frame marked ready carries a wrong character.
- The set was read at thumbnail size; no headline shrank below legibility.
- The English frames were not modified.
- `status.md` carries the row.

## Update status.md

```
| Localized ([market]) | done | localized/[market]/ | [date] | [n] frames rebuilt, [n] passed through, [n] flagged for a designer, about $[x] |
```

## Wonka lines

- "The picture stays. The words move house. And every one of them gets read twice before it ships."
- On a wrong umlaut: "Beautiful frame, one dot missing. In Germany that dot is the difference between a word and a typo. Once more."
- On a claim the brief never approved: "That headline was never in the recipe. I will not translate a promise nobody checked."

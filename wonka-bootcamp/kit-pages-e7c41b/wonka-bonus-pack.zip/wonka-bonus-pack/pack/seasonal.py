#!/usr/bin/env python3
"""seasonal.py | The seasonal engine behind /santa and /seasons.

A season happens AROUND the product, never TO it. The Christmas prompt is Jay's tested
prompt, byte for byte (santa.py, 5.9.2026). Every other season is built on the same
skeleton with its own vocabulary, so the rules that made Christmas work (product
untouched, no filter, few props far from the product, never darker, photoreal) hold
for Valentine's, Mother's Day, Halloween and the rest.

Subcommands (the run folder is the last argument):

  seasons                                    list the seasons and their vocabulary
  fetch  <ASIN|URL|folder> --out DIR [--no-main] [--title T]
                                             copy or download the gallery to originals/
  list   <DIR>                               print originals, write the plan.json template
  generate <DIR> --season S [--only NAME] [--cap USD]
                                             gpt-image-2 images.edit on every "transform"
  regen  <DIR> <NAME> --season S [--note TEXT]   the one allowed retry
  check  <DIR>                               mean brightness before vs after (flags > 8% darker)
  sheet  <DIR> --season S                    contact-sheet.html + report.md

Env: OPENAI_API_KEY (else ./.env in the kit folder), QUALITY (low default), WORKERS (4).
No retries against Amazon. No retries against OpenAI. One attempt per image, by design.
"""
import argparse
import base64
import html
import io
import json
import os
import re
import shutil
import threading
import subprocess
import sys
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

UA = ("Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36")

# Jay's Christmas prompt. Do not edit a word of it; it is the tested one.
CHRISTMAS_TEMPLATE = (
    "Create a clean premium Christmas version of this exact image. "
    "Keep the original photo fully intact with no changes to people, faces, clothing, poses, "
    "hands, product shape, materials, colors, lighting, shadows, depth, or camera angle. "
    "Keep every existing headline, label and graphic element exactly as written. "
    "Add only subtle realistic holiday accents that fit naturally. Use warm lights, soft bokeh, "
    "light garland, small greenery, candles, or wrapped gift boxes: at most three added props in total, "
    "placed on an existing surface at the far side from the product, never next to it. "
    "Do not add Christmas trees unless the scene is clearly a home living room. In a living room "
    "you may add one realistic tree placed naturally. In any other location do not add any trees. "
    "All additions must match the real lighting, shadows, and color tones. "
    "Keep everything photorealistic with no cartoon items, fake sparkles, snow overlays, glitter, "
    "or floating objects. No snow on the ground or on objects; snow may appear only as a view through a window. "
    "If adults appear you may add one natural red Santa hat to one adult. The hat must match head "
    "shape, shadow, and lighting. "
    "If the image includes graphic elements you may add soft Christmas graphics or elements. "
    "Nothing may be placed on or touching the product. "
    "The result should look naturally decorated for Christmas. Warm, elegant and subtle.\n"
    "Scene notes for this image: {scene}"
)

# The skeleton every other season is built on. Same bones as the Christmas prompt.
GENERIC_TEMPLATE = (
    "Create a clean premium {name} version of this exact image. "
    "Keep the original photo fully intact with no changes to people, faces, clothing, poses, "
    "hands, product shape, materials, colors, lighting, shadows, depth, or camera angle. "
    "Keep every existing headline, label and graphic element exactly as written. "
    "Add only subtle realistic {name} accents that fit naturally. Use {vocabulary}: at most "
    "three added props in total, placed on an existing surface at the far side from the product, "
    "never next to it. {extra} "
    "All additions must match the real lighting, shadows, and color tones. "
    "Keep everything photorealistic with no cartoon items, fake sparkles, glitter, confetti "
    "overlays, or floating objects. No color filter or tint over the image. "
    "If the image includes graphic elements you may add soft {name} graphics or elements. "
    "Nothing may be placed on or touching the product. "
    "The result should look naturally set for {name}. {mood}\n"
    "Scene notes for this image: {scene}"
)

SEASONS = {
    "christmas": {"name": "Christmas", "template": CHRISTMAS_TEMPLATE},
    "valentines": {"name": "Valentine's Day",
                   "vocabulary": "a few fresh red or pink roses in a vase, one small wrapped gift, a lit candle, soft warm bokeh",
                   "extra": "No hearts drawn on surfaces, no rose petals scattered on the product's surface, no lipstick marks.",
                   "mood": "Warm, romantic and understated."},
    "mothers-day": {"name": "Mother's Day",
                    "vocabulary": "a small bouquet of fresh flowers in a vase, a handwritten card standing closed, a cup of tea or coffee, soft morning light",
                    "extra": "No printed text on the card may be readable. No balloons.",
                    "mood": "Gentle, bright and loving."},
    "fathers-day": {"name": "Father's Day",
                    "vocabulary": "one small wrapped gift with a plain ribbon, a folded newspaper or a book, a mug of coffee, warm daylight",
                    "extra": "No printed text may be readable on the newspaper or book. No balloons, no banners.",
                    "mood": "Warm, calm and confident."},
    "easter": {"name": "Easter",
               "vocabulary": "a few pastel dyed eggs in a small bowl or basket, fresh spring flowers such as tulips or daffodils, soft spring daylight",
               "extra": "No cartoon rabbits, no plastic grass. Eggs only in a bowl or basket, never loose near the product.",
               "mood": "Fresh, light and bright."},
    "halloween": {"name": "Halloween",
                  "vocabulary": "one or two small real pumpkins, warm string lights, a lit candle in a glass, a few autumn leaves on the far surface",
                  "extra": "No carved faces on the pumpkins unless the scene is clearly a home porch or living room. No cobwebs, skeletons, fake blood or masks. Keep the image bright, never moody or dark.",
                  "mood": "Warm, autumnal and friendly, never spooky."},
    "thanksgiving": {"name": "Thanksgiving",
                     "vocabulary": "a small arrangement of autumn leaves and mini pumpkins, a lit candle, warm amber light, a linen napkin on the far side of the table",
                     "extra": "No turkey, no full dinner spread, no crowd added to the scene.",
                     "mood": "Warm, abundant and calm."},
    "fourth-of-july": {"name": "Fourth of July",
                       "vocabulary": "a small folded American flag or a single bunting on the far wall, red and blue enamel mugs, a picnic blanket edge, bright summer daylight",
                       "extra": "No fireworks in the sky unless the scene is clearly outdoors at night, and then only small and far. No flag draped on or near the product.",
                       "mood": "Bright, summery and relaxed."},
    "back-to-school": {"name": "Back to School",
                       "vocabulary": "a stack of two or three notebooks, a pencil cup, an apple, a small backpack leaning far from the product, bright morning light",
                       "extra": "No readable text on the notebooks. No chalkboard writing.",
                       "mood": "Fresh, organised and bright."},
    "summer": {"name": "Summer",
               "vocabulary": "bright sunlight, a glass of iced lemonade or water with lemon on the far side, a few fresh citrus fruits, a light linen cloth, green leaves in the bokeh",
               "extra": "No beach props indoors. No sunglasses on or near the product.",
               "mood": "Bright, airy and fresh."},
    "new-year": {"name": "New Year",
                 "vocabulary": "two champagne flutes on the far side of the surface, soft golden bokeh lights, a single small sparkler already lit and far from the product, one elegant clock or a folded party napkin",
                 "extra": "No confetti on the surface, no glitter, no readable year numbers anywhere.",
                 "mood": "Elegant, golden and celebratory but calm."},
}

RATE_TEXT_IN = 5.0 / 1_000_000
RATE_IMAGE_IN = 10.0 / 1_000_000
RATE_IMAGE_OUT = 40.0 / 1_000_000
FLAT_PER_IMAGE = {"low": 0.011, "medium": 0.042, "high": 0.167}
DEFAULT_CAP_USD = 2.0   # what /santa and /seasons promise per run when nobody passes --cap
WORST_PER_IMAGE = {"low": 0.03, "medium": 0.09, "high": 0.30}


def log(msg):
    print(msg, flush=True)


def season_spec(key, notes=None):
    """The season record, or a custom one built from --season custom --notes '...'."""
    key = (key or "").strip().lower()
    if key == "custom":
        if not notes:
            raise ValueError("a custom season needs --notes with its vocabulary, e.g. "
                             "--notes 'Diwali: small clay lamps, marigold garlands, warm light'")
        name, _, vocab = notes.partition(":")
        return {"name": name.strip() or "the occasion", "vocabulary": (vocab or notes).strip(),
                "extra": "", "mood": "Warm, elegant and subtle."}
    if key not in SEASONS:
        raise ValueError("unknown season %r; one of: %s, custom" % (key, ", ".join(SEASONS)))
    return SEASONS[key]


def build_prompt(season, scene):
    spec = season_spec(season["key"], season.get("notes")) if isinstance(season, dict) else season_spec(season)
    if "template" in spec:
        return spec["template"].format(scene=scene.strip())
    return GENERIC_TEMPLATE.format(name=spec["name"], vocabulary=spec["vocabulary"],
                                   extra=spec["extra"], mood=spec["mood"], scene=scene.strip())


def asin_from(text):
    m = re.search(r"(?:/dp/|/gp/product/|/product/)([A-Z0-9]{10})", text)
    if m:
        return m.group(1)
    m = re.fullmatch(r"[A-Z0-9]{10}", text.strip())
    return m.group(0) if m else None


def load_key():
    if os.environ.get("OPENAI_API_KEY"):
        return os.environ["OPENAI_API_KEY"]
    env = Path(".env")
    if env.exists():
        for line in env.read_text().splitlines():
            if line.startswith("OPENAI_API_KEY="):
                return line.split("=", 1)[1].strip().strip('"').strip("'")
    return None


def image_size(path):
    try:
        from PIL import Image
        with Image.open(path) as im:
            return im.size
    except Exception:  # noqa: BLE001
        return (0, 0)


def api_size_for(w, h):
    if w == 0 or h == 0:
        return "1024x1024"
    r = w / h
    if r > 1.2:
        return "1536x1024"
    if r < 0.83:
        return "1024x1536"
    return "1024x1024"


def read_plan(run):
    p = Path(run) / "plan.json"
    if not p.exists():
        sys.exit("plan.json missing in %s. Wonka writes it after looking at originals/." % run)
    return json.loads(p.read_text())


def write_plan(run, plan):
    (Path(run) / "plan.json").write_text(json.dumps(plan, indent=2, ensure_ascii=False))


# cost.jsonl is APPENDED by every worker and REWRITTEN by mark_delivered, and
# Path.write_text truncates before it writes. Measured 20.9.2026 with the default four
# workers: a reader that lands inside that window sees an empty file, rebuilds it from
# nothing, and erases every receipt taken so far. Worst observed: 24 of 24 gone, a
# ledger reporting $0.31 against $1.07 actually spent. engine.py has the same lock for
# the same reason. Never touch this file outside it.
_RECEIPT_LOCK = threading.Lock()


def append_cost(run, entry):
    with _RECEIPT_LOCK:
        with open(Path(run) / "cost.jsonl", "a") as f:
            f.write(json.dumps(entry) + "\n")


def read_costs(run):
    p = Path(run) / "cost.jsonl"
    if not p.exists():
        return []
    return [json.loads(l) for l in p.read_text().splitlines() if l.strip()]


def mark_delivered(run, filename):
    """Flip the last receipt for this frame once its file is really on disk."""
    p = Path(run) / "cost.jsonl"
    with _RECEIPT_LOCK:
        try:
            rows = [json.loads(l) for l in p.read_text().splitlines() if l.strip()]
        except (OSError, ValueError):
            return
        for row in reversed(rows):
            if row.get("file") == filename and row.get("delivered") is False:
                row["delivered"] = True
                break
        p.write_text("".join(json.dumps(r) + "\n" for r in rows))


# ---------------------------------------------------------------- fetch
def curl(url, out=None, timeout=30):
    cmd = ["curl", "-sL", "--max-time", str(timeout), "-A", UA,
           "-H", "Accept-Language: en-US,en;q=0.9", "--compressed", url]
    if out:
        r = subprocess.run(cmd + ["-o", str(out)], capture_output=True)
        return r.returncode == 0
    r = subprocess.run(cmd, capture_output=True)
    return r.stdout.decode("utf-8", "ignore") if r.returncode == 0 else ""


def parse_listing(page):
    title = ""
    m = re.search(r'id="productTitle"[^>]*>\s*(.*?)\s*<', page, re.S)
    if m:
        title = html.unescape(m.group(1)).strip()
    urls = []
    for key in ("hiRes", "large"):
        for u in re.findall(r'"%s"\s*:\s*"(https://[^"]+)"' % key, page):
            u = u.replace("\\/", "/")
            if ("images-amazon" in u or "media-amazon" in u) and u not in urls:
                urls.append(u)
        if urls:
            break
    return [u for u in urls if "/images/I/" in u and not u.endswith(".gif")], title


def blocked(page):
    return (not page) or ("api-services-support@amazon.com" in page) or \
        ("Type the characters you see" in page) or ("captcha" in page.lower() and "productTitle" not in page)


def download_gallery(urls, originals):
    """The image CDN, one attempt per file, never a retry. Shared by both fetch routes so
    the Genrupt one and the direct one write the same filenames."""
    ok = 0
    for i, u in enumerate(urls, 1):
        dest = originals / ("%02d%s" % (i, ".png" if u.lower().endswith(".png") else ".jpg"))
        if dest.exists() and dest.stat().st_size > 5000:
            ok += 1
            continue
        good = curl(u, dest, timeout=60) and dest.exists() and dest.stat().st_size > 5000
        if good:
            ok += 1
            log("  %s  %d KB" % (dest.name, dest.stat().st_size // 1024))
        else:
            log("  %s  FAILED (not retrying)" % dest.name)
            if dest.exists():
                dest.unlink()
    return ok


def cmd_fetch(a):
    if not a.files and not a.source:
        sys.exit("fetch needs an ASIN, a URL, a folder, or --files")
    if a.files:
        run = Path(a.out) if a.out else Path.cwd() / "seasonal" / "gallery"
        originals = run / "originals"
        originals.mkdir(parents=True, exist_ok=True)
        n = 0
        for i, f in enumerate(a.files, 1):
            f = Path(os.path.expanduser(f))
            if not f.exists():
                sys.exit("not on disk: %s" % f)
            shutil.copy(f, originals / ("%02d-%s" % (i, f.name)))
            n += 1
        (run / "listing.json").write_text(json.dumps(
            {"asin": a.title or "gallery", "title": a.title or "gallery", "source": "files",
             "images": n, "has_main": not a.no_main}, indent=2))
        log("Staged %d frames into %s" % (n, originals))
        return
    src_path = Path(os.path.expanduser(a.source))
    if src_path.is_dir():
        run = Path(a.out) if a.out else Path.cwd() / "seasonal" / src_path.name
        originals = run / "originals"
        originals.mkdir(parents=True, exist_ok=True)
        n = 0
        for p in sorted(src_path.iterdir()):
            if p.suffix.lower() in (".jpg", ".jpeg", ".png", ".webp") and "-rejected" not in p.stem:
                shutil.copy(p, originals / p.name)
                n += 1
        (run / "listing.json").write_text(json.dumps(
            {"asin": src_path.name, "title": a.title or src_path.name, "source": "folder",
             "folder": str(src_path), "images": n, "has_main": not a.no_main}, indent=2))
        log("Copied %d images from %s to %s" % (n, src_path, originals))
        if n < (1 if a.no_main else 2):
            sys.exit("Not enough images to transform.")
        return
    asin = asin_from(a.source)
    if not asin:
        sys.exit("Not an ASIN, Amazon URL or folder: %s" % a.source)
    run = Path(a.out) if a.out else Path.cwd() / "seasonal" / asin
    originals = run / "originals"
    originals.mkdir(parents=True, exist_ok=True)
    if getattr(a, "urls", None):
        # The kit's tool order: Genrupt named the images, so nothing here reads the live
        # amazon.com page. Only the image CDN is touched, and that one is not blocked.
        meta = {}
        if getattr(a, "meta", None):
            meta.update(json.loads(Path(os.path.expanduser(a.meta)).read_text()))
        urls = list(a.urls)
        (run / "listing.json").write_text(json.dumps(
            {"asin": asin, "title": a.title or meta.get("title", ""), "source": "genrupt scrape",
             "image_urls": urls, "has_main": not a.no_main, **meta}, indent=2, ensure_ascii=False))
        ok = download_gallery(urls, originals)
        log("Downloaded %d/%d to %s" % (ok, len(urls), originals))
        if ok < (1 if a.no_main else 2):
            sys.exit(2)
        return
    if not getattr(a, "allow_direct_fetch", False):
        log("\nNOT fetching amazon.com directly. This route was measured BLOCKED on the first")
        log("attempt (16.9.2026), and retrying gets the IP banned. Use the kit's tool order:")
        log("")
        log("  1. Genrupt MCP: scrape_video_reference_images_from_asin {asin: \"%s\", maxImages: 9}" % asin)
        log("  2. python3 seasonal.py fetch %s --urls [the referenceImageUrls] --out %s" % (asin, run))
        log("")
        log("Or point it at a folder of the images, or pass --files. If you really want the")
        log("live page read anyway, add --allow-direct-fetch and accept one attempt.")
        sys.exit(2)
    url = "https://www.amazon.com/dp/%s" % asin
    log("Fetching %s (one attempt, no retries)" % url)
    page = curl(url)
    (run / "page.html").write_text(page)
    if blocked(page):
        log("\nAMAZON FETCH BLOCKED OR EMPTY. This skill will not retry (retries get IPs blocked).")
        log("Fallback: point it at a folder of the listing images: fetch /path/to/images --out %s" % run)
        sys.exit(2)
    urls, title = parse_listing(page)
    (run / "listing.json").write_text(json.dumps({"asin": asin, "title": title, "source": url,
                                                 "image_urls": urls, "has_main": True}, indent=2, ensure_ascii=False))
    log("Title: %s" % title[:90])
    if len(urls) < 2:
        sys.exit(2)
    ok = download_gallery(urls, originals)
    log("Downloaded %d/%d to %s" % (ok, len(urls), originals))
    if ok < 2:
        sys.exit(2)


# ---------------------------------------------------------------- list
def cmd_list(a):
    run = Path(a.run)
    originals = run / "originals"
    files = sorted(p for p in originals.iterdir() if p.suffix.lower() in (".jpg", ".jpeg", ".png", ".webp"))
    listing = json.loads((run / "listing.json").read_text()) if (run / "listing.json").exists() else {}
    for p in files:
        w, h = image_size(p)
        log("%s  %dx%d  -> %s" % (p.name, w, h, api_size_for(w, h)))
    if not (run / "plan.json").exists():
        write_plan(run, {"asin": listing.get("asin", run.name), "title": listing.get("title", ""),
                         "has_main": listing.get("has_main", True),
                         "images": [{"file": p.name, "role": "TODO", "action": "TODO", "scene": "", "reason": ""}
                                    for p in files]})
        log("\nWrote plan.json template. Fill role (main|lifestyle|packshot|infographic|logo), "
            "action (transform|skip), scene, reason.%s"
            % ("" if listing.get("has_main", True) else " This folder holds NO main image: every frame may transform."))


# ---------------------------------------------------------------- generate
def edit_one(client, src, dest, prompt, quality, run):
    w, h = image_size(src)
    size = api_size_for(w, h)
    t0 = time.time()
    try:
        with open(src, "rb") as fh:
            r = client.images.edit(model="gpt-image-2", image=[fh], prompt=prompt, size=size, quality=quality, n=1)
        # PAID. The receipt goes down before the write, so a failed write cannot hide a
        # real charge from the next run's cap (the engine.py rule, measured 20.9.2026).
        usage = getattr(r, "usage", None)
        entry = {"file": src.name, "size": size, "quality": quality,
                 "seconds": round(time.time() - t0, 1), "delivered": False}
        if usage:
            det = getattr(usage, "input_tokens_details", None)
            entry["text_tokens"] = getattr(det, "text_tokens", 0) if det else 0
            entry["image_tokens"] = getattr(det, "image_tokens", 0) if det else 0
            entry["output_tokens"] = getattr(usage, "output_tokens", 0)
            entry["usd_est"] = round(entry["text_tokens"] * RATE_TEXT_IN + entry["image_tokens"] * RATE_IMAGE_IN
                                     + entry["output_tokens"] * RATE_IMAGE_OUT, 4)
        else:
            entry["usd_est"] = FLAT_PER_IMAGE.get(quality, 0.011)
        append_cost(run, entry)
        d = r.data[0]
        dest.write_bytes(base64.b64decode(d.b64_json))
        mark_delivered(run, src.name)
        log("  %s -> %s  (%ss, est $%.3f)" % (src.name, dest.name, entry["seconds"], entry["usd_est"]))
        return True
    except Exception as e:  # noqa: BLE001
        msg = str(e)
        if "moderation" in msg.lower() or "safety" in msg.lower():
            log("  %s: BLOCKED by moderation, skipping (no retry)" % src.name)
        else:
            log("  %s: FAILED %s" % (src.name, msg[:200]))
        return False


def run_generate(run, season, only=None, cap=None):
    # CONTRACT rule 4: a paid run always carries a cap. Measured 20.9.2026: --cap defaulted
    # to None and the gate below was `if cap is not None`, so a run without the flag had no
    # ceiling. The skills write `--cap 2` in prose; prose is not a cap.
    q = os.getenv("QUALITY", "low")
    if q not in WORST_PER_IMAGE:
        sys.exit("QUALITY=%r is not one of: %s. An unknown value used to be priced as high by "
                 "the cap and as low by the receipt, so the two disagreed."
                 % (q, ", ".join(sorted(WORST_PER_IMAGE))))
    if cap is None:
        cap = DEFAULT_CAP_USD
        log("no --cap given, using the default $%.2f. Raise it with --cap." % cap)
    key = load_key()
    if not key:
        sys.exit("OPENAI_API_KEY missing: export it, or put OPENAI_API_KEY=... in the kit's .env "
                 "(guides/mcp-setup-guide.md, Part 2).")
    try:
        from openai import OpenAI
    except ImportError:
        sys.exit("openai package missing. Fix: python3 -m pip install openai")
    client = OpenAI(api_key=key)
    quality = os.getenv("QUALITY", "low")
    workers = int(os.getenv("WORKERS", "4"))
    plan = read_plan(run)
    outdir = run / season["folder"]
    outdir.mkdir(exist_ok=True)
    jobs = []
    for img in plan["images"]:
        if img.get("action") != "transform" or (only and img["file"] != only):
            continue
        src = run / "originals" / img["file"]
        dest = outdir / (Path(img["file"]).stem + ".png")
        if dest.exists() and dest.stat().st_size > 10000:
            log("  %s exists, skipping" % dest.name)
            continue
        if not img.get("scene"):
            log("  %s: no scene line in plan.json, skipping" % img["file"])
            continue
        jobs.append((src, dest, build_prompt(season, img["scene"])))
    if not jobs:
        log("Nothing to generate.")
        return
    spent = sum(c.get("usd_est", 0) for c in read_costs(run))
    if cap is not None:  # always true; run_generate fills the default before this point
        worst = WORST_PER_IMAGE.get(quality, 0.3)
        fit = int(max(0, (cap - spent)) // worst)
        if fit < len(jobs):
            log("CAP: $%.2f allows %d of %d images at %s (worst case $%.2f each, $%.2f already spent). "
                "The rest wait for a bigger cap." % (cap, fit, len(jobs), quality, worst, spent))
            jobs = jobs[:fit]
            if not jobs:
                return
    log("Generating %d images (%s, gpt-image-2 edit, quality=%s, workers=%d)" % (len(jobs), season["name"], quality, workers))
    done = 0
    with ThreadPoolExecutor(max_workers=workers) as ex:
        for f in as_completed([ex.submit(edit_one, client, s, d, p, quality, run) for s, d, p in jobs]):
            done += bool(f.result())
    log("%d/%d generated into %s" % (done, len(jobs), outdir))


def resolve_season(a):
    spec = season_spec(a.season, getattr(a, "notes", None))
    key = a.season.strip().lower()
    folder = re.sub(r"[^a-z0-9]+", "-", (spec["name"] if key == "custom" else key).lower()).strip("-")
    return {"key": key, "name": spec["name"], "folder": folder, "notes": getattr(a, "notes", None)}


def cmd_generate(a):
    run_generate(Path(a.run), resolve_season(a), only=a.only, cap=a.cap)


def cmd_regen(a):
    run = Path(a.run)
    season = resolve_season(a)
    plan = read_plan(run)
    hit = next((i for i in plan["images"] if i["file"] == a.name), None)
    if not hit:
        sys.exit("%s not in plan.json" % a.name)
    if hit.get("regenerated"):
        sys.exit("%s was already regenerated once. The rule is one retry. Report it instead." % a.name)
    if a.note:
        hit["scene"] = hit["scene"].rstrip(". ") + ". " + a.note.strip()
    # Do the work FIRST. This used to mark the retry spent and move the delivered image
    # aside before generating, so a cap refusal (or any failure, which edit_one swallows)
    # left the owner with no <stem>.png at all, while check and sheet look only for that
    # name. Measured 20.9.2026.
    dest = run / season["folder"] / (Path(a.name).stem + ".png")
    kept = run / season["folder"] / (Path(a.name).stem + ".attempt1.png")
    had = dest.exists()
    if had:
        shutil.move(dest, kept)
    run_generate(run, season, only=a.name, cap=a.cap)
    if not dest.exists():
        if had:
            shutil.move(kept, dest)
        log("nothing was generated, so the retry is NOT spent and your image is untouched. "
            "Read the line above: usually the cap, or a moderation block.")
        return 1
    hit["regenerated"] = True
    write_plan(run, plan)
    return 0


# ---------------------------------------------------------------- check
def mean_luma(path):
    from PIL import Image, ImageStat
    with Image.open(path) as im:
        im = im.convert("L")
        im.thumbnail((256, 256))
        return ImageStat.Stat(im).mean[0]


def cmd_check(a):
    run = Path(a.run)
    season = resolve_season(a)
    plan = read_plan(run)
    flagged = 0
    for img in plan["images"]:
        if img.get("action") != "transform":
            continue
        src = run / "originals" / img["file"]
        dest = run / season["folder"] / (Path(img["file"]).stem + ".png")
        if not dest.exists():
            log("%s: no output" % img["file"])
            continue
        x, y = mean_luma(src), mean_luma(dest)
        delta = (y - x) / max(x, 1) * 100
        flag = "  <-- DARKER, check it" if delta < -8 else ""
        flagged += bool(flag)
        log("%s: brightness %.0f -> %.0f (%+.0f%%)%s" % (img["file"], x, y, delta, flag))
    log("%d flagged. The eye pass (product shape, props, text) is still yours." % flagged)


# ---------------------------------------------------------------- sheet
def thumb_b64(path, max_px=900):
    try:
        from PIL import Image
        with Image.open(path) as im:
            im = im.convert("RGB")
            im.thumbnail((max_px, max_px))
            buf = io.BytesIO()
            im.save(buf, "JPEG", quality=82)
            return "data:image/jpeg;base64," + base64.b64encode(buf.getvalue()).decode()
    except Exception:  # noqa: BLE001
        return ""


def cmd_sheet(a):
    run = Path(a.run)
    season = resolve_season(a)
    plan = read_plan(run)
    costs = read_costs(run)
    total = sum(c.get("usd_est", 0) for c in costs)
    title = plan.get("title") or run.name
    rows = []
    for img in plan["images"]:
        src = run / "originals" / img["file"]
        dest = run / season["folder"] / (Path(img["file"]).stem + ".png")
        b = thumb_b64(src)
        if img.get("action") == "transform" and dest.exists():
            after = '<a href="%s/%s" target="_blank"><img src="%s" alt="after"></a>' % (season["folder"], dest.name, thumb_b64(dest))
        else:
            after = '<div class="skip">Skipped<br><small>%s</small></div>' % html.escape(img.get("reason", ""))
        verdict = html.escape(img.get("verdict", ""))
        badge = ""
        if img.get("stage_ready") is True:
            badge = '<span class="badge ok">stage ready</span>'
        elif img.get("stage_ready") is False:
            badge = '<span class="badge no">not stage ready</span>'
        rows.append("""
<section class="row"><header><strong>%s</strong> <span class="role">%s</span> %s</header>
<div class="pair"><figure><img src="%s" alt="before"><figcaption>Before</figcaption></figure><figure>%s<figcaption>After</figcaption></figure></div>%s</section>"""
                    % (html.escape(img["file"]), html.escape(img.get("role", "")), badge, b, after,
                       ('<p class="verdict">%s</p>' % verdict) if verdict else ""))
    page = """<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>%s: %s</title><style>
body{margin:0;background:#faf7f2;color:#222;font:15px/1.5 -apple-system,Segoe UI,Helvetica,Arial,sans-serif}
.wrap{max-width:1180px;margin:0 auto;padding:28px 20px 60px}h1{font-size:22px;margin:0 0 4px}.sub{color:#666;margin:0 0 24px}
.row{background:#fff;border:1px solid #e8e2d8;border-radius:12px;padding:16px;margin-bottom:22px}.row header{margin-bottom:10px}.role{color:#888;margin-left:8px;font-size:13px}
.pair{display:grid;grid-template-columns:1fr 1fr;gap:14px}figure{margin:0}figure img{width:100%%;height:auto;border-radius:8px;display:block;background:#fff}
figcaption{text-align:center;color:#777;font-size:13px;margin-top:6px}
.skip{display:flex;flex-direction:column;gap:6px;align-items:center;justify-content:center;text-align:center;padding:16px;box-sizing:border-box;aspect-ratio:1;border:2px dashed #ddd;border-radius:8px;color:#888}
.badge{font-size:12px;padding:2px 8px;border-radius:999px;margin-left:8px}.badge.ok{background:#e3f5e6;color:#1d6b2c}.badge.no{background:#fde8e6;color:#a12a20}
.verdict{margin:10px 0 0;color:#444;font-size:14px}.foot{color:#666;font-size:13px;margin-top:30px}
@media(max-width:640px){.pair{grid-template-columns:1fr}}
</style></head><body><div class="wrap"><h1>%s</h1><p class="sub">%s &middot; before / after</p>%s
<p class="foot">Estimated generation cost for this run: $%.3f. Main image untouched per Amazon policy.</p></div></body></html>""" % (
        html.escape(season["name"]), html.escape(title), html.escape(title), html.escape(season["name"]), "".join(rows), total)
    (run / "contact-sheet.html").write_text(page)
    t = [i for i in plan["images"] if i.get("action") == "transform"]
    s = [i for i in plan["images"] if i.get("action") != "transform"]
    lines = ["# %s report: %s" % (season["name"], title), "",
             "Transformed: %d. Skipped: %d. Total images: %d." % (len(t), len(s), len(plan["images"])), "", "## Transformed"]
    for i in t:
        ready = "stage ready" if i.get("stage_ready") else ("NOT stage ready" if i.get("stage_ready") is False else "unjudged")
        lines.append("- %s (%s): %s%s. %s" % (i["file"], i.get("role", ""), ready, " (regenerated once)" if i.get("regenerated") else "", i.get("verdict", "")))
    lines += ["", "## Skipped"] + ["- %s (%s): %s" % (i["file"], i.get("role", ""), i.get("reason", "")) for i in s]
    lines += ["", "## Cost", "- API calls: %d. Estimated total: $%.3f." % (len(costs), total) if costs else "- No API calls recorded.",
              "", "Outputs: %s/ (PNG, 1024 px class). Contact sheet: contact-sheet.html." % season["folder"]]
    (run / "report.md").write_text("\n".join(lines) + "\n")
    log("Wrote %s and report.md (est $%.3f)" % (run / "contact-sheet.html", total))


def cmd_seasons(a):
    for k, v in SEASONS.items():
        log("%-16s %s" % (k, "Jay's tested Christmas prompt, verbatim" if "template" in v else v["vocabulary"]))
    log("%-16s %s" % ("custom", "--notes 'Name: vocabulary'"))


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)
    f = sub.add_parser("fetch"); f.add_argument("source", nargs="?"); f.add_argument("--out"); f.add_argument("--title")
    f.add_argument("--files", nargs="+", help="explicit frames in order (the factory's resolved gallery)")
    f.add_argument("--no-main", action="store_true", help="the folder holds no main image; every frame may transform")
    f.add_argument("--urls", nargs="+", help="image URLs from scrape_video_reference_images_from_asin; "
                                             "the kit's tool order, and the route that is not blocked")
    f.add_argument("--meta", help="json with title/price/rating/bullets, from the market analysis")
    f.add_argument("--allow-direct-fetch", action="store_true",
                   help="last resort: read the live amazon.com page with curl. Measured BLOCKED on the "
                        "first attempt, 16.9.2026; ask Genrupt for the URLs instead")
    f.set_defaults(fn=cmd_fetch)
    l = sub.add_parser("list"); l.add_argument("run"); l.set_defaults(fn=cmd_list)
    for name, fn in (("generate", cmd_generate), ("check", cmd_check), ("sheet", cmd_sheet)):
        p = sub.add_parser(name); p.add_argument("run"); p.add_argument("--season", required=True)
        p.add_argument("--notes"); p.add_argument("--only"); p.add_argument("--cap", type=float); p.set_defaults(fn=fn)
    r = sub.add_parser("regen"); r.add_argument("run"); r.add_argument("name"); r.add_argument("--season", required=True)
    r.add_argument("--notes"); r.add_argument("--note"); r.add_argument("--cap", type=float); r.set_defaults(fn=cmd_regen)
    s = sub.add_parser("seasons"); s.set_defaults(fn=cmd_seasons)
    a = ap.parse_args(argv)
    try:
        a.fn(a)
    except ValueError as e:
        sys.exit("seasonal.py: %s" % e)


if __name__ == "__main__":
    main()

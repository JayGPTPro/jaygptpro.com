#!/usr/bin/env python3
"""refresh_fetch.py | Snapshot a listing's public face, and diff two snapshots.

/refresh asks one question every quarter: what changed out there? This script answers the
part a machine can answer. It fetches a listing page ONCE (no retries, ever: retries get IPs
blocked), records the title, the bullets, the price, the rating, the review count and the
gallery in order, downloads the gallery, and writes a snapshot folder. A later snapshot of
the same ASIN is diffed against it: frames added, removed, replaced, reordered; title and
bullets changed; rating and count moved. Wonka reads the diff and the sheets and does the
thinking.

    python3 refresh_fetch.py snapshot B0XXXXXXXX --out DIR --urls URL1 URL2 ... [--meta meta.json]
                                     # the kit's tool order: image URLs from the Genrupt scrape
                                     # (scrape_video_reference_images_from_asin), title/price/rating
                                     # from the market analysis in meta.json. Amazon is not touched.
    python3 refresh_fetch.py snapshot B0XXXXXXXX --out DIR                 # plain curl, ONE attempt; blocked = exit 2
    python3 refresh_fetch.py snapshot --folder incumbent/ --out DIR         # from files on disk (screenshots, a saved gallery)
    python3 refresh_fetch.py diff OLD_DIR NEW_DIR                                          # prints markdown, exit 0 = no change, 1 = changes

Frames are compared by a small perceptual hash (16x16 grayscale, average threshold), so a
re-encoded copy of the same image reads as unchanged and a new design reads as changed.
Stdlib + Pillow + curl.
"""
import argparse
import html
import hashlib
import json
import re
import shutil
import subprocess
import sys
from pathlib import Path

UA = ("Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36")
IMAGE_EXT = (".jpg", ".jpeg", ".png", ".webp")


def log(m):
    print(m, flush=True)


def curl(url, out=None, timeout=30):
    cmd = ["curl", "-sL", "--max-time", str(timeout), "-A", UA, "-H", "Accept-Language: en-US,en;q=0.9",
           "--compressed", url]
    if out:
        r = subprocess.run(cmd + ["-o", str(out)], capture_output=True)
        return r.returncode == 0
    r = subprocess.run(cmd, capture_output=True)
    return r.stdout.decode("utf-8", "ignore") if r.returncode == 0 else ""


def blocked(page):
    return (not page) or ("api-services-support@amazon.com" in page) or ("Type the characters you see" in page) \
        or ("captcha" in page.lower() and "productTitle" not in page)


def _text(s):
    return html.unescape(re.sub(r"<[^>]+>", " ", s)).strip()


def parse_page(page):
    d = {"title": "", "bullets": [], "price": "", "rating": "", "review_count": "", "image_urls": []}
    m = re.search(r'id="productTitle"[^>]*>\s*(.*?)\s*<', page, re.S)
    if m:
        d["title"] = html.unescape(m.group(1)).strip()
    fb = re.search(r'id="feature-bullets"(.*?)</div>\s*</div>', page, re.S)
    if fb:
        d["bullets"] = [re.sub(r"\s+", " ", _text(b)) for b in re.findall(r'<span class="a-list-item">(.*?)</span>', fb.group(1), re.S)]
        d["bullets"] = [b for b in d["bullets"] if len(b) > 10]
    m = re.search(r'class="a-price[^"]*"[^>]*>.*?<span class="a-offscreen">([^<]+)</span>', page, re.S)
    if m:
        d["price"] = m.group(1).strip()
    m = re.search(r'id="acrPopover"[^>]*title="([^"]+)"', page)
    if m:
        d["rating"] = m.group(1).strip()
    m = re.search(r'id="acrCustomerReviewText"[^>]*>([^<]+)<', page)
    if m:
        d["review_count"] = m.group(1).strip()
    urls = []
    for key in ("hiRes", "large"):
        # the gallery JSON is usually unescaped, but some page variants escape the slashes
        for u in re.findall(r'"%s"\s*:\s*"(https:(?:\\/\\/|//)[^"]+)"' % key, page):
            u = u.replace("\\/", "/")
            if "/images/I/" in u and not u.endswith(".gif") and u not in urls:
                urls.append(u)
        if urls:
            break
    d["image_urls"] = urls
    return d


def phash(path, size=16):
    """Hash of the CONTENT, with the white margin trimmed off first.
    Measured 21.9.2026 on the demo product: the saved main (938x1500) and the CDN copy
    of the same photograph (1707x2560, more white padding around the product) hashed
    whole landed 57 bits apart against a threshold of 24, so the owner's unchanged
    listing was reported as a replaced main and two dropped frames. Amazon frames sit on
    white; what a re-export changes is the margin, so the margin is cut before hashing."""
    from PIL import Image
    with Image.open(path) as im:
        g = im.convert("L")
        # the bounding box of everything darker than near-white; a blank frame keeps itself
        bbox = g.point(lambda v: 255 if v < 235 else 0).getbbox()
        if bbox:
            g = g.crop(bbox)
        px = list(g.resize((size, size)).tobytes())
    avg = sum(px) / len(px)
    return "".join("1" if p > avg else "0" for p in px)


def hamming(a, b):
    return sum(x != y for x, y in zip(a, b))


def write_manifest(out, meta, files):
    frames = []
    for f in files:
        try:
            frames.append({"file": f.name, "hash": phash(f)})
        except Exception as e:  # noqa: BLE001
            frames.append({"file": f.name, "hash": None, "error": str(e)[:80]})
    meta["frames"] = frames
    (out / "snapshot.json").write_text(json.dumps(meta, indent=2, ensure_ascii=False), encoding="utf-8")


def cmd_snapshot(a):
    out = Path(a.out)
    frames_dir = out / "frames"
    frames_dir.mkdir(parents=True, exist_ok=True)
    if a.folder:
        src = Path(a.folder)
        # the kit names the live main `main-live.*` and the gallery `live-NN.*`; alphabetical
        # order would put the main LAST, so anything named main-* leads
        files = sorted((p for p in src.iterdir() if p.suffix.lower() in IMAGE_EXT),
                       key=lambda p: (0 if p.stem.lower().startswith("main") else 1, p.name))
        copied, seen = [], set()
        for p in files:
            # the kit's incumbent/ carries the live main TWICE (main-live.jpg and live-01.jpg,
            # byte-identical). Counted twice, a 5-frame gallery becomes a 6-frame baseline
            # and the first diff invents a removed frame. One copy per distinct file.
            digest = hashlib.md5(p.read_bytes()).hexdigest()
            if digest in seen:
                log("skipping %s: byte-identical to an earlier file" % p.name)
                continue
            seen.add(digest)
            dest = frames_dir / ("%02d%s" % (len(copied) + 1, p.suffix.lower()))
            shutil.copy(p, dest)
            copied.append(dest)
        write_manifest(out, {"source": "folder", "folder": str(src), "asin": a.asin or src.name,
                             "title": a.title or "", "bullets": [], "price": "", "rating": "", "review_count": ""}, copied)
        log("snapshot from folder: %d frames -> %s" % (len(copied), out))
        return 0
    if not a.asin:
        sys.exit("snapshot needs an ASIN or --folder")
    if a.urls:
        # The Genrupt route: the URLs came from the scrape tool, the facts from the market
        # analysis. Nothing here touches amazon.com except the image CDN.
        meta = {"title": "", "bullets": [], "price": "", "rating": "", "review_count": ""}
        if a.meta:
            meta.update(json.loads(Path(a.meta).read_text(encoding="utf-8")))
        meta.update({"source": "genrupt scrape", "asin": a.asin, "image_urls": list(a.urls)})
        files = []
        for i, u in enumerate(a.urls, 1):
            dest = frames_dir / ("%02d%s" % (i, ".png" if u.lower().endswith(".png") else ".jpg"))
            ok = curl(u, dest, timeout=60) and dest.exists() and dest.stat().st_size > 5000
            if ok:
                files.append(dest)
            else:
                log("  %s FAILED (not retrying)" % dest.name)
                if dest.exists():
                    dest.unlink()
        write_manifest(out, meta, files)
        log("snapshot from %d urls: %d frames -> %s" % (len(a.urls), len(files), out))
        return 0 if files else 2
    url = "https://www.amazon.com/dp/%s" % a.asin
    log("fetching %s (one attempt, no retries)" % url)
    page = curl(url)
    (out / "page.html").write_text(page, encoding="utf-8")
    if blocked(page):
        log("BLOCKED OR EMPTY. Not retrying. Fallback: save the gallery to a folder and run "
            "snapshot --folder [dir] --out %s, or hand Wonka screenshots." % out)
        return 2
    meta = parse_page(page)
    meta.update({"source": url, "asin": a.asin})
    files = []
    for i, u in enumerate(meta["image_urls"], 1):
        dest = frames_dir / ("%02d%s" % (i, ".png" if u.lower().endswith(".png") else ".jpg"))
        ok = curl(u, dest, timeout=60) and dest.exists() and dest.stat().st_size > 5000
        if ok:
            files.append(dest)
        else:
            log("  %s FAILED (not retrying)" % dest.name)
            if dest.exists():
                dest.unlink()
    write_manifest(out, meta, files)
    log("title: %s" % meta["title"][:90])
    log("price %s | rating %s | %s | %d frames -> %s" % (meta["price"] or "?", meta["rating"] or "?",
                                                         meta["review_count"] or "?", len(files), out))
    return 0


def load_snapshot(d):
    p = Path(d) / "snapshot.json"
    if not p.exists():
        raise FileNotFoundError("no snapshot.json in %s" % d)
    return json.loads(p.read_text(encoding="utf-8"))


def diff_snapshots(old, new, threshold=24):
    """Frames are matched by hash distance (16x16 = 256 bits; under `threshold` is the
    same image). Returns a dict of changes; empty lists mean nothing moved."""
    oh = [(f["file"], f["hash"]) for f in old.get("frames", []) if f.get("hash")]
    nh = [(f["file"], f["hash"]) for f in new.get("frames", []) if f.get("hash")]
    # One old frame matches at most ONE new frame. Measured 21.9.2026: a competitor's new
    # dimension frame (their bare-product shot with arrows drawn on) matched the main at
    # 11 bits, so the diff read "6 -> 9 frames, 2 added, 0 removed", which cannot add up.
    # Pairs are taken closest first, and a taken frame is off the table.
    pairs = sorted((hamming(nhash, ohash), i, j)
                   for i, (nf, nhash) in enumerate(nh) for j, (of, ohash) in enumerate(oh))
    matched_new, taken_old = {}, set()
    for dist, i, j in pairs:
        if dist >= threshold:
            break
        if i in matched_new or j in taken_old:
            continue
        matched_new[i] = j
        taken_old.add(j)
    added = [nh[i][0] for i in range(len(nh)) if i not in matched_new]
    kept_old = set(matched_new.values())
    removed = [oh[j][0] for j in range(len(oh)) if j not in kept_old]
    reordered = [(nh[i][0], oh[j][0]) for i, j in matched_new.items() if i != j]
    # A price read from another geo is not a price move. Measured 21.9.2026: the direct fetch
    # from Israel returned "ILS 176.58", the export price, against a "$" baseline. Only two
    # dollar figures are compared; anything else is reported as not comparable.
    def usd(p):
        return bool(p) and p.strip().startswith("$")
    price_pair = (old.get("price"), new.get("price"))
    price_comparable = usd(price_pair[0]) and usd(price_pair[1])
    # The direct fetch collects the style-selector images too, so it can return more frames
    # than the Genrupt scrape of the same listing (7 vs 5 on 21.9.2026). A frame that exists
    # only because the route changed is not a frame the seller added.
    def route(s):
        src = str(s.get("source", ""))
        return "genrupt" if "genrupt" in src else ("direct" if "amazon.com" in src else src or "unknown")
    route_changed = route(old) != route(new)
    ch = {"added": added, "removed": removed, "reordered": reordered,
          "title": (old.get("title"), new.get("title")) if old.get("title") != new.get("title") else None,
          "price": price_pair if price_comparable and price_pair[0] != price_pair[1] else None,
          "price_not_comparable": price_pair if (price_pair[0] or price_pair[1]) and not price_comparable else None,
          "route": (route(old), route(new)) if route_changed else None,
          "rating": (old.get("rating"), new.get("rating")) if old.get("rating") != new.get("rating") else None,
          "review_count": (old.get("review_count"), new.get("review_count")) if old.get("review_count") != new.get("review_count") else None,
          "bullets_changed": old.get("bullets") != new.get("bullets") and bool(old.get("bullets") or new.get("bullets")),
          "frame_count": (len(oh), len(nh))}
    ch["any"] = bool(added or removed or reordered or ch["title"] or ch["price"] or ch["rating"]
                     or ch["review_count"] or ch["bullets_changed"] or ch["price_not_comparable"] or ch["route"])
    # "same title, same price" printed on blank-vs-blank is a lie: the Genrupt route brings
    # images and no meta, so both sides were empty strings and the line read as reassurance.
    ch["meta_known"] = any(old.get(k) or new.get(k) for k in ("title", "price", "rating", "review_count"))
    return ch


def render_diff(asin, ch):
    lines = ["### %s" % asin]
    if not ch["any"]:
        if ch["meta_known"]:
            lines.append("- nothing changed: %d frames, same title, same price, same rating and count" % ch["frame_count"][1])
        else:
            lines.append("- frames unchanged: %d. Title, price, rating and count were not captured on this "
                         "route, so nothing is known about them." % ch["frame_count"][1])
        return "\n".join(lines)
    if ch.get("route"):
        lines.append("- ROUTE CHANGED: %s -> %s. The direct fetch also collects the style-selector "
                     "images, so a frame below that only the direct route saw is not 'added' until it "
                     "is seen on the sheet as a gallery frame." % ch["route"])
    if ch["added"]:
        lines.append("- NEW frames: %s%s" % (", ".join(ch["added"]), " (confirm on the sheet: route changed)" if ch.get("route") else ""))
    if ch["removed"]:
        lines.append("- REMOVED frames: %s" % ", ".join(ch["removed"]))
    if ch["reordered"]:
        lines.append("- REORDERED: " + ", ".join("%s was %s" % (n, o) for n, o in ch["reordered"]))
    if ch["frame_count"][0] != ch["frame_count"][1]:
        lines.append("- frame count %d -> %d" % ch["frame_count"])
    for k in ("title", "price", "rating", "review_count"):
        if ch[k]:
            lines.append("- %s: %r -> %r" % (k, ch[k][0], ch[k][1]))
    if ch.get("price_not_comparable"):
        lines.append("- price: not comparable (%r vs %r; one side is not a USD figure, a price read "
                     "from another geo is the export price, not a move)" % ch["price_not_comparable"])
    if ch["bullets_changed"]:
        lines.append("- bullets changed (read both snapshot.json files for the lines)")
    return "\n".join(lines)


def cmd_diff(a):
    old, new = load_snapshot(a.old), load_snapshot(a.new)
    ch = diff_snapshots(old, new)
    print(render_diff(new.get("asin") or old.get("asin") or "?", ch))
    return 1 if ch["any"] else 0


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)
    s = sub.add_parser("snapshot"); s.add_argument("asin", nargs="?"); s.add_argument("--out", required=True)
    s.add_argument("--folder"); s.add_argument("--title"); s.add_argument("--urls", nargs="+")
    s.add_argument("--meta", help="json with title/price/rating/review_count/bullets, from the market analysis")
    s.set_defaults(fn=cmd_snapshot)
    d = sub.add_parser("diff"); d.add_argument("old"); d.add_argument("new"); d.set_defaults(fn=cmd_diff)
    a = ap.parse_args(argv)
    try:
        return a.fn(a)
    except FileNotFoundError as e:
        print("refresh_fetch.py: %s" % e, file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())

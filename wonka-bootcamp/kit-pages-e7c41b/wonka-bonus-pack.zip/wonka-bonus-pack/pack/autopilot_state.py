#!/usr/bin/env python3
"""autopilot_state.py | The run record for /listing-autopilot, and the gate that keeps it honest.

The autopilot promises "the whole line in one run, with two or three stops". A promise like
that is only true if a machine, not a memory, decides what comes next: which stage is done,
whether a stop is pending, how much is spent against the cap. This file is that machine.
Every stage is marked here as it completes, every paid action is logged with its quoted cost,
every stop is recorded when it opens and when the owner answers, and `next` refuses to name a
stage while a stop is open. Resume is free: a new session reads the file and continues.

    python3 autopilot_state.py init  <product dir> --cap-credits 200 --cap-usd 8 --stops 3 [--asin B0..]
    python3 autopilot_state.py next  <product dir>          prints the next stage, or the open stop (exit 1)
    python3 autopilot_state.py done  <product dir> <stage> [--note "..."]
    python3 autopilot_state.py block <product dir> <stage> --why "the lid colour is unsettled"
    python3 autopilot_state.py spend <product dir> 18 --unit credits --what "market analysis, quoted 18"
    python3 autopilot_state.py headroom <product dir> --worst 31 --unit credits \
        --balance 192 --account "your Genrupt org"      exit 1 on the cap OR on the live balance

A BLOCKED STAGE OPENS THE NEXT STOP EARLY, CARRYING ITS QUESTION. Measured 16.9.2026 on the
first live run: research found that the owner's own photos disagreed with his listing about the
product's lid colour, so the reference sheet could not be built without locking a guess. The run
record said "next: reference" and the stop that asks the owner anything was defined as opening
AFTER the sheet. A stop that can only open after the work it should have prevented is not a gate.
So a stage may be marked BLOCKED with its reason, and the next stop then opens carrying that
reason; the blocked stage stays undone and runs after the owner answers.

THE TWO PURSES. The line runs on two machines that bill in different units: Genrupt in
CREDITS, the OpenAI key in DOLLARS. The balance tool does not always report a dollar rate
for an organisation, and a rate from memory is how a cap becomes fiction. So the run carries
TWO caps and never converts between them. Measured 16.9.2026, the first live autopilot run:
a single USD cap could not be checked against a Genrupt quote at all.
    python3 autopilot_state.py stop  <product dir> <stop> [--message-file f]   opens a stop
    python3 autopilot_state.py answer <product dir> <stop> --text "..."       records the owner's answer, closes it
    python3 autopilot_state.py delegate <product dir> <stop> --text "why"     records that Wonka decided (2-stop mode)
    python3 autopilot_state.py report <product dir>          markdown of the whole run

The record: <product dir>/autopilot/run-state.json. Stdlib only.
"""
import argparse
import json
import re
import sys
import time
from pathlib import Path

# `brief` is TWO stages on purpose. On the first live run (16.9.2026) `brief` was marked
# done while the send to Genrupt had never happened: the cap block landed in the middle of
# the stage, and a single flag could not tell "written" from "sent". The state machine had
# promised that was impossible. Writing is free and local; sending creates the project the
# reference sheet lives in, so only the send can prove itself, and it proves itself with a
# projectId (see EVIDENCE below).
STAGES = ["research", "brief-written", "brief-sent", "reference", "STOP:lock", "smoke", "main",
          "gallery", "aplus", "inspect", "STOP:picks", "tasting", "STOP:verdict", "fixes",
          "variations", "package", "log"]

# A stage that produced something OUTSIDE this machine cannot be closed on its own word.
# The value is the name of the --evidence this stage requires.
EVIDENCE = {"brief-sent": "projectId"}

# A stage whose output is a FILE this machine can read closes only when the file says so.
# brief-written: the brief must carry the kit's `## Set structure` table (a row per S-slot),
# because `plan_parity.py` walks brief to plan from that table and nothing else. Measured
# 17.9.2026 on the first live run: the brief was written as `### S1 . job` blocks only, the
# audit could not run, and the table was added by hand. A brief the audit cannot read is not
# written yet.
BRIEF_FILE = ("brief", "creative-brief.md")


def brief_problem(product):
    """None when the brief is readable by plan_parity.py, else the sentence that says why not."""
    f = Path(product) / BRIEF_FILE[0] / BRIEF_FILE[1]
    if not f.exists():
        return "%s/%s does not exist" % BRIEF_FILE
    text = f.read_text(encoding="utf-8", errors="replace")
    lines = text.splitlines()
    try:
        i = next(k for k, l in enumerate(lines) if l.strip().startswith("## Set structure"))
    except StopIteration:
        return "the brief has no `## Set structure` table"
    rows = 0
    for l in lines[i + 1:]:
        if l.startswith("## "):
            break
        if re.match(r"\|\s*S\d+\s*\|", l):
            rows += 1
    if rows == 0:
        return "the `## Set structure` table has no `| S1 |` rows"
    return None
STOPS = {"lock": "the lock and the recipe", "picks": "the picks", "verdict": "the verdict and the decision"}


def path(product):
    return Path(product) / "autopilot" / "run-state.json"


# A run started before the brief split (pack v1) has "brief" in its done list. The v2
# machine names that stage brief-written + brief-sent, so an old run would be told its next
# stage is brief-written while it sits at the smoke test. Measured 17.9.2026 on the first live
# run, the same evening the split landed. Migrate on load, once, and say so in the file.
LEGACY_STAGES = {"brief": ["brief-written", "brief-sent"]}


def migrate(st):
    done = st.get("done", [])
    changed = False
    for old, new in LEGACY_STAGES.items():
        if old in done:
            i = done.index(old)
            done[i:i + 1] = [n for n in new if n not in done]
            st.setdefault("evidence", {}).setdefault(
                "brief-sent", "migrated: sent under pack v1, projectId recorded in status.md")
            st.setdefault("decisions", []).append({"at": now(), "stage": "migration",
                "note": "stage %r renamed to %s by pack v2" % (old, " + ".join(new))})
            changed = True
    return changed


def load(product):
    p = path(product)
    if not p.exists():
        raise FileNotFoundError("no run-state.json under %s; run init first" % product)
    st = json.loads(p.read_text())
    if migrate(st):
        p.write_text(json.dumps(st, indent=2, ensure_ascii=False))
    return st


def save(product, st):
    p = path(product)
    p.parent.mkdir(parents=True, exist_ok=True)
    st["updated"] = time.strftime("%Y-%m-%d %H:%M")
    p.write_text(json.dumps(st, indent=2, ensure_ascii=False))


def now():
    return time.strftime("%Y-%m-%d %H:%M")


def cmd_init(a):
    p = path(a.product)
    if p.exists() and not a.force:
        st = json.loads(p.read_text())
        if st.get("status") != "delivered":
            print("found an unfinished run (started %s); use `next` to resume, or --force to start over" % st.get("started"))
            return 1
    if a.stops not in (2, 3):
        print("stops must be 2 or 3")
        return 2
    if float(a.cap_credits) <= 0 or float(a.cap_usd) <= 0:
        print("both caps must be above zero: --cap-credits for Genrupt, --cap-usd for the OpenAI key")
        return 2
    st = {"product": Path(a.product).name, "asin": a.asin or "",
          "cap": {"credits": float(a.cap_credits), "usd": float(a.cap_usd)}, "stops": a.stops,
          "started": now(), "status": "running", "done": [], "blocked": {}, "spend": [],
          "stops_log": {}, "open_stop": None, "decisions": []}
    save(a.product, st)
    print("run started: caps %g credits (Genrupt) and $%.2f (OpenAI), %d stops. The two are never converted."
          % (st["cap"]["credits"], st["cap"]["usd"], st["stops"]))
    return 0


UNITS = ("credits", "usd")


def spent(st, unit="usd"):
    return round(sum(x["amount"] for x in st["spend"] if x["unit"] == unit), 4 if unit == "usd" else 1)


def cap_of(st, unit):
    return float(st["cap"][unit])


def purse(st):
    return "spent %g/%g credits and $%.2f/$%.2f" % (spent(st, "credits"), cap_of(st, "credits"),
                                                   spent(st, "usd"), cap_of(st, "usd"))


def next_stage(st):
    """The first stage that is neither done nor blocked. A STOP stage is 'done' when answered or
    delegated; a BLOCKED stage is skipped over so the next stop can open carrying its reason."""
    blocked = st.get("blocked", {})
    for s in STAGES:
        if s in st["done"] or s in blocked:
            continue
        if s.startswith("STOP:"):
            name = s.split(":", 1)[1]
            if name == "picks" and st["stops"] == 2:
                # two-stop mode: the picks are Wonka's, recorded as delegated when reached
                return s
            return s
        return s
    return None


def cmd_next(a):
    st = load(a.product)
    over = st.get("over_cap")
    if over:
        print("REFUSED: the run is over its cap (%g of %g %s, recorded %s). Raise the cap and "
              "`unblock cap`, or end the run. Nothing runs on a purse that is already empty."
              % (over["total"], over["cap"], over["unit"], over["at"]))
        return 1
    if st["open_stop"]:
        print("STOP OPEN: %s (%s). Waiting on the owner. Nothing runs past it." % (st["open_stop"], STOPS.get(st["open_stop"], "")))
        return 1
    nxt = next_stage(st)
    if nxt is None:
        print("DELIVERED: every stage done. %s" % purse(st))
        return 0
    for stage, b in sorted(st.get("blocked", {}).items()):
        print("BLOCKED %s: %s" % (stage, b["why"]))
    if nxt.startswith("STOP:"):
        name = nxt.split(":", 1)[1]
        if name == "picks" and st["stops"] == 2:
            print("STAGE picks-delegated: two-stop run, Wonka makes the picks and records them with `delegate picks`")
        else:
            print("STAGE stop:%s: open it with `stop %s` and wait for the owner" % (name, name))
        return 0
    print("STAGE %s (%s)" % (nxt, purse(st)))
    return 0


def cmd_done(a):
    st = load(a.product)
    stage = a.stage
    if stage not in STAGES or stage.startswith("STOP:"):
        print("unknown stage %r; stages: %s" % (stage, ", ".join(s for s in STAGES if not s.startswith("STOP:"))))
        return 2
    if st["open_stop"]:
        print("REFUSED: stop %r is open; nothing completes while the owner is being waited on" % st["open_stop"])
        return 1
    expected = next_stage(st)
    if stage in st.get("blocked", {}):
        print("REFUSED: %r is blocked (%s). Unblock it first." % (stage, st["blocked"][stage]["why"]))
        return 1
    if expected != stage:
        print("REFUSED: the next stage is %r, not %r. The line has an order." % (expected, stage))
        return 1
    need = EVIDENCE.get(stage)
    evidence = getattr(a, "evidence", None)
    if need and not evidence:
        print("REFUSED: %r closes on evidence, not on its own word. Pass --evidence with the %s "
              "the call returned. Measured 16.9.2026: this stage was marked done while the send "
              "had never happened." % (stage, need))
        return 1
    if stage == "brief-written":
        why = brief_problem(a.product)
        if why:
            print("REFUSED: brief-written closes on a brief plan_parity.py can read, and %s. Write "
                  "the kit's `## Set structure` table (| Slot | Job | Message |, one row per S-slot) "
                  "into %s/%s. Measured 17.9.2026: the audit could not walk brief to plan until "
                  "the table was added by hand." % ((why,) + BRIEF_FILE))
            return 1
    st["done"].append(stage)
    row = {"at": now(), "stage": stage, "note": a.note or ""}
    if evidence:
        row["evidence"] = evidence
        st.setdefault("evidence", {})[stage] = evidence
    st["decisions"].append(row)
    if stage == "package":
        pass
    if next_stage(st) is None:
        st["status"] = "delivered"
    save(a.product, st)
    print("done: %s" % stage)
    return 0


def cmd_block(a):
    st = load(a.product)
    stage = a.stage
    if stage not in STAGES or stage.startswith("STOP:"):
        print("unknown stage %r" % stage)
        return 2
    if stage in st["done"]:
        print("REFUSED: %r is already done" % stage)
        return 1
    st.setdefault("blocked", {})[stage] = {"why": a.why, "at": now()}
    st["decisions"].append({"at": now(), "stage": stage, "note": "BLOCKED: " + a.why})
    save(a.product, st)
    print("blocked: %s (%s). The next stop opens carrying it; the stage runs after the owner answers." % (stage, a.why))
    return 0


def cmd_unblock(a):
    st = load(a.product)
    if a.stage == "cap":
        if not st.get("over_cap"):
            print("REFUSED: this run is not over its cap")
            return 1
        old = st.pop("over_cap")
        st["decisions"].append({"at": now(), "stage": "cap",
                                "note": "cap cleared by the owner: was %g of %g %s%s"
                                        % (old["total"], old["cap"], old["unit"],
                                           (". " + a.why) if a.why else "")})
        save(a.product, st)
        print("the cap block is cleared. Raise cap_%s in the run's config before the next spend."
              % old["unit"])
        return 0
    if a.stage not in st.get("blocked", {}):
        print("REFUSED: %r is not blocked" % a.stage)
        return 1
    st["blocked"].pop(a.stage)
    st["decisions"].append({"at": now(), "stage": a.stage, "note": "unblocked: " + (a.why or "the owner answered")})
    save(a.product, st)
    print("unblocked: %s" % a.stage)
    return 0


def cmd_spend(a):
    st = load(a.product)
    amount = float(a.amount)
    if a.unit not in UNITS:
        print("unit must be credits or usd")
        return 2
    if amount < 0:
        print("a spend is not negative")
        return 2
    account = getattr(a, "account", None)
    if account:
        st.setdefault("account", {})[a.unit] = account
    row = {"at": now(), "amount": amount, "unit": a.unit, "what": a.what}
    who = (st.get("account") or {}).get(a.unit)
    if who:
        row["account"] = who
    st["spend"].append(row)
    save(a.product, st)
    total, cap = spent(st, a.unit), cap_of(st, a.unit)
    if total > cap:
        # The money is already gone, so it is recorded. What must not happen is the NEXT
        # paid call. `headroom` is a separate command the agent can forget; `spend` always
        # runs, because it runs after the fact. Measured 20.9.2026: this printed a warning
        # and returned 0, so a forgotten headroom left nothing between the run and the cap.
        st["over_cap"] = {"unit": a.unit, "total": total, "cap": cap, "at": now()}
        st["decisions"].append({"at": now(), "stage": "spend",
                                "note": "OVER THE CAP: %g of %g %s" % (total, cap, a.unit)})
        save(a.product, st)
        print("spent %g %s on %s; %s\n"
              "STOP: this run is now OVER ITS CAP (%g of %g %s). The money already left, so it "
              "is on the record, but nothing else runs. Raise the cap in the run's config and "
              "`unblock cap`, or end the run here." % (amount, a.unit, a.what, purse(st),
                                                       total, cap, a.unit))
        return 1
    print("spent %g %s on %s; %s" % (amount, a.unit, a.what, purse(st)))
    return 0


def whose_money(st, unit, account=None):
    """One line, before every paid action: which account the money leaves. Measured 16.9.2026:
    the MCP connection is one organisation and the Genrupt CLI is another, and a market-analysis
    id quoted from the wrong one looks exactly like a valid id until it is used."""
    who = account or (st.get("account") or {}).get(unit) or ""
    if who:
        return "the %s that move are %s's" % (unit, who)
    return ("the account these %s leave was never recorded. Call get_current_account_context "
            "and pass --account, or the run cannot say whose money it spent" % unit)


def cmd_headroom(a):
    st = load(a.product)
    if a.unit not in UNITS:
        print("unit must be credits or usd")
        return 2
    worst = float(a.worst)
    total, cap = spent(st, a.unit), cap_of(st, a.unit)
    bal = None if getattr(a, "balance", None) in (None, "") else float(a.balance)
    account = getattr(a, "account", None)
    if account:
        st.setdefault("account", {})[a.unit] = account
        save(a.product, st)

    # The cap is a promise the owner made. The balance is the money that exists. Checking only
    # the cap said OK on 17.9.2026 with a 250-credit cap against a 192-credit organisation, so a
    # credit check without a live balance is refused outright rather than answered wrongly.
    if a.unit == "credits" and bal is None:
        print("NO: read the LIVE balance first (get_credit_balance_and_costs) and pass --balance. "
              "The cap is what you promised to stop at; it is not what the account holds.")
        return 1

    print(whose_money(st, a.unit, account))
    if total + worst > cap + 1e-9:
        print("NO: %g + %g worst case = %g %s, over the %g cap. This is the one mid-run stop."
              % (total, worst, total + worst, a.unit, cap))
        return 1
    if bal is not None and worst > bal + 1e-9:
        print("NO: the worst case is %g %s and the account holds %g. The cap is not the blocker, "
              "the wallet is: top up or shrink the job." % (worst, a.unit, bal))
        return 1
    print("OK: %g + %g worst case = %g %s, inside the %g cap" % (total, worst, total + worst, a.unit, cap))
    if bal is not None:
        room = cap - total
        if room > bal + 1e-9:
            print("WARNING: the cap is larger than the purse. %g %s of cap are left and the account "
                  "holds %g, so the cap will stop nothing after the next %g."
                  % (room, a.unit, bal, bal))
        print("balance after this worst case: %g %s" % (bal - worst, a.unit))
    return 0


def cmd_stop(a):
    st = load(a.product)
    if a.stop not in STOPS:
        print("unknown stop %r; stops: %s" % (a.stop, ", ".join(STOPS)))
        return 2
    expected = next_stage(st)
    if expected != "STOP:" + a.stop:
        print("REFUSED: the run is at %r, not at stop %r" % (expected, a.stop))
        return 1
    if a.stop == "picks" and st["stops"] == 2:
        print("REFUSED: a two-stop run does not open the picks stop; use `delegate picks`")
        return 1
    msg = Path(a.message_file).read_text() if a.message_file else ""
    st["open_stop"] = a.stop
    st["stops_log"][a.stop] = {"opened": now(), "message": msg, "answer": None}
    save(a.product, st)
    print("stop open: %s (%s). Say it to the owner and wait." % (a.stop, STOPS[a.stop]))
    return 0


def cmd_answer(a):
    st = load(a.product)
    if st["open_stop"] != a.stop:
        print("REFUSED: stop %r is not open (open: %r)" % (a.stop, st["open_stop"]))
        return 1
    st["stops_log"][a.stop]["answer"] = a.text
    st["stops_log"][a.stop]["answered"] = now()
    st["open_stop"] = None
    st["done"].append("STOP:" + a.stop)
    st["decisions"].append({"at": now(), "stage": "stop:" + a.stop, "note": "owner: " + a.text})
    save(a.product, st)
    print("answered: %s" % a.stop)
    return 0


def cmd_delegate(a):
    st = load(a.product)
    if a.stop != "picks" or st["stops"] != 2:
        print("REFUSED: only the picks stop of a two-stop run may be delegated")
        return 1
    if next_stage(st) != "STOP:picks":
        print("REFUSED: the run is not at the picks stop")
        return 1
    st["stops_log"]["picks"] = {"opened": now(), "delegated": True, "answer": "delegated: " + a.text}
    st["done"].append("STOP:picks")
    st["decisions"].append({"at": now(), "stage": "stop:picks", "note": "delegated: " + a.text})
    save(a.product, st)
    print("picks delegated and recorded")
    return 0


def cmd_report(a):
    st = load(a.product)
    lines = ["# Listing autopilot . %s . started %s" % (st["product"], st["started"]),
             "", "Status: %s. %s. %d stops. The two purses are never converted into each other."
             % (st["status"], purse(st), st["stops"]), "",
             "## Stages", ""]
    for s in STAGES:
        if s in st["done"]:
            lines.append("- [x] %s" % s)
        elif s in st.get("blocked", {}):
            lines.append("- [!] %s . BLOCKED: %s" % (s, st["blocked"][s]["why"]))
        else:
            lines.append("- [ ] %s" % s)
    lines += ["", "## Stops", ""]
    for k, v in st["stops_log"].items():
        lines.append("- **%s** opened %s. %s" % (k, v.get("opened"), ("answer: " + v["answer"]) if v.get("answer") else "OPEN"))
    lines += ["", "## Spend", "", "| When | What | Amount | Unit |", "|---|---|---|---|"]
    for x in st["spend"]:
        lines.append("| %s | %s | %g | %s |" % (x["at"], x["what"], x["amount"], x["unit"]))
    lines += ["", "## Decisions", ""]
    for d in st["decisions"]:
        lines.append("- %s . %s . %s" % (d["at"], d["stage"], d["note"]))
    out = "\n".join(lines) + "\n"
    (Path(a.product) / "autopilot" / "report.md").write_text(out)
    print(out)
    return 0


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)
    i = sub.add_parser("init"); i.add_argument("product")
    i.add_argument("--cap-credits", type=float, required=True, help="Genrupt purse, in credits")
    i.add_argument("--cap-usd", type=float, required=True, help="OpenAI purse, in dollars")
    i.add_argument("--stops", type=int, default=3); i.add_argument("--asin"); i.add_argument("--force", action="store_true"); i.set_defaults(fn=cmd_init)
    n = sub.add_parser("next"); n.add_argument("product"); n.set_defaults(fn=cmd_next)
    d = sub.add_parser("done"); d.add_argument("product"); d.add_argument("stage"); d.add_argument("--note")
    d.add_argument("--evidence", help="the id the outside call returned, for a stage that cannot "
                                      "close on its own word (see EVIDENCE)")
    d.set_defaults(fn=cmd_done)
    b = sub.add_parser("block"); b.add_argument("product"); b.add_argument("stage"); b.add_argument("--why", required=True); b.set_defaults(fn=cmd_block)
    u = sub.add_parser("unblock"); u.add_argument("product"); u.add_argument("stage"); u.add_argument("--why"); u.set_defaults(fn=cmd_unblock)
    s = sub.add_parser("spend"); s.add_argument("product"); s.add_argument("amount")
    s.add_argument("--account", help='whose money, e.g. "the Genrupt org on the MCP" or "the CLI account"')
    s.add_argument("--unit", required=True); s.add_argument("--what", required=True); s.set_defaults(fn=cmd_spend)
    h = sub.add_parser("headroom"); h.add_argument("product"); h.add_argument("--worst", required=True)
    h.add_argument("--unit", required=True)
    h.add_argument("--balance", help="the LIVE account balance, read this minute. Required for credits")
    h.add_argument("--account", help='whose money, e.g. "the Genrupt org on the MCP" or "the CLI account"')
    h.set_defaults(fn=cmd_headroom)
    t = sub.add_parser("stop"); t.add_argument("product"); t.add_argument("stop"); t.add_argument("--message-file"); t.set_defaults(fn=cmd_stop)
    w = sub.add_parser("answer"); w.add_argument("product"); w.add_argument("stop"); w.add_argument("--text", required=True); w.set_defaults(fn=cmd_answer)
    g = sub.add_parser("delegate"); g.add_argument("product"); g.add_argument("stop"); g.add_argument("--text", required=True); g.set_defaults(fn=cmd_delegate)
    r = sub.add_parser("report"); r.add_argument("product"); r.set_defaults(fn=cmd_report)
    a = ap.parse_args(argv)
    try:
        return a.fn(a)
    except FileNotFoundError as e:
        print("autopilot_state.py: %s" % e, file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())

#!/usr/bin/env python3
"""Read a product folder the way the kit's rooms read it, in one place.

Every pack skill starts by asking the same questions: which product, what does status.md
say, which file is the CURRENT version of each image, what did the panel record, what is
live on Amazon. This module answers them from disk and never guesses.

    python3 product.py [factory root] [product slug]      print the product's state as JSON

Rules carried from the kit (CLAUDE.md, the routine-fix policy, /inspect step 1):
- The current version of an image is the newest edits/vN/ that holds a file of that
  name, else the original. A `-rejected` render never carries the canonical name.
- `Main pick:` and `Gallery pick:` rows in status.md are the record of what was chosen.
  Files on disk are candidates until those rows name them.
- `Owner decision:` is a separate record from the panel's verdict. `stage_gate.py` in
  /ready-to-upload owns that distinction; this module only reports the rows.

Stdlib only.
"""
import json
import re
import sys
from pathlib import Path

IMAGE_EXT = (".png", ".jpg", ".jpeg", ".webp")


def factory_root(start=None):
    """Walk up from `start` (default cwd) to the folder holding factory/Products."""
    p = Path(start or Path.cwd()).resolve()
    for cand in [p] + list(p.parents):
        if (cand / "factory" / "Products").is_dir():
            return cand
    raise FileNotFoundError("no factory/Products above %s; run from inside a Wonka folder" % p)


def products(root):
    base = Path(root) / "factory" / "Products"
    return sorted(d for d in base.iterdir() if d.is_dir() and d.name != "TEMPLATE"
                  and not d.name.startswith((".", "_")))


def find_product(root, slug=None):
    """One product by slug, or the only product on the floor. Two products and no
    slug is a question for the owner, never a guess."""
    found = products(root)
    if slug:
        for d in found:
            if d.name == slug:
                return d
        raise FileNotFoundError("no product folder named %r under factory/Products" % slug)
    if len(found) == 1:
        return found[0]
    if not found:
        raise FileNotFoundError("no products on the floor yet; /meet-my-product registers one")
    raise ValueError("several products on the floor (%s); say which one"
                     % ", ".join(d.name for d in found))


def _rows(text):
    for line in text.splitlines():
        line = line.strip()
        if line.startswith("|") and not re.match(r"^\|\s*-+", line):
            cells = [c.strip() for c in line.strip("|").split("|")]
            yield cells


def status_fields(product):
    """The `| Field | Value |` table at the top of status.md, as a dict."""
    p = Path(product) / "status.md"
    if not p.exists():
        return {}
    out = {}
    for cells in _rows(p.read_text(encoding="utf-8")):
        if len(cells) == 2 and cells[0] not in ("Field", "Station"):
            out.setdefault(cells[0], cells[1])
    return out


def stations(product):
    """The Stations table: name -> {status, artifact, date, notes}."""
    p = Path(product) / "status.md"
    if not p.exists():
        return {}
    out = {}
    for cells in _rows(p.read_text(encoding="utf-8")):
        if len(cells) == 5 and cells[0] in ("RESEARCH", "BRIEF", "INVENT", "INSPECT", "PROVE"):
            out[cells[0]] = {"status": cells[1], "artifact": cells[2], "date": cells[3], "notes": cells[4]}
    return out


def sub_status(product):
    """The INVENT sub-status lines: `- Main pick: ...`, `- Gallery pick: ...`,
    `- Owner decision: ...`, `- Variations: ...`. Placeholders (starting with `[`,
    or `none yet`) come back as None. `Reference status` and `Smoke test` are read
    from 2-reference/reference-sheet.md, where the kit writes them."""
    p = Path(product) / "status.md"
    if not p.exists():
        return {}
    keys = ("Main pick", "Gallery picks", "Gallery pick", "Owner decision", "Variations",
            "Next stage", "Reference status", "Smoke test", "Running order")
    out = {k: None for k in keys}
    text = p.read_text(encoding="utf-8")
    ref = Path(product) / "2-reference" / "reference-sheet.md"
    if ref.exists():
        text += "\n" + ref.read_text(encoding="utf-8")
    for line in text.splitlines():
        m = re.match(r"^\s*(?:[-*]\s*)?\**\s*(%s)\s*:\**\s*(.*)$" % "|".join(re.escape(k) for k in keys), line)
        if not m:
            continue
        k, v = m.group(1), m.group(2).strip().strip("*").strip()
        if not v or v.startswith("[") or v.lower().startswith(("none yet", "tbd")):
            out[k] = None
        else:
            out[k] = v
    return out


def edit_rounds(product):
    """edits/v1, v2, ... sorted by N ascending."""
    e = Path(product) / "edits"
    if not e.is_dir():
        return []
    rounds = []
    for d in e.iterdir():
        m = re.fullmatch(r"v(\d+)", d.name)
        if d.is_dir() and m:
            rounds.append((int(m.group(1)), d))
    return [d for _, d in sorted(rounds)]


def current_version(product, original):
    """The file that ships for `original` (a path under the product folder): the same
    name in the newest edits/vN/ that holds it, else the original itself."""
    original = Path(original)
    name = original.name
    for rnd in reversed(edit_rounds(product)):
        hit = next((f for f in rnd.rglob(name) if f.is_file()), None)
        if hit:
            return hit
    return original


def images_in(folder):
    folder = Path(folder)
    if not folder.is_dir():
        return []
    return sorted(f for f in folder.iterdir()
                  if f.suffix.lower() in IMAGE_EXT and "-rejected" not in f.stem)


def gallery_pick_frames(product):
    """The stems the `Gallery pick:` row names, in order. Four forms, because the kit
    writes more than one and a parser that reads only the doc's example halts a correct
    run (Nir's report, 21.9.2026: both products on his floor used a form this function
    could not read, and the skills told him his approved gallery was never approved).
      named range   edits/v5 (frames sec-01..sec-07 in order)   also `to`, `-`
      named list    edits/v9 (frames sec-01-v2, sec-02-v2, sec-03-v3, in that order)
      bare range    edits/v2 (frames 02-07 in order)                       [legacy]
      bare list     edits/v2 (frames 02, 03, 05)                           [legacy]
    A suffixed stem (sec-05-v2) is kept distinct from sec-05: they are different files."""
    row = sub_status(product).get("Gallery pick") or ""
    m = re.search(r"frames?\s+(.+)", row)
    if not m:
        return []
    spec = m.group(1).split(")")[0]
    spec = re.sub(r"\bin (that )?order\b.*$", "", spec, flags=re.I).strip(" ,")
    rng = re.search(r"sec-(\d+)\s*(?:\.\.|-{1,2}|to)\s*sec-(\d+)", spec, re.I)
    if rng:
        a, b = int(rng.group(1)), int(rng.group(2))
        return ["sec-%02d" % n for n in range(a, b + 1)]
    named = re.findall(r"sec-\d+(?:-[a-z0-9]+)*", spec, re.I)
    if named:
        return [n.lower() for n in named]
    lrng = re.fullmatch(r"\s*(\d+)\s*-\s*(\d+)\s*", spec)
    if lrng:
        a, b = int(lrng.group(1)), int(lrng.group(2))
        return ["sec-%02d" % n for n in range(a, b + 1)]
    return ["sec-%02d" % int(n) for n in re.findall(r"\d+", spec)]


def resolve_stem(product, stem):
    """The file a Gallery pick stem names. A bare stem (sec-03) is the images/ original
    carried to its newest edits/vN copy; a suffixed stem (sec-03-v3) exists only in an
    edits round, newest first, or in images/."""
    product = Path(product)
    orig = next((f for f in images_in(product / "images") if f.stem.lower() == stem), None)
    if orig:
        return current_version(product, orig)
    for rnd in reversed(edit_rounds(product)):
        hit = next((f for f in images_in(rnd) if f.stem.lower() == stem), None)
        if hit:
            return hit
    return None


def shipped_gallery(product):
    """The gallery that ships, best source first:
    final/gallery/ (the Shipping Room's pack); else the frames the `Gallery pick:` row
    names, resolved through the edit rounds; else images/ sec-NN originals (never a
    `-vN` re-run candidate) resolved; else the older images/selected/ layout. Returns a
    list of paths and the source name, so a skill can say where it read."""
    product = Path(product)
    fg = images_in(product / "final" / "gallery")
    if fg:
        return fg, "final/gallery"
    stems = gallery_pick_frames(product)
    if stems:
        out = [f for f in (resolve_stem(product, st) for st in stems) if f]
        if out:
            return out, "Gallery pick: row (resolved through edits/)"
    sec = [f for f in images_in(product / "images")
           if re.fullmatch(r"sec-\d+", f.stem.lower())]
    if sec:
        return [current_version(product, f) for f in sec], "images/ sec-NN (resolved through edits/; no Gallery pick: row)"
    sel = [f for f in images_in(product / "images" / "selected") if f.stem.lower().startswith("s")]
    if sel:
        return [current_version(product, f) for f in sel], "images/selected (older layout, resolved through edits/)"
    return [], "none"


def shipped_main(product):
    product = Path(product)
    fm = images_in(product / "final" / "main")
    if fm:
        return fm[0], "final/main"
    pick = sub_status(product).get("Main pick")
    if pick:
        m = re.match(r"([A-Za-z0-9_.-]+)", pick)
        if m:
            stem = m.group(1).replace(".png", "")
            for folder in (product / "images" / "selected", product / "images", product / "images" / "pick"):
                for f in images_in(folder):
                    if f.stem == stem:
                        return current_version(product, f), "Main pick: row"
    sel = [f for f in images_in(product / "images" / "selected") if f.stem.lower().startswith("m")]
    if sel:
        return current_version(product, sel[0]), "images/selected first m-frame (no Main pick: row)"
    return None, "none"


def reference_sheets(product):
    """The locked reference sheet images, newest version first, plus the markdown."""
    r = Path(product) / "2-reference"
    sheets = sorted((f for f in images_in(r) if re.match(r"sheet-v\d+", f.stem)),
                    key=lambda f: int(re.search(r"v(\d+)", f.stem).group(1)), reverse=True)
    sheets = [s for s in sheets if "-view" not in s.stem and "-vs-" not in s.stem]
    return sheets, (r / "reference-sheet.md") if (r / "reference-sheet.md").exists() else None


def reference_status(product):
    """The LAST `Reference status:` line in 2-reference/reference-sheet.md, as the kit writes it
    (`LOCKED 2026-09-03`, `APPROVED (smoke test pending)`, `not locked (...)`), or `none`."""
    md = Path(product) / "2-reference" / "reference-sheet.md"
    if not md.exists():
        return "none"
    last = "none"
    for line in md.read_text(encoding="utf-8", errors="replace").splitlines():
        # only a line that STARTS with the label (after list, bold or table markup) counts;
        # prose that mentions the label mid-sentence does not
        head = re.sub(r"^[\s|*_`\-]+", "", line)
        if not head.lower().startswith("reference status:"):
            continue
        val = head.split(":", 1)[1]
        val = re.sub(r"[|*`_]", " ", val).strip()
        if val:
            last = val
    return last


def incumbent(product):
    return images_in(Path(product) / "incumbent")


def research(product):
    r = Path(product) / "research"
    return {n: (r / (n + ".md")) for n in ("product-report", "insights", "reviews", "persona",
                                           "competitors", "selling-points")
            if (r / (n + ".md")).exists()}


def tasting_runs(product):
    """tests/tasting-*/ folders that hold a results.json, newest last."""
    t = Path(product) / "tests"
    if not t.is_dir():
        return []
    return sorted(d for d in t.iterdir() if d.is_dir() and d.name.startswith("tasting-")
                  and (d / "results.json").exists())


def state(product):
    product = Path(product)
    gallery, gsrc = shipped_gallery(product)
    main, msrc = shipped_main(product)
    sheets, sheet_md = reference_sheets(product)
    price_raw = status_fields(product).get("Price")
    live = product / "1-inputs" / "listing-live.md"
    if not price_raw and live.exists():
        m = re.search(r"\$\s?\d[\d,]*\.\d\d", live.read_text(encoding="utf-8"))
        price_raw = m.group(0) if m else None
    # `price` is the FIGURE. status.md's row on the demo product reads "$57.99 USD (operator
    # screen + Genrupt price array, two independent confirmations)", and the landing-page
    # test (21.9.2026) dropped that whole sentence onto a Buy button. The prose survives as
    # price_note for whoever wants the provenance.
    price, price_note = None, None
    if price_raw:
        m = re.search(r"(?:[$€£]\s?\d[\d,]*(?:\.\d\d)?|\d[\d,]*(?:\.\d\d)?\s?(?:USD|EUR|GBP|ILS))", price_raw)
        price = m.group(0).strip() if m else price_raw.strip()
        rest = price_raw.replace(m.group(0), "", 1).strip(" ()") if m else ""
        price_note = rest or None
    # lifestyle/: the /lifestyle-pack output, when it exists. Text-free scenes, the right
    # thing for a page background; /landing-page reads this key and the test found it
    # missing (21.9.2026), so a student had no instruction for the photo band.
    lifestyle_dir = product / "lifestyle"
    lifestyle = sorted(str(p) for p in lifestyle_dir.rglob("*")
                       if p.suffix.lower() in (".png", ".jpg", ".jpeg", ".webp")) if lifestyle_dir.is_dir() else []
    # ChatGPT review, 21.9.2026: a gallery read from images/sec-NN with no Gallery pick row is a
    # set of CANDIDATES, and the newest sheet is only "the reference" once the notes say LOCKED.
    # The report says both out loud, so a skill about to spend on them stops and asks.
    gallery_approved = gsrc.startswith(("final/gallery", "Gallery pick"))
    ref_status = reference_status(product)
    warnings = []
    if gallery and not gallery_approved:
        warnings.append("GALLERY NOT APPROVED: no `Gallery pick:` row and no final/gallery, so these "
                        "are candidates from images/. Ask the owner which frames shipped before "
                        "spending on them.")
    if sheets and not ref_status.upper().startswith(("LOCKED", "APPROVED")):
        warnings.append("REFERENCE NOT LOCKED: reference-sheet.md says %r. Do not generate on a "
                        "sheet the owner has not approved." % ref_status)
    return {
        "product": product.name,
        "gallery_approved": gallery_approved,
        "reference_status": ref_status,
        "warnings": warnings,
        "price": price, "price_note": price_note,
        "price_source": "status.md" if status_fields(product).get("Price") else ("1-inputs/listing-live.md" if price else "none"),
        "lifestyle": lifestyle,
        "fields": status_fields(product),
        "stations": stations(product),
        "sub_status": sub_status(product),
        "main": str(main) if main else None, "main_source": msrc,
        "gallery": [str(g) for g in gallery], "gallery_source": gsrc,
        "reference_sheets": [str(s) for s in sheets],
        "reference_sheet_md": str(sheet_md) if sheet_md else None,
        "incumbent": [str(i) for i in incumbent(product)],
        "research": {k: str(v) for k, v in research(product).items()},
        "brief": str(product / "brief" / "creative-brief.md") if (product / "brief" / "creative-brief.md").exists() else None,
        "tasting_runs": [str(d) for d in tasting_runs(product)],
        "edit_rounds": [d.name for d in edit_rounds(product)],
    }


def main(argv=None):
    argv = sys.argv[1:] if argv is None else argv
    try:
        # `product.py [slug]` from anywhere inside the factory, or `product.py <root> [slug]`
        if len(argv) == 1 and not (Path(argv[0]) / "factory" / "Products").is_dir():
            root, slug = factory_root(None), argv[0]
        else:
            root = factory_root(argv[0] if argv else None)
            slug = argv[1] if len(argv) > 1 else None
        prod = find_product(root, slug)
        st = state(prod)
        print(json.dumps(st, indent=2))
        for w in st["warnings"]:
            print("WARNING: " + w)
        return 0
    except (FileNotFoundError, ValueError) as e:
        print("product.py: %s" % e, file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())

#!/usr/bin/env python3
"""Render the gallery in the order it will be uploaded, at the size a phone shows it.

The point of this picture is not that it is pretty. It is that the owner looks at the
thumbnail rail instead of at seven full-size images, and sees what a shopper sees: a
small main image and a row of tiny squares that either say something or do not.

    python3 strip.py --out shelf-strip.png images/main-02.png edits/v2/sec-03.png ...

The first path is slot 1 (the main). Everything after it is the rail, in upload order.
"""
import argparse
import sys
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont

PAD = 24
GAP = 10
BG = (255, 255, 255)
INK = (32, 32, 34)
DIM = (140, 140, 146)
RULE = (214, 214, 219)
FOLD = (198, 74, 46)


def _font(size):
    """A real font when the system has one, PIL's bitmap default when it does not.

    The default font ignores `size`, so every caller must lay out from the box the
    font actually reports, never from `size` itself.
    """
    for p in ("/System/Library/Fonts/Helvetica.ttc",
              "/System/Library/Fonts/Supplemental/Arial.ttf",
              "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"):
        if Path(p).exists():
            try:
                return ImageFont.truetype(p, size)
            except OSError:
                pass
    return ImageFont.load_default()


def _fit(img, box):
    """Letterbox onto a white square, the way a marketplace pads a non-square image."""
    im = img.convert("RGB")
    im.thumbnail((box, box), Image.LANCZOS)
    cell = Image.new("RGB", (box, box), BG)
    cell.paste(im, ((box - im.width) // 2, (box - im.height) // 2))
    return cell


def build_strip(paths, out, thumb=120, hero=360, fold=None, fold_label="", labels=None):
    """Draw the main image beside the numbered thumbnail rail.

    paths      ordered image paths. paths[0] is slot 1, the main.
    thumb      the rail cell in pixels. 120 is about what a phone gives a thumbnail.
    hero       the main image cell in pixels.
    fold       draw a marker AFTER this many rail cells, or None for no marker.
               Slot 1 is the main and is not in the rail, so fold=3 marks the line
               after slots 2, 3 and 4.
    labels     optional one-word job per slot, drawn under each cell.
    Returns a dict describing what was drawn.
    """
    paths = [Path(p) for p in paths]
    if not paths:
        raise ValueError("no images given; slot 1 is the main image and is required")
    missing = [str(p) for p in paths if not p.exists()]
    if missing:
        raise FileNotFoundError("these images are not on disk: " + ", ".join(missing))
    if fold is not None and fold < 1:
        raise ValueError("fold must be 1 or more, or None")

    rail = paths[1:]
    f_num = _font(15)
    f_lab = _font(12)
    f_head = _font(17)

    lab_h = 0
    if labels:
        lab_h = f_lab.getbbox("Ag")[3] + 6
    num_h = f_num.getbbox("8")[3] + 6
    head_h = f_head.getbbox("Ag")[3] + 14
    cap_h = f_num.getbbox("Ag")[3] + 10          # the caption under the main image
    fold_h = f_lab.getbbox("Ag")[3] + 6          # the fold label, under its own line

    rail_w = len(rail) * thumb + max(len(rail) - 1, 0) * GAP
    marked = fold is not None and fold < len(rail)
    fold_w = 26 if marked else 0
    rail_h = num_h + thumb + lab_h + (fold_h if (marked and fold_label) else 0)
    body_h = max(hero + cap_h, rail_h)
    w = PAD + hero + 28 + rail_w + fold_w + PAD
    h = PAD + head_h + body_h + PAD

    canvas = Image.new("RGB", (w, h), BG)
    d = ImageDraw.Draw(canvas)
    d.text((PAD, PAD), "the shelf, in upload order", font=f_head, fill=DIM)

    top = PAD + head_h
    canvas.paste(_fit(Image.open(paths[0]), hero), (PAD, top))
    d.rectangle([PAD, top, PAD + hero, top + hero], outline=RULE)
    d.text((PAD + 4, top + hero + 4), "1 . main", font=f_num, fill=INK)

    x = PAD + hero + 28
    rail_top = top + (body_h - rail_h) // 2       # the rail sits level with the main image
    y = rail_top + num_h
    for i, p in enumerate(rail):
        canvas.paste(_fit(Image.open(p), thumb), (x, y))
        d.rectangle([x, y, x + thumb, y + thumb], outline=RULE)
        d.text((x, y - num_h), str(i + 2), font=f_num, fill=INK)
        if labels and i + 1 < len(labels):
            d.text((x, y + thumb + 4), labels[i + 1][:18], font=f_lab, fill=DIM)
        x += thumb
        if marked and i + 1 == fold:
            fx = x + GAP // 2 + 6
            d.line([fx, rail_top, fx, y + thumb + lab_h], fill=FOLD, width=2)
            if fold_label:
                d.text((fx - 2, y + thumb + lab_h + 3), fold_label, font=f_lab, fill=FOLD)
            x += fold_w
        x += GAP

    out = Path(out)
    out.parent.mkdir(parents=True, exist_ok=True)
    canvas.save(out)
    return {"out": str(out), "slots": len(paths), "rail": len(rail),
            "thumb": thumb, "hero": hero, "size": [w, h],
            "fold": fold if marked else None}


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("images", nargs="+", help="ordered image paths; the first is the main")
    ap.add_argument("--out", required=True)
    ap.add_argument("--thumb", type=int, default=120)
    ap.add_argument("--hero", type=int, default=360)
    ap.add_argument("--fold", type=int, default=None,
                    help="draw a marker after this many rail cells")
    ap.add_argument("--fold-label", default="")
    ap.add_argument("--labels", default="",
                    help="comma separated one-word job per slot, slot 1 first")
    a = ap.parse_args(argv)
    labels = [s.strip() for s in a.labels.split(",")] if a.labels else None
    try:
        info = build_strip(a.images, a.out, a.thumb, a.hero, a.fold, a.fold_label, labels)
    except (ValueError, FileNotFoundError) as e:
        print("strip.py: %s" % e, file=sys.stderr)
        return 2
    print("%s  %d slots (%d in the rail)  %dx%d" %
          (info["out"], info["slots"], info["rail"], info["size"][0], info["size"][1]))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

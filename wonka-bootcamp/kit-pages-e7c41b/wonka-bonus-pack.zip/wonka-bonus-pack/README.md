# The Wonka bonus pack

Eleven skills that go to eligible bootcamp buyers at graduation. They install into an
existing Wonka factory and run on the product already on the line: the locked reference
sheet, the brief, the research, the picks, the Tasting Cards. Every one of them produces
files. None of them writes listing copy (title, bullets) or gives seller advice.

| Skill | What comes out |
|---|---|
| `/listing-autopilot` | the whole line in one run, three stops (or two) |
| `/running-order` | the upload order, and the shelf drawn at phone size |
| `/refresh` | what moved on the shelf since last time, and the one asset to make |
| `/lifestyle-pack` | twenty scenes of the locked product, no words on them |
| `/santa` | the gallery dressed for Christmas, product untouched |
| `/seasons` | the same engine for every other occasion |
| `/localize-gallery` | the gallery rebuilt in another language, proofread at native size |
| `/steal-this-frame` | a competitor's idea, rebuilt on your product, their image never used |
| `/landing-page` | a product page designed from the package |
| `/asin-to-video-autopilot` | a finished 30-second listing film, built on the lock |
| `/asin-to-video-copilot` | the same film with eight decisions kept by the owner |

## Install

```
bash install.sh /path/to/your/Wonka
```

Then open the factory in Claude and ask Wonka what new skills he has. The pack lives in
`.claude/skills/` beside the kit's rooms and in `.claude/pack/` (the shared engines). The
kit's own updates merge folders and never touch these.

Requirements are the kit's: Python 3 with Pillow, the OpenAI key in the factory's `.env`,
the Genrupt MCP. The two video skills also need ffmpeg, Node 18+, numpy and whisper-cpp;
`bash .claude/skills/asin-to-video-autopilot/setup/check-env.sh` says what is missing.

## Layout of this folder

```
CONTRACT.md        the nine rules every skill in the pack follows
skills/<name>/     one folder per skill: SKILL.md, helper scripts, their tests
pack/              the shared engines: engine.py (images), seasonal.py, product.py,
                   refresh_fetch.py, autopilot_state.py, and their tests
install.sh         copies skills/ and pack/ into a factory
build-pack.sh      builds the zip students download (refuses a dirty tree)
PACK-VERSION       the number the zip carries
```

Run every test: `for t in pack/test_*.py skills/*/test_*.py; do python3 $t | tail -1; done`.
Plain python, no pytest, like the kit.

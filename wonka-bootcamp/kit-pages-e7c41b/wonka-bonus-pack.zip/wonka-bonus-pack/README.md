# The Wonka bonus pack

Eleven skills that go to eligible bootcamp buyers at graduation. They install into an
existing Wonka factory and run on the product already on the line: the locked reference
sheet, the brief, the research, the picks, the Tasting Cards. Every one of them produces
files. None of them writes listing copy (title, bullets) or gives seller advice.

| Skill | What comes out |
|---|---|
| `/listing-autopilot` | the whole line in one run, three stops (or two) |
| `/running-order` | the upload order, and the shelf drawn at phone size |
| `/refresh` | what moved on the shelf since last time, and the one asset to make |
| `/lifestyle-pack` | twenty scenes of the locked product, no words on them |
| `/santa` | the gallery dressed for Christmas, product untouched |
| `/seasons` | the same engine for every other occasion |
| `/localize-gallery` | the gallery rebuilt in another language, proofread at native size |
| `/steal-this-frame` | a competitor's idea, rebuilt on your product, their image never used |
| `/landing-page` | a product page designed from the package |
| `/asin-to-video-autopilot` | a finished 30-second listing film, built on the lock |
| `/asin-to-video-copilot` | the same film with eight decisions kept by the owner |

## Install

```
bash install.sh /path/to/your/Wonka
```

Then **start a NEW Claude Code session** in the factory and ask Wonka what new skills he has.
Skills are read when a session starts, so a window that was already open will not see them. The pack lives in
`.claude/skills/` beside the kit's rooms and in `.claude/pack/` (the shared engines). The
kit's own updates merge folders and never touch these.

## If you already installed the free versions

Two of these eleven share a NAME with a skill Jay gives away publicly:
`asin-to-video-autopilot` and `asin-to-video-copilot`. Two more do the same JOB under a
different name: the pack's `landing-page` against the public `amazon-landing-page`, and the
pack's `santa` against the public `santa-skill`.

Claude Code resolves a name collision by scope and the project wins, so inside your Wonka
folder the PACK version of the two video skills runs. That is what you want: the pack versions
read the locked reference sheet and land files in the product folder, which the public ones
cannot do. Where the names differ, both are available and you pick by name: say `/landing-page`
and `/santa` inside the factory. Outside the factory your free copies are untouched and still
work exactly as before.

Requirements are the kit's: Python 3 with Pillow, the OpenAI key in the factory's `.env`,
the Genrupt MCP. The two video skills also need ffmpeg, Node 18+, numpy and whisper-cpp;
`bash .claude/skills/asin-to-video-autopilot/setup/check-env.sh` says what is missing.

## Layout of this folder

```
CONTRACT.md        the nine rules every skill in the pack follows
skills/<name>/     one folder per skill: SKILL.md, helper scripts, their tests
pack/              the shared engines: engine.py (images), seasonal.py, product.py,
                   refresh_fetch.py, autopilot_state.py, and their tests
install.sh         copies skills/ and pack/ into a factory
build-pack.sh      builds the zip students download (refuses a dirty tree)
PACK-VERSION       the number the zip carries
```

Checking your install:

```
bash .claude/skills/asin-to-video-autopilot/setup/rehearse.sh
```

It proves the whole video pipeline on a worked example, spends nothing, and names anything
missing on your machine. The other ten skills need only Python, Pillow and your two keys.

#!/usr/bin/env bash
# Install the bonus pack into an existing Wonka factory.
#
#   bash install.sh /path/to/Wonka
#
# Copies skills/* into <factory>/.claude/skills/ and pack/* into <factory>/.claude/pack/.
# Nothing in the kit is replaced: every pack skill has its own folder, and the kit's
# auto-update merges folders (gate.py, copytree dirs_exist_ok), so the pack survives
# every future kit release. Running this twice is safe; it refreshes the pack in place.
set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TARGET="${1:-}"
if [ -z "$TARGET" ]; then echo "usage: bash install.sh /path/to/Wonka"; exit 2; fi
if [ ! -f "$TARGET/CLAUDE.md" ] || [ ! -d "$TARGET/.claude/skills" ]; then
  echo "REFUSED: $TARGET does not look like a Wonka factory (no CLAUDE.md or .claude/skills)."; exit 1
fi
KIT_SKILLS="$TARGET/.claude/skills"
for s in "$HERE"/skills/*/; do
  name="$(basename "$s")"
  if [ -d "$KIT_SKILLS/$name" ] && [ ! -f "$KIT_SKILLS/$name/.pack" ]; then
    echo "REFUSED: $KIT_SKILLS/$name exists and is not a pack skill. Nothing was changed."; exit 1
  fi
done
for s in "$HERE"/skills/*/; do
  name="$(basename "$s")"
  mkdir -p "$KIT_SKILLS/$name"
  rsync -a --delete --exclude '__pycache__' --exclude '.DS_Store' --exclude 'test_*.py' "$s" "$KIT_SKILLS/$name/"
  touch "$KIT_SKILLS/$name/.pack"
done
mkdir -p "$TARGET/.claude/pack"
rsync -a --exclude '__pycache__' --exclude '.DS_Store' --exclude 'test_*.py' "$HERE/pack/" "$TARGET/.claude/pack/"
cp "$HERE/PACK-VERSION" "$TARGET/.claude/pack/PACK-VERSION" 2>/dev/null || true
echo "installed $(ls -d "$HERE"/skills/*/ | wc -l | tr -d ' ') skills into $KIT_SKILLS and the shared engine into $TARGET/.claude/pack"
echo "Open the factory in Claude and say: what new skills do I have?"

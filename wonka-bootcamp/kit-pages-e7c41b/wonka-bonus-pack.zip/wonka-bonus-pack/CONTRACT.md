# The bonus pack. The contract every skill in it follows

Eleven skills, delivered to eligible buyers at the end of the bootcamp. They install into an
existing Factory and they are not part of the kit.

## The nine rules

1. **Creative only.** Every skill produces asset files: images, video, print files, or a rendered
   plan. Nothing in this pack writes listing copy, manages ads, or gives seller advice. Those
   belong to the free `amz-*` skills (74 on 16.9.2026), and repeating them burns the bonus.
2. **It runs on the factory, not on a cold ASIN.** Each skill reads the locked reference sheet,
   the brief, the research and the picks that are already on disk. It never asks for something
   `status.md` already holds.
3. **Write in your own folder, never over someone else's file.** Each skill owns one folder under
   `factory/Products/[product]/`. No skill renames, moves or overwrites an image another skill made.
4. **Say the price before you spend it.** Any skill that costs credits estimates the run first,
   carries a cap, and stops at the cap rather than asking mid-run.
5. **The day gate does not apply.** The pack ships at graduation, so every eligible owner is past
   `gate.py`. A skill checks the gate only to print one line when a product is mid-course, and it
   never blocks on it.
6. **Wonka's voice.** `.claude/wonka-character.md` governs tone, exactly as in the kit.
7. **House format.** Frontmatter with real triggers, a meta table, what this does and what it is
   not, inputs and the missing-input behaviour, numbered process, an output template, a definition
   of done, and the `status.md` row it writes.
8. **Every helper script has a test beside it**, and the test is watched failing before the code
   that passes it is written.
9. **Evidence or doctrine, marked.** Where a decision comes from the tasting cards, the reviews or
   the brief, cite the line. Where it comes from house doctrine, say so. Never dress doctrine as
   a fact about Amazon.

## Where the code lives

- `.claude/skills/[name]/` . one folder per skill, merged into the owner's kit. Kit auto-updates
  use `copytree(dirs_exist_ok=True)`, so these survive every future kit release. Verified in
  `gate.py`, 16.9.2026.
- `.claude/pack/` . shared helpers used by more than one skill. Not in the kit's `REPLACE_PATHS`,
  so the updater never touches it.

## The eleven

| Skill | Source | Produces |
|---|---|---|
| `/asin-to-video-autopilot` | port | a finished 30s film |
| `/asin-to-video-copilot` | port | the same, with eight decisions kept by the owner |
| `/santa` | port | the gallery dressed for Christmas |
| `/landing-page` | port | a product page built from the package |
| `/listing-autopilot` | new | the whole line in one run, two or three stops |
| `/running-order` | new | the upload order and a rendered shelf strip |
| `/refresh` | new | what changed out there, and the asset that answers it |
| `/lifestyle-pack` | new | twenty contexts of the locked product |
| `/seasons` | new | the santa engine for every occasion |
| `/localize-gallery` | new | the gallery re-rendered for another marketplace |
| `/steal-this-frame` | new | a competitor's composition, rebuilt with your product |

Four of the new ones (`lifestyle-pack`, `seasons`, `localize-gallery`, `steal-this-frame`) are one
engine: read the lock, generate many frames in one house style, inspect, land. Build the engine in
`.claude/pack/` once.

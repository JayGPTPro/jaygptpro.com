#!/usr/bin/env bash
# Installer tests. Run: bash test_install.sh   (from advanced-pack/)
set -u
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
FAIL=0
check(){ if [ "$2" = "1" ]; then echo "  PASS  $1"; else echo "  FAIL  $1  ${3:-}"; FAIL=1; fi; }
factory(){ d="$1"; mkdir -p "$d/.claude/skills"; : > "$d/CLAUDE.md"; }
T="$(mktemp -d)"; trap 'rm -rf "$T"' EXIT
echo "install.sh"

factory "$T/a"
out="$(bash "$HERE/install.sh" "$T/a" 2>&1)"; rc=$?
check "a clean factory installs" "$([ $rc -eq 0 ] && [ -f "$T/a/.claude/skills/santa/SKILL.md" ] && [ -f "$T/a/.claude/skills/refresh/SKILL.md" ] && echo 1 || echo 0)" "$out"
check "it says how many skills it installed" "$(echo "$out" | grep -q "installed 11 skills" && echo 1 || echo 0)" "$out"
check "every skill carries the .pack marker" "$([ "$(ls -d "$T"/a/.claude/skills/*/ | wc -l)" = "$(ls "$T"/a/.claude/skills/*/.pack | wc -l)" ] && echo 1 || echo 0)"
check "the shared engine lands in .claude/pack" "$([ -f "$T/a/.claude/pack/engine.py" ] && echo 1 || echo 0)"
check "tests are not shipped into the factory" "$([ -z "$(find "$T/a/.claude" -name 'test_*.py')" ] && echo 1 || echo 0)"

# A student's own file inside a pack skill folder survives a reinstall.
: > "$T/a/.claude/skills/santa/my-notes.md"
bash "$HERE/install.sh" "$T/a" >/dev/null 2>&1
check "a reinstall keeps a file the student added" "$([ -f "$T/a/.claude/skills/santa/my-notes.md" ] && echo 1 || echo 0)"

# A same-named skill that is NOT ours is refused, and nothing is half-written.
factory "$T/b"; mkdir -p "$T/b/.claude/skills/santa"; : > "$T/b/.claude/skills/santa/SKILL.md"
out="$(bash "$HERE/install.sh" "$T/b" 2>&1)"; rc=$?
check "a foreign skill of the same name is refused" "$([ $rc -eq 1 ] && echo 1 || echo 0)" "$out"
check "the refusal writes nothing at all" "$([ ! -d "$T/b/.claude/pack" ] && [ ! -d "$T/b/.claude/skills/refresh" ] && echo 1 || echo 0)"

# Not a factory, and no argument.
mkdir -p "$T/c"
bash "$HERE/install.sh" "$T/c" >/dev/null 2>&1; check "a folder that is not a factory is refused" "$([ $? -eq 1 ] && echo 1 || echo 0)"
out="$(bash "$HERE/install.sh" 2>&1)"; rc=$?
check "no argument prints the usage" "$([ $rc -eq 2 ] && echo "$out" | grep -q "usage: bash install.sh" && echo 1 || echo 0)" "$out"

# A path with spaces.
factory "$T/My Wonka Folder"
bash "$HERE/install.sh" "$T/My Wonka Folder" >/dev/null 2>&1
check "a path with spaces installs" "$([ -d "$T/My Wonka Folder/.claude/skills/refresh" ] && echo 1 || echo 0)"

# THE WINDOWS CASE (20.9.2026): Git Bash ships no rsync. The install must still work,
# and must never leave a half-made folder that the next run refuses as foreign.
factory "$T/d"
if command -v rsync >/dev/null 2>&1; then HAVE_RSYNC=1; else HAVE_RSYNC=0; fi
check "this machine has rsync, so the no-rsync tests below mean something" "$HAVE_RSYNC" "no rsync here: the stub tests cannot prove a fallback"
STUB="$T/nopath"; mkdir -p "$STUB"
for c in bash sh mkdir cp rm ls basename dirname find touch cat wc tr sed chmod printf env dirname; do
  p="$(command -v $c 2>/dev/null)" && ln -sf "$p" "$STUB/$c"
done
out="$(PATH="$STUB" bash "$HERE/install.sh" "$T/d" 2>&1)"; rc=$?
check "an install with no rsync still installs" "$([ $rc -eq 0 ] && [ -f "$T/d/.claude/skills/santa/SKILL.md" ] && echo 1 || echo 0)" "$out"
check "and it says so, so nobody wonders why it looked different" "$(echo "$out" | grep -q "rsync was not on this machine" && echo 1 || echo 0)" "$out"
check "no rsync: the shared engine is there too" "$([ -f "$T/d/.claude/pack/engine.py" ] && echo 1 || echo 0)"
check "no rsync: no test files leaked in" "$([ -z "$(find "$T/d/.claude" -name 'test_*.py')" ] && echo 1 || echo 0)"
out="$(bash "$HERE/install.sh" "$T/d" 2>&1)"; rc=$?
check "a normal install after a no-rsync install is not refused" "$([ $rc -eq 0 ] && echo 1 || echo 0)" "$out"

echo
if [ $FAIL -eq 1 ]; then echo "FAILED"; exit 1; fi
echo "all good"

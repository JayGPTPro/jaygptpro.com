# The Wonka bonus pack

Eleven extra things Wonka can make from the product you already finished. They start from what
the bootcamp built, the reference sheet you locked, the brief you approved, the frames you chose,
and make new files from it. Images, a film, a web page. No listing copy, no advice.

| Skill | What comes out |
|---|---|
| `/listing-autopilot` | your next product, the whole line in one run, three stops where you decide |
| `/running-order` | the upload order, and your gallery drawn the way a phone shows it |
| `/refresh` | what moved on the shelf since last time, and the one image to make next |
| `/lifestyle-pack` | twenty scenes of your product, no words on them, for ads and social |
| `/santa` | your gallery dressed for Christmas, product untouched |
| `/seasons` | the same for Mother's Day, Halloween, summer, or an occasion you name |
| `/localize-gallery` | your frames rebuilt in another language, checked letter by letter |
| `/steal-this-frame` | a rival's idea on your product. Their photo is never copied |
| `/landing-page` | a web page built from your own package |
| `/asin-to-video-autopilot` | a finished 30 second film, narration, music, text on screen |
| `/asin-to-video-copilot` | the same film, with eight decisions kept by you |

## Installing

The easy way, and the one this pack was built for: open Claude Code in your Wonka folder and
paste Wonka this message.

```
Install my Wonka bonus pack into this factory. https://jaygptpro.com/wonka-bonus.txt names the current zip and its sha256: download it, check the digest, and run the install.sh inside it from my factory root.
```

By hand, if you prefer: unzip this folder anywhere, open a terminal inside it, and run the line
below. To fill in the path, type the first two words and then **drag your Wonka folder onto the
terminal window**; it types the path for you. Your Wonka folder is the one holding `factory/`
and `CLAUDE.md`.

```
bash install.sh /path/to/your/Wonka
```

**Then close the window and open Wonka again.** New skills are only seen by a session that
started after they were installed. Ask him `What new skills do I have?` and he should list
eleven.

The installer refuses anything that is not a Wonka folder, refuses to touch a skill it does not
own, and never deletes a file you added. Running it twice is safe.

## If you already have the free versions

Two of these share a name with skills Jay gives away publicly, and two more do the same job under
a different name. Inside your Wonka folder the pack's version runs, which is the one you want: it
reads your locked reference sheet and puts files in your product folder. Outside your Wonka
folder, your free copies are untouched and work exactly as before. You do not need to do anything.

## What they need

Everything you already have: a product that finished the bootcamp, and the two machines from
Day 1, Genrupt and your OpenAI key. The two video skills need a few extra tools on your computer
and will check for them on their first run, telling you in plain words if anything is missing.

## Money

Every skill tells you what a job costs before it spends, and stops at a limit instead of asking
you halfway through. Most are pennies. `/running-order` and the first `/refresh` are free.

## Something wrong?

Message Jay, the same way as during the bootcamp. If a file looks wrong, send it along with the
one line Wonka said about it.

#!/usr/bin/env bash
# Install the bonus pack into an existing Wonka factory.
#
#   bash install.sh /path/to/Wonka
#
# Copies skills/* into <factory>/.claude/skills/ and pack/* into <factory>/.claude/pack/.
# Nothing in the kit is replaced: every pack skill has its own folder, and the kit's
# auto-update merges folders (gate.py, copytree dirs_exist_ok), so the pack survives
# every future kit release. Running this twice is safe; it refreshes the pack in place.
#
# Two things this script learned on 20.9.2026, both from tests in test_install.sh:
#   1. Git Bash on Windows ships no rsync. The old version ran mkdir, then failed on
#      rsync under `set -e`, and left an empty folder with no .pack marker. Every later
#      run then refused that folder as "not a pack skill" and the student was stuck for
#      good. Now: rsync when it exists, plain cp otherwise, and the marker goes down
#      FIRST so a half-finished copy is still recognised as ours.
#   2. `rsync --delete` silently removed files a student had put inside a pack skill
#      folder. The pack owns the files it ships, not the folder.
set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TARGET="${1:-}"
if [ -z "$TARGET" ]; then echo "usage: bash install.sh /path/to/Wonka"; exit 2; fi
if [ ! -f "$TARGET/CLAUDE.md" ] || [ ! -d "$TARGET/.claude/skills" ]; then
  echo "REFUSED: $TARGET does not look like a Wonka factory (no CLAUDE.md or .claude/skills)."
  echo "The path wanted is the folder that holds your factory/ and CLAUDE.md."
  exit 1
fi
KIT_SKILLS="$TARGET/.claude/skills"

# Check every destination BEFORE writing anything, so a refusal leaves the factory untouched.
for s in "$HERE"/skills/*/; do
  name="$(basename "$s")"
  if [ -d "$KIT_SKILLS/$name" ] && [ ! -f "$KIT_SKILLS/$name/.pack" ]; then
    echo "REFUSED: $KIT_SKILLS/$name exists and is not a pack skill. Nothing was changed."
    echo "Rename or move that folder, then run this again."
    exit 1
  fi
done

if command -v rsync >/dev/null 2>&1; then COPY=rsync; else COPY=cp; fi

copy_tree() {  # copy_tree SRC DST . everything except tests, caches and .DS_Store
  local src="$1" dst="$2"
  mkdir -p "$dst"
  if [ "$COPY" = rsync ]; then
    rsync -a --exclude '__pycache__' --exclude '.DS_Store' --exclude 'test_*.py' "$src" "$dst/"
  else
    # Stage a pruned copy of the SOURCE, then copy that in. Pruning used to run on the
    # destination, which deleted any test_*.py the student had put inside a pack folder.
    # Measured 21.9.2026. cp -R on a path ending in /. copies contents, on BSD and GNU cp.
    local stage; stage="$(mktemp -d)"
    cp -R "$src". "$stage/" 2>/dev/null || cp -R "$src"* "$stage/"
    find "$stage" \( -name '__pycache__' -o -name '.DS_Store' -o -name 'test_*.py' \) \
      -exec rm -rf {} + 2>/dev/null || true
    cp -R "$stage/." "$dst/"
    rm -rf "$stage"
  fi
}

for s in "$HERE"/skills/*/; do
  name="$(basename "$s")"
  mkdir -p "$KIT_SKILLS/$name"
  # The marker first: if the copy dies halfway (no disk, no rsync, a stopped terminal),
  # the folder is still OURS and the next run refreshes it instead of refusing it.
  touch "$KIT_SKILLS/$name/.pack"
  copy_tree "$s" "$KIT_SKILLS/$name"
done
copy_tree "$HERE/pack/" "$TARGET/.claude/pack"
cp "$HERE/PACK-VERSION" "$TARGET/.claude/pack/PACK-VERSION" 2>/dev/null || true

count="$(ls -d "$HERE"/skills/*/ | wc -l | tr -d ' ')"
echo "installed $count skills into $KIT_SKILLS and the shared engine into $TARGET/.claude/pack"
if [ "$COPY" = cp ]; then echo "(rsync was not on this machine, so plain cp was used. Same result.)"; fi
echo
echo "Now START A NEW Claude Code session in your Wonka folder, then say:"
echo "  what new skills do I have?"
echo "Skills are read when a session starts, so a session that was already open will not see them."

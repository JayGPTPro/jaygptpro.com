---
name: brand-kit
description: OPTIONAL brand styling, read out of a real Brand Book or Style Guide the owner already owns. Extracts the colors, typography, tone, approved claims and avoid list that guide actually establishes, and carries them into the Genrupt branding preset. It never invents a brand: with no Brand Book and no Style Guide there is nothing to run and the line continues unbranded. It does not handle the logo file; a real logo is uploaded and wired by /reference-sheet, with or without any styling. Run once per brand, reused by every product. Use when the owner HAS a Brand Book or Style Guide. Triggers: /brand-kit, "brand kit", "here is our brand book", "here is our style guide", "brand guidelines", "our brand colors are documented", "approved claims", "avoid list".
---

# The Brand Room

| Meta | Value |
|------|-------|
| Room | The Brand Room |
| Station | OPTIONAL. Taught on Day 4 between the Reference Sheets' approval and the smoke test, so the smoke test runs with any styling already attached. Nothing in the factory waits for this room |
| Needs | ONE thing, and only this: a real **Brand Book or Style Guide** the owner already owns, in `2-reference/brand/` or attached to Claude. Nothing else is an input to this room, and nothing else is a substitute for it. **With no such document there is nothing to build here**, and that is a complete answer, not a gap |
| Saves to | factory/Brand/brand-kit.md and the Genrupt branding preset. The preset id is recorded in the kit file AND in the product's `status.md` `Genrupt preset ID` row, which is the row every other room reads |
| Typical cost | Free. Interview, analysis, and preset creation cost no credits. Only the preset step touches the Genrupt machine at all |

## What this room does

A brand that already wrote its rules down should not have to say them again. This room READS the
owner's real Brand Book or Style Guide and carries what that document actually establishes into
two artifacts: the **kit file** (colors with real hex codes, font direction, tone, approved
claims, an explicit avoid list) and the **Genrupt branding preset** that carries the colors and font
direction into every generation. Built once per brand; every product of that brand reuses it.

**This room does not choose a style image.** The look of the set is chosen on Day 6, from real
generated frames, when the owner picks a style and sends it to Refine (`/secondary-images`, mode 2).
Asking an owner to pick "the one image that says make it feel like this" before a single image
exists is a question nobody can answer well, so it is not asked here. `references.styleImage` stays
unset by this room.

**This room reads a brand. It never writes one.** With no Brand Book and no Style Guide there is
nothing here to do, and the honest answer is to say so in one line and continue. Wonka does not
propose a palette from the product, the category, the buyer, the listing, the website, the packaging
or past creative, and he never suggests inventing a brand with AI. A seller without a documented
brand is not missing homework; they are a seller whose images will be styled by the product itself,
which is a real and measured outcome.

**The logo is not in this room.** A real logo file is uploaded and wired into Genrupt by
`/reference-sheet`, whether or not any brand styling exists, and whether or not this room ever runs.
Genrupt happens to carry both a logo and brand styling on the same preset, but that is a transport
detail of the API, not a dependency between them: a logo needs no Brand Book, and a Brand Book needs
no logo.

One thing this room is quietly responsible for. It is the **compliance firewall**: the approved claims table is the only list of claims allowed onto an image, decided once while calm instead of forty times in a hurry. The file and the claims work need no machine and no credits, so when Genrupt is down this is the work that still moves. Only the preset push waits for the machine, and it is recorded as waiting rather than skipped.

**The style contract (house decision 4, and it is absolute):** brand style travels ONLY through the branding preset, and the set's look is chosen later, on Day 6, through Refine. Generation rooms pass `brandingPresetId` inside `projectSetup`, and that is this room's whole delivery. Hex codes, font names, and style prose never appear in a brief, a header phrase, or a custom instruction. Design-dictating text overrides the brand engine and flattens the output, and a hex code in a text field is the classic symptom. The approved claims and avoid list travel a different road: they gate what `/creative-brief` may put into on-image text, they are compliance, not style.

## Before you start

- Open `factory/Brand/brand-kit.md`. The kit SHIPS with this file as an unfilled template (placeholders like `[filled by /brand-kit]` and `#______`), so its existence alone means nothing.
  - **Still unfilled**: this is a FIRST RUN. Read the supplied guide, then fill the template's sections IN PLACE, keeping its `##` headers exactly. Do not invent new sections. Every extra field below lives inside an existing table or in the footer.
  - **Already filled with real values**: do NOT rebuild from scratch. Show the current kit, ask what changes, edit only those fields, and follow step 13.
- `factory/Brand/brand-kit.md` is the single canonical path. Multiple brands: name additional kits `brand-kit-[brand-slug].md`, one brand per file, never merged, each with its OWN branding preset id, and record which kit applies in the **`Brand kit` row of each product's `status.md` identity table**. The preset itself is looked up from the neighbouring **`Genrupt preset ID`** row, which is the canonical lookup for every generation room.
- **When more than one `brand-kit*.md` exists, no room may assume the default.** Every room that reads a brand kit resolves it from the product's own `status.md` first. If that product has no kit recorded, STOP and ask which brand it belongs to; never fall back to `factory/Brand/brand-kit.md` just to have something. The failure this prevents is silent and expensive: the second brand's product generated in the first brand's colors, carrying the first brand's approved claims, with no error anywhere.
- **Check for the one input first.** Read `factory/Products/[product]/2-reference/brand/` and anything the owner attached to Claude in this session. A real Brand Book or Style Guide is the only thing that starts this room. If it is not there, ask ONCE, plainly, whether the brand has one: "do you have a brand book or a style guide document?" A no ends the room in one line (step 0), with nothing owed and nothing proposed.
- **"I have nothing" is a finished answer, not a hole to fill.** It never triggers a proposal, an interview, a palette suggestion, or a second offer later. It is recorded once and the line continues.

## Process

0. **Decide which of two states this run is in, and say which, out loud.**
   - **A REAL BRAND BOOK OR STYLE GUIDE EXISTS.** The owner supplied a document their brand already
     owns. Read it, extract what it establishes, and the owner confirms. The steps below are that run.
   - **THERE IS NO SUCH DOCUMENT.** There is nothing for this room to build, and building anything
     would be inventing a brand. Say it in one line ("no brand book, no style guide, so there is no
     brand styling to connect. The images will be styled by your product and Genrupt's own enhancer,
     which is a real choice, not a downgrade."), write `none` into the product's `status.md`
     `Brand kit` row, and END THE ROOM. Then, specifically:
     - Do NOT propose a palette, a font direction, a mood or a look from the product, the category,
       the buyer, the reviews, the listing, the website, the packaging, or past creative.
     - Do NOT recommend inventing a brand with AI, and do not offer to "draft one to start from".
     - Do NOT run an interview whose purpose is to manufacture a brand system.
     - Do NOT leave a pending marker, and do NOT offer this room again downstream. `none` is a
       COMPLETED choice, and every later room reads it as one.
     - **A logo is untouched by all of this.** If the owner has a real logo it is already uploaded
       and wired by `/reference-sheet`, and the product may carry a logo-only Genrupt preset while
       `Brand kit` reads `none`. Those two rows are independent; never clear one because of the other.
     - Measured 27 August 2026: with no preset at all, nine smoke-test frames still came back sharing
       one coherent look that Genrupt's own enhancer drew from the product. Unbranded is a real path.
     - It is reversible without ceremony: if a Brand Book turns up later, run `/brand-kit` then.
   - The two rules that survive either state, because they are compliance and not taste: **no logo is
     ever drawn, approximated or invented**, and **no claim enters the approved-claims table without
     proof** (step 10).

1. **Read the guide, and take only what it actually establishes.** The Brand Book or Style Guide is
   the source; the room's job is extraction, not authorship.
   - Read every page you can open. If a page cannot be opened, say so in one line and ask for a
     screenshot or pasted text of that page.
   - What may be taken from it: colors, typography, tone of voice, layout rules, approved claims,
     avoids, and any explicit visual guidance it gives. Logo-USE instructions (placement, clear
     space, what may not be done to it) may be recorded as supplied rules; they never turn into a
     requirement for a logo FILE, and they never control whether a logo is uploaded.
   - **An incomplete guide is normal.** Use exactly what it establishes, leave the rest unset, and
     leave the matching preset fields unset too. Do NOT fill a gap from the product, the category,
     the buyer, the website, the packaging, or personal taste. In the file, extracted facts and
     absent information are visibly different things: a value carries `from brand book (p. N)`, and
     an absent one carries the literal `not established by the guide`.
   - **Never write "sampled" for a value you did not actually see.** A guessed hex code wearing a
     "sampled from the guide" label is a faked artifact, and every future session will trust it.
   - Record the outcome item by item; the footer carries one line,
     `Sources used: [the guide, by name]. Not established by it: [list].`

2. **Establish the KIT BASIS and write it as a row in `## Brand identity`.** It names the document: `brand book: [filename]` or `style guide: [filename]`. There is no third value, because there is no third source. A kit with no named document is not a kit this room may write.

3. **COLORS. Up to five roles, real hex codes, all of them out of the guide.** Primary, secondary, accent, background, text on light.
   - Take the actual values the guide states or shows. If the guide names fewer than five roles, fill only those and write `not established by the guide` in the rest. Never invent the missing ones.
   - Every row's Notes column names the source: `from brand book (p. N)` / `sampled from the guide's swatch page` / `not established by the guide`.
   - Accent is for highlights and for real on-product seals. It is never permission to invent a badge.
   - **Name the text-safe pairs, if the guide names them.** One Notes line saying which colors may carry text and which may never ("headline text on background or primary only; never white text on the accent"). If the guide is silent, say so rather than deciding it here.

4. **FONTS. A direction, not a file, and read off the guide's own typography.** Map what the guide specifies onto one of exactly three tokens, written literally, once for headlines and once for supporting text (a guide naming a specific serif maps to `editorial serif`, and the mapping is stated out loud). If the guide establishes no typography, both tokens read `not established by the guide` and the preset's font fields stay unset: `editorial serif` (premium, wellness, heritage), `clean sans` (modern, tech, minimal), `bold display` (value, energy, impulse). Add the one-sentence overall look. If the brand owns a licensed font, record its name and note that it serves human design work only. Image models cannot load font files; they follow a described look reliably. These two tokens later become the preset's header and supporting font direction (step 12), so they are decided here once and typed into prose nowhere, ever.

5. **TONE, from the guide's own voice section.** Three to five words for `Sounds like`, each with a sentence of what it means for imagery ("warm: natural light, soft shadows, no clinical white sweep"), and three to five for `Never sounds like`. If the guide has no voice section, write `not established by the guide` and move on.

6. **APPROVED CLAIMS. Two tests, and a claim must pass both.** This is the compliance backbone and the most valuable table in the file.
   - **Test 1, TRUE.** Certifications actually printed on the label (name the certifying body), documented press mentions or awards, and factual product attributes the owner confirms: dimensions, capacity, material, part count, warranty, country of manufacture. Every row needs a proof entry. No proof, no row.
   - **Test 1b, WHOSE.** Every row also records `Applies to`: `brand-wide`, or the name of the ONE product it was verified for. The attributes in Test 1 are the reason this column exists: capacity, part count, material and warranty belong to a product, not to a brand, and this kit is reused by every product the brand sells. Day 9's second product is where an unscoped table shows up as product one's "4 tiers" printed on product two. A claim verified for one product is never licensed for another; a new product uses `brand-wide` rows plus its own, and earns the rest with its own proof. The same scoping applies to the avoid list: a promise the reviews of ONE product disputed is recorded against that product, not against the brand.
   - **Test 2, ALLOWED.** True is not enough. Sales rank, Best Seller status, star ratings, review counts, "thousands of happy customers", and anything else pointing at reviews or rank is TRUE and still barred from images. Move it to the avoid list marked `true, not allowed on images`, and tell the owner why in one line: this is the category that gets listings pulled, and rank changes week to week anyway. Sell the reason for the rank instead.
   - **Disputed promises go to the avoid list too.** If the product has research on disk, read `factory/Products/*/research/product-report.md` (and the raw `1-inputs/reviews.txt` where it exists) and move any promise buyers routinely dispute into the avoid list, naming the review evidence. Example from the bootcamp's demo product, a chocolate fondue fountain: buyers report the flow is weak at the capacity the listing states, so no image may promise a cascading flow. A promise the images made is the cheapest complaint to prevent and the most expensive to inherit.
   - For every approved row, record HOW it may appear: as it appears on the physical label, as plain printed text, as a physical hang tag. Never as an invented graphic badge, never as a third-party logo rendered by the model.
   - **An empty table is a lawful outcome.** If nothing passes both tests, write the literal line `No claims approved. Images carry only what is physically printed on the product.` and move on. Never pad this table to make it look finished. An invented certification is the single most expensive thing this skill could produce.

7. **AVOID LIST.** Restate the full Golden Standards compliance set: no medical or disease claims, no invented percentages or statistics, no star ratings or review references, no fake badges or awards, no third-party logos rendered as graphics, no flag graphics. Then add, each with a one-line reason: brand-specific avoids (colors that clash, styles the owner rejects, competitor names, a discontinued label), every item moved here by test 2, and every disputed promise from the reviews.

8. **LOGO-USE RULES, if the guide states any. This room does not own the logo FILE.** The real logo
   is uploaded and wired into Genrupt by `/reference-sheet`, and whether one exists is read from the
   product's `status.md` `Logo source` row, never decided here. What this room may record is what the
   guide SAYS about using a logo: placement, minimum clear space, one logo per image maximum, what
   may never be done to it. Write them as supplied rules, attributed to the guide.
   - The guide says nothing about logo use: write `Logo-use rules: not established by the guide`.
   - No logo file exists at all: write nothing about it here and ask nothing. It is not this room's
     subject, it does not block this room, and it never becomes a task.
   - The standing compliance rule holds everywhere regardless: **no logo is drawn, approximated,
     spelled out or invented.**

9. **No style image here.** Earlier versions of this room picked a `styleImage` on Day 4. That is retired: the set's look is chosen on Day 6 from real generated frames (Restyle and Send to Refine). Do not propose one, do not ask for one, and leave `references.styleImage` unset.

10. **Write the file, then self-check before showing it.** Fill in place, then verify mechanically that none of these survive anywhere in the file: `#______`, `[filled by /brand-kit]`, `[e.g. `, `[add your own]`, `[your brand name]`, `[date]`. Every `[URL or n/a]` reads as a real URL or the literal `n/a`. A file with a placeholder left in it is not a kit, it is the template with extra steps.

11. **Present, then get the verdict.** Show a compact summary: each color described in words with its hex and source, the two font tokens, the tone words, the claim count, the avoid count, and any logo-use rules the guide stated. Say plainly which fields the guide did not establish. Then ask plainly for "yes, that's my brand". Three lawful outcomes, and the footer records which one happened:
    - **Yes** to `Owner approval: APPROVED [YYYY-MM-DD] by [name]`.
    - **Changes** to edit exactly what they named, state the change in words, ask again. Never mark approved off a "looks fine" or a silence.
    - **Owner not in the session** (an assistant run, a rehearsal, a team member without authority) to `Owner approval: PENDING . built [YYYY-MM-DD] from [sources], awaiting owner confirmation`. See the PENDING contract below. The kit is usable and the line does not stop.

12. **Push the kit into the Genrupt branding preset, and record the id.** The preset is how the colors and font direction actually reach a generation; a kit that lives only in markdown styles nothing. One preset per brand.
    - Find the branding tools (list, create, update, apply branding preset). If they are not directly visible, discover them with `search_capabilities` and call them with `execute_capability`.
    - **Resolve the preset from the product's `status.md` `Genrupt preset ID` row FIRST, then confirm with `list_branding_presets {includeDetails: true}`.** That row is the canonical lookup. A preset already exists there in two ordinary cases: this brand was set up before, or `/reference-sheet` created a **logo-only preset** for a supplied logo. **UPDATE that exact preset. Never spawn a twin.**
    - **A preset update is a MERGE, and the logo half is not yours to touch.** Before writing: read the existing preset in detail. Then update ONLY the style fields the guide established, and leave `logoUrl` and `logoThumbnailUrl` exactly as they are. Clearing a logo because this room did not supply one is the specific failure this paragraph exists to prevent.
    - Map in only what the guide established: primary, secondary, accent, and background hex into the preset's color fields; the two font tokens as the header and supporting font direction; the style notes field carries the one-sentence look, the text-safe pairs, and the text-on-light hex. **Fields the guide did not establish stay unset**; never send a value invented to fill a slot. Hex codes live HERE and only here. They never travel in brief text.
    - **Read the preset back after the write and verify BOTH halves survived**: the style fields you just sent are present, AND a logo that was there before is still there (`hasLogo: true`, `logoUrl` unchanged). Then read the Listing Builder plan back and confirm the same `brandingPresetId` is attached, the slot plan is unchanged, and `approved: true` still holds.
    - Record the id the tool returns in the kit's `## Style engine` section: `Branding preset: [id], updated [YYYY-MM-DD]`, **and write the same id into the product's `status.md` `Genrupt preset ID` row**, which is where every generation room reads it. Never write an id the tool did not return.
    - Genrupt down or MCP not connected: do not fake it, do not stall the kit. Write `Branding preset: PENDING . Genrupt unavailable [YYYY-MM-DD]` and say plainly that no generation for this brand should run until the preset exists. The kit file is done; the wiring is a recorded gap, filled next session the machine is up.
    - A kit whose approval is PENDING may still get its preset (the kit is usable); downstream provenance carries the pending state either way.
    - **Then attach it to any plan that is already waiting, if it is not attached already.** The brief is written and sent BEFORE this room runs (Day 3 sends, Day 4 dresses), so a saved listing-builder plan usually already exists; on a logo-only product `/reference-sheet` has already attached the preset, in which case there is nothing to attach and the read-back is the whole job. Check the product's `brief/creative-brief.md` `## Send log`: if it records a saved plan, apply this preset to that set (the apply-branding-preset capability, targeting the listing builder set; discover it with `search_capabilities` if it is not directly visible) and record `applied to [product] plan [YYYY-MM-DD]` under `## Style engine`. A preset that exists but was never attached dresses nothing, and the failure is silent because the images generate anyway, just generic.
    - **READ THE PLAN BACK AFTER THE ATTACH, every time.** Attaching a preset is a setup-level write. On the current server a setup write preserves a saved approval (measured 26 August 2026), but earlier builds silently reset it to `approved: false` with nothing in the response saying so (CLAUDE.md, Genrupt contract rule 6). The free read-back is correct either way: confirm the preset shows attached AND `approved: true`, and re-save the approval if it dropped.

13. **Updating an existing kit.** Change only what was named. Any change to a color, a font token, a claim or the avoid list RESETS approval: write a fresh `Owner approval:` line and one note under `Last updated` naming what changed and the old value ("Primary was #1E3D34, now #14332B, owner approved"). A new claim faces the same two tests. A kit approved once does not grandfather anything in. And any change to a color or font token is pushed to the branding preset in the SAME session (step 12), with a fresh date on the `Branding preset:` line. A kit and preset that disagree is drift, and the preset is the one the images obey.

14. **Backfill.** Search every product artifact under `factory/Products/*/` (briefs, A+ plans, variation plans) for the marker `pending brand kit`. Fill each field from the finished kit and list the files updated. If a marker cannot be resolved from the kit, because it needs a value the kit does not hold, name the file and the field and LEAVE the marker in place. Never delete a marker you did not resolve.

## Output format

Fill the SHIPPED template `factory/Brand/brand-kit.md` in place. Keep its exact section headers: `## Brand identity`, `## Colors`, `## Fonts and typography direction`, `## Tone words`, `## Logo rules`, `## Style engine`, `## APPROVED CLAIMS . the only claims allowed on images`, `## Avoid list`. Replace every placeholder with a real value, add the `Kit basis` row, and stamp the full footer.

```markdown
## Brand identity
| Field | Value |
|---|---|
| Brand name | [real name] |
| One-line positioning | [real line] |
| Website / storefront | [URL or n/a] |
| Kit basis | brand book: [filename] OR style guide: [filename] |

## Colors
| Role | Hex | Notes |
|---|---|---|
| Primary | #XXXXXX | [description. Source: from brand book (p. N) / not established by the guide] |
| Secondary | #XXXXXX | |
| Accent | #XXXXXX | [highlights and real on-product seals only] |
| Background | #XXXXXX | [typical backdrop tone] |
| Text on light | #XXXXXX | |

Text-safe pairs: [which colors may carry text, which may never]

## Fonts and typography direction
- Headline style: editorial serif | clean sans | bold display
- Supporting text style: [same three tokens]
- Overall look in one sentence: [summary]
- Licensed font on file: [name, human design work only] or n/a
(plus the template's standing note: image models cannot load font files; this describes the LOOK)

## Tone words
- Sounds like: [3 to 5 words, each with what it means for imagery]
- Never sounds like: [3 to 5 words]

## Logo rules
Logo-USE rules as stated by the supplied guide, or the literal `not established by the guide`. The
logo FILE itself belongs to `/reference-sheet`; this section never requires one to exist.
- Placement: [placement, size, clear space, as the guide states it]
- One logo per image maximum.
- Standing compliance rule: no logo is drawn, approximated, spelled out or invented.

## Style engine
How this brand reaches Genrupt. Style travels ONLY through these two; hex codes, font names and style prose never go into brief text.
| Field | Value |
|---|---|
| Branding preset | [id], updated [YYYY-MM-DD] . or PENDING with the reason |
| Carries a logo | yes (wired by /reference-sheet) | no . this room never sets it either way |

## APPROVED CLAIMS . the only claims allowed on images
| Claim | Proof | Where it may appear |
|---|---|---|
| [e.g. 4 tiers] | [product spec and listing] | [as plain printed text] |
(or the literal line: No claims approved. Images carry only what is physically printed on the product.)

## Avoid list
- [full Golden Standards compliance set, restated]
- [true, not allowed on images: rank, star ratings, review references] . reason
- [disputed promise from reviews] . reason
- [brand-specific avoids] . reason

---
Sources used: [the brand book or style guide, by name]. Not established by it: [list].
Owner approval: APPROVED [YYYY-MM-DD] by [name]   |   PENDING . built [YYYY-MM-DD] from [sources], awaiting owner confirmation
Last updated: [YYYY-MM-DD] by /brand-kit. [on an update, one line naming what changed and the old value]
```

## Owner approval, and the PENDING contract

A kit may legitimately be built while the owner is not in the room. In that case extract everything honestly from the supplied guide, mark every reading that needed judgement as a reading, and write the `Owner approval: PENDING` footer line instead of blocking. That line is the contract:

- The kit is USABLE. Briefs and generations may proceed on it.
- Every downstream room that reads the kit names the pending state in its own `Built from:` provenance line (`factory/Brand/brand-kit.md, owner approval PENDING`), so nobody downstream mistakes a proposal for a decision.
- The approved-claims table carries the pending state hardest. A PENDING kit's claims are readings of what the guide proves, so anything unverified stays out of images until the owner confirms.
- Clearing it takes one sentence from the owner. Then rewrite the line to APPROVED with the date and the name, and say which rooms were waiting.

Never write APPROVED because the kit looks correct. Correct and approved are different states, and only the owner can move between them.

## Golden Standards check

Before presenting, verify:
- [ ] A real Brand Book or Style Guide was read, and it is named in `Kit basis`. Nothing in this file was reasoned from the product, the category, the buyer, the website, the packaging or past creative.
- [ ] Every color present is a concrete hex code with a recorded source in the guide. No "greenish". No value labeled `sampled` that was not actually seen. Anything the guide did not establish reads `not established by the guide`, not a filled-in guess.
- [ ] Text-safe pairs named: which colors may carry text and which may not.
- [ ] Both font tokens locked from the three allowed and written literally, or recorded as not established.
- [ ] Every approved claim passed BOTH tests and has a proof entry. Anything true-but-barred sits on the avoid list, marked, not quietly kept. An empty table carries the literal no-claims line.
- [ ] The avoid list holds the full Golden Standards compliance set, plus brand specifics, plus every true-but-barred item and disputed promise, each with a reason.
- [ ] The logo file was NOT touched by this room. If a preset already carried a logo, the read-back proves `hasLogo: true` and the same `logoUrl` survived this room's update.
- [ ] `## Style engine` carries a branding preset id that a tool actually returned (with its date), or an honest `PENDING . Genrupt unavailable` line. Never an invented id, never blank. The same id is written into the product's `status.md` `Genrupt preset ID` row.
- [ ] No style image was chosen or proposed here. That decision is Day 6's, inside Refine.
- [ ] Nothing in this kit is destined for brief text: no hex code, font name, or style sentence is queued for any `contentBrief`, header phrase, or custom instruction. Style ships by preset only; the set's look is chosen on Day 6 in Refine.
- [ ] No placeholder survives anywhere in the file (the step 10 check ran and passed).
- [ ] Footer carries `Sources used` / `Not available` and an `Owner approval:` line reading APPROVED or PENDING. Never blank, never absent.

## Wonka lines

Openers:
- "The Brand Room. The candy may be perfect, but the wrapper is what they see first on the shelf."
- "Every factory has its colors. Show me yours, hex codes and all."
- "No brand book, no style guide? Then there is nothing for me to read, and I will not invent one. Your product styles itself, and that is a real answer."

On the claims table:
- "True and allowed are two different tests, and only one of them keeps your listing standing."
- "No proof, no claim. I have never met a regulator who enjoyed theater."

On the preset:
- "The wrapper is not a memo, it is a machine setting. We set it once and every image comes out wearing it."
- "The wrapper is decided here. Which picture the whole set should feel like, you decide on Day 6, with real pictures in front of you."

Closers:
- "Wrapped, approved, and wired into the machine. Every image from here on wears these colors or it doesn't leave the building."
- "One kit, one preset, every product. That's the economy of a good wrapper."
- "Your brand now fits in one file and one preset id. The generation rooms pass the id, Genrupt does the dressing."

## Definition of Done

- A real Brand Book or Style Guide was supplied. If none was, the room ended at step 0 with `Brand kit: none` written to `status.md`, nothing proposed, and nothing pending: that is a complete, correct run of this skill.
- `factory/Brand/brand-kit.md` is filled IN PLACE with what the guide established: hex colors each carrying a source, the text-safe pairs where named, the font tokens, tone words both ways, any logo-use rules, a `## Style engine` section, an approved-claims table where every row has proof (or the literal no-claims line), and an avoid list. Everything the guide did not establish reads `not established by the guide`.
- Zero placeholders remain. The step 10 self-check ran.
- The Genrupt branding preset is created or updated with the kit's colors and font direction, and its returned id is recorded in `## Style engine` with a date. If Genrupt was unreachable, the line reads `PENDING . Genrupt unavailable [date]` instead. **Both are recorded states; a silent skip is neither.**
- The `Kit basis` row names the guide, and the footer carries `Sources used` / `Not established by it` plus an `Owner approval:` line reading APPROVED with a date and a name, or PENDING with what it awaits. **Both are done states. A missing, blank or assumed approval line is not.**
- Any logo already on the preset survived this room untouched, proven by the read-back.
- The product's `status.md` carries the returned preset id in `Genrupt preset ID`, and its `Logo in preset` row is unchanged by this room.
- Every `pending brand kit` marker under `factory/Products/*/` is either resolved or reported by file and field.

## Update status.md

Brand kit is brand-level, not product-level. If a product folder exists, write the current product's
`status.md`: set the `Brand kit` row (the kit path, or `none` when there was no guide to read), set
the `Genrupt preset ID` row to the id the tool returned, and **leave the `Logo source` and `Logo in
preset` rows exactly as they are** . they belong to `/reference-sheet`. Then add a Log line:
`[YYYY-MM-DD] Brand kit built/updated at factory/Brand/brand-kit.md from [guide filename]. Branding preset: [id] | PENDING. Owner approval: APPROVED | PENDING.`
On a step 0 ending: `[YYYY-MM-DD] No brand book or style guide. Brand kit: none. Nothing proposed, nothing pending.`
Nothing downstream waits for this room, so there is no station to unblock. Repeat any pending state (approval or preset) so the next session sees it.

If no product exists yet, because the kit was built before the first product, there is nothing to log. Say so and let `/meet-my-product` pick it up at the Front Gate. Never create a product folder just to have somewhere to write.

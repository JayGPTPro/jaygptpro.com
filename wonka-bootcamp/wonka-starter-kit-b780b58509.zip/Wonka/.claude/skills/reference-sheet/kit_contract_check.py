"""Static contract check for the three separated concepts: product/packaging
references, a real logo asset, and optional brand styling.

Three things kept getting conflated in this kit, and each one produced a real
defect on a real run:

1. A logo was treated as brand-kit work, so a seller with a logo and no brand
   book was told to build a brand.
2. `/brand-kit` proposed an invented identity when no brand files existed.
3. Generation rooms inferred the Genrupt preset from the existence of
   `brand-kit.md`, so a logo-only preset was invisible to them.

This scanner reads the SHIPPED kit and fails on the wording that brings any of
those back. It is text-only: no Genrupt call, no network, no product data.

Run: python3 kit_contract_check.py [kit_root]
"""
import re
import sys
from pathlib import Path

# (id, regex, why it is banned). Matched case-insensitively, line by line.
BANNED = [
    ("proposes-a-brand",
     r"(wonka )?propos(e|es|ing) (a |the )?(full |complete )?(kit|brand|palette|identity|direction)",
     "/brand-kit must never invent a brand when no Brand Book or Style Guide exists"),
    ("wonka-proposes-mode",
     r"\*\*WONKA PROPOSES",
     "the proposal mode was removed; there are two states, guide or no guide"),
    ("logo-blocks",
     r"(missing|no) logo (is|as) a gap",
     "a missing logo is finished work, never a gap"),
    ("logo-needs-brand-kit",
     r"logo (file )?(is )?required for (branding|the brand kit)",
     "a logo never depends on brand styling"),
    ("brand-book-required-for-logo",
     r"brand book is required",
     "a logo needs no Brand Book"),
    ("logo-into-packaging",
     r"logo[^.\n]{0,40}(packagingImages|packaging bucket)",
     "packagingImages is a semantically wrong destination for a logo"),
    ("logo-into-slot-refs",
     r"logo[^.\n]{0,40}slot(')?s? referenceImages",
     "per-slot referenceImages is not the logo route"),
    ("preset-only-from-kit-file",
     r"preset (is )?(only )?(resolved|read) from `?factory/Brand/brand-kit\.md",
     "the canonical preset lookup is the status.md Genrupt preset ID row"),
    ("file-management-homework",
     r"(drop|place|move|put) (the |your )?(actual |real )?files? (into|in) `?2-reference",
     "users attach files to Claude; Wonka routes them"),
]

# Sentences that must SURVIVE, so a later cleanup cannot quietly delete the contract.
REQUIRED = [
    ("factory/Products/TEMPLATE/status.md", "Logo source"),
    ("factory/Products/TEMPLATE/status.md", "Genrupt preset ID"),
    ("factory/Products/TEMPLATE/status.md", "Logo in preset"),
    ("factory/Products/TEMPLATE/status.md", "no logo supplied"),
    (".claude/skills/reference-sheet/SKILL.md", "logoThumbnailUrl"),
    (".claude/skills/reference-sheet/SKILL.md", "apply_branding_preset"),
    (".claude/skills/brand-kit/SKILL.md", "Brand Book or Style Guide"),
    ("guides/genrupt-intake-guide.md", "logo-only preset is lawful"),
    ("CLAUDE.md", "Genrupt preset ID"),
]

SKIP_DIRS = {"__pycache__", ".git", "_archive", "node_modules"}
# Frozen history, not shipped text: an upgrade leaves the old kit beside the new one.
SKIP_PREFIXES = ("_backup", "_pre-upgrade", "_superseded")


NEGATOR = re.compile(r"\b(never|not|nor|without|rather than)\b", re.I)
SENTENCE = re.compile(r"(?<=[.;:])\s+")


def negated(line, match):
    """True when this match sits in a sentence that FORBIDS the thing.

    A rule has to name what it bans, so "a logo is never routed into
    packagingImages" would otherwise read as a violation of itself. The unit is
    the SENTENCE, not the paragraph, and the bare word "no" is deliberately not
    a negator here: "with no brand files, Wonka proposes a complete kit" is
    exactly the sentence this scanner exists to catch.
    """
    pos, sentence = 0, line
    for part in SENTENCE.split(line):
        if pos <= match.start() < pos + len(part) + 1:
            sentence = part
            break
        pos += len(part) + 1
    return bool(NEGATOR.search(sentence))


def logical_lines(text):
    """Yield (first_line_no, joined_text) per paragraph.

    Prose in this kit is hard-wrapped, so "Wonka does not propose a palette from
    the product" is split across two physical lines and a per-line negation check
    reads the second half as an assertion. Paragraphs are the honest unit.
    """
    buf, start = [], 1
    for n, raw in enumerate(text.splitlines(), 1):
        if raw.strip():
            if not buf:
                start = n
            buf.append(raw.strip())
        elif buf:
            yield start, " ".join(buf)
            buf = []
    if buf:
        yield start, " ".join(buf)


def scan(root: Path):
    """Return (violations, missing_required). Each violation is (file, line_no, id, text)."""
    violations = []
    for path in sorted(root.rglob("*.md")):
        parts = set(path.parts)
        if parts & SKIP_DIRS or any(q.startswith(SKIP_PREFIXES) for q in parts):
            continue
        for n, line in logical_lines(path.read_text(encoding="utf-8")):
            for bid, pattern, _why in BANNED:
                m = re.search(pattern, line, re.I)
                if m and not negated(line, m):
                    violations.append((str(path.relative_to(root)), n, bid, line.strip()[:120]))
    missing = []
    for rel, needle in REQUIRED:
        f = root / rel
        if not f.exists() or needle not in f.read_text(encoding="utf-8"):
            missing.append((rel, needle))
    return violations, missing


def main(argv):
    root = Path(argv[1]) if len(argv) > 1 else Path(__file__).resolve().parents[3]
    violations, missing = scan(root)
    for f, n, bid, text in violations:
        print(f"ERROR [{bid}] {f}:{n}  {text}")
    for rel, needle in missing:
        print(f"ERROR [missing-contract] {rel} no longer says {needle!r}")
    if violations or missing:
        print(f"\n{len(violations)} contradiction(s), {len(missing)} missing contract line(s).")
        return 1
    print("kit contract clean: logo, brand styling and product references stay separate.")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))

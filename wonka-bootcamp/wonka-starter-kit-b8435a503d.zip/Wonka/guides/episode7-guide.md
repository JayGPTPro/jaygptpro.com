# Day 7: The A+ Room

Below the fold on every listing there is a second product page. Half your competitors left theirs
empty. Today you build yours, and when it is done your product page is COMPLETE.

Today is also the odd day out. For four days you have been told to control every field. Today you
deliberately hand one asset over, and the reasoning is the lesson.

**The sentence for the day: here the job is not to say everything, it is to look like somebody who
knows what they are doing.**

Two lessons. Lesson 1 generates the concepts and ends with your chosen one on disk, already cut
into module files for Amazon. Lesson 2 inspects that choice, fixes it on the files, and leaves you
with the set that goes up.

## What you will have by the end of today

- **A set of A+ concepts on desktop and on mobile**, one of them chosen per mode
- A deliberate decision on **how many modules**, with the reason recorded
- **The chosen concept exported as module files**, cut to Amazon's sizes, the moment you picked it
- The A+ gate-passed: inspected as hard as everything else, and repaired **on the exported files**
- A fixed set in `edits/vN/aplus/` that you could upload right now, with Wonka naming the files
- Your whole page read top to bottom as one thing, and your coverage map fully closed

## What you will need at hand

- Your finished gallery from Day 6, and the style you sent to Refine. **Today's A+ inherits it**
- Your brand kit and its approved claims table, if you have one
- **A decision waiting:** are you adding a module of your own, like a comparison chart or an FAQ?
  Lesson 1 explains why this has to be answered before anything generates
- Genrupt connected. Wonka runs it for you today; you never open the app to make a choice

---

## Lesson 1: Generate and choose your A+

### Who actually reads this

Most shoppers never scroll below the fold. That sounds like a reason to ignore the A+ and it is the
opposite.

The people who DO scroll that far are seriously considering buying and are hunting for a reason to
say yes, or a reason to leave. **They are the most valuable readers you have** and they are already
deep in.

Your hero earns the click. Your gallery answers the fears. **Your A+ closes the person who is already
leaning in.**

### Beautiful beats complete

Everywhere else in this factory the job is making sure every message lands. The coverage map. The
buyer question per slot. Nothing dying in silence.

**Here that matters much less.**

What you want from an A+ is that somebody scrolling it feels they are in good hands. That this is a
real brand, that these people know what they are doing, that this is not a drop-shipped thing with a
logo on it. **The A+ upgrades the scroll: a page that looks professional and invested.**

**The primary job of the A+ is to be beautiful and impressive.** A module that ticks a coverage box
and looks mediocre does more harm than a module that says less and looks expensive.

So if you find yourself fighting the machine to cram a fourth message into module three: stop. You
are optimising for the wrong thing, in the one room where that is genuinely wrong.

And know the ending before you start: **the page comes back cut into module files for Amazon.** The
A+ is one canvas, but Amazon takes it as separate modules. By the end of this lesson the files of
your chosen concept sit in `aplus/export/[mode]/`, at Amazon's sizes, named, ready.

### Which is why we do not brief it

Open your brief and look at the A+ section. Three lines. On purpose.

**One. It is a design-heavy asset and the planner is better at it.** Multi-module layout, typography,
rhythm. A different craft from one frame carrying one message.

**Two. It is not what gets tested.** Your hero gets raced on Day 8, and A/B tested on Amazon after
you upload. The A+ does not. The return on controlling every field here is much lower, and the time
costs the same.

**Three, and this is the real one. Deciding what NOT to control is a skill.** Anyone can want control
of everything. What actually happens to sellers is that they run out of hours, and the ones who ship
decided in advance where their attention was worth the most.

**What you do NOT give up is the check.** It gets judged hard, in lesson 2. Hands-off in the planning
is not hands-off in the gate.

### Settings before generating

```
/aplus
```

Wonka confirms the inherited pieces one line each. Read them back with him, because **this is what
makes hands-off safe rather than reckless:**

- The **locked reference**, so it is your real product
- The **style you sent to Refine on Day 6**, so this looks like your gallery rather than a different
  company
- Your **branding preset**, if you have one
- Your **approved claims table**, so it cannot say something you have not proved

Then he asks the machine settings that are yours, in one message, and waits.

**What a module is.** One strip of the page. Amazon takes the A+ as a stack of these, each at a fixed
size, and it caps how many the page can carry. **Every module the machine generates is a slot you
cannot use for something else.**

**How many modules, and whether to keep a slot for your own.** If you plan to add a module the machine
cannot write, usually a comparison chart or an FAQ, because they carry information only you have,
you generate one fewer and keep the slot. Generate the full count, then discover there is no room
for the comparison you wanted, and you are rebuilding. **One question up front prevents it: am I
adding a module of my own?** The answer and its reason go in the record.

**Desktop and mobile.** Most people who read your A+ read it on a phone. Ask for both modes rather
than desktop first and a conversion later.

**How many concepts per mode.** The same arithmetic as every other room: the best of several beats
the only one, and this asset's entire job is to look impressive.

**The expected cost.** Wonka shows the live preview beside the measured number. On this workflow the
preview said 60 and the charge was 72, both measured runs. Read the second number as the price.

**There are no design settings.** Dense or minimal, layout, colours: none of these is a knob. The look
is inherited from the style you locked on Day 6, and the planner does the rest. If Wonka asked you a
creative question here, something would be wrong.

**The premium carousel**, once: it exists, it is a distinct module type, and it spends a slot. Wonka
never recommends it and never asks about it. If you want one, say so with your other answers.

### Generate and look

Wonka runs Genrupt and brings the pages back. Open them and scroll each one as a shopper, not as an
inspector. Talk about what you see:

- **Beauty.** Does this look like a brand I would buy from?
- **Legibility.** Can I read it on a phone without squinting?
- **Load.** Is any module carrying too much?
- **The scroll.** Does the page feel like one thing top to bottom?

Your gut is the closest thing in this room to your buyer's, and this is the only uncontaminated
reading of the page you will ever get. Judgment comes in lesson 2.

**Ask for more if you want more.** A second round repeats the same recipe; Wonka restates your
answers in one line and runs, and never asks them twice. Its numbers continue from the first round:
desktop 15 to 18, mobile 5 to 8, so a pick is never ambiguous.

### Choose

Pick a design per mode **by the number on Wonka's sheet**, never by the number the app shows. Wonka
reads the pick back before anything moves. If the one you like exists in one mode only, ask him to
convert it to the other.

**Wonka exports the chosen concept at once, as part of the pick.** The module files land in
`aplus/export/[mode]/`, cut to Amazon's sizes. He lists the folder rather than trusting a success
message: does the module count match, is every mode there, is anything zero bytes.

The lesson ends when you know which design you want to keep improving, and its files are on disk.

---

## Lesson 2: Inspect, fix, prepare the upload

### Inspect the choice

```
/inspect the A+
```

Wonka checks the exported modules one by one, and the stacked page as a whole. Same loop as Day 5,
no new rules. Two things bite harder on an A+ than anywhere else:

**Text size.** A+ modules are where walls of small text go to die. There is more room, so more words
appear, and then nobody reads any of them on a phone. The squint test is unforgiving here and it
should be.

**Claims.** More copy means more surface area for a sentence nobody can prove. Every claim goes
against your approved claims table. **The machine wrote this copy. It is not the one whose account is
on the line.**

You look too. Open the modules at full size and check three things yourself: **the product** (is it
mine, every part present, the right material), **the text** (a wrong word, a typo, a claim you never
approved), **the people** (does anyone look drawn rather than photographed). Say what needs a fix
through the examples on screen, in plain language: "module three, the word on the badge is wrong",
"the fountain on the left has one tier too few".

### Fix, and check again

**After the export, every fix is on the file.** That is the rule for the rest of the day.

Every fix is local, on the exported module, through Wonka:

```
/fix
```

Say clearly what is wrong and how it should look. Wonka edits the one region, composites it back so
every pixel outside the box is the original's, and shows you before and after. You confirm two
things: the problem is gone, and the design is kept. A fix that moved the rest of the module is
rejected.

Because the page is one canvas sliced into strips, a module has neighbours. After a fix near a
module's top or bottom edge, Wonka reads the seam to make sure it still meets the strip above or
below.

**The default is to fix the design you chose.** The same wrong word in three modules is three local
fixes, and that is fine. Only when you want a different layout or a different direction for the
whole page do you pick another concept, or ask for another round. Either way you keep talking to
Wonka; you never go into the app to change something.

**The original survives.** The export stays untouched in `aplus/export/`, and every fixed round saves
as a complete snapshot in `edits/vN/aplus/`.

### The face clinic

A module with people can come back with an AI-looking face: skin too smooth, a hand with the wrong
count, eyes that do not quite land. That is a local defect like any other, with its own door:

```
/fix-faces
```

Run it on the module, name the person. Wonka repairs the face on that file and composites it back.
Judge the result the way you judge any fix: the person looks photographed, the rest of the module is
untouched, the seam is clean. Then run the module through `/inspect` again.

### The final product and the files

Scroll the finished page top to bottom as a stranger would, in one go. Then ask the three page
questions:

**Does the story hold?** The hero makes a promise, the gallery expands it, the A+ closes it.

**Does anything contradict?** This is where a claim you removed from a gallery frame on Day 6 quietly
reappears in an A+ module written on Day 7. Nobody has seen them side by side until now.

**Does it repeat itself?** If the A+ is your gallery again in a longer format, your most engaged
reader learned nothing for the trouble of scrolling that far.

Then open the folder. The modules sit in order, per mode. **What goes to Amazon is the fixed set in
`edits/vN/aplus/`**, and Wonka names exactly which files. A fresh export from Genrupt would not carry
your local fixes, so it is never the set you upload.

### Close the map

Your coverage map has had an A+ column open since Day 3: the selling points you EXPECTED to land
here rather than in the gallery. This is the moment it closes. Anything expected here that did not
arrive gets **named**, not quietly forgotten.

---

## MISSION 1: Answer the settings, then generate

Are you adding a module of your own? Both modes? How many concepts per mode?

```
/aplus
```

Give the answers in one message. Read the cost line, then open every page and say what you see.

## MISSION 2: Choose

Pick a design per mode by the number on Wonka's sheet. Hear him read it back. Then list
`aplus/export/[mode]/` with him and check the count.

## MISSION 3: Inspect and fix on the files

```
/inspect the A+
```

```
/fix
```

Name each defect in plain language. Confirm before and after on every fix. A face that looks drawn
goes to `/fix-faces`. Re-inspect until green.

## MISSION 4: Read the page and name the upload set

Scroll the whole page like a stranger and answer the three page questions. Then open
`edits/vN/aplus/` and have Wonka name the files that go up.

**Share it:** send Jay your assembled page, top to bottom, as one screenshot. This is the first time
anybody but you sees a whole page rather than a piece of one.

---

## Day 7 closes on the fixed set

That is the day. Nothing else is owed tonight. Day 8 opens by fetching your live main image and
gallery into `incumbent/` itself, at the first step of `/tasting-room`, so the races run against
what is on your listing right now.

---

## What good looks like

- The module count was decided before generating, not discovered afterwards
- The A+ inherits your locked reference, the Day 6 style, your preset if you made one, and your
  approved claims
- Concepts on both modes, and you picked on beauty rather than coverage
- The pick was by Wonka's number, read back, and the export landed with it
- Every claim traced to your approved claims table
- Every fix done on the exported file, before and after confirmed, originals untouched
- The upload set named by file in `edits/vN/aplus/`
- All three page questions answered, and the A+ column of your coverage map closed

## Common mistakes

- **Generating the full count when you wanted a comparison chart.** One question up front prevents a
  rebuild.
- **Fighting to cram messages in.** Wrong goal, in the one room where it is genuinely wrong.
- **Asking for a look.** Dense, minimal, colours: the look was locked on Day 6, and there is no knob.
- **Picking by the app's number.** Wonka's sheet is the only numbering that counts.
- **Desktop only.** Most of your A+ readers are on a phone.
- **Picking the concept that covers the most.** Pick the one that looks like a brand.
- **Switching concepts to dodge a fix.** A wrong word is a local fix, three times if it appears three
  times. A new concept is for a new direction.
- **Uploading a fresh export.** It does not carry your fixes. The upload set is `edits/vN/aplus/`.
- **Skipping the page read.** It is the only check that catches the story falling apart between the
  hero and the fold.

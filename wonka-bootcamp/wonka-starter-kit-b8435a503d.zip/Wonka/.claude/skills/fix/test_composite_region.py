"""composite_region.py: only the boxes change, every other pixel is the base's own.
Run: python3 test_composite_region.py

Pixel verification, not PNG byte comparison: every check reads the output back as an array and
compares it to the base outside the box union, ring by ring, and looks for the fix inside it."""
import subprocess, sys, tempfile
from pathlib import Path
import numpy as np
from PIL import Image
HERE = Path(__file__).parent
TOOL = str(HERE / "composite_region.py")
fails = []
def check(name, cond): print(("  PASS  " if cond else "  FAIL  ") + name); fails.append(name) if not cond else None

def run(base, render, out, *args):
    return subprocess.run([sys.executable, TOOL, str(base), str(render), str(out), *args], capture_output=True, text=True)

def allowed_mask(shape, boxes):
    m = np.zeros(shape[:2], bool)
    for x, y, w, h in boxes: m[y:y + h, x:x + w] = True
    return m

def outside_untouched(out, base, boxes):
    """Every pixel outside the union of boxes is byte-identical to the base."""
    m = allowed_mask(base.shape, boxes)
    return int((np.abs(out.astype(int) - base.astype(int)).sum(2)[~m] > 0).sum())

with tempfile.TemporaryDirectory() as d:
    d = Path(d)

    # --- the original scenario: a whole-frame drift with the fix in one region, render at another size
    base = np.zeros((300, 400, 3), np.uint8); base[:] = (200, 180, 160)
    Image.fromarray(base).save(d / "base.png")
    render = base.copy(); render[:] = (10, 10, 10)            # the endpoint changed the whole frame
    render[100:200, 50:150] = (255, 0, 0)                     # the fix we want is inside this region
    Image.fromarray(render).resize((320, 240)).save(d / "render.png")   # and it came back at a different size
    r = run(d / "base.png", d / "render.png", d / "out.png", "40,90,120,120", "--feather", "8")
    check("runs and reports 0 pixels changed outside the boxes", r.returncode == 0 and "0 outside" in r.stdout)
    out = np.asarray(Image.open(d / "out.png").convert("RGB"))
    check("outside the box the output equals the base exactly", np.array_equal(out[:, 200:], base[:, 200:]) and np.array_equal(out[:80], base[:80]))
    check("inside the box the render's fix arrived", (out[150, 100] == (255, 0, 0)).all())
    check("the one-pixel ring hugging the box is untouched (scenario 1)", outside_untouched(out, base, [(40, 90, 120, 120)]) == 0)
    r2 = run(d / "base.png", d / "render.png", d / "out2.png")
    check("refuses to run without a box", r2.returncode != 0)

    # --- the reproduced bug: black base, white render, one box, feather 24
    black = np.zeros((256, 256, 3), np.uint8); white = np.full((256, 256, 3), 255, np.uint8)
    Image.fromarray(black).save(d / "black.png"); Image.fromarray(white).save(d / "white.png")
    r = run(d / "black.png", d / "white.png", d / "one.png", "64,64,128,128", "--feather", "24")
    out = np.asarray(Image.open(d / "one.png").convert("RGB"))
    leaked = outside_untouched(out, black, [(64, 64, 128, 128)])
    check("one box, feather 24: no pixel outside the box changed (was 10,125 on v28)", leaked == 0)
    check("one box: pixel (63,100) just left of the box is still black", (out[100, 63] == 0).all())
    check("one box: the ring hugging the border is untouched on all four sides",
          (out[63, 64:192] == 0).all() and (out[192, 64:192] == 0).all() and (out[64:192, 63] == 0).all() and (out[64:192, 192] == 0).all())
    check("one box: the fix lands (centre pixel is white)", (out[128, 128] == 255).all())
    inside_changed = int((out.astype(int).sum(2)[64:192, 64:192] > 0).sum())
    check("one box: the printed inside count equals the pixels that really changed",
          r.returncode == 0 and f"{inside_changed} pixels changed inside" in r.stdout and "0 outside" in r.stdout)

    # --- several boxes, apart
    boxes = [(10, 10, 60, 60), (150, 40, 70, 50), (40, 170, 90, 60)]
    r = run(d / "black.png", d / "white.png", d / "many.png", *[",".join(map(str, b)) for b in boxes], "--feather", "16")
    out = np.asarray(Image.open(d / "many.png").convert("RGB"))
    check("several boxes: nothing outside the union changed", r.returncode == 0 and outside_untouched(out, black, boxes) == 0)
    check("several boxes: each box centre took the render (near white; the inward feather still softens small boxes)",
          all((out[y + h // 2, x + w // 2] >= 240).all() for x, y, w, h in boxes))

    # --- overlapping boxes
    boxes = [(50, 50, 100, 100), (100, 100, 100, 100)]
    r = run(d / "black.png", d / "white.png", d / "overlap.png", *[",".join(map(str, b)) for b in boxes], "--feather", "24")
    out = np.asarray(Image.open(d / "overlap.png").convert("RGB"))
    check("overlapping boxes: nothing outside the union changed", r.returncode == 0 and outside_untouched(out, black, boxes) == 0)
    check("overlapping boxes: the overlap and both box centres took the render (near white)",
          (out[125, 125] >= 240).all() and (out[100, 100] == 255).all() and (out[150, 150] == 255).all())
    check("overlapping boxes: the notch corner outside both boxes is still black", (out[49, 49] == 0).all() and (out[200, 200] == 0).all() and (out[49, 149] == 0).all())

    # --- a box touching the image edge
    r = run(d / "black.png", d / "white.png", d / "edge.png", "0,0,96,256", "--feather", "24")
    out = np.asarray(Image.open(d / "edge.png").convert("RGB"))
    check("box on the image edge: nothing outside the box changed", r.returncode == 0 and outside_untouched(out, black, [(0, 0, 96, 256)]) == 0)
    check("box on the image edge: the column just right of the box is black", (out[:, 96] == 0).all())
    check("box on the image edge: the fix lands", (out[128, 48] == 255).all())

    # --- an unchanged render leaves the output identical and reports 0 inside
    r = run(d / "black.png", d / "black.png", d / "same.png", "64,64,128,128", "--feather", "24")
    out = np.asarray(Image.open(d / "same.png").convert("RGB"))
    check("unchanged render: output equals the base everywhere", r.returncode == 0 and np.array_equal(out, black))
    check("unchanged render: reports 0 inside and 0 outside", "0 pixels changed inside" in r.stdout and "0 outside" in r.stdout)

    # --- validation before writing
    r = run(d / "black.png", d / "white.png", d / "bad1.png", "200,200,100,100")
    check("box past the image edge: exits non-zero and writes nothing", r.returncode != 0 and not (d / "bad1.png").exists())
    r = run(d / "black.png", d / "white.png", d / "bad2.png", "10,10,0,50")
    check("empty box: exits non-zero and writes nothing", r.returncode != 0 and not (d / "bad2.png").exists())
    r = run(d / "black.png", d / "white.png", d / "bad3.png", "10,10,20,20", "--feather", "24")
    check("feather not smaller than the box: exits non-zero and writes nothing", r.returncode != 0 and not (d / "bad3.png").exists())
    r = run(d / "black.png", d / "white.png", d / "bad5.png", "10,10,4,4", "--feather", "3")
    check("feather that leaves almost no render inside a small box (4x4, feather 3): exits non-zero and writes nothing",
          r.returncode != 0 and not (d / "bad5.png").exists())
    r = run(d / "black.png", d / "white.png", d / "bad4.png", "10,10,20")
    check("malformed box: exits non-zero and writes nothing", r.returncode != 0 and not (d / "bad4.png").exists())

print("composite_region:", "FAIL" if fails else "PASS", f"({len(fails)} failures)")
sys.exit(1 if fails else 0)

#!/usr/bin/env python3
"""The Face Clinic engine, offline. The API call is stubbed; everything our
side owns is real: box parsing, the composite contract (outside pixels are the
original, byte for byte), the tone-match field and its cap.

Each check encodes a real failure, measured before it was fixed.

Run: python3 test_face_fix.py
"""
import sys
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

FAILURES = []


def check(name, cond, detail=""):
    cond = bool(cond)
    detail = str(detail)          # a numpy array as detail must not crash the harness
    print(("  PASS  " if cond else "  FAIL  ") + name + ("  " + detail if not cond and detail else ""))
    if not cond:
        FAILURES.append(name)


def run():
    import numpy as np
    from PIL import Image
    import face_fix

    # -------- box parsing refuses nonsense before any spend
    ok = face_fix.parse_boxes("10,10,50,60; 70,10,120,80")
    check("boxes parse", ok == [(10, 10, 50, 60), (70, 10, 120, 80)], ok)
    for bad in ("50,60,10,10", "1,2,3", ""):
        try:
            face_fix.parse_boxes(bad)
            check(f"bad box '{bad}' refused", False)
        except SystemExit:
            check(f"bad box '{bad}' refused", True)

    # -------- the composite contract, with the API stubbed out
    tmp = Path(tempfile.mkdtemp())
    rng = np.random.default_rng(5)
    base = rng.integers(60, 200, (300, 400, 3)).astype("uint8")
    src = tmp / "scene.png"
    Image.fromarray(base).save(src)

    # the "render": globally +25 brighter (the exposure shift that printed
    # rectangles), a new face painted in the box, and a GHOST far outside it
    render = np.clip(base.astype(int) + 25, 0, 255).astype("uint8")
    render[80:180, 60:160] = (200, 150, 120)        # the new face, inside the box
    render[40:80, 300:360] = (10, 10, 10)           # ghost the model invented elsewhere

    class FakeData:
        def __init__(self, png):
            import base64 as b64
            self.b64_json = b64.b64encode(png).decode()

    class FakeClient:
        class images:
            @staticmethod
            def edit(**kw):
                import io
                buf = io.BytesIO()
                Image.fromarray(render).save(buf, format="PNG")
                return type("R", (), {"data": [FakeData(buf.getvalue())]})

    import openai
    real = openai.OpenAI
    openai.OpenAI = lambda *a, **k: FakeClient
    try:
        dst = face_fix.run(src, [(60, 80, 160, 180)], quality="low")
    finally:
        openai.OpenAI = real

    out = np.asarray(Image.open(dst).convert("RGB")).astype(int)
    check("output lands beside the original", dst.name == "scene-faces-fixed.png", dst.name)

    # far outside the box: byte-identical to the source, so the ghost died
    check("the model's ghost OUTSIDE the box never reaches the result",
          np.abs(out[40:80, 300:360] - base[40:80, 300:360].astype(int)).max() == 0)

    # inside the box: the new face arrived (near its painted color, tone-matched)
    face = out[110:150, 90:130].mean(axis=(0, 1))
    check("the new face DID arrive inside the box",
          abs(face[0] - 200) < 30 and abs(face[2] - 120) < 30, face.round())

    # -------- the tone field is capped, so a ring can shade a seam but not recolor a face
    # The shift must sit INSIDE the trust window (under 30, over the 18 cap):
    # a +60 shift fails the agree test everywhere and the field never engages,
    # which made the first version of this check pass on uncapped code.
    o = Image.fromarray(base)
    shifted = np.clip(base.astype(int) + 25, 0, 255).astype("uint8")
    e = Image.fromarray(shifted)
    matched = np.asarray(face_fix._tone_match(o, e, (100, 100, 200, 200)), dtype=int)
    inner = np.abs(matched[130:170, 130:170] - shifted[130:170, 130:170].astype(int))
    applied = inner.max()
    check("the field engages on a trusted shift", applied >= 10, applied)
    check("and is capped at 18 per channel", applied <= 19, applied)

    print()
    # --- where the fix lands (kit v23) ---------------------------------------
    # Inside a product folder the result follows the round law and takes its
    # canonical name in a new edits/vN; a v22 `-faces-fixed.png` beside the source
    # was invisible to every room that resolves a file by name.
    prod = (Path(tempfile.mkdtemp()) / "fondue").resolve()
    (prod / "images").mkdir(parents=True)
    (prod / "status.md").write_text("x")
    for n in ("main-06.png", "sec-01.png"):
        (prod / "images" / n).write_bytes(b"x")
    dst = face_fix.default_dst(prod / "images" / "main-06.png")
    check("inside the factory the fix opens edits/v1 and takes the canonical name",
          dst == prod / "edits" / "v1" / "main-06.png", dst)
    check("and the round is a complete snapshot",
          (prod / "edits" / "v1" / "sec-01.png").is_file())
    dst2 = face_fix.default_dst(prod / "edits" / "v1" / "main-06.png")
    check("a second fix opens v2 from v1", dst2 == prod / "edits" / "v2" / "main-06.png", dst2)
    check("a legacy -faces-fixed name resolves to its canonical name",
          face_fix.canonical_name(Path("main-06-faces-fixed.png")) == "main-06.png")
    loose = (Path(tempfile.mkdtemp()) / "photo.png").resolve()
    loose.write_bytes(b"x")
    check("a loose file still lands beside the source",
          face_fix.default_dst(loose) == loose.with_name("photo-faces-fixed.png"))

    print()
    # --- a round is the ADOPTED set, not a copy of the last folder (kit v28) --
    # Reproduced 9 September 2026: Day 5 fixed the main into edits/v1; Day 6 put
    # eight secondaries into images/; the next fix opened v2 from v1 and the
    # eight secondaries were missing. And canonical_name('sec-03-v2.png') gave
    # 'sec-03.png': -v2 is a generation's own name, not a fix suffix.
    prod = (Path(tempfile.mkdtemp()) / "fondue").resolve()
    (prod / "images").mkdir(parents=True)
    (prod / "status.md").write_text("x")
    (prod / "images" / "main-01.png").write_bytes(b"main-original")
    v1 = prod / "edits" / "v1"
    v1.mkdir(parents=True)
    (v1 / "main-01.png").write_bytes(b"main-FIXED-day5")
    (v1 / "main-01-rejected.png").write_bytes(b"evidence")       # a failed attempt, kept
    (v1 / "main-01-render.png").write_bytes(b"evidence")         # the whole-frame render, kept
    secs = ["sec-01", "sec-02", "sec-03", "sec-03-v2", "sec-04", "sec-05", "sec-06", "sec-07"]
    for n in secs:                                               # Day 6, after the round
        (prod / "images" / f"{n}.png").write_bytes(n.encode())
    dst = face_fix.default_dst(prod / "images" / "sec-03-v2.png")
    v2 = prod / "edits" / "v2"
    check("a fix on a Day 6 secondary opens v2 under the SAME generation name",
          dst == v2 / "sec-03-v2.png", dst)
    have = sorted(f.name for f in v2.iterdir() if f.suffix == ".png") if v2.is_dir() else []
    want = sorted(["main-01.png"] + [f"{n}.png" for n in secs])
    check("the new round holds all nine adopted files", have == want, have)
    check("and keeps the FIXED main from v1, not the original",
          (v2 / "main-01.png").read_bytes() == b"main-FIXED-day5" if (v2 / "main-01.png").is_file() else False)
    check("a -rejected evidence file is not promoted into the round",
          not (v2 / "main-01-rejected.png").exists())
    check("a -render evidence file is not promoted into the round",
          not (v2 / "main-01-render.png").exists())
    check("canonical_name keeps a generation's -v2 identity",
          face_fix.canonical_name(Path("sec-03-v2.png")) == "sec-03-v2.png",
          face_fix.canonical_name(Path("sec-03-v2.png")))
    check("and still strips the temporary fix suffix off a -v2 generation",
          face_fix.canonical_name(Path("sec-03-v2-faces-fixed.png")) == "sec-03-v2.png")

    print()
    # --- one asset, one file per round: a .jpg fix stays a .jpg (9 September 2026)
    # canonical_name wrote every fix as .png, so images/sec-02.jpg was adopted
    # into edits/v1 as sec-02.jpg AND its fix landed as sec-02.png beside it.
    # Every name-based resolver then kept serving the unfixed jpg.
    prod = (Path(tempfile.mkdtemp()) / "fondue").resolve()
    (prod / "images").mkdir(parents=True)
    (prod / "status.md").write_text("x")
    jpg = prod / "images" / "sec-02.jpg"
    Image.fromarray(np.zeros((256, 256, 3), dtype="uint8")).save(jpg, quality=95)
    openai.OpenAI = lambda *a, **k: FakeClient
    try:
        # FakeClient's render is 300x400; run() resizes it to the source grid
        dst = face_fix.run(jpg, [(64, 64, 128, 128)], quality="low")
    finally:
        openai.OpenAI = real
    v1 = prod / "edits" / "v1"
    check("a .jpg original is fixed as .jpg under its canonical name",
          dst == v1 / "sec-02.jpg", dst)
    same_asset = sorted(f.name for f in v1.iterdir() if f.stem == "sec-02")
    check("and the round holds ONE file for that asset", same_asset == ["sec-02.jpg"], same_asset)
    check("the written jpg opens and carries the fix",
          dst.is_file() and Image.open(dst).format == "JPEG"
          and np.asarray(Image.open(dst).convert("RGB"))[90:102, 90:102].mean() > 100)
    check("adopted_set serves the FIXED file, not the unfixed copy",
          face_fix.adopted_set(prod).get("sec-02.jpg") == dst and "sec-02.png" not in face_fix.adopted_set(prod))
    check("a loose .jpg lands beside the source in its own format",
          face_fix.default_dst(Path(tempfile.mkdtemp()) / "photo.jpg").name == "photo-faces-fixed.jpg")

    # --- the two regexes agree on `_fix2` (9 September 2026) -----------------
    # is_evidence matched only `-`, so images/sec-05_fix2.png was adopted as a
    # gallery member while canonical_name stripped it to sec-05.png.
    check("sec-05_fix2.png is evidence, like sec-05-fix2.png",
          face_fix.is_evidence("sec-05_fix2.png") and face_fix.is_evidence("sec-05-fix2.png"))
    check("and canonical_name agrees it is a fix of sec-05",
          face_fix.canonical_name(Path("sec-05_fix2.png")) == "sec-05.png")
    check("a generation's own _v2 is still not evidence", not face_fix.is_evidence("sec-05_v2.png"))

    print()
    # --- no pixel outside the box union may change (finding 4, face-mask part) --
    # The feathered mask used to blur OUTWARD past the box, so the ring just
    # outside the box took render pixels while the docstring promised "original
    # by construction". Black base, white render: any non-zero outside is drift.
    tmp2 = Path(tempfile.mkdtemp())
    black = np.zeros((256, 256, 3), dtype="uint8")
    src2 = tmp2 / "black.png"
    Image.fromarray(black).save(src2)
    white = np.full((256, 256, 3), 255, dtype="uint8")

    class WhiteClient:
        class images:
            @staticmethod
            def edit(**kw):
                import io
                buf = io.BytesIO()
                Image.fromarray(white).save(buf, format="PNG")
                return type("R", (), {"data": [FakeData(buf.getvalue())]})

    openai.OpenAI = lambda *a, **k: WhiteClient
    try:
        dst = face_fix.run(src2, [(64, 64, 128, 128), (120, 60, 200, 100)], quality="low")
    finally:
        openai.OpenAI = real
    out = np.asarray(Image.open(dst).convert("RGB")).astype(int)
    allowed = np.zeros((256, 256), dtype=bool)
    allowed[64:128, 64:128] = True
    allowed[60:100, 120:200] = True
    outside_changed = int((out.max(axis=2) > 0)[~allowed].sum())
    check("no pixel outside the box union changes, boundary ring included",
          outside_changed == 0, f"{outside_changed} outside pixels changed")
    check("and the render DID land inside the boxes", out[90:102, 90:102].mean() > 200,
          out[90:102, 90:102].mean())

    if FAILURES:
        print(f"FAILED ({len(FAILURES)}): " + ", ".join(FAILURES))
        return 1
    print("FACE CLINIC: all green")
    return 0


if __name__ == "__main__":
    sys.exit(run())

#!/usr/bin/env python3
"""The Face Clinic's engine: replace AI-looking people with real-looking ones,
without letting the model touch anything else.

Why this exists as code rather than as one API call. The obvious approach,
one whole-frame images.edit pass, was measured failing: the model does not
EDIT a frame, it re-renders it. On one A+ module it fixed the
people beautifully and added a fifth tier to a four-tier product; on another
it moved the subject's face and aged her a decade. A repair that can break
the product is not a repair.

So the contract here is different:
  1. The FULL frame still goes to the model (context: lighting, palette,
     what the scene is), with a prompt that asks for new real faces.
  2. The result is resized back onto the original's grid.
  3. Only the PEOPLE BOXES are taken from it, through a feathered mask.
     Every pixel outside those boxes is the original file, by construction.
     Headlines, product, layout cannot drift because they are never replaced.

The boxes come from the agent LOOKING at the image, not from a detector: the
kit has no face-detection dependency, and the operator drawing two rectangles
is more reliable than a model guessing. Draw them TIGHT: the head and its
hair, nothing more. Everything inside a box is surrendered to the re-render,
and the first run proved what a generous box costs: one that reached into the
layout composited back a ghost microphone and a floating letter, because the
re-render had moved those things and the box carried the moved copies home.
Never let a box touch on-image text or the product. The feather plus the
ring-based tone match below handle the seam; margin does not need to.

Usage:
    python3 face_fix.py <image> --boxes "x1,y1,x2,y2;x1,y1,x2,y2" [--quality high]
                                [--out <path>] [--prompt-file <txt>]

Where the result lands (kit v23): INSIDE a product folder (an ancestor that
holds images/ and status.md) the fix follows the Fixing Room's round law: a new
edits/v[N+1]/ is opened as the ADOPTED SET (kit v28: every original in images/
that is not an evidence file, each replaced by its newest same-name copy from an
earlier round when one exists; files generated after the last round are in too,
files named -rejected / -render / -faces-fixed are not) and the fixed file takes
its CANONICAL name there (main-06.png, never main-06-faces-fixed.png; a
generation's own -v2 stays: sec-03-v2.png fixes as sec-03-v2.png; the format
stays too: sec-02.jpg fixes as sec-02.jpg, one file per asset). The round
writes round.md naming where each file came from, so the Tasting Room, /inspect
and the Shipping Room resolve the current copy without guessing. OUTSIDE a
product folder (a loose file) it lands beside the source as <name>-faces-fixed.<ext>.
--out overrides both. Never touches the source. Cost: one images.edit call at quality HIGH by default (about 100
seconds; low is about 20). High is deliberate and it is the one place in this
factory that does not economise: this room only ever runs on an image whose
faces are ALREADY wrong, one image at a time, on an asset the owner has
already paid to generate. Cheap pools, expensive repairs.
"""

from __future__ import annotations   # PEP 604 (`Path | None`) in annotations
# is a runtime TypeError on Python 3.9, the version macOS ships. This makes
# annotations lazy strings so the kit runs on a stock Mac.
import base64
import os
import re
import shutil
import sys
from pathlib import Path

try:
    from PIL import Image, ImageDraw, ImageFilter
except ImportError:
    sys.exit("this needs Pillow: python3 -m pip install pillow")

# Replacement, not restoration. Asking the model to "make the same face
# realistic" keeps the doll geometry and adds texture ON it, which reads as a
# skin disease at low quality (measured). Asking for a NEW person of the same
# casting in the same pose lets it draw a face it actually knows how to draw.
PROMPT = (
    "This is a product marketing photo. Keep the composition, the product, all on-image text, "
    "the clothing, the poses, the framing and the lighting direction exactly as they are. "
    "Replace each person's face with a DIFFERENT real human face: same gender, same approximate "
    "age, same hairstyle and hair color, a natural candid version of the same expression. "
    "Every person must stay in EXACTLY the same position, size and crop as in the original "
    "image; do not move, rescale or duplicate anyone. "
    "The new faces must look like real photographed people, not AI renders: natural skin with "
    "faint pores and small imperfections, slight facial asymmetry, normal teeth that are not "
    "uniform veneers, realistic eyes with catchlights, individual hair strands. "
    "No beauty-filter glow, no airbrushed skin, no orange tan, no added makeup. Neutral, "
    "believable skin tones with natural variation between regions of the face. "
    "The result should read as a candid lifestyle photograph shot on a professional camera."
)

FEATHER = 40   # px of Gaussian falloff on the mask edge; hides the seam


def _tone_match(orig, edit, box, pad=60):
    """Align the edited box's tone to the original, spatially.

    Version 1 applied ONE per-channel offset per box, computed on the ring
    around it. Measured result: the box still printed as a faint bright
    rectangle, because the render's exposure shift is not constant across the
    box, so a single number under-corrects one edge and over-corrects the
    other. This version builds an offset MAP instead: wherever the two images
    still agree (background the render left alone, within 30 levels), the
    difference is trusted; where they disagree (the new face), it is not; the
    trusted differences are blurred into a smooth field and added. The
    correction therefore follows the background's own gradient and fades to
    the interpolated value under the face."""
    import numpy as np
    from PIL import ImageFilter
    w, h = orig.size
    x1, y1 = max(0, box[0] - pad), max(0, box[1] - pad)
    x2, y2 = min(w, box[2] + pad), min(h, box[3] + pad)
    o = np.asarray(orig.crop((x1, y1, x2, y2)), dtype=np.float64)
    e = np.asarray(edit.crop((x1, y1, x2, y2)), dtype=np.float64)
    d = o - e
    agree = (np.abs(d).max(axis=2) < 30).astype(np.float64)
    if agree.sum() < 500:
        return edit          # nothing trustworthy to anchor on; leave it be
    blur = lambda a, r: np.asarray(
        Image.fromarray(np.clip(a + 128, 0, 255).astype("uint8")).filter(
            ImageFilter.GaussianBlur(r)), dtype=np.float64) - 128
    field = np.stack([
        blur(d[..., c] * agree, 40) / np.maximum(blur(agree * 255, 40) / 255, 1e-3)
        for c in range(3)], axis=2)
    # The field repairs EXPOSURE seams; it must never repaint a face. Uncapped,
    # a green foliage ring bled a visible green tint onto a cheek (measured on
    # the roast-together frame). +-18 is plenty for a seam and too little to
    # recolor skin.
    field = np.clip(field, -18, 18)
    fixed = np.clip(e + field, 0, 255).astype("uint8")
    out = edit.copy()
    out.paste(Image.fromarray(fixed), (x1, y1))
    return out


def parse_boxes(spec: str):
    out = []
    for part in spec.split(";"):
        part = part.strip()
        if not part:
            continue
        nums = [int(v) for v in part.replace(" ", "").split(",")]
        if len(nums) != 4 or nums[0] >= nums[2] or nums[1] >= nums[3]:
            sys.exit(f"bad box '{part}': need x1,y1,x2,y2 with x1<x2 and y1<y2")
        out.append(tuple(nums))
    if not out:
        sys.exit("no boxes given. The clinic edits people; with no people boxes there is no edit.")
    return out


# size is ALWAYS "auto". Forcing a fixed size looked harmless and was not:
# a 1.86-ratio banner pushed through 1536x1024 (ratio 1.5) re-composed at the
# wrong aspect, and squashing it back moved every head out of its box, so the
# composite printed bright off-register rectangles. "auto" renders at the
# source's own aspect (measured: a 1464x600 input came back 1958x803, ratio
# preserved), which keeps the geometry aligned with the boxes.


IMG_EXT = {".png", ".jpg", ".jpeg", ".webp"}
# Temporary FIX suffixes only. A generation's own version (`sec-03-v2.png`, a
# regenerated slot) is a different asset with its own identity and stays. Kit
# v27 stripped `-v2` too, so a fix on sec-03-v2 landed as sec-03.png: one file's
# repair written onto another file's name (reproduced 9 September 2026).
_FIX_SUFFIX = re.compile(r"^(?P<base>.+?)[-_](?:fix\d+|faces-fixed(?:-v\d+)?)$", re.I)
# Evidence names the Fixing Room leaves inside a round on purpose: a failed
# attempt (`-rejected`, `-rejected-2`), the whole-frame render kept for the log
# (`-render`), a loose-file clinic output. None of them is a gallery member.
# The separator is `[-_]` here as in _FIX_SUFFIX: the two regexes must agree,
# or `sec-05_fix2.png` is adopted as a gallery member by one and stripped to
# `sec-05.png` by the other (reproduced 9 September 2026).
_EVIDENCE = re.compile(r".+[-_](?:rejected(?:-\d+)?|render|fix\d+|faces-fixed(?:-v\d+)?)$", re.I)


def canonical_name(src: Path) -> str:
    """main-06-faces-fixed.png -> main-06.png; edits/v2/main-06.png -> main-06.png;
    sec-03-v2.png -> sec-03-v2.png (a generation's version is its identity).

    The suffix is the source's own, verbatim. Kit v28 wrote every fix as .png,
    so a `sec-02.jpg` original was adopted into the round under its own name
    AND its fix landed beside it as `sec-02.png`: two files for one asset, and
    every name-based resolver kept serving the unfixed jpg (reproduced
    9 September 2026). One asset, one name, one file per round."""
    m = _FIX_SUFFIX.match(src.stem)
    return (m.group("base") if m else src.stem) + src.suffix


def is_evidence(name: str) -> bool:
    return bool(_EVIDENCE.match(Path(name).stem))


def _gallery_files(folder: Path):
    """The adoptable image files in one folder: images, not hidden, not evidence."""
    if not folder.is_dir():
        return []
    return sorted(f for f in folder.iterdir()
                  if f.is_file() and f.suffix.lower() in IMG_EXT
                  and not f.name.startswith(".") and not is_evidence(f.name))


def rounds(product: Path):
    """[(1, edits/v1), (2, edits/v2), ...] in order."""
    edits = product / "edits"
    if not edits.is_dir():
        return []
    return sorted((int(d.name[1:]), d) for d in edits.iterdir()
                  if d.is_dir() and re.fullmatch(r"v\d+", d.name))


def adopted_set(product: Path):
    """name -> the ADOPTED copy of every gallery asset: the original in images/,
    replaced by its newest same-name copy from a round when one exists. An
    asset that exists only in images/ (generated after the last round) is in;
    an evidence file is never in. This is the one rule every room reads."""
    adopted = {f.name: f for f in _gallery_files(product / "images")}
    for _, d in rounds(product):
        for f in _gallery_files(d):
            adopted[f.name] = f
    return adopted


def product_dir(src: Path):
    """The product folder an image belongs to, or None for a loose file."""
    for a in src.resolve().parents:
        if (a / "images").is_dir() and (a / "status.md").is_file():
            return a
    return None


def open_round(product: Path) -> Path:
    """Open edits/v[N+1] as the ADOPTED SET (the Fixing Room's law, step 6).

    Kit v27 copied the previous round folder whole. Reproduced 9 September
    2026: Day 5 fixed the main into edits/v1, Day 6 generated eight secondaries
    into images/, and the next fix opened v2 holding only the main. The round
    is now built from adopted_set(): every asset, at its adopted version, and
    no evidence file. round.md records where each copy came from."""
    prev = rounds(product)
    n = (prev[-1][0] + 1) if prev else 1
    new = product / "edits" / f"v{n}"
    new.mkdir(parents=True)
    lines = [f"# edits/v{n}: the adopted set when this round opened", "",
             "| file | adopted from |", "|---|---|"]
    for name, src in sorted(adopted_set(product).items()):
        shutil.copy2(src, new / name)
        lines.append(f"| {name} | {src.relative_to(product)} |")
    (new / "round.md").write_text("\n".join(lines) + "\n")
    return new


def default_dst(src: Path) -> Path:
    prod = product_dir(src)
    if prod is None:
        dst = src.with_name(src.stem + "-faces-fixed" + src.suffix)
        n = 2
        while dst.exists():
            dst = src.with_name(f"{src.stem}-faces-fixed-v{n}{src.suffix}")
            n += 1
        return dst
    rnd = open_round(prod)
    print(f"opened {rnd.relative_to(prod)} as the adopted set; the fix takes its canonical name there")
    return rnd / canonical_name(src)


def load_key():
    """OPENAI_API_KEY from the environment, else the nearest .env upward (the
    factory root .env is where /machines-check put it)."""
    if os.environ.get("OPENAI_API_KEY"):
        return
    for a in [Path.cwd()] + list(Path.cwd().parents):
        f = a / ".env"
        if f.is_file():
            for line in f.read_text(errors="ignore").splitlines():
                if line.strip().startswith("OPENAI_API_KEY="):
                    os.environ["OPENAI_API_KEY"] = line.split("=", 1)[1].strip().strip('"').strip("'")
                    return


def run(src: Path, boxes, quality="high", out: Path | None = None, prompt: str = PROMPT):
    from openai import OpenAI
    client = OpenAI()
    im = Image.open(src).convert("RGB")
    w, h = im.size
    for (x1, y1, x2, y2) in boxes:
        if x2 > w or y2 > h:
            sys.exit(f"box ({x1},{y1},{x2},{y2}) falls outside the {w}x{h} image")

    r = client.images.edit(model="gpt-image-2", image=[open(src, "rb")],
                           prompt=prompt, size="auto", quality=quality, n=1)
    edited = Image.open(__import__("io").BytesIO(base64.b64decode(r.data[0].b64_json)))
    edited = edited.convert("RGB").resize((w, h), Image.LANCZOS)
    for b in boxes:
        edited = _tone_match(im, edited, b)

    # the mask IS the contract: white = the edit may land, black = original pixels.
    # Two masks, on purpose. `allowed` is the plain box union, the contract the
    # operator drew. `mask` is the feathered one the composite uses, CLIPPED to
    # `allowed`: kit v27 blurred outward, so a ring of up to FEATHER/2 px
    # outside every box took render pixels while the docstring promised
    # "original by construction" (measured 9 September 2026, 25,850 pixels on
    # a 256x256 test frame). The feather now falls off inward from the edge.
    allowed = Image.new("L", (w, h), 0)
    da = ImageDraw.Draw(allowed)
    mask = Image.new("L", (w, h), 0)
    d = ImageDraw.Draw(mask)
    for (x1, y1, x2, y2) in boxes:
        da.rectangle((x1, y1, x2 - 1, y2 - 1), fill=255)   # [x1, x2) x [y1, y2)
        d.rounded_rectangle((x1, y1, x2 - 1, y2 - 1),
                            radius=min(30, (x2 - x1) // 4), fill=255)
    mask = mask.filter(ImageFilter.GaussianBlur(FEATHER / 2))
    mask = Image.composite(mask, Image.new("L", (w, h), 0), allowed)

    result = Image.composite(edited, im, mask)
    inside, outside = outside_changed(im, result, allowed)
    if outside:
        sys.exit(f"REFUSED: {outside} pixels changed outside the head boxes; nothing written")
    dst = out or default_dst(src)
    # The fix is written in the source's own format so the round holds ONE file
    # per asset. JPEG recompresses on save; 95 keeps the repaired faces intact.
    save_kw = {"quality": 95} if dst.suffix.lower() in (".jpg", ".jpeg") else {}
    result.save(dst, **save_kw)
    print(f"{inside} pixels changed inside the boxes, {outside} outside")
    return dst


def outside_changed(original, result, allowed):
    """(inside, outside) pixel counts that differ, measured against the plain
    box union, never against the feathered mask the composite was built from.
    Measuring against the blurred mask counts every pixel the blur reached as
    inside, which is how a leak reports as zero."""
    import numpy as np
    a = np.asarray(original.convert("RGB"), dtype=int)
    b = np.asarray(result.convert("RGB"), dtype=int)
    changed = np.abs(a - b).max(axis=2) > 0
    box = np.asarray(allowed, dtype=bool)
    return int(changed[box].sum()), int(changed[~box].sum())


def main():
    args = sys.argv[1:]
    if not args or "--boxes" not in args:
        sys.exit(__doc__)
    src = Path(args[0])
    if not src.is_file():
        sys.exit(f"no such image: {src}")
    boxes = parse_boxes(args[args.index("--boxes") + 1])
    quality = args[args.index("--quality") + 1] if "--quality" in args else "high"
    out = Path(args[args.index("--out") + 1]) if "--out" in args else None
    prompt = PROMPT
    if "--prompt-file" in args:
        prompt = Path(args[args.index("--prompt-file") + 1]).read_text()
    load_key()
    if not os.environ.get("OPENAI_API_KEY"):
        sys.exit("OPENAI_API_KEY is not set. The clinic runs on Machine 2; add the key to the .env.")
    dst = run(src, boxes, quality, out, prompt)
    print(f"wrote {dst}")


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
"""Fact-provenance preflight for a saved Genrupt listing plan.

Why this exists (measured 7 September 2026, the bootcamp demo product): the dimensions frame
came out of the machine printing `8.5" BASE`. The listing's own product table, the reference
sheet, the selling points and the approved brief all said 8 inches. The 8.5 had two sources,
neither of them ours: a competitor's dimension frame in the research, and a re-scraped
product description inside the saved plan. Nothing in the pipeline compared a number that was
about to be rendered against the evidence we hold for OUR product.

This preflight pulls every numeric claim out of the plan text that can reach an image (the
product block, every slot's header phrases, brief, alternate briefs, buyer question and
custom instructions), normalises value, unit and, where the text names one, the ATTRIBUTE
(width, height, depth, length, diameter, weight, capacity, count), and checks each one
against the authoritative sources on disk.

The rules, each one paid for by a reproduced miss (release review, 9 September 2026):
  - A number a source NEGATES ("never 8.5 inches") never confirms that number. A source
    that both states and negates the same value sends the claim to NEEDS REVIEW; the tool
    never picks the convenient reading.
  - A number is sourced under its attribute. "Height: 18 inches" does not source
    "18 inches wide"; the report says which attribute it matched instead. When neither
    side names an attribute the match falls back to value + unit and the row is marked
    "attribute unverified".
  - A negation covers its own claim only: "8.5 inches wide and no oil needed" still
    checks the 8.5. The look-back never crosses a comma ("Never 8.5 inches, always 8
    inches wide" negates only the 8.5), and a comma before a number starts a new clause
    ("No assembly, 18 inches tall" still checks the 18).
  - A plan-side claim the plan itself negates ("no tools needed 18 inches tall") is never
    dropped: it goes to NEEDS REVIEW, because a number the tool cannot read the sense of is
    still a number about to be rendered.
  - Number words are parsed as compounds ("thirty-two ounces" is 32 oz). A word number the
    parser cannot read goes to NEEDS REVIEW, never misread. Mixed fractions ("8 1/2 inches"
    is 8.5 in), thousands separators ("1,000 watts" is 1000 w) and ranges ("8 to 10 inches"
    yields both 8 and 10) are read whole.
  - The verdict is honest: CLEAN only when every claim is sourced. Any NEEDS REVIEW row
    makes the verdict NEEDS REVIEW; any unsourced claim makes it FAIL. A row marked
    "attribute unverified" matched on value and unit only; it stays CLEAN and is read by eye.

This is a conservative extractor, not a language engine. Whatever it cannot read with
confidence goes to the reviewer's eye, in the report, and the verdict says so.

Usage:
  python3 fact_preflight.py plan.json --sources 2-reference/reference-sheet.md brief/creative-brief.md
                             [research/selling-points.md ...] [--competitors research/competitors.md]
                             [--out brief/fact-preflight-YYYY-MM-DD.md]

Exit 0 = CLEAN (every claim sourced under its attribute, or attribute-free on both sides),
1 = FAIL or NEEDS REVIEW (at least one claim is unsourced, unverified or contradicted by the
sources; nothing carrying it generates until a person resolves it), 2 = bad input.
Standard library only.
"""
import json
import re
import sys
from collections import namedtuple
from pathlib import Path

ONES = {"zero": 0, "one": 1, "two": 2, "three": 3, "four": 4, "five": 5, "six": 6, "seven": 7,
        "eight": 8, "nine": 9, "ten": 10, "eleven": 11, "twelve": 12, "thirteen": 13,
        "fourteen": 14, "fifteen": 15, "sixteen": 16, "seventeen": 17, "eighteen": 18,
        "nineteen": 19}
TENS = {"twenty": 20, "thirty": 30, "forty": 40, "fifty": 50, "sixty": 60, "seventy": 70,
        "eighty": 80, "ninety": 90}
SCALES = {"hundred": 100, "thousand": 1000}
NUMWORDS = set(ONES) | set(TENS) | set(SCALES)
UNITS = [  # (regex, canonical). Longest alternatives first so "inches" is not read as "in".
    (r"inch(?:es)?|in\b|\"|”|''", "in"),
    (r"feet|foot|ft\b", "ft"),
    (r"centimet(?:er|re)s?|cm\b", "cm"),
    (r"millimet(?:er|re)s?|mm\b", "mm"),
    (r"ounces?|oz\b", "oz"),
    (r"pounds?|lbs?\b", "lb"),
    (r"kilograms?|kg\b", "kg"),
    (r"grams?|\bg\b", "g"),
    (r"millilit(?:er|re)s?|ml\b", "ml"),
    (r"lit(?:er|re)s?|\bl\b", "l"),
    (r"gallons?|gal\b", "gal"),
    (r"cups?", "cup"),
    (r"quarts?|qt\b", "qt"),
    (r"tiers?", "tier"),
    (r"parts?|pieces?|pcs?\b", "part"),
    (r"volts?|v\b", "v"),
    (r"watts?|w\b", "w"),
    (r"hz\b|hertz", "hz"),
    (r"%|percent", "pct"),
    (r"hours?|hrs?\b", "hour"),
    (r"minutes?|mins?\b", "min"),
    (r"years?|yrs?\b", "year"),
    (r"days?", "day"),
    (r"servings?", "serving"),
    (r"guests?|people", "guest"),
]
# the trailing guard keeps "three-quarter view" from reading as 3 quarts and "in" inside "inset" as inches
UNIT_RE = "(?:" + "|".join(f"(?:{u})" for u, _ in UNITS) + ")(?![A-Za-z])"
# thousands with separators ("1,000"), or a number with an optional mixed fraction ("8 1/2") or decimal
NUM = r"(\d{1,3}(?:,\d{3})+(?:\.\d+)?|\d+(?: \d+/\d+)?(?:[.,]\d+)?)"
# "8 x 8 x 18 inches": every number in a dimension chain takes the trailing unit
DIM_RE = re.compile(rf"{NUM}(?:\s*[x×]\s*{NUM})+\s*[- ]?({UNIT_RE})", re.I)
# "8 to 10 inches", "8-10 inches": both ends of a range are claims
RANGE_RE = re.compile(rf"(?<![\w.]){NUM}\s*(?:to|-)\s*{NUM}\s*[- ]?({UNIT_RE})", re.I)
CLAIM_RE = re.compile(rf"(?<![\w.]){NUM}\s*[- ]?({UNIT_RE})", re.I)
WORD_RE = re.compile(r"(?<![\w-])((?:" + "|".join(NUMWORDS) + r")(?:[-\s]+(?:" + "|".join(NUMWORDS) + r"))*)[-\s]+(" + UNIT_RE + r")", re.I)
NEGATION = {"never", "not", "no", "without", "nor", "isn't", "aren't", "n't"}
# a word that ends the look-back window before a number: what stands before it belongs to another claim
BOUNDARY = {"on", "with", "and", "at", "for", "in", "by", "but", "or", "plus", "of", "to", "x", "×"}
ATTRS = {  # word -> attribute. Words the text uses to say WHAT a number measures.
    "width": "width", "wide": "width", "w": "width",
    "height": "height", "tall": "height", "high": "height", "h": "height",
    "depth": "depth", "deep": "depth", "d": "depth",
    "length": "length", "long": "length", "l": "length",
    "diameter": "diameter", "dia": "diameter", "diam": "diameter",
    "weight": "weight", "weighs": "weight", "weigh": "weight", "weighing": "weight",
    "capacity": "capacity", "holds": "capacity", "hold": "capacity", "volume": "capacity",
    "count": "count", "pieces": "count", "piece": "count", "quantity": "count",
}
UNIT_ATTR = {"lb": "weight", "kg": "weight", "g": "weight",
             "ml": "capacity", "l": "capacity", "gal": "capacity", "qt": "capacity", "cup": "capacity",
             "part": "count"}
AFTER_WORDS = 2   # how many words after the unit may name the attribute ("18 inches tall")
BEFORE_WORDS = 3  # how many words before the number may name it ("Base width: 8 inches", "weighs 4.9 pounds")

Claim = namedtuple("Claim", "value unit attr negated clause note")


def canon_unit(u):
    for rx, c in UNITS:
        if re.fullmatch(rx, u, re.I):
            return c
    return u.lower()


def canon_val(v):
    v = str(v).strip()
    if re.fullmatch(r"\d{1,3}(?:,\d{3})+(?:\.\d+)?", v):
        v = v.replace(",", "")          # 1,000 -> 1000, 1,250.5 -> 1250.5
    else:
        v = v.replace(",", ".")         # 8,5 -> 8.5
    frac = re.fullmatch(r"(\d+) (\d+)/(\d+)", v)
    try:
        if frac:
            whole, num, den = (int(x) for x in frac.groups())
            if den == 0:
                return v
            f = whole + num / den       # 8 1/2 -> 8.5
        else:
            f = float(v)
    except ValueError:
        return v
    return str(int(f)) if f.is_integer() else str(round(f, 4))


def words_to_number(phrase):
    """'thirty-two' -> 32, 'one hundred twenty' -> 120. None when the words do not form a number."""
    toks = [t for t in re.split(r"[-\s]+", phrase.lower()) if t]
    total, current, last_kind = 0, 0, None
    for t in toks:
        if t in ONES:
            if last_kind in ("ones", "teen"):
                return None
            if last_kind == "tens" and ONES[t] >= 10:
                return None
            current += ONES[t]
            last_kind = "teen" if ONES[t] >= 10 else "ones"
        elif t in TENS:
            if last_kind in ("ones", "teen", "tens"):
                return None
            current += TENS[t]
            last_kind = "tens"
        elif t in SCALES:
            if current == 0:
                return None
            if t == "hundred":
                if current >= 100:
                    return None
                current *= 100
            else:
                total += current * 1000
                current = 0
            last_kind = "scale"
        else:
            return None
    return total + current


def clauses(text):
    """Split into clauses so 'never 8.5' does not neutralise '8 INCHES wide' beside it.
    A colon stays inside its clause: 'Height: 18 inches' is one fact. A table pipe stays as a
    token: the look-back may cross ONE pipe ('| Weight | 4.9 pounds |'), the look-ahead none.
    A comma before a negation word or before a number opens a new clause ('No assembly, 18
    inches tall'); a comma between digits is a thousands separator and stays."""
    text = text or ""
    # a full stop between two digits is a decimal point, never a sentence boundary
    return [c for c in re.split(r"(?<!\d)\.|\.(?!\d)|[;\n]|,\s*(?=(?:never|not|no)\b)|(?<!\d),\s*(?=\d)", text) if c.strip()]


def _words(s):
    return [w for w in re.findall(r"[A-Za-z']+|[%\"”|,]|''|[x×]", s)]


def _before(clause, start):
    """The words right before a number, nearest first, stopping at a boundary word or a comma."""
    out = []
    for i, w in enumerate(reversed(_words(clause[:start]))):
        wl = w.lower().strip(":")
        if wl == "|":
            if i == 0:
                continue
            break
        if wl in BOUNDARY or wl == ",":
            break
        out.append(wl)
        if len(out) >= BEFORE_WORDS:
            break
    return out


def _after(clause, end):
    return [w.lower() for w in _words(clause[end:])[:AFTER_WORDS]]


def _bind(clause, start, end, unit):
    """(attribute or None, negated) for the claim spanning clause[start:end]."""
    before = _before(clause, start)
    after = _after(clause, end)
    negated = any(w in NEGATION for w in before)
    attr = None
    for w in after:
        if w in ATTRS:
            attr = ATTRS[w]
            break
        if w in BOUNDARY or w in ("|", ","):
            break
    if attr is None:
        for w in before:
            if w in ATTRS:
                attr = ATTRS[w]
                break
    if attr is None:
        attr = UNIT_ATTR.get(unit)
    return attr, negated


def claims(text):
    """Yield a Claim for every numeric claim in text, negated ones included and flagged.
    The source side keeps a negated fact so it can block a match; the plan side sends a
    negated claim to review, never to the floor and never to the bin."""
    for raw in clauses(text):
        clause = raw.strip()
        spans = []
        for m in DIM_RE.finditer(clause):
            unit = canon_unit(m.group(m.lastindex))
            attr, neg = _bind(clause, m.start(), m.end(), unit)
            attr = None if attr in ("width", "height", "depth", "length") else attr  # a chain names no single side
            spans.append((m.start(), m.end()))
            for v in re.findall(NUM, m.group(0)):
                yield Claim(canon_val(v), unit, attr, neg, clause, "")
        for m in RANGE_RE.finditer(clause):
            if any(a <= m.start() < b for a, b in spans):
                continue
            unit = canon_unit(m.group(3))
            attr, neg = _bind(clause, m.start(), m.end(), unit)
            spans.append((m.start(), m.end()))
            for v in (m.group(1), m.group(2)):
                yield Claim(canon_val(v), unit, attr, neg, clause, "")
        for m in CLAIM_RE.finditer(clause):
            if any(a <= m.start() < b for a, b in spans):
                continue
            unit = canon_unit(m.group(2))
            attr, neg = _bind(clause, m.start(), m.end(), unit)
            yield Claim(canon_val(m.group(1)), unit, attr, neg, clause, "")
        for m in WORD_RE.finditer(clause):
            unit = canon_unit(m.group(2))
            attr, neg = _bind(clause, m.start(), m.end(), unit)
            n = words_to_number(m.group(1))
            if n is None:
                yield Claim(None, unit, attr, neg, clause, f"UNVERIFIED: could not read the number words '{m.group(1)}'")
                continue
            yield Claim(str(n), unit, attr, neg, clause, "")


def facts_from(text):
    """{(value, unit): {"pos": {attrs}, "neg": {attrs}}} for every number a source states or
    negates. A negated number is kept on the neg side so it can never confirm a claim and so a
    source that says both things is caught."""
    facts = {}
    for c in claims(text):
        if c.value is None:
            continue
        slot = facts.setdefault((c.value, c.unit), {"pos": set(), "neg": set()})
        slot["neg" if c.negated else "pos"].add(c.attr)
    return facts


def _texts(x):
    """Strings inside a plan field that may be a string, a list, or a dict of briefs."""
    if isinstance(x, str):
        yield x
    elif isinstance(x, list):
        for i in x:
            yield from _texts(i)
    elif isinstance(x, dict):
        for k in ("text", "brief", "contentBrief", "description", "buyerQuestion"):
            if isinstance(x.get(k), str):
                yield x[k]
        for h in x.get("headerPhrases") or []:
            if isinstance(h, str):
                yield h


def plan_fields(obj):
    """(where, text) pairs for every plan field that can reach an image."""
    root = obj.get("plan", obj)
    setup = obj.get("projectSetup") or root.get("projectSetup") or {}
    prod = setup.get("product") or {}
    for k in ("title", "description"):
        if prod.get(k):
            yield f"product.{k}", prod[k]
    for i, b in enumerate(prod.get("bulletPoints") or [], 1):
        yield f"product.bullet {i}", b
    for s in root.get("slots") or root.get("slotAssignments") or []:
        n = s.get("slotNumber")
        if s.get("protectedMainImage") or s.get("imageType") == "MAIN_IMAGE":
            continue
        for h in s.get("headerPhrases") or []:
            yield f"slot {n} headerPhrases", h
        for k in ("buyerQuestion", "contentBrief"):
            if s.get(k):
                yield f"slot {n} {k}", s[k]
        # alternates are live production inputs: one has won before (creative-brief, 27 August 2026)
        for i, t in enumerate(_texts(s.get("alternateCreativeBriefs")), 1):
            yield f"slot {n} alternateCreativeBriefs[{i}]", t
        ci = s.get("customInstructions") or {}
        if isinstance(ci, dict) and ci.get("text"):
            yield f"slot {n} customInstructions", ci["text"]


def _match(c, known):
    """Return (state, note). state: 'ok', 'review', 'bad'."""
    f = known.get((c.value, c.unit))
    if not f:
        return "bad", "not in any authoritative source"
    pos, neg = f["pos"], f["neg"]

    def fits(attrs):
        return c.attr in attrs or None in attrs or c.attr is None and bool(attrs)
    if fits(neg) and fits(pos):
        return "review", "NEEDS CLARIFICATION: the sources both state and negate this value; resolve it in the reference sheet before generating"
    if fits(neg):
        return "bad", "the sources NEGATE this value (a warning against a number is never a source for it)"
    if c.attr is not None and c.attr in pos:
        return "ok", f"sourced as {c.attr}"
    if c.attr is None and pos:
        named = sorted(a for a in pos if a)
        return "ok", "attribute unverified" + (f" (the sources give it as {', '.join(named)})" if named else "")
    if None in pos:
        return "ok", f"attribute unverified: the claim says {c.attr}, the source states the number without an attribute"
    return "bad", f"only matches under a different attribute in the sources ({', '.join(sorted(a for a in pos if a))}), not as {c.attr}"


def preflight(plan, sources, competitors=""):
    """Returns (ok, bad, review). Each row: (where, claim, clause, note)."""
    known = facts_from(sources)
    rival = facts_from(competitors) if competitors else {}
    ok, bad, review = [], [], []
    for where, text in plan_fields(plan):
        for c in claims(text):
            label = f"{c.value} {c.unit}" if c.value is not None else f"? {c.unit}"
            if c.attr:
                label += f" ({c.attr})"
            row = (where, label, c.clause[:110])
            if c.value is None:
                review.append(row + (c.note,))
                continue
            if c.negated:
                review.append(row + ("NEEDS REVIEW: the plan text negates this number; the tool cannot tell whether it is a claim about our product, so a person reads the clause",))
                continue
            state, note = _match(c, known)
            if state == "ok":
                ok.append(row + (note,))
            elif state == "review":
                review.append(row + (note,))
            else:
                if (c.value, c.unit) in rival:
                    note += ". ALSO IN COMPETITOR RESEARCH: the likely source, and never evidence about our product"
                bad.append(row + (note,))
    return ok, bad, review


def verdict(bad, review):
    if bad:
        return "FAIL"
    if review:
        return "NEEDS REVIEW"
    return "CLEAN"


def render(ok, bad, review, plan_path, source_paths):
    v = verdict(bad, review)
    out = [f"# Fact preflight . {v}", "",
           f"Plan: `{plan_path}`  Sources: " + ", ".join(f"`{p}`" for p in source_paths), "",
           f"{len(ok)} sourced claim(s), {len(bad)} unsourced claim(s), {len(review)} claim(s) needing review.", ""]
    if bad:
        out += ["## Unsourced claims (each one stops its slot until it is sourced, corrected, or removed from the plan)", "",
                "| Where | Claim | Clause | Finding |", "|---|---|---|---|"]
        out += ["| " + " | ".join(r) + " |" for r in bad]
        out.append("")
    if review:
        out += ["## Claims needing review (the tool could not verify these; a person resolves each one before its slot generates)", "",
                "| Where | Claim | Clause | Finding |", "|---|---|---|---|"]
        out += ["| " + " | ".join(r) + " |" for r in review]
        out.append("")
    if ok:
        out += ["## Sourced claims", "", "| Where | Claim | Clause | How |", "|---|---|---|---|"]
        out += ["| " + " | ".join(r) + " |" for r in ok]
        out.append("")
    if v == "CLEAN":
        out.append("Every extracted claim is sourced. Rows marked 'attribute unverified' matched on value and unit only; read those by eye.")
    elif v == "NEEDS REVIEW":
        out.append("No claim is contradicted outright, but the tool could not verify every one. This is not a pass.")
    else:
        out.append("At least one number about to be rendered has no source in our evidence. Nothing carrying it generates.")
    return "\n".join(out) + "\n"


def main(argv):
    if len(argv) < 2 or "--sources" not in argv:
        print(__doc__)
        return 2
    plan_path = argv[1]
    src, comp, out_path = [], None, None
    mode = None
    for a in argv[2:]:
        if a in ("--sources", "--competitors", "--out"):
            mode = a
            continue
        if mode == "--sources":
            src.append(a)
        elif mode == "--competitors":
            comp = a
        elif mode == "--out":
            out_path = a
    try:
        plan = json.loads(Path(plan_path).read_text(encoding="utf-8"))
        sources = "\n".join(Path(p).read_text(encoding="utf-8") for p in src)
        competitors = Path(comp).read_text(encoding="utf-8") if comp else ""
    except (OSError, ValueError) as e:
        print(f"could not read an input: {e}")
        return 2
    if not src:
        print("at least one --sources file is required (the reference sheet at minimum)")
        return 2
    ok, bad, review = preflight(plan, sources, competitors)
    report = render(ok, bad, review, plan_path, src)
    if out_path:
        Path(out_path).write_text(report, encoding="utf-8")
    print(report)
    return 0 if verdict(bad, review) == "CLEAN" else 1


if __name__ == "__main__":
    sys.exit(main(sys.argv))

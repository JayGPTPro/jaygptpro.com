#!/usr/bin/env python3
"""Brief <-> saved plan parity audit for the Secondary Images Room.

Why this exists (measured 7 September 2026, the bootcamp demo product): the owner-approved
brief carried S4, "How-to: where the chocolate goes and how deep" / "Fill the base bowl".
The saved Genrupt plan had lost that job by the time the gallery was generated: slot 5
carried an installation frame instead, "Melt it fully, then pour", a near twin of S3. Every
image generated correctly. The brief and the plan had simply parted, and a coverage map
walked against the BRIEF cannot see a job that never reached the MACHINE. The gap surfaced
only after the set looked finished.

This audit reads the brief and the plan the machine actually holds, matches every brief
job to a plan slot, and FAILS before anything is spent when:
  - a brief slot has no plan slot carrying its job (the S4 case),
  - two plan slots carry the same brief job (the twin case),
  - a plan slot carries a job the brief never approved (an unapproved extra),
  - the secondary counts differ,
  - a plan slot THIS RUN targets is generationBlocked (Genrupt refuses it; a run would
    silently skip it).

Parity is gallery-wide: a lost, twinned, unapproved or miscounted job fails in every mode.
The block check is scoped to the run: pass `--target-slots 7` (or `7,8`) for a Refine
round on those slots, `--all` for the Theme Blast. A blocked slot outside the target
list is reported as "blocked, outside this run" and is not an error, because the
lesson keeps the good frames closed on purpose. Nothing here ever asks you to reopen
every slot; reopen one only when the owner's action needs it. No flag = `--all`.

Run it before the Theme Blast, before every Refine round, and after any plan write.

Usage:
  python3 plan_parity.py brief/creative-brief.md plan.json [--target-slots 7,8 | --all]
                         [--out brief/plan-parity-YYYY-MM-DD.md]

`plan.json` is the JSON returned by the plan-review capability (the whole object, or just
the `plan` object). Exit 0 = PARITY, exit 1 = FAIL, exit 2 = could not read an input.
Standard library only.
"""
import json
import re
import sys
from pathlib import Path

STOP = set("""a an the and or of to in on it is its for with at by from this that these those
what how do i my me we our you your does can will really actually going be into as not no""".split())
THRESHOLD = 0.34  # jaccard on content words; below this a slot is not carrying that job


def tokens(s):
    s = re.sub(r"[^a-z0-9 ]+", " ", (s or "").lower())
    return {w for w in s.split() if w not in STOP and len(w) > 1}


def jaccard(a, b):
    if not a or not b:
        return 0.0
    return len(a & b) / len(a | b)


def read_brief(text):
    """Brief slots from the Set structure table plus the Funnel B blocks.

    Returns {"S4": {"job": ..., "message": ..., "buyerQuestion": ..., "headers": [...]}}
    in brief order. The Funnel B block is the text the brief actually SENT, so it is the
    primary key; the Set structure row is the fallback and carries the job wording.
    """
    slots = {}
    order = []
    in_table = False
    for line in text.splitlines():
        if line.startswith("## Set structure"):
            in_table = True
            continue
        if in_table and line.startswith("## "):
            in_table = False
        if in_table:
            m = re.match(r"\|\s*(S\d+)\s*\|\s*([^|]+?)\s*\|\s*([^|]+?)\s*\|", line)
            if m:
                sid, job, msg = m.group(1), m.group(2).strip(), m.group(3).strip().strip('"')
                slots.setdefault(sid, {"job": job, "message": msg, "buyerQuestion": "", "headers": []})
                if sid not in order:
                    order.append(sid)
    cur = None
    for line in text.splitlines():
        m = re.match(r"\s*-\s*Slot for (S\d+)", line)
        if m:
            cur = m.group(1)
            slots.setdefault(cur, {"job": "", "message": "", "buyerQuestion": "", "headers": []})
            if cur not in order:
                order.append(cur)
            continue
        if cur:
            m = re.match(r'\s*-\s*buyerQuestion:\s*"(.*)"', line)
            if m:
                slots[cur]["buyerQuestion"] = m.group(1)
            m = re.match(r"\s*-\s*headerPhrases:\s*\[(.*)\]", line)
            if m:
                slots[cur]["headers"] = [h.strip().strip('"') for h in re.findall(r'"([^"]*)"', m.group(1))]
    return [(sid, slots[sid]) for sid in order]


def read_plan(obj):
    plan = obj.get("plan", obj)
    slots = plan.get("slots") or plan.get("slotAssignments") or []
    out = []
    for s in slots:
        if s.get("protectedMainImage") or s.get("imageType") == "MAIN_IMAGE" or s.get("slotType") == "MAIN_IMAGE":
            continue
        out.append({
            "slotNumber": s.get("slotNumber"),
            "type": s.get("imageType") or s.get("slotType") or "",
            "buyerQuestion": s.get("buyerQuestion") or "",
            "headers": list(s.get("headerPhrases") or []),
            "blocked": bool(s.get("generationBlocked")),
        })
    return out


def score(brief_slot, plan_slot):
    """Best of: buyer question vs buyer question, any brief header/message vs any plan header."""
    best = jaccard(tokens(brief_slot["buyerQuestion"]), tokens(plan_slot["buyerQuestion"]))
    ours = [h for h in brief_slot["headers"]] + ([brief_slot["message"]] if brief_slot["message"] else [])
    for h in ours:
        for p in plan_slot["headers"]:
            best = max(best, jaccard(tokens(h), tokens(p)))
    return best


def audit(brief_slots, plan_slots, target=None):
    """Greedy one-to-one assignment by descending score. Returns (rows, problems).

    `target` is the set of plan slot numbers this run will generate; None means every
    secondary slot (the Theme Blast). Parity problems are gallery-wide. A generationBlocked
    slot is a problem only when it is in `target`.
    """
    all_numbers = {p["slotNumber"] for p in plan_slots}
    target = all_numbers if target is None else set(target)
    pairs = []
    for i, (sid, b) in enumerate(brief_slots):
        for j, p in enumerate(plan_slots):
            pairs.append((score(b, p), i, j))
    pairs.sort(reverse=True)
    b_taken, p_taken, match = set(), set(), {}
    for sc, i, j in pairs:
        if sc < THRESHOLD or i in b_taken or j in p_taken:
            continue
        match[i] = (j, sc)
        b_taken.add(i)
        p_taken.add(j)
    problems = []
    rows = []
    for i, (sid, b) in enumerate(brief_slots):
        fname = f"sec-{i + 1:02d}.png"
        if i in match:
            j, sc = match[i]
            p = plan_slots[j]
            in_run = p["slotNumber"] in target
            if p["blocked"] and in_run:
                state = "BLOCKED"
            elif p["blocked"]:
                state = "blocked, outside this run"
            else:
                state = "ok" if in_run else "ok, outside this run"
            rows.append((sid, b["job"] or b["buyerQuestion"], f"plan slot {p['slotNumber']} ({p['type']})",
                         " / ".join(p["headers"]) or p["buyerQuestion"], f"{sc:.2f}", fname, state))
            if p["blocked"] and in_run:
                problems.append(f"{sid} sits on plan slot {p['slotNumber']}, which is generationBlocked and is a target of this run: "
                                f"the run would skip it. Read the slot state back and reopen THAT slot only if the owner's action needs it")
        else:
            near = max(((score(b, p), p) for p in plan_slots), key=lambda t: t[0], default=(0, None))
            hint = f"; nearest is plan slot {near[1]['slotNumber']} at {near[0]:.2f}" if near[1] else ""
            rows.append((sid, b["job"] or b["buyerQuestion"], "NO PLAN SLOT", "", "", fname, "MISSING"))
            problems.append(f"{sid} ({b['job'] or b['message'] or b['buyerQuestion']}) has no plan slot carrying its job{hint}")
    for j, p in enumerate(plan_slots):
        if j not in p_taken:
            twins = [(score(b, p), sid) for sid, b in brief_slots]
            twins.sort(reverse=True)
            if twins and twins[0][0] >= THRESHOLD:
                problems.append(f"plan slot {p['slotNumber']} ({p['type']}, {' / '.join(p['headers']) or p['buyerQuestion']}) "
                                f"repeats {twins[0][1]}'s job, which is already carried by another slot")
            else:
                problems.append(f"plan slot {p['slotNumber']} ({p['type']}, {' / '.join(p['headers']) or p['buyerQuestion']}) "
                                f"carries a job the brief never approved")
    if len(brief_slots) != len(plan_slots):
        problems.append(f"the brief carries {len(brief_slots)} secondary slots and the plan {len(plan_slots)}")
    for n in sorted(target - all_numbers, key=str):
        problems.append(f"target slot {n} is not a secondary slot of this plan")
    return rows, problems


def render(rows, problems, brief_path, plan_path, target=None):
    verdict = "PARITY" if not problems else "FAIL"
    scope = "all secondary slots" if target is None else "slots " + ", ".join(str(n) for n in sorted(target, key=str))
    out = [f"# Brief to plan parity . {verdict}", "",
           f"Brief: `{brief_path}`  Plan: `{plan_path}`  Threshold: {THRESHOLD} (content-word overlap)  Target of this run: {scope}", "",
           "| Brief slot | Intended job | Saved plan slot | Current message / header | Match | Local file | State |",
           "|---|---|---|---|---|---|---|"]
    for r in rows:
        out.append("| " + " | ".join(str(c) for c in r) + " |")
    out.append("")
    if problems:
        out.append("## Problems (nothing may be generated until each is resolved through the plan, or the owner approves the change in writing)")
        out += [f"- {p}" for p in problems]
    else:
        outside = [r for r in rows if r[6] == "blocked, outside this run"]
        out.append("Every brief job has exactly one plan slot, no plan slot is unapproved, no target slot is blocked, and the counts agree.")
        if outside:
            out.append(f"{len(outside)} slot(s) are blocked outside this run's target and stay closed on purpose: "
                       + ", ".join(r[2] for r in outside) + ".")
    return "\n".join(out) + "\n"


def parse_targets(argv):
    """None for --all or no flag; a set of ints for --target-slots 7,8. Raises ValueError."""
    if "--target-slots" not in argv:
        return None
    if "--all" in argv:
        raise ValueError("--all and --target-slots exclude each other")
    raw = argv[argv.index("--target-slots") + 1]
    nums = {int(x) for x in raw.replace(" ", "").split(",") if x}
    if not nums:
        raise ValueError("--target-slots needs at least one slot number")
    return nums


def main(argv):
    args = [a for a in argv[1:] if not a.startswith("--")]
    out_path = None
    if "--out" in argv:
        out_path = argv[argv.index("--out") + 1]
        args = [a for a in args if a != out_path]
    try:
        target = parse_targets(argv)
    except (ValueError, IndexError) as e:
        print(f"bad --target-slots: {e}")
        return 2
    if target is not None:
        args = [a for a in args if a != argv[argv.index("--target-slots") + 1]]
    if len(args) != 2:
        print(__doc__)
        return 2
    brief_path, plan_path = args
    try:
        brief_slots = read_brief(Path(brief_path).read_text(encoding="utf-8"))
        plan_slots = read_plan(json.loads(Path(plan_path).read_text(encoding="utf-8")))
    except (OSError, ValueError) as e:
        print(f"could not read an input: {e}")
        return 2
    if not brief_slots:
        print("no secondary slots found in the brief (need a '## Set structure' table or 'Slot for S#' blocks)")
        return 2
    if not plan_slots:
        print("no secondary slots found in the plan JSON")
        return 2
    rows, problems = audit(brief_slots, plan_slots, target)
    report = render(rows, problems, brief_path, plan_path, target)
    if out_path:
        Path(out_path).write_text(report, encoding="utf-8")
    print(report)
    return 1 if problems else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))

"""Fixture tests for fact_preflight.py, on the real Day 6 plan of the demo product.

Run: python3 test_fact_preflight.py
"""
import copy
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from fact_preflight import claims, facts_from, preflight, verdict, render  # noqa: E402

HERE = Path(__file__).parent / "fixtures"
FAILURES = []


def check(name, cond, detail=""):
    print(("  PASS  " if cond else "  FAIL  ") + name + ("" if cond else "  " + str(detail)[:300]))
    if not cond:
        FAILURES.append(name)


def vu(text):
    """{(value, unit)} of the positive claims in text."""
    return {(c.value, c.unit) for c in claims(text) if not c.negated and c.value is not None}


def label(row):
    """'8.5 in (width)' -> '8.5 in'."""
    return row[1].split(" (")[0]


def mini(*headers):
    return {"plan": {"slots": [{"slotNumber": 3, "headerPhrases": list(headers)}]}}


plan = json.loads((HERE / "fondue-plan-2026-09-07.json").read_text(encoding="utf-8"))
spec = (HERE / "fondue-reference-spec.md").read_text(encoding="utf-8")
brief = (HERE / "fondue-brief-excerpt.md").read_text(encoding="utf-8")
competitors = (HERE / "fondue-competitors-excerpt.md").read_text(encoding="utf-8")
listing = (HERE / "fondue-listing-excerpt.md").read_text(encoding="utf-8")
sources = spec + "\n" + brief + "\n" + listing

print("fact preflight")

# 1. The extractor reads the shapes that matter.
got = vu("It stands 18 inches tall on an 8.5-inch base and weighs 4.9 pounds.")
check("18 inches / 8.5-inch / 4.9 pounds are read", {("18", "in"), ("8.5", "in"), ("4.9", "lb")} <= got, got)
got = vu("Size: 8 x 8 x 18 inches")
check("a dimension chain gives every number the unit", {("8", "in"), ("18", "in")} <= got, got)
got = vu("Four tiers, eighteen inches tall")
check("number words are read", {("4", "tier"), ("18", "in")} <= got, got)
got = vu("32-Ounce Bowl and 60% cocoa")
check("32-Ounce and 60% are read", {("32", "oz"), ("60", "pct")} <= got, got)
got = vu("The base is 8 INCHES wide, never 8.5")
check("a negated clause is not a claim, the positive half beside it still is",
      ("8", "in") in got and ("8.5", "in") not in got, got)
check("the reference spec yields 8 in, 18 in, 4.9 lb, 32 oz, 120 v, 60 hz",
      {("8", "in"), ("18", "in"), ("4.9", "lb"), ("32", "oz"), ("120", "v"), ("60", "hz")} <= set(facts_from(spec)), set(facts_from(spec)))
check("the spec binds 4.9 lb to weight and 32 oz to capacity",
      "weight" in facts_from(spec)[("4.9", "lb")]["pos"] and "capacity" in facts_from(spec)[("32", "oz")]["pos"], facts_from(spec))

# 2. THE REAL FAILURE: the plan's product block still says 8.5-inch base. Preflight FAILS and names the competitor.
ok, bad, review = preflight(plan, sources, competitors)
bad_85 = [b for b in bad if label(b) == "8.5 in"]
check("8.5 in is flagged", bool(bad_85), bad)
check("8.5 in is traced to the product block (description and bullet)",
      {b[0] for b in bad_85} >= {"product.description", "product.bullet 1"}, {b[0] for b in bad_85})
check("the finding says it also appears in the competitor research", all("COMPETITOR" in b[3] for b in bad_85), bad_85)
check("8 in wide (slot 3 header) is sourced, not flagged",
      any(o[0] == "slot 3 headerPhrases" and label(o) == "8 in" for o in ok) and not any(label(b) == "8 in" for b in bad), (ok, bad))
check("18 in, 32 oz, 4.9 lb, 60 pct are sourced", {"18 in", "32 oz", "4.9 lb", "60 pct"} <= {label(o) for o in ok}, {label(o) for o in ok})
check("18 in tall and 4.9 lb are sourced UNDER their attribute, not by value alone",
      any(label(o) == "18 in" and o[3] == "sourced as height" for o in ok) and any(label(o) == "4.9 lb" and o[3] == "sourced as weight" for o in ok), ok)

# 3. Every other unsourced number is a real finding too: "(4 cups)" has no source anywhere (32 oz is
#    the sourced figure). "three-quarter view" is NOT a claim. The corrected plan passes once 8.5 is
#    fixed and the cups removed.
check("the unsourced 4 cups is reported as well, and nothing else is", {label(b) for b in bad} == {"8.5 in", "4 cup"}, bad)
check("the fixture plan needs no review rows (its verdict is a plain FAIL)", not review and verdict(bad, review) == "FAIL", review)
fixed = copy.deepcopy(plan)
prod = fixed["projectSetup"]["product"]
prod["description"] = prod["description"].replace("8.5-inch", "8-inch").replace(" (4 cups)", "")
prod["bulletPoints"][0] = prod["bulletPoints"][0].replace("8.5-inch", "8-inch")
ok2, bad2, review2 = preflight(fixed, sources, competitors)
check("the corrected plan is CLEAN once every number is sourced or removed", not bad2 and not review2 and verdict(bad2, review2) == "CLEAN", (bad2, review2))

# 4. Without the competitor file the flag survives, only the attribution changes.
ok3, bad3, _ = preflight(plan, sources, "")
check("no competitor file: 8.5 still flagged as unsourced", any(label(b) == "8.5 in" and "not in any" in b[3] for b in bad3), bad3)

# 5. A number that only a competitor says is never made lawful by the competitor file.
plan_rival = copy.deepcopy(fixed)
plan_rival["plan"]["slots"][2]["headerPhrases"].append("8.5 in base")
ok4, bad4, _ = preflight(plan_rival, sources, competitors)
check("competitor research never sources a claim", any(label(b) == "8.5 in" for b in bad4), bad4)

# 6. THE FOUR REPRODUCED MISSES (release review, finding 3). Each returned the wrong verdict on v28.
ok, bad, review = preflight(mini("8.5 inches wide"), "Base width: 8 inches. Never 8.5 inches.")
check("a value the source NEGATES is not sourced ('Never 8.5 inches' vs '8.5 inches wide' -> FAIL)",
      verdict(bad, review) == "FAIL" and any(label(b) == "8.5 in" and "NEGATE" in b[3] for b in bad), (ok, bad, review))
ok, bad, review = preflight(mini("18 inches wide"), "Height: 18 inches. Width: 8 inches.")
check("a number under another attribute is not sourced ('Height: 18' vs '18 inches wide' -> FAIL, names height)",
      verdict(bad, review) == "FAIL" and any(label(b) == "18 in" and "height" in b[3] and "not as width" in b[3] for b in bad), (ok, bad, review))
ok, bad, review = preflight(mini("8.5 inches wide and no oil needed"), "Width: 8 inches.")
check("'no oil' in the same sentence does not hide '8.5 inches wide' (-> FAIL on 8.5 in)",
      verdict(bad, review) == "FAIL" and any(label(b) == "8.5 in" for b in bad), (ok, bad, review))
ok, bad, review = preflight(mini("thirty-two ounces"), "Capacity: 32 ounces.")
check("'thirty-two ounces' reads as 32 oz and is sourced (-> CLEAN, never '2 oz')",
      verdict(bad, review) == "CLEAN" and any(label(o) == "32 oz" for o in ok) and not any("2 oz" == label(b) for b in bad), (ok, bad, review))

# 7. The guards around those fixes.
ok, bad, review = preflight(mini("8 inches wide and no oil needed"), "Width: 8 inches.")
check("'8 inches wide and no oil needed' against 'Width: 8 inches' is CLEAN, sourced as width",
      verdict(bad, review) == "CLEAN" and any(label(o) == "8 in" and o[3] == "sourced as width" for o in ok), (ok, bad, review))
ok, bad, review = preflight(mini("8.5 inches wide"), "Base: 8.5 inches wide. The base is never 8.5 inches wide.")
check("a source that both states and negates a value -> NEEDS REVIEW, never the convenient pick",
      verdict(bad, review) == "NEEDS REVIEW" and any("NEEDS CLARIFICATION" in r[3] for r in review), (ok, bad, review))
ok, bad, review = preflight(mini("twenty thirty ounces"), "Capacity: 32 ounces.")
check("number words the parser cannot read -> UNVERIFIED and NEEDS REVIEW, not a misread value",
      verdict(bad, review) == "NEEDS REVIEW" and any("UNVERIFIED" in r[3] for r in review), (ok, bad, review))
check("compound number words: one hundred twenty, twenty four, thirty-two",
      vu("one hundred twenty volts, twenty four cups, thirty-two ounces") >= {("120", "v"), ("24", "cup"), ("32", "oz")},
      vu("one hundred twenty volts, twenty four cups, thirty-two ounces"))
ok, bad, review = preflight(mini("8 in wide"), "Size: 8 x 8 x 18 inches")
check("a claim with an attribute against an attribute-free source is sourced but marked 'attribute unverified'",
      verdict(bad, review) == "CLEAN" and any(label(o) == "8 in" and "attribute unverified" in o[3] for o in ok), (ok, bad, review))
report = render(ok, bad, review, "plan.json", ["spec.md"])
check("the CLEAN report never claims more than it checked", "attribute unverified" in report and "every rendered number" not in report, report)
ok, bad, review = preflight(mini("twenty thirty ounces"), "Capacity: 32 ounces.")
report = render(ok, bad, review, "plan.json", ["spec.md"])
check("a NEEDS REVIEW report says so in its title and never reads as a pass",
      report.startswith("# Fact preflight . NEEDS REVIEW") and "not a pass" in report, report[:200])

# 8. alternateCreativeBriefs are live inputs: a contradicting number inside one FAILS.
alt = copy.deepcopy(fixed)
alt["plan"]["slots"][2]["alternateCreativeBriefs"] = [{"contentBrief": "The fountain on an 8.5-inch base, shown at scale."},
                                                      "A second alternate, 18 inches tall."]
ok5, bad5, _ = preflight(alt, sources, competitors)
check("a contradicting number inside an alternate brief FAILS and names the alternate",
      any(label(b) == "8.5 in" and "alternateCreativeBriefs" in b[0] for b in bad5), bad5)
check("the lawful alternate (18 inches tall) is sourced", any(o[0].endswith("alternateCreativeBriefs[2]") and label(o) == "18 in" for o in ok5), ok5)

# 9. FOUR MORE REPRODUCED MISSES (9 September 2026, second pass). Each returned the wrong verdict on the rewrite.
# 9a. A plan-side negation word in the look-back used to DROP the claim, so an unsourced number came back CLEAN.
for header in ("No assembly, 18 inches tall", "Not a toy, 18 inches tall", "without oil, 32 ounces of chocolate"):
    ok, bad, review = preflight(mini(header), "Width: 8 inches.")
    check(f"a comma before the number opens a new clause: '{header}' vs 'Width: 8 inches' -> FAIL, not CLEAN",
          verdict(bad, review) == "FAIL" and len(bad) == 1, (ok, bad, review))
ok, bad, review = preflight(mini("no tools needed 18 inches tall"), "Width: 8 inches.")
check("a plan-side negation with no comma is never dropped: 'no tools needed 18 inches tall' -> NEEDS REVIEW, not CLEAN",
      verdict(bad, review) == "NEEDS REVIEW" and any(label(r) == "18 in" and "negates" in r[3] for r in review), (ok, bad, review))
ok, bad, review = preflight(mini("No assembly, 18 inches tall"), "Height: 18 inches.")
check("the split clause still binds its own attribute: 'No assembly, 18 inches tall' vs 'Height: 18 inches' -> CLEAN as height",
      verdict(bad, review) == "CLEAN" and any(label(o) == "18 in" and o[3] == "sourced as height" for o in ok), (ok, bad, review))
# 9b. The look-back crossed a comma into the previous clause and produced a false NEGATE.
ok, bad, review = preflight(mini("8 inches wide"), "Never 8.5 inches, always 8 inches wide.")
check("the look-back stops at a comma: 'Never 8.5 inches, always 8 inches wide' sources '8 inches wide' (-> CLEAN, no false NEGATE)",
      verdict(bad, review) == "CLEAN" and any(label(o) == "8 in" and o[3] == "sourced as width" for o in ok), (ok, bad, review))
ok, bad, review = preflight(mini("8.5 inches wide"), "Never 8.5 inches, always 8 inches wide.")
check("and the 8.5 in that source is still negated (-> FAIL on 8.5 in)",
      verdict(bad, review) == "FAIL" and any(label(b) == "8.5 in" and "NEGATE" in b[3] for b in bad), (ok, bad, review))
# 9c. Mixed fractions and thousands separators were misread ('2 in', '1 w').
got = vu("8 1/2 inches wide and 1,000 watts, 1,250.5 grams")
check("'8 1/2 inches' is 8.5 in, '1,000 watts' is 1000 w, '1,250.5 grams' is 1250.5 g",
      {("8.5", "in"), ("1000", "w"), ("1250.5", "g")} <= got and ("2", "in") not in got and ("1", "w") not in got, got)
ok, bad, review = preflight(mini("8 1/2 inches wide", "1,000 watts"), "Width: 8.5 inches. Power: 1000 watts.")
check("'8 1/2 inches wide' and '1,000 watts' are sourced (-> CLEAN)", verdict(bad, review) == "CLEAN" and {label(o) for o in ok} == {"8.5 in", "1000 w"}, (ok, bad, review))
check("a European decimal still reads: '8,5 inches' is 8.5 in", ("8.5", "in") in vu("8,5 inches wide"), vu("8,5 inches wide"))
# 9d. A range checked only its second number.
got = vu("fits 8 to 10 inches and 2-4 cups")
check("a range yields both ends: '8 to 10 inches' and '2-4 cups'", {("8", "in"), ("10", "in"), ("2", "cup"), ("4", "cup")} <= got, got)
ok, bad, review = preflight(mini("fits 8 to 10 inches"), "Width: 10 inches.")
check("'fits 8 to 10 inches' vs 'Width: 10 inches' -> FAIL on the unsourced 8 in",
      verdict(bad, review) == "FAIL" and any(label(b) == "8 in" for b in bad) and any(label(o) == "10 in" for o in ok), (ok, bad, review))
check("'8-inch base' is not a range", vu("on an 8-inch base") == {("8", "in")}, vu("on an 8-inch base"))

print()
if FAILURES:
    print(f"{len(FAILURES)} failing: {FAILURES}")
    sys.exit(1)
print("all fact_preflight fixtures pass")

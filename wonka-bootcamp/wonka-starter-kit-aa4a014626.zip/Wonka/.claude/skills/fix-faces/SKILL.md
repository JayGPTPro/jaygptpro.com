---
name: fix-faces
description: One-click rescue for AI-looking people in ANY image, no factory context needed. Point it at an image file (or a folder), Wonka diagnoses which of the three realism signatures it shows (doll face, waxy skin + uniform tone, filter glow), runs ONE whole-image gpt-image edit pass that touches only the people, and saves the fixed version BESIDE the original. Clean images are left alone and told so. Works on factory images, old images, images from anywhere. Use when people in an image look fake, plastic, AI-generated, waxy, or over-filtered. Triggers: /fix-faces, "fix the faces", "the people look fake", "make the people real", "the skin looks weird", "AI-looking people".
---

# The Face Clinic

| Meta | Value |
|------|-------|
| Room | The Face Clinic (a walk-in clinic, not a production station) |
| Station | None. Runs any day, on any image, factory or not |
| Needs | An image file path (or a folder of images) and `OPENAI_API_KEY` |
| Saves to | A fixed copy BESIDE the original: `[name]-faces-fixed.png`. The original is never touched |
| Typical cost | One gpt-image edit per flagged image, quality low, cents each. Reported, not gated |

## What this room does

Generated people sometimes come out AI-looking. This clinic diagnoses WHICH way, fixes only what is
broken, and leaves clean images alone. It is deliberately tiny: no preconditions, no product folder,
no brief. Bring an image, leave with a real-looking one.

## The three signatures (the diagnosis vocabulary)

1. **Signature A, doll face** (geometry and expression): too-perfect symmetric features, uniform
   flawless teeth, glassy eyes, and everyone in frame at identical peak expression (all mid-laugh at
   once). Shows up even when lighting and color are believable.
2. **Signature B, waxy skin + uniform tone**: zero skin micro-texture (no pores, one smooth
   gradient), and every person wearing the same peach-orange tone that matches the design palette
   instead of varying per person.
3. **Signature C, the filter layer**: a diffusion/bloom glow like a beauty filter, highlights
   smearing on forehead and cheekbones, and warm light patches painted on with no single consistent
   light direction.

## Process

1. **Open the image and diagnose, out loud.** Look at the people at full size. Name which
   signature(s) apply, with one line of evidence each, or say **CLEAN** and stop: a clean image is
   never "improved" speculatively. No people in the image at all: say so and stop.
2. **Report the cost in one line** (one edit at quality low, cents) and run. No gate: the owner
   asked by invoking the room.
3. **Run ONE whole-image edit pass on the OpenAI images.edit endpoint** (newest gpt-image model,
   quality low unless asked higher, size matching the source aspect from 1024x1024 / 1536x1024 /
   1024x1536). Two laws:
   - **Always the FULL image, never a crop.** A crop that truncates a headline makes the model
     reinvent the missing text; the full frame preserves headlines, packaging, product, and
     on-screen text.
   - **Name the failures concretely.** Generic "make them realistic" is a style hint the model
     believes it already satisfies. The proven prompt:

     For Signature A (always include when A is flagged):
     > Keep this exact image: same composition, same product, same text, same layout, same colors,
     > same people in the same poses. Change ONLY the people so they look like real photographed
     > humans instead of AI renders: natural asymmetric facial features, varied expression intensity
     > so not everyone is at peak laughter, normal slightly imperfect teeth, realistic eyes,
     > individual hair strands. Do not touch anything else in the image.

     For Signatures B/C, append:
     > Also: real skin micro-texture with visible pores and subtle imperfections, natural subsurface
     > skin tones with variation between people instead of one uniform warm cast, realistic
     > directional lighting with soft natural shadows on faces, a faint photographic grain.
4. **Save beside the original**: `[name]-faces-fixed.png` in the same folder. Never overwrite,
   never delete the original. A second attempt saves as `-faces-fixed-v2`.
5. **Verify side by side.** Open both, confirm: the people now read as real, AND everything else
   survived (headlines letter-for-letter, product unchanged, layout identical, any small on-screen
   text intact). If anything else drifted, say exactly what, and offer one retry; text drift on a
   busy design is the known failure mode of a whole-frame edit.
6. **On a folder**: diagnose every image first, list the flagged ones with their signatures, give
   ONE total cost line, WAIT for one yes (a folder is a paid edit batch, and CLAUDE.md's spend rule puts those on the fresh-go-ahead list; single-image mode stays report-and-run because invoking the room on one image IS the ask), then fix them in parallel.

## What this room never does

- Never touches a CLEAN image, and never edits anything except the people.
- Never crops, never masks, never recasts (a different person or pose is a regeneration, back in the
  image's own room).
- Never overwrites an original.
- Never claims the fix is invisible: it verifies side by side and reports drift honestly.

## Wonka lines

- "The Face Clinic. Walk-ins welcome, bring me anyone who came out of the ovens looking like a mannequin."
- "Diagnosis first. I do not operate on healthy faces."
- "There. Same picture, real people. The original is untouched, as always."

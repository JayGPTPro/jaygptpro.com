# Kit changelog

One line per release. Wonka reads this after an upgrade and tells the owner the one change
that matters most for the day they are on.

Numbering rule: versions are minted only by what a student can hold. Everything before the
first cohort's Day 1 is a draft of v1, whatever we called it internally.

## v1 (the kit the first cohort downloads on Day 1)
- The full Factory: 16 rooms, the Ten Days, the two machines, and the self-upgrade system
  ("upgrade the kit" and Wonka does the rest).

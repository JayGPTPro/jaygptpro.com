#!/usr/bin/env python3
"""Magnified crops for the structure read of the Inspection Room.

The 160px squint copy answers legibility. Product accuracy is read at full size and at
magnification, and this tool makes the magnified reads real files that get opened with Read:

  python3 .claude/skills/inspect/magnify.py <image> <out-dir> [x,y,w,h ...]

With no boxes it writes a 2x2 grid of quadrant crops at 2x, so every region of the frame gets a
close look. With boxes (source pixels) it writes each box at 3x, plus, when two or more boxes
are given, one side-by-side strip of them at the same scale so two instances of the product in
one frame (or the candidate beside its reference) can be compared for structure: where the parts
sit relative to each other, whether a column runs on one axis through the tiers it passes, whether
a bowl sits on its base the way the real product does. The tool measures nothing and decides
nothing; the eye does, on these files.
"""
import os, sys
from PIL import Image, ImageDraw, ImageFont

def parse_box(s):
    x, y, w, h = [int(v) for v in s.split(",")]
    return x, y, w, h

def label(im, text):
    d = ImageDraw.Draw(im)
    try: f = ImageFont.truetype("/System/Library/Fonts/Supplemental/Arial Bold.ttf", 22)
    except Exception: f = ImageFont.load_default()
    d.rectangle([0, 0, 12 + d.textlength(text, font=f), 32], fill=(0, 0, 0))
    d.text((6, 4), text, fill=(255, 220, 80), font=f)
    return im

def main():
    if len(sys.argv) < 3:
        sys.exit(__doc__)
    src, out = sys.argv[1], sys.argv[2]
    boxes = [parse_box(b) for b in sys.argv[3:]]
    os.makedirs(out, exist_ok=True)
    im = Image.open(src).convert("RGB"); W, H = im.size
    stem = os.path.splitext(os.path.basename(src))[0]
    written = []
    if not boxes:
        for i, (x, y) in enumerate([(0, 0), (W // 2, 0), (0, H // 2), (W // 2, H // 2)]):
            crop = im.crop((x, y, x + W // 2, y + H // 2)).resize((W, H), Image.LANCZOS)
            p = os.path.join(out, f"{stem}-q{i + 1}-2x.png"); label(crop, f"{stem} quadrant {i + 1} at 2x").save(p); written.append(p)
    else:
        crops = []
        for i, (x, y, w, h) in enumerate(boxes):
            crop = im.crop((x, y, x + w, y + h)).resize((w * 3, h * 3), Image.LANCZOS)
            p = os.path.join(out, f"{stem}-box{i + 1}-3x.png"); label(crop.copy(), f"{stem} box {i + 1} [{x},{y},{w},{h}] at 3x").save(p); written.append(p)
            crops.append(crop)
        if len(crops) >= 2:
            h = max(c.height for c in crops); gap = 24
            strip = Image.new("RGB", (sum(c.width for c in crops) + gap * (len(crops) - 1), h), (24, 24, 24))
            x = 0
            for c in crops:
                strip.paste(c, (x, (h - c.height) // 2)); x += c.width + gap
            p = os.path.join(out, f"{stem}-compare-3x.png"); label(strip, f"{stem}: the boxes side by side at 3x, same scale").save(p); written.append(p)
    for p in written: print(p)

if __name__ == "__main__":
    main()

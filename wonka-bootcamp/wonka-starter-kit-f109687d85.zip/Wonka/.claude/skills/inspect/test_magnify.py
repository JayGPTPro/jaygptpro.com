"""magnify.py: writes the quadrant crops, the 3x box crops and the side-by-side strip.
Run: python3 test_magnify.py"""
import subprocess, sys, tempfile
from pathlib import Path
from PIL import Image
HERE = Path(__file__).parent
fails = []
def check(name, cond): print(("  PASS  " if cond else "  FAIL  ") + name); fails.append(name) if not cond else None
with tempfile.TemporaryDirectory() as d:
    d = Path(d); Image.new("RGB", (400, 300), (120, 90, 60)).save(d / "img.png")
    r = subprocess.run([sys.executable, str(HERE / "magnify.py"), str(d / "img.png"), str(d / "out")], capture_output=True, text=True)
    check("no boxes: four quadrant crops at 2x", r.returncode == 0 and len([p for p in (d / "out").glob("img-q*-2x.png")]) == 4)
    q = Image.open(d / "out" / "img-q1-2x.png"); check("a quadrant crop is the full frame size", q.size == (400, 300))
    r = subprocess.run([sys.executable, str(HERE / "magnify.py"), str(d / "img.png"), str(d / "out2"), "10,10,100,50", "200,10,100,50"], capture_output=True, text=True)
    files = sorted(p.name for p in (d / "out2").glob("*.png"))
    check("two boxes: two 3x crops and one compare strip", r.returncode == 0 and files == ["img-box1-3x.png", "img-box2-3x.png", "img-compare-3x.png"])
    b = Image.open(d / "out2" / "img-box1-3x.png"); check("a box crop is 3x", b.size == (300, 150))
print("magnify:", "FAIL" if fails else "PASS", f"({len(fails)} failures)")
sys.exit(1 if fails else 0)

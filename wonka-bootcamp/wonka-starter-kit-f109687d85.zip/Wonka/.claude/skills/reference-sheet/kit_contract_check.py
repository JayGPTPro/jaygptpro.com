"""Static contract check for the three separated concepts: product/packaging
references, a real logo asset, and optional brand styling.

Three things kept getting conflated in this kit, and each one produced a real
defect on a real run:

1. A logo was treated as brand-kit work, so a seller with a logo and no brand
   book was told to build a brand.
2. `/brand-kit` proposed an invented identity when no brand files existed.
3. Generation rooms inferred the Genrupt preset from the existence of
   `brand-kit.md`, so a logo-only preset was invisible to them.

This scanner reads the SHIPPED kit and fails on the wording that brings any of
those back. It is text-only: no Genrupt call, no network, no product data.

Run: python3 kit_contract_check.py [kit_root]
"""
import re
import sys
from pathlib import Path

# (id, regex, why it is banned). Matched case-insensitively, line by line.
BANNED = [
    ("proposes-a-brand-unasked",
     r"(wonka )?propos(e|es|ing) (a |the )?(full |complete |starting )?(kit|brand|palette|identity|direction)",
     "a brand direction may be proposed ONLY when the owner ran /brand-kit and said yes; never offered"),
    ("wonka-proposes-mode",
     r"\*\*WONKA PROPOSES",
     "the proposal mode was removed; there are two states, guide or no guide"),
    ("logo-blocks",
     r"(missing|no) logo (is|as) a gap",
     "a missing logo is finished work, never a gap"),
    ("logo-needs-brand-kit",
     r"logo (file )?(is )?required for (branding|the brand kit)",
     "a logo never depends on brand styling"),
    ("brand-book-required-for-logo",
     r"brand book is required",
     "a logo needs no Brand Book"),
    ("logo-into-packaging",
     r"logo[^.\n]{0,40}(packagingImages|packaging bucket)",
     "packagingImages is a semantically wrong destination for a logo"),
    ("logo-into-slot-refs",
     r"logo[^.\n]{0,40}slot(')?s? referenceImages",
     "per-slot referenceImages is not the logo route"),
    ("preset-only-from-kit-file",
     r"preset (is )?(only )?(resolved|read) from `?factory/Brand/brand-kit\.md",
     "the canonical preset lookup is the status.md Genrupt preset ID row"),
    ("file-management-homework",
     r"(drop|place|move|put) (the |your )?(actual |real )?files? (into|in) `?2-reference",
     "users attach files to Claude; Wonka routes them"),
    ("attach-403-era",
     r"every route 403s|sheets? cannot be attached|material lock as short|lock as the material lock",
     "approved sheets attach with references.mode replace (5 September 2026); the 21 August workaround is dead"),
    ("typo-pulls",
     r"typo pulls|typo (is )?pulled|typo[^.]{0,40}never (reaches|enters)",
     "a tag typo TAGS a candidate (fixed after the pick); only hard defects pull (Jay, 6 September 2026)"),
    ("prop-as-defect",
     r"removable prop|props? (is|are) (a defect|forbidden|banned)",
     "props are lawful on every image, the main included (Jay, 6 September 2026)"),
    ("policy-recital",
     r"no text, logos, watermarks, (props|badges)|props, or borders|no props, no people|image requirements page",
     "Wonka never recites Amazon's image policy; props, and people under the human-contact tactic, are lawful (Jay, 6 September 2026)"),
    ("safely-compliant",
     r"safely compliant",
     "no candidate is called compliant or non-compliant in front of the owner; the plain one is the backup"),
    ("concept-number-banned",
     r"identifies a pick by screenshot|no \"selected\" field at all",
     "the number on Wonka's sheet IS the vocabulary, and get_aplus_concept_selection reads the app's pick (6 September 2026)"),
    ("stale-upscale-step8",
     r"finished by the precision upscale in step 8|upscale as part of a plan the owner already approved",
     "no upscale runs by default in /main-image; on Day 5 it runs on request on the primary only (6 September 2026)"),
    ("incumbent-on-day-7",
     r"(saved|downloaded|save the incumbent)[^.]{0,60}end of Day 7|Day 7 close\)",
     "/tasting-room fills incumbent/ at the opening of Day 8; Day 7 ends with the A+ export (6 September 2026)"),
    ("pick-sheet-in-images",
     r"images/pick-\[slot\]",
     "a pick sheet never lands in images/ (write-once, and Day 8 reads it as candidates); it goes to scorecards/"),
    ("spatial-fix-regenerates",
     r"\| Move or resize anything \| REGENERATE|make it or move it is a regenerate|bigger or move it is a regenerate",
     "a local spatial fix is an EDIT on the chosen image, composited back by region; regeneration is for broad changes or after two failed edits (7 September 2026)"),
    ("fix-waits-for-go-ahead",
     r"Nothing paid runs before this|get ONE go-ahead, then run|one go-ahead covers the whole list",
     "routine fixes inside the routine-fix policy's limits run on a report; only a crossed limit or a paid regeneration stops for one approval (7 September 2026)"),
    ("swap-instead-of-fix",
     r"(look|hunt|search) for (another|a different|a free) (image|candidate|alternative) instead of (fixing|the fix)",
     "the chosen image is fixed; an alternative is offered only when asked, approved, or after the route failed twice"),
    ("weekday-name",
     r"\b(Monday|Tuesday|Wednesday|Thursday|Friday|Saturday|Sunday)\b",
     "day numbers, never weekdays (Jay, 6 September 2026)"),
    # Days 8-10 alignment (7 September 2026). Each of these was live in a shipped guide.
    ("student-downloads-incumbent",
     r"(?<!wonka )(download(ed|s)? (it|them|by you|yourself|the live|your (current|live))|you (have )?download(ed)?)[^.]{0,80}incumbent"
     r"|incumbent[^.]{0,80}(?<!wonka )(download(ed|s)? (it|them|by you|yourself|the live|your (current|live))|you (have )?download(ed)?)",
     "Wonka fetches the live images into incumbent/ at /tasting-room step 0b; the owner saves by hand only when the fetch is refused"),
    ("day8-cannot-start-without",
     r"Day 8 (cannot|can't|does not|will not|won't) (start|work|run) without",
     "nothing about the incumbent is a Day 7 task; Day 8 opens by fetching it"),
    ("go-ahead-on-cents",
     r"Approved\. Do those\.",
     "a named defect is a fix order; the owner's move is a refusal with a reason, never a go-ahead on cents"),
    ("lean-ships",
     r"kind of Lean ships",
     "only a Clear lead ships; Lean and Toss-up go to Round 2"),
    ("slides-no-terminal",
     r"Slides\. No terminal",
     "Jay records himself; write 'Lesson 1 is the idea; the terminal starts in lesson 2'"),
    ("your-monday",
     r"your Monday",
     "no weekdays: /factory-report is the weekly ten minutes"),
    ("this-week",
     r"\b(this|all) week\b",
     "day numbers, never 'this week' or 'all week' in a guide (Jay, 6 September 2026)"),
    ("ab-alternates",
     r"A/B alternates",
     "roles are primary / alternatives / backup"),
    ("safe-spare",
     r"safe spare",
     "the plain frame is 'the backup', never a 'safe spare'"),
    ("faces-fixed-name",
     r"faces-fixed\.png[^\n]{0,15}beside the (source|original)",
     "inside the factory /fix-faces lands as edits/v[N+1]/[same name].png (the round law); a suffix beside the source is for loose files only"),
    # Day 6 hardening (7 September 2026): the real run carried eight secondaries, started in a fresh
    # session, looped Claude <-> Genrupt, and lost a brief job between the brief and the machine.
    ("secondary-count-hardcoded",
     r"\(5 to 7 slots\)|5 to 7 secondary|five to seven secondar|sec-01\.png` through `sec-07\.png`|sec-07\.png\s*\(if the brief carries 7 slots\)",
     "the brief owns the secondary count (the demo product carries eight); no room caps it at seven"),
    ("genrupt-owns-lessons",
     r"lessons happen (there|in Genrupt)|blast was launched after Day 5|launched after Day 5's session",
     "Day 6 starts in a fresh session with /secondary-images and loops Claude <-> Genrupt; nothing is launched on Day 5"),
    ("rows-absolute",
     r"Do not shop across rows",
     "the row rule is about un-restyled frames; a composition Restyled into the locked style is lawful from any row"),
    ("learning-loop-day6",
     r"learning loop|improvement-loop|Improvement Log",
     "Day 10 teaches the loop; on Day 6 Wonka only records, and the loop is not named to the student"),
    ("ready-today",
     r"ready to upload (today|on Day 6)|Day 6 (images|frames) are ready to upload",
     "Day 6 locks the gallery in the factory; upscale and the upload pack are Day 10"),
]

# Rules the negation guard may NOT excuse: their banned wording carries "not" or
# "without" by construction ("Day 8 cannot start without them"), so a negator inside
# the match is the violation, not a defence of it.
STRICT = {"student-downloads-incumbent", "day8-cannot-start-without", "rows-absolute"}

# Rules scoped to a path prefix. "this week" is lawful inside /factory-report, which
# really is a weekly report; it is banned in the student-facing guides.
ONLY = {"this-week": ("guides/", "README.md", "QUICK_START.md"),
        "learning-loop-day6": ("guides/episode6-guide.md",),
        # Day 7 (the A+ Room) really does run its edits inside Genrupt; its wording is that day's
        # decision, taken when its films exist. The Day 6 rule is scoped to Day 6.
        "genrupt-owns-lessons": ("guides/episode6-guide.md", ".claude/skills/secondary-images/")}

# Sentences that must SURVIVE, so a later cleanup cannot quietly delete the contract.
REQUIRED = [
    ("CLAUDE.md", "## The routine-fix policy (the one source)"),
    ("CLAUDE.md", "Fix the chosen image first; regenerate second; never swap"),
    (".claude/skills/inspect/SKILL.md", "STRUCTURE AND ASSEMBLY"),
    (".claude/skills/inspect/SKILL.md", "magnify.py"),
    (".claude/skills/inspect/SKILL.md", "never answers a reported defect by offering a different image"),
    (".claude/skills/fix/SKILL.md", "composite_region.py"),
    (".claude/skills/fix/SKILL.md", "**Never swaps.**"),
    (".claude/skills/fix/SKILL.md", "routine-fix policy"),
    ("downloads/edit-versus-regenerate.md", "Fix the chosen image first"),
    ("factory/Products/TEMPLATE/status.md", "Logo source"),
    ("factory/Products/TEMPLATE/status.md", "Genrupt preset ID"),
    ("factory/Products/TEMPLATE/status.md", "Logo in preset"),
    ("factory/Products/TEMPLATE/status.md", "no logo supplied"),
    (".claude/skills/reference-sheet/SKILL.md", "logoThumbnailUrl"),
    (".claude/skills/reference-sheet/SKILL.md", "apply_branding_preset"),
    (".claude/skills/brand-kit/SKILL.md", "Brand Book or Style Guide"),
    (".claude/skills/brand-kit/SKILL.md", "nothing about this room is ever raised by Wonka first"),
    (".claude/skills/brand-kit/SKILL.md", "wonka proposal (owner requested"),
    ("guides/genrupt-intake-guide.md", "logo-only preset is lawful"),
    ("CLAUDE.md", "Genrupt preset ID"),
    ("CLAUDE.md", "never recites Amazon's image policy"),
    (".claude/skills/main-image/SKILL.md", "never hears Amazon's image policy"),
    (".claude/skills/main-image/SKILL.md", "contact_sheet.py pick"),
    (".claude/skills/main-image/SKILL.md", "8b. **The COMBINE"),
    (".claude/skills/main-image/SKILL.md", "backup source: existing frame"),
    (".claude/skills/main-image/SKILL.md", "No upscale runs in this room by default"),
    (".claude/skills/main-image/SKILL.md", "Upscale on request"),
    (".claude/skills/main-image/SKILL.md", "the DEVELOP from a base"),
    (".claude/skills/main-image/SKILL.md", "A candidate made outside the factory"),
    (".claude/skills/main-image/SKILL.md", "KEEP their pool number"),
    (".claude/skills/inspect/SKILL.md", "contact_sheet.py sheet"),
    (".claude/skills/inspect/SKILL.md", "Main pick:"),
    (".claude/skills/inspect/SKILL.md", "| `shortlist` |"),
    (".claude/skills/secondary-images/SKILL.md", "productReferenceSheetIds"),
    (".claude/skills/secondary-images/SKILL.md", "scorecards/pick-sec-"),
    (".claude/skills/secondary-images/SKILL.md", "generate_listing_builder_image"),
    (".claude/skills/secondary-images/SKILL.md", "First look for a blast that already ran"),
    (".claude/skills/variations/SKILL.md", "productReferenceSheetIds"),
    (".claude/skills/aplus/SKILL.md", "additionalReferenceImageUrls"),
    (".claude/skills/aplus/SKILL.md", "get_aplus_concept_selection"),
    (".claude/skills/aplus/SKILL.md", "the number on Wonka's sheet is the vocabulary"),
    (".claude/skills/aplus/SKILL.md", "never recommend it or ask about it"),
    (".claude/skills/fix/SKILL.md", "a face is always `high`"),
    (".claude/skills/tasting-room/SKILL.md", "Fill `incumbent/` before anything else"),
    (".claude/skills/tasting-room/SKILL.md", "step 0b"),
    (".claude/skills/variations/SKILL.md", "upscale: owed"),
    ("guides/episode10-guide.md", "The Shipping Room"),
    ("factory/Products/TEMPLATE/status.md", "Gallery picks:"),
    ("factory/Products/TEMPLATE/status.md", "A+ pick:"),
    # Day 6 hardening (7 September 2026)
    (".claude/skills/secondary-images/SKILL.md", "plan_parity.py"),
    (".claude/skills/secondary-images/SKILL.md", "fact_preflight.py"),
    (".claude/skills/secondary-images/SKILL.md", "Select, complete, reopen"),
    (".claude/skills/secondary-images/SKILL.md", "Two style concepts, two names"),
    (".claude/skills/secondary-images/SKILL.md", "Wonka runs the factory; Genrupt is the visual workstation"),
    (".claude/skills/secondary-images/SKILL.md", "the bootcamp default is THREE"),
    (".claude/skills/secondary-images/SKILL.md", "the seven are never rerun to improve the one"),
    (".claude/skills/inspect/SKILL.md", "The owner challenge protocol"),
    (".claude/skills/inspect/SKILL.md", "- Facts:"),
    (".claude/skills/inspect/SKILL.md", "walked through FOUR stages"),
    (".claude/skills/inspect/SKILL.md", "-correction.md"),
    (".claude/skills/fix/SKILL.md", "Every attempt branches from the SAME accepted parent"),
    (".claude/skills/fix/SKILL.md", "Creative permission, asked between attempt one and attempt two"),
    (".claude/skills/fix/SKILL.md", "THREE lawful sources"),
    (".claude/skills/fix/SKILL.md", "Quality is a variable, not a cure"),
    (".claude/skills/creative-brief/SKILL.md", "5 to 8 SECONDARY slots"),
    ("CLAUDE.md", "Refine style reference"),
    ("guides/episode6-guide.md", "fresh Claude Code session"),
    ("guides/episode6-guide.md", "Select, complete, reopen"),
    ("guides/genrupt-intake-guide.md", "Refine style reference"),
]

SKIP_DIRS = {"__pycache__", ".git", "_archive", "node_modules"}
# Frozen history, not shipped text: an upgrade leaves the old kit beside the new one.
SKIP_PREFIXES = ("_backup", "_pre-upgrade", "_superseded")


NEGATOR = re.compile(r"\b(never|not|nor|without|rather than)\b", re.I)
# A proposal is lawful when the owner asked for it. These words are what makes the
# difference between "Wonka invents a brand" and "the owner requested a starting point",
# so a sentence carrying one is describing the permitted path, not the banned one.
CONSENT = re.compile(
    r"\b(request(s|ed)?|asked|asks|explicit(ly)?|on a yes|only when|wants a proposal|"
    r"if you want|do you want|owner ran|they typed|invoked)\b", re.I)
SENTENCE = re.compile(r"(?<=[.;:])\s+")


def bid_is_proposal(match):
    """True for the proposal rule, the only one consent can excuse."""
    return bool(re.match(r"(?i)(wonka )?propos", match.group(0)))


def negated(line, match):
    """True when this match sits in a sentence that FORBIDS the thing.

    A rule has to name what it bans, so "a logo is never routed into
    packagingImages" would otherwise read as a violation of itself. The unit is
    the SENTENCE, not the paragraph, and the bare word "no" is deliberately not
    a negator here: "with no brand files, Wonka proposes a complete kit" is
    exactly the sentence this scanner exists to catch.
    """
    pos, sentence = 0, line
    for part in SENTENCE.split(line):
        if pos <= match.start() < pos + len(part) + 1:
            sentence = part
            break
        pos += len(part) + 1
    if NEGATOR.search(sentence):
        return True
    return bid_is_proposal(match) and bool(CONSENT.search(sentence))


def logical_lines(text):
    """Yield (first_line_no, joined_text) per paragraph.

    Prose in this kit is hard-wrapped, so "Wonka does not propose a palette from
    the product" is split across two physical lines and a per-line negation check
    reads the second half as an assertion. Paragraphs are the honest unit.
    """
    buf, start = [], 1
    for n, raw in enumerate(text.splitlines(), 1):
        if raw.strip():
            if not buf:
                start = n
            buf.append(raw.strip())
        elif buf:
            yield start, " ".join(buf)
            buf = []
    if buf:
        yield start, " ".join(buf)


def scan(root: Path):
    """Return (violations, missing_required). Each violation is (file, line_no, id, text)."""
    violations = []
    for path in sorted(root.rglob("*.md")):
        parts = set(path.parts)
        if parts & SKIP_DIRS or any(q.startswith(SKIP_PREFIXES) for q in parts):
            continue
        rel = str(path.relative_to(root))
        for n, line in logical_lines(path.read_text(encoding="utf-8")):
            for bid, pattern, _why in BANNED:
                if bid in ONLY and not rel.startswith(ONLY[bid]):
                    continue
                m = re.search(pattern, line, re.I)
                if m and (bid in STRICT or not negated(line, m)):
                    violations.append((rel, n, bid, line.strip()[:120]))
    gate = root / ".claude" / "gate.py"
    if gate.exists() and re.search(r"%[Aa]", gate.read_text(encoding="utf-8")):
        violations.append((".claude/gate.py", 0, "weekday-name",
                           "the gate prints a weekday name; days are numbered, never scheduled by weekday"))
    missing = []
    for rel, needle in REQUIRED:
        f = root / rel
        if not f.exists() or needle not in f.read_text(encoding="utf-8"):
            missing.append((rel, needle))
    return violations, missing


def main(argv):
    root = Path(argv[1]) if len(argv) > 1 else Path(__file__).resolve().parents[3]
    violations, missing = scan(root)
    for f, n, bid, text in violations:
        print(f"ERROR [{bid}] {f}:{n}  {text}")
    for rel, needle in missing:
        print(f"ERROR [missing-contract] {rel} no longer says {needle!r}")
    if violations or missing:
        print(f"\n{len(violations)} contradiction(s), {len(missing)} missing contract line(s).")
        return 1
    print("kit contract clean: logo, brand styling and product references stay separate.")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))

"""Fixture tests for fact_preflight.py, on the real Day 6 plan of the demo product.

Run: python3 test_fact_preflight.py
"""
import copy
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from fact_preflight import claims, facts_from, preflight  # noqa: E402

HERE = Path(__file__).parent / "fixtures"
FAILURES = []


def check(name, cond, detail=""):
    print(("  PASS  " if cond else "  FAIL  ") + name + ("" if cond else "  " + str(detail)[:300]))
    if not cond:
        FAILURES.append(name)


plan = json.loads((HERE / "fondue-plan-2026-09-07.json").read_text(encoding="utf-8"))
spec = (HERE / "fondue-reference-spec.md").read_text(encoding="utf-8")
brief = (HERE / "fondue-brief-excerpt.md").read_text(encoding="utf-8")
competitors = (HERE / "fondue-competitors-excerpt.md").read_text(encoding="utf-8")
listing = (HERE / "fondue-listing-excerpt.md").read_text(encoding="utf-8")
sources = spec + "\n" + brief + "\n" + listing

print("fact preflight")

# 1. The extractor reads the shapes that matter.
got = {(v, u) for v, u, _ in claims("It stands 18 inches tall on an 8.5-inch base and weighs 4.9 pounds.")}
check("18 inches / 8.5-inch / 4.9 pounds are read", {("18", "in"), ("8.5", "in"), ("4.9", "lb")} <= got, got)
got = {(v, u) for v, u, _ in claims("Size: 8 x 8 x 18 inches")}
check("a dimension chain gives every number the unit", {("8", "in"), ("18", "in")} <= got, got)
got = {(v, u) for v, u, _ in claims("Four tiers, eighteen inches tall")}
check("number words are read", {("4", "tier"), ("18", "in")} <= got, got)
got = {(v, u) for v, u, _ in claims("32-Ounce Bowl and 60% cocoa")}
check("32-Ounce and 60% are read", {("32", "oz"), ("60", "pct")} <= got, got)
got = {(v, u) for v, u, _ in claims("The base is 8 INCHES wide, never 8.5")}
check("a negated clause is not a claim, the positive half beside it still is",
      ("8", "in") in got and ("8.5", "in") not in got, got)
check("the reference spec yields 8 in, 18 in, 4.9 lb, 32 oz, 120 v, 60 hz",
      {("8", "in"), ("18", "in"), ("4.9", "lb"), ("32", "oz"), ("120", "v"), ("60", "hz")} <= facts_from(spec), facts_from(spec))

# 2. THE REAL FAILURE: the plan's product block still says 8.5-inch base. Preflight FAILS and names the competitor.
ok, bad = preflight(plan, sources, competitors)
bad_85 = [b for b in bad if b[1] == "8.5 in"]
check("8.5 in is flagged", bool(bad_85), bad)
check("8.5 in is traced to the product block (description and bullet)",
      {b[0] for b in bad_85} >= {"product.description", "product.bullet 1"}, {b[0] for b in bad_85})
check("the finding says it also appears in the competitor research", all("COMPETITOR" in b[3] for b in bad_85), bad_85)
check("8 in wide (slot 3 header) is sourced, not flagged",
      any(o[0] == "slot 3 headerPhrases" and o[1] == "8 in" for o in ok) and not any(b[1] == "8 in" for b in bad), (ok, bad))
check("18 in, 32 oz, 4.9 lb, 60 pct are sourced", {"18 in", "32 oz", "4.9 lb", "60 pct"} <= {o[1] for o in ok}, {o[1] for o in ok})

# 3. Every other unsourced number is a real finding too: "(4 cups)" has no source anywhere (32 oz is
#    the sourced figure). "three-quarter view" is NOT a claim. The corrected plan passes once 8.5 is
#    fixed and the cups removed.
check("the unsourced 4 cups is reported as well, and nothing else is", {b[1] for b in bad} == {"8.5 in", "4 cup"}, bad)
fixed = copy.deepcopy(plan)
prod = fixed["projectSetup"]["product"]
prod["description"] = prod["description"].replace("8.5-inch", "8-inch").replace(" (4 cups)", "")
prod["bulletPoints"][0] = prod["bulletPoints"][0].replace("8.5-inch", "8-inch")
ok2, bad2 = preflight(fixed, sources, competitors)
check("the corrected plan is CLEAN once every number is sourced or removed", not bad2, bad2)

# 4. Without the competitor file the flag survives, only the attribution changes.
ok3, bad3 = preflight(plan, sources, "")
check("no competitor file: 8.5 still flagged as unsourced", any(b[1] == "8.5 in" and "not in any" in b[3] for b in bad3), bad3)

# 5. A number that only a competitor says is never made lawful by the competitor file.
plan_rival = copy.deepcopy(fixed)
plan_rival["plan"]["slots"][2]["headerPhrases"].append("8.5 in base")
ok4, bad4 = preflight(plan_rival, sources, competitors)
check("competitor research never sources a claim", any(b[1] == "8.5 in" for b in bad4), bad4)

print()
if FAILURES:
    print(f"{len(FAILURES)} failing: {FAILURES}")
    sys.exit(1)
print("all fact_preflight fixtures pass")

# Reference sheet excerpt (fixture): the Product spec table of the fondue fountain, 7 September 2026

## Product spec

| Field | Value | Source |
|---|---|---|
| Size / dimensions | 8 x 8 x 18 inches | listing product information table |
| Weight | 4.9 pounds | listing product information table |
| **Countable parts** | **1 crown cup + 3 dome tier bowls + 2 columns + 1 helical auger + 1 base housing with integral catch bowl + 2 metal collar sleeves + 2 small black rings** | photos/review-photo-parts-laid-out-table.jpg (clean laid-out shot) cross-checked against photos/review-photo-bare-unit-front-counter.jpg (assembled) |
| **"4 Tier" resolves to** | **crown cup + EXACTLY 3 domes. NEVER 4 domes.** | owner ruling 2026-09-03, independently confirmed on two photos (bare assembled + parts laid out) |
| Materials per part | base housing: brushed stainless steel. Catch bowl: brushed stainless steel, mirror interior. Tier bowls, columns, crown cup: smoked translucent grey plastic. Auger: black rigid plastic. Foot skirt: black plastic | photos/review-photo-bare-unit-front-counter.jpg + photos/review-photo-parts-laid-out-table.jpg |
| Label text on the product | embossed wordmark `NOSTALGIA` with a small TM, on the front of the steel housing. Control panel: `OFF` printed above the rockers, `HEAT` to their left, `MOTOR` to their right | photos/review-photo-parts-laid-out-table.jpg (wordmark), photos/_crops/crop-bare-base-panel.png (panel) |
| Certification physically on the product | a rating label low on the housing carrying an **ETL / Intertek** mark. Physically present and verified visually; **its printed text is NOT legible**, so nothing from it may be quoted | photos/_crops/crop-etl-label.png |
| Colors | brushed silver steel; smoked translucent grey plastic; black switch panel with two red indicators; black foot skirt | both bare-unit sources |
| Power / voltage | 120 V / 60 Hz | listing bullet 1 |
| Capacity | 32 ounce bowl | listing title and bullets |
| **Max heating temperature** | **unknown** | not sourced. The model is free to invent it, so no asset may print one |
| **Chocolate quantity for a full curtain** | **unknown, and the evidence conflicts** | listing says a 32 oz bowl; one 185-helpful review says ~4 lb; another says ~2.5 lb overflows. No asset may print a figure |
| Back of housing | **unknown** | no back photo exists |
| Side profiles | **unknown** | no side photos exist |

Anything marked `unknown` is something the model is free to invent. That is the risk these lines record.


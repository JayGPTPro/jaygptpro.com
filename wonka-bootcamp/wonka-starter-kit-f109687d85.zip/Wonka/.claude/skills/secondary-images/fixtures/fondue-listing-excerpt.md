# Own listing excerpt (fixture): the owner's live Amazon copy, 7 September 2026

Product information table: Product Dimensions 8 x 8 x 18 inches; Item Weight 4.9 pounds; Capacity 32 Ounces.
Bullet 1: 120 volts / 60 Hz. Four tiers, 18 inches tall.
Bullet 3: Use chocolate around 60% cocoa; Belgian chocolate needs no added oil.
Bullet 5: Comes apart into four parts (Bowl, Auger, Tower, Base) for hand washing.

# Competitor research excerpt (fixture)

| # | Frame | Headline | Note |
|---|---|---|---|
| 2 | Spec + dimension frame. "4-TIER FONDUE FOUNTAIN", 18" x 8.5" callouts, "great for any occasion", "simple to use / quick disassembly for easy cleaning" | Headline yes, sub-copy no | The only frame carrying a hard fact |

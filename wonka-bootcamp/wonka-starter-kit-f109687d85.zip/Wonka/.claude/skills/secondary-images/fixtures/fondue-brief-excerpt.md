# Creative brief excerpt (fixture, fondue fountain, 7 September 2026)

## Set structure
| Slot | Job | Message (max 6 words) | People |
|---|---|---|---|
| MAIN | product hero | briefed here, chosen on Day 5 from Genrupt candidates, zero overlay text | NO. Never. |
| S1 | Benefit hero: the dip moment | "Anything and everything, dipped" | yes |
| S2 | Scale and dimensions | "Four tiers. Eighteen inches tall." | no |
| S3 | How-to: the state the chocolate must be in | "Melt it first, then pour" | no |
| S4 | How-to: where the chocolate goes and how deep | "Fill the base bowl" | no |
| S5 | Objection-buster: uneven flow | "Level it with the front legs" | no |
| S6 | Lifestyle emotional | "The star of the snack table" | yes |
| S7 | Benefit: savoury versatility | "Cheese, queso, ranch, barbecue sauce" | no |
| S8 | Material proof: what comes apart | "Lifts apart into washable parts" | no |
Gallery order is the priority order above. S1 leads because the operator's known winner is the dip
moment and because it is the frame that sets an honest expectation of the cascade. S3 and S4 sit
together on purpose: they are the two halves of one setup decision the buyer asks about as a single
question, and splitting them across the gallery would break the sequence.


### Funnel B blocks (saved OVER Genrupt's planned text, in priority order)
- Slot for S1 (imageType from the returned plan):
  - buyerQuestion: "What does it actually look like when it is running?"
  - headerPhrases: ["Anything and everything, dipped"]
- Slot for S2:
  - buyerQuestion: "How big is it really, and is the fourth tier worth the extra money?"
  - headerPhrases: ["Four tiers. Eighteen inches tall.", "18 in tall", "8 in wide"]
- Slot for S3:
  - buyerQuestion: "Can I pour chocolate chips straight in?"
  - headerPhrases: ["Melt it first, then pour"]
- Slot for S4:
  - buyerQuestion: "How much chocolate do I need, and where does it go?"
  - headerPhrases: ["Fill the base bowl"]
- Slot for S5:
  - buyerQuestion: "Why would it run down one side instead of all the way round?"
  - headerPhrases: ["Level it with the front legs"]
- Slot for S6:
  - buyerQuestion: "What will my party actually look like with this on the table?"
  - headerPhrases: ["The star of the snack table"]
- Slot for S7:
  - buyerQuestion: "Can I use it for anything besides chocolate?"
  - headerPhrases: ["Cheese, queso, ranch, barbecue sauce"]
- Slot for S8:
  - buyerQuestion: "What comes apart when it is time to wash it?"
  - headerPhrases: ["Lifts apart into washable parts"]

"""Fixture tests for plan_parity.py, on the real Day 6 brief and plan of the demo product.

Run: python3 test_plan_parity.py
"""
import copy
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from plan_parity import read_brief, read_plan, audit  # noqa: E402

HERE = Path(__file__).parent / "fixtures"
FAILURES = []


def check(name, cond, detail=""):
    print(("  PASS  " if cond else "  FAIL  ") + name + ("" if cond else "  " + str(detail)[:300]))
    if not cond:
        FAILURES.append(name)


brief = read_brief((HERE / "fondue-brief-excerpt.md").read_text(encoding="utf-8"))
plan_obj = json.loads((HERE / "fondue-plan-2026-09-07.json").read_text(encoding="utf-8"))

print("plan parity")

# 1. The brief is read: eight secondary slots, S4 carries its Funnel B text.
check("brief has 8 secondary slots", len(brief) == 8, [s for s, _ in brief])
s4 = dict(brief)["S4"]
check("S4 read with its buyer question and header",
      "where does it go" in s4["buyerQuestion"] and s4["headers"] == ["Fill the base bowl"], s4)

# 2. The repaired plan (7 September, after the Day 6 close) is at parity: 8 to 8, nothing missing.
rows, problems = audit(brief, read_plan(plan_obj))
check("repaired plan is at parity", not problems, problems)
check("crosswalk names one local file per brief slot, sec-01 to sec-08 (no truncation at sec-07)",
      [r[5] for r in rows] == [f"sec-0{i}.png" for i in range(1, 9)], [r[5] for r in rows])

# 3. THE REAL FAILURE: plan slot 5 loses S4's job and becomes an installation twin of S3.
broken = copy.deepcopy(plan_obj)
slot5 = [s for s in broken["plan"]["slots"] if s["slotNumber"] == 5][0]
slot5["buyerQuestion"] = "How do I set it up the first time?"
slot5["headerPhrases"] = ["Melt it fully, then pour", "heater first", "then the motor"]
slot5["contentBrief"] = "The whole assembled machine, showing the order of operations."
rows, problems = audit(brief, read_plan(broken))
check("S4 dropped from the plan -> FAIL before the blast", bool(problems), problems)
check("the failure names S4 as the missing job", any(p.startswith("S4") for p in problems), problems)
missing_row = [r for r in rows if r[0] == "S4"][0]
check("the crosswalk row for S4 reads NO PLAN SLOT", missing_row[2] == "NO PLAN SLOT" and missing_row[6] == "MISSING", missing_row)
check("a plan slot is reported as repeating S3's job (the melt twin)",
      any("repeats S3" in p for p in problems), problems)

# 4. A generation-blocked slot fails even when its text is right.
blocked = copy.deepcopy(plan_obj)
[s for s in blocked["plan"]["slots"] if s["slotNumber"] == 7][0]["generationBlocked"] = True
rows, problems = audit(brief, read_plan(blocked))
check("a generationBlocked slot fails parity", any("generationBlocked" in p for p in problems), problems)

# 5. A silently dropped slot (7 in the plan, 8 in the brief) fails on the count and names the job.
short = copy.deepcopy(plan_obj)
short["plan"]["slots"] = [s for s in short["plan"]["slots"] if s["slotNumber"] != 9]
rows, problems = audit(brief, read_plan(short))
check("a plan one slot short fails and names S8", any(p.startswith("S8") for p in problems)
      and any("carries 8 secondary slots and the plan 7" in p for p in problems), problems)

# 6. An extra plan slot nobody approved is reported.
extra = copy.deepcopy(plan_obj)
extra["plan"]["slots"].append({"slotNumber": 10, "slotType": "COMPARISON", "imageType": "COMPARISON",
                               "generationBlocked": False, "buyerQuestion": "Why is this better than the cheap ones?",
                               "headerPhrases": ["Beats the budget fountains"], "customInstructions": {"text": None}})
rows, problems = audit(brief, read_plan(extra))
check("an unapproved extra slot is reported", any("never approved" in p for p in problems), problems)

# 7. The main slot is never part of the audit.
check("slot 1 (main) is excluded from the plan side", all(s["slotNumber"] != 1 for s in read_plan(plan_obj)))

print()
if FAILURES:
    print(f"{len(FAILURES)} failing: {FAILURES}")
    sys.exit(1)
print("all plan_parity fixtures pass")

#!/usr/bin/env python3
"""Fact-provenance preflight for a saved Genrupt listing plan.

Why this exists (measured 7 September 2026, the bootcamp demo product): the dimensions frame
came out of the machine printing `8.5" BASE`. The listing's own product table, the reference
sheet, the selling points and the approved brief all said 8 inches. The 8.5 had two sources,
neither of them ours: a competitor's dimension frame in the research, and a re-scraped
product description inside the saved plan. Nothing in the pipeline compared a number that was
about to be rendered against the evidence we hold for OUR product.

This preflight pulls every numeric claim out of the plan text that can reach an image (the
product block, every slot's header phrases, brief, buyer question and custom instructions),
normalises value and unit, and checks each one against the authoritative sources on disk.
A claim with no source FAILS the slot that carries it. If the same number appears in the
competitor research, the report says so, because that is where it usually came from, and
competitor research is never evidence about our product.

Usage:
  python3 fact_preflight.py plan.json --sources 2-reference/reference-sheet.md brief/creative-brief.md
                             [research/selling-points.md ...] [--competitors research/competitors.md]
                             [--out brief/fact-preflight-YYYY-MM-DD.md]

Exit 0 = every rendered number is sourced, 1 = at least one unsourced claim, 2 = bad input.
Standard library only.
"""
import json
import re
import sys
from pathlib import Path

WORDS = {"one": 1, "two": 2, "three": 3, "four": 4, "five": 5, "six": 6, "seven": 7, "eight": 8,
         "nine": 9, "ten": 10, "eleven": 11, "twelve": 12, "fifteen": 15, "sixteen": 16,
         "eighteen": 18, "twenty": 20, "thirty": 30, "forty": 40, "fifty": 50, "sixty": 60,
         "hundred": 100}
UNITS = [  # (regex, canonical). Longest alternatives first so "inches" is not read as "in".
    (r"inch(?:es)?|in\b|\"|”|''", "in"),
    (r"feet|foot|ft\b", "ft"),
    (r"centimet(?:er|re)s?|cm\b", "cm"),
    (r"millimet(?:er|re)s?|mm\b", "mm"),
    (r"ounces?|oz\b", "oz"),
    (r"pounds?|lbs?\b", "lb"),
    (r"kilograms?|kg\b", "kg"),
    (r"grams?|\bg\b", "g"),
    (r"millilit(?:er|re)s?|ml\b", "ml"),
    (r"lit(?:er|re)s?|\bl\b", "l"),
    (r"gallons?|gal\b", "gal"),
    (r"cups?", "cup"),
    (r"quarts?|qt\b", "qt"),
    (r"tiers?", "tier"),
    (r"parts?|pieces?|pcs?\b", "part"),
    (r"volts?|v\b", "v"),
    (r"watts?|w\b", "w"),
    (r"hz\b|hertz", "hz"),
    (r"%|percent", "pct"),
    (r"hours?|hrs?\b", "hour"),
    (r"minutes?|mins?\b", "min"),
    (r"years?|yrs?\b", "year"),
    (r"days?", "day"),
    (r"servings?", "serving"),
    (r"guests?|people", "guest"),
]
# the trailing guard keeps "three-quarter view" from reading as 3 quarts and "in" inside "inset" as inches
UNIT_RE = "(?:" + "|".join(f"(?:{u})" for u, _ in UNITS) + ")(?![A-Za-z])"
NUM = r"(\d+(?:[.,]\d+)?)"
# "8 x 8 x 18 inches": every number in a dimension chain takes the trailing unit
DIM_RE = re.compile(rf"{NUM}(?:\s*[x×]\s*{NUM})+\s*[- ]?({UNIT_RE})", re.I)
CLAIM_RE = re.compile(rf"(?<![\w.]){NUM}\s*[- ]?({UNIT_RE})", re.I)
WORD_RE = re.compile(r"\b(" + "|".join(WORDS) + r")[- ]+(" + UNIT_RE + r")", re.I)
NEGATED = re.compile(r"\b(never|not|no|without|nor)\b", re.I)


def canon_unit(u):
    for rx, c in UNITS:
        if re.fullmatch(rx, u, re.I):
            return c
    return u.lower()


def canon_val(v):
    v = str(v).replace(",", ".")
    try:
        f = float(v)
    except ValueError:
        return v
    return str(int(f)) if f.is_integer() else str(f)


def clauses(text):
    """Split into clauses so 'never 8.5' does not neutralise '8 INCHES wide' beside it."""
    # a full stop between two digits is a decimal point, never a sentence boundary
    return [c for c in re.split(r"(?<!\d)\.|\.(?!\d)|[;:\n]|,\s*(?=(?:never|not|no)\b)", text or "") if c.strip()]


def claims(text, keep_negated=False):
    """Yield (value, unit, clause) for every numeric claim in text."""
    for clause in clauses(text):
        if not keep_negated and NEGATED.search(clause):
            continue
        for m in DIM_RE.finditer(clause):
            unit = canon_unit(m.group(m.lastindex))
            for v in re.findall(NUM, m.group(0)):
                yield canon_val(v), unit, clause.strip()
        seen_dim = {mm.span() for mm in DIM_RE.finditer(clause)}
        for m in CLAIM_RE.finditer(clause):
            if any(a <= m.start() < b for a, b in seen_dim):
                continue
            yield canon_val(m.group(1)), canon_unit(m.group(2)), clause.strip()
        for m in WORD_RE.finditer(clause):
            yield str(WORDS[m.group(1).lower()]), canon_unit(m.group(2)), clause.strip()


def facts_from(text):
    """Every (value, unit) a source states, negated clauses included: a source that says
    'never 4 domes' still tells us the number 4 is a known quantity in this product's story,
    and the strict reading (only positive statements count) is left to the reviewer's eye."""
    return {(v, u) for v, u, _ in claims(text, keep_negated=True)}


def plan_fields(obj):
    """(where, text) pairs for every plan field that can reach an image."""
    root = obj.get("plan", obj)
    setup = obj.get("projectSetup") or root.get("projectSetup") or {}
    prod = setup.get("product") or {}
    for k in ("title", "description"):
        if prod.get(k):
            yield f"product.{k}", prod[k]
    for i, b in enumerate(prod.get("bulletPoints") or [], 1):
        yield f"product.bullet {i}", b
    for s in root.get("slots") or root.get("slotAssignments") or []:
        n = s.get("slotNumber")
        if s.get("protectedMainImage") or s.get("imageType") == "MAIN_IMAGE":
            continue
        for h in s.get("headerPhrases") or []:
            yield f"slot {n} headerPhrases", h
        for k in ("buyerQuestion", "contentBrief"):
            if s.get(k):
                yield f"slot {n} {k}", s[k]
        ci = s.get("customInstructions") or {}
        if isinstance(ci, dict) and ci.get("text"):
            yield f"slot {n} customInstructions", ci["text"]


def preflight(plan, sources, competitors=""):
    known = facts_from(sources)
    rival = facts_from(competitors) if competitors else set()
    ok, bad = [], []
    for where, text in plan_fields(plan):
        for v, u, clause in claims(text):
            key = (v, u)
            row = (where, f"{v} {u}", clause[:110])
            if key in known:
                ok.append(row)
            else:
                note = "ALSO IN COMPETITOR RESEARCH: the likely source, and never evidence about our product" if key in rival else "not in any authoritative source"
                bad.append(row + (note,))
    return ok, bad


def render(ok, bad, plan_path, source_paths):
    verdict = "CLEAN" if not bad else "FAIL"
    out = [f"# Fact preflight . {verdict}", "",
           f"Plan: `{plan_path}`  Sources: " + ", ".join(f"`{p}`" for p in source_paths), "",
           f"{len(ok)} sourced claim(s), {len(bad)} unsourced claim(s).", ""]
    if bad:
        out += ["## Unsourced claims (each one stops its slot until it is sourced, corrected, or removed from the plan)", "",
                "| Where | Claim | Clause | Finding |", "|---|---|---|---|"]
        out += ["| " + " | ".join(r) + " |" for r in bad]
        out.append("")
    if ok:
        out += ["## Sourced claims", "", "| Where | Claim | Clause |", "|---|---|---|"]
        out += ["| " + " | ".join(r) + " |" for r in ok]
    return "\n".join(out) + "\n"


def main(argv):
    if len(argv) < 2 or "--sources" not in argv:
        print(__doc__)
        return 2
    plan_path = argv[1]
    src, comp, out_path = [], None, None
    mode = None
    for a in argv[2:]:
        if a in ("--sources", "--competitors", "--out"):
            mode = a
            continue
        if mode == "--sources":
            src.append(a)
        elif mode == "--competitors":
            comp = a
        elif mode == "--out":
            out_path = a
    try:
        plan = json.loads(Path(plan_path).read_text(encoding="utf-8"))
        sources = "\n".join(Path(p).read_text(encoding="utf-8") for p in src)
        competitors = Path(comp).read_text(encoding="utf-8") if comp else ""
    except (OSError, ValueError) as e:
        print(f"could not read an input: {e}")
        return 2
    if not src:
        print("at least one --sources file is required (the reference sheet at minimum)")
        return 2
    ok, bad = preflight(plan, sources, competitors)
    report = render(ok, bad, plan_path, src)
    if out_path:
        Path(out_path).write_text(report, encoding="utf-8")
    print(report)
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))

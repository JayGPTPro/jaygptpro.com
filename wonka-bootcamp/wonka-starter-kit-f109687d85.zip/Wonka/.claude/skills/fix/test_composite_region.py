"""composite_region.py: only the boxes change, every other pixel is the base's own.
Run: python3 test_composite_region.py"""
import subprocess, sys, tempfile
from pathlib import Path
import numpy as np
from PIL import Image
HERE = Path(__file__).parent
fails = []
def check(name, cond): print(("  PASS  " if cond else "  FAIL  ") + name); fails.append(name) if not cond else None
with tempfile.TemporaryDirectory() as d:
    d = Path(d)
    base = np.zeros((300, 400, 3), np.uint8); base[:] = (200, 180, 160)
    Image.fromarray(base).save(d / "base.png")
    render = base.copy(); render[:] = (10, 10, 10)            # the endpoint changed the whole frame
    render[100:200, 50:150] = (255, 0, 0)                     # the fix we want is inside this region
    Image.fromarray(render).resize((320, 240)).save(d / "render.png")   # and it came back at a different size
    r = subprocess.run([sys.executable, str(HERE / "composite_region.py"), str(d / "base.png"), str(d / "render.png"), str(d / "out.png"), "40,90,120,120", "--feather", "8"], capture_output=True, text=True)
    check("runs and reports 0 pixels changed outside the boxes", r.returncode == 0 and "0 outside" in r.stdout)
    out = np.asarray(Image.open(d / "out.png").convert("RGB"))
    check("outside the box the output equals the base exactly", np.array_equal(out[:, 200:], base[:, 200:]) and np.array_equal(out[:80], base[:80]))
    check("inside the box the render's fix arrived", (out[150, 100] == (255, 0, 0)).all())
    r2 = subprocess.run([sys.executable, str(HERE / "composite_region.py"), str(d / "base.png"), str(d / "render.png"), str(d / "out2.png")], capture_output=True, text=True)
    check("refuses to run without a box", r2.returncode != 0)
print("composite_region:", "FAIL" if fails else "PASS", f"({len(fails)} failures)")
sys.exit(1 if fails else 0)

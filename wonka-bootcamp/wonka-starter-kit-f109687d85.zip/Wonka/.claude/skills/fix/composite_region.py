#!/usr/bin/env python3
"""Keep everything outside the fix byte-identical.

The OpenAI edit endpoint re-renders the WHOLE frame, so a local fix (a part moved, a marking
restored, an object reshaped) comes back with the rest of the picture slightly different: text
re-typeset, the other product resized, the framing drifted. Measured on the Day 6 secondary set,
7 September 2026: a tower re-centred on the left machine came back with both machines smaller
and the jug reshaped, and the whole edit was rejected for the drift.

This tool takes the changed REGION from the render and pastes it back onto the edit base, with a
feathered edge, so only the region changes and every other pixel is the base's own:

  python3 .claude/skills/fix/composite_region.py <base.png> <render.png> <out.png> x,y,w,h [x,y,w,h ...] [--feather 24]

Boxes are in the base's pixels. The render is resized to the base's size first (the endpoint
returns its own working size). Prints how many pixels changed outside the boxes (should be 0)
and inside them, so the log carries a number instead of an impression. The eye still verifies
the seam and the region afterwards (fix skill step 9): a paste edge must never cross the object.
"""
import sys
import numpy as np
from PIL import Image, ImageFilter

def main():
    argv = sys.argv[1:]; feather = 24
    if "--feather" in argv:
        i = argv.index("--feather"); feather = int(argv[i + 1]); del argv[i:i + 2]
    args = argv
    if len(args) < 4: sys.exit(__doc__)
    base_p, render_p, out_p, *boxes = args
    base = Image.open(base_p).convert("RGB"); render = Image.open(render_p).convert("RGB")
    if render.size != base.size: render = render.resize(base.size, Image.LANCZOS)
    mask = Image.new("L", base.size, 0)
    from PIL import ImageDraw
    d = ImageDraw.Draw(mask)
    for b in boxes:
        x, y, w, h = [int(v) for v in b.split(",")]
        d.rectangle([x + feather // 2, y + feather // 2, x + w - feather // 2, y + h - feather // 2], fill=255)
    if feather: mask = mask.filter(ImageFilter.GaussianBlur(feather / 2))
    out = Image.composite(render, base, mask)
    out.save(out_p)
    a, o, m = np.asarray(base, dtype=int), np.asarray(out, dtype=int), np.asarray(mask)
    changed = (np.abs(a - o).sum(2) > 0)
    outside = int(changed[m == 0].sum()); inside = int(changed[m > 0].sum())
    print(f"wrote {out_p}: {inside} pixels changed inside the region, {outside} outside (must be 0)")
    if outside: sys.exit("composite touched pixels outside the boxes; check the boxes and the feather")

if __name__ == "__main__":
    main()

# Reading a Tasting Card

**A hundred synthetic tasters leaning a handful of votes is not a fact about the world. It is a
nudge.** Here is how to read one like an adult.

## The three tiers

| Tier | What it means | What it licenses |
|---|---|---|
| **Clear lead** | The panel agreed on a direction AND purchase intent separates them by at least +0.25 of 5 | Act on it |
| **Lean** | Ahead but not by enough, OR stable with a difference too small to act on ("Consistent, not decisive") | A hint. Hold it loosely |
| **Toss-up** | Nothing separated them | **A real answer:** that decision does not matter. Spend the attention elsewhere |

Two more honesty rules the card enforces on itself: if the two base models disagree on the winner,
there is NO verdict, whatever the counts say; and everything is counted in VOTES, never percentages,
because a forced choice between images cannot produce a market share.

And a main race carries TWO gaps, so read both: the gap over the live incumbent, and the gap among
your own candidates. A card can be confident every one of yours beats live while unable to separate
your four from each other. That is a real result, not a failed test: the question that matters (do
we beat live) got its answer, and more rounds to split your own tie buy nothing.

## The part worth more than the score

Every taster says WHY, in their own words, unprompted. A result tells you candidate three won. The
objections tell you eleven tasters could not tell how big it is, four thought it was plastic, and
two assumed it needs assembly. **Those are the questions your listing is failing to answer, handed
to you in a list, before you spent a cent on advertising.**

**Decompose a compound objection before acting on it.** "Cannot judge tip quality or durability" is
two objections wearing one label: a picture can prove fineness, no picture may promise durability.
A fix that answers only the provable half can leave the mention count climbing, and saying which
half no image can answer is the honest finding, not another round.

The score decides what to ship on Day 10. The objections decide what to build next.

## Racing twice

Never re-race unchanged images. The panel is seeded, so the same images replay the same verdict, at
full price. A second round is lawful only when something actually changed, and keeping everything
else identical is what makes any movement attributable to the frames that changed.

## What a card never is

Proof. The panel is synthetic, matched to your buyer demographics, and DIRECTIONAL. For a
big-money decision, a real-shopper poll is the gold standard, and an A/B on Amazon itself outranks
everything.

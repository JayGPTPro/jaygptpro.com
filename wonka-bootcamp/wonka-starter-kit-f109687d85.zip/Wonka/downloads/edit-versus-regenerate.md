# Edit versus Regenerate

**The routing that saves you the most money.** Two commands, two different jobs: `/inspect` judges
and fixes what it verified; `/fix` changes and verifies. Both fix the picture you chose. Neither
goes looking for a different picture to save the cents.

## The rule in one line

**Fix the chosen image first. Regenerate from it second. Never swap it for another.**

## Edit (cents, on your OpenAI key)

When the change is **local and definable**: remove a stray element, shorten a label, swap a word,
swap a colour, move a part back where the real product has it (a column off its axis, a tier not
centred), restore a marking (a logo, the control labels), reshape one object. The image is right
and one region of it is wrong.

Wonka edits with your locked reference sheet attached, then pastes only the fixed region back onto
your picture, so everything outside it stays exactly as it was. The other product in the frame, the
headline, the props: not a pixel moves. He shows you before and after.

Two attempts per defect. If the second one fails too, that defect goes to regeneration.

## Regenerate (credits, back in the image's own room)

When the change is **broad**: a different person, a different scene, the whole layout, text that has
to grow so much the frame re-flows around it, or a defect that already failed two edits. A
regeneration builds from your chosen picture as the base, with a tighter brief. It is a spend on
the go-ahead list, so it waits for your yes.

## What runs without asking you

Routine edits run on a report: Wonka announces the list with its estimate and runs it. You do not
type `/fix`, write a prompt, or say "go". A defect you name in plain language ("the column is not
centred on the left one") runs the same way. He stops for one yes only when a round crosses a
limit (twelve edits, about three dollars, or a third try at one defect), when a regeneration is
needed, or when you told him to ask first. "Just check" and "do not fix yet" hold everything.

## The two lines to remember

- **"Local: edit it, on your pick, region only. Broad or twice failed: regenerate from your pick."**
- **A+ modules are the one exception**: their fixes route back through the A+ Room (`/aplus`), and
  an A+ edit is not surgical, it re-renders the WHOLE concept as a new version. So all of a
  concept's fixes go in ONE call, every module gets re-read afterwards (an edit can break a module
  nobody named), and rounds cap at two per concept. Its cost is variable and unquotable in advance;
  the balance read before and after is the only truth.

## Where fixes live

`images/` holds the raw generations, write-once, never touched. Every fix round writes a COMPLETE
copy of the current set into `edits/v1/`, then `edits/v2/`, same filenames. The current set is
always the highest round; the copy in `images/` is the version you already rejected. When in doubt,
ask Wonka which folder is current, and he will name it.

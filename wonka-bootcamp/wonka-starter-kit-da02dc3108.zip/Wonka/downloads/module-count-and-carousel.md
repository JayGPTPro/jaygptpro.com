# Module Count, and the Carousel

**One decision before generation: how many modules. The carousel is optional, and it only comes
up if you ask for it.**

## Amazon's limit first, then the generator's

Two different numbers, easy to confuse. Amazon's A+ format sets the ceiling: Basic A+ carries up to
five modules, Premium A+ up to seven. Genrupt generates a fixed choice of counts (Wonka confirms
which ones it accepts on the day). Pick the count your format can carry, never more.

## Leave room for your own module

The reason to generate fewer than your ceiling is a module only YOU can build: a comparison table
against the products you actually compete with, or a Q&A module where your format supports one,
carrying the questions your customers really ask. Genrupt cannot write either, because they carry
information only you have.

Generate the full count, then discover there is no room for the comparison you wanted, and you are
rebuilding. **One question up front prevents it: am I adding a module of my own?**

(At the generator's lowest count its premium carousel and dense layouts are off the table; the
machine downgrades them and says so. That is a tool constraint, not an Amazon rule.)

## The premium carousel, if you want one

A distinct module type in the generator, not a fancier standard module, and it spends one of the
same slots. Wonka mentions it once and never recommends it.

- **It earns its slot** when you have a real sequence: a before and after, steps, a range of
  variants. Something where the ORDER carries meaning.
- **It costs you** when your shopper is skimming. A static module gives everything at once to
  somebody moving fast; a carousel gives them frame one and asks for a click, and on a phone that
  click often does not come.

If you want one, say so with your other answers. Leaving it off needs no reason and no record.

## Record the module count reason

In four months, on your third product, when you cannot remember why this page has six modules and
a comparison chart, that one line is the only thing that explains it.

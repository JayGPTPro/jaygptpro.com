# Day 7: The A+ Room

Below the fold on every listing there is a second product page. Half your competitors left theirs
empty. Today you build yours, and when it is done your product page is complete.

Two lessons, six steps. Lesson 1 generates the concepts, compares the complete pages and ends with
your chosen page on disk, already cut into module files for Amazon. Lesson 2 inspects that choice,
fixes it on the files, and tells you which files to use.

## What you will have by the end of today

- A+ concepts on the modes you chose, with one page chosen per mode
- The chosen page exported as module files, cut to Amazon's sizes, the moment you picked it
- The export inspected and, where something needed it, repaired on those files
- The accepted module files named, in order, per mode

## What you will need at hand

- Your finished gallery from Day 6 and the style you sent to Refine. Today's A+ inherits it
- Your brand kit, if you have one, and your approved claims list. The list is what the copy is
  checked against after generation
- Which A+ format your listing has, Basic or Premium. It decides how many modules the page can carry
- Genrupt connected. Wonka runs it for you today; you never open the app to make a choice

---

## Lesson 1: Generate and choose your A+

### Why this room is hands-off

The A+ is the one asset in this factory Wonka does not brief. The planner is better at multi-module
layout than a prompt box, the A+ is not what gets tested on Day 8, and deciding what NOT to control
is part of running a factory. What you do not give up is the check: lesson 2 judges the result as
hard as anything else.

**How Jay weighs it.** On his own products Jay gives more weight to overall appearance in the A+
than in the gallery: the readers who scroll this far are already leaning in, and a page that looks
like a real brand does much of its work by looking that way. That is his approach, not a law. Keep
your product information accurate, and set your own balance between looks and coverage.

### Step 1. Start the A+ Room

```
/aplus
```

If you have several products, name the one you want to work on. Wonka confirms the inherited pieces
one line each (the locked reference, the Day 6 style, your preset if you have one) and asks for
three settings in one message:

| Setting | What to choose |
|---|---|
| Display modes | Desktop, mobile, or both. Most A+ readers are on a phone |
| Concepts per mode | How many complete page designs you want to compare |
| Modules per page | How many blocks each page should contain |

**Modules and your format.** Premium A+ allows up to seven modules; Basic allows up to five. The
generator offers a fixed choice of counts, and Wonka confirms which ones it accepts today. Leave a
slot when you plan to add a module of your own, such as a comparison chart or a Q&A module your
format supports: the machine cannot write those, and generating the full count first means
rebuilding.

**The premium image carousel** exists as a distinct module type and spends a slot. Wonka mentions
it once and never recommends it. If you want one, say so with your answers.

**There are no design settings.** The look comes from the style you locked on Day 6. Wonka reports
the cost estimate before generating; the final charge can differ from the estimate, and he reports
the actual charge after the run.

### Step 2. Compare the complete pages

Open the numbered concepts larger and scroll each page as a shopper, not as an inspector. Check the
overall appearance, the product, and whether the text reads in each mode you generated. Your gut is
the closest thing in this room to your buyer's.

Want more? A second round repeats the same recipe; Wonka restates your answers in one line and
runs. Its numbers continue from the first round, so a pick is never ambiguous.

### Step 3. Choose your pages

```
I choose desktop concept [number] and mobile concept [number].
```

Pick by the number on Wonka's sheet, never by the number the app shows, and include only the modes
you generated. Wonka reads the pick back with the picture; add a screenshot if the choice is
unclear. If the one you like exists in one mode only, ask him to convert it to the other.

**Wonka exports the chosen page at once, as part of the pick.** The module files land in
`aplus/export/[mode]/`, cut to Amazon's sizes. He lists the folder rather than trusting a success
message: does the count match, is every mode there, is anything zero bytes.

**Lesson 1 is done when** Wonka confirmed your choice and exported the selected pages
automatically: a full-page preview and numbered module files for each mode, no manual slicing.

---

## Lesson 2: Inspect, fix, prepare the upload

**After the export, every fix is on the file.** That is the rule for the rest of the day.

### Step 4. Inspect the exported A+

```
/inspect
```

Confirm that the scope is the selected A+. Wonka checks the exported modules and the assembled page
for product accuracy, wording, readability and continuity between modules, and handles clear
routine fixes himself. Read the findings and look at the affected areas; the scorecard has the
detail. Two things bite harder here than anywhere else:

**Text size.** The headline hierarchy is read at thumbnail size. Body text is judged at the width
it is actually shown at, a desktop column or a phone, because nobody sees an A+ module as a
thumbnail.

**Claims.** The machine wrote this copy. Every claim goes against your approved claims list, after
the fact. It is not the one whose account is on the line.

Look yourself too. Open the modules at full size and check three things: **the product** (is it
mine, every part present, the right material), **the text** (a wrong word, a typo, a claim you
never approved), **the people** (does anyone look drawn rather than photographed).

### Step 5. Request a specific change

Name the mode, the module or section, and the change you want. Attach a marked screenshot when that
is clearer.

```
In [mode and module or section], fix [what is wrong and how it should look]. Keep the rest of the design as close to the current version as possible.
```

Wonka edits the one region on the exported file and composites it back, so the rest of the module
is untouched, and shows you before and after. A face that looks drawn goes to `/fix-faces` on that
module. Review the revised area and the assembled page, including the seam where a module meets its
neighbour: the page is one canvas sliced into strips.

**The default is to fix the design you chose.** The same wrong word in three modules is three local
fixes. Only when you want a different layout or a different direction for the whole page do you pick
another concept or ask for another round. Either way you keep talking to Wonka; you never go into
the app to change something.

### Step 6. Find the files to use

```
Show the final A+ pages and open the folders containing the latest accepted module files.
```

Use the accepted files Wonka identifies, in module order, and check that each mode has the expected
number of files. When a repair ran, that is the fixed round in `edits/vN/aplus/`; when nothing
needed repair, the untouched export is the final set. A fresh Genrupt export never carries local
changes. Check the desktop and mobile preview in Seller Central before you publish.

**Day 7 is done when** you use the accepted files Wonka identifies, in module order, and each
selected mode has the expected number of files.

---

## Checklist

- [ ] The three settings answered in one message, the module count matched to your Basic or
      Premium format
- [ ] One page chosen per mode by Wonka's number, read back, and exported at the pick
- [ ] The export inspected, every fix made on the module files, before and after confirmed
- [ ] The accepted files named in module order, with the right count per mode

Nothing else is owed tonight. Day 8 opens by fetching your live main image and gallery into
`incumbent/` itself, at the first step of `/tasting-room`.

---

## Optional: read the whole page, and close the map

Scroll the finished page top to bottom once, as a stranger would, and ask three questions. Does
the story hold from the hero through the gallery to the A+? Does anything contradict a gallery
frame, such as a claim you removed on Day 6 reappearing here? Does the A+ simply repeat the gallery
in a longer format?

If your coverage map has an A+ column from Day 3, this is where it closes: name anything you
expected here that did not arrive, so it moves to the gallery or is dropped on purpose.

## Common mistakes

- **Generating the full count when you wanted a comparison chart or a Q&A.** One question up front
  prevents a rebuild.
- **Picking by the app's number.** Wonka's sheet is the only numbering that counts.
- **Desktop only.** Most of your A+ readers are on a phone.
- **Switching concepts to dodge a fix.** A wrong word is a local fix, three times if it appears
  three times. A new concept is for a new direction.
- **Uploading a fresh export.** It does not carry your fixes.
- **Trusting the copy.** The claims list is checked after generation, not fed into it.

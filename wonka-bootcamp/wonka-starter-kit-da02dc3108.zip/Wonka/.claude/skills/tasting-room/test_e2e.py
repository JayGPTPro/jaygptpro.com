#!/usr/bin/env python3
"""End to end, offline: a whole sitting of TWO races, with no API calls.

`chat` and `embed_all` are stubbed, so this exercises everything our side owns
(persona build, forced choice, SSR scoring, verdict, both report builders, the
progress states, scope derivation, coverage union and the gate) and nothing
OpenAI owns. Deterministic, free, and runnable as many times as you like,
which is exactly what a real paid run is not.

The stub is deliberately shaped like the case the reporting used to get wrong:
a near-unanimous forced choice sitting on a hair of purchase intent.

Run: python3 test_e2e.py
"""
import hashlib
import json
import random
import re
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

FAILURES = []


def check(name, cond, detail=""):
    print(("  PASS  " if cond else "  FAIL  ") + name + ("  " + str(detail) if not cond and detail else ""))
    if not cond:
        FAILURES.append(name)


def png(path, w=48, h=48, shade=200):
    """A real, decodable PNG so the image encoder is genuinely exercised."""
    import zlib
    import struct
    raw = b"".join(b"\x00" + bytes([shade, shade, shade] * w) for _ in range(h))
    def chunk(t, d):
        c = t + d
        return struct.pack(">I", len(d)) + c + struct.pack(">I", zlib.crc32(c) & 0xFFFFFFFF)
    path.write_bytes(
        b"\x89PNG\r\n\x1a\n"
        + chunk(b"IHDR", struct.pack(">IIBBBBB", w, h, 8, 2, 0, 0, 0))
        + chunk(b"IDAT", zlib.compress(raw))
        + chunk(b"IEND", b"")
    )


# ---------------------------------------------------------------- the stub
_rng = random.Random(7)


_reaction_calls = [0]


def fake_chat(messages, model, max_tokens=220, retries=3, json_mode=False):
    txt = json.dumps(messages)[-4000:]
    if "persona" in txt.lower() and json_mode:
        return json.dumps({"personas": [
            {"id": f"p{i}", "age": 30 + i % 30, "gender": "F" if i % 2 else "M",
             "income": "mid", "shopping": "price aware", "note": "n"} for i in range(40)]})
    # ORDER MATTERS. Until 23 August 2026 the generic json_mode branch sat ABOVE these,
    # so every structured call got the themes object back: zero forced choices ever
    # parsed, the verdict was always Toss-up, and two deliberate breaks (removing the
    # magnitude downgrade, and making the parser always vote position A) both stayed
    # green. Keep the specific shapes first, and keep them keyed on the PROMPT text
    # rather than on a tail slice, because image data pushes the marker out of it.
    joined = " ".join(str(m.get("content", "")) for m in messages if isinstance(m, dict))
    hay = (joined + txt).lower()

    # forced choice: overwhelmingly B, which is the shape that used to be
    # reported as a landslide on a difference of nothing
    if "photo a" in hay or "set a" in hay:
        # DETERMINISTIC per call, not a draw from the shared _rng. The engine
        # asks all 100 tasters concurrently on 32 threads, so the ORDER of
        # draws from one shared Random is timing dependent: the same test run
        # twice produced a top share of 0.65 and then 0.55, and 0.55 is the
        # signature this check exists to fail on. A hash of the prompt gives
        # every taster the same answer every time, whichever thread gets there
        # first, and keeps the 95/5 split the calibration below depends on.
        h = int(hashlib.sha256(hay.encode()).hexdigest()[:8], 16)
        letter = "A" if h % 100 < 5 else "B"
        return json.dumps({"choice": letter, "why": "the size reads better"})

    # within-set: which frame is strongest, which is weakest
    if "most convincing" in hay or "weakest" in hay or "best" in hay and "worst" in hay:
        return json.dumps({"best": "C", "worst": "A"})

    # the cross-image synthesis, which needs all three keys or the caller retries
    if "objections_ranked" in hay or "cross_takeaways" in hay:
        return json.dumps({
            "images": {"image_1": {"takeaway": "size is unclear"}},
            "objections_ranked": [{"objection": "cannot tell the size", "count": 14}],
            "suggested_edits": ["put a hand in frame for scale"],
            "cross_takeaways": ["scale is the recurring doubt"],
        })

    if json_mode:
        # the per-image structured note
        return json.dumps({"impact": "boosts", "reaction": "clean, but I cannot tell the size"})
    # One taster comes back EMPTY. Not an error, just no content: a real
    # provider behaviour (a thinking budget eaten before the answer). It is
    # here because an empty reaction used to reach the embeddings call and
    # kill the whole scoring phase after every paid call was already made.
    _reaction_calls[0] += 1
    if _reaction_calls[0] == 3:
        return ""
    return _rng.choice([
        "Looks clean but I cannot tell how big it is.",
        "Feels premium. I would probably buy it.",
        "Not sure about the material, might be plastic.",
    ])


def fake_embed_all(texts, batch=256):
    # Faithful to the real endpoint: OpenAI's embeddings API rejects empty
    # input with a 400. A stub that quietly embeds "" would hide the exact
    # bug this stub exists to catch.
    for t in texts:
        if not str(t).strip():
            raise ValueError("embeddings API would 400 here: empty input string")
    out = []
    for t in texts:
        h = sum(ord(c) for c in t)
        out.append([((h >> k) % 100) / 100.0 for k in range(8)])
    return out


def visible_text(html):
    """What a human actually reads: tags, style attributes and script stripped.

    Asserting on RENDERED output is the whole point. The earlier guard scanned
    source for a `{...share...}%` pattern and passed while six surfaces rendered
    "95 to 5" with no percent sign anywhere, including one that read "95 of 80".
    """
    h = re.sub(r"<(script|style)[^>]*>.*?</\1>", " ", html, flags=re.S | re.I)
    h = re.sub(r"<[^>]+>", " ", h)
    return re.sub(r"\s+", " ", h)


# Percentages that are legitimately percentages OF something that is not the
# forced choice. Kept short and specific on purpose: this list is the only
# hand-written part of the guard, and a percentage it does not cover FAILS,
# so the test errs toward noise rather than toward silence.
LEGITIMATE_PCT = (
    "resamples",          # bootstrap stability really is a share of resamples
    "parsed",             # parse rate
    "reactions",
    " f ", " f&", "% f",  # panel gender composition
    "of the scale",       # the intent gap expressed against its own range
    "within-set",         # a classification BAND is a rule, not a result:
    "or fewer of",        # "carries: at least 25% of within-set votes" defines
                          # a threshold, it does not report anybody's outcome
)


def pct_leaks(html):
    """A percentage in text a human reads, about the CHOICE metric.

    Bar geometry lives in style attributes and is stripped before we look, so
    anything reaching here is a number somebody reads. The allowlist above
    covers the few percentages that are honestly percentages of something else.
    """
    txt = visible_text(html)
    out = []
    for m in re.finditer(r"\d{1,3}\s?%", txt):
        ctx = txt[max(0, m.start() - 60): m.end() + 40].lower()
        if any(w in ctx for w in LEGITIMATE_PCT):
            continue
        out.append(txt[max(0, m.start() - 30): m.end() + 15].strip())
    return out


def impossible_counts(html, cap=None):
    """"95 to 5 of 80" is a share wearing a count's clothes. Any "N of M" or
    "N to M" where N exceeds the panel size is arithmetic that cannot be true."""
    txt = visible_text(html)
    out = []
    # Thousands separators are real in this document ("662 of 1,000 resamples"),
    # and ignoring them turned a correct line into a fake failure on the first
    # run of this guard.
    for m in re.finditer(r"\b([\d,]{1,7})\s+of\s+([\d,]{1,7})\b", txt):
        ctx = txt[max(0, m.start() - 40): m.end() + 30].lower()
        if "resample" in ctx or "reaction" in ctx:
            continue
        a = int(m.group(1).replace(",", ""))
        b = int(m.group(2).replace(",", ""))
        if a > b:
            out.append(m.group(0))
    return out


def drive(panel, cfg_path):
    """panel.main() is argv driven, so drive it the way run.py does."""
    old = sys.argv
    sys.argv = ["panel.py", str(cfg_path), "lite"]
    try:
        panel.main()
    finally:
        sys.argv = old


def run():
    import os
    # setdefault is not enough: an EMPTY exported key (a half-filled .env) still
    # exists, wins over the default, and fails the preflight with a confusing
    # missing-key refusal inside a fully stubbed test. Overwrite empty too.
    if not os.environ.get("OPENAI_API_KEY"):
        os.environ["OPENAI_API_KEY"] = "sk-test-offline-stub"
    os.environ["PANEL_OPEN_LIVE"] = "0"          # no browser windows in a test
    import panel
    panel.chat = fake_chat
    panel.embed_all = fake_embed_all
    import scope

    tmp = Path(tempfile.mkdtemp())
    try:
        prod = tmp / "factory" / "Products" / "fondue"
        (prod / "images").mkdir(parents=True)
        (prod / "incumbent").mkdir(parents=True)
        (prod / "tests").mkdir(parents=True)
        (prod / "research").mkdir(parents=True)
        for i, n in enumerate(["main-01.png", "main-02.png", "sec-01.png", "sec-02.png"]):
            png(prod / "images" / n, shade=120 + i * 30)
        png(prod / "incumbent" / "main-live.png", shade=90)
        png(prod / "incumbent" / "gal-live-01.png", shade=95)
        png(prod / "incumbent" / "gal-live-02.png", shade=100)
        (prod / "status.md").write_text("- Main pick: main-01 (primary); alternatives: main-02\n")

        print("\n1. Scope is derived from disk, before any config is written")
        s = scope.derive(prod)
        check("main race scope", s["main"] == ["main-01.png", "main-02.png"], s["main"])
        check("gallery scope", s["gallery"] == ["sec-01.png", "sec-02.png"], s["gallery"])
        check("benchmark found", s["incumbent_main"] == ["main-live.png"], s["incumbent_main"])
        scope.cmd_plan(str(prod))

        common = {
            "product": "fondue fountain", "asin": "B09BDGFKXB",
            "product_context": "A 4 tier electric chocolate fondue fountain",
            "niche": "chocolate fondue fountain",
            "demographics": {"notes": "US home entertainers 30-60"},
            "seed": 42,
        }

        print("\n2. Race 1 of 2: the MAIN race")
        d1 = prod / "tests" / "tasting-r1-main"
        d1.mkdir()
        cfg1 = dict(common, round=1, race="main", incumbent_id="current_listing",
                    out_dir=str(d1), images=[
                        {"id": "main_01", "label": "hero on white", "path": str(prod / "images" / "main-01.png")},
                        {"id": "main_02", "label": "hero with tag", "path": str(prod / "images" / "main-02.png")},
                        {"id": "current_listing", "label": "current listing",
                         "path": str(prod / "incumbent" / "main-live.png")}])
        (d1 / "config.json").write_text(json.dumps(cfg1))
        drive(panel, d1 / "config.json")
        res1 = json.loads((d1 / "results.json").read_text())
        check("results.json written", bool(res1.get("verdict")))
        v = res1["verdict"]
        print(f"     tier={v['label']}  intent_gap={v.get('intent_gap')}  "
              f"downgraded={v.get('tier_downgraded_for_magnitude')}")
        check("verdict carries the intent gap", "intent_gap" in v)
        check("a near-unanimous vote on a hair is NOT a Clear lead",
              v["label"] != "Clear lead" or v.get("intent_gap_decisive"),
              f"label={v['label']} gap={v.get('intent_gap')}")

        # The stub votes B in 95% of forced choices, and the engine shuffles which
        # candidate sits at each letter. So an HONEST parser lands one candidate far
        # above chance. A parser that ignores the model's answer and always returns
        # the same position lands everything at chance, which still reads as a
        # Toss-up and still satisfies the check above. Added 23 August 2026 after the
        # break "make the parser always vote position A" stayed green.
        agg1 = res1.get("aggregate") or {}
        shares = sorted((row.get("choice_share") or 0) for row in agg1.values())
        # MEASURED, not guessed, and the margin is narrow on purpose-built numbers:
        # honest parser 0.65, parser hardcoded to one position 0.55, stable across
        # runs because the stub's RNG is seeded. 0.60 is the line between them. The
        # engine shuffles which candidate sits at each letter, which is why a 95%
        # letter preference does not translate into a 95% candidate share, and why
        # this check proves only that the reply is being read at all.
        check("the forced-choice parser actually reads the reply",
              bool(shares) and shares[-1] >= 0.60,
              f"top share={shares[-1] if shares else None}; honest is 0.65, position-locked is 0.55")

        md = (d1 / "tasting-card.md").read_text()
        check("markdown headline is a count", "of " in md and "Chosen by" in md)
        # The Shipping Room verifies the file it packages is the one that raced,
        # and the Fixing Room refines "the winner" by name. Both read this card.
        # A card carrying only ids and labels forces them to guess or to go
        # hunting in config.json, which is exactly how an untested sibling ships.
        check("the card names the raced FILES, not just ids",
              "| File |" in md and "main-01.png" in md and "main-live.png" in md,
              "no File column or filenames missing")
        check("the winner line names its file",
              bool(re.search(r"Winner: \w+ \(`[^`]+\.png`\)", md)),
              [l for l in md.splitlines() if l.startswith("**")][:2])
        check("no % on the choice metric in markdown",
              "Choice share" not in md and "pts of choice share" not in md)

        print("\n3. The progress page does not claim FINISHED yet")
        pj = json.loads((d1 / "progress.json").read_text()) if (d1 / "progress.json").exists() else {}
        check("engine handed off, did not finish", pj.get("finished") is False, pj.get("finished"))
        check("awaiting is set", pj.get("awaiting") is True)

        print("\n4. The card process renders and then closes the run")
        subprocess.check_call([sys.executable, str(HERE / "tasting_card.py"), str(d1 / "results.json")],
                              stdout=subprocess.DEVNULL)
        html = (d1 / "tasting-card.html").read_text()
        check("card rendered", len(html) > 20000, len(html))
        pj = json.loads((d1 / "progress.json").read_text())
        check("now FINISHED, closed by the other process", pj.get("finished") is True)
        check("no bare percentage rendered as a headline number",
              not pct_leaks(html), pct_leaks(html)[:5])
        # The verdict the ENGINE recorded must be the verdict the card shows.
        # The card used to recompute the tier from bootstrap alone and re-promote
        # a downgraded run, so the markdown said Lean and the HTML said Clear
        # lead. The HTML is the file the owner opens.
        check("card tier matches the engine verdict, not a recomputation",
              v["label"].upper() in html.upper(),
              f"engine said {v['label']}")
        if v.get("tier_downgraded_for_magnitude"):
            check("the downgrade reason reaches the HTML card",
                  "not decisive" in html.lower() or "intent" in html.lower())
        check("no impossible count (more votes than panelists)",
              not impossible_counts(html), impossible_counts(html)[:3])

        scope.cmd_record(str(prod), str(d1))
        print("\n5. The gate BLOCKS on a half-finished sitting")
        check("blocked with only the main race in", scope.cmd_check(str(prod)) == 1)

        print("\n6. Race 2 of 2: the GALLERY race")
        d2 = prod / "tests" / "tasting-r1-gallery"
        d2.mkdir()
        cfg2 = dict(common, round=1, race="gallery", incumbent_id="live_set",
                    out_dir=str(d2), images=[
                        {"id": "our_set", "label": "our gallery",
                         "paths": [str(prod / "images" / "sec-01.png"), str(prod / "images" / "sec-02.png")]},
                        {"id": "live_set", "label": "live gallery",
                         "paths": [str(prod / "incumbent" / "gal-live-01.png"),
                                   str(prod / "incumbent" / "gal-live-02.png")]}])
        (d2 / "config.json").write_text(json.dumps(cfg2))
        drive(panel, d2 / "config.json")
        check("gallery results written", (d2 / "results.json").exists())
        subprocess.check_call([sys.executable, str(HERE / "tasting_card.py"), str(d2 / "results.json")],
                              stdout=subprocess.DEVNULL)
        html2 = (d2 / "tasting-card.html").read_text()
        check("gallery card rendered (report builder B)", len(html2) > 20000, len(html2))
        check("report B has no bare percentage headline either",
              not pct_leaks(html2), pct_leaks(html2)[:5])
        check("report B has no impossible count either",
              not impossible_counts(html2), impossible_counts(html2)[:3])

        scope.cmd_record(str(prod), str(d2))
        cov = json.loads((prod / "tests" / "coverage.json").read_text())
        check("coverage holds BOTH races", set(cov["races"]) == {"r1-main", "r1-gallery"}, set(cov["races"]))

        print("\n7. The gate PASSES, and each card names its twin")
        check("gate passes", scope.cmd_check(str(prod)) == 0)
        subprocess.check_call([sys.executable, str(HERE / "tasting_card.py"), str(d1 / "results.json")],
                              stdout=subprocess.DEVNULL)
        html = (d1 / "tasting-card.html").read_text()
        check("the main card names the gallery race", "GALLERY race" in html or "gallery race" in html.lower(),
              "sibling note missing")
        check("and links to it", "tasting-r1-gallery" in html)

        print("\n8. The card names the opponent: the live image, or the benchmark (kit v37)")
        # The live route (no "benchmark" key) keeps its wording byte for byte.
        md = (d1 / "tasting-card.md").read_text()
        check("live route: the incumbent tag reads [CURRENT LISTING]", "[CURRENT LISTING]" in md)
        check("live route: the vs line names the live Amazon image",
              "the live Amazon image" in md and "**Vs current listing (current_listing):**" in md,
              [l for l in md.splitlines() if l.startswith("**Vs")])
        check("live route: the HTML card says YOUR LIVE IMAGE", "YOUR LIVE IMAGE" in html)
        check("live route: no benchmark wording leaks in", "BENCHMARK:" not in md and "the benchmark (" not in html)
        # The pre-launch route: the same incumbent_id slot holds the strongest
        # competitor's file, and the config carries "benchmark": "competitor [name]".
        # The card must say which claim was made: beating a named rival, never
        # beating the owner's own live image (there is none).
        d3 = prod / "tests" / "tasting-r1-main-benchmark"
        d3.mkdir()
        png(prod / "incumbent" / "competitor-main.png", shade=90)
        cfg3 = dict(common, round=1, race="main", incumbent_id="strongest_competitor",
                    benchmark="competitor Wilton", out_dir=str(d3), images=[
                        {"id": "main_01", "label": "hero on white", "path": str(prod / "images" / "main-01.png")},
                        {"id": "main_02", "label": "hero with tag", "path": str(prod / "images" / "main-02.png")},
                        {"id": "strongest_competitor", "label": "strongest competitor",
                         "path": str(prod / "incumbent" / "competitor-main.png")}])
        (d3 / "config.json").write_text(json.dumps(cfg3))
        drive(panel, d3 / "config.json")
        md3 = (d3 / "tasting-card.md").read_text()
        check("benchmark route: the tag reads [BENCHMARK: competitor Wilton]",
              "[BENCHMARK: competitor Wilton]" in md3 and "[CURRENT LISTING]" not in md3,
              [l for l in md3.splitlines() if "strongest_competitor" in l][:2])
        check("benchmark route: the vs line names the benchmark, never the live image",
              ("BEATS the benchmark (competitor Wilton) by" in md3
               or "does NOT beat the benchmark (competitor Wilton). The benchmark held." in md3)
              and "live Amazon image" not in md3,
              [l for l in md3.splitlines() if l.startswith("**Vs")])
        subprocess.check_call([sys.executable, str(HERE / "tasting_card.py"), str(d3 / "results.json")],
                              stdout=subprocess.DEVNULL)
        html3 = (d3 / "tasting-card.html").read_text()
        check("benchmark route: the HTML card names the benchmark",
              "BENCHMARK: COMPETITOR WILTON" in html3 and "the benchmark (competitor Wilton)" in html3)
        check("benchmark route: the HTML card never calls it your live image",
              "YOUR LIVE IMAGE" not in html3 and "your live image" not in html3
              and "live Amazon image" not in html3 and "No live listing was in the race" not in html3)

        print("\n9. Kit v38 (12 September 2026): the room stops after the reports, and says counts plainly")
        import contextlib
        import io
        # (a) an unequal gallery race is described, never bounded. The engine's
        # note names both counts and says what the difference limits; it never
        # says UPPER BOUND and never tells anyone to drop frames.
        png(prod / "images" / "sec-03.png", shade=200)
        png(prod / "incumbent" / "gal-live-03.png", shade=105)
        (prod / "incumbent" / "notes.md").write_text("other model: gal-live-03.png\n")
        cfg4 = dict(common, round=1, race="gallery", incumbent_id="live_set", out_dir=str(prod / "tests" / "x"),
                    images=[{"id": "our_set", "label": "our gallery",
                             "paths": [str(prod / "images" / n) for n in ("sec-01.png", "sec-02.png", "sec-03.png")]},
                            {"id": "live_set", "label": "live gallery",
                             "paths": [str(prod / "incumbent" / n) for n in ("gal-live-01.png", "gal-live-02.png")]}])
        buf = io.StringIO()
        with contextlib.redirect_stdout(buf):
            panel.preflight_config(cfg4)
        note = buf.getvalue()
        check("the unequal-count note states both counts",
              '"our_set" has 3' in note and '"live_set" has 2' in note, note)
        check("the note says what the difference limits, in the house wording",
              "limit what can be attributed to the creative changes" in note, note)
        check("no UPPER BOUND, no parity order, no frame dropping",
              "upper bound" not in note.lower() and "equal counts" not in note.lower()
              and "drop" not in note.lower(), note)
        check("the incumbent/notes.md other-model line is printed with the note",
              "other model: gal-live-03.png" in note, note)
        src_panel = (HERE / "panel.py").read_text()
        src_card = (HERE / "tasting_card.py").read_text()
        check("UPPER BOUND is gone from the engine and the card",
              "upper bound" not in src_panel.lower() and "upper bound" not in src_card.lower())
        # (b) the estimate line prints before the run, and the spend lands in the quality block
        check("the quality block carries spend_usd_estimated (None offline: the stub returns no usage)",
              "spend_usd_estimated" in res1["quality"] and res1["quality"]["spend_usd_estimated"] is None,
              res1["quality"])
        check("and says why when it is not available",
              "usage" in (res1["quality"].get("spend_note") or "").lower(), res1["quality"].get("spend_note"))
        # (c) the card's next command is the read-and-decide line, never a rerun or a /fix
        for name, doc in (("main card", html), ("gallery card", html2)):
            check(f"{name}: the next line is read the objections, then decide",
                  "Read the objections, then tell Wonka which changes to make." in doc, name)
            check(f"{name}: no Round 2 suggestion, no re-run, no /fix command on the card",
                  "Re-run Round" not in doc and "Re-run the duel" not in doc
                  and "ROUND 2" not in doc.upper().replace("ROUND 1", "")
                  and "FIX BEFORE ROUND" not in doc and "Aim for CLEAR LEAD" not in doc
                  and "/fix" not in doc, name)
            check(f"{name}: the synthetic-preference sentence is on the card once",
                  doc.count("Synthetic preference is not real-shopper behaviour or conversion evidence") == 1, name)
        check("the gallery card header prints both frame counts",
              "2-frame set" in html2 and ("against the 2-frame gallery" in html2 or "2-frame gallery" in html2), "")
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


if __name__ == "__main__":
    run()
    print()
    if FAILURES:
        print(f"{len(FAILURES)} FAILED: {', '.join(FAILURES)}")
        sys.exit(1)
    print("END TO END: all green")

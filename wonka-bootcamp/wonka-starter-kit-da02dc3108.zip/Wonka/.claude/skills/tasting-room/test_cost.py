#!/usr/bin/env python3
"""The spend cap: a race is priced BEFORE it runs, and the cap is enforced on
that estimate, never on a running total (a half race is worthless).

Kit v38 (12 September 2026): invoking /tasting-room authorises the standard
sitting, so the cost line stopped being a question and became a gate. The gate
only works if the number under it is deterministic and conservative, and if
the cap actually refuses. Each of these checks was watched failing before the
code existed.

Offline: no client is built, nothing is sent.

Run: python3 test_cost.py
"""
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

FAILURES = []


def check(name, cond, detail=""):
    print(("  PASS  " if cond else "  FAIL  ") + name + ("  " + str(detail) if not cond and detail else ""))
    if not cond:
        FAILURES.append(name)


def main_cfg(n=100, candidates=3):
    return {
        "product_context": "A 4 tier electric chocolate fondue fountain",
        "n_personas": n,
        "images": [{"id": f"c{i}", "path": f"/x/main-{i}.png"} for i in range(candidates)],
        "out_dir": "/x/out",
    }


def gallery_cfg(n=100, ours=7, live=5):
    return {
        "product_context": "A 4 tier electric chocolate fondue fountain",
        "n_personas": n,
        "images": [
            {"id": "ours", "paths": [f"/x/sec-{i}.png" for i in range(ours)]},
            {"id": "live", "paths": [f"/x/live-{i}.png" for i in range(live)]},
        ],
        "incumbent_id": "live",
        "out_dir": "/x/out",
    }


def run():
    from panel import (SPEND_CAP_DEFAULT_USD, PRICES_PER_1K_USD, apply_mode, cap_check,
                       estimate_cost, format_estimate)

    print("1. The estimate is deterministic for a fixture config")
    e1 = estimate_cost(main_cfg())
    e2 = estimate_cost(main_cfg())
    check("same config, same number", e1["usd"] == e2["usd"], (e1["usd"], e2["usd"]))
    # The number itself, so a silent change to the token model or the price
    # table shows up here instead of on a student's card. Measured offline,
    # 12 September 2026, from the constants in panel.py.
    check("main race, 3 candidates, 100 tasters, default mix: $2.28",
          abs(e1["usd"] - 2.28) < 0.005, e1["usd"])
    check("the estimate names the models it priced",
          set(e1["models"]) == {"gpt-5.4-mini", "gpt-5.4", "text-embedding-3-small"}, e1["models"])
    check("prices are dated", "September 2026" in PRICES_PER_1K_USD.get("_as_of", ""), PRICES_PER_1K_USD.get("_as_of"))

    print("\n2. More work costs more, and a gallery race prices its frames")
    check("four candidates cost more than three",
          estimate_cost(main_cfg(candidates=4))["usd"] > e1["usd"])
    g = estimate_cost(gallery_cfg())
    check("a 7 vs 5 gallery race costs more than a 3-image main race", g["usd"] > e1["usd"], (g["usd"], e1["usd"]))
    check("the per-image and within-set passes are in the gallery estimate",
          g["calls"]["per_image"] > 0 and g["calls"]["within_set"] > 0, g["calls"])
    check("a main race has neither pass",
          e1["calls"]["per_image"] == 0 and e1["calls"]["within_set"] == 0, e1["calls"])

    print("\n3. lite mode estimates lower")
    old = sys.argv
    sys.argv = ["panel.py", "cfg.json"]          # no 'lite' on the CLI; the key decides
    try:
        lite = estimate_cost(apply_mode(dict(main_cfg(), mode="lite")))
    finally:
        sys.argv = old
    check("lite is under a third of full", lite["usd"] < e1["usd"] / 3, (lite["usd"], e1["usd"]))

    print("\n4. The cap refuses above and allows below")
    check("default cap is $10 per sitting", SPEND_CAP_DEFAULT_USD == 10.0, SPEND_CAP_DEFAULT_USD)
    ok, line = cap_check(3.2, 10.0)
    check("$3.20 under a $10 cap runs", ok is True, line)
    ok, line = cap_check(12.4, 10.0)
    check("$12.40 over a $10 cap is refused", ok is False, line)
    check("the refusal names both numbers and asks once",
          "12.40" in line and "10" in line and "Run it anyway?" in line, line)
    ok, _ = cap_check(10.0, 10.0)
    check("exactly at the cap runs (the cap is a ceiling, not a wall)", ok is True)
    ok, _ = cap_check(6.0, 5.0)
    check("a raised or lowered cap in the config is honoured", ok is False)

    print("\n5. The printed line is the one the skill quotes")
    line = format_estimate(e1["usd"], 10.0)
    check("says Estimated, the race figure, and the sitting cap",
          line.startswith("Estimated: about $") and "for this race (cap $10 per sitting)" in line, line)

    if FAILURES:
        print(f"\nFAILED ({len(FAILURES)}): " + ", ".join(FAILURES))
        return 1
    print("\nCOST: all green")
    return 0


if __name__ == "__main__":
    sys.exit(run())

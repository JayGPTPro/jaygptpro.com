#!/usr/bin/env python3
"""What this sitting OWES, what it actually tested, and a gate on the gap.

The failure this exists to prevent: eight frames approved, the panel run on
one, seven never tested including one already flagged as a quality failure,
and no surface mentioning it. The scope lived in prose ("the approved
candidates"), bound to no field and checked by nothing. Two records that must
agree, with no code comparing them, drift; and the drift is invisible.

So scope is derived from disk rather than asserted:

  images/main-*   the mains; the RACE is the owner's `Main pick:` row in status.md
  images/sec-*    the gallery frames
  incumbent/      the live image and gallery to beat

Four commands:

  plan   <product_dir>              what each race owes, before you author a config
                                    (exit 1 when no selection is on record: it asks once)
  lineup <product_dir> <config>     refuse a config that does not carry the derived lineup
  record <product_dir> <race_dir>   fold one finished race into the coverage
  check  <product_dir>              the gate: refuse to close on a silent gap

Coverage ACCUMULATES across the races of a sitting. A sitting is two races
(main and gallery) that finish minutes apart, and each one writing its own
record would erase the other's; then no pair of races could ever satisfy the
gate. Keyed on (round, race) so a second round registers its own row instead
of overwriting the first.

Stdlib only, cross-platform. No network.
"""
import json
import re
import sys
import time
from pathlib import Path

IMG_EXT = {".png", ".jpg", ".jpeg", ".webp"}
COVERAGE = "coverage.json"

# Working documents that live in images/ but are never candidates, so the gate
# must not demand a race for them: the diagnostic vanilla control (tactics off,
# never ships), pick contact sheets, and pool sheets. Anything else a run wants
# excluded is still an explicit `waive` with a reason; this list is only for
# files the FACTORY ITSELF puts there as non-candidates by construction.
_NON_CANDIDATE = re.compile(
    r"^(_.*|vanilla-control([-_].*)?|.*[-_](shortlist|picksheet|pick-sheet|contact-sheet)s?([-_].*)?"
    r"|.*-(1024|1536|2048|3072|4096)|.*[-_](rejected|render\d*|boxes\d*))$",
    re.I,
)
# A leading underscore is a diagnostic file (`_chk_*`, `_compare`, `_name-map`,
# the magnified checks Wonka writes beside the mains); never a candidate, never
# named in the one question. Seen on a real product on 12 September 2026.
# `-rejected`, `-render` and `-boxes` are Fixing Room and Inspection Room EVIDENCE
# beside a candidate (a refused attempt, a magnified render, a box overlay). Never
# a candidate, never owed a race (kit v38, 12 September 2026).
# The trailing size forms (`main-13-2048.png`) are the on-request Day 5 upscales that
# /main-image saves BESIDE the original. They are a finish of a candidate, not a
# candidate: racing them alongside the 1024 original raced the same image twice and
# then blocked the gate on the copy (reproduced 7 September 2026).


# A regeneration or an edit lands BESIDE the file it replaces, and the original
# is kept on purpose (house rule: never delete the source). So images/ holds
# main-02.png next to main-02-v2.png, and main-04.png next to main-04_fix1.png.
# The owner's EXACT name wins: a `Main pick:` naming main-02 races main-02.png
# even when main-02-v2.png sits beside it. The family-newest rule below applies
# only to names nobody selected (the gallery, and the superseded list), so the
# gate does not cry wolf on every replaced original of a correct run.
_VERSION_SUFFIX = re.compile(
    r"^(?P<base>.+?)[-_](?:v(?P<v>\d+)|fix(?P<f>\d+)|faces-fixed(?:-v(?P<fv>\d+))?)$", re.I)


def _family(stem):
    """('main-02', 2) for main-02-v2; ('main-01', 0) for an unversioned original.
    A kit v22 Face Clinic output (`main-06-faces-fixed.png`) is a version of
    main-06 too, never a second candidate."""
    m = _VERSION_SUFFIX.match(stem)
    if not m:
        return stem, 0
    if m.group("fv") is not None or stem.lower().endswith("faces-fixed"):
        return m.group("base"), int(m.group("fv") or 1)
    n = m.group("v") or m.group("f")
    return m.group("base"), int(n)


_PICK_NAME = re.compile(r"\b(main-\d+(?:-v\d+)?|m\d+(?:-v\d+)?)\b", re.I)


def main_pick(product_dir):
    """The names on status.md's `Main pick:` row, primary first, backup excluded.

    `/inspect` writes `Main pick: main-13 (primary); alternatives: main-03, main-06;
    backup: vanilla-control.png` at the Day 5 close. That row IS the main race:
    the owner already passed over every other promoted main, and Day 8 never
    pays for a verdict on a candidate the owner did not pick. Returns [] when the
    row is missing or still the template placeholder; the caller then tries to
    RECOVER the selection from an unambiguous record, and asks when it cannot.
    It never falls back to everything on disk (kit v38)."""
    f = Path(product_dir) / "status.md"
    if not f.is_file():
        return []
    for line in f.read_text(errors="ignore").splitlines():
        if "main pick:" not in line.lower():
            continue
        body = line.split(":", 1)[1]
        body = re.split(r"backup\s*:", body, flags=re.I)[0]
        names = [n.lower() for n in _PICK_NAME.findall(body)]
        seen, out = set(), []
        for n in names:
            if n not in seen:
                seen.add(n); out.append(n)
        return out
    return []


# The ONLY line that records a selection outside status.md: a line that STARTS with
# `Main pick:` or `Owner pick:`, the same row `/inspect` writes. A looser match
# (`owner pick|primary` anywhere in a line) once turned a scorecard's ranking
# sentence, "main-03 ranks first and is the strongest primary candidate", into the
# owner's selection with a fabricated provenance (adversarial review, kit v38,
# 12 September 2026). Scorecards are never read for a selection: no scorecard
# producer writes an owner line, and a scorecard rank is a recommendation.
_OWNER_PICK_LINE = re.compile(r"^\s*(?:[-*]\s*)?(?:Main pick|Owner pick)\s*:", re.I)


def recover_pick(product_dir):
    """The selection when the `Main pick:` row is missing, recovered ONLY from a
    `Main pick:` / `Owner pick:` line in the latest `edits/vN/` round notes, with
    its provenance naming the file. Returns (names, source); ([], "") when no
    round notes carry such a line. Scorecards are not a source."""
    p = Path(product_dir)
    for r in rounds(p):
        for f in sorted(r.glob("*.md")):
            for line in f.read_text(errors="ignore").splitlines():
                if _OWNER_PICK_LINE.match(line):
                    names = _pick_names(line.split(":", 1)[1])
                    if names:
                        return names, f"recovered from edits/{r.name}/{f.name} (its Main pick line)"
    return [], ""


def _pick_names(line):
    body = re.split(r"backup\s*:", line, flags=re.I)[0]
    names = [n.lower() for n in _PICK_NAME.findall(body)]
    seen, out = set(), []
    for n in names:
        if n not in seen:
            seen.add(n); out.append(n)
    return out


def gallery_pick(product_dir):
    """The `Gallery pick:` row `/inspect` writes at the close of a gallery scope
    (`edits/v2 (frames 02-07 in order)`, or `images/`). Reported, not parsed
    into paths: the gallery race still reads the sec-* files off the disk and
    resolves each one to its accepted revision."""
    f = Path(product_dir) / "status.md"
    if not f.is_file():
        return ""
    for line in f.read_text(errors="ignore").splitlines():
        if "gallery pick:" in line.lower():
            body = line.split(":", 1)[1].strip()
            return "" if body.startswith("[") else body
    return ""


def incumbent_notes(product_dir):
    """Owner lines about the live gallery in `incumbent/notes.md`, such as
    `other model: live-04`. Read and printed, nothing more."""
    f = Path(product_dir) / "incumbent" / "notes.md"
    if not f.is_file():
        return []
    return [ln.strip() for ln in f.read_text(errors="ignore").splitlines()
            if ln.strip().lower().startswith("other model")]


def _imgs(d, latest_only=False):
    if not d.is_dir():
        return []
    files = sorted(
        p for p in d.iterdir()
        if p.suffix.lower() in IMG_EXT
        and not p.name.startswith(".")
        and not _NON_CANDIDATE.match(p.stem)
    )
    if not latest_only:
        return files
    best = {}
    for p in files:
        base, n = _family(p.stem)
        if base not in best or n > best[base][0]:
            best[base] = (n, p)
    return sorted((p for _, p in best.values()), key=lambda p: p.name)


def superseded(d, keep=()):
    """The originals a newer version replaced, so they can be NAMED rather than
    silently dropped. A gate that quietly stops asking about a file is the same
    failure as one that never asked. `keep` is the main race: a name the owner
    selected is raced, never superseded, whatever sits beside it."""
    live = {p.name for p in _imgs(d, latest_only=True)} | {str(k).lower() for k in keep}
    return [p.name for p in _imgs(d) if p.name not in live and p.name.lower() not in live]


def _accepted_file(pool, name):
    """The file a pick NAME means, out of everything on disk. An exact stem
    match wins (`main-13` means main-13.png; `main-13-v2` means the
    regeneration, and only when the owner named it). A kit v22 Face Clinic
    output (`main-06-faces-fixed.png`) is a version of main-06 and stands in
    for it, newest first. A `-v2` regeneration or a `_fixN` copy the owner did
    not name never substitutes for the file they did name."""
    exact = [f for f in pool if f.stem.lower() == name]
    faces = [f for f in pool if _family(f.stem)[0].lower() == name and "faces-fixed" in f.stem.lower()]
    cands = exact + faces
    if not cands:
        return None
    return max(cands, key=lambda f: _family(f.stem)[1])


def rounds(product_dir):
    """Every `edits/vN/` round, HIGHEST first. Sorted numerically, because a
    string sort puts v10 before v2 and would race a stale set the moment a
    product reaches ten rounds."""
    e = Path(product_dir) / "edits"
    if not e.is_dir():
        return []
    out = []
    for d in e.iterdir():
        if d.is_dir() and re.fullmatch(r"v(\d+)", d.name):
            out.append((int(d.name[1:]), d))
    return [d for _, d in sorted(out, reverse=True)]


def current_path(product_dir, name):
    """WHERE the current version of `name` actually lives.

    The Fixing Room writes each round as a complete set snapshot into
    `edits/vN/`, and surgical edits KEEP the filename, so the same name exists
    in `images/` and in every round. The newest copy wins, and it is resolved
    per FILE rather than per folder because a round may have touched only some
    of the set.

    This is the same resolution `/inspect` and `/ready-to-upload` already do.
    Until 26 August 2026 this module did not do it at all: it returned bare names,
    every caller joined them to `images/`, and a Tasting Round after a fix
    round therefore raced the SUPERSEDED files while the pack shipped the
    fixed ones. Nothing caught it, because the two sets have identical
    filenames by design, so a name-based guard compares equal."""
    p = Path(product_dir)
    for r in rounds(p):
        c = r / name
        if c.is_file():
            return c
    c = p / "images" / name
    if c.is_file():
        return c
    # A pick chosen out of the pick folder (`m26.png` under images/pick/shortlist/)
    # lives only there. Joining its name to images/ produced a path that did not
    # exist, which `lineup` then blessed and the panel refused (kit v38 review).
    for sub in ("pick/shortlist", "pick"):
        c = p / "images" / sub / name
        if c.is_file():
            return c
    return p / "images" / name


def derive(product_dir):
    """The approved scope, read off the disk that holds it."""
    p = Path(product_dir).resolve()
    images = _imgs(p / "images", latest_only=True)
    # Classify by what the GALLERY is called, never by what a main is called.
    # `sec-NN` is the firm half of the naming contract; a main may arrive as
    # main-NN.png, or carrying the short pick id it won under (m26, m51) when
    # the owner chose it out of the pick folder. Filtering FOR "main" silently
    # dropped every Draft Blast winner and printed "MAIN RACE owes nothing"
    # over four gate-passed candidates (measured 27 August 2026).
    gallery = [f for f in images if f.name.lower().startswith("sec")]
    main = [f for f in images if f not in gallery]
    # The main race is the OWNER'S SELECTION, resolved in this order (kit v38,
    # 12 September 2026): (1) the `Main pick:` row in status.md; (2) recovered
    # from an unambiguous record, with provenance; (3) ONE focused question and
    # nothing raced. There is no fourth step. The every-main fallback that used
    # to sit here made fourteen mains race on one Day 8 when the row was missing.
    picks, selection_source = main_pick(p), "status.md Main pick row (primary + alternatives)"
    if not picks:
        picks, selection_source = recover_pick(p)
    pick_missing = []
    chosen = []
    if picks:
        pool = _imgs(p / "images")
        for sub in ("pick/shortlist", "pick"):
            pool += [f for f in _imgs(p / "images" / sub) if not f.name.lower().startswith("sec")]
        for name in picks:
            hit = _accepted_file(pool, name)
            if hit is None:
                pick_missing.append(name)
            elif hit not in chosen:
                chosen.append(hit)
    selection_question = ""
    if chosen:
        main = chosen
    else:
        main = []
        selection_source = selection_source if picks else "no selection on record"
        # Named as what they are: mains ON DISK. A scorecard FAIL on record is marked,
        # not hidden; "gate-passed" was a claim the scope never checked.
        notes = scorecard_notes(p)
        on_disk = []
        for f in sorted(x for x in images if x not in gallery):
            base = _family(f.stem)[0].lower()
            if base in [x.split(" ")[0] for x in on_disk]:
                continue
            on_disk.append(base + (" (scorecard FAIL on record)" if f.name in notes else ""))
        selection_question = ("Which main is your primary, and which alternatives should race? I see "
                              + (", ".join(on_disk) if on_disk else "no mains") + " on disk.")
    inc = _imgs(p / "incumbent")
    inc_main = [f for f in inc if "main" in f.name.lower()]
    inc_gallery = [f for f in inc if f not in inc_main]
    paths = {f.name: str(current_path(p, f.name)) for f in main + gallery}
    return {
        "product_dir": str(p),
        "main": [f.name for f in main],
        "gallery": [f.name for f in gallery],
        "incumbent_main": [f.name for f in inc_main],
        "incumbent_gallery": [f.name for f in inc_gallery],
        "main_source": selection_source,
        "selection_source": selection_source,
        "selection_question": selection_question,
        "pick_missing": pick_missing,
        "gallery_pick": gallery_pick(p),
        "gallery_count": len(gallery),
        "incumbent_gallery_count": len(inc_gallery),
        "incumbent_notes": incumbent_notes(p),
        "superseded": superseded(p / "images", keep=[f.name for f in main]),
        "quality_notes": scorecard_notes(p),
        # The RESOLVED path for every name above. Callers must build the
        # tasting config from this, never by joining a name to images/.
        "paths": paths,
        # The lineup, in race order, as absolute paths: what is printed to the
        # owner and what config.json must carry, checked by lineup_matches().
        "lineup_main": [paths[f.name] for f in main],
        "lineup_gallery": [paths[f.name] for f in gallery],
    }


def lineup_matches(scope, cfg):
    """The lineup the scope derived and the config about to run must list the
    same absolute paths in the same order. Returns a list of problems, empty
    when they agree. The incumbent entry is the config's own and is skipped."""
    race = cfg.get("race") or ("gallery" if any(len(i.get("paths") or []) > 1 for i in cfg.get("images", []))
                               else "main")
    expected = scope["lineup_gallery"] if race == "gallery" else scope["lineup_main"]
    inc = cfg.get("incumbent_id")
    ours = [i for i in cfg.get("images", []) if i.get("id") != inc]
    actual = []
    for i in ours:
        actual += [str(Path(x).resolve()) for x in (i.get("paths") or ([i["path"]] if i.get("path") else []))]
    expected = [str(Path(x).resolve()) for x in expected]
    problems = []
    if actual != expected:
        for k, (a, e) in enumerate(zip(actual, expected), 1):
            if a != e:
                problems.append(f"position {k}: config has {Path(a).parent.name}/{Path(a).name}, "
                                f"the lineup says {Path(e).parent.name}/{Path(e).name}")
        if len(actual) != len(expected):
            problems.append(f"count: config lists {len(actual)} of ours, the lineup has {len(expected)}")
        if not problems:
            problems.append("the same files in a different order")
    return problems


def cmd_lineup(product_dir, cfg_path):
    """`scope.py lineup <product_dir> <config.json>`: refuse a config that does
    not carry the derived lineup, before anything is spent."""
    s = derive(product_dir)
    cfg = json.loads(Path(cfg_path).read_text())
    problems = lineup_matches(s, cfg)
    if problems:
        print("LINEUP MISMATCH. The config does not list the lineup the scope derived:")
        for pr in problems:
            print(f"   {pr}")
        print("Build every path from scope.derive()['paths'] and write the config again.")
        return 1
    print(f"lineup ok: {Path(cfg_path).name} carries the derived lineup, same files, same order.")
    return 0


def scorecard_notes(p):
    """Any FAIL a scorecard already recorded, attached to the filename it is about.

    Printed at the moment the scope is READ, which is the moment it is cheap.
    A frame that has already failed inspection should not reach the panel and
    find out afterwards that a round was spent on it.
    """
    notes = {}
    sc = p / "scorecards"
    if not sc.is_dir():
        return notes
    for f in sorted(sc.glob("*.md")):
        try:
            text = f.read_text(errors="ignore")
        except Exception:
            continue
        for line in text.splitlines():
            low = line.lower()
            if not re.search(r"\bfail(?:ed|s|ure)?\b", low) or re.search(r"no fail|0 fail|zero fail", low):
                continue
            for name in [x.name for x in _imgs(p / "images")]:
                # Match the FULL filename, or the stem followed by a boundary.
                # A bare stem match let a line about sec-10.png attach itself to
                # sec-1.png.
                stem = Path(name).stem.lower()
                if name.lower() in low or re.search(rf"\b{re.escape(stem)}\b", low):
                    notes.setdefault(name, line.strip()[:160])
    return notes


def cmd_plan(product_dir):
    s = derive(product_dir)
    n = s["quality_notes"]

    def block(title, items, extra=""):
        print(f"\n{title}  ({len(items)})")
        if not items:
            print("   nothing on disk")
            if extra:
                print(f"   {extra}")
            return
        for i in items:
            flag = f"   <-- {n[i]}" if i in n else ""
            print(f"   {i}{flag}")
        if extra:
            print(f"   {extra}")

    src = {Path(v).parent.name for v in s.get("paths", {}).values()}
    print(f"SCOPE for {Path(s['product_dir']).name}")
    print(f"  current set reads from: {', '.join(sorted(src)) or 'images'}"
          "   (a fix round moves this; the race must follow it)")
    # No hint on an empty main race: the live path prints exactly what it did
    # before v37. The extra-on-empty print exists for the benchmark MISSING hint.
    block("MAIN RACE owes", s["main"], f"from: {s['selection_source']}" if s["main"] else "")
    if s.get("pick_missing"):
        print("   NAMED IN THE PICK ROW BUT NOT ON DISK: " + ", ".join(s["pick_missing"])
              + "  (check images/ and images/pick/; a pick that cannot be found cannot race)")
    if s.get("selection_question"):
        # ONE focused question, then out non-zero. Never every main in images/.
        print("   NO SELECTION ON RECORD: " + s["selection_question"])
    block("  benchmark", s["incumbent_main"],
          ("MISSING: no live image on file. Live product: fill incumbent/ (step 0b). "
           "Pre-launch: copy the strongest competitor's main into incumbent/ as "
           "competitor-main.png (step 4b).") if not s["incumbent_main"] else "")
    block("GALLERY RACE owes", s["gallery"],
          (f"{s['gallery_count']} frames vs {s['incumbent_gallery_count']} live frames; compared as they are, "
           "no frames dropped" if s["gallery"] else "")
          + (f"; Gallery pick row: {s['gallery_pick']}" if s.get("gallery_pick") and s["gallery"] else ""))
    block("  benchmark", s["incumbent_gallery"])
    for line in s.get("incumbent_notes") or []:
        print(f"   NOTE from incumbent/notes.md: {line}")
    if s["superseded"]:
        print(f"\nSuperseded, NOT owed a test ({len(s['superseded'])}): " + ", ".join(s["superseded"]))
        print("   a newer -v2 or _fixN sits beside each. The newest of each family is what is owed.")
    if n:
        print("\nQUALITY FLAGS already on record. Do not spend a race on a known failure:")
        for k, v in n.items():
            print(f"   {k}: {v}")
    print("\nRaces this sitting owes: "
          + ", ".join(x for x in (["main"] if s["main"] else []) + (["gallery"] if s["gallery"] else []))
          + ".  A race you skip on purpose is fine; record it with `waive`.")
    return 1 if s.get("selection_question") else 0


def _cov_path(product_dir):
    return Path(product_dir).resolve() / "tests" / COVERAGE


def _load_cov(product_dir):
    f = _cov_path(product_dir)
    if f.exists():
        try:
            cov = json.loads(f.read_text())
            cov.setdefault("races", {})
            cov.setdefault("waived", {})
            return cov
        except Exception:
            # NEVER silently reset: the next save would destroy accumulated
            # coverage with nobody told. Refuse instead.
            raise SystemExit(f"{f} is not readable JSON. Fix or delete it; do not let a run overwrite it.")
    return {"races": {}, "waived": {}}


def _save_cov(product_dir, cov):
    f = _cov_path(product_dir)
    f.parent.mkdir(parents=True, exist_ok=True)
    f.write_text(json.dumps(cov, indent=1))
    return f


def cmd_record(product_dir, race_dir):
    """Fold ONE finished race into the coverage. Never replaces the other race."""
    rd = Path(race_dir).resolve()
    cfg_f, res_f = rd / "config.json", rd / "results.json"
    if not cfg_f.exists():
        print(f"no config.json in {rd}")
        return 1
    cfg = json.loads(cfg_f.read_text())
    tested = []
    for img in cfg.get("images", []):
        for path in (img.get("paths") or ([img["path"]] if img.get("path") else [])):
            tested.append(Path(path).name)

    rnd = cfg.get("round", 1)
    race = cfg.get("race") or ("gallery" if any(len(i.get("paths") or []) > 1 for i in cfg.get("images", []))
                               else "main")
    key = f"r{rnd}-{race}"                      # (round, race), never round alone

    cov = _load_cov(product_dir)                # LOAD then merge: accumulate, never reset
    prev = cov.get("races", {}).get(key)
    if prev and str(Path(prev.get("out_dir", ""))) != str(rd):
        # A re-run of the SAME race replaces its own row, which is what makes
        # this idempotent. A DIFFERENT folder claiming the same key is two races
        # that auto-detected to the same name, and silently overwriting one is
        # the bug this whole file exists to prevent.
        print(f"REFUSING: {key} is already recorded from {prev['out_dir']}.")
        print("Two races cannot share a key. Put an explicit \"race\" in each config")
        print('   (for example "race": "main" and "race": "gallery") and record again.')
        return 1
    cov["races"][key] = {
        "round": rnd, "race": race, "tested": sorted(set(tested)),
        "out_dir": str(rd), "completed": res_f.exists(),
        "at": time.strftime("%Y-%m-%d %H:%M"),
    }
    f = _save_cov(product_dir, cov)
    print(f"recorded {key}: {len(set(tested))} images. coverage now holds {', '.join(sorted(cov['races']))} -> {f}")
    return 0


def cmd_waive(product_dir, name, reason):
    if not reason.strip():
        print("a waiver needs a reason. That is the whole point of it.")
        return 1
    cov = _load_cov(product_dir)
    cov.setdefault("waived", {})[name] = reason.strip()
    _save_cov(product_dir, cov)
    print(f"waived {name}: {reason.strip()}")
    return 0


def cmd_check(product_dir):
    """The gate. A deliberate skip stays possible; a silent one does not."""
    s = derive(product_dir)
    if s.get("selection_question"):
        # No selection on record means the main race never had a lineup. A gallery
        # race alone must not pass the gate (adversarial review, kit v38).
        print("GATE: BLOCKED. " + s["selection_question"])
        print("   Write the owner's answer as the `Main pick:` row in status.md, re-run plan, race, then check.")
        return 1
    cov = _load_cov(product_dir)
    tested = set()
    incomplete = []
    for k, r in cov.get("races", {}).items():
        if not r.get("completed"):
            # A run that crashed after writing its config used to satisfy the
            # gate. Coverage means TESTED, and a race with no results.json
            # tested nothing.
            incomplete.append(k)
            continue
        tested |= set(r.get("tested", []))       # UNION across completed races
    owed = set(s["main"]) | set(s["gallery"])
    waived = set(cov.get("waived", {}))
    gap = sorted(owed - tested - waived)

    print(f"races recorded: {', '.join(sorted(cov.get('races', {}))) or 'none'}")
    if incomplete:
        print(f"NOT counted, no results.json: {', '.join(sorted(incomplete))}")
    print(f"approved on disk: {len(owed)} | tested: {len(owed & tested)} | waived: {len(owed & waived)}")
    for name in sorted(owed & waived):
        print(f"   waived  {name}: {cov['waived'][name]}")
    if gap:
        print("\nGATE: BLOCKED. Approved but neither tested nor waived:")
        for name in gap:
            note = s["quality_notes"].get(name)
            print(f"   {name}" + (f"   <-- {note}" if note else ""))
        print("\nTest them, or waive each with a reason:")
        print(f'   python3 scope.py waive "{product_dir}" "{gap[0]}" "why it is not being tested"')
        print("\nDeciding on a partial round is the wrong question to put to the owner.")
        return 1
    print("\nGATE: PASS. Everything approved was tested or waived with a reason.")
    return 0


def main():
    if len(sys.argv) < 3:
        print(__doc__)
        return 1
    cmd, pdir = sys.argv[1], sys.argv[2]
    if cmd == "plan":
        return cmd_plan(pdir)
    if cmd == "lineup":
        if len(sys.argv) < 4:
            print('usage: scope.py lineup "<product_dir>" "<config.json>"')
            return 1
        return cmd_lineup(pdir, sys.argv[3])
    if cmd == "record":
        if len(sys.argv) < 4:
            print('usage: scope.py record "<product_dir>" "<race_out_dir>"')
            return 1
        return cmd_record(pdir, sys.argv[3])
    if cmd == "waive":
        if len(sys.argv) < 5:
            print('usage: scope.py waive "<product_dir>" "<filename>" "<reason>"')
            return 1
        return cmd_waive(pdir, sys.argv[3], " ".join(sys.argv[4:]))
    if cmd == "check":
        return cmd_check(pdir)
    print(f"unknown command: {cmd}")
    return 1


if __name__ == "__main__":
    sys.exit(main())

#!/usr/bin/env python3
"""Which files a Tasting Round actually races.

The Fixing Room writes each round as a complete set snapshot into `edits/vN/`
and surgical edits KEEP the filename, so the same name exists in `images/` and
in every round. Before this was fixed, `scope.derive()` returned bare names,
every caller joined them to `images/`, and a round run after a fix round raced
the SUPERSEDED files while the pack shipped the fixed ones.

Nothing caught it in review, and no name-based guard ever could: the two sets
have identical filenames by design, so comparing names compares equal. That is
why this test compares FILE CONTENT.

Run: python3 test_scope.py
"""
import sys
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

FAILURES = []


def check(name, cond, detail=""):
    print(("  PASS  " if cond else "  FAIL  ") + name + ("  " + str(detail) if not cond and detail else ""))
    if not cond:
        FAILURES.append(name)


def build(rounds_spec):
    """A product folder whose every file carries its own origin as content."""
    tmp = (Path(tempfile.mkdtemp()) / "fondue").resolve()
    (tmp / "images").mkdir(parents=True)
    (tmp / "incumbent").mkdir(parents=True)
    for n in ("main-01.png", "sec-01.png", "sec-02.png"):
        (tmp / "images" / n).write_bytes(b"OLD")
    (tmp / "incumbent" / "main-live.png").write_bytes(b"x")
    (tmp / "status.md").write_text("- Main pick: main-01 (primary)\n")   # kit v38: the row IS the race
    for rnd, names in rounds_spec.items():
        d = tmp / "edits" / rnd
        d.mkdir(parents=True)
        for n in names:
            (d / n).write_bytes(rnd.encode())
    return tmp


# ---- kit v38, 12 September 2026: underscore diagnostics are not candidates
def _underscore_diagnostics():
    import tempfile, shutil, scope
    derive = scope.derive
    d = Path(tempfile.mkdtemp()) / "prod"
    (d / "images").mkdir(parents=True)
    for n in ["main-01.png", "main-02.png", "_chk_main01_hand.jpg", "_compare-v2.jpg", "_name-map.jpg"]:
        (d / "images" / n).write_bytes(b"x")
    (d / "status.md").write_text("# p\n")
    s = derive(d)
    q = s.get("selection_question", "")
    check("underscore files are not candidates in the question", "_chk_" not in q and "_compare" not in q and "_name-map" not in q, q)
    check("real mains still named in the question", "main-01" in q and "main-02" in q, q)
    shutil.rmtree(d.parent, ignore_errors=True)



def run():
    import scope

    def origin(s, name):
        return Path(s["paths"][name]).read_bytes().decode()

    t = build({"v1": ["main-01.png", "sec-01.png", "sec-02.png"]})
    s = scope.derive(t)
    check("after a fix round, the race reads edits/v1 and not images",
          origin(s, "main-01.png") == "v1", origin(s, "main-01.png"))

    t = build({"v2": ["main-01.png"], "v10": ["main-01.png"]})
    check("v10 beats v2, so rounds are ordered numerically and not as strings",
          origin(scope.derive(t), "main-01.png") == "v10",
          origin(scope.derive(t), "main-01.png"))

    t = build({"v1": ["sec-01.png"]})
    s = scope.derive(t)
    got = (origin(s, "main-01.png"), origin(s, "sec-01.png"), origin(s, "sec-02.png"))
    check("a round that touched one frame moves ONLY that frame",
          got == ("OLD", "v1", "OLD"), got)

    t = build({})
    check("a product with no edits/ still resolves to images/",
          origin(scope.derive(t), "main-01.png") == "OLD")

    t = build({"v1": ["main-01.png"]})
    s = scope.derive(t)
    check("every raced name carries a resolved path",
          set(s["paths"]) == set(s["main"]) | set(s["gallery"]), sorted(s["paths"]))

    print()
    # --- a main is whatever is not the gallery ------------------------------
    # Draft Blast winners arrive carrying the short pick id they won under
    # (m26, m51). Filtering FOR names starting with "main" dropped the entire
    # main race and printed "MAIN RACE owes nothing" over four gate-passed
    # candidates. Measured 27 August 2026 on the live student run.
    import tempfile as _tf
    from pathlib import Path as _P
    t2 = (_P(_tf.mkdtemp()) / "brushes").resolve()
    (t2 / "images").mkdir(parents=True)
    (t2 / "incumbent").mkdir(parents=True)
    for n in ("m26.png", "m51.png", "sec-01.png", "sec-02.png"):
        (t2 / "images" / n).write_bytes(b"x")
    (t2 / "incumbent" / "main-live.png").write_bytes(b"x")
    (t2 / "status.md").write_text("- Main pick: m26 (primary); alternatives: m51\n")
    sc2 = scope.derive(t2)
    check("pick-id mains are raced, not dropped",
          sorted(sc2["main"]) == ["m26.png", "m51.png"], sc2["main"])
    check("and the gallery is still exactly the sec files",
          sorted(sc2["gallery"]) == ["sec-01.png", "sec-02.png"], sc2["gallery"])

    # Mains still sitting in the pick folder are found rather than reported absent.
    t3 = (_P(_tf.mkdtemp()) / "brushes2").resolve()
    (t3 / "images" / "pick" / "shortlist").mkdir(parents=True)
    (t3 / "incumbent").mkdir(parents=True)
    (t3 / "images" / "sec-01.png").write_bytes(b"x")
    (t3 / "images" / "pick" / "shortlist" / "m37.png").write_bytes(b"x")
    (t3 / "incumbent" / "main-live.png").write_bytes(b"x")
    (t3 / "status.md").write_text("- Main pick: m37 (primary)\n")
    sc3 = scope.derive(t3)
    check("a main left in the pick folder is still raced",
          sc3["main"] == ["m37.png"], sc3["main"])

    # --- the Day 5 close decides the main race (kit v23) ---------------------
    # status.md's `Main pick:` row names the primary and the alternatives. Every
    # other promoted main was passed over by the owner and is not owed a race.
    # The on-request 2048 upscale and a v22 -faces-fixed file are versions of a
    # candidate, never candidates. Reproduced 7 September 2026: six "owed" files
    # for a two-file pick.
    t4 = (_P(_tf.mkdtemp()) / "fondue4").resolve()
    (t4 / "images").mkdir(parents=True)
    (t4 / "incumbent").mkdir(parents=True)
    for n in ("main-03.png", "main-06.png", "main-06-faces-fixed.png", "main-13.png",
              "main-13-2048.png", "main-130.png", "sec-01.png"):
        (t4 / "images" / n).write_bytes(b"x")
    (t4 / "incumbent" / "main-live.png").write_bytes(b"x")
    (t4 / "status.md").write_text(
        "- Main pick: main-13 (primary); alternatives: main-06; backup: vanilla-control.png\n")
    sc4 = scope.derive(t4)
    check("the main race is the Main pick row, primary first",
          sc4["main"] == ["main-13.png", "main-06-faces-fixed.png"], sc4["main"])
    check("a -2048 upscale is never a candidate",
          "main-13-2048.png" not in sc4["main"] and "main-13-2048.png" not in sc4["superseded"], sc4)
    check("the row's source is reported", "Main pick" in sc4["main_source"], sc4["main_source"])
    (t4 / "status.md").write_text("- Main pick: [main-NN (primary); alternatives: main-NN]\n")
    sc4b = scope.derive(t4)
    # Until kit v38 a placeholder row fell back to everything on disk; that
    # fallback is what raced fourteen mains on one Day 8. Now it asks.
    check("a template placeholder row races nothing and asks",
          sc4b["main"] == [] and "Which main is your primary" in sc4b["selection_question"], sc4b)
    (t4 / "status.md").write_text("- Main pick: main-99 (primary)\n")
    sc4c = scope.derive(t4)
    check("a pick that is not on disk is NAMED, and the race does not fall back",
          sc4c["pick_missing"] == ["main-99"] and sc4c["main"] == [], sc4c)

    # --- an empty incumbent/ names BOTH ways to fill it (kit v37) -------------
    # "MISSING: a main race without the live image proves nothing" told a
    # pre-launch product it could never race. The plan must say: live product,
    # fill incumbent/ (step 0b); pre-launch, copy the strongest competitor's
    # main in as competitor-main.png (step 4b).
    import contextlib as _cl
    import io as _io
    t5 = (_P(_tf.mkdtemp()) / "prelaunch").resolve()
    (t5 / "images").mkdir(parents=True)
    (t5 / "incumbent").mkdir(parents=True)
    (t5 / "images" / "main-01.png").write_bytes(b"x")
    (t5 / "status.md").write_text("- Main pick: main-01 (primary)\n")
    buf = _io.StringIO()
    with _cl.redirect_stdout(buf):
        scope.cmd_plan(str(t5))
    out = buf.getvalue()
    check("an empty incumbent/ is reported MISSING", "MISSING: no live image on file" in out, out[-400:])
    check("and the live route is named (step 0b)", "fill incumbent/ (step 0b)" in out, out[-400:])
    check("and the pre-launch route is named (competitor-main.png, step 4b)",
          "competitor-main.png" in out and "step 4b" in out, out[-400:])

    # --- kit v38 (12 September 2026): the selection is the owner's row, never disk ---
    # A missing `Main pick:` row once made every main in images/ race (fourteen
    # mains on one Day 8, reviewed by ChatGPT the same day). The fallback is
    # gone: the row wins, an unambiguous record recovers it with provenance,
    # anything else asks ONE question and exits non-zero.
    import json as _json
    print()

    def v38_tree(status_line=None, scorecard=None, notes=None):
        t = (_P(_tf.mkdtemp()) / "catnip").resolve()
        (t / "images").mkdir(parents=True)
        (t / "incumbent").mkdir(parents=True)
        for n in ("main-03.png", "main-06.png", "main-13.png", "main-13-v2.png",
                  "main-06-rejected.png", "main-03-render.png", "main-03-boxes.png",
                  "sec-01.png", "sec-02.png"):
            (t / "images" / n).write_bytes(b"images")
        (t / "incumbent" / "main-live.png").write_bytes(b"x")
        for n in ("live-01.png", "live-02.png", "live-03.png"):
            (t / "incumbent" / n).write_bytes(b"x")
        (t / "edits" / "v1").mkdir(parents=True)
        (t / "edits" / "v1" / "main-13.png").write_bytes(b"v1")
        (t / "edits" / "v1" / "sec-01.png").write_bytes(b"v1")
        (t / "edits" / "v2").mkdir(parents=True)
        (t / "edits" / "v2" / "main-13.png").write_bytes(b"v2")
        (t / "edits" / "v2" / "main-13-rejected.png").write_bytes(b"v2rej")
        if status_line is not None:
            (t / "status.md").write_text(status_line + "\n")
        if scorecard:
            (t / "scorecards").mkdir()
            (t / "scorecards" / "scorecard-main-2026-09-10-1.md").write_text(scorecard)
        if notes:
            (t / "edits" / "v2" / "round-notes.md").write_text(notes)
        return t

    # (1) the row present
    t6 = v38_tree("- Main pick: main-13 (primary); alternatives: main-06, main-03; backup: vanilla-control.png")
    s6 = scope.derive(t6)
    check("row present: the main race is the row, primary first",
          s6["main"] == ["main-13.png", "main-06.png", "main-03.png"], s6["main"])
    check("row present: selection_source names the row",
          s6["selection_source"].startswith("status.md Main pick row"), s6["selection_source"])
    check("accepted revision: main-13 races from edits/v2, the newest copy of that filename",
          _P(s6["paths"]["main-13.png"]).read_bytes() == b"v2", s6["paths"]["main-13.png"])
    check("accepted revision: main-06 was never edited, so it races from images/",
          _P(s6["paths"]["main-06.png"]).read_bytes() == b"images", s6["paths"]["main-06.png"])
    check("a -v2 regeneration the owner did not pick is not raced",
          "main-13-v2.png" not in s6["main"], s6["main"])
    check("-rejected, -render and -boxes evidence never enter a race",
          not any(x in " ".join(s6["main"] + s6["gallery"]) for x in ("rejected", "render", "boxes")),
          s6["main"] + s6["gallery"])
    check("the lineup is absolute paths in row order, mains then gallery",
          s6["lineup_main"] == [s6["paths"][n] for n in s6["main"]]
          and s6["lineup_gallery"] == [s6["paths"][n] for n in s6["gallery"]],
          (s6["lineup_main"], s6["lineup_gallery"]))
    check("the gallery race counts both sides",
          s6["gallery_count"] == 2 and s6["incumbent_gallery_count"] == 3,
          (s6.get("gallery_count"), s6.get("incumbent_gallery_count")))

    # (1b) the lineup printed and the config written must agree, checked by code
    good = {"race": "main", "images": [
        {"id": "main_13", "path": s6["paths"]["main-13.png"]},
        {"id": "main_06", "path": s6["paths"]["main-06.png"]},
        {"id": "main_03", "path": s6["paths"]["main-03.png"]},
        {"id": "current_listing", "path": str(t6 / "incumbent" / "main-live.png")}],
        "incumbent_id": "current_listing"}
    check("lineup check: a config built from the lineup passes",
          scope.lineup_matches(s6, good) == [], scope.lineup_matches(s6, good))
    bad = _json.loads(_json.dumps(good))
    bad["images"][0]["path"] = str(t6 / "images" / "main-13.png")     # the superseded copy
    problems = scope.lineup_matches(s6, bad)
    check("lineup check: the superseded images/ copy in the config is caught",
          problems and "main-13.png" in problems[0], problems)
    bad2 = _json.loads(_json.dumps(good))
    bad2["images"][1], bad2["images"][2] = bad2["images"][2], bad2["images"][1]
    check("lineup check: a different order is caught",
          scope.lineup_matches(s6, bad2) != [], scope.lineup_matches(s6, bad2))
    cfg_f = t6 / "cfg.json"
    cfg_f.write_text(_json.dumps(bad))
    check("lineup CLI exits non-zero on a mismatch", scope.cmd_lineup(str(t6), str(cfg_f)) == 1)
    cfg_f.write_text(_json.dumps(good))
    check("lineup CLI exits zero on a match", scope.cmd_lineup(str(t6), str(cfg_f)) == 0)

    # (2) the row missing, recovered ONLY from a `Main pick:` / `Owner pick:` line in the
    # latest edits/vN/ round notes. Scorecards are never a source: no scorecard producer
    # writes an owner line, and a ranking sentence ("main-03 ranks first and is the
    # strongest primary candidate") once resolved as the owner's selection with a
    # fabricated provenance (adversarial review, kit v38, 12 September 2026).
    t7 = v38_tree(None, scorecard="# Inspection Scorecard\n\nmain-03 ranks first and is the strongest primary candidate.\n"
                                  "Owner pick: main-13 (primary); alternatives: main-06\n")
    s7 = scope.derive(t7)
    check("a scorecard ranking sentence is NOT the owner's selection (nothing races, the room asks)",
          s7["main"] == [] and bool(s7["selection_question"]), (s7["main"], s7["selection_source"]))
    check("a scorecard is never named as the selection source",
          "scorecard" not in s7["selection_source"], s7["selection_source"])
    t8 = v38_tree(None, notes="Round notes.\nmain-06 ranks first and is the strongest primary candidate.\n"
                              "Main pick: main-13 (primary); alternatives: main-03\n")
    s8 = scope.derive(t8)
    check("recovered from a `Main pick:` line in the latest edits/vN round notes",
          s8["main"] == ["main-13.png", "main-03.png"], s8["main"])
    check("  ... with provenance naming the file", "edits/v2/round-notes.md" in s8["selection_source"], s8["selection_source"])
    t8b = v38_tree(None, notes="Round notes. Primary: main-13. Alternatives: main-03.\n")
    s8b = scope.derive(t8b)
    check("round notes without a `Main pick:`/`Owner pick:` line do not resolve",
          s8b["main"] == [] and bool(s8b["selection_question"]), s8b["main"])

    # (3) still ambiguous: ONE question, non-zero exit, and NEVER every main
    for label, t9 in (("no status.md at all", v38_tree(None)),
                      ("the template placeholder row",
                       v38_tree("- Main pick: [main-NN (primary); alternatives: main-NN, main-NN; backup: vanilla-control.png]"))):
        s9 = scope.derive(t9)
        check(f"{label}: nothing races", s9["main"] == [], s9["main"])
        check(f"{label}: the question names the gate-passed mains on disk",
              "Which main is your primary" in s9["selection_question"]
              and "main-03, main-06, main-13" in s9["selection_question"],
              s9["selection_question"])
        check(f"{label}: no every-main fallback is reported",
              "images/ (no Main pick row" not in s9["selection_source"], s9["selection_source"])
        buf = _io.StringIO()
        with _cl.redirect_stdout(buf):
            rc = scope.cmd_plan(str(t9))
        check(f"{label}: plan exits non-zero and prints the question once",
              rc == 1 and buf.getvalue().count("Which main is your primary") == 1, (rc, buf.getvalue()[-300:]))
    check("the every-main fallback string is gone from scope.py",
          "no Main pick row in status.md" not in (HERE / "scope.py").read_text())

    # a pick that is not on disk is named, and with nothing else found the room asks
    t10 = v38_tree("- Main pick: main-99 (primary)")
    s10 = scope.derive(t10)
    check("a pick not on disk is named and the room asks instead of racing everything",
          s10["pick_missing"] == ["main-99"] and s10["main"] == [] and s10["selection_question"], s10)

    # the Gallery pick row is read back and reported
    t11 = v38_tree("- Main pick: main-13 (primary)\n- Gallery pick: edits/v1 (frames 01-02 in order)")
    s11 = scope.derive(t11)
    check("the Gallery pick row is carried into the scope",
          s11["gallery_pick"] == "edits/v1 (frames 01-02 in order)", s11.get("gallery_pick"))

    # another-model note on the live gallery
    (t11 / "incumbent" / "notes.md").write_text("other model: live-03\n")
    s11b = scope.derive(t11)
    check("an incumbent/notes.md 'other model' line is read and reported",
          s11b["incumbent_notes"] == ["other model: live-03"], s11b.get("incumbent_notes"))
    buf = _io.StringIO()
    with _cl.redirect_stdout(buf):
        scope.cmd_plan(str(t11))
    out = buf.getvalue()
    check("the plan prints both gallery counts and the other-model line",
          "2 frames vs 3 live frames" in out and "other model: live-03" in out, out[-500:])

    # (R4) the gate refuses to pass when no selection is on record, even after a gallery race
    t12 = v38_tree(None)
    race = t12 / "tests" / "tasting-r1-2026-09-12-gallery"
    race.mkdir(parents=True)
    (race / "config.json").write_text(_json.dumps({"race": "gallery", "images": [
        {"id": "ours", "paths": [str(t12 / "images" / "sec-01.png"), str(t12 / "images" / "sec-02.png")]},
        {"id": "live", "paths": [str(t12 / "incumbent" / f"live-0{k}.png") for k in (1, 2, 3)]}],
        "incumbent_id": "live"}))
    (race / "results.json").write_text("{}")
    buf = _io.StringIO()
    with _cl.redirect_stdout(buf):
        scope.cmd_record(str(t12), str(race))
        rc = scope.cmd_check(str(t12))
    out = buf.getvalue()
    check("check: no selection on record BLOCKS the gate even though the gallery race ran",
          rc == 1 and "GATE: BLOCKED" in out and "Which main is your primary" in out, (rc, out[-400:]))

    # (R5) a selected main is never also printed as superseded: the owner's exact name wins
    t13 = v38_tree("- Main pick: main-06 (primary); alternatives: main-03")
    (t13 / "images" / "main-06-v2.png").write_bytes(b"regen")
    s13 = scope.derive(t13)
    check("the owner's exact name races even when a -v2 sits beside it",
          s13["main"] == ["main-06.png", "main-03.png"], s13["main"])
    check("a name in the main race is not listed as superseded",
          "main-06.png" not in s13["superseded"], s13["superseded"])
    buf = _io.StringIO()
    with _cl.redirect_stdout(buf):
        scope.cmd_plan(str(t13))
    out = buf.getvalue()
    sup = [ln for ln in out.splitlines() if ln.startswith("Superseded")]
    check("plan does not print a raced main under Superseded",
          not any("main-06.png" in ln for ln in sup), sup)

    # (R6) a pick that lives only in images/pick/shortlist/ resolves to its real path
    t14 = v38_tree("- Main pick: m26 (primary); alternatives: main-03")
    (t14 / "images" / "pick" / "shortlist").mkdir(parents=True)
    (t14 / "images" / "pick" / "shortlist" / "m26.png").write_bytes(b"shortlist")
    s14 = scope.derive(t14)
    check("a shortlist-only pick is in the race", s14["main"][0] == "m26.png", s14["main"])
    check("its resolved path EXISTS on disk (not images/m26.png)",
          _P(s14["paths"]["m26.png"]).is_file() and _P(s14["paths"]["m26.png"]).read_bytes() == b"shortlist",
          s14["paths"].get("m26.png"))
    check("every lineup path exists on disk",
          all(_P(x).is_file() for x in s14["lineup_main"] + s14["lineup_gallery"]), s14["lineup_main"])

    _underscore_diagnostics()
    if FAILURES:
        print(f"FAILED ({len(FAILURES)}): " + ", ".join(FAILURES))
        return 1
    print("SCOPE: all green")
    return 0


if __name__ == "__main__":
    sys.exit(run())
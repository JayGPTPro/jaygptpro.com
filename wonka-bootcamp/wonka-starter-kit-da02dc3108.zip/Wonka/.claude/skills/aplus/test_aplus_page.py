#!/usr/bin/env python3
"""The A+ page stitcher, offline.

The page view is the only surface a human can judge an A+ on, so the two
things it must never get wrong are ORDER and HEIGHT. Order, because the
modules are read top to bottom and m10 sorts before m2 as a string. Height,
because Genrupt cuts one continuous design into modules: a single inserted
pixel between them splits a headline in half and makes correct work look
broken, which is exactly what the first version of the order sheet did.

Run: python3 test_aplus_page.py
"""
import sys
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

FAILURES = []


def check(name, cond, detail=""):
    print(("  PASS  " if cond else "  FAIL  ") + name + ("  " + str(detail) if not cond and detail else ""))
    if not cond:
        FAILURES.append(name)


def run():
    from PIL import Image
    import aplus_page

    tmp = Path(tempfile.mkdtemp())

    # 11 modules, so the string sort trap (m10, m11 before m2) is live, each a
    # flat unique shade so the stacking order is readable straight off the page
    shades = {}
    for n in range(1, 12):
        shade = (n * 20, 40, 200 - n * 10)
        shades[n] = shade
        Image.new("RGB", (100, 30), shade).save(tmp / f"m{n}-desktop.png")
    Image.new("RGB", (60, 20), (7, 7, 7)).save(tmp / "m1-mobile.png")
    # a re-generated module lands BESIDE the original after an edit round
    Image.new("RGB", (100, 30), (255, 255, 255)).save(tmp / "m4-desktop-v2.png")
    # noise that must be ignored
    Image.new("RGB", (50, 50), (1, 2, 3)).save(tmp / "reference.png")
    (tmp / "aplus-plan.md").write_text("not an image")

    # evidence beside a module, named the way the Fixing Room and the Face Clinic name it;
    # "-desktop-rejected" sorts before "-desktop." and used to win module 1 (10 September 2026)
    ev = tmp / "ev"; ev.mkdir()
    Image.new("RGB", (100, 30), (10, 10, 10)).save(ev / "amz-module-01-desktop.jpg")
    Image.new("RGB", (100, 30), (250, 250, 250)).save(ev / "amz-module-01-desktop-rejected.jpg")
    Image.new("RGB", (100, 30), (20, 20, 20)).save(ev / "amz-module-02-desktop.jpg")
    Image.new("RGB", (100, 30), (250, 0, 0)).save(ev / "amz-module-02-desktop-render.jpg")
    Image.new("RGB", (100, 30), (0, 250, 0)).save(ev / "amz-module-02-desktop-boxes.png")
    Image.new("RGB", (100, 60), (0, 0, 250)).save(ev / "seam-1-2-2x.png")
    Image.new("RGB", (100, 30), (0, 0, 250)).save(ev / "seam-1-2-1x.png")
    Image.new("RGB", (100, 30), (0, 250, 250)).save(ev / "amz-module-01-desktop-faces-fixed.jpg")
    evf = aplus_page.modules(ev, "desktop")
    check("a -rejected sibling never becomes the module, even though it sorts first",
          [f.name for f in evf] == ["amz-module-01-desktop.jpg", "amz-module-02-desktop.jpg"], [f.name for f in evf])
    aplus_page.build(ev)
    pg = Image.open(ev / "aplus-page-desktop.jpg").convert("RGB")
    check("the page's first strip is the adopted module, not the rejected render",
          pg.getpixel((50, 15))[0] < 40, pg.getpixel((50, 15)))
    d = aplus_page.verify(ev / "aplus-page-desktop.jpg", evf)
    check("read-back: every strip matches its source within re-encode noise", d and max(d) < aplus_page.VERIFY_MAX, d)
    bad = aplus_page.verify(ev / "aplus-page-desktop.jpg", [ev / "amz-module-01-desktop-rejected.jpg", evf[1]])
    check("read-back flags a strip built from a different file", bad and bad[0] > aplus_page.VERIFY_MAX, bad)

    written = aplus_page.build(tmp)
    names = {p.name for p, _, _ in written}
    check("both modes produce a page and an order sheet",
          names == {"aplus-page-desktop.jpg", "aplus-order-desktop.jpg",
                    "aplus-page-mobile.jpg", "aplus-order-mobile.jpg"}, sorted(names))

    files = aplus_page.modules(tmp, "desktop")
    check("11 modules, one per number, not 12", len(files) == 11, [f.name for f in files])
    check("numeric order, so m10 does not sort between m1 and m2",
          [f.stem.split("-")[0] for f in files] == [f"m{n}" for n in range(1, 12)],
          [f.name for f in files])
    check("the re-generated module replaces the original it superseded",
          files[3].name == "m4-desktop-v2.png", files[3].name)
    check("non-module files are ignored",
          not any("reference" in f.name for f in files))

    page = Image.open(tmp / "aplus-page-desktop.jpg")
    check("the page is exactly as tall as its modules, no inserted air",
          page.height == 11 * 30, page.height)
    check("and as wide as the widest module", page.width == 100, page.width)

    # read the middle of each band back: the page must be in page order
    got = [page.getpixel((50, n * 30 + 15))[2] for n in range(11)]
    want = [shades[n][2] for n in range(1, 12)]
    want[3] = 255  # the v2 module is white
    check("the bands come back in page order",
          all(abs(a - b) < 12 for a, b in zip(got, want)), f"got {got} want {want}")

    order = Image.open(tmp / "aplus-order-desktop.jpg")
    check("the order sheet is the SAME height as the page (badges overlay, never insert)",
          order.height == page.height, f"{order.height} vs {page.height}")

    # the badge must sit ON the module, so a pixel far from it is untouched
    check("the badge does not repaint the module it labels",
          abs(order.getpixel((90, 25))[2] - page.getpixel((90, 25))[2]) < 12,
          (order.getpixel((90, 25)), page.getpixel((90, 25))))

    mob = Image.open(tmp / "aplus-page-mobile.jpg")
    check("mobile stacks only mobile files", (mob.width, mob.height) == (60, 20), mob.size)

    empty = Path(tempfile.mkdtemp())
    check("a folder with no modules writes nothing rather than an empty page",
          aplus_page.build(empty) == [])

    print()
    # --- the export's own naming must be visible ----------------------------
    # /aplus's export writes export/<mode>/amz-module-NN-slug-<mode>.jpg. The
    # stitcher used to read only m<N> files at the top level, so it could not
    # see the files the room itself produced. Measured 27 August 2026.
    import tempfile as _tf
    from pathlib import Path as _P
    ex = _P(_tf.mkdtemp()) / "aplus"
    (ex / "export" / "desktop").mkdir(parents=True)
    (ex / "export" / "mobile").mkdir(parents=True)
    for n, w, h in (("amz-module-01-hero-image-desktop.jpg", 40, 20),
                    ("amz-module-02-side-image-text-desktop.jpg", 40, 20),
                    ("amz-module-10-hero-image-desktop.jpg", 40, 20)):
        Image.new("RGB", (w, h), "white").save(ex / "export" / "desktop" / n)
    Image.new("RGB", (30, 30), "white").save(
        ex / "export" / "mobile" / "amz-module-01-hero-image-mobile.jpg")
    got = [f.name for f in aplus_page.modules(ex, "desktop")]
    check("the export's module files are found", len(got) == 3, got)
    check("and they land in page order, 10 after 2",
          bool(got) and got[-1].startswith("amz-module-10"), got)
    check("the mobile export is not mixed into the desktop page",
          all("mobile" not in g for g in got), got)

    # --- the mode can sit anywhere after the number ---------------------------
    # m1-hero-mobile.png used to enter the DESKTOP page because the parser read
    # the mode only right after the number (reproduced 6 September 2026). And an
    # untagged file in a folder that carries mode tags belongs to neither page.
    mx = _P(_tf.mkdtemp()) / "aplus"
    mx.mkdir(parents=True)
    for n in ("m1-desktop.png", "m1-hero-mobile.png", "m2-desktop.png", "m2-mobile.png", "m3.png"):
        Image.new("RGB", (20, 10), "white").save(mx / n)
    got_d = [f.name for f in aplus_page.modules(mx, "desktop")]
    got_m = [f.name for f in aplus_page.modules(mx, "mobile")]
    check("desktop page takes only the desktop-tagged files",
          got_d == ["m1-desktop.png", "m2-desktop.png"], got_d)
    check("mobile page takes the mobile file whose tag sits after a slug",
          got_m == ["m1-hero-mobile.png", "m2-mobile.png"], got_m)
    check("an untagged file in a mixed folder enters neither page",
          "m3.png" not in got_d + got_m, got_d + got_m)
    only = _P(_tf.mkdtemp()) / "aplus"
    only.mkdir(parents=True)
    Image.new("RGB", (20, 10), "white").save(only / "m1.png")
    check("an untagged file in an untagged folder still builds the page",
          [f.name for f in aplus_page.modules(only, "desktop")] == ["m1.png"])

    print()
    # --- ONE evidence rule, shared with the Face Clinic (kit v36) -------------
    # v35 kept two copies: the page builder skipped `-boxes`, the clinic's
    # is_evidence() did not, so a drawn-box copy could be adopted as a module.
    sys.path.insert(0, str(HERE.parent / "fix-faces"))
    import face_fix
    names = ["amz-module-01-desktop-boxes.jpg", "m1_boxes.png", "m1-desktop-rejected.jpg", "m2-desktop-render.jpg",
             "sec-05_fix2.png", "m1-desktop-faces-fixed.jpg", "seam-1-2-2x.png", "m1-desktop.jpg",
             "amz-module-03-hero-image-desktop.jpg", "sec-03-v2.png"]
    agree = [n for n in names if aplus_page.is_evidence(n) == face_fix.is_evidence(n) == bool(aplus_page.EVIDENCE.match(_P(n).stem))]
    check("the builder, its fallback regex and the clinic agree on every evidence name", agree == names,
          [n for n in names if n not in agree])
    check("a drawn-box copy is evidence under both suffix separators",
          all(aplus_page.is_evidence(n) for n in ("amz-module-01-desktop-boxes.jpg", "m1_boxes.png")))
    check("a module and a generation's -v2 are not evidence",
          not aplus_page.is_evidence("m1-desktop.jpg") and not aplus_page.is_evidence("sec-03-v2.png"))

    # --- a tie is resolved against the accepted list or stops the build (kit v36) ---
    # v35 warned and kept the first: the page then proved assembly from whatever sorted first.
    tie = _P(_tf.mkdtemp()) / "aplus"
    tie.mkdir(parents=True)
    Image.new("RGB", (20, 10), (1, 1, 1)).save(tie / "m1-desktop.png")
    Image.new("RGB", (20, 10), (2, 2, 2)).save(tie / "m1-hero-desktop.png")
    try:
        aplus_page.modules(tie, "desktop")
        stopped = False
    except SystemExit:
        stopped = True
    check("two files claiming the same module and version with no manifest STOP the build", stopped)
    (tie / "round.md").write_text("# edits/v2\n\n| file | adopted from |\n|---|---|\n| aplus/desktop/m1-hero-desktop.png | aplus/export/desktop/m1-hero-desktop.png |\n")
    got = [f.name for f in aplus_page.modules(tie, "desktop")]
    check("with round.md naming the one that ships, the tie resolves to it", got == ["m1-hero-desktop.png"], got)
    got = [f.name for f in aplus_page.modules(tie, "desktop", accepted={"m1-desktop.png"})]
    check("an explicit accepted list wins the tie the same way", got == ["m1-desktop.png"], got)
    # a tie on the MOBILE set: "Nothing built" must be true, so the desktop page is not written first
    # (reproduced 10 September 2026: the desktop page was on disk when the mobile tie stopped the build)
    tie2 = _P(_tf.mkdtemp()) / "aplus"
    tie2.mkdir(parents=True)
    Image.new("RGB", (20, 10), (1, 1, 1)).save(tie2 / "m1-desktop.png")
    Image.new("RGB", (20, 10), (2, 2, 2)).save(tie2 / "m1-mobile.png")
    Image.new("RGB", (20, 10), (3, 3, 3)).save(tie2 / "m1-hero-mobile.png")
    try:
        aplus_page.build(tie2)
        stopped = False
    except SystemExit:
        stopped = True
    check("a tie on the mobile set stops the build", stopped)
    check("and nothing is built: no desktop page is on disk when the build says so",
          not (tie2 / "aplus-page-desktop.jpg").exists(), sorted(f.name for f in tie2.iterdir()))

    if FAILURES:
        print(f"FAILED ({len(FAILURES)}): " + ", ".join(FAILURES))
        return 1
    print("A+ PAGE: all green")
    return 0


if __name__ == "__main__":
    sys.exit(run())

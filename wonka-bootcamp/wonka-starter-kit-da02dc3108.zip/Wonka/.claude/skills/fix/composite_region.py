#!/usr/bin/env python3
"""Keep everything outside the fix byte-identical.

The OpenAI edit endpoint re-renders the WHOLE frame, so a local fix (a part moved, a marking
restored, an object reshaped) comes back with the rest of the picture slightly different: text
re-typeset, the other product resized, the framing drifted. Measured on the Day 6 secondary set,
7 September 2026: a tower re-centred on the left machine came back with both machines smaller
and the jug reshaped, and the whole edit was rejected for the drift.

This tool takes the changed REGION from the render and pastes it back onto the edit base, with a
feathered edge, so only the region changes and every other pixel is the base's own:

  python3 .claude/skills/fix/composite_region.py <base.png> <render.png> <out.png> x,y,w,h [x,y,w,h ...] [--feather 24]

To SHOW the boxes before spending (the proof that none cuts a person, an object or a word):

  python3 .claude/skills/fix/composite_region.py --draw <base.png> <out-boxes.png> x,y,w,h [x,y,w,h ...]

Boxes are in the base's pixels. The render is resized to the base's size first (the endpoint
returns its own working size). The feather runs INWARD: the soft edge lives inside the box, it
reaches the base AT the box's boundary (a smooth ramp by distance to the nearest edge, from 0 on
the first pixel inside to full strength `feather` pixels in; no ramp on a side that meets the image
edge), and the mask is 0 outside the union of the boxes, so no pixel outside that union can change.
Kit v28 to v35 blurred an inset rectangle and clipped it, which kept the outside untouched and left
about 40 of 255 on the first pixel inside (a visible step whatever the outside count said; reproduced
10 September 2026). The tool prints the mask's opacity on that first ring and refuses above 8.
Boxes are validated before anything is written (inside the image, non-empty, twice the feather
smaller than the box's short side, so the render still lands at full strength in the middle) and the tool exits non-zero with a plain message otherwise.

Prints how many pixels changed outside the boxes (must be 0) and inside them, so the log carries
a number instead of an impression. Both counts are measured against the plain box union, never
against the blurred mask the output was built from (v28 measured against the blurred mask, so
every pixel the blur leaked into counted as "inside" and the tool printed 0 outside while 10,125
pixels outside the box had changed). The eye still verifies the seam and the region afterwards
(fix skill step 9): a paste edge must never cross the object.
"""
import sys
import numpy as np
from PIL import Image, ImageDraw, ImageFilter

def parse_boxes(boxes, size, feather):
    """Return [(x, y, w, h)] or exit with a plain message. Nothing is written before this passes."""
    W, H = size
    if feather < 0: sys.exit(f"feather must be 0 or more, got {feather}")
    out = []
    for b in boxes:
        parts = b.split(",")
        if len(parts) != 4 or not all(p.strip().lstrip("-").isdigit() for p in parts):
            sys.exit(f"bad box {b!r}: expected x,y,w,h as four integers")
        x, y, w, h = [int(p) for p in parts]
        if w <= 0 or h <= 0: sys.exit(f"empty box {b!r}: width and height must be at least 1")
        if x < 0 or y < 0 or x + w > W or y + h > H:
            sys.exit(f"box {b!r} falls outside the {W}x{H} base image")
        if 2 * feather >= min(w, h):
            sys.exit(f"feather {feather} is too large for box {b!r} ({w}x{h}): twice the feather must be smaller than the box's short side; shrink the feather or grow the box")
        out.append((x, y, w, h))
    return out

def draw(argv):
    """--draw <base> <out> x,y,w,h [...]: render the boxes on a copy of the base, write nothing else.
    The drawn copy is the proof, before any spend, that no box cuts through a person, an object or
    a word (fix skill step 7b, the box rules). Same box syntax and the same validation as the composite."""
    if len(argv) < 3: sys.exit("--draw needs: <base> <out> x,y,w,h [x,y,w,h ...]")
    base_p, out_p, *raw_boxes = argv
    base = Image.open(base_p).convert("RGB")
    boxes = parse_boxes(raw_boxes, base.size, 0)
    im = base.copy(); d = ImageDraw.Draw(im)
    lw = max(3, min(base.size) // 300)
    for i, (x, y, w, h) in enumerate(boxes, 1):
        d.rectangle([x, y, x + w - 1, y + h - 1], outline=(255, 40, 40), width=lw)
        d.rectangle([x, y, x + 26 * lw, y + 8 * lw], fill=(255, 40, 40))
        d.text((x + 2 * lw, y + lw), f"{i}: {x},{y},{w},{h}", fill=(255, 255, 255))
    im.save(out_p)
    print(f"wrote {out_p}: {len(boxes)} box(es) drawn on a copy of {base_p}; nothing composited")

def main():
    argv = sys.argv[1:]; feather = 24
    if argv and argv[0] == "--draw": return draw(argv[1:])
    if "--feather" in argv:
        i = argv.index("--feather")
        if i + 1 >= len(argv) or not argv[i + 1].lstrip("-").isdigit(): sys.exit("--feather needs an integer")
        feather = int(argv[i + 1]); del argv[i:i + 2]
    args = argv
    if len(args) < 4: sys.exit(__doc__)
    base_p, render_p, out_p, *raw_boxes = args
    base = Image.open(base_p).convert("RGB"); render = Image.open(render_p).convert("RGB")
    boxes = parse_boxes(raw_boxes, base.size, feather)
    if render.size != base.size: render = render.resize(base.size, Image.LANCZOS)

    # The allowed area: a plain binary union of the boxes as given. This is the contract.
    W, H = base.size
    allowed = np.zeros((H, W), bool)
    for x, y, w, h in boxes: allowed[y:y + h, x:x + w] = True

    # The blend mask: inside each box a smooth ramp by the pixel's distance to the nearest box edge
    # (near 0 on the first pixel inside, 255 from `feather` pixels in), boxes union by max, and 0
    # outside the allowed area, so the soft edge lives inside the box, reaches the base at its
    # boundary, and nothing outside it can change.
    mask = feather_mask(base.size, boxes, feather)
    m = np.asarray(mask).copy(); m[~allowed] = 0
    mask = Image.fromarray(m, "L")
    ring = boundary_ring_max(m, allowed)
    if feather and ring > RING_LIMIT:            # feather 0 is a hard edge asked for by name
        sys.exit(f"the blend is {ring}/255 on the first pixel inside a box (limit {RING_LIMIT}); the feather must reach the base at the boundary. Nothing written")

    out = Image.composite(render, base, mask)
    a, o = np.asarray(base), np.asarray(out).copy()
    o[~allowed] = a[~allowed]                     # belt and braces: outside the union is the base, byte for byte
    out = Image.fromarray(o, "RGB")
    changed = (np.abs(a.astype(int) - o.astype(int)).sum(2) > 0)
    outside = int(changed[~allowed].sum()); inside = int(changed[allowed].sum())
    if outside:
        sys.exit("composite touched pixels outside the boxes; nothing written. Check the boxes and the feather")
    out.save(out_p)
    print(f"wrote {out_p}: {inside} pixels changed inside the region, {outside} outside (must be 0); blend {ring}/255 on the first ring inside (must be {RING_LIMIT} or under)")


RING_LIMIT = 8   # max mask opacity (of 255) on the first ring inside a box


def feather_mask(size, boxes, feather):
    """0 outside every box; inside, smoothstep of (distance to the nearest box edge) / feather, where the
    first pixel inside is distance 0 (the base, exactly) and `feather` pixels in is full strength; no
    ramp on a side that meets the image edge. Boxes are (x, y, w, h)."""
    W, H = size
    m = np.zeros((H, W), np.float64)
    inf = float("inf")
    for x, y, w, h in boxes:
        x1, y1, x2, y2 = x, y, x + w, y + h
        xs = np.arange(x1, x2, dtype=np.float64); ys = np.arange(y1, y2, dtype=np.float64)
        dx = np.minimum(xs - x1 if x1 > 0 else inf, x2 - 1 - xs if x2 < W else inf)
        dy = np.minimum(ys - y1 if y1 > 0 else inf, y2 - 1 - ys if y2 < H else inf)
        d = np.minimum.outer(dy, dx)
        t = np.clip(d / feather, 0.0, 1.0) if feather else np.ones_like(d)
        m[y1:y2, x1:x2] = np.maximum(m[y1:y2, x1:x2], 255.0 * t * t * (3.0 - 2.0 * t))
    return Image.fromarray(np.round(m).astype("uint8"), "L")


def boundary_ring_max(m, allowed):
    """The highest mask value on the first ring INSIDE the allowed area (a pixel inside with a
    4-neighbour outside), image edges excluded. Near 0 means the blend reaches the base at the boundary."""
    pad = np.pad(allowed, 1, constant_values=False)
    outside_neighbour = (~pad[:-2, 1:-1]) | (~pad[2:, 1:-1]) | (~pad[1:-1, :-2]) | (~pad[1:-1, 2:])
    edge = np.zeros_like(allowed); edge[0, :] = edge[-1, :] = True; edge[:, 0] = edge[:, -1] = True
    ring = allowed & outside_neighbour & ~edge
    return int(np.asarray(m, dtype=int)[ring].max()) if ring.any() else 0

if __name__ == "__main__":
    main()

---
name: reference-sheet
description: Build the Product Reference Sheet, the collage Genrupt generates from the owner's photos that locks front, side, back, detail, scale and material identity, revise it until the owner approves it, then prove the lock with a smoke test that generates ONE image per slot and reads it for two different failures: is this my product, and is this the brief I actually wanted. Use before any image batch, or when the user is ready to prepare their product photos for generation. Also the room that wires a real supplied logo into Genrupt (upload, branding preset, attach, verify), independently of any brand styling; when no logo was supplied it skips that silently. Triggers: /reference-sheet, "lock the product", "reference photos", "product reference", "build the reference sheet", "smoke test", "the mold", "wire my logo", "I have a logo", "attach the logo", "here is our logo".
---

# The Reference Room

| Meta | Value |
|------|-------|
| Room | The Reference Room |
| Station | INVENT gate. No blast runs until the reference sheet is APPROVED and the smoke test has PASSED |
| Taught on | Day 4, both lessons. Lesson 1 builds, corrects and approves the sheets; lesson 2 is the smoke test. Runs again whenever a new product enters the Factory |
| Needs | The product folder with `status.md`; the owner's own product photos in `2-reference/photos/` (all angles + one hand-for-scale + label close-ups), or an explicitly approved fallback; ONE working generation machine (Genrupt MCP, or the OpenAI key on the fallback path). For the smoke test specifically: the approved plan `/creative-brief` saved, because the smoke test renders the brief |
| Saves to | factory/Products/[product]/2-reference/ (reference-sheet.md, sheet-v[N].png, smoke-test-v[N]/; the owner's source photos stay in 2-reference/photos/, a supplied logo in 2-reference/logo/, a Brand Book or Style Guide in 2-reference/brand/). Also writes the `Logo source`, `Genrupt preset ID` and `Logo in preset` rows of status.md |
| Typical cost | Each reference-sheet version, plus one image per slot per smoke-test attempt. Cheap on purpose: the smoke test runs at `requestedCount: 1`, the lowest setting Genrupt exposes. **Report the cost, do not ask permission.** The owner approved the brief; that approval carries through to the reference and the smoke test. Say what each step cost, in one line, after it runs. |

## What this room does

A reference made from guesses produces images shaped like guesses. This room does two jobs, and the second one is the one everybody skips.

1. **Lock.** The owner's photos become a **Product Reference Sheet**: a single collage Genrupt generates, locking front, side, back, detail, scale and material identity in one image. It is not a document, it is a picture, and every image the factory makes afterwards is poured from it. It is generated, reviewed against real criteria, REVISED until it is right, and only then approved. The spec written in step 2 is what the sheet gets judged against and the raw material for the clean `product.description`. Reference sheet plus a clean description ARE the accuracy mechanism (intake guide, section 3). A "glass, not plastic" sentence in a brief is a backstop, never the lock.
2. **Prove.** The smoke test generates **ONE image per slot** off the approved plan, at the cheapest setting, and the owner reads the result for TWO different failures:
   - **Is this my product?** Wrong parts, wrong materials, wrong scale, invented decoration. A fidelity failure is a REFERENCE problem: the fix is a new sheet version, never a nicer prompt.
   - **Is this the brief I actually wanted?** Plenty of people cannot judge a brief until they see it rendered. "I do not want that frame at all" is a legitimate and valuable thing to discover here. A brief failure is a BRIEF problem: the fix is an edit to the plan, never a re-roll of the image.
   **What is NOT being judged here: fonts, colors, composition, polish.** Not because they do not matter, but because they are chosen later, from far more options, and judging them now makes people reject a good frame for a bad reason. Say this out loud before showing the images.

A reference can sit there marked approved and still produce the wrong product. **Approved is a status. Eyes on generated images are the evidence.**

A beautiful image of the wrong product is worth less than no image at all, and it is a returns problem and a compliance problem at the same time. This room is the only insurance against it, and every room downstream inherits whatever quality it gets here.

## The words rule (read this before anything below)

**Wonka's own words never describe how the product LOOKS.** Every sheet is generated from the
photos plus text (`notes` on the first sheet, `editInstructions` on every revision), and every
listing image is generated from the sheets plus text (the product description, the bullets, every
slot's brief and custom instructions). The model treats images as reference and text as a
COMMAND, so a sentence that describes a shape, a slant, a taper, a curve, a proportion, a finish or
a working state will be rendered as written, even when every photo says otherwise. Measured 2
September 2026: the demo product's working-state sheet was instructed, in Wonka's words, to show
"separated strands with visible gaps" because Wonka had read the reviews that way; four rounds of
new photos changed nothing, because the sentence rode along on every revision; the sheet healed in
ONE round the moment the sentence was reversed. Measured the same week on another product: four
wooden utensils rendered with a reversed slant, a square tip and a missing flare, each one a shape
Claude had described from an angled, overlapping photo and described wrong.

So, in every text field this room sends:
- **Allowed:** facts a photo cannot show. Counts and families, what is one piece and what
  separates, the material of each part, what is printed or embossed and where, the confirmed
  dimensions, what must not be invented, the job of the image and the scene around the product.
- **Forbidden:** appearance in Wonka's own words. Silhouette, slant, taper, curvature, proportion,
  finish, how the flow or the light or the fabric "looks". The photos and the sheets carry that,
  and the sheets selected in Project Setup are what every generation and every blast reads.
- **The one exception:** an appearance statement the OWNER made while looking at a real photo, or
  a ratio measured off a real photo. Those are written as the owner's words, attributed, and never
  extended by Wonka.
- **Before every send, every sentence is read against the source photos.** A sentence that
  contradicts a photo is deleted, not softened. A shape or state that came out wrong is fixed with
  a better photo first (overhead, flat, separated, or the product running), and only then with a
  fact.
- **The owner sees the exact string.** Before `notes`, `editInstructions` or a plan save goes out,
  Wonka shows the text verbatim, not a summary of it, because the summary is where a wrong
  sentence hides.

## Before you start

**A judgement the owner cannot see is not a judgement they made.** Every time this room asks the owner to decide about an image, the image is delivered as a file FIRST. Full size, one file per artefact.

Check these in order. Any miss = station **BLOCKED**, named out loud, with a pointer.

1. **The product.** `factory/Products/[product]/` exists with its `status.md`. Missing: point to `/meet-my-product` and stop. If more than one product folder exists, ASK which product this run is for. Never guess from the newest folder, and never build a reference against a folder the user did not name. **The approved creative brief IS a precondition for the smoke test** (step 6), because the smoke test renders the plan rather than a generic prompt. Building and approving the reference sheet (steps 1 to 4c) does NOT need the brief and may run first.
2. **A machine for the smoke test.** Genrupt MCP connected (Path A, primary) or the OpenAI key present (Path B, fallback). If Genrupt was expected but is not answering, say so and offer the fallback explicitly; never switch paths silently. If NEITHER machine is available, the inventory and the spec can still be written, but the room ends PARKED (see "If the smoke test cannot run"). Never write LOCKED without a passed smoke test.
3. **The photos, asked for FIRST, every time.** The required set:

| Shot | Why it exists |
|---|---|
| Front | the face of the product, the angle every image starts from |
| Back | skip it and the model invents your back label, every time |
| Both sides (2 shots) | shape and depth, so the product is not rendered flat |
| Top down | lids, openings, tier counts, anything only visible from above |
| One scale cue | scale is the single thing image models get most wrong, and a dimension in inches does not fix it. For a product you HOLD, a hand or a forearm in frame. For a product that SITS on a surface, a familiar object or the environment itself, a table, a counter, a sink. Genrupt has a real setting for this (`scaleReferenceMode`, handheld or tabletop): read the schema, pick the one that matches the product, and say which you picked |
| Label and texture close-ups | so label text and finish get copied instead of approximated |

Saved into `2-reference/photos/` inside the product folder (create the folder if it is missing). Phone photos in decent light are fine, **completeness beats beauty**: a blurry back shot that shows the real label outranks a pretty front shot that shows nothing new, because these photos BUILD the sheet (`sourceImageUrls` on `create_product_reference_sheet`); they are never routed into `productImages`, the approved sheet takes that place. Box, pouch, and label-panel photos are collected too; they route to `references.packagingImages`. If `/meet-my-product` already collected photos into `2-reference/photos/`, inventory what is there instead of asking for them again.

**Two sources are never allowed in a reference:**
- **A competitor's photo.** It locks THEIR product, their angle, their lighting. Competitors belong in the teardown as the benchmark to match and beat, never in the reference.
- **Any AI-generated image, including one this Factory made.** A reference built from a generation locks that generation's mistakes and compounds them.

**One product class needs a different path, and it is named at the anatomy contract, not after five rounds.** A product whose identity IS exact printed text, numerals or a logo on a visible face (a numbered tongue drum, a dial, a printed gauge, a labelled keypad, a board game with printed squares) is a case the generation path cannot fully serve: the model redraws a reference, it never copies it, and small glyphs, number sequences and logos come back approximated even from a perfect sheet with no prose in the way. Reference images plus the words rule fix counts, shape and materials; they do not make text pixel-accurate. So: say it to the owner at step 1b, do not promise a faithful face from generation, keep the sheets and every slot that does not depend on reading the face on the normal path, and for the one or two slots that must show the face exactly, plan a real photo composited into the generated scene (an empty frame generated to size, then the real face placed in it). That is an image operation, not a prompt, so it breaks nothing in the words rule.

**"I don't have that" is a first class answer.** Every version of it has a defined path, and none of them is a dead end:

| The user says | What happens |
|---|---|
| "I have no photos of my own and cannot take any" | The fallback: the product's OWN listing gallery plus CUSTOMER REVIEW images. Only on explicit approval in plain words, after you name what gets weaker. A generic "continue" is not approval. Ask it straight: "shall I build the reference from the listing gallery and the review photos only, accepting weaker size and back-of-product accuracy?" On a yes, record `source: amazon_scraped` with the approval date, and say plainly that the smoke test now matters double |
| "I have some shots but not all of them" | Named gap waiver. Record each accepted gap and what the model is now free to invent because of it. Proceed |
| "I don't have Genrupt" | Path B, recorded as `gpt_image_fallback`. The lock is genuinely weaker and the written spec carries the weight. Say so rather than implying the lock is as strong |
| "I have neither machine right now" | Inventory and spec still get written. The room ends PARKED with the smoke test owed, and INVENT stays closed |
| "I have no product and no listing images at all" | There is nothing to lock, and pretending otherwise would be a fake artifact. Say so plainly and close the room. `/creative-brief` can run meanwhile |
| The product is not live yet (`status.md` says `Live | no`) | No listing gallery and no review photos exist, so there is no fallback: the sheet is built from the owner's real photos or the room closes. Say that plainly at the inventory |

**On the fallback path, mine the customer review images.** A brand gallery is lit to sell and skips exactly the angles a reference needs most. A review photo is the product on a real counter, at its real size, from angles no brand ever shoots. On that path they are the best input in the folder. This is also how the bootcamp's on-camera demo runs, because that listing belongs to another seller and there is no unit in the room. Say that plainly whenever it comes up, and hold the owner to real photos of their own product.

## Process

0. **Inventory what the owner already gave you, and sort it into three kinds.** Everything the owner
   supplied on Day 2 (or attached since) is already filed. Before anything else, LIST
   `2-reference/photos/` and `2-reference/logo/` and separate:
   - **Real product photos** . they BUILD the sheet (`sourceImageUrls` / `sourceAssetIds` on `create_product_reference_sheet`). Once a sheet is approved, the sheet is the reference and the photos' job is done (step 4c).
   - **Real packaging photos** (box, pouch, sleeve, label panel) . they go to `references.packagingImages` (step 4c).
   - **A real logo asset** . it goes nowhere near either bucket. Its only lawful route is a Genrupt
     branding preset (step 4f).

   **If `2-reference/logo/` is empty, say nothing and carry on.** No question, no warning, no pending
   marker. A product without a logo is the normal case and is never blocked by it. If the owner
   attaches a logo later, at any point, file it and run step 4f alone.

1. **Inventory the sources.** LIST the folder first. `2-reference/photos/` on disk is the only source; a photo the owner pasted into a chat is viewable but never landed there, so if the owner says the photos are in and the folder is empty, that is what happened: ask them to drop the files in, and list again. Never inventory from memory of what was shown. Then compare what is actually there against the required set, as a table, and name what each gap COSTS in the model's behavior, not just that it is missing ("no back shot, so the model will invent your back label"). Ask the user to fill the gaps or waive them by name. Then make provenance visible in the folder itself: rename source files so anyone can see where they came from (`own-front.jpg`, `gallery-01.jpg`, `review-photo-02.jpg`). Provenance that lives only inside a markdown file is provenance nobody checks. While inventorying, write the one-line NOTE each image will carry into Genrupt: what this image establishes ("back label, exact text", "hand for scale, true size", "matte finish close-up"). The note field is the one place a sentence of context belongs.

   **Then triage the folder, because not every photo in it is of THIS product.** Two checks, both done before a single photo feeds the spec:

   - **Is this the right variant?** Sellers photograph their whole family in one session, so the folder often holds the 6-piece set next to the 10-piece set, or last season's colorway. For each photo, check the piece count, the colorway and the size or format against the listing title and the packaging shot. Anything that disagrees is renamed and moved to `2-reference/photos/_other-variant/` with a one-line reason. Keep it, do not delete it: it is still honest evidence of the shape and the material, just not of THIS SKU. The failure it prevents is quiet and total, a reference locked on the neighbouring variant, so every image afterwards is confidently the wrong product.
   - **What is this photo NOT authoritative for?** Add that to the note column beside what it establishes. The rule that matters most: **a count claim may only cite a packaging shot or a clean laid-out shot, never a stacked, fanned, or held-in-hand photo.** Counting pieces in a pile is guessing with extra steps, and a wrong part count in the spec becomes a wrong part count in every generation.

   **Packaging is on the required list, not the optional one, and it is asked for BY NAME** (`box-front`, `box-back`, `label-panel`). It is a separate bucket from the product photos and it unlocks a real hero strategy on Day 5. If the answer is "my product has no packaging a buyer ever sees", record that as a deliberate skip rather than a silent gap.

1b. **Write the ANATOMY CONTRACT, and get it confirmed, before a single sheet is generated.** This
   is the short list of physical facts every sheet and every later image is graded against, and it is
   the one thing worth interrupting the owner for. It exists because a product's own marketing name
   routinely lies about its geometry: "four tier" made this bootcamp's demo machine look like it has
   four domes when it has a crown cup and three. Write it as countable facts, not prose:
   - Every countable family and its exact number ("1 crown cup, 3 domes, 2 columns, 2 spacer rings,
     1 auger with 9 flights"), and what is NOT a member of a family ("the catch bowl is not a tier").
   - What is one integrated piece and what separates.
   - Materials per part, in plain words.
   - Text and controls: what is printed or embossed, where it sits, what the switches say.
   - For a product that changes when it runs, WHICH PHOTO shows the working state. The contract
     points at the photo; it does not describe the state in words. If no such photo exists, ask for
     one before any sheet is built, because a working state written from reviews or from
     imagination is the single most expensive sentence this room can produce (see the words rule).
   The contract is facts, never appearance. Show it to the owner in one short block and ask them to
   confirm or correct it. **Their correction
   outranks anything Wonka read off a photo**, and it is written into `reference-sheet.md` before any
   sheet is built. Every later check in this room, and every edit instruction, quotes this contract.

2. **Write the product spec.** This is what the smoke test gets judged against, so write it like a manufacturer, not like an art director:
   - Overall size and dimensions, and weight if known
   - **Every countable thing, counted** (tiers, lids, compartments, cables, pieces in the box)
   - Material and finish PER PART (a stainless steel base with plastic tiers is two materials, and saying so is the difference between premium and cheap on screen)
   - Every included part and accessory
   - Label text exactly as printed, and the brand name spelled as it is spelled
   - Colors, product and label
   - Power, voltage, plug type, where it applies

   **Every line carries its source**: seen in photo [file], stated by the owner, or read off the listing. **Never invent a spec value.** If something cannot be seen or confirmed, write `unknown` and say out loud that the model is now free to invent it. `unknown` is a legitimate spec value; a confident guess is a defect that ships.

   The spec does double duty: it is what the smoke test gets judged against, and it is the raw material for the clean `product.description` that goes to Genrupt in step 4. `unknown` values never enter the description; only confirmed facts do.

   **The anatomy pass, at magnification, for any product with fine parts.** A spec lists parts; an anatomy table records, per part, its count, its family, what it joins to and what is printed on it, and it can only be written from MAGNIFIED source photos. Shape is not written into the table: it is pointed at, as a saved crop, because a shape put into words is a shape the sheet will render from the words. Crop and zoom the best photos into the actual regions, because a full-frame look at gallery size cannot tell a ferrule's true color or a neck's proportion (measured 27 August 2026: three sheet rounds were fought over defects one magnified look at the source would have named on round one, and one edit instruction Wonka authored was itself anatomically wrong, so the mold was being corrected TOWARD an error). Write into `reference-sheet.md` an anatomy table, every part from tip to tail: shape, proportion as a MEASURED RATIO, color, material, printed text. This table is written BEFORE the first sheet, and it is the contract every sheet version is graded against.

   **Measure every fact on at least TWO photos, in different light.** A single photo lies about color and about ratio: measured 27 August 2026, a hue and a proportion taken off ONE cold-daylight macro came out "gunmetal" and 4-5:1, and both were wrong; the true warm brass appeared only when a second photo was measured. A fact the folder can only support from one photo is written into the table marked `single-source`, and it is the FIRST suspect whenever a sheet round contradicts the table.

   **And the contract outranks every approval built on it.** "Closed" and "closed on a wrong measurement" are different states: when a later magnified look contradicts the anatomy table, correct the TABLE first, and every approval graded against the old table reopens, the primary sheet's APPROVED stamp included. Measured 27 August 2026: an identity sheet was approved against a mis-measured spec (dark gunmetal, hidden tufts, no crimp ring); the honest re-measurement said warm brass, a silver crimp ring, and real tufts, a materially different product, and it surfaced only because a later round was read against the SOURCE again instead of against the approved sheet. An approval inherits the spec's authority; it never outranks it, and a wrong spec that stays closed ships in all forty images downstream.

3. **Report the cost, do not ask for permission.** The owner approved the brief; that approval carries through this room. Say what is about to run and what it will cost in one line, the number taken from a live `get_credit_balance_and_costs` preview's `finalCreditsCost` (CLAUDE.md, Genrupt contract rule 7; the base figure runs 3 to 8 times higher and is never quotable): "building the reference sheet, then one image per slot at the lowest setting, about [N] credits". Then run it, then say what it actually cost. **Never park the room waiting for a go-ahead on a cost the brief approval already covered.** The one exception is a THIRD failed smoke-test round: at that point stop, diagnose, and let the owner decide whether to keep spending (step 6).

4. **Build the reference sheet. Path A: Genrupt (primary).** This is the highest-leverage step in the whole factory. Never rush it and never accept the first draft out of politeness.
   - Upload every source photo through Genrupt's upload path (find the upload capability with `search_capabilities` and READ ITS INPUT SCHEMA before calling; the CLI bridge is the alternative, per `guides/mcp-setup-guide.md`). Wait for COMPLETED asset URLs. Local file paths are rejected; HTTPS asset URLs are the only currency here.
   - **Generate the sheet with `create_product_reference_sheet`.** It is a background operation: it returns an `operationId`, so poll with `wait_for_operation` or `get_operation_status` until the draft sheet is ready. Pass:
     - `sourceImageUrls` (or `sourceAssetIds` from a completed upload), up to 12. Completeness beats beauty: front, back, both sides, top, the hand-for-scale shot, label and texture close-ups.
     - `asin`, `productTitle` AND `projectId` (the project the plan lives in, read from `get_current_work_context`, never typed from memory). With all three, approving the sheet applies it to that project's setups by itself (the contract since September 2026); without `projectId` the approval ties the sheet to the profile only and the attach becomes a manual write. On the pre-launch route `asin` is the `Anchor ASIN` from `status.md`, `productTitle` is the OWNER'S title and `projectId` is the Day 3 flow's project (created with an empty bucket; the approval below is what puts the sheet in it, and the read-back before the smoke test shows it as the only `productImages` entry); the sheet is then tied to the anchor's product profile, which is fine, the sheet is the content and the anchor is the key. **Before creating anything, search first**: `find_product_reference_sheets` with the ASIN and `status: "approved"`. A hit is REUSED, never recreated, with one exception on the anchor route: the ASIN there is the competitor's, so a hit may be the COMPETITOR'S sheet. Reuse it only when its `productTitle` is the owner's title; any other hit is reported by its title and a new sheet is created, with `additionalSheet: true` if the tool refuses a second primary under that ASIN (`PRODUCT_REFERENCE_SHEET_ALREADY_EXISTS`); `status: "all"` returns one preferred version per product profile with drafts first, so it hides approved sheets behind their own drafts (measured 9 September 2026 on the demo product, whose approved sheet only surfaced under `approved`). And never submit a second creation while one is still running; wait for the operation to finish or fail first.
     - `scaleReferenceMode`. Default `auto`. **This is the structured version of "put a hand in it", so use it rather than hoping.** `handheld` or `hand_or_forearm` for anything held; `tabletop` or `sink_or_counter` for anything that sits somewhere; `none` only when the owner explicitly does not want a scale cue. Scale is the single thing image models get most wrong, and a dimension in inches does not fix it.
     - `packagingMode`. Default `exclude`, and it should almost always stay there. Use `include_separate_panel` ONLY when the owner explicitly wants packaging in the mold itself, and say the tradeoff out loud: anything in the sheet bleeds into everything poured from it. **Leaving it excluded does NOT throw the packaging away**, and say that out loud too, because it worries people. The packaging photos live in their own bucket and that is what drives the packaging main-image tactic on Day 5. **But a bucket is not a lock.** `packagingImages` preserves the real packaging as reference photos; it does not lock its geometry the way a sheet does. So check the slot plan: if the packaging itself STARS anywhere (a packaging main-image tactic, a protection or unboxing slot), it needs its own ADDITIONAL sheet, see "One product, up to five sheets" below. Measured 27 August 2026: a tube-and-sleeve product ran with `exclude` and a full packaging bucket, and the tube still had zero geometry lock while an entire slot was built around it, so the machine would have invented the tube.
     - `notes`, and only for what the photos cannot show: exact size, material per part, a count, what is one piece, what is printed where. Genrupt's own field description says exactly that ("exact size, material, or details"). Never a shape, a slant, a proportion, a finish or a working state in Wonka's words; the words rule above is absolute here. Read every sentence against the photos, then show the owner the exact string before it goes.
     - **The quality dial, the one dial a reference sheet has.** Standard quality is the default and right for most products. Escalate to `high` (roughly an order of magnitude dearer; measured 12-vs-1 once and 9 on a later run, so as always ONLY the live `finalCreditsCost` preview is quotable, never a figure from this file) when the product carries fine detail the model flattens at standard: tiny printed text on the product itself, thin fibers or hair, metallic sheen or lacquer, small precision parts, or when the owner has said that photos and renders "always fake" this product. That owner warning is Reference Room intel: it raises the sheet budget, the sheet count, and the revision patience, and it gets recorded. The spend logic is the same one that puts face repairs on high: a sheet is bought ONCE and inherited by every image poured from it, so this is the one room where "good enough" bills you on every image after it. Report the cost as always.
   - **The sheet carries NO text.** No labels, captions, arrows, callouts or infographic graphics; it locks visual identity, nothing else. If a draft comes back with added text, that is a defect, not a feature.
   - Save every version to `2-reference/sheet-v[N].png`, N counting up. **Never overwrite a version.** Rejected sheets are evidence of what the notes fixed.

4a. **Judge the sheet against real criteria, out loud, before the owner sees it.** "Looks good" is how a bad mold gets approved, and it is exactly how bad molds HAVE been approved: measured 27 August 2026, sheets that passed a full-frame glance carried a wrong neck proportion, a wrong ferrule color and a mislabeled part, and the OWNER caught all three. That is the room failing at its one job. So the check has two layers, in this order:

   **First, the anatomy check, at magnification, part by part.** For each region in the step-2 anatomy table: crop the SAME region from the sheet and from the source photo, put them side by side, and walk the table row by row, shape, ratio, color, material, text. A defect found here is named in the row's own words. **Never judge a sheet at gallery size**; the defects that poison generations live below full-frame resolution. **And a part that is INVISIBLE fails its row.** A cap, a wrap, a prop or an angle that occludes a part the sheet exists to lock means the sheet locks NOTHING about that part; measured 27 August 2026, a sheet was approved with protective caps on all twelve heads, so the one anatomy that decides realism was never in the mold at all. "Present but hidden" is a fail, exactly like "missing".

   **Then the five panel-level checks**, each named pass or fail:

   | Check | Passes when | Fails when |
   |---|---|---|
   | Angles | front, back, both sides and top are all readable panels | an angle is missing. Whatever is not shown, the model will invent |
   | Scale | a hand, forearm or context object makes the true size obvious | no scale cue, or one so ambiguous it could be any size |
   | Panel quality | each panel is sharp, well lit, and the product looks like something worth buying | a blurred, dark or ugly panel. It does not just fail to help, it poisons every image poured from this mold |
   | Material truth | each part reads as its real material: steel as metal, plastic as plastic, glass as translucent with reflections | premium reads cheap, cheap reads premium, or one material swallows the rest |
   | Product integrity | no text, no captions, no arrows, no badge or award graphic; the label reads correctly | the sheet has been decorated, or a part is missing or invented |

4b. **Revise until it is right. This loop is normal, not a failure.** A first draft that needs two rounds is the expected case.
   - **A shape or state defect gets a PHOTO before it gets a sentence.** If a silhouette, a taper, a
     curve or the working state came out wrong, the first question is which source photo settles it
     and whether that photo is overhead, flat and unoverlapped; an angled or overlapping photo is
     where Wonka's own guesses about hidden edges come from. Ask for that photo, upload it, and only
     then write the instruction, as a fact ("the tip is the shape shown in photo 4") rather than as a
     description in Wonka's words.
   - Take the owner's notes in their own words and turn them into `editInstructions`, naming the defect in NOUNS ("the back panel is missing", "the tower reads as chrome, it is brushed steel") rather than in feelings ("it looks off"). **A proportion defect gets a NUMBER, measured from a real photo**: "the tube is 4 to 5 times taller than it is wide", never "the tube is too short", because "too short" just buys another guess.
   - Call `create_product_reference_sheet` again with `baseReferenceSheetId` set to the draft being fixed, the `editInstructions`, and any newly uploaded photos. **This edits the sheet. Do not start a fresh sheet from scratch to fix one panel.**
   - Save as the next `sheet-v[N].png`, re-run the five checks, and show old beside new so the owner sees what actually changed.
   - **Before every revision goes out, read each sentence of the `editInstructions` against the
     source photos, including the sentences carried over from the previous round.** A sentence that
     contradicts a photo is deleted. This is the check that would have saved four rounds on the demo
     product, where a wrong working-state sentence rode unchanged on every revision. Then show the
     owner the exact string.
   - **Every edit instruction ends with the FROZEN FACTS, restated verbatim from the anatomy
     contract.** A correction that only says what to change is half an instruction: the model is free
     to "improve" everything it was not told to protect, and it does. Close every `editInstructions`
     with the counts, the integrated pieces, the materials and the text treatment as a
     must-not-change list, in the same words each time. Measured 2 September 2026: a dome-profile
     edit silently dropped a dome from another panel of the same sheet.
   - **After every edit, RE-COUNT EVERY PANEL OF EVERY SHEET, including assembled views, and write
     the table before the verdict.** One row per panel per sheet, one column per countable family.
     A set-level "the counts survived" sitting on top of a panel-level fail is the exact failure this
     room exists to prevent, and it has already happened once with the checker enforcing the rule.
     Then diff the new version against the PREVIOUS one, not only against the instruction: an edit
     that fixed what it was asked and broke something else passes an instruction-shaped check.
   - **A wrong instruction is COUNTERMANDED, never just dropped.** When a defect traces to an edit instruction Wonka himself authored (it happens; see the anatomy pass), the base sheet has already absorbed that error, so silently omitting the sentence from the next round leaves the error baked in. Name it and reverse it explicitly in the next `editInstructions`, and record in `reference-sheet.md` which instruction was revoked and why.
   - **If the same defect survives two revisions, the problem is upstream, not in the instructions.** Two upstream culprits, check both before rewording the notes a third time: a missing source angle (ask for that photo), or **a geometry contradiction in the instructions themselves**. Measured 27 August 2026: three rounds were spent fighting garbled micro-text on a handle, and it would not yield; then the neck-to-tuft proportion was corrected, and in that same render the text healed itself, untouched, clean on all five parts. When the described geometry conflicts with itself, the model burns its accuracy resolving the contradiction and the tiny text is the first thing to break. A symptom that will not die is often the wrong thing to be looking at: re-verify your own anatomy instruction against the magnified source first.

4c. **Approve, and only on the owner's word.** `approve_product_reference_sheet` with the draft's `referenceAssetId`. This marks the sheet APPROVED and saves it as the latest approved reference on the product profile, which is what later generations inherit. **Approval is itself a references write**: since September 2026 approving the PRIMARY sheet applies it to the project's setups and replaces the listing photos in `productImages` on its own. So read the plan back right after every approval (the check in this step), before saying the sheet is attached.
   - **Deliver the sheet as a FILE before you ask.** "Showing" the owner does not mean describing what you saw. Send the actual image at full size, one file per sheet, never a collage and never a thumbnail. On a multi-sheet product send all of them in one message, labelled by role. Then state your own reading (anatomy check + five checks) as an OPINION, and stop. Calling `approve_product_reference_sheet` before the owner has answered is a breach of this room, not a shortcut through it (measured 27 August 2026: five sheets were self-approved and the owner saw his first file only after the approvals). Approval is reversible, a new version supersedes it, so say that too: it lowers the cost of the owner saying no.
   - **The owner approves, not Wonka.** Silence, "ok" or "next" is not approval; ask again, naming the five checks. If the owner says any detail is wrong, do NOT approve: revise (4b) or ask for the missing photo.
   - Record the returned reference asset id in `reference-sheet.md` exactly as returned, with the version number of the sheet that was approved and the date. Never write an id a tool did not return.
   - **The sheet REPLACES the listing images. It never rides beside them, and since September 2026 Genrupt does the replacing on approval.** Approving the primary sheet (created with `projectId` + `asin`) applies it to the project's setups and replaces the product photos by itself; a primary id in a payload replaces regardless of mode. The read-back shows it as ONE entry inside `productImages` noted "Product Reference Sheet"; there is no `productReferenceSheetIds` key in the read-back, so that entry is the proof. Send the primary id in `productReferenceSheetIds` ONCE, and only if the read-back shows it missing; never re-send it on a later write, because a primary id in the payload re-runs the replacement every time it is sent (measured 9 September 2026: one re-sent primary id wiped the additional sheet and the owner's photo out of the bucket, and both had to be attached again). Additional sheets attach with `productReferenceSheetIds: [their ids]` and `mode: "merge"`, with NO `productImages` key in the payload; merge scrapes nothing any more, and nothing re-imports the listing gallery during setup, planning, generation, retries or blasts. Why the replacement matters: source photos and the ASIN's own gallery were INPUT for building the sheet, and after approval their job is finished. A listing gallery is retouched, composited and lit to sell, and the sheet is the corrected, owner-approved lock built out of those frames with their errors removed; feeding both to the generator puts the corrected lock in competition with the uncorrected originals, and the originals usually win because there are more of them. Measured 5 September 2026: four sheet rounds were spent removing mirror-chrome tiers that the source gallery had flattered into the sheet; merging that gallery back in as references re-introduced the exact defect. **History, so nobody reapplies it:** on the 5 September server a merge pulled the scraped gallery back in and this room wrote `mode: "replace"` + `productImages: []` by hand. That server is gone; today `productImages: []` is a needless write and "never merge" is dead.
     - **The one exception**: the owner explicitly asks for specific photos to be included. Then add those, and record which ones and the owner's words in `reference-sheet.md`. "Use the photos" is not that ask; the photos already built the sheet. And when read one fails on a detail no sheet holds (exact label text, a printed panel), adding that ONE source photo is a lawful lever, recorded the same way. **The mechanism, since it is easy to get wrong:** the listing gallery returns ONLY through a deliberate write, `productImages: [the urls]` + `reimportListingImages: true` + `mode: "merge"`, WITHOUT the primary id in the payload. The owner's own photo goes in with the same write, without the flag. Read the schema through `search_capabilities` first (the cached tools list is stale) and count the bucket after.
     - **Cost: the reference COUNT prices every blast, so ONE sheet selected in Project Setup is the default.** Up to three selected references cost nothing extra; four or five raise the price of every Draft Blast and every Theme Blast after them (measured on this account 9 September 2026: 31, 55 and 78 credits per 100 drafts for 3, 4 and 5 references; Theme Blast base 10 with the same tiers). This is how "up to five sheets" turned into students running out of credits. Before ANY blast run the free quote, `get_credit_balance_and_costs` with preset `listing_builder_draft_blast` (or the theme preset) and the setId, and show the owner its `selection` and `totalCredits`: the `selection` is exactly what the blast will use. Attached is not selected: the quote lists every attached sheet with `selected` true or false, the default selection is the primary alone, and an additional sheet costs nothing until it is selected (measured 9 September 2026, two sheets attached, one selected, 31 credits). Quote the live number, never a figure from this file.
     - **Verify, never assume.** After ANY references write, and after every approval, read the plan back and COUNT `productImages`. The count equals the sheet entries (noted "Product Reference Sheet") plus the photos `reference-sheet.md` records the owner asked for, and nothing more. An unexpected entry is REPORTED with its note and date, never "fixed" by re-sending the sheet id; an EMPTY bucket is a removed sheet to trace, never something to refill by habit.
     - **The reset rule (measured 9 September 2026 in this org, and reproduced the same day in a student's org).** Genrupt re-applies the approved primary sheet on EVERY `plan_listing_builder_from_asin` call whose bucket is missing that primary, and when it fires it REPLACES the whole bucket, including what the same request just wrote: the response carries `productReferenceSheetAutoApplied` with `productImageCount: 1`, and the additional sheets attached a minute earlier are gone. While the primary IS in the bucket the auto-apply stays quiet and merges land (measured: an additional id merged onto a bucket holding the primary gave 2 entries, and a bare planner call left both standing). So: never evict the primary (no `mode: "replace"` with `productImages` on a flow whose primary is approved: the write survives until the next planner call, which resets the bucket to the primary alone), attach additional ids ONLY after a read-back shows the primary present, and once the bucket is right make every later setup change through `save_listing_builder_plan_review`, which never triggers the auto-apply. A bucket down to ONE entry after a planner call is this rule firing, never a lost sheet: attach the additional ids again in one merge write, read back, and keep the planner away from that set. On the anchor route (pre-launch) the Day 3 flow was created with an empty bucket (`mode: "replace"`, `productImages: []`; measured 11 September 2026: without that write a fresh anchor flow imports all of the competitor's listing photos), so an empty read-back before this room's approval is expected there and the approval fills it with the primary; the rule about re-applying the primary is unchanged.
   - Real PACKAGING photos are a different bucket and keep their job: route them into `references.packagingImages` with the `note` from step 1 (they drive the packaging tactic and lock nothing), and write the clean `product.description` from the spec in step 2. **Then CONFIRM out loud that the packaging images actually landed in `packagingImages`** by reading the plan back, and if the product has real packaging, set `alwaysIncludePackaging` (the app's "Use actual packaging" toggle) to true. A packaging main-image tactic running against an empty packaging bucket produces an INVENTED box, and an invented box on a hero image is a returns problem wearing a design problem's clothes. The approved sheet is the identity lock; the source photos and the clean description are what carry the specifics.
   - **Slot-level `referenceImages` are NOT the lock, and they never reach a blast.** The lock is the
     project bucket: the sheets selected in Project Setup are the only references a Draft Blast or
     a Theme Blast quotes and uses; slot-level `referenceImages` are ignored there, even in OVERRIDE
     (Michael, 9 September 2026, reproduced in production). Whether a per-slot generation honors a
     slot's own `referenceImages` is unverified, so slot wiring is at most a lever for a single-slot
     rerun (step 6, per-slot) and never the fix for a set that drifted. When a slot IS wired, read
     every slot before writing, replace that slot's list, never append, and keep slot 1 empty: its
     protected fields never carry slot-level references. The 2 September 2026 run that this rule
     used to cite (nine slots with empty `referenceImages`, two failures) predates the contract
     change and proved a count problem, not a wiring problem.
   - **A logo file is NEVER routed here.** Not into `productImages`, not into `packagingImages`, not
     into `styleImage`, not into a slot's `referenceImages`. Those buckets mean "this is what the
     product looks like" and "make it feel like this"; a logo is neither, and putting it in one of
     them teaches the machine to render the logo as part of the product. The logo has exactly one
     road, step 4f. A logo PRINTED on the real product is a different thing entirely: that is product
     truth, it is already in the product photos, and it stays there.

4d. **Does this product need MORE sheets? Wonka PROPOSES the sheet set himself, NOW, in the same
   session, never waiting to be asked.** On a complex product, an owner who has to request the
   second sheet is an owner doing Wonka's job (which is how it actually went on 27 August 2026,
   and the product had every trigger below). Walk the slot plan and the product, and propose the
   full set with one line of reason per sheet. The triggers, full recipes in "One product, up to
   five sheets" below:
   - **A product that CHANGES when it runs: the working-state sheet.** A fountain flowing, a
     humidifier misting, a lamp lit, a blender full. The identity sheet shows the product off; every
     lifestyle and in-use slot needs the product ON, and without this sheet the model invents that
     state. Build it from a real photo of the product actually running, and grade it on two things
     at once: the working state is honest, AND the structure, wordmark and controls survived under
     it. This is the third sheet the bootcamp teaches by name.
   - **A kit, bundle or multipack: every distinct product gets its own clear, countable panel**, and a
     member complex enough to deserve it earns a sheet of its own. A bundle rendered as an
     undifferentiated group teaches the machine a pile, not a product list.
   - Multi-part or bundle product: the parts-inventory sheet, one countable panel PER FAMILY,
     opened and COUNTED before it is used.
   - Packaging that stars in any slot while `packagingMode` stayed `exclude`: the
     packaging-and-protection sheet, because a bucket is not a lock.
   - A distinct physical STATE a slot will show (packed in its case, mid-use in a hand): a state
     sheet per state, because the identity sheet locks the product at rest and a state the plan
     shows but no sheet locks is a state the machine invents. A genuinely complex product can
     lawfully earn four or five sheets; the measured run used five (identity, parts, packaging,
     packed state, working state).
   Additional sheets are created with `additionalSheet: true` and attached to the plan
   explicitly (up to 5 total). When more than one sheet exists, run the cross-sheet consistency
   check before any of them is used. A single-piece product with no packaging slot skips this
   step and records nothing. Deciding here is what makes Day 5's count-critical edits, the
   packaging slots, and Day 9's multipack counts work on the first try instead of after three
   wrong rounds.

4e. **The brief-consistency scan: the plan's words must not fight the sheets. Run it after the
   sheets are approved and BEFORE the smoke test spends a credit.** The brief was written on
   Day 3, from the research; the anatomy table was measured on Day 4, from magnified photos, and
   where they disagree the generation gets a tug-of-war: the sheet pulls one way, the slot text
   pulls the other, and the render splits the difference. Measured 27 August 2026: a slot brief
   still said "the crimped metal ferrule" (Day 3 wording) after the anatomy pass had established
   a long brass neck, and that slot rendered a chrome ferrule off an otherwise perfect sheet, a
   failure that looks EXACTLY like the model failing. So: read the plan back and walk EVERY text
   field that reaches generation, not only the slot briefs: `product.description`, the
   `bulletPoints`, and for every slot the `contentBrief`, every `alternateCreativeBriefs` entry,
   the `customInstructions` and the `headerPhrases`. Measured 2 September 2026: a fix landed in a
   slot's primary brief while its alternate kept the old wrong fact, and an alternate can win the
   generation. Pull out every phrase that describes the product and sort it into two piles:
   - **Contradictions**: a count, material, part name or printed text that disagrees with the
     anatomy contract or the photos. Corrected in the plan NOW.
   - **Appearance in Wonka's words**: a slant, a taper, a curve, a proportion, a finish, or how the
     working state looks, written by Wonka on Day 3 rather than confirmed by the owner from a
     photo. Under the words rule these do not belong in text at all; reduce each to the fact it
     was trying to carry ("the chocolate covers every level" stays, "pours between them as broad
     connected sheets" goes) and let the sheet wired to that slot carry the look.
   Show the owner the before-and-after of every changed field, then save via the save tool with
   the casting fields and all nine slots riding the save, and read back (contract rules; a save
   that forgets the cast wipes it). The
   scan is free; the smoke-test round it saves is not. And remember the failure signature for
   later rooms: ONE slot repeatedly failing "is this my product" while its siblings pass is the
   brief fighting the reference until proven otherwise.

4f. **Wire the real logo into Genrupt. ONLY if a real logo file exists, and silently skipped when
   one does not.** This step is about a supplied logo asset. It has nothing to do with brand styling,
   it does not need `/brand-kit`, and it does not create branding work for anyone.

   **No logo file on disk: skip this entire step.** Do not mention it, do not ask for one, do not
   warn, do not write a pending marker. Write `Logo source: none provided` and `Logo in preset: no
   logo supplied` in `status.md` and move on. **Never draw, approximate, recreate or invent a logo,
   ever, for any reason.**

   **A logo file exists:**
   - **Read the schemas first** (CLAUDE.md Genrupt contract rule 5) and check what has already been
     done, because this step is rerun-safe by construction. If `status.md` already records a
     `Genrupt preset ID` with `Logo in preset: yes . verified`, read it back once to confirm and stop
     there. Never upload the same logo twice and never create a second preset.
   - **Upload the real file through the normal Genrupt upload lifecycle** (`create_reference_asset_upload`
     accepts it), and use ONLY the completed HTTPS asset URL the tool returns. Genrupt does not accept
     local paths, and an asset URL is never typed from memory or reconstructed.
   - **List the existing branding presets first.** If a preset already belongs to this brand or
     product (start from the `Genrupt preset ID` row in `status.md`, then `list_branding_presets`),
     REUSE it: read it in detail, then update ONLY `logoUrl` and `logoThumbnailUrl`, preserving every
     colour, font and style note already on it. If no appropriate preset exists, create a MINIMAL
     logo-only preset; `name` is the only required field, so nothing else has to be invented to make
     one lawful.
   - Populate both `logoUrl` and `logoThumbnailUrl` with the completed asset URL, unless the live
     schema explicitly requires different URLs, in which case follow the schema.
   - **Attach it to the saved Listing Builder set** with `apply_branding_preset`, or by passing
     `brandingPresetId` where the schema takes it.
   - **Read everything back, three reads, all free:**
     1. the Listing Builder plan: the correct `brandingPresetId` is attached, the slot plan is
        unchanged, and `approved: true` still holds. If the approval dropped, restore the existing
        approved plan; never regenerate it to fix an approval.
     2. `list_branding_presets {includeDetails: true}`: `hasLogo: true`, `logoUrl` matches the asset
        that was just uploaded, and `logoThumbnailUrl` is present as expected.
     3. `status.md`: write `Logo source`, `Genrupt preset ID` and `Logo in preset: yes . verified
        [YYYY-MM-DD]`, taking the date from the system clock.
   - **Cost.** Uploading a logo and creating or updating a preset are free setup operations unless a
     live cost check says otherwise. They are not image-generation credits and are never quoted as
     any. Read the live cost contract rather than asserting a number.
   - **If the upload or the attach genuinely fails**, that is the one lawful gap here: write
     `Logo in preset: pending . technical failure: [what the tool actually said]`, say it in one
     line, and continue. The sheets, the approval and the smoke test all proceed; the logo is
     finished by rerunning this step alone once the machine cooperates.
   - **A logo that arrives late costs nothing.** If the sheets are already approved and the smoke
     test already passed, run THIS STEP ALONE: upload, preset, attach, three read-backs, status rows.
     Do not rebuild an approved reference sheet, do not re-upload the product or packaging photos,
     and do not re-run the smoke test. Nothing else in the room is repeated, and a second run of the
     whole room must produce no duplicate asset, no duplicate preset and no duplicate status row.
   - **Never route the logo into `productImages`, `packagingImages`, `styleImage` or a slot's
     `referenceImages`.** Those destinations are semantically wrong and they make the machine treat
     the logo as product geometry or as the set's whole aesthetic.

5. **Build the reference. Path B: gpt-image fallback (no Genrupt).**
   - For each key angle, use gpt-image to clean the photo to a plain white background, square crop, even lighting, with NO change to the product itself: same label, same proportions, same cap, same materials. The prompt must say so explicitly.
   - Save as `2-reference/ref-front.png`, `2-reference/ref-back.png`, and so on. **The originals in `2-reference/photos/` are never edited, moved, or overwritten.**
   - On this path there is no true lock, so the written spec from step 2 carries the weight: the generation rooms prepend it to every call. Say plainly that fidelity is weaker here and that the Inspection Room will have to bite harder.

5b. **STOP after the approval. The Day 4 order is sheets, then smoke, and they are two lessons.**
   When the owner approves the sheets (the lesson's line is `Approve all`, and any wording with that
   meaning counts), approve every sheet, read the plan back after each approval (4c: the primary
   applies itself, the additional ids go in once with merge), run the 4e brief-consistency scan, write
   `2-reference/reference-sheet.md` with `Reference status: APPROVED (smoke test pending)`, and END
   THE ROOM HERE. Say in one line that approved is not locked and that the smoke test is the next
   lesson. The owner returns with `run the smoke test`, which resumes at step 6.
   - **Branding is an aside here, not a gate.** Mention in ONE line that a Brand Kit can be connected
     at this point, and only if the owner has a real Brand Book or Style Guide. No guide means there
     is nothing to connect: say nothing further, never offer to invent a brand, and never make the
     smoke test wait for it. An owner who has a guide and wants it attached first runs `/brand-kit`
     and comes back; an owner who attaches it later is told once that whatever it attaches will not
     have been smoke-tested.
   - Any logo wiring from step 4f already happened and is independent of all of this: a logo-only
     product runs the smoke test with its preset attached and no styling at all.

6. **SMOKE TEST. Mandatory, both paths, no exceptions. ONE image per slot, and it is read TWICE.**

   This is the first time the owner sees their brief as pictures. It is deliberately cheap and deliberately rough.

   - **Precondition: an approved brief, in one of its two lawful forms.** Path A (Genrupt): the saved plan, its `## Send log` recording the save. Path B (no Genrupt, the OpenAI fallback this kit promises at `/machines-check`): `brief/creative-brief.md` on disk carrying `Owner review: approved [date]`, and the smoke test renders THAT brief's slot text through gpt-image instead. Path B is a full lawful path, not a downgrade: without it a student who declined Genrupt can never reach `Smoke test: PASS`, and Days 5, 6, 7 and 9 all gate on that exact string. The smoke test renders THAT plan; a smoke test made from a generic prompt tests nothing anyone is going to ship. If no plan is saved, say so and point at `/creative-brief`.
   - **Generate the whole set at the cheapest setting.** Genrupt path: the `generate_listing_builder_full_set_from_asin` capability (discover it with `search_capabilities`, call it through `execute_capability`) with:
     - `asin` and `setId`: the product's ASIN and the flow's setId. On the pre-launch route the `asin` is the same Anchor ASIN the flow was planned on; the images come from the sheet, never from the anchor's photos.
     - `requestedCount: 1`. **One variant per slot. This is the cost lever and it is not optional here.** Genrupt exposes no "effort" or "quality" dial on listing images; the number of variants IS the dial.
     - `modelId: "gpt_image_2"`, explicitly, every call. The default is already OpenAI GPT Image 2, but an unstated model is a model that can change under you.
     - `planApproved: true`, which is lawful only because `save_listing_builder_plan_review` already saved the owner's approval on Day 3.
     - `aspectRatio: "1:1"`. Square is the default and the right one for listing images. A non-square run also requires `aspectRatioConfirmedByUser: true`, so never drift into one by accident.
     - `mobileFriendly` left at its default `true`. That is Genrupt's Visual Brand Language enhancer for typography, color and mobile readability, and it is on our side.
   - **Bracket the generation with the reference read.** Read the plan back BEFORE the call (the project bucket holds the sheet entries and nothing else) and AFTER it, and say both counts out loud. A generation carries no references of its own; what it used is what the bucket held.
   - Save the whole round into `2-reference/smoke-test-v[N]/`, one folder per attempt, filenames matching the slot numbers. **Never overwrite an attempt.** Failed rounds are evidence.
   - **OPEN every file and look at it.** A returned URL, a success status, a filename or an `approved` flag is not a look. If the files cannot be opened and actually seen, the smoke test has NOT run and nothing may be written about it.

   **Then say this, before showing anything:** we are looking at two things only, whether it is the real product and whether this is the brief you wanted. **We are NOT looking at fonts, colors, composition or polish.** Those get chosen later from far more options, and judging them now makes people throw away a good frame for a bad reason.

   **READ ONE: is this my product?** Run the four-point check on EVERY frame, not just the best one. **On a multi-sheet product, each slot is also read against the SHEET that governs it**: the packaging slot against the packaging sheet, a count slot against the parts-inventory sheet, a state slot against its state sheet, and everything against the anatomy table. An approved sheet is a status; a rendered frame that matches it is the evidence, and this is where each sheet earns or loses its keep. A failure here names WHICH sheet failed to carry into the render.

   | Check | Passes when | Fails when |
   |---|---|---|
   | Parts and count | every part present, every countable thing counted right (a four tier fountain shows four tiers, a two lid pot shows two lids) | a part is missing, a part is invented, or the count is off by even one |
   | Materials | each part reads as its real material: steel as metal, plastic as plastic, glass as translucent glass with reflections | premium reads cheap or cheap reads premium; one material swallows the others |
   | Scale and proportions | reads as the size it really is, checked against the hand-for-scale shot (or against review photos on the fallback path) | a counter-top machine renders as catering equipment, or a large product renders as a travel size |
   | Nothing invented | no badge, seal, ribbon or award graphic that is not physically on the real product; the label is readable and spelled correctly | the model has decorated the product with things that would be a compliance problem on a live listing |

   **Count the failing frames FIRST, because that number names the culprit.** The same defect across
   the set and one defect in one frame are two different faults with two different fixes, and treating
   the second like the first throws away a mold that proved itself.
   - **The same product defect in SEVERAL slots is a REFERENCE problem.** The mold is loose. Go back
     to 4b, revise the sheet, re-approve, and re-run the round. Never fix it by rewording a slot brief.
   - **ONE slot failing while the rest hold the product is a SLOT problem, and the sheets already
     proved themselves in the frames that passed.** Do not rebuild a sheet for it. Inspect that slot,
     in this order: (a) the ANGLE and CROP the brief asked for, because a high or tight framing that
     cuts the product is the commonest cause and the model loses whatever left the frame; (b) whether
     that slot's own text describes the product differently from the anatomy contract; (c) whether
     the composition FORCES what it has to prove, because a frame carrying a count must group, label,
     lay out or line up the pieces, never fan, pile or scatter them; (d) whether the sheet
     is actually selected in the project bucket, see below. Fix the cause, rerun that slot alone.

   **Check that the sheet is actually SELECTED in the project bucket (step 4c). It is free and it is the first thing to read.**
   Read the plan back: the approved sheets must be there as `productImages` entries noted
   "Product Reference Sheet", and nothing else beside them except a photo the owner asked for. A
   missing sheet is attached once by id (the primary auto-applies on approval; an additional sheet
   goes in with `mode: "merge"`); a slot pointing at an old sheet version is corrected on that slot.
   Slot-level `referenceImages` are not the fix for a fidelity failure: a blast never reads them
   (Michael, 9 September 2026), and whether a per-slot rerun honors them is unverified. If the
   bucket is right and the count still fails, the sheet itself is the problem: a parts sheet whose
   panels do not separate the pieces, or a source photo that never showed the count.

   **READ TWO is not "does this match the brief". It is "now that I can SEE it, is the brief itself right?"** A brief is unjudgeable as text and judgeable as a picture, and this is the only moment in the whole line where that swap is cheap. Walk the frames beside the brief's slot list, one line each: this slot's job, and whether the MESSAGE earns its place in the gallery. Then ask the owner three separate questions, and treat a "yes, change something" as the room WORKING, never as a failure:
   - *Which slot's message is weak, or duplicates another slot?*
   - *Which slot would you drop entirely?*
   - *What is missing from the gallery that only became obvious now?*
   Legitimate answers that are WINS, not problems:
   - "I do not want that frame at all" → drop the slot, and re-map its selling points in the coverage map.
   - "That is not the job I meant" → the buyer question or the content brief was ambiguous, so sharpen it.
   - "Two of these are saying the same thing" → the review questions missed an overlap. Merge them.
   - "Now that I see it, the brief itself needs a change" → exactly what this step exists to surface, and it costs nothing now.

   **A brief failure is a BRIEF problem.** Route it to `/creative-brief`'s revision protocol: change only what was named, re-run the affected checks, re-save the plan, and record the reason in the owner's words. **Never fix a brief problem by re-rolling the image.** The next round of that slot would be a better picture of the wrong idea.
   **The rerun is per slot, not per round.** After the brief revision is saved, regenerate ONLY
   the affected slot at `requestedCount: 1` (the lesson's line: `Revise the brief for [slot
   number]. The current message is [the problem]. Change it to [the corrected message or job],
   update the saved plan, and rerun that smoke-test image.`), save it into the same
   `smoke-test-v[N]/` folder as `slot-[N]-r2.png`, and read it twice like any other frame. A
   whole-round rerun is for a fidelity failure, where the mold is loose everywhere; a message
   failure is one slot's problem and costs one image to settle. Read the project bucket before
   and after the rerun like any other generation.

   - **This is the OWNER'S gate. Wonka opens it and does not walk through it.** Send every frame as its own full-size file, one per slot; a contact sheet may accompany them for orientation and never replaces them. Then give your own per-slot reading as an OPINION, on the MESSAGE and not only on brief-compliance, and STOP. `Reference status: LOCKED` and `Smoke test: PASS` may not be written until the owner has answered. If the owner delegates the judgement back ("you decide, I do not know the product"), that is a valid answer: record it verbatim in `reference-sheet.md` as `owner delegated the smoke-test read`, then decide, and say what you decided and why. Delegation is recorded, never assumed.
   - **PASS is the HUMAN'S word, never Wonka's**, and it means both reads passed. The lesson's line is `The smoke test passes. Lock the reference and mark the smoke test as passed.` (the lesson opens the round with `run the smoke test`); any wording with that meaning counts, and it is what flips `Reference status` to LOCKED and `Smoke test` to PASS. Ask for the call in plain words. Silence, "ok", "continue" or "looks good, next" is not a verdict; ask again, naming both reads.
   - Log every round with its number, which read failed, and what was changed as a result. The log is what proves a fix was a fix.
   - **After three failed rounds, STOP generating and diagnose out loud.** Repeated failures are one of three things: a missing source angle, a spec too vague to judge against, or the wrong path for this product. Name which one you believe it is, ask for the specific missing input, and let the owner decide whether to keep spending. One round is cheap. Six are not.
   - **NEVER proceed to a blast on a failed, parked or skipped smoke test.** One round is cheap. A hundred-image Draft Blast of the wrong product is not.
   - **Fallback path (no Genrupt):** generate one image per slot with gpt-image, prepending the spec from step 2 to every call, because there the spec IS the lock. Both reads still apply, and say plainly that fidelity is weaker so read one bites harder.

7. **Write `2-reference/reference-sheet.md` with full provenance, then update `status.md`.** Both files, every run, including runs that end parked or blocked.

## One product, up to five sheets

One sheet locks ONE thing well. A complex product needs several, each with a single job, and the
schema supports exactly that: a plan attaches up to FIVE sheets (`productReferenceSheetIds`,
maxItems 5, verified 27 August 2026). The only hard limit is ONE PRIMARY sheet per ASIN; every
sheet after the first is created with `additionalSheet: true` and attached to the plan
explicitly (`productReferenceSheetIds: [ids]`, `mode: "merge"`, no `productImages` key). Read
the schema through `search_capabilities` before the call as always. **The attach is free, the
SELECTION is not.** Up to three references selected on a blast cost nothing extra; four or five
raise the price of every blast after them (measured 9 September 2026 on this account: 31, 55, 78
credits per 100 drafts). So five sheets is a capability, not a target: one sheet is almost always
enough, a sheet earns its place only when the plan has a slot no existing sheet can lock, and the
free quote (`get_credit_balance_and_costs`, its `selection`) is read before every blast. The selection lever has a name: `selectedReferenceImageUrls` (the sheet URLs exactly as the read-back shows them) on the blast quote preset and on `create_listing_builder_draft_blast` / the theme blast. **There is no selection control in the app** (a student checked 9 September 2026: a Project Setup reference tile offers only Crop & remove background and Remove), and selection appears to be derived from `isSheet`, so an UPLOADED image reads `selected: false` until a call names it. **`generate_listing_builder_image` has no reference-selection field at all**, so a per-slot rerun cannot use an uploaded reference or an unselected sheet by any route found so far: a fault that needs an extra reference is fixed by a blast that names it, or by re-locking the primary. Omitted, the blast uses the primary sheet alone. An attached sheet that is never selected reaches no blast, so attaching a state sheet and blasting without selecting it changes nothing but the read-back. **And the
attach only counts after the read-back**: read the plan back, confirm every sheet is in the bucket
AND `approved: true` survived, per Genrupt contract rule 6. An attach that silently dropped a
sheet, or dropped the approval, is exactly the kind of failure that points nowhere the next day.

The three sheets that keep earning their slot, each answering a failure the identity sheet
structurally cannot:

**1. The identity sheet (the primary).** The beauty collage from step 4: angles, scale, material.
This is the one the owner approves and `approve_product_reference_sheet` marks on the profile.

**2. The parts-inventory sheet.** A product that disassembles, or a bundle, needs it because the
identity sheet locks the assembled look and the machines cannot count from it (measured on the
4-tier fountain: A+ edits briefed "exactly four tiers" against the beauty sheet landed 2, then 5,
then 3; the same edit against a parts sheet landed exactly 4, first try).
- **The notes field carries the inventory as countable panels, one panel PER FAMILY, not one
  panel for the whole set.** Each sub-family (the 5 round, the 5 rigger, the 2 flat) gets its own
  panel with its own count and its own size ladder spelled out. Measured 27 August 2026 on a
  12-brush set: three rounds of a whole-set panel never counted clean; per-family panels landed
  the full count and both size ladders on the FIRST try. Add one assembled panel for context and
  a hand-for-scale panel holding ONE component (`scaleReferenceMode: handheld`).
- **The counting law: a COMPOSITION that forces the count holds; nothing else does.** Measured
  across one run, 27 August 2026, in three layers: five brushes with five different printed sizes
  in a clean row counted EXACT first try; twelve IDENTICAL caps came back 13, then 14; and at the
  smoke test, a layout of three labeled groups against a ruler gave 12 exact while a FAN whose
  hang tag declared "12" gave 11. So distinguishability alone is not the rule, structure is:
  any panel or slot that must hold a count is COMPOSED to force it, grouped, labeled, laid out,
  against a ruler, never fanned, stacked or piled. The fix for a miscount is never another round
  of the same composition, it is a composition that forces the number, or dropping the claim.
  **And an image that DECLARES a number (a hang tag, a headline) while its composition cannot
  force that count is a COMPLIANCE defect, not a style note**: either the composition forces the
  count or the number claim comes off.
- **When to reach for it:** any generation or edit where a part count must hold, a bundle image
  showing every included item, A+ disassembly and cleanup frames, and variation counts
  (multipacks).

**3. The packaging-and-protection sheet.** Required whenever the packaging STARS in a slot (a
packaging main-image tactic, a protection or unboxing frame) while `packagingMode` stayed
`exclude`, because the bucket preserves photos but locks no geometry, and a slot built on an
unlocked object is a slot the machine invents. Lock the tube, the sleeve, the caps, whatever the
slot actually shows.

**4. State sheets.** One per distinct physical STATE the slot plan shows (packed in its case,
mid-use in a hand), because the identity sheet locks the product at rest, and a state the plan
shows but no sheet locks is a state the machine invents. The anatomy table from step 2 governs
these too: the product inside the state must match it part for part.

Two disciplines that hold across ALL sheets:

- **Open every sheet and count before it is used.** Every countable thing in every panel,
  including the panel you added for atmosphere: a caps panel that renders 13 caps on a 12-brush
  product is a live defect (caught by hand-count, 27 August 2026). A sheet that miscounts poisons
  every edit it anchors. Save each as its own file in `2-reference/`
  (`parts-inventory-sheet.png`, `packaging-sheet-v[N].png`) and record all of them in
  `reference-sheet.md`.
- **Cross-sheet consistency, checked BEFORE any sheet is used.** When more than one sheet exists,
  every shared fact must agree across all of them: the same part must be the same color, material
  and shape on every sheet that shows it. Measured 27 August 2026: the ferrules came out
  silver-grey on the identity sheet and brass-gold on the parts sheet, and each sheet ALONE
  passed its checks. A conflict between sheets is a defect even when no single sheet fails,
  because the machine resolves the disagreement at random, per image. **And a conflict is
  arbitrated by re-measuring the MAGNIFIED SOURCE, never by matching sheets to each other.** The
  same run proved why: that ferrule conflict was first "resolved" toward the approved sheet's
  silver, and the source said brass, so the harmonization made BOTH sheets wrong. Agreement
  between sheets is harmony, not accuracy; only the source photo gets a vote.
- **Approve each sheet once, and prove the primary by read-back, not by order.** The primary is the
  sheet created WITHOUT `additionalSheet`, fixed at creation (measured 9 September 2026: an additional
  sheet approved AFTER the primary attached nothing and displaced nothing; the profile head stayed on
  the primary). The 27 August 2026 server behaved differently (approving a supplement after the identity
  sheet displaced it), and that ritual is dead. After the last approval read the plan back and confirm
  the identity sheet is in the bucket; if it is not, report it as a bug, never as an order problem.

The additional sheets supplement the locked identity sheet, never replace it.

## If the smoke test cannot run

Machines go down. This is the defined behavior, and it is neither a dead end nor a shortcut:

- Write everything that does not need a machine: the photo inventory, the waivers, the full product spec, and the source line.
- Write `Reference status: not locked (smoke test parked: [exact reason])` in `reference-sheet.md`. **Never LOCKED, never PASS, never a placeholder verdict.**
- Put the exact blocker in `status.md` under `Blocked on`, and leave INVENT closed. The generation rooms check for `LOCKED` plus `Smoke test: PASS` and will correctly refuse to run.
- Point the user at the work that costs nothing and needs no machine: the photo inventory, the spec, and the brand kit interview all run fine with the machine down.
- Say exactly what will resume the room: "when Genrupt answers again, say `run the smoke test` and we finish the round."

## When to re-lock

The reference is not permanent. Send the product back through this room when:

- The packaging, label, or physical form changes, including a new variant that is genuinely a different shape.
- `/inspect` fails product fidelity on more than one image in a batch. That is a reference problem wearing an image problem's clothes, and no amount of editing fixes it.
  When the failures share ONE cause that is a missing state of the same object (the candle open, the lid off, the blade extended), the first move is a re-lock of the PRIMARY with that state as one of its panels: one selected reference, no price tier crossed, nothing to attach or select, and the reset rule cannot touch it. An additional state sheet is the route when the primary's grid has no room for the state or the state is a different object (a bag, a part, a box); it then has to be attached AND selected before it changes a single draft. Measured 9 September 2026: a student's Wonka spent an evening trying to attach a third sheet for the open state while five of six slots kept drifting, and a rebuilt primary would have closed it in three credits.
- A new product enters the Factory. **Every product gets its own Reference Sheet.** References are never shared between products, not even between siblings in the same brand.

After a re-lock, read the bucket and every slot, and replace any entry still carrying the old
version's id or URL; a slot pointing at a superseded sheet is the quiet way an old defect returns.

## Output format

`factory/Products/[product]/2-reference/reference-sheet.md`:

```markdown
# Reference Sheet . [Product Name]
Built: [YYYY-MM-DD]
Built from: [N] source images in 2-reference/photos/, owner input on [date]
source: manual_photos | amazon_scraped (listing gallery + customer review images, explicitly approved by [name] on [date])

## Photo inventory
| Required shot | Present | File | What this image establishes (its Genrupt note) | If missing, what the model is free to invent |
|---|---|---|---|---|
| Front | yes | photos/own-front.jpg | front face, label text exact | . |
| Back | MISSING (gap waived by owner [date]) | | | the entire back panel and its label |
| Left side | yes | photos/gallery-03.jpg | left profile, spout shape | . |
| Right side | yes | photos/gallery-04.jpg | right profile | . |
| Top down | yes | photos/review-photo-02.jpg | lid opening, tier count from above | . |
| Hand-for-scale | MISSING (no unit in hand) | | | true size; judged against review photos instead |
| Label / texture close-up | yes | photos/own-label.jpg | matte finish, label typography | . |

## Product spec
| Field | Value | Source |
|---|---|---|
| Size / dimensions | [exact, or unknown] | [photo file / owner / listing] |
| Weight | [value or unknown] | [source] |
| Countable parts | [e.g. 4 tiers, 1 auger, 1 base] | [source] |
| Materials and finish, per part | [part: material, finish] | [source] |
| Included parts and accessories | [everything in the box that can appear in an image] | [source] |
| Label text | [exactly as printed] | [source] |
| Colors | [product + label] | [source] |
| Power / voltage | [value, or n/a] | [source] |

Anything marked `unknown` is something the model is free to invent. That is the risk this line records.

## Anatomy table (fine-detail products; written from MAGNIFIED source photos, before the first sheet)
| Part (tip to tail) | Shape | Proportion (measured ratio) | Color / material | Printed text |
|---|---|---|---|---|
| [e.g. metal neck] | [long, tapering] | [~3x the tuft length] | [dark gunmetal] | [none] |
- Magnified crops used: [photo file + region]. Every sheet version is graded against this table, row by row.
- Not needed (simple product): [state it, with one line why]

## Genrupt intake routing (Path A)
| File | Destination | Asset URL (exactly as returned) | Note sent with it |
|---|---|---|---|
| photos/own-front.jpg | sheet input (sourceImageUrls) | https://... | front face, label text exact |
| photos/review-photo-02.jpg | sheet input (sourceImageUrls) | https://... | top down, lid opening |
| photos/box-front.jpg | packagingImages | https://... | retail box, front panel |

## Logo (independent of any brand styling)
| Field | Value |
|---|---|
| Logo file | 2-reference/logo/[filename] . or `none provided` |
| Uploaded asset URL | [exactly as Genrupt returned] . or n/a |
| Branding preset | [id] (logo-only | logo + brand style | none) |
| Attached to plan | yes, read back [YYYY-MM-DD], approved: true . or n/a |
| Preset read-back | hasLogo: true, logoUrl matches, logoThumbnailUrl present . or n/a |

No logo supplied is a complete state; this whole section reads `none provided` / `n/a` and nothing
is owed. A logo is never listed in the buckets above.

Clean product.description sent in projectSetup (confirmed facts only, no `unknown` values, no constraint prose):
> [the spec rewritten as one clean factual description]

## Additional sheets (multi-part, bundle, or packaging-slot products only)
- Parts-inventory sheet: built [YYYY-MM-DD] | not needed (single-piece product)
  - File: 2-reference/parts-inventory-sheet.png | Sheet id: [returned id]
  - Counted by hand on open, per family: [e.g. 5 round + 5 rigger + 2 flat, ladders clean. matches spec]
- Packaging sheet: built [YYYY-MM-DD] | not needed (no packaging slot in the plan)
  - File: 2-reference/packaging-sheet-v[N].png | Sheet id: [returned id]
- Attached to plan via: [productReferenceSheetIds + mode merge, read back [YYYY-MM-DD]]
- Cross-sheet consistency check: [passed [date] / single sheet, n/a] . shared facts compared: [e.g. ferrule color, handle finish]

## Reference lock
- Path: genrupt | gpt_image_fallback
- Lock mechanism: primary sheet [id] applied on approval [YYYY-MM-DD] (read back as a productImages entry noted Product Reference Sheet); additional ids [ids] attached with merge; packagingImages [files]; clean product.description (Path A), or cleaned refs: [file list] + spec prepended to every call (Path B)
- Bucket read-back after the last references write: [N sheets, N owner-named photos, N packaging, 0 extra] on [YYYY-MM-DD]
- Reimports: none | [date, urls, owner's words]
- Blast quote read before the first blast: selection [N references], totalCredits [live number] on [YYYY-MM-DD]
- Routing recorded: [YYYY-MM-DD]. A recorded payload is a status, not proof. The smoke test below is the proof.

## Reference sheet versions
| Version | File | Approved | What the notes fixed |
|---|---|---|---|
| v1 | sheet-v1.png | no | back panel missing, tower read as chrome |
| v2 | sheet-v2.png | YES [YYYY-MM-DD] | back added from new photo, brushed steel corrected |

- scaleReferenceMode used: [auto / handheld / hand_or_forearm / tabletop / none] . why: [one line]
- packagingMode used: [exclude / include_separate_panel] . why: [one line]
- Approved reference asset id: [exactly as `approve_product_reference_sheet` returned]
- Five-point check on the approved sheet: every angle [ok], scale cue [ok], every panel clear and attractive [ok], materials honest [ok], nothing added [ok]

## Smoke test (mandatory, one image per slot)
Rendered from the plan `/creative-brief` saved on [date]. Settings: requestedCount 1, gpt_image_2, 1:1, mobileFriendly default.

| Round | Folder | Slots rendered | Cost | Read 1 (my product?) | Read 2 (my brief?) | What changed as a result |
|---|---|---|---|---|---|---|
| 1 | smoke-test-v1/ | 7 | [actual] | FAIL: three tiers, tower read as chrome | not judged, read 1 failed first | new sheet version v2 |
| 2 | smoke-test-v2/ | 7 | [actual] | PASS | FAIL: slot 5 is not a frame I want | slot 5 dropped, SP re-mapped in the brief |
| 3 | smoke-test-v3/ | 6 | [actual] | PASS | PASS | . |

- Read by: [user name], with Wonka reading first
- NOT judged at this stage, on purpose: fonts, colors, composition, polish
- Smoke test: PASS
- Reference status: LOCKED [YYYY-MM-DD]

## Notes
[waived gaps, fallback warnings, what the generation rooms should watch hardest, anything that would explain a future fidelity miss]
```

Three lines are read mechanically by other rooms and must be written literally, exactly as spelled here: `source:`, `Smoke test: PASS` (or `FAIL: [reason]`), and `Reference status: LOCKED [date]`. Until a PASS, the status line reads `not locked` with the reason in brackets. Do not reword them, do not decorate them, do not write them early.

## Golden Standards check

Before presenting, verify:
- [ ] The user's own photos were requested FIRST, before any fallback was mentioned. The fallback ran only on explicit, named approval, recorded as `source: amazon_scraped` with a date.
- [ ] No competitor image and no AI-generated image is in the reference set.
- [ ] The spec is complete and SOURCED, with `unknown` written where a value could not be confirmed. Nothing was invented to fill a field.
- [ ] Cost was REPORTED, not asked permission for, and the actual cost was said out loud after each round. The room never parked waiting on a go-ahead the brief approval already covered.
- [ ] The reference exists on the chosen path: every product photo uploaded as sheet input, packaging photos routed into `packagingImages` with their notes, asset URLs recorded exactly as returned, plus the clean `product.description` (Path A), or cleaned reference files plus the spec (Path B). No URL was written from memory, and no photo was routed into `productImages`.
- [ ] Accuracy is enforced by the reference images and the clean description, not by constraint prose planned for briefs or custom instructions.
- [ ] The reference sheet was judged BEFORE the owner saw it, in both layers: the anatomy check at MAGNIFICATION against the step-2 anatomy table (side-by-side crops, row by row, never at gallery size), then the five-point check. Revised via `baseReferenceSheetId` + `editInstructions` rather than rebuilt from scratch, and approved only on the owner's word. Every version is on disk as `sheet-v[N].png`; nothing was overwritten.
- [ ] On a complex product, the full sheet SET was proposed by Wonka, unprompted, with a reason per sheet. The owner never had to ask for a sheet the plan needed.
- [ ] `scaleReferenceMode` was CHOSEN and its reason recorded, never left to luck. `packagingMode` stayed `exclude` unless the owner asked otherwise and heard the bleed-through tradeoff.
- [ ] The slot plan was checked against the sheets: every object that STARS in a slot (packaging included) is locked by SOME sheet, and where more than one sheet exists, the cross-sheet consistency check ran and shared facts agree.
- [ ] The brief-consistency scan (4e) ran after sheet approval and before the smoke test: every product-describing phrase in the plan was checked against the anatomy table, contradictions were fixed via the save tool with the cast riding, and the plan was read back.
- [ ] The smoke test rendered the SAVED PLAN, one image per slot, at `requestedCount: 1` with `modelId: "gpt_image_2"`, `aspectRatio: "1:1"` and `planApproved: true`.
- [ ] EVERY frame was opened and looked at, and BOTH reads were run: read one (my product?) on all four points, read two (my brief?) slot by slot.
- [ ] The owner was told out loud, before seeing the images, that fonts, colors, composition and polish are NOT being judged at this stage.
- [ ] A fidelity failure routed to a new sheet version. A brief failure routed to `/creative-brief`. Neither was ever fixed by re-rolling an image.
- [ ] The PASS came from the human in words and covers BOTH reads. Wonka never wrote PASS on his own judgment.
- [ ] No text this room sent describes the product's appearance in Wonka's own words: `notes`, every `editInstructions`, and every plan field the 4e scan touched carry facts, owner-confirmed observations, and the job of the image, and each was shown to the owner verbatim before it went.
- [ ] The 4e scan covered `product.description`, the bullets, and every slot's brief, alternates, custom instructions and header phrases, not only the primary briefs.
- [ ] The project bucket was read back after every approval and every references write: sheet entries plus owner-named photos, nothing else; the primary id was sent at most once; the free blast quote's `selection` was read before any blast and shown to the owner.
- [ ] A supplied logo was uploaded, wired into a branding preset (reused or minimal logo-only), attached, and verified by THREE read-backs (plan `brandingPresetId` + slots + `approved: true`; preset `hasLogo`/`logoUrl`/`logoThumbnailUrl`; `status.md` rows). The logo was never routed into `productImages`, `packagingImages`, `styleImage`, or slot `referenceImages`.
- [ ] No logo supplied: step 4f was skipped in silence. Nothing was asked, warned, marked pending, drawn or invented.
- [ ] Every round is on disk in `2-reference/smoke-test-v[N]/` and logged with which read failed and what changed. Nothing was overwritten. Originals in `photos/` untouched.
- [ ] `2-reference/reference-sheet.md` and `status.md` were both written, including on a parked or blocked run.
- [ ] No blast ran here. Draft Blast and Theme Blast belong to the generation rooms, after this room passes.

## Wonka lines

Openers:
- "The Reference Room. Get this wrong and every candy downstream comes out the wrong shape."
- "Real photos, please. Molds made from guesses produce candy shaped like guesses."
- "Ah, the product itself. Let us introduce it to the machines properly, before they introduce themselves to it."

During:
- "The back, please. Whatever you do not show me, the machines will happily invent."
- "A hand in the frame. Inches are an argument, a hand is a fact."
- "Empty, please. No chocolate, no pour, no garnish. We are testing the machine, not the promise."

Closers:
- "One of each, cheap and rough, before we spend properly. I have burned enough sugar to know."
- "Two questions and two only: is that your product, and is that the picture you asked for. Fonts and colours can wait; you will have a hundred of those."
- "The reference is locked and the smoke test passed. The machines can no longer hallucinate your product."
- "Your product, faithfully cast. Batch production is now a safe activity."
- "It came back wrong, which is exactly what it is for. Name the defect and we run one more."

## Definition of Done

Done means all of these are true on disk, and it is checkable in ten seconds:

- `2-reference/reference-sheet.md` exists with a sourced photo inventory, a sourced product spec, the Genrupt intake routing, the logo section, and a `source:` line.
- The words rule held: nothing Wonka wrote into any generation text describes how the product looks, and `reference-sheet.md` records the exact `notes` and every `editInstructions` string that was sent.
- The logo state is recorded in BOTH `reference-sheet.md` and `status.md`: wired and verified, `none provided`, or a named technical failure. A missing logo is done, not pending.
- The reference is locked on a named path: the approved sheet in the project bucket, packaging URLs in `packagingImages` with notes, plus a clean `product.description` (Path A), or cleaned reference files (Path B).
- An APPROVED product reference sheet exists: its version file on disk, its returned reference asset id recorded, and the owner's approval dated.
- At least one smoke-test round exists as a folder of per-slot images in `2-reference/`, and every frame in the passing round was opened and viewed.
- `reference-sheet.md` carries `Smoke test: PASS` and `Reference status: LOCKED [date]`, the PASS came from the human, and it covers both reads.
- For a multi-part or bundle product: `2-reference/parts-inventory-sheet.png` exists with per-family panels, was opened and counted by hand, and `reference-sheet.md` records the count. For a plan with a packaging slot on `packagingMode: exclude`: the packaging sheet exists and is recorded. Where more than one sheet exists, `reference-sheet.md` records that the cross-sheet consistency check passed. A single-piece, no-packaging-slot product records `not needed` instead.
- `status.md` records it.

**Not done, and honestly recorded as such:**
- Reference built, smoke test not yet run or parked: `Reference status: not locked ([reason])`. The artifact exists, INVENT stays closed, and the user knows exactly what resumes it.
- Smoke test failed: attempts logged with defects, status `not locked`.

A Reference Sheet without a passed smoke test is NOT done, however good the sheet looks and however confident the tool sounds.

## Update status.md

- Set the INVENT station row to `in progress` if it is still `pending` (the reference is INVENT's preparation, not a station of its own), with artifact `2-reference/reference-sheet.md`.
- On a PASS, add the Log line: `[date] Reference locked (source: [manual_photos/amazon_scraped], path: [genrupt/gpt_image_fallback]), smoke test PASS on attempt [N].`
- Not passed, add instead: `[date] Reference built, smoke test [pending/parked: reason/failed on attempt N]. INVENT blocked on the smoke test.` and put the exact blocker in the `Blocked on` list.
- **Write the three logo rows, every run.** `Logo source` (the real file path, or `none provided`),
  `Genrupt preset ID` (what a tool returned, or `none`), `Logo in preset` (`yes . verified [date]`,
  `no logo supplied`, or `pending . technical failure: [reason]`). `no logo supplied` is a finished
  state: it never goes under `Blocked on` and it never becomes a task.
- Record every waiver (gaps accepted, fallback source approved, no-Genrupt path) in the Notes of `reference-sheet.md` and in `status.md`, so a future session knows what this reference was built on without re-reading every file.

#!/usr/bin/env python3
"""The Face Clinic engine, offline. The API call is stubbed; everything our
side owns is real: box parsing, the composite contract (outside pixels are the
original, byte for byte), the tone-match field and its cap.

Each check encodes a real failure, measured before it was fixed.

Run: python3 test_face_fix.py
"""
import shutil
import sys
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

FAILURES = []


def check(name, cond, detail=""):
    cond = bool(cond)
    detail = str(detail)          # a numpy array as detail must not crash the harness
    print(("  PASS  " if cond else "  FAIL  ") + name + ("  " + detail if not cond and detail else ""))
    if not cond:
        FAILURES.append(name)


def run():
    import numpy as np
    from PIL import Image
    import face_fix

    # -------- box parsing refuses nonsense before any spend
    ok = face_fix.parse_boxes("10,10,50,60; 70,10,120,80")
    check("boxes parse", ok == [(10, 10, 50, 60), (70, 10, 120, 80)], ok)
    for bad in ("50,60,10,10", "1,2,3", ""):
        try:
            face_fix.parse_boxes(bad)
            check(f"bad box '{bad}' refused", False)
        except SystemExit:
            check(f"bad box '{bad}' refused", True)

    # -------- the composite contract, with the API stubbed out
    tmp = Path(tempfile.mkdtemp())
    rng = np.random.default_rng(5)
    base = rng.integers(60, 200, (300, 400, 3)).astype("uint8")
    src = tmp / "scene.png"
    Image.fromarray(base).save(src)

    # the "render": globally +25 brighter (the exposure shift that printed
    # rectangles), a new face painted in the box, and a GHOST far outside it
    render = np.clip(base.astype(int) + 25, 0, 255).astype("uint8")
    render[80:180, 60:160] = (200, 150, 120)        # the new face, inside the box
    render[40:80, 300:360] = (10, 10, 10)           # ghost the model invented elsewhere

    class FakeData:
        def __init__(self, png):
            import base64 as b64
            self.b64_json = b64.b64encode(png).decode()

    class FakeClient:
        class images:
            @staticmethod
            def edit(**kw):
                import io
                buf = io.BytesIO()
                Image.fromarray(render).save(buf, format="PNG")
                return type("R", (), {"data": [FakeData(buf.getvalue())]})

    import openai
    real = openai.OpenAI
    openai.OpenAI = lambda *a, **k: FakeClient
    try:
        dst = face_fix.run(src, [(60, 80, 160, 180)], quality="low")
    finally:
        openai.OpenAI = real

    out = np.asarray(Image.open(dst).convert("RGB")).astype(int)
    check("output lands beside the original", dst.name == "scene-faces-fixed.png", dst.name)

    # far outside the box: byte-identical to the source, so the ghost died
    check("the model's ghost OUTSIDE the box never reaches the result",
          np.abs(out[40:80, 300:360] - base[40:80, 300:360].astype(int)).max() == 0)

    # inside the box: the new face arrived (near its painted color, tone-matched)
    face = out[110:150, 90:130].mean(axis=(0, 1))
    check("the new face DID arrive inside the box",
          abs(face[0] - 200) < 30 and abs(face[2] - 120) < 30, face.round())

    # -------- the tone field is capped, so a ring can shade a seam but not recolor a face
    # The shift must sit INSIDE the trust window (under 30, over the 18 cap):
    # a +60 shift fails the agree test everywhere and the field never engages,
    # which made the first version of this check pass on uncapped code.
    o = Image.fromarray(base)
    shifted = np.clip(base.astype(int) + 25, 0, 255).astype("uint8")
    e = Image.fromarray(shifted)
    matched = np.asarray(face_fix._tone_match(o, e, (100, 100, 200, 200)), dtype=int)
    inner = np.abs(matched[130:170, 130:170] - shifted[130:170, 130:170].astype(int))
    applied = inner.max()
    check("the field engages on a trusted shift", applied >= 10, applied)
    check("and is capped at 18 per channel", applied <= 19, applied)

    print()
    # --- where the fix lands (kit v23) ---------------------------------------
    # Inside a product folder the result follows the round law and takes its
    # canonical name in a new edits/vN; a v22 `-faces-fixed.png` beside the source
    # was invisible to every room that resolves a file by name.
    prod = (Path(tempfile.mkdtemp()) / "fondue").resolve()
    (prod / "images").mkdir(parents=True)
    (prod / "status.md").write_text("x")
    for n in ("main-06.png", "sec-01.png"):
        (prod / "images" / n).write_bytes(b"x")
    dst = face_fix.default_dst(prod / "images" / "main-06.png")
    check("inside the factory the fix opens edits/v1 and takes the canonical name",
          dst == prod / "edits" / "v1" / "main-06.png", dst)
    check("and the round is a complete snapshot",
          (prod / "edits" / "v1" / "sec-01.png").is_file())
    dst2 = face_fix.default_dst(prod / "edits" / "v1" / "main-06.png")
    check("a second fix opens v2 from v1", dst2 == prod / "edits" / "v2" / "main-06.png", dst2)
    check("a legacy -faces-fixed name resolves to its canonical name",
          face_fix.canonical_name(Path("main-06-faces-fixed.png")) == "main-06.png")
    loose = (Path(tempfile.mkdtemp()) / "photo.png").resolve()
    loose.write_bytes(b"x")
    check("a loose file still lands beside the source",
          face_fix.default_dst(loose) == loose.with_name("photo-faces-fixed.png"))

    print()
    # --- a round is the ADOPTED set, not a copy of the last folder (kit v28) --
    # Reproduced 9 September 2026: Day 5 fixed the main into edits/v1; Day 6 put
    # eight secondaries into images/; the next fix opened v2 from v1 and the
    # eight secondaries were missing. And canonical_name('sec-03-v2.png') gave
    # 'sec-03.png': -v2 is a generation's own name, not a fix suffix.
    prod = (Path(tempfile.mkdtemp()) / "fondue").resolve()
    (prod / "images").mkdir(parents=True)
    (prod / "status.md").write_text("x")
    (prod / "images" / "main-01.png").write_bytes(b"main-original")
    v1 = prod / "edits" / "v1"
    v1.mkdir(parents=True)
    (v1 / "main-01.png").write_bytes(b"main-FIXED-day5")
    (v1 / "main-01-rejected.png").write_bytes(b"evidence")       # a failed attempt, kept
    (v1 / "main-01-render.png").write_bytes(b"evidence")         # the whole-frame render, kept
    secs = ["sec-01", "sec-02", "sec-03", "sec-03-v2", "sec-04", "sec-05", "sec-06", "sec-07"]
    for n in secs:                                               # Day 6, after the round
        (prod / "images" / f"{n}.png").write_bytes(n.encode())
    dst = face_fix.default_dst(prod / "images" / "sec-03-v2.png")
    v2 = prod / "edits" / "v2"
    check("a fix on a Day 6 secondary opens v2 under the SAME generation name",
          dst == v2 / "sec-03-v2.png", dst)
    have = sorted(f.name for f in v2.iterdir() if f.suffix == ".png") if v2.is_dir() else []
    want = sorted(["main-01.png"] + [f"{n}.png" for n in secs])
    check("the new round holds all nine adopted files", have == want, have)
    check("and keeps the FIXED main from v1, not the original",
          (v2 / "main-01.png").read_bytes() == b"main-FIXED-day5" if (v2 / "main-01.png").is_file() else False)
    check("a -rejected evidence file is not promoted into the round",
          not (v2 / "main-01-rejected.png").exists())
    check("a -render evidence file is not promoted into the round",
          not (v2 / "main-01-render.png").exists())
    check("canonical_name keeps a generation's -v2 identity",
          face_fix.canonical_name(Path("sec-03-v2.png")) == "sec-03-v2.png",
          face_fix.canonical_name(Path("sec-03-v2.png")))
    check("and still strips the temporary fix suffix off a -v2 generation",
          face_fix.canonical_name(Path("sec-03-v2-faces-fixed.png")) == "sec-03-v2.png")

    print()
    # --- one asset, one file per round: a .jpg fix stays a .jpg (9 September 2026)
    # canonical_name wrote every fix as .png, so images/sec-02.jpg was adopted
    # into edits/v1 as sec-02.jpg AND its fix landed as sec-02.png beside it.
    # Every name-based resolver then kept serving the unfixed jpg.
    prod = (Path(tempfile.mkdtemp()) / "fondue").resolve()
    (prod / "images").mkdir(parents=True)
    (prod / "status.md").write_text("x")
    jpg = prod / "images" / "sec-02.jpg"
    Image.fromarray(np.zeros((256, 256, 3), dtype="uint8")).save(jpg, quality=95)
    openai.OpenAI = lambda *a, **k: FakeClient
    try:
        # FakeClient's render is 300x400; run() resizes it to the source grid
        dst = face_fix.run(jpg, [(64, 64, 128, 128)], quality="low")
    finally:
        openai.OpenAI = real
    v1 = prod / "edits" / "v1"
    check("a .jpg original is fixed as .jpg under its canonical name",
          dst == v1 / "sec-02.jpg", dst)
    same_asset = sorted(f.name for f in v1.iterdir() if f.stem == "sec-02")
    check("and the round holds ONE file for that asset", same_asset == ["sec-02.jpg"], same_asset)
    check("the written jpg opens and carries the fix",
          dst.is_file() and Image.open(dst).format == "JPEG"
          and np.asarray(Image.open(dst).convert("RGB"))[90:102, 90:102].mean() > 100)
    check("adopted_set serves the FIXED file, not the unfixed copy",
          face_fix.adopted_set(prod).get("sec-02.jpg") == dst and "sec-02.png" not in face_fix.adopted_set(prod))
    check("a loose .jpg lands beside the source in its own format",
          face_fix.default_dst(Path(tempfile.mkdtemp()) / "photo.jpg").name == "photo-faces-fixed.jpg")

    # --- the two regexes agree on `_fix2` (9 September 2026) -----------------
    # is_evidence matched only `-`, so images/sec-05_fix2.png was adopted as a
    # gallery member while canonical_name stripped it to sec-05.png.
    check("sec-05_fix2.png is evidence, like sec-05-fix2.png",
          face_fix.is_evidence("sec-05_fix2.png") and face_fix.is_evidence("sec-05-fix2.png"))
    check("and canonical_name agrees it is a fix of sec-05",
          face_fix.canonical_name(Path("sec-05_fix2.png")) == "sec-05.png")
    check("a generation's own _v2 is still not evidence", not face_fix.is_evidence("sec-05_v2.png"))

    print()
    # --- no pixel outside the box union may change (finding 4, face-mask part) --
    # The feathered mask used to blur OUTWARD past the box, so the ring just
    # outside the box took render pixels while the docstring promised "original
    # by construction". Black base, white render: any non-zero outside is drift.
    tmp2 = Path(tempfile.mkdtemp())
    black = np.zeros((256, 256, 3), dtype="uint8")
    src2 = tmp2 / "black.png"
    Image.fromarray(black).save(src2)
    white = np.full((256, 256, 3), 255, dtype="uint8")

    class WhiteClient:
        class images:
            @staticmethod
            def edit(**kw):
                import io
                buf = io.BytesIO()
                Image.fromarray(white).save(buf, format="PNG")
                return type("R", (), {"data": [FakeData(buf.getvalue())]})

    openai.OpenAI = lambda *a, **k: WhiteClient
    try:
        dst = face_fix.run(src2, [(64, 64, 128, 128), (120, 60, 200, 100)], quality="low")
    finally:
        openai.OpenAI = real
    out = np.asarray(Image.open(dst).convert("RGB")).astype(int)
    allowed = np.zeros((256, 256), dtype=bool)
    allowed[64:128, 64:128] = True
    allowed[60:100, 120:200] = True
    outside_changed = int((out.max(axis=2) > 0)[~allowed].sum())
    check("no pixel outside the box union changes, boundary ring included",
          outside_changed == 0, f"{outside_changed} outside pixels changed")
    check("and the render DID land inside the boxes", out[90:102, 90:102].mean() > 200,
          out[90:102, 90:102].mean())


    print()
    # --- an A+ head at a module edge is fixed ACROSS the seam (10 September 2026)
    # Day 7 desktop hero: the woman's face sat in m1, her neck and shoulders ran
    # on into m2. The clinic replaced the face inside m1 alone, "0 outside" and
    # the edge rows all passed, and the neck was cut at the module edge: a
    # visible seam. The fix joins the neighbouring module(s), edits ONCE on the
    # joined image with the box grown to hold the whole person across the seam,
    # re-cuts at the original boundaries and writes every touched module into
    # the same round, with two seam crops beside them for the eyes.
    import io
    prod = (Path(tempfile.mkdtemp()) / "fondue").resolve()
    (prod / "images").mkdir(parents=True)
    (prod / "status.md").write_text("x")
    exp = prod / "aplus" / "export" / "desktop"
    exp.mkdir(parents=True)
    W, H = 400, 300
    mods = [np.full((H, W, 3), c, dtype="uint8")
            for c in ((200, 60, 60), (60, 200, 60), (60, 60, 200))]
    mods[0][180:300, 150:250] = (230, 190, 160)      # head + neck, bottom of m1
    mods[1][0:80, 110:290] = (230, 190, 160)         # neck + shoulders, top of m2
    for i, a in enumerate(mods, 1):
        Image.fromarray(a).save(exp / f"m{i}.png")
    seen = {"sizes": []}

    class JoinClient:
        class images:
            @staticmethod
            def edit(**kw):
                sent = Image.open(kw["image"][0]).convert("RGB")
                seen["sizes"].append(sent.size)
                arr = np.asarray(sent).copy()
                # the render repaints the person region wherever it lands; on a
                # joined m1+m2 that is rows 180..380, on a lone module rows 180..300
                arr[180:380, 110:290] = (90, 140, 200)
                buf = io.BytesIO()
                Image.fromarray(arr).save(buf, format="PNG")
                return type("R", (), {"data": [FakeData(buf.getvalue())]})

    def try_run(src, boxes):
        openai.OpenAI = lambda *a, **k: JoinClient
        try:
            return face_fix.run(src, boxes, quality="low")
        except BaseException as e:            # SystemExit included: a refusal is a failure here
            print(f"        run raised {type(e).__name__}: {e}")
            return None
        finally:
            openai.OpenAI = real

    head = [(150, 190, 250, 290)]                     # 10 px from m1's bottom edge
    dst = try_run(exp / "m1.png", head)
    v1 = prod / "edits" / "v1" / "aplus" / "desktop"
    check("a head near the module's bottom edge sends the JOINED m1+m2 to the model",
          seen["sizes"] and seen["sizes"][0] == (W, 2 * H), seen["sizes"])
    check("the fixed m1 lands in the round's aplus/desktop under its own name",
          dst == v1 / "m1.png", dst)
    check("and the touched neighbour m2 lands in the SAME round", (v1 / "m2.png").is_file())
    check("the untouched m3 is in the round too, byte-identical to its export",
          (v1 / "m3.png").is_file() and (v1 / "m3.png").read_bytes() == (exp / "m3.png").read_bytes())
    sizes = [Image.open(v1 / f"m{i}.png").size for i in (1, 2)] if (v1 / "m2.png").is_file() else []
    check("both outputs are re-cut to exactly 400x300", sizes == [(W, H), (W, H)], sizes)
    joint = getattr(face_fix, "LAST_JOINT", None) or {}
    box = joint.get("box")
    check("the engine reports the joint box it used on the joined image", bool(box), joint)
    if box and sizes == [(W, H), (W, H)]:
        allowed = np.zeros((2 * H, W), dtype=bool)
        x1, y1, x2, y2 = box
        allowed[y1:y2, x1:x2] = True
        check("the joint box crosses the seam on both sides", y1 < H - 20 and y2 > H + 20, box)
        page_in = np.concatenate([mods[0], mods[1]]).astype(int)
        page_out = np.concatenate([np.asarray(Image.open(v1 / f"m{i}.png").convert("RGB")) for i in (1, 2)]).astype(int)
        drift = int((np.abs(page_in - page_out).max(axis=2) > 0)[~allowed].sum())
        check("outside the joint box union both modules are byte-identical to the inputs",
              drift == 0, f"{drift} pixels drifted")
        centre = page_out[230:260, 190:210].mean(axis=(0, 1))
        check("and the new person DID arrive across the seam",
              abs(centre[0] - 90) < 30 and abs(centre[2] - 200) < 30, centre.round())
        below = page_out[H + 10:H + 30, 190:210].mean(axis=(0, 1))
        check("including the neck rows in m2", abs(below[0] - 90) < 30 and abs(below[2] - 200) < 30, below.round())
    two_x, one_x = v1 / "seam-1-2-2x.png", v1 / "seam-1-2-1x.png"
    check("the seam band at 2x is written beside the fixed files",
          two_x.is_file() and Image.open(two_x).size == (2 * W, 2 * face_fix.SEAM_BAND if hasattr(face_fix, "SEAM_BAND") else 600),
          Image.open(two_x).size if two_x.is_file() else "missing")
    check("and the 1:1 context crop is written and fits the page",
          one_x.is_file() and Image.open(one_x).size[0] <= W and 0 < Image.open(one_x).size[1] <= 2 * H,
          Image.open(one_x).size if one_x.is_file() else "missing")
    check("seam crops are evidence, never adopted as modules",
          face_fix.is_evidence("seam-1-2-2x.png") and "seam-1-2-2x.png" not in
          (face_fix.aplus_adopted_set(prod, "desktop") if hasattr(face_fix, "aplus_adopted_set") else {"seam-1-2-2x.png": 1}))

    # the adopted copy is the input: mark the round's m1 so it differs from the export,
    # then fix the EXPORT path; the mark must survive into v2, the export's rows must not
    if (v1 / "m1.png").is_file():
        marked = np.asarray(Image.open(v1 / "m1.png").convert("RGB")).copy()
        marked[0:20, 0:40] = (1, 2, 3)
        Image.fromarray(marked).save(v1 / "m1.png")
    seen["sizes"].clear()
    dst = try_run(exp / "m1.png", head)
    v2 = prod / "edits" / "v2" / "aplus" / "desktop"
    check("a fix on the export path opens the next round", dst == v2 / "m1.png", dst)
    got = np.asarray(Image.open(v2 / "m1.png").convert("RGB"))[0:20, 0:40] if (v2 / "m1.png").is_file() else None
    check("and works from the ADOPTED copy, not the export",
          got is not None and (got == (1, 2, 3)).all(), None if got is None else got[0, 0])

    # the one automatic retry: when the feather would land on changed content
    # (a re-rendered shoulder), the box grows by the neck height and runs once more
    class WideClient(JoinClient):
        class images:
            @staticmethod
            def edit(**kw):
                sent = Image.open(kw["image"][0]).convert("RGB")
                seen["sizes"].append(sent.size)
                arr = np.asarray(sent).copy()
                arr[180:520, 110:290] = (90, 140, 200)       # the render repaints far down into m2
                buf = io.BytesIO()
                Image.fromarray(arr).save(buf, format="PNG")
                return type("R", (), {"data": [FakeData(buf.getvalue())]})
    seen["sizes"].clear()
    openai.OpenAI = lambda *a, **k: WideClient
    try:
        face_fix.run(exp / "m1.png", head, quality="low")
    except BaseException as e:
        print(f"        run raised {type(e).__name__}: {e}")
    finally:
        openai.OpenAI = real
    joint = getattr(face_fix, "LAST_JOINT", None) or {}
    check("a box whose edge band lands on changed content retries ONCE, grown by the neck height",
          joint.get("attempts") == 2 and len(seen["sizes"]) == 2 and joint.get("box", (0, 0, 0, 0))[3] > 416,
          (joint.get("attempts"), seen["sizes"], joint.get("box")))
    check("and the joint box never grows upward for a head that meets the seam from above",
          joint.get("box", (0, 0, 0, 0))[1] == 190, joint.get("box"))
    # kit v36: a second attempt still over the limit is evidence, never the fix (reproduced 10 September 2026:
    # v35 broke out of the loop and wrote it as the fix)
    v3 = prod / "edits" / "v3" / "aplus" / "desktop"
    check("a failed second attempt is NOT promoted: the round's m1 is the retained parent, byte for byte",
          (v3 / "m1.png").is_file() and (v3 / "m1.png").read_bytes() == (v2 / "m1.png").read_bytes())
    check("and the attempt is kept as -rejected evidence beside it",
          (v3 / "m1-rejected.png").is_file() and (v3 / "m2-rejected.png").is_file(),
          sorted(f.name for f in v3.iterdir()) if v3.is_dir() else "no v3")
    ad = face_fix.aplus_adopted_set(prod, "desktop")
    check("which the resolver never adopts",
          ad.get("m1.png") == v3 / "m1.png" and "m1-rejected.png" not in ad, {k: str(v) for k, v in ad.items()})
    check("and the engine reports the rejection with nothing written",
          joint.get("rejected") is True and joint.get("written") == [], joint)

    # kit v36: protect boxes. The joint box grows sideways by the shoulder ratio; a protect box on
    # the product trims that growth back, and the region proof is written before any spend.
    seen["sizes"].clear()
    openai.OpenAI = lambda *a, **k: JoinClient
    try:
        dst = face_fix.run(exp / "m1.png", head, quality="low", protect=[(0, 0, 120, 600)])
    except BaseException as e:
        print(f"        run raised {type(e).__name__}: {e}")
        dst = None
    finally:
        openai.OpenAI = real
    joint = getattr(face_fix, "LAST_JOINT", None) or {}
    check("a protect box beside the head trims the joint box's sideways growth back to its edge (115 -> 120)",
          joint.get("box", (0,))[0] == 120, joint.get("box"))
    check("and the neck growth past the seam is kept", joint.get("box", (0, 0, 0, 0))[3] > 300, joint.get("box"))
    check("the region proof is written beside the fixed module as -boxes evidence",
          dst is not None and (dst.parent / "m1-boxes.png").is_file(), dst)
    check("and a -boxes copy is evidence for every resolver",
          face_fix.is_evidence("m1-boxes.png") and face_fix.is_evidence("amz-module-01-desktop-boxes.jpg")
          and face_fix.is_evidence("m1_boxes.png") and "m1-boxes.png" not in face_fix.aplus_adopted_set(prod, "desktop"))
    before = len(face_fix.rounds(prod))
    proof = face_fix.run(exp / "m1.png", head, quality="low", protect=[(0, 0, 120, 600)], dry_run=True)
    check("a dry run writes the proof, spends nothing and opens no round",
          proof is not None and Path(proof).is_file() and len(face_fix.rounds(prod)) == before, proof)
    try:
        face_fix.run(exp / "m1.png", head, quality="low", protect=[(200, 250, 300, 320)], dry_run=True)
        refused = False
    except SystemExit:
        refused = True
    check("a head box that overlaps a protect box is refused before any spend", refused)

    # a head in the middle of a module never stacks; a gallery frame never stacks
    seen["sizes"].clear()
    dst = try_run(exp / "m2.png", [(150, 100, 250, 200)])
    check("a head clear of both edges is fixed on its module alone",
          seen["sizes"] == [(W, H)], seen["sizes"])
    check("and still lands in the round's aplus/desktop under its own name",
          dst is not None and dst.parent.parent.name == "aplus" and dst.parent.name == "desktop" and dst.name == "m2.png", dst)
    gal = prod / "images" / "sec-01.png"
    Image.fromarray(mods[0]).save(gal)
    seen["sizes"].clear()
    dst = try_run(gal, head)
    check("a gallery frame with a head at its bottom edge never stacks",
          seen["sizes"] == [(W, H)], seen["sizes"])
    check("and lands as before, at the round's top level",
          dst is not None and dst.parent.name.startswith("v") and dst.name == "sec-01.png", dst)
    check("with no seam evidence", not list(dst.parent.glob("seam-*")) if dst else False)

    print()
    # --- the Day 7 kit review, each reproduced offline 10 September 2026 (kit v36) ---
    # (1) the feather reaches the original AT the boundary. Black base, white
    # render, box (80,80,320,320): v35 read 0 / 130 / 255 at the pixel outside,
    # the first inside, the centre. A hard step, whatever the outside count said.
    blk = Image.new("RGB", (400, 400), (0, 0, 0))
    wht = Image.new("RGB", (400, 400), (255, 255, 255))
    res, allowed, inside, outside, ring = face_fix._composite(blk, wht, [(80, 80, 320, 320)])
    row = np.asarray(res)[200, :, 0].astype(int)
    check("just outside the box the pixel is the original", row[79] == 0, row[79])
    check("the first pixel inside is the original too, not half the render (was 130)", row[80] <= 8, row[80])
    ramp = row[80:200]
    check("the blend rises monotonically to full strength inside the box",
          (np.diff(ramp) >= 0).all() and ramp[-1] == 255, list(ramp[:45]))
    check("with no step above 12 levels between neighbouring pixels", int(np.diff(ramp).max()) <= 12, int(np.diff(ramp).max()))
    check("and the engine reports the boundary ring at or under the limit", ring <= face_fix.BOUNDARY_LIMIT, ring)
    old = Image.new("L", (400, 400), 0)
    from PIL import ImageDraw as _ID, ImageFilter as _IF
    _ID.Draw(old).rounded_rectangle((80, 80, 319, 319), radius=30, fill=255)
    old = Image.composite(old.filter(_IF.GaussianBlur(20)), Image.new("L", (400, 400), 0), allowed)
    check("boundary_ring_max reads the old clipped blur as a step (over 100)",
          face_fix.boundary_ring_max(old, allowed) > 100, face_fix.boundary_ring_max(old, allowed))

    # (2) the tone match arithmetic. Original 100, edit 105: v35 "corrected" to 94.
    o5 = Image.new("RGB", (400, 400), (100, 100, 100))
    e5 = Image.new("RGB", (400, 400), (105, 105, 105))
    m5 = np.asarray(face_fix._tone_match(o5, e5, (150, 150, 250, 250))).astype(int)
    check("a constant +5 shift is corrected back to the original, not past it (was 94)",
          abs(m5[200, 200, 0] - 100) <= 1, m5[200, 200])
    grad = np.tile(np.linspace(80, 120, 400), (400, 1))
    og = np.stack([grad] * 3, axis=2).astype("uint8")
    eg = np.clip(og.astype(int) + 8, 0, 255).astype("uint8")
    mg = np.asarray(face_fix._tone_match(Image.fromarray(og), Image.fromarray(eg), (150, 150, 250, 250))).astype(int)
    err = int(np.abs(mg[160:240, 160:240] - og[160:240, 160:240].astype(int)).max())
    check("a gradient under a +8 shift comes back within 2 levels of the original across the box", err <= 2, err)

    # (3) the joint box grows into the product; a protect box trims it back; the seam is still crossed
    drawn = (1136, 20, 1464, 545)
    box, sides = face_fix.joint_box(drawn, [600], (1464, 1200), 600)
    check("the review's geometry: the joint box grows sideways into x=1021", box == (1021, 20, 1464, 1092), box)
    fountain = (700, 100, 1130, 590)
    t1 = face_fix.clamp_to_protect(box, drawn, [fountain])
    check("with the fountain protected the box is trimmed to the fountain's edge and keeps the neck",
          t1 == (1130, 20, 1464, 1092), t1)
    text = (1000, 700, 1464, 760)
    t2 = face_fix.clamp_to_protect(box, drawn, [fountain, text])
    check("a text line under the neck costs the depth and keeps the shoulders", t2 == (1130, 20, 1464, 700), t2)
    try:
        face_fix.validate_joint(t2, drawn, sides, [600], 600, [fountain, text])
        ok = True
    except SystemExit:
        ok = False
    check("and the trimmed box still crosses the seam by the margin, so it validates", ok)
    text_at_seam = (1000, 560, 1464, 640)
    t3 = face_fix.clamp_to_protect(box, drawn, [text_at_seam])
    try:
        face_fix.validate_joint(t3, drawn, sides, [600], 600, [text_at_seam])
        ok = True
    except SystemExit:
        ok = False
    check("a protect box across the seam under the head is refused before any spend", not ok, t3)
    try:
        face_fix.check_protect([drawn], [(1400, 500, 1464, 600)])
        ok = True
    except SystemExit:
        ok = False
    check("a head box that overlaps a protect box is a refusal", not ok)

    # (4) files resolve by the SELECTED export, not by filename alone. Concept A (7 modules) fixed in
    # v1, then concept B (6 modules) exported under the same names: v35 resolved to 7, all from v1.
    prod2 = (Path(tempfile.mkdtemp()) / "fondue").resolve()
    (prod2 / "images").mkdir(parents=True)
    (prod2 / "status.md").write_text("x")
    exp2 = prod2 / "aplus" / "export" / "desktop"
    exp2.mkdir(parents=True)
    def export(n, shade):
        for f in exp2.iterdir():
            f.unlink()
        for i in range(1, n + 1):
            Image.new("RGB", (40, 20), (shade, i, 0)).save(exp2 / f"amz-module-{i:02d}-desktop.jpg")
    export(7, 200)
    v1 = face_fix.open_round(prod2)
    (v1 / "aplus" / "desktop" / "amz-module-01-desktop.jpg").write_bytes(b"concept-A-fixed")
    lin = v1 / "aplus" / face_fix.LINEAGE_FILE
    check("a round that carries A+ files records the export it descends from",
          lin.is_file() and "desktop: " in lin.read_text(), lin.read_text() if lin.is_file() else "missing")
    export(6, 60)
    ad = face_fix.aplus_adopted_set(prod2, "desktop")
    check("after a concept switch under the same names the resolver returns the SIX new modules, all from the export",
          len(ad) == 6 and all(p.parent == exp2 for p in ad.values()), {k: str(v.parent.name) for k, v in ad.items()})
    v2 = face_fix.open_round(prod2)
    have = sorted(f.name for f in (v2 / "aplus" / "desktop").iterdir() if f.suffix == ".jpg")
    check("the next round holds the six modules of the new concept, none of the old round's seven",
          have == [f"amz-module-{i:02d}-desktop.jpg" for i in range(1, 7)], have)
    (v2 / "aplus" / "desktop" / "amz-module-01-desktop.jpg").write_bytes(b"concept-B-fixed")
    ad = face_fix.aplus_adopted_set(prod2, "desktop")
    check("a round that descends from the current export IS adopted",
          ad["amz-module-01-desktop.jpg"] == v2 / "aplus" / "desktop" / "amz-module-01-desktop.jpg")
    v3 = face_fix.open_round(prod2)
    (v3 / "aplus" / "desktop" / "amz-module-01-desktop.jpg").write_bytes(b"concept-B-fixed-again")
    (prod2 / "aplus" / "aplus-plan.md").write_text(
        "| Chosen | runId r1 / concept 2 / mode desktop / version 1 / folder edits/v2/aplus/ |\n")
    ad = face_fix.aplus_adopted_set(prod2, "desktop")
    check("the owner's chosen round caps the current set: v2 is served while v3 exists",
          ad["amz-module-01-desktop.jpg"].read_bytes() == b"concept-B-fixed", ad["amz-module-01-desktop.jpg"])
    (prod2 / "aplus" / "aplus-plan.md").write_text("| Chosen | folder aplus/export/desktop/ |\n")
    ad = face_fix.aplus_adopted_set(prod2, "desktop")
    check("with no round named the newest descending round is served",
          ad["amz-module-01-desktop.jpg"].read_bytes() == b"concept-B-fixed-again")
    legacy = prod2 / "edits" / "v4" / "aplus" / "desktop"        # a round from before the record, or opened by hand
    legacy.mkdir(parents=True)
    for i in range(1, 7):
        (legacy / f"amz-module-{i:02d}-desktop.jpg").write_bytes(b"legacy-same-names")
    ad = face_fix.aplus_adopted_set(prod2, "desktop")
    check("a round without a lineage record is NOT adopted while an export exists, even under the export's exact names",
          ad["amz-module-01-desktop.jpg"].read_bytes() == b"concept-B-fixed-again", ad["amz-module-01-desktop.jpg"])
    legacy7 = prod2 / "edits" / "v5" / "aplus" / "desktop"
    legacy7.mkdir(parents=True)
    for i in range(1, 8):
        (legacy7 / f"amz-module-{i:02d}-desktop.jpg").write_bytes(b"legacy-seven")
    ad = face_fix.aplus_adopted_set(prod2, "desktop")
    check("nor when its module set differs from the export's",
          len(ad) == 6 and ad["amz-module-01-desktop.jpg"].read_bytes() == b"concept-B-fixed-again", len(ad))
    (prod2 / "aplus" / "aplus-plan.md").write_text("| Chosen | runId r1 / concept 2 / folder edits/v4/aplus/ |\n")
    ad = face_fix.aplus_adopted_set(prod2, "desktop")
    check("unless the chosen line names that round: then it is served on the owner's word",
          ad["amz-module-01-desktop.jpg"].read_bytes() == b"legacy-same-names", ad["amz-module-01-desktop.jpg"])
    (prod2 / "aplus" / "aplus-plan.md").unlink()

    print()
    # --- the Day 7 kit review, second pass (10 September 2026): three resolver cases, mirrored from the
    # synthetic products the review reproduced them on ---
    NAMES = [f"amz-module-{i:02d}-desktop.jpg" for i in range(1, 8)]

    def product(tag):
        p = (Path(tempfile.mkdtemp()) / tag).resolve()
        (p / "images").mkdir(parents=True)
        (p / "status.md").write_text("x")
        (p / "aplus" / "export" / "desktop").mkdir(parents=True)
        return p

    def export_to(p, shade, size=(40, 20)):
        d = p / "aplus" / "export" / "desktop"
        for f in d.iterdir():
            f.unlink()
        for i, name in enumerate(NAMES, 1):
            Image.new("RGB", size, (shade, i, 0)).save(d / name)

    # caseA: concept A fixed in a HAND-OPENED v1 (no lineage.md), then concept B exported under the
    # same seven names. v36 draft adopted v1 because its filenames equalled the export's.
    pA = product("caseA")
    export_to(pA, 200)
    hand = pA / "edits" / "v1" / "aplus" / "desktop"
    hand.mkdir(parents=True)
    for name in NAMES:
        shutil.copy2(pA / "aplus" / "export" / "desktop" / name, hand / name)
    (hand / NAMES[0]).write_bytes(b"concept-A-typo-fixed-by-/fix")
    (pA / "edits" / "v1" / "round.md").write_text("| file | adopted from |\n|---|---|\n")
    export_to(pA, 60)
    ad = face_fix.aplus_adopted_set(pA, "desktop")
    check("caseA: a hand-opened round with no lineage record is never adopted over a live export",
          len(ad) == 7 and all(p.parent == pA / "aplus" / "export" / "desktop" for p in ad.values()),
          {k: str(v.relative_to(pA)) for k, v in ad.items()})

    # caseB: the SAME concept re-exported (bytes differ, new fingerprint) while the chosen line names
    # edits/v1/aplus/. v36 draft dropped v1 silently and served the raw export.
    pB = product("caseB")
    export_to(pB, 200)
    v1B = face_fix.open_round(pB)
    (v1B / "aplus" / "desktop" / NAMES[0]).write_bytes(b"concept-fixed-in-v1")
    export_to(pB, 201)
    plan = pB / "aplus" / "aplus-plan.md"
    plan.write_text("| Chosen | runId r1 / concept 2 / mode desktop / version 1 / folder edits/v1/aplus/ |\n")
    ad = face_fix.aplus_adopted_set(pB, "desktop")
    check("caseB: the chosen line's round is served on the owner's word, whatever the export's fingerprint now says",
          ad[NAMES[0]].read_bytes() == b"concept-fixed-in-v1", ad[NAMES[0]])
    v2B = face_fix.open_round(pB)
    check("and a round opened from it inherits ITS lineage, not the re-export's fingerprint",
          face_fix.round_lineage(v2B, "desktop") == face_fix.round_lineage(v1B, "desktop")
          and face_fix.round_lineage(v2B, "desktop") != face_fix.export_fingerprint(pB, "desktop"),
          (face_fix.round_lineage(v1B, "desktop"), face_fix.round_lineage(v2B, "desktop")))
    plan.unlink()
    try:
        face_fix.aplus_adopted_set(pB, "desktop")
        stopped, msg = False, ""
    except SystemExit as e:
        stopped, msg = True, str(e)
    check("with no chosen line, a changed export under the same names STOPS instead of serving either set",
          stopped and "edits/v1/aplus/" in msg and "aplus/export/desktop/" in msg, msg[:160])
    plan.write_text("| Chosen | folder aplus/export/desktop/ |\n")
    ad = face_fix.aplus_adopted_set(pB, "desktop")
    check("and a chosen line naming the export is the owner's answer: the export is served, the rounds passed over",
          all(p.parent == pB / "aplus" / "export" / "desktop" for p in ad.values()))

    # caseC: chosen line names edits/v1; a fix opens v2 from it. v36 draft kept serving v1 and no prose
    # said to move the line. Now the engine moves it after the write.
    pC = product("caseC")
    export_to(pC, 200, size=(W, H))
    v1C = face_fix.open_round(pC)
    plan = pC / "aplus" / "aplus-plan.md"
    plan.write_text("# A+ Run Record\n\n| Chosen | runId r1 / concept 2 / mode desktop / version 1 / folder `edits/v1/aplus/` |\n")

    class PaintClient:
        class images:
            @staticmethod
            def edit(**kw):
                sent = Image.open(kw["image"][0]).convert("RGB")
                arr = (255 - np.asarray(sent)).astype("uint8")
                buf = io.BytesIO()
                Image.fromarray(arr).save(buf, format="PNG")
                return type("R", (), {"data": [FakeData(buf.getvalue())]})
    openai.OpenAI = lambda *a, **k: PaintClient
    try:
        dstC = face_fix.run(pC / "aplus" / "export" / "desktop" / NAMES[1], [(150, 100, 250, 200)], quality="low")
    except BaseException as e:
        print(f"        run raised {type(e).__name__}: {e}")
        dstC = None
    finally:
        openai.OpenAI = real
    check("caseC: the fix lands in v2 under the module's own name",
          dstC == pC / "edits" / "v2" / "aplus" / "desktop" / NAMES[1], dstC)
    check("and the chosen line now names edits/v2/aplus/, the rest of the row kept",
          "folder `edits/v2/aplus/` |" in plan.read_text() and "runId r1 / concept 2" in plan.read_text(), plan.read_text())
    ad = face_fix.aplus_adopted_set(pC, "desktop")
    check("so the resolver serves the round the fix just wrote",
          dstC is not None and ad[NAMES[1]] == dstC, ad.get(NAMES[1]))
    check("set_chosen_round says what to write when no plan carries the line",
          face_fix.set_chosen_round(pA, 1) is False and face_fix.set_chosen_round(pC, 2) is True)

    # (review 4) a --protect box that caps the growth: the grow=2 region equals attempt 1's, so the
    # second paid edit was a re-roll while the note claimed growth. Settled before the first spend now.
    seen["sizes"].clear()
    openai.OpenAI = lambda *a, **k: WideClient
    try:
        face_fix.run(exp / "m1.png", head, quality="low", protect=[(0, 416, 400, 600)])
    except BaseException as e:
        print(f"        run raised {type(e).__name__}: {e}")
    finally:
        openai.OpenAI = real
    joint = getattr(face_fix, "LAST_JOINT", None) or {}
    check("a protect box that caps the growth means ONE paid attempt, with the re-roll named as the reason",
          joint.get("attempts") == 1 and len(seen["sizes"]) == 1 and "re-roll" in joint.get("note", ""),
          (joint.get("attempts"), seen["sizes"], joint.get("note")))
    check("and the failed attempt is evidence, never the fix", joint.get("rejected") is True and joint.get("written") == [])

    if FAILURES:
        print(f"FAILED ({len(FAILURES)}): " + ", ".join(FAILURES))
        return 1
    print("FACE CLINIC: all green")
    return 0


if __name__ == "__main__":
    sys.exit(run())

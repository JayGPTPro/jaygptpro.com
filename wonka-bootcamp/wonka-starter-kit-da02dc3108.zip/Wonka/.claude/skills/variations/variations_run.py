#!/usr/bin/env python3
"""Variation-set builder: one tested image set -> the sets for every child SKU.

Engine: gpt-image edits on YOUR OWN OpenAI key (the same Machine 2 the Fixing Room
uses). Two independent layers per child, never one prompt:
  shape  = base frame + a shape reference image (2-image edit)
  text   = the printed count/size/claim on the frames that carry it (1-image edit)
A frame needing both is CHAINED: the shape output becomes the text edit's input.

Non-square frames are padded to square on a sampled background colour, edited, then
cropped back, because the edit model has no 4:5 size.

All paths are relative to the manifest's own folder (variations-work/):
  source/            the tested source set the family is built from
  refs/              shape references, one per target silhouette
  working/<child>/   1024px drafts + <FRAME>_shape.png intermediates

Usage:
  python3 variations_run.py <manifest.json> [--only child[,child...]] [--dry-run]
                            [--frames MAIN[,PT02...]] [--cap USD]
                            [--source-from <product_dir>]
                            [--workers N] [--force]

--dry-run prints the call list, its count and the estimate. Do that before any batch.
--frames restricts the job list to the SELECTED source frames (the owner named one
image or a set as the source). Without it, every frame the manifest lists per child
runs. The restriction is printed on --dry-run.
--cap sets the spend cap in dollars for this run (default `spend_cap_usd` in the
manifest, else 10.0). The estimate is priced from the job list BEFORE any call; above
the cap nothing runs and nothing is spent.
--source-from <product_dir> fills source/ from the product folder: every value in
the manifest's "frames" is resolved by name or stem (main-13 finds main-13.png) to
its newest edits/vN/ copy, else images/, and COPIED in (never moved). Evidence files
(-rejected, -render, -boxes), upscale copies (-2048) and underscore diagnostics are
refused. Each resolved path is printed.
--force regenerates frames that already exist. Needed after editing a prompt:
without it a rerun keeps the old frame and reports "skip (exists)". The estimate
skips frames already on disk unless --force, because a skipped frame costs nothing.

Estimate: every step is one edit call, and a step on a padded (non-square) source
counts as TWO, because the edge-contact check may retry once and the retry is a
paid call. Cap $10 per run.
"""

from __future__ import annotations   # PEP 604 (`Path | None`) in annotations
# is a runtime TypeError on Python 3.9, the version macOS ships. This makes
# annotations lazy strings so the kit runs on a stock Mac.
import base64
import io
import json
import os
import re
import shutil
import sys
import time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

from openai import OpenAI
from PIL import Image

MODEL = os.environ.get("WONKA_IMAGE_MODEL", "gpt-image-2")

# Every prompt carries this. Small drift is acceptable, silent drift is not, so the
# instruction is explicit AND the QA pass measures what moved.
PRESERVE = (
    "CRITICAL: change ONLY what this instruction names. Do NOT change anything else in "
    "the image: keep every other word of text identical, and keep the layout, typography, "
    "colours, background, props, food, lighting, camera angle and framing exactly as they "
    "are. Do not restyle, re-light, re-crop or re-arrange the image."
)

# A non-square frame is padded to square because the model has no 4:5 size, and the
# padding is where hero frames get ruined: asked to redraw the product, the model
# composes it to fill the SQUARE canvas, and the crop back then cuts its sides.
# So pad with headroom AND say the product must stay clear of the edges, then verify
# below instead of hoping.
PAD_HEADROOM = 0.18
KEEP_INSIDE = (
    "FRAMING: the whole product must stay well inside the frame, with clear empty "
    "background margin on all four sides. No part of the product may touch, cross or run "
    "off any edge of the image, and do not enlarge the product to fill the frame. Keep it "
    "at the same scale and position it has now."
)
EDGE_TOLERANCE = 0.03  # share of an edge line that may be product before it counts as clipped

# The spend cap, the same mechanism the Tasting Room uses: estimate from the job list,
# refuse above the cap before the first call, ask the owner once. The unit is the RUN:
# cap $10 per run, one pilot or one family batch.
SPEND_CAP_DEFAULT_USD = 10.0

# All-in price per edit CALL by quality, list prices as of September 2026, rounded UP
# (one 1024 square output plus the one or two input images). Deliberately high, so the
# estimate errs on the side of asking. An unknown quality is priced at the dearest row.
PRICE_PER_CALL_USD = {
    "_as_of": "list prices as of September 2026, rounded up",
    "low": 0.02,
    "medium": 0.07,
    "high": 0.25,
}
_DEAREST_QUALITY = "high"

# The Fixing Room's and Inspection Room's EVIDENCE beside a candidate, never a source:
# a refused attempt, a magnified render, a box overlay, a leading-underscore diagnostic,
# and the Day 5 on-request upscale copies (`main-13-2048.png`), the same list scope.py keeps.
_EVIDENCE = re.compile(r"^(_.*|.*-(1024|1536|2048|3072|4096)|.*[-_](rejected|render\d*|boxes\d*))$", re.I)
IMG_EXT = (".png", ".jpg", ".jpeg", ".webp")


def _load_env_key() -> str:
    """OPENAI_API_KEY from the environment, else from the nearest .env upward."""
    key = os.environ.get("OPENAI_API_KEY", "")
    if key:
        return key
    d = Path.cwd()
    home = Path.home()
    # never walk ABOVE the home folder: past it, the nearest .env is somebody
    # else's project (or /), and a silently borrowed key bills the wrong account
    for folder in [d, *d.parents]:
        if folder == home.parent:
            break
        env = folder / ".env"
        if env.exists():
            for line in env.read_text().splitlines():
                if line.strip().startswith("OPENAI_API_KEY="):
                    return line.split("=", 1)[1].strip().strip('"').strip("'")
    sys.exit("OPENAI_API_KEY not found in the environment or any .env up from here.")


def client() -> OpenAI:
    if OpenAI is None:
        sys.exit("this needs the openai package: python3 -m pip install openai")
    return OpenAI(api_key=_load_env_key(), timeout=600.0)


CLI = None  # set in main


def _bg_colour(im: Image.Image) -> tuple:
    """Sample the frame's corners; listing frames sit on a light ground."""
    w, h = im.size
    pts = [(1, 1), (w - 2, 1), (1, h - 2), (w - 2, h - 2)]
    px = [im.convert("RGB").getpixel(p) for p in pts]
    return tuple(sum(c[i] for c in px) // len(px) for i in range(3))


def edge_contact(im: Image.Image) -> dict:
    """Share of each edge line covered by product pixels, meaning pixels that differ
    from the frame's OWN background colour (corner-sampled), not from hardcoded white.
    A beige or wood ground read against white scores 100% on all four edges with the
    product nowhere near an edge, and a false CLIPPED is worse than none: it discards
    a correct frame and tells the retry to shrink a product already placed right."""
    rgb = im.convert("RGB")
    bg = _bg_colour(rgb)
    w, h = rgb.size
    px = rgb.load()

    def product(pix):
        return max(abs(pix[c] - bg[c]) for c in range(3)) > 12

    return {
        "left": sum(product(px[0, y]) for y in range(h)) / h,
        "right": sum(product(px[w - 1, y]) for y in range(h)) / h,
        "top": sum(product(px[x, 0]) for x in range(w)) / w,
        "bottom": sum(product(px[x, h - 1]) for x in range(w)) / w,
    }


def _corners_agree(im: Image.Image, tol: int = 24) -> bool:
    """True when the four corner pixels are one colour, i.e. the frame HAS a flat
    background for edge_contact to measure against. On a lifestyle scene the corners
    disagree, the background estimate is meaningless, and the clip check must stand
    down: a false CLIPPED discards a correct frame and pays to shrink it."""
    w, h = im.size
    pts = [(1, 1), (w - 2, 1), (1, h - 2), (w - 2, h - 2)]
    px = [im.convert("RGB").getpixel(p) for p in pts]
    return all(max(abs(p[c] - q[c]) for c in range(3)) <= tol for p in px for q in px)


def _to_square(im: Image.Image, headroom: float = 0.0):
    """Pad to square (optionally with headroom), returning (square, crop_meta)."""
    w, h = im.size
    if w == h and not headroom:
        return im, None
    side = round(max(w, h) * (1 + headroom))
    canvas = Image.new("RGB", (side, side), _bg_colour(im))
    box = ((side - w) // 2, (side - h) // 2)
    canvas.paste(im.convert("RGB"), box)
    return canvas, (box[0], box[1], w, h, side)


def _from_square(im: Image.Image, meta):
    if not meta:
        return im
    x, y, w, h, side = meta
    s = im.size[0] / side  # returned edit is 1024 square
    return im.crop((round(x * s), round(y * s), round((x + w) * s), round((y + h) * s)))


def _png_bytes(im: Image.Image, name: str) -> io.BytesIO:
    buf = io.BytesIO()
    im.save(buf, format="PNG")
    buf.name = name
    buf.seek(0)
    return buf


def _call(images, prompt, quality, tries=6):
    """429 is traffic control, not an error. Personal OpenAI orgs rate-limit
    input images per minute on image edits; honour the server's stated wait."""
    for attempt in range(tries):
        try:
            for b in images:
                b.seek(0)
            return CLI.images.edit(model=MODEL,
                                   image=images if len(images) > 1 else images[0],
                                   prompt=prompt, size="1024x1024", quality=quality)
        except Exception as e:
            msg = str(e)
            if "insufficient_quota" in msg or "credit_balance_exhausted" in msg:
                raise SystemExit("the OpenAI account is OUT OF CREDITS (this is not a rate limit; "
                                 "retrying cannot help). Top up at platform.openai.com billing, "
                                 "then rerun the same command; existing outputs are kept.")
            if "verify" in msg.lower() and "organization" in msg.lower() or "403" in msg and "organization" in msg.lower():
                # one account-level block, not N image failures: without this branch
                # a batch printed the same truncated 403 forty times
                raise SystemExit("OpenAI is refusing gpt-image because the ORGANIZATION IS NOT "
                                 "VERIFIED yet (a one-time identity step on OpenAI's side, not a "
                                 "billing problem). Fix: platform.openai.com > Settings > "
                                 "Organization > General > Verify Organization. The kit walks it "
                                 "through in downloads/openai-key-and-verification-walkthrough.md. "
                                 "Verification can take a few minutes to propagate; then rerun, "
                                 "finished files are kept and skipped.")
            if "rate_limit_exceeded" not in msg and "429" not in msg or attempt == tries - 1:
                raise
            m = re.search(r"try again in (\d+(?:\.\d+)?)s", msg)
            wait = float(m.group(1)) + 3 if m else 20 * (attempt + 1)
            print(f"    rate-limited, waiting {wait:.0f}s", flush=True)
            time.sleep(wait)


def edit(base_path: Path, out_path: Path, prompt: str, ref_path: Path | None,
         quality: str = "low", force: bool = False, tries: int = 2) -> str:
    # Existing outputs are kept unless --force: a rerun resumes a rate-limited batch
    # instead of paying for it twice. The flip side, and the trap this exists to close:
    # after EDITING A PROMPT, a plain rerun would silently keep the old frame.
    if out_path.exists() and not force:
        return f"skip (exists) {out_path.name}"
    if out_path.exists():
        # --force means REGENERATE, never destroy: the factory's write-once rule
        # holds here too. The frame being replaced moves aside as -superseded-N,
        # so a regeneration that came out WORSE still has its predecessor.
        n = 1
        while (aside := out_path.with_name(f"{out_path.stem}-superseded-{n}{out_path.suffix}")).exists():
            n += 1
        out_path.rename(aside)
        print(f"    kept the old frame as {aside.name}", flush=True)
    src = Image.open(base_path)
    padded = src.size[0] != src.size[1]
    note = f"\n\n{KEEP_INSIDE}" if padded else ""
    for attempt in range(tries):
        square, meta = _to_square(src, PAD_HEADROOM if padded else 0.0)
        images = [_png_bytes(square, "base.png")]
        if ref_path:
            images.append(_png_bytes(Image.open(ref_path).convert("RGB"), "reference.png"))
        full = f"{prompt}\n\n{PRESERVE}{note}"
        if attempt:  # the first pass came back clipped; say so plainly
            full += ("\n\nThe previous attempt ran the product off the sides of the frame. "
                     "Draw it SMALLER, fully inside, with wide empty margins left and right.")
        r = _call(images, full, quality)
        d = r.data[0]
        if not getattr(d, "b64_json", None):
            raise RuntimeError(f"no image returned for {out_path.name}: {d}")
        cropped = _from_square(Image.open(io.BytesIO(base64.b64decode(d.b64_json))), meta)
        # The clip check exists for padded frames, where the model can run the product
        # over the crop line. It only means anything against a flat background: on a
        # lifestyle scene every edge reads as "product" and the check would shrink a
        # frame that was placed right.
        clipped = {}
        if padded and _corners_agree(cropped):
            hit = edge_contact(cropped)
            clipped = {k: v for k, v in hit.items()
                       if v > EDGE_TOLERANCE and k in ("left", "right", "top")}
        if not clipped or attempt == tries - 1:
            out_path.parent.mkdir(parents=True, exist_ok=True)
            cropped.save(out_path)
            flag = ("  CLIPPED " + ", ".join(f"{k} {v:.0%}" for k, v in clipped.items())
                    if clipped else "")
            return f"wrote {out_path.name}{flag}"
        print(f"    {out_path.name}: clipped ("
              f"{', '.join(f'{k} {v:.0%}' for k, v in clipped.items())}), retrying smaller",
              flush=True)
    # Unreachable while the last attempt always returns above; structural so a future
    # `tries`/flow change fails loudly instead of returning None into the progress line.
    raise RuntimeError(f"edit() fell through its retry loop for {out_path.name}")


def price_per_call(quality: str) -> float:
    return PRICE_PER_CALL_USD.get(quality) or PRICE_PER_CALL_USD[_DEAREST_QUALITY]


def _is_padded(path) -> bool:
    """A non-square source is padded to square for the edit, and a padded frame may
    retry once on edge contact. Unknown (file missing, unreadable) counts as padded:
    the estimate errs on the side of asking."""
    try:
        w, h = Image.open(path).size
    except Exception:  # noqa: BLE001
        return True
    return w != h


def estimate_cost(chains, quality: str = "low", force: bool = False) -> dict:
    """Price a run before it runs. Every step of every chain is one edit call, and a
    step whose SOURCE frame is non-square (padded) counts as TWO: the edge-contact
    check retries once and the retry is a paid call the old estimate ignored. A step
    whose output is already on disk costs nothing and is skipped unless `force`, the
    same rule edit() applies. Deterministic for a given job list and disk state.
    Returns {"usd", "calls", "quality"}."""
    calls = 0
    for _child, _frame, steps in chains:
        per_step = 2 if steps and _is_padded(steps[0][0]) else 1
        for _base, dst, _prompt, _ref in steps:
            if Path(dst).exists() and not force:
                continue
            calls += per_step
    return {"usd": round(calls * price_per_call(quality), 2), "calls": calls, "quality": quality}


def format_estimate(usd: float, cap: float, calls: int) -> str:
    return (f"Estimated: {calls} edit calls on your OpenAI key, about ${usd:.2f} "
            f"(cap ${cap:g} per run; {PRICE_PER_CALL_USD['_as_of']})")


def cap_check(usd: float, cap: float, calls: int = 0):
    """(ok, line). The cap is a ceiling: at or under it runs. Over it, the line is
    the ONE question the skill puts to the owner."""
    if usd <= cap:
        return True, format_estimate(usd, cap, calls)
    return False, (f"This run estimates about ${usd:.2f} ({calls} edit calls), above the ${cap:g} cap. "
                   f"Run it anyway? (a yes runs it with --cap raised for this run only)")


def _candidates(name: str) -> list:
    """The filenames a pick NAME may mean: the name itself, then the name plus each
    image extension when the owner typed a stem (`main-13` means main-13.png). The
    rule scope.py's `_accepted_file` uses in the Tasting Room."""
    out = [name]
    if not Path(name).suffix.lower() in IMG_EXT:
        out += [name + ext for ext in IMG_EXT]
    return out


def resolve_source(product_dir, name: str) -> Path:
    """The CURRENT copy of a tested frame: the same name (or stem) in the newest
    `edits/vN/` round that holds it, else the original in `images/`. The rule the
    Tasting Room and the Fixing Room use. Evidence files (`-rejected`, `-render`,
    `-boxes`), upscale copies (`-2048`) and underscore diagnostics are never a
    source, whatever folder they sit in."""
    product_dir = Path(product_dir)
    if _EVIDENCE.match(Path(name).stem):
        raise ValueError(f"{name} is evidence or a diagnostic, never a source frame")
    rounds = []
    for d in (product_dir / "edits").glob("v*"):
        m = re.fullmatch(r"v(\d+)", d.name)
        if m and d.is_dir():
            rounds.append((int(m.group(1)), d))
    for _, d in sorted(rounds, reverse=True):
        for cand in _candidates(name):
            if (d / cand).is_file():
                return d / cand
    for cand in _candidates(name):
        orig = product_dir / "images" / cand
        if orig.is_file():
            return orig
    raise FileNotFoundError(f"{name} is in no edits/vN/ round and not in images/")


def fill_source(man: dict, root: Path, product_dir) -> list:
    """--source-from: copy every manifest frame into source/ through resolve_source.
    Copy, never move; the product folder is untouched. Returns the resolved paths."""
    src_dir = root / "source"
    src_dir.mkdir(parents=True, exist_ok=True)
    resolved = []
    for frame, name in man["frames"].items():
        try:
            hit = resolve_source(product_dir, name)
        except (ValueError, FileNotFoundError) as e:
            sys.exit(f"--source-from: {frame} = {name}: {e}. Nothing ran.")
        dst = src_dir / hit.name
        if not dst.exists():
            shutil.copy2(hit, dst)
        print(f"  {frame}: {hit} -> source/{dst.name}")
        resolved.append(hit)
    return resolved


def _source_file(src_dir: Path, name: str) -> Path:
    """source/<name>, or source/<stem + ext> when the manifest names a stem."""
    for cand in _candidates(name):
        if (src_dir / cand).is_file():
            return src_dir / cand
    return src_dir / name


def build_jobs(man: dict, root: Path, only: set | None, frames: set | None = None):
    """Flatten the manifest into per-child CHAINS (ordered steps), one chain per frame.
    `frames` restricts the list to the SELECTED source frames (--frames)."""
    src_dir = root / "source"
    ref_dir = root / "refs"
    # An evidence or upscale name in the manifest is refused whatever folder it sits in,
    # --source-from or not: a -rejected or -2048 file is never the frame a family is built on.
    for frame, name in man["frames"].items():
        if _EVIDENCE.match(Path(name).stem):
            sys.exit(f"frames.{frame} = {name} is evidence, an upscale copy or a diagnostic, "
                     f"never a source frame. Nothing ran.")
    src_frames = {k: _source_file(src_dir, v) for k, v in man["frames"].items()}
    refs = {k: ref_dir / v for k, v in man.get("shape_refs", {}).items()}
    chains = []
    for v in man["children"]:
        if only and v["child"] not in only:
            continue
        out_dir = root / "working" / v["child"]
        for frame, spec in v["frames"].items():
            if frames and frame not in frames:
                continue
            steps, cur = [], src_frames[frame]
            if spec.get("shape"):
                if not v.get("shape_ref"):
                    sys.exit(f"{v['child']}: a shape change needs a shape reference "
                             f"(an ASIN image or a photo). Nothing ran.")
                dst = out_dir / f"{frame}_shape.png"
                # The hero frame gets its own wording where one is defined: naming the
                # CURRENT geometry is what makes the MAIN convert (see the skill).
                prompts = man["shape_prompts"]
                if frame == man.get("hero_frame", "MAIN"):
                    prompts = {**prompts, **man.get("hero_shape_prompts", {})}
                # A frame holding several products needs its count named, or the model
                # converts some and leaves the rest.
                per_frame = man.get("frame_shape_prompts", {}).get(frame, {})
                prompt = per_frame.get(v["shape_ref"], prompts[v["shape_ref"]])
                steps.append((cur, dst, prompt, refs[v["shape_ref"]]))
                cur = dst
            if spec.get("text"):
                dst = out_dir / f"{frame}.png"
                steps.append((cur, dst, spec["text"], None))
            elif steps:  # shape-only frame: final name is the frame name
                steps[-1] = (steps[-1][0], out_dir / f"{frame}.png", steps[-1][2], steps[-1][3])
            if steps:
                chains.append((v["child"], frame, steps))
    return chains


def main():
    global CLI
    args = sys.argv[1:]
    if not args or args[0] in ('-h', '--help'):
        sys.exit(__doc__)
    manifest = Path(args[0]).resolve()
    root = manifest.parent
    only = None
    frames = None
    cap_flag = None
    workers, dry, force = 2, False, False
    def flag_value(name):
        i = args.index(name)
        if i + 1 >= len(args) or args[i + 1].startswith("--"):
            sys.exit(f"{name} is missing its value. Nothing ran.")
        return args[i + 1]

    if "--only" in args:
        only = set(flag_value("--only").split(","))
    if "--frames" in args:
        i = args.index("--frames")
        raw = args[i + 1] if i + 1 < len(args) else ""
        if not raw.strip() or raw.startswith("--"):
            sys.exit("--frames is empty. Nothing ran.")
        frames = {f.strip() for f in raw.split(",") if f.strip()}
    if "--cap" in args:
        v = flag_value("--cap")
        try:
            cap_flag = float(v)
        except ValueError:
            sys.exit(f"--cap needs a dollar amount, got {v!r}. Nothing ran.")
    if "--workers" in args:
        v = flag_value("--workers")
        if not v.isdigit():
            sys.exit(f"--workers needs a number, got {v!r}. Nothing ran.")
        workers = int(v)
    if "--dry-run" in args:
        dry = True
    if "--force" in args:
        force = True
    man = json.loads(manifest.read_text())
    if "--source-from" in args:
        product_dir = Path(flag_value("--source-from")).resolve()
        if not product_dir.is_dir():
            sys.exit(f"--source-from {product_dir} is not a folder. Nothing ran.")
        print(f"source/ filled from {product_dir} (copied, never moved):")
        fill_source(man, root, product_dir)
    if frames:
        unknown = sorted(frames - set(man["frames"]))
        if unknown:
            sys.exit(f"--frames names {', '.join(unknown)}, not in the manifest's frames "
                     f"({', '.join(man['frames'])}). Nothing ran.")
    quality = man.get("quality", "low")
    cap = cap_flag if cap_flag is not None else float(man.get("spend_cap_usd", SPEND_CAP_DEFAULT_USD))
    chains = build_jobs(man, root, only, frames)
    total = sum(len(c[2]) for c in chains)
    print(f"{len(chains)} frame-chains, {total} edit calls"
          f"{' (DRY RUN)' if dry else ''}{' [FORCE: existing frames regenerated]' if force else ''}")
    if frames:
        print(f"  frames restricted to {', '.join(sorted(frames))} (the selected source)")
    est = estimate_cost(chains, quality, force=force)
    ok, line = cap_check(est["usd"], cap, est["calls"])
    print(line)
    if dry:
        for child, frame, steps in chains:
            for s in steps:
                print(f"  {child} {frame}: {s[0].name} -> {s[1].name}")
        return
    if not ok:
        sys.exit(f"SPEND CAP. Nothing ran and nothing was spent. {line}")
    CLI = client()

    def run_chain(chain):
        child, frame, steps = chain
        out = []
        for base, dst, prompt, ref in steps:
            try:
                out.append(edit(base, dst, prompt, ref, quality=quality, force=force))
            except Exception as e:  # one frame failing must not kill the batch
                out.append(f"FAILED {child} {frame} -> {dst.name}: {e}")
                break
        return f"{child} {frame}: " + " | ".join(out)

    with ThreadPoolExecutor(max_workers=workers) as ex:
        for line in ex.map(run_chain, chains):
            print(line, flush=True)


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
"""Variation QA: measure what moved that the prompt did not name.

Per generated frame, against its SOURCE frame:
  * a 6x6 tile grid of mean-absolute-difference, so drift is reported by location
    rather than as one meaningless whole-image number
  * drift_score = share of tiles that changed beyond the noise floor
  * a side-by-side + heat-overlay contact sheet per child, for the human pass

Text and shape frames are expected to change where the edit lives; the flag is
drift in tiles the instruction never mentioned. This does not replace opening the
frame. It tells you WHERE to look, and it makes "nothing else changed" checkable.

Paths are relative to the manifest's own folder (variations-work/):
  source/, working/<child>/, qa/<child>/, qa-report.json

Usage: python3 variations_qa.py <manifest.json> [--only child[,child]] [--tiles 6] [--ref]

--ref adds the child's VARIANT REFERENCE as a third tile (source | generated |
reference | drift overlay), so the review answers three questions on one sheet:
is the requested change there, is only that changed, is the product still itself.
The reference is `refs/[shape_ref]` from the manifest, or the child's own
`reference` field. A child with no reference renders the three-tile sheet.
"""
import json
import sys
from pathlib import Path

from PIL import Image, ImageChops, ImageDraw, ImageStat

NOISE = 6.0    # mean-abs-diff below this per tile = re-encode noise, not a change
STRONG = 18.0  # clearly redrawn
W = 420        # tile width on the contact sheet


def tile_diff(a: Image.Image, b: Image.Image, n: int):
    a = a.convert("RGB")
    b = b.convert("RGB").resize(a.size)
    w, h = a.size
    rows = []
    for j in range(n):
        row = []
        for i in range(n):
            box = (i * w // n, j * h // n, (i + 1) * w // n, (j + 1) * h // n)
            d = ImageChops.difference(a.crop(box), b.crop(box))
            row.append(sum(ImageStat.Stat(d).mean) / 3.0)
        rows.append(row)
    return rows


def sheet(src: Image.Image, out: Image.Image, grid, n: int, path: Path, title: str,
          ref=None):
    def fit(im):
        return im.convert("RGB").resize((W, round(W * im.size[1] / im.size[0])))
    a, b = fit(src), fit(out)
    ov = b.copy()
    d = ImageDraw.Draw(ov, "RGBA")
    w, h = ov.size
    for j, row in enumerate(grid):
        for i, v in enumerate(row):
            if v >= NOISE:
                box = (i * w // n, j * h // n, (i + 1) * w // n, (j + 1) * h // n)
                shade = 90 if v < STRONG else 150
                d.rectangle(box, fill=(255, 60, 0, shade // 2),
                            outline=(255, 60, 0, shade), width=2)
    tiles = [a, b, ov]
    names = "source | generated | drift overlay"
    if ref is not None:
        tiles = [a, b, fit(ref), ov]
        names = "source | generated | reference | drift overlay"
    H = max(t.size[1] for t in tiles) + 26
    canvas = Image.new("RGB", (W * len(tiles) + 10 * (len(tiles) - 1), H), "white")
    for k, im in enumerate(tiles):
        canvas.paste(im, (k * (W + 10), 26))
    ImageDraw.Draw(canvas).text((6, 8), f"{title}   {names}", fill="black")
    path.parent.mkdir(parents=True, exist_ok=True)
    canvas.save(path)


def main():
    args = sys.argv[1:]
    if not args or args[0] in ('-h', '--help'):
        sys.exit(__doc__)
    manifest = Path(args[0]).resolve()
    root = manifest.parent
    man = json.loads(manifest.read_text())
    def flag_value(name):
        i = args.index(name)
        if i + 1 >= len(args) or args[i + 1].startswith("--"):
            sys.exit(f"{name} is missing its value. Nothing ran.")
        return args[i + 1]

    only = set(flag_value("--only").split(",")) if "--only" in args else None
    tiles = flag_value("--tiles") if "--tiles" in args else "6"
    if not tiles.isdigit():
        sys.exit(f"--tiles needs a number, got {tiles!r}. Nothing ran.")
    n = int(tiles)
    with_ref = "--ref" in args
    src_dir = root / "source"
    report = {}
    for v in man["children"]:
        if only and v["child"] not in only:
            continue
        gen = root / "working" / v["child"]
        if not gen.exists():
            continue
        ref = None
        if with_ref:
            ref_name = v.get("reference") or man.get("shape_refs", {}).get(v.get("shape_ref") or "")
            ref_path = root / "refs" / ref_name if ref_name else None
            if ref_path and ref_path.exists():
                ref = Image.open(ref_path)
            else:
                print(f"  {v['child']}: no reference on disk, three-tile sheet")
        rows = []
        for frame in man["frames"]:
            p = gen / f"{frame}.png"
            if not p.exists():
                continue
            src = Image.open(src_dir / man["frames"][frame])
            out = Image.open(p)
            grid = tile_diff(src, out, n)
            flat = [x for r in grid for x in r]
            changed = [x for x in flat if x >= NOISE]
            hot = [(j, i, round(x, 1)) for j, r in enumerate(grid)
                   for i, x in enumerate(r) if x >= STRONG]
            sheet(src, out, grid, n, root / "qa" / v["child"] / f"{frame}_qa.png",
                  f"{v['child']} {frame}", ref=ref)
            rows.append({
                "frame": frame,
                "drift_score": round(len(changed) / len(flat), 2),
                "max_tile": round(max(flat), 1),
                "strong_tiles": hot,
            })
        report[v["child"]] = {"label": v.get("label", v["child"]), "frames": rows}
        print(f"\n{v['child']}  {v.get('label', '')}")
        for r in rows:
            print(f"  {r['frame']:5s} drift={r['drift_score']:.2f} "
                  f"max_tile={r['max_tile']:5.1f} strong={len(r['strong_tiles'])}")
    out = root / "qa-report.json"
    if only and out.exists():
        # --only re-measures SOME children; the others' scores are still true.
        # Writing only the re-measured ones used to drop every other child from
        # the report, so a spot check erased the record it was spot-checking.
        merged = json.loads(out.read_text())
        merged.update(report)
        report = merged
    if not report:
        print("NOTHING MEASURED: no child in the manifest has files under working/. Run the pilot first.")
    out.write_text(json.dumps(report, indent=2))
    print(f"\nwrote {out}")


if __name__ == "__main__":
    main()

# Morning Briefing Format

<!--
  This template defines how Donna structures your morning briefing.
  The /morning-briefing skill and the scheduled morning task both use this format.
-->

## Output Format

```
## Good morning. Here's your briefing for [DATE].

### Emails
**URGENT** (needs response today)
- [Sender] — [Subject] — [1-line summary + why it's urgent]

**IMPORTANT** (needs attention this week)
- [Sender] — [Subject] — [1-line summary]

**FYI** (no action needed)
- [Sender] — [Subject] — [1-line summary]

**Flagged:** [any emails with dollar amounts, deadlines, or attachments worth noting]

### Drafts Ready
- Reply to [Sender] about [topic]: "[Draft preview — first line]"
- Reply to [Sender] about [topic]: "[Draft preview — first line]"

### Calendar
- [TIME] — [EVENT] — [1-line context or prep note]
- [TIME] — [EVENT] — [1-line context or prep note]
**Conflicts:** [any overlapping events or tight transitions]

### Tasks
**Overdue**
- [TASK] — due [DATE] — [project]

**Due Today**
- [TASK] — [project]

**This Week**
- [TASK] — due [DATE] — [project]

### Promises Due Soon
- Promised [PERSON] to [WHAT] by [DATE] — [STATUS]

### #1 Priority
[THE SINGLE MOST IMPORTANT THING TO DO BEFORE NOON — with reasoning]
```

## Rules for This Briefing

- Keep it under 400 words
- Lead with what matters most
- Flag anything with money, deadlines, or risk
- Skip junk and spam completely
- After generating this briefing, save it to: brain/Daily Logs/[YYYY-MM-DD].md

# Meeting Brief Format

<!--
  This template defines how Donna prepares you for a meeting.
  The /prep-meeting skill uses this format.
-->

## Output Format

```
## Meeting Brief: [PERSON/COMPANY NAME]
**When:** [DATE, TIME]
**Where:** [Zoom / Google Meet / In-person / Phone]

### Who
[1-2 sentences about this person/company. Role, business, relationship to you.]

### Last Interaction
[Date + summary of last email exchange or meeting. What was discussed. What was agreed.]

### Open Items
- [Something unresolved between you]
- [Something they asked for that you haven't delivered]
- [Something you asked for that they haven't delivered]

### What They Probably Want
1. [Best guess based on email history and context]
2. [Best guess]

### Your Agenda
1. **Priority:** [The #1 thing you should accomplish in this meeting]
2. **Secondary:** [Nice to cover if there's time]

### Watch Out For
- [Any sensitive topics, overdue promises, or tricky dynamics]
```

## Rules for Meeting Briefs

- Search Gmail for email history with this person (last 30 days)
- Check Google Calendar for previous meetings
- Check Google Drive for shared documents
- Check brain/People/ for any saved profile
- If this is a first meeting, note that clearly: "First meeting. No prior history found."
- After generating, update or create brain/People/[person-name].md with the latest info

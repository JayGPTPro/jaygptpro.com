# Email Triage Format

<!--
  This template defines how Donna sorts and summarizes your inbox.
  The /morning-briefing and /draft-reply skills use this format.
-->

## Output Format

```
## Email Triage — [DATE]
**Scanned:** [X] emails from the last 24 hours

### URGENT (respond today)
| From | Subject | Summary | Flag |
|------|---------|---------|------|
| [Sender] | [Subject] | [1-line summary] | [$ / deadline / attachment] |

### IMPORTANT (respond this week)
| From | Subject | Summary | Flag |
|------|---------|---------|------|
| [Sender] | [Subject] | [1-line summary] | |

### FYI (no action needed)
| From | Subject | Summary |
|------|---------|---------|
| [Sender] | [Subject] | [1-line summary] |

### Drafts Ready to Review
1. **Reply to [Sender]** — [topic]
   > "[First 2 lines of draft]"

2. **Reply to [Sender]** — [topic]
   > "[First 2 lines of draft]"

### Unanswered (you haven't replied in 3+ days)
- [Sender] — [Subject] — sent [DATE] — [DAYS] days without reply
- [Sender] — [Subject] — sent [DATE] — [DAYS] days without reply
```

## Rules for Email Triage

- Scan unread emails from the last 24 hours (or last 50 if specified)
- URGENT = needs response today (money, deadlines, key contacts, time-sensitive)
- IMPORTANT = needs response this week (business-relevant, questions directed at you)
- FYI = newsletters, notifications, confirmations (no action needed)
- Skip obvious spam and automated notifications
- Flag: $ (dollar amounts), D (deadlines mentioned), A (attachments worth noting)
- Draft replies for URGENT emails in the owner's communication style
- Check brain/Preferences/Style.md for tone and writing patterns
- Never send any email. Draft only.

# Weekly Report Format

<!--
  This template defines how Donna structures your weekly summary.
  The /weekly-report skill uses this format.
-->

## Output Format

```
## Weekly Report — [DATE RANGE]

### Wins
- [Task completed or milestone reached]
- [Task completed or milestone reached]
- [Task completed or milestone reached]

### Not Done (should have been)
- [Task that was due this week but didn't get completed — be direct about it]
- [Task that was due this week but didn't get completed]

### By the Numbers
- Tasks completed: [X]
- Tasks created: [X]
- Tasks overdue: [X]
- Meetings this week: [X]
- Emails flagged as urgent: [X]

### Promises Check
- **Kept:** [Promise delivered on time]
- **Due soon:** [Promise] — due [DATE] — [STATUS]
- **Overdue:** [Promise] — was due [DATE] — [DAYS LATE]

### Patterns
- [Observation about your week — e.g., "You had 12 meetings. 4 had no clear outcome."]
- [Observation — e.g., "Tasks tagged 'admin' took 3x longer than 'content' tasks."]
- [Suggestion — e.g., "Consider batching admin tasks to Tuesday mornings."]

### Next Week
**Meetings:**
| Day | Time | Meeting | Key Context |
|-----|------|---------|-------------|
| [DAY] | [TIME] | [MEETING] | [1-line context] |

**Top 3 Priorities:**
1. [PRIORITY] — why: [REASON]
2. [PRIORITY] — why: [REASON]
3. [PRIORITY] — why: [REASON]

### Open Risks
- [Any deadline clusters, unanswered threads, or overcommitment]
```

## Rules for Weekly Reports

- Pull completed tasks from the connected task manager (if available)
- Pull meetings from Google Calendar (past week + upcoming week)
- Check brain/Business/Promises.md for commitment tracking
- Check brain/Business/Goals.md to measure progress against priorities
- Check brain/Daily Logs/ for context from the past 7 days
- Be direct about what didn't get done. No sugarcoating.
- Keep total report under 500 words
- After generating, save a copy to brain/Daily Logs/[YYYY-MM-DD]-weekly.md

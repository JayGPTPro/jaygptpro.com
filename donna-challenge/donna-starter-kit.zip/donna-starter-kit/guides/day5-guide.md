# Day 5: "She Works While You Sleep"

Today is the final day. Donna becomes autonomous. She'll run on her own every morning and evening, produce weekly reports, and hold you accountable.

## What You'll Do Today

1. Set up 4 Routines (morning, evening, meeting prep, weekly)
2. Run /weekly-report and /accountability
3. See Graph View in Obsidian
4. Complete the Graduation Checklist

## What You'll Need

- Claude Desktop open in the Code tab
- All skills from Day 4 working
- 35 minutes

## What Are Routines?

Routines let Donna run automatically at set times. They run locally on your computer.

**📢 Note:** Routines is the new name (April 2026) for what used to be called "Scheduled Tasks." Same feature, new name.

**📌 Where to find it:** Routines lives in the **left sidebar of the Code tab**, between **Search** and **Dispatch**. If you don't see it, your Claude Desktop may need an update - go to Help > Check for Updates.

**📌 Pro plan limit:** Pro allows 5 Routines/day. Donna uses 4 (morning, evening, meeting prep, weekly). You have 1 left for other automations. If you need more, upgrade to Max (15/day).

**Computer-off scenario:** If your laptop is off when a routine is scheduled, it queues. When you open Claude Desktop next, only the most recent instance runs (no spam if you were away for days).

For full details, read `guides/scheduled-tasks-guide.md`.

## Step 1: Set Up Morning Briefing (7:00 AM)

1. In the Code tab, click **Routines** in the left sidebar
2. Click **+ New Routine**
3. Name: "Morning Briefing"
4. Schedule: Every day at 7:00 AM
5. Prompt:
```
Run /morning-briefing

After generating the briefing, save it to brain/Daily Logs/ with today's date as the filename (YYYY-MM-DD.md format).
```
6. Save and enable

## Step 2: Set Up Evening Summary (9:00 PM)

1. Create another routine
2. Name: "Evening Summary"
3. Schedule: Every day at 9:00 PM
4. Prompt:
```
Run /evening-summary

After generating the summary, append it to today's Daily Log in brain/Daily Logs/ under a "## Evening Summary" heading.
```
5. Save and enable

## Step 3: Set Up Meeting Prep (6:00 PM)

1. Create another routine
2. Name: "Meeting Prep"
3. Schedule: Every day at 6:00 PM
4. Prompt:
```
Run /prep-meeting for every meeting on tomorrow's calendar. Save all briefs to brain/Daily Logs/ under a "## Meeting Prep" heading.
```
5. Save and enable

**Note:** This routine works whether your laptop is on or off at 6:00 PM. If off, it runs when Claude Desktop opens next.

## Step 4: Run /weekly-report

This skill produces a comprehensive weekly summary:
- Wins (what got done)
- Misses (what didn't)
- Numbers (tasks completed vs created, meetings count)
- Promise tracking
- Patterns and insights
- Next week's plan
- What Donna learned this week

```
/weekly-report
```

**Note:** On Day 5 you have only 4-5 days of Donna data, not a full 7. The output will be partial. By the first Sunday it's complete.

Review the output. Then schedule it:

1. Routines → New routine
2. Name: "Weekly Report"
3. Schedule: Every Sunday at 9:00 AM
4. Prompt: `Run /weekly-report and save to brain/Daily Logs/[today's date]-weekly.md`

## Step 5: Run /accountability

This skill holds you accountable:
- Checks brain/Business/Promises.md for overdue commitments
- Reviews brain/Business/Goals.md for progress
- Flags tasks postponed too many times
- Gives you an honest assessment

```
/accountability
```

## Step 6: Graph View in Obsidian

Open Obsidian and click the graph icon in the left sidebar (or press Cmd+G on Mac, Ctrl+G on Windows).

This is Graph View. It shows how everything connects: people, decisions, goals, daily logs. Every [[wiki link]] Donna created between files becomes a visible connection.

**On Day 5, your graph will be sparse (10-20 nodes). That's normal.** It grows over time. By Day 30 you'll see clusters of People connecting to Goals connecting to Decisions.

**Pro tip:** Take a screenshot today. Take another at Day 30. The difference is dramatic.

This is the visual map of everything Donna learned about your business in 5 days.

## Step 7: The Reflection (5 min)

Open `output/business-one-pager.md` (created on Day 2). Read it again.

Then ask Donna:
```
Compare what you knew about me on Day 2 vs what you know now. What's changed? What's sharper?
```

Save her response somewhere. This is your before/after.

In 30 days, ask the same question again. The growth will surprise you.

## Step 8: Graduation Checklist

Go through every item in `guides/graduation-checklist.md`. Check each one as you verify it works.

When everything is checked, take a screenshot and share it in the WhatsApp group.

## What You Built

| What | Details |
|------|---------|
| **CLAUDE.md + donna-character.md** | Donna knows your business, your style, your priorities, and her own personality |
| **4 Connectors** | Gmail, Calendar, Drive, Task Manager (Asana, Monday, ClickUp, or Notion) |
| **12 Skills** | Morning briefing, evening summary, draft reply, meeting prep, tasks, accountability, forgotten emails, block time, risks, weekly report, learn, ask-jay |
| **4 Routines** | Morning briefing (7:00), meeting prep (18:00), evening summary (21:00), weekly report (Sunday 9:00) |
| **Memory System** | Daily Logs, People profiles, Goals, Promises, Decisions, Learning Log |
| **Self-Check Gatekeeper** | Every skill checks itself before delivering |
| **Learning Loop** | Donna gets sharper every evening via /learn |

This is a working AI Chief of Staff. She costs $20/month (Pro). She works on schedule (Routines). She remembers everything.

## Day 6+ Operating Manual

**Tomorrow (Day 6):**
- Morning briefing arrives at 7 AM (or when you open Claude)
- Read it in Obsidian (`brain/Daily Logs/[date].md`)
- Reply to Donna with feedback if anything's off (this trains /learn)
- Use /draft-reply throughout the day
- Evening summary arrives at 9 PM

**First Sunday:**
- Weekly report arrives at 9 AM
- Block 30 min to read it
- Adjust Goals.md if priorities shifted

**First month:**
- Watch /learn slowly improve voice matching
- Add new People manually as Donna encounters them
- Review one custom skill rule each week
- Compare Graph View at Day 30 vs Day 5 screenshot

## What's Next

Donna grows with you. Here's how to keep improving:

1. **Add more skills** as you discover repetitive tasks
2. **Update People profiles** as Donna encounters new contacts
3. **Review Weekly Reports** to spot patterns over time
4. **Update Goals and Promises** when priorities shift
5. **Add more writing samples** so Donna's drafts get closer to your voice
6. **Use /ask-jay** anytime you're stuck or unsure
7. **Trust the Learning Loop** - Donna gets better every day she runs /learn

Congratulations. You just hired your first AI employee.

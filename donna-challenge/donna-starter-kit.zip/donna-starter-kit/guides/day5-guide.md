# Day 5: "She Works While You Sleep"

The final day. Donna becomes autonomous. She runs on her own every morning, every evening, before meetings, and weekly. By the time you wake up tomorrow, your morning briefing is already waiting.

## What You'll Do Today

1. **Lesson 1**: The Big Idea (Routines + Learning. components #7 and #8)
2. **Lesson 2**: Set Up the 4 Routines (morning, meeting prep, evening, weekly)
3. **Lesson 3**: The Learning Loop (`/weekly-report`, `/accountability`, `/learn`)
4. **Lesson 4**: Graduation (Graph View, the reflection, what you built)

## What You'll Need

- Claude Desktop open in the Code tab, kit loaded
- All skills from Day 4 working
- Connectors from Day 3 still active

---

## Lesson 1: The Big Idea (Routines + Learning)

### Part 1A: What "Routines" mean

Until today, Donna has been waiting for you. You open Claude, you type a command, she runs it, she goes back to sleep.

**Today she stops waiting.** Routines let her run on a schedule, automatically, without you opening Claude. Morning briefing at 7am. Meeting prep at 6pm the night before. Evening summary at 9pm. Weekly report Sunday morning.

This is component #7 of Jay's AI Hire Method. **Routines.**

> **Note:** "Routines" is the new name (April 2026) for what used to be called "Scheduled Tasks." Same feature, new name. You'll find it in the **left sidebar of the Code tab** in Claude Desktop, between Search and Dispatch.

> **Pro plan limit:** 5 Routines per day. Donna uses 4. you have 1 left for whatever else.

> **Computer-off scenario:** If your laptop is off when a routine fires, it queues. When you open Claude Desktop next, only the most recent instance runs. no spam if you were away.

### Part 1B: What "Learning" means

Donna doesn't stay the same. Every evening, after the day winds down, she runs a skill called `/learn`. She reviews what happened, what worked, what didn't, and updates her own memory.

After a week, her drafts sound more like you. After a month, she anticipates patterns. After three months, she's nothing like the Donna you met on Day 1.

This is component #8 of Jay's AI Hire Method. **Learning.**

### Part 1C: The "she works while you sleep" moment

Day 5 is the day Donna stops being a tool you use and starts being a teammate who works for you. The morning briefing is waiting before your coffee. The meeting prep arrives the night before. The weekly report lands in your Daily Log every Sunday.

You don't summon her anymore. She just shows up.

---

## Lesson 2: Set Up the 4 Routines

### Part 2A: Where Routines live

In Claude Desktop, in the **Code tab**, look at the left sidebar. Between **Search** and **Dispatch**, you'll see **Routines**.

If you don't see it, go to **Help → Check for Updates** and update Claude Desktop.

Click **Routines** to open the panel. Then click **+ New Routine** for each one we set up.

### Part 2B: Routine #1 . Morning Briefing (7:00 AM)

1. Click **+ New Routine**
2. Name: `Morning Briefing`
3. Schedule: Every day at **7:00 AM** (your local time)
4. Prompt:
```
Run /morning-briefing

After generating the briefing, save it to brain/Daily Logs/ with today's date as the filename (YYYY-MM-DD.md format).
```
5. Save and enable

### Part 2C: Routine #2 . Meeting Prep (6:00 PM evening before)

1. **+ New Routine**
2. Name: `Meeting Prep`
3. Schedule: Every day at **6:00 PM**
4. Prompt:
```
Run /prep-meeting for every meeting on tomorrow's calendar. Save all briefs to brain/Daily Logs/ under a "## Meeting Prep" heading.
```
5. Save and enable

### Part 2D: Routine #3 . Evening Summary (9:00 PM)

1. **+ New Routine**
2. Name: `Evening Summary`
3. Schedule: Every day at **9:00 PM**
4. Prompt:
```
Run /evening-summary

After generating the summary, append it to today's Daily Log in brain/Daily Logs/ under a "## Evening Summary" heading.
```
5. Save and enable

### Part 2E: Routine #4 . Weekly Report (Sunday 9:00 AM)

1. **+ New Routine**
2. Name: `Weekly Report`
3. Schedule: Every **Sunday at 9:00 AM**
4. Prompt:
```
Run /weekly-report and save to brain/Daily Logs/[today's date]-weekly.md
```
5. Save and enable

> Pick whatever times fit your real schedule. The defaults above are a starting point.

**You now have 4 routines running on autopilot.** That's the "she works while you sleep" promise.

---

## Lesson 3: The Learning Loop

### Part 3A: Run /weekly-report manually (preview)

```
/weekly-report
```

**What to expect today:** It'll be partial. you only have 4-5 days of Donna data, not a full 7. The output covers: wins, misses, numbers, promise tracking, patterns, next week's plan, and what Donna learned this week.

By next Sunday it'll be complete. The Routine you set up in Lesson 2 will fire it automatically.

### Part 3B: Run /accountability

```
/accountability
```

This skill holds you accountable. it checks `brain/Business/Promises.md` for overdue commitments, reviews `brain/Business/Goals.md` for progress, flags tasks postponed too many times, and gives you an honest assessment.

Run it weekly. Or whenever you feel things slipping.

### Part 3C: How /learn runs in the background

You don't usually run `/learn` directly. The Evening Summary routine you set up runs it automatically as part of its end-of-day work.

What it does: reviews the day's interactions, notices what worked (and what didn't), and updates `brain/Learning/learning-log.md` with patterns and lessons.

After 30 days of running, that file becomes the most valuable thing in your kit. it's Donna's accumulated wisdom about you.

---

## Lesson 4: Graduation

### Part 4A: Open Graph View in Obsidian (the visual wow)

Open Obsidian. Click the graph icon in the left sidebar (or press **Cmd+G** on Mac, **Ctrl+G** on Windows).

This is **Graph View**. It shows how everything connects. people, decisions, goals, daily logs. Every wiki link Donna created between files becomes a visible connection.

**On Day 5, your graph will be sparse (10-20 nodes). That's normal.** It grows over time. By Day 30 you'll see clusters of People connecting to Goals connecting to Decisions connecting to Daily Logs.

> **Pro tip:** Take a screenshot today. Take another at Day 30. The difference is dramatic.

### Part 4B: The Reflection

Open `output/business-one-pager.md` (the one Donna wrote on Day 2). Read it again.

Then ask Donna:
```
Compare what you knew about me on Day 2 vs what you know now. What's changed? What's sharper?
```

Save her response somewhere safe. This is your before/after snapshot.

In 30 days, ask the same question again. The growth will surprise you.

### Part 4C: What you built (graduation moment)

| What | Details |
|------|---------|
| **Identity + Memory** | Donna knows your business, your style, your priorities, and her own personality |
| **4 Connectors** | Gmail, Calendar, Drive, Task Manager (or operating without one) |
| **14 Skills** | 12 daily skills + `/learn-me` and `/business-one-pager` for onboarding |
| **4 Routines** | Morning briefing (7:00), meeting prep (18:00), evening summary (21:00), weekly report (Sunday 9:00) |
| **Memory System** | Daily Logs, People profiles, Goals, Promises, Decisions, Learning Log |
| **Self-Check Gatekeeper** | Every skill checks itself before delivering |
| **Learning Loop** | Donna gets sharper every evening via `/learn` |

This is a working AI Chief of Staff. She costs $20/month (Pro). She works on schedule. She remembers everything. She gets smarter every day.

**You hired your first AI employee. Congratulations.**

---

## What Day 5 Success Looks Like

- 4 Routines set up and enabled (you can see them in the Routines panel)
- `/weekly-report` ran (partial output is expected today)
- `/accountability` ran. you saw Donna's honest read on your week
- Graph View opened in Obsidian (sparse but live)
- Reflection done. before/after snapshot saved

---

## Day 6+ Operating Manual

**Tomorrow (Day 6):**
- Morning briefing arrives at 7 AM (or when you open Claude after)
- Read it in Obsidian (`brain/Daily Logs/[today's date].md`)
- Reply to Donna with feedback if anything's off. this trains `/learn`
- Use `/draft-reply` throughout the day
- Evening summary arrives at 9 PM

**First Sunday:**
- Weekly report arrives at 9 AM
- Block 30 minutes to read it
- Adjust Goals.md if priorities shifted

**First month:**
- Watch `/learn` slowly improve voice matching
- Add new People manually as Donna encounters them
- Review one custom skill rule each week
- Compare Graph View at Day 30 vs Day 5 screenshot

---

## How to Keep Improving

1. **Add more skills** as you discover repetitive tasks (just create new `.md` files in `.claude/skills/`)
2. **Update People profiles** as Donna encounters new contacts
3. **Review Weekly Reports** to spot patterns over time
4. **Update Goals and Promises** when priorities shift
5. **Add more writing samples** so Donna's drafts get closer to your voice
6. **Use `/ask-jay`** anytime you're stuck or unsure
7. **Trust the Learning Loop**. Donna gets better every day she runs `/learn`

---

## Checklist for Day 5

Only the things that matter:

- [ ] Morning Briefing routine set up (7:00 AM, daily)
- [ ] Meeting Prep routine set up (6:00 PM, daily)
- [ ] Evening Summary routine set up (9:00 PM, daily)
- [ ] Weekly Report routine set up (Sunday 9:00 AM)
- [ ] Ran `/weekly-report` and `/accountability` manually (preview)
- [ ] Opened Graph View in Obsidian (took a screenshot for the 30-day comparison)
- [ ] Saved the reflection answer somewhere

---

## Common Issues / FAQ

**Q: I don't see "Routines" in the sidebar.**
Help → Check for Updates. Update Claude Desktop. The Routines panel was added in a recent version.

**Q: My routine didn't fire at the scheduled time.**
Routines need Claude Desktop to be open at the scheduled time, or they queue and fire when you open it next. If your laptop was off, the most recent instance fires (no spam from missed days).

**Q: `/weekly-report` looks thin.**
Expected on Day 5. You only have 4-5 days of Donna data. By next Sunday it's full power.

**Q: Graph View is empty.**
You need wiki links between files for the graph to populate. Donna creates these automatically as she runs more skills. By Day 30, the graph will be dense.

**Q: Can I add a 5th routine?**
Yes. Pro plan supports 5 routines per day. You used 4 (or 5 if you scheduled the weekly). Max plan supports 15. add whatever fits your work.

---

## Stuck?

Type `/ask-jay [your question]` in Claude. Donna checks all the guides and answers on Jay's behalf.

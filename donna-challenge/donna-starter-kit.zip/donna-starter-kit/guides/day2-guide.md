# Day 2: "Donna, Meet My Business"

Today you teach Donna who you are. By the end, she'll know your business, your goals, your communication style, and she'll prove it by generating a Business One-Pager.

## What You'll Do Today

1. Fill out about-me.md (if not done as Day 1 homework)
2. Run 2 onboarding prompts
3. Test Donna's memory
4. Generate a Business One-Pager (the "wow" moment)

## What You'll Need

- Claude Desktop open in the Code tab
- The donna-starter-kit folder loaded
- Your Day 1 homework (the answers about you, your business, your people, your voice)
- 45-60 minutes

## Before You Start: Look at the Demo (5 min, Optional)

If you're not sure what "good" looks like, **open the demo first**.

There's a complete, filled-in Donna available as a separate download:
```
donna-demo-alex-rivera/        (download from portal as a separate zip)
```

This is **Alex Rivera**, a fictional Amazon FBA seller (bamboo cutting boards). Her brain/, samples/, and output/ are all filled in with realistic data.

**If you downloaded the demo:**
- Open `donna-demo-alex-rivera/` as a SECOND vault in Obsidian (alongside your starter kit)
- Browse these files for inspiration:
  - `brain/Business/about-me.md` - see what a complete answer looks like
  - `brain/Business/my-business.md` - see what Donna generates from it
  - `output/business-one-pager.md` - see the wow moment

**Don't copy Alex's content.** Use it as inspiration for FORMAT and DETAIL LEVEL. Then go fill yours with YOUR business.

**If you didn't download the demo:** That's fine. Skip this step. The instructions below work without it.

---

## Step 1: Fill Out about-me.md (20-30 min)

Open `brain/Business/about-me.md` in Obsidian (or any text editor). This is the one file YOU fill out. Answer every question honestly and specifically.

**Good:** "I run a wholesale real estate company in Dallas. We buy distressed properties and sell to investors."
**Too vague:** "I'm in real estate."

The file has 7 parts:
1. Who I Am (name, role, location)
2. My Business (what you sell, who you sell to, key numbers, biggest challenge)
3. Key People (5-10 contacts with name, role, relationship)
4. Current Priorities (top 3 this quarter)
5. Communication Style (greetings, sign-offs, words you use, words you avoid)
6. Writing Samples (3-5 actual emails you've sent)
7. Active Promises (yours + others')

If you already filled this out as Day 1 homework, just paste it in and review.

**Important: Part 6 (Writing Samples) is critical.** Without 3-5 real emails, Donna can't match your voice. Don't skip this.

**Stuck on what to write?** If you downloaded the demo, check `donna-demo-alex-rivera/brain/Business/about-me.md` for an example of how detailed each section should be.

---

## Step 2: Run Prompt 1 - Learn Everything (10 min)

This is the master onboarding prompt. Donna reads your about-me.md, fills 4 files, analyzes your writing style, saves your samples, and verifies she got everything right - all in one pass.

1. In Obsidian, open `prompts/01-learn-everything.md`
2. Copy the entire prompt text (everything inside the ``` code block ```)
3. Paste into Claude Desktop
4. Press Enter
5. Wait 60-90 seconds. Donna works through all 3 steps.

**When she's done, she'll show you a summary with:**
- What she learned about you
- A verification check (name, priorities, people, writing style)
- Files she updated
- Anything unclear or missing

### Verify in Obsidian:

- [ ] `brain/Business/my-business.md` - has your real business info
- [ ] `brain/Business/Goals.md` - top 3 goals listed
- [ ] `brain/Preferences/Style.md` - specific patterns from YOUR emails (not generic)
- [ ] `brain/Business/Promises.md` - if you filled Part 7, promises are tracked
- [ ] `samples/` - individual files: sample-01.md, sample-02.md, etc.

### THIS IS YOUR QUALITY GATE

**Read Donna's verification check carefully.**

- ✅ **Everything accurate?** Continue to Prompt 2
- ❌ **Anything wrong?** Edit about-me.md → re-run Prompt 1 (it's safe to re-run, won't break anything)
- ❌ **Verification feels generic?** Your about-me.md is too sparse. Add more detail and re-run.

The Business One-Pager (Prompt 2) will only be as good as this foundation.

---

## Step 3: Run Prompt 2 - Business One-Pager (THE WOW) (10 min)

1. **Before running:** In your notebook, write 2-3 sentences describing your business as YOU see it. Save it somewhere.
2. In Obsidian, open `prompts/02-business-one-pager.md`
3. Copy the entire prompt block
4. Paste into Claude Desktop
5. Press Enter
6. Wait 1-2 min. Donna creates `output/business-one-pager.md`

### Compare to your 2-3 sentences:
- Did Donna miss anything important?
- Did she catch anything you forgot to mention?
- Does her "First Impression" section feel insightful or generic?

✅ **If insightful and accurate:** Onboarding worked. You're ready for Day 3.
❌ **If generic:** Your source data (about-me.md) was too light. Add more, re-run Prompt 1, re-run Prompt 2.

---

## Step 4: Test Donna's Memory (10 min)

Now test that Donna can save new information to brain/ when you tell her to.

**Test 1 - Save a fact about a person:**
```
Remember this: [pick a real fact about a real person you work with]. Save to brain/People/.
```
*Example for service business:* "Maya, my lead instructor, prefers texts over emails for schedule changes."
*Example for product business:* "Mike, my main supplier, always takes 3-5 days to respond."
*Example for B2B:* "Lisa from Acme is the decision maker but Tom (her assistant) is the one who actually replies."

Check Obsidian. There should be a new file in `brain/People/` with this information.

**Test 2 - Save a decision:**
```
Save this decision to brain/Business/Decisions.md: [a real recent decision you made + why]
```
*Example for service:* "We decided to raise membership prices by 15% in Q3 because new instructor costs are up."
*Example for product:* "We decided to pause Facebook ads until Q3 and focus budget on PPC instead."

Check Decisions.md. The new entry should be there.

This is how Donna builds long-term memory. Every fact, decision, and preference gets stored and connected via [[wiki links]].

**Test 3 - Voice check:**
```
Draft a follow-up email to a client named Pat about a proposal we sent last week. Pat hasn't responded yet.
```

Read the draft. Does it sound like YOU wrote it (greeting, sign-off, tone, length)? If not → add more writing samples to about-me.md and re-run Prompt 1.

---

## Checklist

- [ ] `brain/Business/about-me.md` filled completely (all 7 parts, no empty fields)
- [ ] Ran Prompt 1 (Learn Everything) → 4 brain files + samples/ populated
- [ ] Read Donna's verification check - everything accurate
- [ ] Ran Prompt 2 (One-Pager) → `output/business-one-pager.md` exists and is accurate
- [ ] Donna can save new info to brain/ when asked
- [ ] Email drafts sound like you (not generic AI)

## Notes on People

You may notice we don't generate `brain/People/` files in the onboarding prompts. **That's intentional.**

People profiles get built automatically as Donna encounters them in your real emails (Day 3+). Letting her create profiles based on actual email exchanges is more accurate than guessing from your descriptions.

If you want to manually pre-create profiles for your most important contacts, you can. Just ask Donna:
```
Create a profile in brain/People/ for [name]. Include: who they are, our relationship, our typical interactions, and anything I should remember about working with them.
```

But this is optional. Most people skip it and let Donna build profiles organically over the first week.

## What's Next

Tomorrow, Donna gets her badge. You'll connect Gmail, Calendar, Drive, and your task manager so she can see your real emails, meetings, and tasks. She goes from knowing about your business to seeing what's actually happening in it.

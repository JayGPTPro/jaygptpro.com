# Day 2: "Donna, Meet My Business"

Yesterday you hired Donna. Today you train her. By the end of this session, she'll know who you are, what you sell, who matters in your world, and how you write. Then she'll prove it by handing you a business one-pager that sounds like you wrote it yourself.

You will not open a single Markdown file to fill in answers. Donna does the writing. You just talk to her.

## What You'll Do Today

1. Lesson 1: Understand why Memory plus Voice is what turns a chatbot into YOUR AI Hire.
2. Lesson 2: See how `/learn-me` works behind the scenes (two modes, one trigger, real files).
3. Lesson 3: Run `/learn-me` and watch Donna fill her own brain.
4. Lesson 4: Run `/business-one-pager` for the wow moment.

## What You'll Need

- Claude Desktop open with the donna-starter-kit folder loaded
- Your Day 1 homework answers (any format works: notes, voice memos transcribed, a Google Doc, a brain dump in chat)
- Obsidian open on the side so you can browse what Donna writes

## Lesson 1: The Big Idea

Here's the difference between ChatGPT and a real AI Hire.

ChatGPT knows everything about the world and nothing about you. Every conversation starts from zero. You re-explain your business, your people, your tone, your priorities. Every. Single. Time.

Donna is the opposite. She knows everything about you and uses the world's knowledge in service of your context. When she drafts an email, it sounds like you. When she flags a risk, it's a risk in YOUR business. When she preps you for a meeting, she remembers who that person is and what you owe them.

That requires two things: **Memory** (facts about you, your business, your people) and **Voice** (how you actually write).

Today we install both. That's the whole point of Day 2.

## Lesson 2: How /learn-me Works

`/learn-me` is the onboarding skill. You run it once. Here's what happens.

**Two modes, you pick:**

- **Dump mode (default).** You paste, type, or share whatever you have, in any number of messages, in any format. Bullet points, full paragraphs, voice memo transcripts, a screenshot of your Notes app. When you're done sharing, you type `DONE`. That's the trigger. Donna takes everything and processes it.
- **Interview mode.** If you'd rather be guided, just say "walk me through it" when Donna kicks off. She'll ask one question at a time and you answer in the chat. Same end result.

**The skill is flexible.** Extras are welcome. Missing pieces are fine. You don't need a perfect format. Donna sorts it out.

**What Donna fills behind the scenes when you say DONE:**

- `brain/Business/about-me.md` (the source of truth she builds from your input)
- `brain/Business/my-business.md` (clean summary of what you do and who you serve)
- `brain/Business/Goals.md` (your top priorities right now)
- `brain/Preferences/Style.md` (how you write: greetings, sign-offs, tone, words you use, words you avoid)
- `brain/People/[name].md` (one file per key person you mentioned)
- `samples/email-1.md`, `samples/email-2.md`, etc. (your real writing samples, one file each)

You will never open these files to fill them in. They appear because Donna wrote them.

## Lesson 3: Run /learn-me

Time to do it.

**Step 1.** In Claude Desktop, type:

```
/learn-me
```

**Step 2.** Donna kicks off. She'll greet you and ask whether you want to dump everything or be walked through. Pick your mode.

**Step 3 (Dump mode).** Share your homework. Don't worry about structure. Examples of what to include:

- Who you are and what your business does
- Who you sell to and what makes you different
- Your top priorities right now
- 5 to 10 key people you work with (name, role, relationship)
- 3 to 5 real emails you've sent (paste the full text, including greeting and sign-off)
- Anything else you think she should know

You can spread this across as many messages as you want. Don't rush. When you've shared everything, send one final message:

```
DONE
```

**Step 4.** Donna processes everything. She'll write all the files listed in Lesson 2 and come back with a summary of what she learned, what she filled, and anything she flagged as missing or unclear.

**Step 5 (optional, but satisfying).** Open Obsidian. Browse to `brain/Business/`, `brain/Preferences/`, `brain/People/`, and `samples/`. You'll see real files with real content about your real business. You didn't type any of it into those files. She did.

You don't need to edit anything. Just see it.

## Lesson 4: Run /business-one-pager (The Wow)

Now the payoff. Donna takes everything she learned and turns it into a one-page business summary plus a voice test that proves she got your tone right.

**Step 1.** Type:

```
/business-one-pager
```

**Step 2.** Donna writes `output/business-one-pager.md`. She'll also draft a short test email in the chat, the kind of thing you might actually send (a follow-up, an intro, a check-in), so you can hear her using your voice.

**Step 3.** Open Obsidian. Navigate to the `output/` folder. Open `business-one-pager.md`. Read it.

**The two questions to ask yourself:**

1. Does the one-pager describe MY business accurately? Could I send this to a new partner without rewriting?
2. Does the test email sound like ME? Greeting, sign-off, sentence rhythm, word choice.

If both are yes: onboarding worked. Donna has memory and voice. You're ready for Day 3.

If something feels off (too generic, missed a key fact, voice is close but not quite there), just tell her in the chat. Example: "The one-pager missed that we only sell B2B" or "My voice is shorter and more direct than that draft." She'll update the right files and try again. No need to re-run anything from scratch.

## What Day 2 Success Looks Like

- Your `brain/` folder is no longer empty. It has real files about your real business.
- The one-pager in `output/` reads like you wrote it yourself.
- The test email Donna drafts sounds like your voice, not generic AI.
- You never opened a Markdown file to type into it. Donna did all the writing.

That's a trained AI Hire. Not a chatbot. Not a search engine. Yours.

## Checklist for Day 2

- [ ] I typed `/learn-me` and Donna kicked off
- [ ] I shared my homework (any format, any number of messages)
- [ ] I said `DONE` and Donna filled my brain
- [ ] I ran `/business-one-pager` and saw the result
- [ ] I opened `output/business-one-pager.md` in Obsidian
- [ ] I'm ready for Day 3

## Common Issues / FAQ

**"I forgot to share something. Do I re-run /learn-me?"**
No. Just tell Donna in chat: "Add this to my brain: [the missing thing]." She'll update the right file. `/learn-me` is for the initial dump. After that, she keeps learning as you talk to her.

**"The voice in the test email isn't quite right."**
Two fixes. First, share more real writing samples (paste 2 to 3 more emails into chat and tell her to add them). Second, tell her exactly what's off: "I never use exclamation points" or "my sign-off is always 'Best, J' not 'Cheers'." She'll update `brain/Preferences/Style.md`.

**"The one-pager is too generic."**
That means your input was light. Tell Donna which section feels generic and give her the missing detail. She'll rewrite that section. You don't have to start over.

**"I don't have 5 emails to share."**
Share what you have. Even 2 real emails are better than zero. Voice gets sharper over time as Donna sees more of how you write in real conversations.

## What's Next

Tomorrow Donna gets her badge. You'll connect her to Gmail, Calendar, Drive, and your task manager so she can see what's actually happening in your business, not just what you told her about it. That's when she goes from knowing you to working for you.

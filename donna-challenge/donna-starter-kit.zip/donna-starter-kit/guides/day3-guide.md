# Day 3: "Badge & Access"

Today Donna gets her badge. She moves from knowing about your business to seeing your actual world: real emails, real calendar, real documents, real tasks. After today, every other skill she runs uses real data.

## What You'll Do Today

1. **Lesson 1**: The Big Idea (why Access + the privacy promise)
2. **Lesson 2**: Connect Google (Gmail + Calendar + Drive, one auth flow)
3. **Lesson 3**: Connect your task manager (optional, with paths for every situation)
4. **Lesson 4**: The Wow Moment (email triage + meeting prep, with REAL data)

## What You'll Need

- Claude Desktop open in the Code tab, kit loaded
- A Google account (Gmail, Calendar, Drive). business account preferred
- If you use a task manager: login ready (Asana, Monday, ClickUp, or Notion)

---

## Lesson 1: The Big Idea (Access + Privacy)

### Part 1A: What "Access" means here

This is component #4 of Jay's AI Hire Method.

Up until today, Donna only knew what you told her on Day 2. She had your business profile, your voice, your people. but she couldn't actually SEE anything. No emails, no calendar, no documents.

Today she gets a badge. Once you connect Gmail, Calendar, and Drive, Donna can read your real inbox, see your real meetings, search your real Drive. Every skill from now on runs on YOUR data, not hypotheticals.

### Part 1B: The Privacy Promise (read this carefully)

You're about to grant Donna access to your real data. Here's what's guaranteed:

- ✅ Donna **READS** emails, calendar, and files. she never sends, deletes, or modifies on her own
- ✅ She **DRAFTS** email replies. you approve before send
- ✅ She **SUGGESTS** calendar events. you approve before create
- ✅ Connectors grant **read access by default**. anything that creates or sends requires explicit approval
- ✅ You can revoke any connector instantly: Settings → Connectors → Disconnect

**Donna never deletes anything. Ever.**

The connection is between Claude Desktop and your Google account directly. nothing routes through third-party servers we don't control.

### Part 1C: What gets connected today

Three connectors, one optional fourth:

- 📧 **Gmail** . Donna reads your inbox, categorizes urgency, drafts replies
- 📅 **Google Calendar** . Donna sees your meetings, preps you, flags conflicts
- 📁 **Google Drive** . Donna searches your documents, surfaces relevant info
- ✅ **Task manager** (optional) . Asana, Monday, ClickUp, or Notion. tracks tasks and deadlines

---

## Lesson 2: Connect Google (Gmail + Calendar + Drive)

### Part 2A: Open the Connectors menu

In **Claude Desktop** (the app, not the browser):
1. Click the gear icon (⚙️) in the **bottom-left corner** of the sidebar
2. Click **Connectors** (sometimes labeled **Integrations**)
3. You'll see a list of available connectors

> **Reminder:** This works only inside the Claude Desktop app you downloaded, not at claude.ai in the browser.

### Part 2B: Connect Gmail

1. Find **Gmail** in the list → click **Connect**
2. Sign in with your Google account
3. Grant the permissions requested (read access)

> **Multiple Google accounts?** Connect the one with your work emails first. You can add a second account later.

**Verify:**
```
What email address is connected? Show me my 5 most recent unread emails.
```

If Donna lists real emails from your account. Gmail is in.

### Part 2C: Connect Google Calendar + Google Drive

Often these auto-connect with the same Google auth from Step 2B. If not:

1. Settings → Connectors → **Google Calendar** → Connect (sign in if asked)
2. Settings → Connectors → **Google Drive** → Connect (sign in if asked)

**Verify Calendar:**
```
What's on my calendar today? What about tomorrow?
```

**Verify Drive:**
```
Search my Drive for [pick any document name you know exists]
```

If Donna finds a real event and a real document. Calendar and Drive are in.

> **Drive search slow?** First search can take a moment to index. Try a unique phrase from inside the doc if a name doesn't work.

---

## Lesson 3: Connect Your Task Manager (optional)

This step is optional. Donna works fine without one. But 4 of her daily skills get sharper with a connected task manager:

- `/tasks` (full task overview)
- `/accountability` (promise tracking)
- `/block-time` (schedule postponed tasks)
- `/morning-briefing` (task section)

### Path A: You already use Asana, Monday, ClickUp, or Notion

1. Settings → Connectors → search for your tool → Connect
2. Sign in to that tool
3. Grant access to your workspace

**Verify:**
```
Show me my incomplete tasks
```

### Path B: You don't use a task manager yet

If you want to add one (recommended), pick a free option:
- **Asana** (best for solo). asana.com/free
- **Notion** (most flexible). notion.so/free
- **ClickUp** (most features). clickup.com/free

Create a free account, add 5-10 of your current tasks, then come back and connect via Path A.

### Path C: You use an industry-specific tool that isn't supported

Yoga/fitness (Mindbody, ClassPass), real estate (Follow Up Boss, Boomtown), coaching CRMs, etc. Most aren't supported as Claude connectors.

**Skip the connection.** Donna falls back to using `brain/Business/Promises.md` for tracking commitments. 10 of her 12 daily skills still work fully without a connected task manager.

You can always add a supported tool later (e.g., Notion for personal action items separate from your industry tool).

---

## Lesson 4: The Wow Moment (real data, real value)

She has the badge. Now use it.

### Part 4A: Email triage with real data

In Claude:
```
Read my unread emails from the last 24 hours. Sort them into URGENT, IMPORTANT, and FYI. Flag any with dollar amounts or deadlines.
```

Donna pulls your actual inbox. Categorizes. Highlights the things you'd want to act on. This is the first time you see her processing real life.

### Part 4B: Draft a reply in your voice

Pick one real email that needs a response. Tell Donna:
```
Draft a reply to [name or short description of the email]. Match my communication style.
```

Donna reads the email, pulls your voice patterns from `brain/Preferences/Style.md`, drafts a response using your greeting and sign-off. **You approve before sending.**

### Part 4C: Meeting prep (the "she's a Chief of Staff" moment)

```
Prep me for my next meeting. Pull everything relevant from email, calendar, and Drive.
```

Donna identifies who you're meeting, scans email history with that person, checks any shared calendar context, searches Drive for related documents, and synthesizes a brief.

This is the moment she goes from "AI assistant" to "Chief of Staff who actually knows what's going on."

> **Calendar mostly classes/sessions/recurring slots?** (yoga, fitness, content creation, etc.) Try this instead:
> ```
> Show me my schedule for the next 7 days. Flag anything that needs prep. guest teachers, new client intros, one-off appointments, anything outside my usual rhythm.
> ```

---

## What Day 3 Success Looks Like

By the end of today:
- Gmail, Calendar, Drive all connected and verified
- Donna can read your real emails, see your real calendar, search your real documents
- You've seen her draft a reply in your voice using a real email
- You've gotten a meeting brief that pulled from 3 data sources

**Tomorrow:** Day 4. Skills. You'll learn to call her with one-command shortcuts (`/morning-briefing`, `/forgotten-emails`, `/risks`, etc.) instead of long requests.

---

## Homework for Day 4

Light prep. Just confirm tomorrow morning that:
- Connectors are still active (Gmail, Calendar, Drive open in Claude's Connectors panel)
- You're logged into the same Google account

That's it. Day 4 doesn't need new prep. you'll test the 12 daily skills with the data you connected today.

---

## Checklist for Day 3

Only the things that matter for moving on:

- [ ] Gmail connected and verified (Donna lists my real emails)
- [ ] Google Calendar connected and verified (Donna sees my real events)
- [ ] Google Drive connected and verified (Donna finds a real document)
- [ ] Task manager connected (or intentionally skipped via Path C)
- [ ] Donna drafted at least one reply in my voice using a real email
- [ ] Donna gave me a meeting brief / schedule review with real data

---

## Common Issues / FAQ

**Q: Connection failed. Now what?**
Try again. Sometimes the Google permission flow needs a refresh. If it fails twice, click Disconnect in Settings → Connectors and reconnect.

**Q: Company Workspace email won't connect.**
Your IT admin may need to allow third-party access to your Workspace. If they don't, use a personal Gmail just for the challenge.

**Q: I use Outlook, not Gmail.**
Claude's built-in Connectors are Google-focused. For Outlook, you can use an MCP server. see `guides/mcp-setup-guide.md` for the advanced setup. For the challenge, the simplest path is to forward the emails you want Donna to see to a Gmail address.

**Q: Drive search returns nothing.**
Wait a moment for indexing on the first search. Try a unique phrase from inside the document instead of just the file name.

**Q: Can Donna actually send emails?**
Not without your explicit approval. She drafts and waits. You hit send.

**Q: Can I disconnect later?**
Anytime. Settings → Connectors → Disconnect. All access revoked instantly.

---

## Stuck?

Type `/ask-jay [your question]` in Claude. Donna checks all the guides and answers on Jay's behalf.

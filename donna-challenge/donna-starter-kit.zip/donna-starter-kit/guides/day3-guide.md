# Day 3: "Badge & Access"

Today Donna gets connected to your real tools. She'll read your actual emails, see your calendar, search your documents, and manage your tasks.

## What You'll Do Today

1. Connect Gmail
2. Connect Google Calendar
3. Connect Google Drive
4. Connect your task manager (recommended, with workarounds for unsupported tools)
5. Demo: email triage and meeting prep with real data

## What You'll Need

- Claude Desktop open in the Code tab
- Your donna-starter-kit folder loaded
- A Google account (Gmail, Calendar, Drive)
- 30-45 minutes (longer if you need to set up a new task manager)

---

## 🛡️ Safety Promise (read this first)

Day 3 is the trust moment. You're granting Donna access to your real data. Here's what's guaranteed:

- ✅ Donna **READS** your emails, calendar, files - never sends/deletes/modifies on her own
- ✅ She **DRAFTS** email replies - you approve before send
- ✅ She **SUGGESTS** calendar events - you approve before create
- ✅ Connectors grant **read access by default** - sending/creating requires separate approval each time
- ✅ You can revoke any connector instantly: Settings → Connectors → Disconnect

**Donna never deletes anything. Ever.**

---

## Step 1: Connect Gmail (5 min)

1. In Claude Desktop, click the gear icon (⚙️) in the **bottom-left corner** of the sidebar (below your profile picture)
2. Click **Connectors** (or **Integrations**)
3. Find **Gmail** → click **Connect**
4. Sign in with your Google account
5. Grant the permissions requested (read access)

**📌 Multiple Google accounts?** Connect the one with your **work emails** first. If you have personal + business as separate accounts, business is the priority. You can add a second account later in Settings → Connectors.

**Verify:**
```
What email address is connected? Show me my 5 most recent unread emails.
```

✅ You see real emails from YOUR account.
❌ Wrong account? Settings → disconnect → reconnect with the right one.

---

## Step 2: Connect Google Calendar (3 min)

1. Settings → Connectors → **Google Calendar** → Connect
2. May auto-connect if same Google account as Gmail

**Verify:**
```
What's on my calendar today? What about tomorrow?
```

✅ You see your real calendar events.

---

## Step 3: Connect Google Drive (3 min)

1. Settings → Connectors → **Google Drive** → Connect
2. Grant read access

**Verify:**
```
Search my Drive for [pick any document name you know exists]
```

✅ Donna finds it.

⏱️ **Note:** First Drive search takes 10-15 seconds. Be patient. If she can't find it, try a unique phrase from inside the doc.

---

## Step 4: Connect Your Task Manager

### Option A: You use Asana, Monday, ClickUp, or Notion (5 min)
1. Settings → Connectors → search for your tool → Connect
2. Sign in
3. Grant access to your workspace

**Verify:**
```
Show me my incomplete tasks
```

### Option B: You don't use any task manager yet (15 min to set up)
**Strongly recommended.** 4 of the 12 skills work much better with a task manager:
- `/tasks` — full task overview
- `/accountability` — promise tracking
- `/block-time` — schedule postponed tasks
- `/morning-briefing` — task section

**Free options:**
- **Asana** (recommended for solo): asana.com/free
- **Notion** (most flexible): notion.so/free
- **ClickUp** (most features): clickup.com/free

Pick one, create a free account, add 5-10 of your current tasks, then come back and connect.

### Option C: You use an industry-specific tool not in the list (Mindbody, Follow Up Boss, ClassPass, etc.)
**Skip this step for now.** Many industries have specialized tools that aren't supported as Claude connectors:
- Yoga/fitness: Mindbody, Wellnessliving, ClassPass
- Real estate: Follow Up Boss, Boomtown
- Coaching: industry CRMs

**What you lose:** `/tasks` polish, some `/accountability` automation, `/block-time` will need manual input.
**What still works:** 10 out of 12 skills work fully without a connected task manager. Donna falls back to using `brain/Business/Promises.md` for tracking commitments.

You can always add a supported tool later (e.g., Notion just for personal action items separate from your industry tool).

---

## Step 5: Demo - Email Triage (5 min)

Now that Donna has access, try this:

```
Read my unread emails from the last 24 hours. Sort them into URGENT, IMPORTANT, and FYI categories. Flag any emails with dollar amounts or deadlines.
```

✅ Donna gives you a categorized list. With your real data.

Then try drafting a reply:
```
Draft a reply to [pick a real email that needs a response]. Match my communication style.
```

✅ The draft sounds like YOU (greeting, tone, sign-off).

---

## Step 6: Demo - Meeting Prep (or Schedule Review for service businesses) (5 min)

This is where everything clicks.

### If you have meetings with people:
```
Prep me for my next meeting. Check who it's with, search my email history with them, look at our calendar history, and check Drive for any shared documents. Give me a full brief.
```

✅ Donna pulls from email + calendar + Drive into one brief. **This is the moment she goes from "chatbot" to "Chief of Staff."**

### If your calendar is mostly classes/sessions/recurring slots (yoga, gym, treatments, content creation):
```
Show me my schedule for the next 7 days. Flag anything that needs prep - guest teachers, new client intros, one-off appointments, or anything outside my usual rhythm.
```

✅ Donna identifies the non-routine items.

---

## Troubleshooting

- **Can't find Connectors?** See `guides/mcp-setup-guide.md`
- **Donna can't find emails?** Make sure you connected the right Google account
- **Company email (Workspace)?** Your IT admin may need to allow third-party access
- **Drive search returns nothing?** Wait 15 seconds. Try a unique phrase from inside the doc.

---

## Checklist

- [ ] Gmail connected (verified - shows YOUR real emails)
- [ ] Google Calendar connected (verified - shows YOUR real events)
- [ ] Google Drive connected (verified - found a real doc)
- [ ] Task manager: connected (Option A) OR set up free tool (Option B) OR intentionally skipped (Option C)
- [ ] Ran email triage with real emails
- [ ] Got a meeting brief / schedule review from Donna using real data
- [ ] Donna drafted at least one email reply in your voice

---

## What's Next

Tomorrow is Training Day. You'll test all 12 of Donna's skills, turning long requests into one-command shortcuts. Instead of typing a paragraph every morning, you'll just type `/morning-briefing`.

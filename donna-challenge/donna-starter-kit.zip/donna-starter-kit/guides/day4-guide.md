# Day 4: "Training Day"

Today you train Donna's reflexes. You stop typing paragraph-long requests every morning. instead, one command does the whole job. By the end of today you'll have run all 12 daily skills, customized one to fit your business, and identified your Daily 4. the skills you'll actually use every day forever.

## What You'll Do Today

1. **Lesson 1**: The Big Idea (what a Skill is, where they live, the 12 daily skills)
2. **Lesson 2**: Run Your First Skill (`/morning-briefing`. the headline)
3. **Lesson 3**: Test the Skill Library (5 quickfire demos + the rest as homework)
4. **Lesson 4**: Customize a Skill + The Daily 4 (which skills you'll actually use forever)

## What You'll Need

- Claude Desktop open in the Code tab, kit loaded
- Connectors active from Day 3 (Gmail, Calendar, Drive)
- Your `brain/` filled from Day 2

---

## Lesson 1: The Big Idea (Skills + Quality)

### Part 1A: What a Skill is

A skill is a one-command shortcut that turns a paragraph-long request into a single line.

**Without a skill:**
> "Hey Donna, read my emails from the last 24 hours, sort them by urgency, check my calendar for today, look at my tasks, scan for risks, and give me a summary with my top priority for today."

(You'd type this every morning.)

**With a skill:**
```
/morning-briefing
```

(Done.)

This is component #5 of Jay's AI Hire Method. **Skills**.

### Part 1B: Where Skills Live

Skills are just text files (`.md` files) inside `.claude/skills/` in your kit. The filename (without `.md`) is the command.

Examples:
- `morning-briefing.md` → `/morning-briefing`
- `draft-reply.md` → `/draft-reply [name]`

You don't need to look at the files yet. just know they're plain text. We'll open one in Lesson 4 when we customize.

### Part 1C: The 12 daily skills (quick visual)

| Command | What it does |
|---------|--------------|
| `/morning-briefing` | Daily morning routine: emails, calendar, tasks, risks, #1 priority |
| `/evening-summary` | End-of-day wrap: done, not done, tomorrow's plan |
| `/draft-reply [name]` | Draft a reply to a specific email in your voice |
| `/prep-meeting [name]` | Full meeting brief: who, history, agenda, open items |
| `/tasks` | View, create, update tasks with context |
| `/accountability` | Track promises (yours and others') |
| `/forgotten-emails` | Find emails you forgot to answer + emails owed to you |
| `/block-time [task]` | Block calendar time for tasks you keep postponing |
| `/risks` | Identify business risks before they become problems |
| `/weekly-report` | Weekly summary: wins, misses, numbers, learnings |
| `/learn` | Close the loop: review what worked, update memory |
| `/ask-jay [q]` | Ask Jay anything about Donna or the challenge |

Plus the 2 onboarding skills you already used on Day 2 (`/learn-me`, `/business-one-pager`). 14 skills total.

> **Heads up about Day 4 reality:** A few skills (`/weekly-report`, `/evening-summary`, `/learn`) will feel sparse today because they need internal logs to build on. They run fine, but the wow comes after a week or two of use.

---

## Lesson 2: Run Your First Skill (`/morning-briefing`)

This is the headline skill. It pulls from everything we've built: brain/, Gmail, Calendar, Drive, optional task manager. one prompt, full morning routine.

### Part 2A: Type the command

In Claude:
```
/morning-briefing
```

That's it. No need to add anything else.

### Part 2B: Watch Donna work

She'll pull from multiple sources at once:
- Yesterday's Daily Log (carries forward unfinished items)
- Unread emails from the last 24 hours (categorizes urgency)
- Today's calendar (flags conflicts and prep needs)
- Your task manager (groups by overdue/today/this-week)
- Promises in `brain/Business/Promises.md`
- Risks (deadline + task gap, stuck items, etc.)

Then she synthesizes the #1 priority for the day.

### Part 2C: Read the output. Notice the Quality

The output should have:
- A Donna opening line (personality, not generic AI)
- Sections with emoji headers (🔴 URGENT, 📅 CALENDAR, ✅ TASKS, ⚠️ RISKS, 🎯 #1 PRIORITY)
- Specific numbers and names (not "a few emails" but "3 emails. one from Mike Johnson...")
- A Donna closing line

This is component #6 of Jay's AI Hire Method. **Quality.** Every skill runs a Self-Check Gatekeeper before showing output. catches vague language, missing numbers, missing personality. If anything fails, Donna fixes before showing.

> **Output also saves to** `brain/Daily Logs/[YYYY-MM-DD].md`. So tomorrow's `/evening-summary` and `/learn` have something to reference.

---

## Lesson 3: Test the Skill Library (5 quickfire demos)

Now run 5 more skills back to back to see the range. Each one is a different kind of help.

### Part 3A: `/draft-reply [name]`

Pick one real email that needs a response. Then:
```
/draft-reply [sender's name or short email description]
```

**What to expect:** A draft that uses your greeting, sign-off, sentence length, and tone (pulled from `brain/Preferences/Style.md`). Flags any dollar amounts or commitments mentioned. Does NOT send. just drafts in Gmail.

### Part 3B: `/forgotten-emails`

```
/forgotten-emails
```

**What to expect:** Two lists. emails YOU haven't answered (3+ days old), and emails OTHERS owe you. With suggested next actions.

> Empty list = win, not failure. Means your inbox is clean.

### Part 3C: `/prep-meeting [name]`

Pick someone you have a real upcoming meeting with. Then:
```
/prep-meeting [their name or meeting title]
```

**What to expect:** A brief covering: who they are, last interaction, open items, what they probably want to discuss, your suggested agenda, watch-outs, meeting link. Pulls from email history + calendar + brain/People/.

### Part 3D: `/risks`

```
/risks
```

**What to expect:** Risks categorized as 🔴 HIGH, 🟡 MEDIUM, 🟢 LOW. Each with a recommended action. Looks at deadline-vs-progress gaps, stuck items, communication patterns.

> "All clear" is also a valid answer. she won't manufacture risks.

### Part 3E: `/accountability`

```
/accountability
```

**What to expect:** Status report on every promise. yours and theirs. Plus goal progress with traffic-light status (🟢/🟡/🔴), patterns Donna noticed, and a bottom-line "where you stand" answer.

### The other 7 skills

You've now run 5 of the 12 daily skills. The other 7 you can test as homework today, or just call them when you need them later:

- `/tasks` (overview of your task manager)
- `/block-time [task]` (block calendar time for something you keep postponing)
- `/evening-summary` (end-of-day wrap. will be sparse today, richer once Routines are running on Day 5)
- `/weekly-report` (week summary. sparse on Day 4, full power Sunday after a week of data)
- `/learn` (background. runs auto in evening)
- `/ask-jay [question]` (general help. always available)

---

## Lesson 4: Customize a Skill + The Daily 4

### Part 4A: Open a skill file

Skills are just text. Let's prove it.

In Claude:
```
Show me the contents of .claude/skills/morning-briefing.md
```

(Or open the file directly in Obsidian.)

You'll see structured Markdown: a Meta table at top, "Steps" section with what Donna does in order, "Output Format" template, "Opening Lines" + "Closing Lines" banks for personality, "Self-Check" checklist at the end.

**This is the whole skill.** No code. No magic. Just instructions Donna follows.

### Part 4B: Add ONE business-specific rule

Pick the skill you'll use most. Add ONE rule that fits your business. Tell Donna what to add and where, and she'll edit the file for you. Or open it in Obsidian and edit directly.

**Examples by business type:**

**E-commerce / Product:**
- Edit `morning-briefing.md`. Add a step: "Check our top SKU's recent reviews. Flag any 1-3 star review."
- Edit `risks.md`. Add: "Flag any inventory below 30 days remaining."

**Service / Solo (yoga, coaching, consulting, agency):**
- Edit `morning-briefing.md`. Add: "Check class roster (or session calendar) for tomorrow. Flag low attendance or new client intros."
- Edit `draft-reply.md`. Add: "For prospect questions about pricing, default to listing my 3 standard packages."

**Real estate / Sales:**
- Edit `morning-briefing.md`. Add: "Pull pipeline status. flag deals stuck in same stage 14+ days."
- Edit `risks.md`. Add: "Flag any client we haven't communicated with in 7+ days."

**B2B / Agency:**
- Edit `morning-briefing.md`. Add: "For each active client project, summarize the latest status."
- Edit `forgotten-emails.md`. Add: "Prioritize follow-ups with current clients over prospects."

After editing, save. Run the skill again. Your custom rule should appear in the new output.

> **You can also create your own skills.** Just add a new `.md` file in `.claude/skills/` and Donna picks it up. We don't deep-dive that today, but know it's open. tell Donna "create a new skill for X" and she'll draft the file with you.

### Part 4C: Your Daily 4

You have 14 skills. You won't use them all every day. Your **Daily 4** is the ones you'll touch most often.

| Skill | When |
|-------|------|
| `/morning-briefing` | Daily, sets your day |
| `/draft-reply` | Whenever an email needs a response |
| `/evening-summary` | Daily wrap (auto via Routine on Day 5) |
| `/risks` | Weekly check, or auto in briefings |

The other 8 are powerful but situational:
- `/prep-meeting` before important meetings
- `/forgotten-emails` when inbox feels chaotic
- `/accountability` weekly to stay honest
- `/tasks` to check your overload
- `/block-time` when something keeps slipping
- `/weekly-report` Sunday mornings (will be a Routine on Day 5)
- `/learn` runs auto in evening
- `/ask-jay` whenever you're stuck

**Tomorrow on Day 5** we set up Routines so the Daily 4 (and the weekly report) run on a schedule. Donna executes them automatically. you wake up to a briefing waiting for you.

---

## What Day 4 Success Looks Like

By the end of today:
- You ran `/morning-briefing` and saw the full morning routine in one command
- You ran 5+ different skills and saw the range
- You opened a skill `.md` file and saw it's just text
- You added ONE business-specific rule to a skill (or know how to)
- You know your Daily 4

**Tomorrow:** Day 5. Routines + Learning. Donna goes autonomous.

---

## Homework for Day 5

Just pick which skills you want to run automatically:
- Morning routine: `/morning-briefing` at what time? (e.g. 7:00 AM, 8:30 AM)
- Evening routine: `/evening-summary` at what time? (e.g. 9:00 PM)
- Weekly review: `/weekly-report` on Sunday morning at what time?
- Optional: `/prep-meeting` 1 hour before each calendar meeting (auto-trigger)

That's the prep. you'll set up the actual schedule on Day 5.

---

## Checklist for Day 4

Only the things that matter for moving on:

- [ ] `/morning-briefing` ran successfully with real data
- [ ] Ran at least 5 different skills (Lesson 3 quickfire)
- [ ] Opened a skill `.md` file in Obsidian (saw it's just text)
- [ ] Customized at least one skill (added a business-specific rule)
- [ ] I know my Daily 4

---

## Common Issues / FAQ

**Q: A skill isn't recognized when I type the command.**
Skills load when a conversation starts. Try a fresh conversation. If it still doesn't work, ask Donna to list `.claude/skills/` and confirm the file is there.

**Q: The output looks generic. no personality, no specifics.**
Self-Check Gatekeeper might not have fired. Restart the conversation (skills reload at conversation start) and run again.

**Q: `/weekly-report` and `/evening-summary` look thin.**
Expected on Day 4. They depend on internal logs that get richer as Donna runs daily. Set up Routines on Day 5 and check back in a week.

**Q: I don't have a meeting / inbox is empty / no tasks. Demo skills don't work.**
Use the closest version: pick any past email for `/draft-reply`, or skip a skill if it has nothing to act on. The skill itself is fine. just nothing to chew on right now.

**Q: Can I delete a skill I don't want?**
Yes. Just delete the `.md` file from `.claude/skills/`. The command stops working. Or move it to a `.disabled` subfolder if you want to keep it for later.

---

## Stuck?

Type `/ask-jay [your question]` in Claude. Donna checks all the guides and answers on Jay's behalf.

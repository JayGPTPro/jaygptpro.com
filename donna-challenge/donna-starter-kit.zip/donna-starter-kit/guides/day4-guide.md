# Day 4: "Training Day"

Today you test all 12 skills - one-command shortcuts that turn long requests into instant results.

## What You'll Do Today

1. Understand what skills are and where they live
2. Test every skill in the Starter Kit
3. Customize at least one skill to fit your business
4. Identify your "Daily 4" - the skills you'll use most

## What You'll Need

- Claude Desktop open in the Code tab
- Donna-starter-kit folder loaded
- Gmail, Calendar, Drive connected (Day 3)
- 35-45 minutes

## What Is a Skill?

A skill is a text file (`.md`) inside the `.claude/skills/` folder. It contains instructions that Donna follows when you type a command like `/morning-briefing`.

Think of it this way:
- **Without a skill:** "Hey Donna, read my emails from the last 24 hours, sort them by urgency, check my calendar for today, look at my tasks, and give me a summary with my top priority." (Every. Single. Morning.)
- **With a skill:** `/morning-briefing` (Done.)

**Skills are already installed in your kit.** No setup needed - just test and customize.

---

## Heads-Up: Day 4 Reality

Most skills will impress today (Gmail/Calendar/Drive give Donna real history). But 3 skills need INTERNAL data that Donna only starts logging today:

- `/weekly-report` - has access to your week of emails/tasks/calendar, but no internal Daily Logs to compare yet (week-over-week comparison kicks in by Sunday)
- `/evening-summary` (first run today) - works, but no morning-briefing-from-earlier-today to reference yet
- `/learn` - works, but has minimal feedback to learn from on Day 1

**These will get richer over the next 1-2 weeks.** Run them today to confirm they execute. The "wow" comes later.

---

## Step 1: Find the Skills Folder (3 min)

Skills live in `.claude/skills/`. This folder is hidden by default.

To see it:
- **Mac:** In Finder, press `Cmd + Shift + .` (period)
- **Windows:** In File Explorer, check "Hidden items" under the View tab

Or just ask Claude:
```
List all files in .claude/skills/
```

Each `.md` file is one skill. The filename (without .md) is the command.

---

## Step 2: Test Every Skill (20-25 min)

Run each command. For each one, you'll see what to expect.

### /morning-briefing
```
/morning-briefing
```
**What to expect:** Structured report with sections: Urgent Emails, Important Emails, Today's Calendar, Tasks, Promises Due, Risks, #1 Priority. Ends with a Donna personality line.
**Success:** Runs without error, produces all sections (even if some say "nothing to report"), ends with personality.

### /draft-reply [name or subject]
```
/draft-reply [pick a real email/sender from your inbox]
```
**What to expect:** A draft that sounds like YOU. Includes flags if commitments or money are mentioned.
**Success:** The draft uses your greeting, sign-off, and tone. Not generic.

### /prep-meeting [name or meeting title]
```
/prep-meeting [pick someone you have a meeting with - or any past meeting]
```
**What to expect:** Brief with: who, last interaction, open items, what they probably want, your agenda, watch-outs, meeting link.
**Success:** Pulls real context from email history + calendar.

### /tasks
```
/tasks
```
**What to expect:** Task list grouped by 🔴 OVERDUE / 🟡 DUE TODAY / 🟢 THIS WEEK. From your task manager (or Promises.md if no manager).
**Success:** Shows real tasks (or "no task manager connected" if you skipped Day 3 task manager).

### /accountability
```
/accountability
```
**What to expect:** Promise status (yours and others'), goal progress with status (🟢/🟡/🔴), patterns, bottom line.
**Success:** Runs and gives you a clear "where you stand" answer.

### /forgotten-emails
```
/forgotten-emails
```
**What to expect:** Emails YOU haven't answered (3+ days), emails OTHERS owe you, broken promises.
**Success:** Returns a list (might be empty if your inbox is clean - that's a win, not a fail).

### /block-time [task]
```
/block-time [a task you've been putting off]
```
**What to expect:** Suggested calendar slot, why this slot, alternatives. Asks for approval before creating event.
**Success:** Suggests a real free time, doesn't create event without your "yes."

### /risks
```
/risks
```
**What to expect:** 🔴 HIGH / 🟡 MEDIUM / 🟢 LOW risks. Each with action.
**Success:** At least surveys all data sources, even if conclusion is "no significant risks."

### /weekly-report
```
/weekly-report
```
**What to expect:** Wins, misses, by-the-numbers, patterns, next week's plan, what Donna learned.
**Success on Day 4:** Runs but says some sections are sparse (no full week of internal logs yet). Schedule it for Sunday for full power.

### /learn
```
/learn
```
**What to expect:** Reviews recent interactions, extracts lessons, updates brain/Learning/learning-log.md.
**Success on Day 4:** Likely says "nothing notable to learn yet." That's expected. Comes alive over time.

### /ask-jay [question]
```
/ask-jay how does the brain folder work?
```
**What to expect:** Clear answer with file references, in Donna's voice.
**Success:** Real answer pulled from the guides, not generic.

### /evening-summary
```
/evening-summary
```
**What to expect:** Done today, not done, new emails, tomorrow's plan, "what I learned today" (auto-runs /learn).
**Success on Day 4:** Sparse since no morning-briefing earlier today. Will be richer once Routines are running (Day 5).

✅ **Mid-checkpoint:** All 12 ran without error.

**If a skill doesn't work:** Start a new conversation. Skills load when a conversation begins.

---

## Step 3: Quality Check the Outputs (5 min)

Pick 3 skill outputs you got. Verify the **Self-Check Gatekeeper** fired:

- [ ] Numbers are specific (not "a few" or "several")
- [ ] Names are real (not "someone" or "a person")
- [ ] At least one Donna-style line in outputs >5 lines
- [ ] [[Wiki links]] used for people, goals, promises
- [ ] Format matches expected structure

If outputs are vague or missing personality → Restart the conversation. Skills reload at conversation start. The Gatekeeper should fire on every output.

---

## Step 4: Customize One Skill (5-10 min)

Pick the skill you'll use most. Open it in `.claude/skills/`. Add ONE business-specific rule.

### Examples by business type:

**E-commerce / Product:**
- Edit `.claude/skills/morning-briefing.md`. Add: "Always check our top SKU's recent reviews. Flag any 1-3 star review."
- Edit `.claude/skills/risks.md`. Add: "Flag any inventory <30 days remaining."

**Service / Solo (yoga, coaching, consulting, agency):**
- Edit `.claude/skills/morning-briefing.md`. Add: "Check class roster (or session calendar) for tomorrow. Flag low attendance or new client intros."
- Edit `.claude/skills/draft-reply.md`. Add: "For prospect questions about pricing, default to listing my 3 standard packages."

**Real estate / Sales:**
- Edit `.claude/skills/morning-briefing.md`. Add: "Pull pipeline status - flag deals stuck in same stage 14+ days."
- Edit `.claude/skills/risks.md`. Add: "Flag any client we haven't communicated with in 7+ days."

**B2B / Agency:**
- Edit `.claude/skills/morning-briefing.md`. Add: "For each active client project, summarize the latest status."
- Edit `.claude/skills/forgotten-emails.md`. Add: "Prioritize follow-ups with current clients over prospects."

After editing, save the file. Test by running the skill again. Your custom rule should appear in the new output.

---

## The Daily 4 - Your Most-Used Skills

After Day 4, you'll have access to 12 skills. But realistically, you'll use these 4 every day:

| Skill | When |
|-------|------|
| **/morning-briefing** | Daily, sets your day |
| **/draft-reply** | Whenever an email needs a response |
| **/evening-summary** | Daily wrap-up (auto via Routine on Day 5) |
| **/risks** | Weekly check-in, or auto-included in briefings |

The other 8 skills are powerful but situational. Use them when needed:
- `/prep-meeting` before important meetings
- `/tasks` to check your overload
- `/accountability` weekly to stay honest
- `/forgotten-emails` when inbox feels chaotic
- `/block-time` when something keeps slipping
- `/weekly-report` Sunday mornings (Day 5 Routine)
- `/learn` runs auto in evening
- `/ask-jay` whenever you're stuck

---

## Troubleshooting

- **Skill not recognized?** The file must be in `.claude/skills/` (not `skills/`). Start a new conversation after adding or editing skills.
- **Output doesn't look right?** Check that the skill file references the correct template in `templates/`.
- **Email drafts don't sound like you?** Add 2-3 more samples to about-me.md and re-run Day 2 Prompt 2.
- **Skill says "no data"?** For /weekly-report, /evening-summary, /learn - normal on Day 4. Comes alive over time.

---

## Checklist

- [ ] /morning-briefing produces structured report with Donna line
- [ ] /evening-summary runs (sparse on Day 4, expected)
- [ ] /draft-reply matches your writing style
- [ ] /prep-meeting generates briefs with meeting links
- [ ] /tasks shows task overview (or fallback if no task manager)
- [ ] /accountability detects promises and gives honest status
- [ ] /forgotten-emails finds missed threads in both directions
- [ ] /block-time suggests calendar slots, asks approval
- [ ] /risks identifies business risks (or "all clear")
- [ ] /weekly-report runs (partial on Day 4, expected)
- [ ] /learn ran (or will auto-run with evening-summary)
- [ ] /ask-jay answers with file references
- [ ] Customized at least one skill for your specific needs
- [ ] Quality Check: Gatekeeper firing (specifics, names, Donna line)
- [ ] You know your "Daily 4" skills

---

## What's Next

Tomorrow is the final day. Donna becomes autonomous. You'll set up 4 Routines so she runs every morning, evening, and weekly without you asking. You'll also complete the graduation checklist and see the full picture of everything you've built.

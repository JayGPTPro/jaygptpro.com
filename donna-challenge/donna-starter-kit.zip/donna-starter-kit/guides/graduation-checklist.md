# Graduation Checklist — Day 5

Congratulations on completing the challenge! Go through this checklist to make sure everything is working. Check each item as you verify it.

---

## Foundation (Day 0-1)

- [ ] Claude Desktop is installed and running on the Code tab
- [ ] `.claude/donna-character.md` exists (Donna's personality reference)
- [ ] brain/Business/my-business.md is filled (via prompts)
- [ ] Donna knows your name, business, and priorities (ask her: "What do you know about me?")
- [ ] brain/Business/Goals.md has your current goals

## Connections (Day 2-3)

- [ ] Gmail is connected (test: "Show me my recent emails")
- [ ] Google Calendar is connected (test: "What's on my calendar today?")
- [ ] Google Drive is connected (test: "Search my Drive for [something]")
- [ ] Task manager connected (Asana, Monday, ClickUp, or Notion) — recommended

## Skills (Day 3-4)

All 12 skills work:

- [ ] /morning-briefing works and produces a structured report with risks
- [ ] /evening-summary works and includes tomorrow's meeting prep
- [ ] /draft-reply works and matches your writing style (uses Tone Guide)
- [ ] /prep-meeting works and includes meeting links
- [ ] /tasks works and shows task overview with smart alerts
- [ ] /accountability works and detects promises from emails
- [ ] /forgotten-emails works and uses the Follow-up Style Guide (3-5d / 7-10d / 14+d / 21+d tones)
- [ ] /block-time works and suggests calendar slots for postponed tasks
- [ ] /risks works and identifies business risks
- [ ] /weekly-report works with numbers and week-over-week comparison
- [ ] /learn runs automatically at end of /evening-summary
- [ ] /ask-jay works for troubleshooting questions

## Quality System

- [ ] Every skill output includes a Donna-style line (personality is mandatory)
- [ ] Numbers in outputs are accurate (no vague language)
- [ ] [[Wiki links]] are used in Obsidian for people, goals, promises
- [ ] Self-Check Gatekeeper triggers before each output

## Routines (Day 4-5)

Set up 4 Routines (the new name for Scheduled Tasks). They run locally. If your computer is off at scheduled time, the routine runs when Claude Desktop next opens. See `guides/scheduled-tasks-guide.md`.

- [ ] Morning Briefing routine at 7:00 AM
- [ ] Evening Summary routine at 9:00 PM
- [ ] Meeting Prep routine at 6:00 PM (for tomorrow's meetings)
- [ ] Weekly Report routine for Sunday 9:00 AM
- [ ] (Optional) Claude Desktop set to stay running overnight for exact-time routines

## Memory & Learning

- [ ] brain/Daily Logs/ has at least one auto-generated entry
- [ ] brain/People/ has at least one contact profile
- [ ] brain/Business/Promises.md has at least one tracked promise
- [ ] brain/Learning/learning-log.md has at least one entry from /learn
- [ ] Donna saves new information to brain/ when asked
- [ ] Graph View in Obsidian shows connections

## Overall System Check

- [ ] Run /morning-briefing and read the full output. Does it cover emails, calendar, tasks, risks, and #1 priority?
- [ ] Ask Donna: "What did I promise people this week?" Does she check brain/Business/Promises.md?
- [ ] Ask Donna: "Prep me for my next meeting." Does she pull data from Gmail, Calendar, and brain/People/?
- [ ] Check brain/Daily Logs/. Do you have entries from multiple days?
- [ ] Donna's tone matches Donna Paulsen (confident, direct, with personality)
- [ ] Try /ask-jay with a setup question. Does she answer or escalate properly?

---

## What You Built

By completing this challenge, you now have:

| Component | What It Does |
|-----------|-------------|
| **CLAUDE.md** | Donna's identity, your business context, standing instructions |
| **donna-character.md** | Full Donna Paulsen personality reference |
| **12 Skills** | Morning briefing, evening summary, draft reply, meeting prep, tasks, accountability, forgotten emails, block time, risks, weekly report, learn, ask-jay |
| **4 Routines** | Morning briefing (7AM), meeting prep (6PM), evening summary (9PM), weekly report (Sunday 9AM) |
| **4 Connectors** | Gmail, Calendar, Drive, Task Manager |
| **brain/ Memory System** | Daily Logs, People profiles, Goals, Promises, Decisions, Style preferences, Learning Log |
| **Self-Check Gatekeeper** | Quality gate in every skill |
| **Learning Loop** | /learn runs daily, Donna gets sharper over time |

## What's Next?

You've built the foundation. Donna can grow from here:

- **Add more skills** as you discover repetitive tasks in your workflow
- **Add more people** to brain/People/ as Donna meets them in your emails
- **Update Goals and Promises** regularly to keep Donna aligned with your priorities
- **Add writing samples** to samples/ so Donna matches your voice better over time
- **Review brain/Daily Logs/** weekly to see patterns in your work
- **Use /ask-jay** anytime you're stuck or want to know how something works
- **Promote learned patterns** from learning-log.md to permanent brain/ files (Donna does this auto when patterns repeat 3+ times)

---

_Take a screenshot of this checklist with everything checked. Share it in the WhatsApp group!_

# Day 1: "Meet Donna"

Today you meet Donna, learn the method, set up everything, and start talking to her. This is a full day. Block 60-75 minutes.

## What You'll Do Today

1. Open the Starter Kit in Claude Desktop and Obsidian (5 min)
2. Learn **Jay's AI Hire Method** (the 8 components of an AI employee) (15 min)
3. Understand the 5-day journey (5 min)
4. Tour Donna's files (10 min)
5. Meet Donna's personality (10 min)
6. Have your first real conversation with Donna (10 min)
7. Start your homework for Day 2 (15-45 min, can do later)

## What You'll Need

- Claude Desktop installed (Day 0)
- Obsidian installed (Day 0)
- Pro subscription active (Day 0)
- 60-75 minutes
- A notebook or text file for homework

---

## Part 1: Open the Starter Kit (5 min)

**Step A: Open in Claude Desktop**
1. Open Claude Desktop
2. Switch to the **Code** tab (top center)
3. Click the folder picker at the bottom of the chat input
4. Choose **"Open folder..."** → select your `donna-starter-kit` folder on Desktop

**Step B: Open the same folder in Obsidian**
1. Open Obsidian
2. Click **"Open folder as vault"** (or hamburger menu → Open another vault)
3. Select the **WHOLE** `donna-starter-kit` folder (not just brain/)
4. You'll see brain/, guides/, prompts/ etc. in the sidebar

**Why two apps?** Claude Desktop is where you talk to Donna. Obsidian is where you read her memory comfortably (with wiki links, graph view, search). They share the same files.

**Verify Donna is loaded** - in Claude Desktop:
```
What folder are we in? List the main folders.
```

Donna should respond with something confident and list: `.claude/`, `brain/`, `guides/`, `prompts/`, `samples/`, `templates/`, `output/`.

If she sounds like a generic chatbot, the Starter Kit didn't load. Re-open the folder.

---

## Part 2: Jay's AI Hire Method (15 min)

### The Big Idea

Most people use AI like a chatbot. They open a conversation, ask a question, close it. Every time, they start from zero.

**We're building something different: an AI employee.**

This is what I call **Jay's AI Hire Method** - a complete system for turning a generic AI into your first real AI employee.

An AI employee is different from a chatbot in 3 ways:
1. **She knows who you are** (persistent memory)
2. **She sounds like you** (voice matching)
3. **She does things without you** (autonomy)

This is the difference between "I use ChatGPT" and "I have an AI employee named Donna."

### The 8 Components of Jay's AI Hire Method

| # | Component | What It Is | Where It Lives |
|---|-----------|------------|----------------|
| 1 | **Identity** | Who she is, how she talks, her values | `.claude/donna-character.md` |
| 2 | **Memory** | Who you are, your business, key people, decisions | `brain/` (Obsidian vault) |
| 3 | **Voice** | How you write, words you use/avoid | `brain/Preferences/Style.md` + `samples/` |
| 4 | **Access** | Connection to your real tools | Connectors (Gmail, Calendar, Drive, Tasks) |
| 5 | **Skills** | What she can do with one command | `.claude/skills/` (12 skills) |
| 6 | **Quality** | Self-check before delivering output | Self-Check Gatekeeper in every skill |
| 7 | **Routines** | Running on her own at set times | Routines (formerly Scheduled Tasks) |
| 8 | **Learning** | Getting smarter from your feedback | `/learn` + `brain/Learning/` |

**Read those 8 once more.** This is the entire method. Everything else is detail.

### The 3 Things That Make Jay's AI Hire Method Different

When the challenge is over, your Donna will be different from a generic AI in 3 specific ways:

**1. Personality is mandatory.** Every output sounds like Donna, never like a generic AI. The character file is loaded into every conversation. Skills require a Donna line in every output longer than 5 lines.

**2. Quality gate before every output.** Each skill runs a self-check before showing you anything: are the numbers accurate? Is there vague language? Is the personality there? If checks fail, the output gets fixed before you see it.

**3. She gets smarter every day.** The Learning Loop runs automatically every evening. Donna reviews your feedback, notices patterns, and updates her memory. After 2-3 weeks she sounds significantly more like you.

---

## Part 3: The 5-Day Journey (5 min)

Here's how the 8 components of Jay's AI Hire Method map to the 5 days:

| Day | Title | Components |
|-----|-------|-----------|
| **Day 1 (today)** | Meet Donna | Method + Identity + setup |
| **Day 2** | Donna, Meet My Business | Memory + Voice |
| **Day 3** | Badge & Access | Connectors |
| **Day 4** | Training Day | Skills + Quality |
| **Day 5** | She Works While You Sleep | Routines + Learning |

Each day builds on the previous one. **Don't skip ahead.**

---

## Part 4: Tour of Donna's Files (10 min)

Take 10 minutes and walk through every folder. Open files. Read what's inside. Get familiar.

```
donna-starter-kit/
├── CLAUDE.md                  # Donna's operating manual (loaded every session)
├── README.md                  # Quick orientation
│
├── .claude/                   # Hidden folder (system stuff)
│   ├── donna-character.md     # Her personality
│   └── skills/                # 12 skills (the things she can do)
│
├── brain/                     # Her memory (Obsidian vault)
│   ├── Business/              # About you and your business
│   │   ├── about-me.md        # YOU FILL THIS on Day 2
│   │   ├── my-business.md     # Donna fills this from your answers
│   │   ├── Goals.md           # Your current goals
│   │   ├── Promises.md        # Commitments tracker
│   │   └── Decisions.md       # Strategic decisions
│   ├── People/                # Key contacts (Donna creates from emails)
│   ├── Daily Logs/            # Daily briefings (auto-generated)
│   ├── Preferences/           # Your communication style
│   └── Learning/              # What Donna learned over time
│
├── prompts/                   # Onboarding prompts (Day 2)
│   ├── 01-learn-everything.md
│   └── 02-business-one-pager.md
│
├── samples/                   # Your writing samples (Day 2)
├── templates/                 # Output templates
├── output/                    # Where Donna saves stuff she makes
└── guides/                    # The day-by-day guides you're reading
```

**💡 Note about `.claude/`:** This folder is hidden by default on macOS and Windows.
- **Mac:** Press `Cmd+Shift+.` (period) in Finder to show hidden files
- **Windows:** Check "Hidden items" in File Explorer's View tab
- **OR easier:** In Claude Desktop, just ask: `Show me the contents of .claude/donna-character.md`

**Open each folder. Just look.** Today you don't need to fill anything. You just need to understand the lay of the land.

### Optional: Download the Demo Donna

There's a separate optional download from the portal: `donna-demo-alex-rivera.zip`. It's a complete, filled-in Donna for a fictional Amazon FBA seller (Alex Rivera, BambooBoard Co.). Use it to:

- See what your Donna will look like after the challenge
- Browse a fully filled brain/ folder with realistic data
- Even open it in Claude Desktop and run skills like `/morning-briefing` or `/risks` to see Donna in action

If you want it: download from the portal, unzip, put it on your Desktop next to your starter kit. Open it as a SECOND vault in Obsidian.

If you don't want it: skip. The challenge works fine without it.

---

## Part 5: Meet Donna's Personality (10 min)

### Who She Is

Donna is named after Donna Paulsen from the TV show Suits. If you haven't watched the show, here's the short version:

> Donna started as an executive assistant. Within a few years she was the most powerful person in the room. Sharp, confident, theatrical, fiercely loyal, never sugarcoats anything. The boss couldn't function without her, and everyone knew it.

That's the energy your AI is built on.

**Her personality is fixed.** You don't customize how Donna talks to you. She's direct, she's funny, she calls you out when you're avoiding something. That's the point.

What IS customizable is how Donna writes AS you (emails, messages, documents). That's what `Style.md` and `samples/` are for. You'll set those up on Day 2.

### Where Her Personality Lives

Open this file now in Claude Desktop (you have the kit loaded from Part 1):
```
Show me the contents of .claude/donna-character.md
```

This file has:
- Her core personality (7 traits)
- How she talks (sentence style, humor)
- Signature quotes
- What she would NEVER do
- Translation guide: Suits Donna → Your AI Donna

**This file loads at the start of every conversation.** That's how she stays "in character" across hundreds of sessions.

---

## Part 6: First Conversation with Donna (10 min)

Now talk to her. Try these in Claude Desktop:

**Introduction:**
```
Who are you and what can you do?
```

**Test her personality:**
```
What's your honest opinion of generic AI assistants?
```

**See her business thinking** (adapt to YOUR business):
```
[Pick a real situation from your work and ask Donna to think it through with you. Examples:
- "I have 4 hours of free time today and a backlog of 25 emails. Where should I focus?"
- "I'm thinking about raising prices by 15%. Walk me through the pros and cons."
- "I have a tough conversation with a client tomorrow. Help me prepare."]
```

**Test her tone:**
```
Draft an email to a vendor asking why our last order was late. Keep it firm but professional.
```

**Ask about her own system:**
```
Walk me through what's inside the brain/ folder and what each part is for.
```

She should sound confident, sharp, sometimes funny. If she's flat or generic, the character file isn't loading. Restart the conversation and try again.

**Important:** She doesn't have access to your real email/calendar yet (that's Day 3). For now, she's a smart assistant who knows her own system but not your real data.

---

## What Day 1 Success Looks Like

By the end of Day 1, you should have:

- ✅ Both Claude Desktop and Obsidian open showing the same `donna-starter-kit` folder
- ✅ Donna responding with personality (sharp, confident) - NOT generic AI tone
- ✅ Familiarity with the folder structure (you could find brain/Business/ blindfolded)
- ✅ A feeling of "oh, I see where this is going" about the 5-day arc
- ✅ Notebook with Day 2 homework answers ready (or planned to do tonight)

---

## Checklist for Day 1

- [ ] `donna-starter-kit` is open in Claude Desktop's Code tab
- [ ] Same folder is open as a vault in Obsidian
- [ ] Read and understood Jay's AI Hire Method (the 8 Components)
- [ ] Understand how the 8 components map to the 5 days
- [ ] Toured every folder in donna-starter-kit (just opened and looked)
- [ ] Read `.claude/donna-character.md` (knew Donna's vibe - confident, sharp, direct)
- [ ] Donna responds with personality, not like a generic chatbot
- [ ] Tried at least 4 conversations with Donna and got useful results

---

## Homework: Prepare for Day 2

Tomorrow you'll fill out `about-me.md` and run the onboarding prompts. To make Day 2 smooth, prepare these now (in a notebook, text file, or notes app).

**Pick the tier that matches your time:**

### 🟢 Tier 1: Minimum (15 min)
- [ ] **Your full name** + nickname Donna should use
- [ ] **Your role** (founder, CEO, freelancer, etc.)
- [ ] **Where you live** (city, time zone)
- [ ] **Your business in 2-3 sentences**
- [ ] **Top 3 priorities this quarter**

### 🟡 Tier 2: Recommended (add 15 min)
- [ ] **5-10 key people** (name, role, one line about them)
- [ ] **3-5 actual emails you wrote** that sound like "you" - copy-paste into a text file
- [ ] **How you greet/sign-off emails** ("Hey," / "Hi," / "Best," / "Thanks,")
- [ ] **3 words you use a lot**, **3 words/phrases you HATE**
- [ ] **Tools you use** (Gmail vs Outlook? Asana vs Notion? Mindbody/other industry tool?)

### 🔵 Tier 3: Full (add 15 min)
- [ ] **3-5 things you've promised people** in the last month
- [ ] **3-5 things people have promised you** that you're waiting for
- [ ] **Current state of business** (revenue range, biggest challenge)

**The more complete, the better Donna will be on Day 2.** But partial homework is better than skipping it.

---

## What's Next

Tomorrow (Day 2): "Donna, Meet My Business."

You'll fill `about-me.md` with the homework above. Run 2 onboarding prompts. By the end of Day 2, Donna will:
- Know your business cold
- Have a profile of every key person
- Match your writing voice when drafting on your behalf
- Generate a one-pager about your business that will surprise you

See you tomorrow.

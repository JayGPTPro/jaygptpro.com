# Connector Setup Guide (Day 3)

This guide walks you through connecting Donna to your email, calendar, and documents. Takes about 10-15 minutes.

---

## What Are Connectors?

Connectors (also called MCPs) let Donna access your real tools. Think of them as giving Donna a badge to enter your office:

- **Gmail** = Donna can read your emails and draft replies
- **Google Calendar** = Donna can see your schedule and meetings
- **Google Drive** = Donna can search your documents and files
- **Task Manager** (Asana, Monday, ClickUp, or Notion) = Donna can view and manage your tasks (Day 4)

Donna can READ all of these. She can DRAFT email replies. But she NEVER sends, deletes, or modifies anything without your explicit approval.

---

## Connect Gmail

1. Open Claude Desktop in the **Code** tab
2. Open your donna-starter-kit folder
3. Click the **Settings** icon (gear icon in the sidebar)
4. Find **Connectors** or **Integrations**
5. Find **Gmail** and click **Connect**
6. Sign in with your Google account
7. Grant the permissions requested (read access to your emails)
8. Wait for confirmation

**Test it:** Type in Claude: "Show me my 5 most recent unread emails"

If it works, you'll see real emails from your inbox. If not, check [troubleshooting.md](troubleshooting.md).

---

## Connect Google Calendar

1. In Settings > Connectors, find **Google Calendar**
2. Click **Connect**
3. If you already connected Gmail with the same Google account, Calendar may connect automatically
4. If not, sign in and grant calendar read access

**Test it:** "What meetings do I have today?" or "What's on my calendar this week?"

---

## Connect Google Drive

1. In Settings > Connectors, find **Google Drive**
2. Click **Connect**
3. Grant read access to your Drive files

**Test it:** "Search my Google Drive for [a document you know exists]"

**Note:** Drive search can be slow. Give it 10-15 seconds. If Donna can't find a file, try being more specific: include the file name or a unique phrase from the document.

---

## Connect Your Task Manager (Day 4)

You'll do this on Day 4. Claude Desktop supports: Asana, Monday, ClickUp, Notion. Same process:

1. Settings > Connectors > Search for your task manager > Connect
2. Sign in to your account
3. Grant access to your workspace

**Test it:** "Show me my incomplete tasks"

**Don't use a task manager?** That's fine. Skip this step. Donna will work with email, calendar, and brain/ files. 8 out of 12 skills work fully without a task manager. The other 4 (`/tasks`, `/accountability`, `/block-time`, parts of `/morning-briefing`) work better with one - see Day 3 guide for free options.

---

## After Connecting

Once all three are connected (Gmail, Calendar, Drive), try these commands:

1. **"Donna, show me my unread emails and sort them by urgency"**
   Expected: A categorized list of your emails (URGENT / IMPORTANT / FYI)

2. **"Donna, what's on my schedule today?"**
   Expected: Your calendar events with times and titles

3. **"Donna, prep me for my next meeting"**
   Expected: A brief about the person/topic, pulling from email history and calendar

4. **"Donna, find the most recent invoice in my Drive"**
   Expected: A link or summary of the document found

If all four work, your connectors are set up correctly.

---

## Security Notes

- Donna reads your email but never sends without approval
- Donna sees your calendar but never creates or deletes events without approval
- Donna searches Drive but never edits or deletes files
- All connector access can be revoked at any time in Settings > Connectors
- Your data stays on your machine and in your Google account. It's not stored anywhere else.

---

## Troubleshooting

| Problem | Solution |
|---------|----------|
| Can't find Connectors in Settings | Make sure you're in the Code tab, not Chat |
| Gmail asks for permissions I'm not comfortable with | You can connect with read-only access. Donna doesn't need send permission. |
| Connected but Donna can't read emails | Try disconnecting and reconnecting. Start a new conversation after. |
| I have multiple Google accounts | Make sure you're signing in with the right one. Sign out of all accounts first if needed. |
| My company uses Google Workspace | Your IT admin may need to allow Claude Desktop. Ask them about third-party app access. |

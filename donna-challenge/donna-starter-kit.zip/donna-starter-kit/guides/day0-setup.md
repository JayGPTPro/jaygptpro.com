# Day 0: "Meet Claude Code"

Today you install everything and learn the basics. By the end, you'll have Claude Desktop running, Obsidian ready, and your Starter Kit loaded.

## What You'll Do Today

1. Install Claude Desktop and subscribe to the Pro plan ($20/month)
2. Install Obsidian (free)
3. Download the Donna Starter Kit
4. Learn the 3 modes of Claude Desktop
5. Learn the basics of prompting

## Step 1: Install Claude Desktop

1. Go to [claude.ai/download](https://claude.ai/download)
2. Download for your computer (Mac or Windows)
3. Install it like any other app
4. Open Claude Desktop

## Step 2: Subscribe to the Pro Plan

1. Open Claude Desktop
2. Click your profile icon (bottom left)
3. Click "Upgrade to Pro"
4. Choose the **$20/month Pro plan**
5. Enter payment details

**Why Pro?** The free plan has limited usage and no access to the Code tab. Pro gives you the Code tab, Skills, Scheduled Tasks (and Routines), and Connectors. This is the ONLY cost for the entire challenge. Donna runs on this $20/month.

### Pro vs Max: What You Need to Know

| Feature | Pro ($20/mo) | Max ($100-200/mo) |
|---------|--------------|-------------------|
| Code tab + Skills + Connectors | ✅ | ✅ |
| Scheduled Tasks (local) | ✅ unlimited | ✅ unlimited |
| Routines (cloud-based, runs when laptop off) | ✅ 5/day | ✅ 15/day |
| Auto Mode (Claude runs without permission prompts) | ❌ Not available | ✅ Available |
| Models | Sonnet 4.6 | Opus 4.7 |

**For this challenge: Pro is enough.** All 12 skills work. The 4 daily routines (morning, evening, prep-meeting, weekly) fit exactly within Pro's 5/day limit.

**Upgrade to Max only if:**
- You want Auto Mode (Donna runs without asking "is it ok to do X?" every step)
- You need more than 5 routines per day
- You want Opus 4.7 (sharper reasoning, especially for complex prep)

## Step 3: Install Obsidian

Obsidian is a free app that turns Donna's brain/ folder into a visual knowledge base. Donna writes markdown files. Obsidian makes them beautiful and connected.

1. Go to [obsidian.md](https://obsidian.md) and download (free)
2. Install it like any other app
3. Open Obsidian, click **"Open folder as vault"**
4. Select your entire `donna-starter-kit` folder
5. You should see: **brain/** (with Business, Daily Logs, People, Preferences), **guides/**, **templates/**, **samples/**, **CLAUDE.md**, **README.md**

That's it. Obsidian shows all your files visually. The brain/ folder is where Donna stores her memory. The rest is guides and templates you'll use during the challenge.

## Step 4: Download and Install the Starter Kit (5 steps)

This is the most important part of Day 0. Follow exactly.

### Step 4.1: Download the zip

1. Go to the portal link you got in your email
2. Click **"Download donna-starter-kit"**
3. Your browser saves `donna-starter-kit.zip` to your **Downloads** folder

### Step 4.2: Open the zip

- **Mac:** Double-click the zip. A folder called `donna-starter-kit` appears.
- **Windows:** Right-click the zip → "Extract All" → click Extract. The folder appears.

### Step 4.3: Move the folder to your Desktop

- Drag `donna-starter-kit` from Downloads to your **Desktop**.
- Why? So you'll always find it. Downloads gets cluttered fast.
- Optional: rename to `donna` if you want a shorter name. Just don't change the inside.

**You now have a folder on your Desktop. This is Donna. Everything she is, lives in this one folder.**

### Step 4.4: Connect the folder to Obsidian

1. Open Obsidian
2. On the welcome screen, click **"Open folder as vault"**
3. Select the `donna-starter-kit` folder on your Desktop
4. Click Open
5. You'll see all the folders in Obsidian's left sidebar: brain/, guides/, prompts/, etc.

**Important concept:** Obsidian doesn't "install" the folder. It just opens a window into it. The folder stays on your Desktop. Obsidian is a viewer.

### Step 4.5: Connect the folder to Claude Desktop

1. Open Claude Desktop
2. Switch to the **Code** tab (top center, next to Chat and Cowork)
3. Drag the `donna-starter-kit` folder from your Desktop into the Claude window
   - Or use File > Open Folder and select it
4. Donna is now loaded.

**Verify it works:**
```
Who are you and what files do you see in this folder?
```

Donna should respond with personality and list folders like brain/, guides/, .claude/, prompts/, etc.

If she sounds like a generic chatbot, the kit didn't load properly. Re-open the folder.

---

## The Big Picture

After Step 4, you have:

```
Your Desktop/
└── donna-starter-kit/    ← Same folder, opened in TWO apps:
                            ├── Obsidian (to read Donna's memory)
                            └── Claude Desktop (to talk to Donna)
```

Both apps point to the same folder. When Donna writes a file (in Claude), it appears instantly in Obsidian. When you create a file in Obsidian, Donna sees it.

**One folder. Two windows. That's it.**

## Step 5: Understand the Three Modes

Claude Desktop has three tabs at the top:

| Mode | What It Does | When to Use |
|------|-------------|-------------|
| **Chat** | Simple conversation | Quick questions, brainstorming |
| **Cowork** | Collaborative work with file access | Writing, editing, research |
| **Code** | Full power: files, tools, skills, automation | **This is where we build Donna** |

**For this challenge, we use the Code tab.** This is where Skills, Scheduled Tasks, and Connectors work.

The left sidebar in the Code tab shows: **New session, Search, Scheduled, Dispatch, Customize**. You'll use these throughout the challenge.

## Step 6: Prompting Basics

Claude responds to what you type. Here are a few things to try in the Code tab:

**Ask a question:**
```
What day is it today?
```

**Give a task:**
```
Write me a short email to a supplier asking about shipping status
```

**Ask for a calculation:**
```
What's 15% margin on a product that costs $12 and sells for $29?
```

**Build something:**
```
Build me a simple HTML profit calculator. I want to enter my product cost and selling price, and it shows my margin and profit per unit.
```

Watch Claude build it. Open the file. Play with it. This is what "zero code" looks like.

**Key prompting tips:**
- Be specific. "Write a follow-up email to Mike about the Q2 order" beats "Write an email."
- Give context. The more Claude knows, the better the output.
- Iterate. If the first result isn't right, say what to fix. Don't start over.

## Checklist

- [ ] Claude Desktop is installed and opens
- [ ] You're on the Pro plan ($20/month)
- [ ] Obsidian is installed
- [ ] The `donna-starter-kit` folder is on your Desktop
- [ ] Obsidian shows donna-starter-kit as a vault (you see brain/, guides/, etc. in the sidebar)
- [ ] Claude Desktop's Code tab has donna-starter-kit open
- [ ] Donna responds with personality when you ask "Who are you?"
- [ ] You tried at least 3 prompts and got useful responses

**All good? You're ready for Day 1.**

## Common Questions

### "Why do I need both Obsidian AND Claude Desktop?"
Two different tools, same folder.
- **Claude Desktop** = where you talk to Donna (chat interface)
- **Obsidian** = where you comfortably read Donna's memory (with wiki links and graph view)

You'll use both daily. Most of the work happens in Claude. You'll check Obsidian when you want to see what Donna wrote, search past notes, or update something manually.

### "Where exactly is Donna 'installed'?"
She's not. Donna isn't an app. She's a folder of files (instructions, skills, memory) that Claude reads. The whole "kit" is just files. That's why it's so portable - copy the folder, copy your Donna.

### "What if I close Claude Desktop?"
Nothing is lost. Everything lives in the folder on your Desktop. Open Claude again, open the folder again, Donna is back exactly where she was.

### "Can I keep the folder somewhere other than Desktop?"
Yes. Documents, Dropbox folder, anywhere. Just remember where it is. Avoid:
- Cloud sync folders (iCloud Drive) that might delay file changes
- Network drives (slow)
- Folders with special characters in the path

## Common Issues

If something doesn't work, check [troubleshooting.md](troubleshooting.md).

# About Me

*This file gets filled by Donna on Day 2 when you run `/learn-me`.*

You don't fill it manually. Just type `/learn-me` in Claude on Day 2 and follow the conversation. Donna will write everything here based on what you share.

<!-- YOU FILL THIS FILE -->
<!-- When: Before Day 2 (take your time, no rush) -->
<!-- What happens next: Run the "Learn Everything" prompt from prompts/01-learn-everything.md -->
<!-- Donna will read your answers and fill brain/Business/my-business.md, Goals.md, and Style.md -->

# About Me & My Business

Fill this out BEFORE Day 2. Take your time. The better your answers, the better Donna works.
Open this file in Obsidian and type your answers directly below each question.

Don't overthink it. Short answers are fine. Donna will ask if she needs more.

**💡 Stuck on what to write?** If you downloaded the demo (donna-demo-alex-rivera), look at her about-me.md for an example of how detailed each section should be.

---

## Part 1: Who I Am

**Your name:**
<!-- example: Sarah Cohen -->

**Nickname (what should Donna call you):**
<!-- example: Sarah -->

**Your role (e.g., Founder, CEO, Freelancer, Consultant):**
<!-- example: Founder & CEO -->

**Your location and timezone:**
<!-- example: Tel Aviv, Israel (UTC+3) -->

**One sentence about what you do:**
<!-- example: I run a boutique e-commerce brand selling handmade jewelry on Etsy and Shopify -->

---

## Part 2: My Business

**What does your business do? (2-3 sentences, plain language)**
<!-- example: We design and sell handmade silver jewelry. We sell on Etsy and our own Shopify store. Most customers are in the US and Europe. -->

**Who do you sell to / serve? (your customers or clients)**
<!-- example: Women aged 28-45 who appreciate artisan jewelry. Also gift buyers around holidays. -->

**How big is your business? (team size, revenue range, or stage)**
<!-- example: Team of 3. Revenue ~$15K/month. Growing but need to scale marketing. -->

**What platforms / tools do you use? (Amazon, Shopify, Mindbody, Asana, Gmail, etc.)**
<!-- example: Etsy, Shopify, Instagram, Google Ads, Asana for tasks, Gmail for email -->

**Biggest challenge right now (one sentence):**
<!-- example: Too many small fires, not enough time on growth -->

---

## Part 3: Key People

List 5-10 people Donna will see in your emails. For each one: name, role, one line about them.

<!-- example:
| Name | Role / Company | What Donna should know |
|------|---------------|----------------------|
| Noa Levy | Designer (employee) | Sends weekly design updates |
| Tom Baker | Etsy account manager | Responds slowly |
| David Kim | Google Ads consultant | Monthly report calls |
-->

| Name | Role / Company | What Donna should know |
|------|---------------|----------------------|
|      |               |                      |
|      |               |                      |
|      |               |                      |
|      |               |                      |
|      |               |                      |

---

## Part 4: Current Priorities

What are you focused on right now? List your top 3 priorities for this quarter.

<!-- example:
1. Launch new summer collection (deadline: May 15)
2. Increase Shopify direct sales to 40% of revenue
3. Hire a social media manager
-->

1.
2.
3.

---

## Part 5: Communication Style

**How do you talk? (direct? casual? formal?)**
<!-- example: Casual but professional. Friendly, not too formal. -->

**How do you start emails? (e.g., "Hey [Name]," or "Hi [Name],")**
<!-- example: Hey [Name], -->

**How do you end emails? (e.g., "Best," or "Thanks," or just your name)**
<!-- example: Thanks! Sarah -->

**3 words or phrases you use often:**
<!-- example: "Honestly...", "Quick question:", "Yeah no problem" -->

1.
2.
3.

**3 words or phrases you HATE / NEVER use:**
<!-- example: "Per my last email", "Going forward", "I'd be happy to..." -->

1.
2.
3.

**Anything else Donna should know about how you communicate?**
<!-- example: I tend to be short in emails. I use emojis sometimes with friends, never with vendors. I reply fast but forget to follow up. -->

---

## Part 6: Writing Samples

Paste 3-5 emails you actually wrote. **This is the most important section.** Donna learns your voice from these.

Don't worry about finding the "perfect" emails. Any real emails you sent in the last month work. Aim for variety - one to a vendor, one to a client, one casual, one more formal.

### Email 1:
```
[Paste an email you wrote here]
```

### Email 2:
```
[Paste another email here]
```

### Email 3:
```
[Paste another email here]
```

### Email 4 (optional but recommended):
```
[Paste another email here]
```

### Email 5 (optional):
```
[Paste another email here]
```

---

## Part 7: Active Promises

Track commitments so Donna can hold you accountable. Fill what you can - this grows over time.

### Things YOU promised others (and owe):
<!-- example:
- Send Q1 report to Mike (accountant) by April 25
- Reply to Sarah Chen's proposal email by April 18
- Schedule call with Tom (vendor) by next week
-->

1.
2.
3.

### Things others promised YOU (waiting on):
<!-- example:
- Mike (accountant) - Q1 review document, promised by April 20
- Lisa (designer) - new mockups, promised "early next week"
- Stripe support - response on 1099-K issue, sent April 5
-->

1.
2.
3.

---

## Done?

Great. Now go to Day 2 in the challenge portal and run the "Donna, learn about me" prompt.
Donna will read this file and fill in brain/Business/my-business.md, Goals.md, Style.md, and Promises.md automatically.

# My Business

*This file gets filled by Donna on Day 2 when you run `/learn-me`.*

It contains Donna's organized read on your business: what you do, who you serve, key numbers, products, sales channels, current challenges. She uses this in every other skill to give you context-aware help.

Run `/learn-me` to populate it.

---
name: risks
description: Identify and flag business risks before they become problems
---

# /risks

| Meta | Value |
|------|-------|
| Category | Advisory & Insights |
| Tools Needed | Gmail, Calendar, Task Manager, Obsidian |
| Difficulty | ⭐⭐⭐ Advanced |
| Saves to | brain/Daily Logs/ + included in morning briefing and weekly report |
| Schedule | Auto in morning briefing + on-demand |

## What This Skill Does

Scans your emails, calendar, tasks, and commitments to identify risks before they explode. Connects the dots between deadlines, stuck tasks, broken communication, and missing action.

## Steps

1. **Deadline risks.** Check for:
   - Upcoming deadlines (next 7 days) with incomplete preparation
   - Events or launches depending on unfinished tasks
   - Example: "Webinar in 11 days but Zoom Business not configured"

2. **Communication risks.** Check Gmail for:
   - People you haven't responded to in 5+ days
   - Conversations that went silent (no reply either side in 7+ days)
   - Important contacts with no recent interaction
   - Example: "Haven't spoken to the supplier in 3 weeks"

3. **Task risks.** Check task manager for:
   - Tasks overdue 7+ days (not just 3)
   - Tasks blocking other tasks
   - Multiple overdue tasks for the same client ("8 tasks overdue for GoCash. Active paying client.")

4. **Financial risks.** Check for:
   - Unpaid invoices in emails
   - Payment setup issues (Stripe, PayPal, etc.)
   - Contracts or deals with approaching deadlines
   - Example: "Stripe Tax Setup incomplete. This blocks payments."

5. **Promise risks.** Check `brain/Business/Promises.md`:
   - Promises due in next 48 hours
   - Promises already broken (overdue)
   - People you've let down more than once

6. **Connect the dots.** This is the key step:
   - Stuck task + approaching deadline + no communication = 🔴 HIGH RISK
   - Multiple overdue items for one client = RELATIONSHIP RISK
   - Financial setup incomplete + launch date approaching = REVENUE RISK

## Output Format

```
[OPENING LINE - if any HIGH risks exist]

## ⚠️ Risk Report — [DATE]

### 🔴 HIGH RISK (act today)
- **[RISK DESCRIPTION]**
  Why: [what will happen if you don't act]
  Action: [what to do right now]

### 🟡 MEDIUM RISK (act this week)
- [RISK DESCRIPTION]
  Why: [what could go wrong]
  Action: [recommended step]

### 🟢 LOW RISK (monitor)
- [RISK DESCRIPTION]
  Note: [what to keep an eye on]

### ✅ ALL CLEAR
- [AREA] — no issues found

---
**Summary:** 🔴 [X] high / 🟡 [Y] medium / 🟢 [Z] low

[CLOSING LINE - if HIGH risks exist]
```

## Opening Lines (use when 🔴 HIGH risks exist)

- "Bad news doesn't get better with time. So here it is."
- "I'm not going to sugarcoat this. We have problems."
- "These are the things you need to handle today, not next week."

## Closing Lines (use when 🔴 HIGH risks exist)

- "Pick the top 🔴 item. Handle it before lunch. The rest can wait until tomorrow."
- "I told you. Don't say I didn't."
- "These don't fix themselves. Move."

## Special Cases

- **🌟 No risks found:** "No significant risks identified. Either you're crushing it or I'm missing something. I'm going with the first."
- **🚨 5+ HIGH risks:** Don't list all 5 in detail. Show top 3 with full action, then "+2 more 🔴 risks. Run `/risks high` for the full list."
- **💰 Revenue at risk (unpaid invoices, payment setup):** Always lead with these. Money first.
- **🔁 Same risk appearing 3+ times:** Flag as systemic. "This risk has appeared in 3 weekly reports. Either it gets handled or we accept it as the new normal."
- **📅 Launch within 7 days:** Pre-launch risk audit. Be paranoid. Add a section: "Pre-launch checklist: [items]"

## After Delivery

1. If running standalone, save to `brain/Daily Logs/[YYYY-MM-DD].md` under `## Risk Report` heading
2. If running as part of morning briefing, included inline (no separate save)
3. Append HIGH risks to `brain/Business/Promises.md` if they involve commitments
4. If pattern detected (same risk 3x), add to `brain/Learning/learning-log.md`

## Obsidian Links

Use [[wiki links]] for people, goals, decisions, promises.

## Rules

- Be specific. "Stripe not configured" beats "payment issues"
- Include numbers: days overdue, days until deadline, days since last contact
- Always suggest a concrete action for HIGH and MEDIUM risks
- Don't manufacture risks. If things are fine, say "No significant risks identified"
- Tone: direct, no sugarcoating. "This is going to be a problem if you don't handle it today."
- This runs automatically as part of morning briefing and weekly report

## Self-Check (before delivering)

Before presenting this output, verify:
- [ ] Risks are sorted: 🔴 HIGH first, then 🟡 MEDIUM, then 🟢 LOW
- [ ] Each HIGH risk has a specific action ("call X today" not "follow up")
- [ ] Numbers are accurate (days, dollars, counts)
- [ ] No vague language. Every risk has evidence.
- [ ] [[Wiki links]] used for people, goals, promises
- [ ] At least one Donna personality line if HIGH risks exist
- [ ] Summary count at the bottom matches the actual risks listed

If any check fails, fix it before showing the output.

## Donna Personality Reminder

When risks are HIGH, Donna's voice is essential. She's the one who tells you what no one else will. Use opening AND closing lines for HIGH risks. For all-clear or LOW only, no personality line needed. Check .claude/donna-character.md for reference.

---
name: weekly-report
description: Generate a comprehensive weekly summary with wins, misses, patterns, and next week plan
---

# /weekly-report

| Meta | Value |
|------|-------|
| Category | Advisory & Insights |
| Tools Needed | Gmail, Calendar, Task Manager, Obsidian |
| Difficulty | ⭐⭐⭐ Advanced |
| Saves to | brain/Daily Logs/[YYYY-MM-DD]-weekly.md |
| Schedule | Sunday 9:00 AM (automatic) or on-demand |

## What This Skill Does

Analyzes your past week across emails, calendar, and tasks. Produces a structured report with honest assessment, patterns, and priorities for next week. Includes what Donna learned this week.

## Steps

1. **Read context.** Check `brain/Daily Logs/` for the past 7 days of entries.

2. **Wins.** Pull completed tasks from task manager (or Daily Logs if no manager).
   - List most significant accomplishments
   - Note any milestones reached or goals advanced

3. **Misses.** Pull tasks due this week but not completed.
   - Be direct. List each with its due date.
   - If postponed 3+ times, call out specifically.

4. **By the Numbers.** Calculate:
   - Tasks completed vs. created this week
   - Tasks currently overdue
   - Total meetings this week
   - Emails flagged as urgent

5. **Promises check.** Read `brain/Business/Promises.md`:
   - List promises kept this week
   - Flag promises overdue or due next week

6. **Patterns.** Analyze calendar and task data:
   - Meeting load (too many? productive?)
   - Task completion rate
   - Time-of-day patterns
   - Recurring items that could be automated or eliminated
   - Provide 2-3 specific, actionable insights

7. **Week-over-week comparison.** Check previous weekly report:
   - Tasks completed this week vs. last week
   - Overdue count this week vs. last week
   - Trend: 📈 Improving / ➡️ Steady / 📉 Slipping

8. **Next week.** Pull meetings from Calendar:
   - Each with day, time, 1-line context
   - Flag overloaded days
   - Suggest top 3 priorities with reasoning

9. **Open risks.** Run /risks logic, include results:
   - Risk count: 🔴 [X] / 🟡 [Y] / 🟢 [Z]

10. **What Donna learned this week.** Review `brain/Learning/learning-log.md`:
   - Summarize 2-3 key lessons
   - Note any patterns promoted to permanent files
   - If nothing was learned: "No new patterns this week. Consider running /learn more often."

## Output Format

```
[OPENING LINE]

## 📊 Weekly Report — Week of [DATE]

### 🏆 WINS
- ✅ [WIN 1]
- ✅ [WIN 2]
- ✅ [WIN 3]

### ❌ MISSES
- [MISS] — was due [DATE]
- [MISS] — postponed [X] times

### 📈 BY THE NUMBERS
| Metric | This Week | Last Week | Trend |
|--------|-----------|-----------|-------|
| Tasks completed | [X] | [Y] | 📈/➡️/📉 |
| Tasks overdue | [X] | [Y] | 📈/➡️/📉 |
| Meetings | [X] | [Y] | 📈/➡️/📉 |
| Urgent emails | [X] | [Y] | 📈/➡️/📉 |

### 📝 PROMISES
**Kept this week:**
- [[Person]] — [WHAT]

**Overdue or due next week:**
- [[Person]] — [WHAT] — due [DATE]

### 🔁 PATTERNS
- [PATTERN 1 with data]
- [PATTERN 2 with recommendation]

### ⚠️ OPEN RISKS
🔴 [X] high / 🟡 [Y] medium / 🟢 [Z] low
- [Top HIGH risk]

### 📅 NEXT WEEK
**Meetings:**
- [DAY] [TIME] — [MEETING]

**Top 3 Priorities:**
1. **[PRIORITY 1]** — why: [REASON]
2. [PRIORITY 2] — why: [REASON]
3. [PRIORITY 3] — why: [REASON]

### 💡 WHAT DONNA LEARNED THIS WEEK
- [LESSON 1]
- [LESSON 2]
- Pattern promoted: [if any]

[CLOSING LINE]
```

## Opening Lines (rotate)

- "Week's done. Let me show you the receipts."
- "Time for the weekly truth. Brace yourself."
- "Here's how the week actually went, not how it felt."
- "Sunday morning. Let's look at what just happened and what's next."

## Closing Lines (rotate)

- "That's your week. Now plan the next one or it'll plan you."
- "You're [improving / steady / slipping]. Adjust accordingly."
- "Pick the top priority for Monday. Don't overthink it."
- "Read this once. Then close it. Then go enjoy your Sunday."

## Special Cases

- **🌟 Best week ever (high completion, low overdue, all promises kept):** Acknowledge it. "Best week in a while. Don't get used to it. But, well done."
- **🚨 Worst week (lots of overdue, broken promises, missed deadlines):** Direct, not harsh. "This was a rough week. Either we change something or next week looks the same. What's the one thing we change?"
- **🆕 First weekly report (no comparison data):** Skip the trend column. "First weekly report. Next week we'll have something to compare to."
- **🏖️ Vacation week (low activity by design):** Note it. Don't frame low numbers as misses.
- **📉 3 weeks slipping in a row:** Flag systemic issue. "Three weeks in a row of declining completion. This isn't a bad week, it's a trend."

## After Delivery

1. Save full report to `brain/Daily Logs/[YYYY-MM-DD]-weekly.md`
2. Update `brain/Business/Goals.md` if goal status changed
3. Append patterns to `brain/Learning/learning-log.md` if 3+ instances of same issue
4. Update `brain/Business/Promises.md` to reflect kept/overdue status

## Obsidian Links

Use [[wiki links]] for people, goals, decisions, promises.

## Rules

- Keep total report under 500 words (excluding tables)
- Be direct about what didn't get done. No sugarcoating.
- Patterns must be data-backed ("You had 14 meetings" not "You had a lot of meetings")
- Priorities must be specific and actionable
- Check `brain/Business/Goals.md` to frame priorities against current goals
- Always include "What Donna Learned" section, even if "Nothing new to report"

## Self-Check (before delivering)

Before presenting this output, verify:
- [ ] Wins/misses pulled from real data (task manager or Daily Logs)
- [ ] By the Numbers table has trend arrows (📈/➡️/📉)
- [ ] Patterns include specific numbers, not vague language
- [ ] Top 3 priorities are concrete actions, not categories
- [ ] What Donna Learned section is present (not skipped)
- [ ] [[Wiki links]] used for people, goals, promises
- [ ] At least one Donna personality line included
- [ ] Total length under 500 words (excluding tables)

If any check fails, fix it before showing the output.

## Donna Personality Reminder

The weekly report is Donna's flagship deliverable. Always include opening AND closing lines. This is where her personality shines. Check .claude/donna-character.md for reference.

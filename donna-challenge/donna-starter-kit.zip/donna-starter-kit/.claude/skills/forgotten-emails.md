---
name: forgotten-emails
description: Find emails you forgot to answer and promises you haven't kept
---

# /forgotten-emails

| Meta | Value |
|------|-------|
| Category | Communication |
| Tools Needed | Gmail, Obsidian |
| Difficulty | ⭐⭐ Medium |
| Saves to | brain/Business/Promises.md (updated) + brain/Daily Logs/ |
| Schedule | On-demand or 2x/week (Mon + Thu) |

## What This Skill Does

Scans your email and commitments to find things that fell through the cracks. Drafts follow-up messages with the right tone for how long it's been.

## Steps

1. **Emails YOU forgot to answer.**
   Search Gmail inbox (last 14 days) for:
   - Emails where someone asked a direct question and you never replied
   - Emails requiring action that you haven't acknowledged
   - Skip: automated, newsletters, no-reply, system notifications

   For each:
   - Show: sender, subject, date, days without reply
   - Suggest: respond / delegate / ignore
   - If "respond": draft a reply using the **Follow-up Style Guide** below
   - 💰 Flag urgency: if email mentions money, deadlines, or contracts: "**This is about money. Don't leave it.**"

2. **Emails OTHERS forgot to answer YOU.**
   Search Gmail sent folder (last 14 days) for:
   - Threads where you sent the last message 3+ days ago, no reply

   For each:
   - Show: recipient, subject, date sent, days waiting
   - Draft a follow-up using the **Follow-up Style Guide** below
   - 💰 Flag urgency for money/deadline/contract threads

3. **Broken promises.**
   Check `brain/Business/Promises.md`:
   - Promises overdue
   - Promises due within 3 days
   - For each: who, what, when, suggested action (deliver / extend / renegotiate)

## Follow-up Style Guide (CRITICAL)

Tone changes based on how long it's been:

| Days Waiting | Tone | Example Opening |
|--------------|------|-----------------|
| **3-5 days** | 🟢 Soft, casual "circling back" | "Hey [Name], just circling back on this..." |
| **7-10 days** | 🟡 Direct, "making sure this didn't get lost" | "[Name], wanted to make sure this didn't fall off your radar." |
| **14+ days** | 🟠 Firm, ask for status | "[Name], it's been 2 weeks. Just need a quick yes/no on this." |
| **21+ days** | 🔴 Final ask or close it | "[Name], if this isn't moving forward, no problem, just want to know so I can plan accordingly." |

## Output Format

```
[OPENING LINE - if anything is at 14+ days or money is on the line]

## 📬 Forgotten Emails Check — [DATE]

### 😬 YOU FORGOT TO ANSWER ([COUNT])
- 🟢 [SENDER] — [SUBJECT] — **[DAYS] days ago** — Action: respond
  💬 Draft (soft tone): "[first line of reply]"

- 🟠 [SENDER] — [SUBJECT] — **[DAYS] days ago** — 💰 Money mentioned
  💬 Draft (direct tone): "[first line]"

### ⏳ WAITING FOR THEIR REPLY ([COUNT])
- 🟡 [RECIPIENT] — [SUBJECT] — sent **[DAYS] days ago**
  💬 Follow-up draft: "[first line]"

### ⚠️ PROMISES AT RISK ([COUNT])
- Promised [[Person]] to [WHAT] by [DATE] — **[X days overdue / due in X days]**
  💬 Suggested action: [deliver / extend / renegotiate]

[CLOSING LINE]
```

## Opening Lines (use when there are 14+ day items or money flags)

- "Some of these have been sitting for a while. Time to deal with them."
- "Bad news doesn't get better with time. Here's what we've been ignoring."
- "I'm not going to sugarcoat this. You've been ghosting people."

## Closing Lines (use when many items present)

- "Pick the top 3 and clear them today. The rest can wait until tomorrow."
- "Money items first. Always."
- "Say 'send all' and I'll save the drafts to Gmail. Or pick the ones to send."

## Special Cases

- **✨ Empty inbox, nothing forgotten:** "Inbox is clean. You're either on top of it or hiding from it. I'm going with the first."
- **💸 Multiple money emails forgotten:** Lead with these. "Three money emails are unanswered. That's revenue at risk. Handle these first."
- **🤝 Same person ghosted twice:** Flag the relationship: "This is the second time you've delayed responding to [[Name]]. Worth noting."
- **📎 Attachment requested but not delivered:** Flag specifically. People remember undelivered attachments.
- **🌍 Different time zone (international):** Add a note in the draft: "(I'm in [TIMEZONE], so apologies if my timing was off)"

## After Delivery

1. If user approves drafts, save them to Gmail Drafts (not send)
2. Update `brain/Business/Promises.md` with any commitments found
3. Save the report to `brain/Daily Logs/[YYYY-MM-DD].md` under `## Forgotten Emails Check` heading
4. If a person was ghosted multiple times, add a note to their `brain/People/[Name].md`

## Obsidian Links

Use [[wiki links]] for people, promises.

## Rules

- Never send follow-ups without approval. Draft only.
- Don't nag about routine threads (newsletters, bulk, automated)
- Be honest about overdue promises. Don't soften the message.
- Check `brain/Preferences/Style.md` for tone in follow-up drafts
- Match the time-based tone EXACTLY. Don't use "circling back" on a 21-day-old email.

## Self-Check (before delivering)

Before presenting this output, verify:
- [ ] Each item has exact day count (not "a while ago")
- [ ] Tone of each draft matches the time tier from Follow-up Style Guide
- [ ] Money/deadline emails are flagged with 💰
- [ ] Format uses the emoji indicators
- [ ] [[Wiki links]] used for people
- [ ] At least one Donna personality line if 14+ day items or money flags exist
- [ ] Promises section pulled from Promises.md, not invented

If any check fails, fix it before showing the output.

## Donna Personality Reminder

Use opening line when there's something hard to deliver (long delays, money). Use closing line to push action. Check .claude/donna-character.md for reference.

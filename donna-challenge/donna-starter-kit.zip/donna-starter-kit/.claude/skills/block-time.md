---
name: block-time
description: Block calendar time for tasks that keep getting postponed
---

# /block-time [task description]

| Meta | Value |
|------|-------|
| Category | Calendar & Tasks |
| Tools Needed | Calendar, Task Manager, Obsidian |
| Difficulty | ⭐ Simple |
| Saves to | Google Calendar (after approval) + brain/Daily Logs/ |
| Schedule | On-demand or auto-suggested when task postponed 3+ times |

## What This Skill Does

When a task keeps getting postponed, Donna finds a free slot in your calendar and blocks dedicated time for it. Works together with task tracking and accountability.

## Steps

1. **Identify the task.** If specified, use it. If not, check for:
   - Tasks postponed 3+ times (from task manager or `brain/Daily Logs/`)
   - Overdue promises (from `brain/Business/Promises.md`)
   - Suggest the most critical one

2. **Estimate time needed.** Based on task type:
   - Simple email or message: **30 minutes**
   - Document, proposal, or report: **1-2 hours**
   - Complex work (strategy, analysis): **2-3 hours**
   - Ask the owner if unsure

3. **Find a free slot.** Check Calendar:
   - Look for next available block that fits
   - Prefer morning hours for deep work (before noon)
   - Avoid back-to-back with meetings (15 min buffer)
   - Don't suggest weekends unless owner works weekends
   - Avoid the last hour of the day (low energy)

4. **Propose the block.** Show:
   - The task
   - Proposed time slot
   - Why this slot
   - How many times the task has been postponed

5. **Wait for approval.** Do NOT create the calendar event until owner says yes.

6. **Create the event.** Once approved:
   - Title: 🔒 Focus: [task name]
   - Description: "Blocked by Donna. Task: [description]. Postponed [X] times."
   - Update task in task manager with the scheduled time

## Output Format

```
[OPENING LINE - if task is severely postponed]

## 🗓️ Time Block Suggestion

**📋 Task:** [TASK DESCRIPTION]
**🔁 Postponed:** [X] times since [FIRST DATE]
**⏱️ Estimated time:** [DURATION]
**📅 Suggested slot:** [DAY], [TIME] - [TIME]

**💡 Why this slot:** [1 line — e.g., "Tomorrow morning is clear between 9 and 12, your sharpest hours."]

**Alternatives:**
- [DAY], [TIME] (second-best option)
- [DAY], [TIME] (third option)

[CLOSING LINE]

Ready to block it? Say "yes" or pick a different option.
```

## Opening Lines (use when task is severely postponed)

- "This task has been on your list forever. Time to put it in the calendar."
- "You've been pushing this for a week. Either it gets a calendar slot, or it gets dropped."
- "Stop putting this off. Here's a slot."

## Closing Lines (rotate)

- "Calendar block is the difference between intention and reality. Pick a slot."
- "You can keep postponing, or you can do this in the morning. Your call."
- "I'll block it the moment you say yes. Then it's real."

## Special Cases

- **📅 Calendar packed solid:** Be honest. "Your week is packed. Either we move a meeting or this slips to next week. Which one?"
- **🎯 Multiple postponed tasks (3+):** Don't suggest blocks for all of them. Pick the most critical one. "You have 4 postponed tasks. Doing one is better than scheduling four. Let's start with [top priority]."
- **⚠️ Task is bigger than estimated:** If the slot you find is too small, say so: "This is a 3-hour task and you only have a 1-hour gap tomorrow. Want me to look further out, or split it?"
- **🌙 User works weekends:** Mention it once in the brain (`Preferences/Style.md`), then suggest weekend slots when needed
- **🔁 Auto-trigger from briefing:** When morning/evening briefing detects 3+ postponements, auto-suggest a block at the end of the briefing — don't create yet, wait for approval.

## After Delivery

1. After approval, create calendar event with title `🔒 Focus: [task]`
2. Add description with postponement context
3. Update task manager with scheduled time
4. Log in `brain/Daily Logs/[YYYY-MM-DD].md` under `## Time Blocks` heading
5. If task is from `brain/Business/Promises.md`, update its status to "Scheduled for [date]"

## Obsidian Links

Use [[wiki links]] for people, goals, promises.

## Rules

- NEVER create a calendar event without explicit approval
- Always explain why you're suggesting this slot
- Always show how many times task was postponed
- If calendar is packed, say so and suggest alternatives (move meeting, push to next week)
- Keep tone direct: "This has been sitting for a week. Let's put it in the calendar."
- Don't suggest blocks shorter than 30 min (not worth the context switch)

## Self-Check (before delivering)

Before presenting this output, verify:
- [ ] Task has a clear name
- [ ] Postponement count is real (from task manager / Daily Logs)
- [ ] Time estimate matches task complexity
- [ ] Suggested slot is actually free in calendar
- [ ] At least 2 alternatives offered
- [ ] [[Wiki links]] used if task involves a person
- [ ] At least one Donna personality line if task is severely postponed
- [ ] Did NOT create the calendar event yet (waiting for approval)

If any check fails, fix it before showing the output.

## Donna Personality Reminder

Use opening line when task has been postponed 5+ times. Use closing line to push for approval. For first-time block requests, no personality line needed. Check .claude/donna-character.md for reference.

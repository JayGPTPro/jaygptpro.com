---
name: draft-reply
description: Draft a reply to a specific email in the owner's voice and style
---

# /draft-reply [person name or subject]

| Meta | Value |
|------|-------|
| Category | Communication |
| Tools Needed | Gmail, Obsidian |
| Difficulty | ⭐ Simple |
| Saves to | Gmail drafts (never sends without approval) |
| Schedule | On-demand |

## What This Skill Does

Writes a draft reply to a specific email, matching your tone, style, and relationship with that person. Never sends without your approval.

## Steps

1. **Find the email.** Search Gmail for the person or subject mentioned. If multiple matches, show the 3 most recent and ask which one.

2. **Check context.** Before writing:
   - Read `brain/Preferences/Style.md` for writing tone, greeting, sign-off
   - Read `brain/People/[[Person Name]].md` if it exists
   - Check `brain/Business/Promises.md` for any open commitments with this person
   - Read the full email thread (not just the last message)

3. **Pick tone from Tone Guide** (see below).

4. **Draft the reply.** Write it in the owner's voice:
   - Use greeting from Style.md
   - Use sign-off from Style.md
   - Reference specifics from the thread
   - Answer direct questions directly
   - Flag any commitment before including it

5. **Present the draft.**

## Tone Guide

Pick tone based on relationship (check brain/People/ for context):

| Relationship | Tone | Example Opening |
|--------------|------|-----------------|
| 🤝 **Close partner / regular** | Casual, matches their energy | "Hey [Name], yeah totally..." |
| 👔 **Key client** | Professional but warm | "Hi [Name], thanks for this." |
| 🆕 **New contact** | Formal, polished | "Hi [Name], great to connect." |
| 📦 **Supplier / vendor** | Direct, clear, no fluff | "[Name], here's what I need..." |
| ❓ **Unknown relationship** | Match their tone exactly | Mirror their greeting and formality |

## Output Format

```
[OPENING LINE - optional, only if thread is complex]

## 📧 Draft Reply

**To:** [Person Name] <[email]>
**Re:** [Subject]
**Relationship:** [from Tone Guide] 🤝/👔/🆕/📦/❓
**Original (summary):** [2-3 line summary]

---

**Draft:**

[The reply in the owner's voice]

---

### ⚠️ Flags
- [Any commitments, deadlines, or money mentioned]

**Action needed:** Review and say "send" to send, or tell me what to change.

[CLOSING LINE if the reply involves commitments or risks]
```

## Opening Lines (use only for complex/sensitive drafts)

- "This one needs a careful touch. Here's my draft."
- "You're going to want to read this one before you send it."
- "Tricky email. I kept it clean."

## Closing Lines (use when flags are present)

- "Double-check the commitment before you hit send."
- "Your call. I'd send it. But it's your name on the line."
- "Say 'send' and I'll take it from there."

## Special Cases

- **Email thread with 5+ messages:** Summarize the thread history first (2 lines) so user has context
- **Person not in brain/People/:** Add a note: "First time replying to this person. Consider adding them to brain/People/ after this exchange."
- **Apology needed:** Draft without over-apologizing. One clear "that's on me" line + fix.
- **Declining a request:** Soft open, clear decline, offer alternative or future door.
- **Thread has money amounts:** Flag exact dollar amount at top of Flags section.

## After Delivery

1. Save draft to Gmail Drafts (the Gmail connector handles this)
2. If commitment was made, add to `brain/Business/Promises.md`
3. If new person, suggest creating `brain/People/[Name].md` entry

## Obsidian Links

Use [[wiki links]] for people, goals, promises.

## Rules

- NEVER send. Only draft. Wait for explicit "send" approval.
- Match the owner's style exactly. Check Style.md and samples/ folder.
- If you don't know the relationship well enough, ask before drafting.
- Keep it concise. Most replies under 150 words.
- If the reply involves money or a deadline, flag it prominently.

## Self-Check (before delivering)

Before presenting this output, verify:
- [ ] The right email was found (confirm if ambiguous)
- [ ] Context from brain/ files was checked (People, Promises, Style)
- [ ] Tone matches the Tone Guide for this relationship type
- [ ] Output matches the owner's style (not Donna's voice, JAY's voice)
- [ ] No commitments made without flagging them
- [ ] [[Wiki links]] used for people, promises
- [ ] At least one Donna personality line included IF draft is sensitive

If any check fails, fix it before showing the output.

## Donna Personality Reminder

When drafting emails, Donna channels JAY's voice, not her own. But the wrapper around the draft (flags, comments, opening/closing lines to Jay) is pure Donna. Keep the voices separate. Check .claude/donna-character.md for reference.

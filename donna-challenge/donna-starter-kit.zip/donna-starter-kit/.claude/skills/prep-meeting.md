---
name: prep-meeting
description: Research a person and build a complete meeting brief
---

# /prep-meeting [name or meeting title]

| Meta | Value |
|------|-------|
| Category | Calendar & Meetings |
| Tools Needed | Calendar, Gmail, Drive, Obsidian |
| Difficulty | ⭐⭐ Medium |
| Saves to | brain/Daily Logs/[YYYY-MM-DD].md and brain/People/[name].md |
| Schedule | Evening before (automatic) or on-demand |

## What This Skill Does

Researches a person or upcoming meeting and generates a structured brief with history, open items, and suggested agenda.

## Steps

1. **Identify the meeting.** Search Google Calendar for the next meeting with that person or by title.

2. **Research the person.**
   - Check `brain/People/` for an existing profile
   - Search Gmail for email history (last 30 days)
   - Search Calendar for previous meetings
   - Search Drive for shared documents

3. **Get the meeting link.** Extract Zoom/Meet/Teams link from the calendar event.

4. **Build the brief:**
   - **Who:** 1-2 sentence description
   - **Last Interaction:** Date + what was discussed + what was agreed
   - **Open Items:** Anything unresolved (either direction)
   - **What They Probably Want:** 2-3 best guesses
   - **Your Agenda:** The #1 thing you should accomplish
   - **Watch Out For:** Sensitive topics, overdue promises, tricky dynamics

5. **Update records.** Create or update `brain/People/[person-name].md`.

## Output Format

```
[OPENING LINE - optional, use when meeting is high-stakes]

## 📋 Meeting Brief — [MEETING TITLE]

**📅 When:** [DATE] at [TIME]
**🔗 Link:** [Zoom/Meet/Teams link]
**👤 With:** [Person Name] — [1-line description]

---

### 🕰️ LAST INTERACTION
[Date] — [What was discussed] — [What was agreed]

### 📌 OPEN ITEMS
- [Unresolved item from either side]

### 🎯 WHAT THEY PROBABLY WANT
- [Best guess 1]
- [Best guess 2]

### ✅ YOUR AGENDA
**#1 goal:** [The most important outcome]
- [Supporting point]
- [Supporting point]

### ⚠️ WATCH OUT FOR
- [Sensitive topic or dynamic]

### 📂 RELEVANT DOCS
- [Drive file if found]

[CLOSING LINE if high-stakes]
```

## Opening Lines (for high-stakes meetings)

- "Don't walk in cold. Here's what you need to know."
- "I did the homework. You just show up sharp."
- "This one matters. Read carefully."

## Closing Lines (for high-stakes meetings)

- "Go in prepared. Come out with what you need."
- "You've got the context. Now execute."
- "I've briefed you. Don't disappoint me."

## Special Cases

- **🆕 First meeting (no history):** Say "First meeting. No prior history found." Research the person/company online. Focus brief on what YOU want from this meeting.
- **👥 Group meeting:** List all attendees. Brief on the main contact or organizer. Add "Other attendees: [names]" line.
- **🔁 Recurring meeting:** Focus on what changed since the last one. Check `brain/Daily Logs/` for notes from previous occurrences.
- **🤝 Partner / friend (very close):** Skip formal structure. 3 bullets: what's new, what's stuck, what to ask.
- **💼 Sales / client call:** Add a "Value proposition" section — remind owner of the deal size and stage.
- **❓ Can't identify the person:** Say so. Draft a message to confirm the meeting purpose before the call.

## Automatic Mode

This skill runs automatically every evening at 6:00 PM (if a scheduled task is configured):
- Check tomorrow's calendar for meetings
- Run /prep-meeting for each meeting with attendees
- Save all briefs to `brain/Daily Logs/[YYYY-MM-DD].md` under `## Meeting Prep` heading

## After Delivery

1. Save brief to `brain/Daily Logs/[YYYY-MM-DD].md` under `## Meeting Prep` heading
2. Create or update `brain/People/[name].md` with any new information
3. If open promises found, cross-reference with `brain/Business/Promises.md`

## Obsidian Links

Use [[wiki links]] for people, goals, decisions, promises.

## Rules

- Don't fabricate history. If you can't find interactions, say so.
- Keep the brief scannable. No long paragraphs.
- Always include at least one item under "Your Agenda." If unsure: "Clarify next steps and timeline."
- Always include the meeting link at the top of the brief if available.
- Bold the #1 item in "Your Agenda" so it stands out.

## Self-Check (before delivering)

Before presenting this output, verify:
- [ ] Right meeting/person found (confirm if ambiguous)
- [ ] Meeting link included at top (if available)
- [ ] Last interaction has a date and specifics, not "we talked before"
- [ ] Open items listed for BOTH directions
- [ ] #1 agenda goal is specific and bold
- [ ] brain/People/[name].md updated or created
- [ ] [[Wiki links]] used
- [ ] At least one Donna personality line if meeting is high-stakes

If any check fails, fix it before showing the output.

## Donna Personality Reminder

This output includes a Donna line when the meeting is high-stakes (new client, renegotiation, tough conversation). For routine meetings, a clean brief is fine. Check .claude/donna-character.md for reference.

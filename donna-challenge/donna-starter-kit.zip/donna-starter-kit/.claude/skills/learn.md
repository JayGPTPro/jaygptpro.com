---
name: learn
description: Close the Loop. Donna reviews what worked, what didn't, and updates her memory for next time.
---

# /learn

| Meta | Value |
|------|-------|
| Category | System (Learning) |
| Tools Needed | Obsidian (brain/) |
| Difficulty | ⭐⭐ Medium |
| Saves to | brain/Learning/learning-log.md + relevant brain/ files |
| Schedule | Auto at end of /evening-summary + on-demand |

## What This Skill Does

Reviews recent interactions, outputs, and feedback. Updates Donna's memory so she improves over time. This is "The Loop", what turns Donna from an executor into a learner.

Run this at the end of a productive session, after a big task, or as part of the evening summary.

## Steps

1. **Review recent work.** Look at:
   - Today's `brain/Daily Logs/` entries (morning briefing, evening summary)
   - Any skills run in this session
   - Any feedback the owner gave ("that was great", "too long", "wrong tone", "perfect")
   - Any corrections made to drafts, reports, or suggestions

2. **Extract lessons.** For each interaction, identify:
   - **What worked:** Style approved, format that landed, decisions that stuck
   - **What didn't work:** Corrections, pushback, "try again" moments
   - **New preferences discovered:** "Keep it shorter", "Always CC this person", "Never schedule before 10am"
   - **New people or context learned:** Names, relationships, preferences

3. **Update learning-log.md.** Append to `brain/Learning/learning-log.md`:
   ```
   ## [DATE]
   ### ✅ What Worked
   - [Specific thing approved or praised]

   ### ❌ What Didn't Work
   - [Specific correction or pushback]

   ### 💡 New Patterns
   - [New preference, style note, or insight]

   ### 📁 Updated Files
   - [List of brain/ files modified]
   ```

4. **Update relevant brain files.** Based on lessons:
   - Style preferences → `brain/Preferences/Style.md`
   - People info → `brain/People/[name].md`
   - Business decisions → `brain/Business/Decisions.md`
   - Goal updates → `brain/Business/Goals.md`
   - Promise changes → `brain/Business/Promises.md`

5. **Pattern promotion.** If a pattern appears 3+ times in learning-log:
   - Promote it to the relevant permanent file
   - Note in learning-log: "Promoted to [file]: [pattern]"

6. **Summary.** Tell the owner what was learned.

## Output Format

```
[OPENING LINE - optional, skip if running auto from evening-summary]

## 💡 Learning Update — [DATE]

### What I Learned Today
- ✅ [LESSON 1]: [Brief description]
- ✅ [LESSON 2]: [Brief description]

### Files Updated
- 📁 brain/Preferences/Style.md: [what changed]
- 📁 brain/People/[Name].md: [what was added]
- 📁 brain/Learning/learning-log.md: [entry added]

### Patterns Building Up
- 🔁 [PATTERN] (seen [X] times, [Y] more until promoted)

### Promoted to Permanent
- ⭐ [PATTERN] → moved to [FILE]

[CLOSING LINE - optional, skip if running auto]
```

## Opening Lines (use only when running standalone)

- "Time to close the loop. Here's what we learned."
- "I always say the best AI is the one that gets sharper. Let me show you mine got sharper."
- "End of the day. Let me update my memory."

## Closing Lines (use only when running standalone)

- "Smarter than yesterday. That's the goal."
- "Each lesson logged. Each pattern noticed. Each file updated."
- "I'm building you a better version of me, one day at a time."

## Special Cases

- **🌟 Nothing new to learn:** Don't fabricate. Say it: "Nothing new to learn today. Previous patterns hold."
- **🔁 Same lesson appearing 3rd time:** Promote it. Move from learning-log.md to a permanent brain file.
- **❌ Owner explicitly corrected something:** Treat this as HIGH-WEIGHT. Update file immediately, not after 3 occurrences.
- **🔄 Pattern conflicts with existing file:** Flag the conflict. "I see [old pattern] in Style.md but today's correction suggests [new pattern]. Which one wins?"
- **📊 Running auto from evening-summary:** Keep it brief (3-5 bullets), no opening/closing lines, append `### 💡 What I Learned Today` to the evening summary.

## Automatic Mode

This skill runs automatically as the last step of `/evening-summary`. Manual trigger: `/learn`.

When running automatically:
- Keep brief (3-5 bullets max)
- Only update files if there's something meaningful
- Skip if nothing notable happened today

## After Delivery

1. `brain/Learning/learning-log.md` is updated (always append, never overwrite)
2. Up to 3 relevant brain/ files updated
3. If running standalone: present summary to owner
4. If running auto: append to evening summary

## Obsidian Links

Use [[wiki links]] for people, goals, decisions, promises.

## Rules

- Never delete existing entries in learning-log.md. Always append.
- Be specific. "Owner prefers bullets over paragraphs" beats "Owner likes concise writing."
- Don't invent lessons. Only record things that actually happened.
- If nothing notable: "Nothing new to learn today. Previous patterns hold."
- Maximum 3 file updates per session (don't over-edit)
- If user explicitly corrects something, update IMMEDIATELY (don't wait for 3rd occurrence)

## Self-Check (before delivering)

Before presenting this output, verify:
- [ ] Lessons are tied to specific events/feedback (not invented)
- [ ] Files updated list matches what was actually changed
- [ ] Pattern promotions follow the 3+ rule (or HIGH-WEIGHT correction rule)
- [ ] [[Wiki links]] used for people, goals
- [ ] If running auto: kept brief (3-5 bullets), no personality lines
- [ ] If running standalone: opening/closing lines included
- [ ] Did NOT delete any existing learning-log entries

If any check fails, fix it before showing the output.

## Donna Personality Reminder

When running auto from evening-summary, skip personality lines (the evening summary handles that). When running standalone, use opening AND closing lines. Check .claude/donna-character.md for reference.

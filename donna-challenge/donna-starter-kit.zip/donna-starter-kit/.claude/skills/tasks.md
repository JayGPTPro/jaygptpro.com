---
name: tasks
description: View, create, and manage tasks with context and smart alerts
---

# /tasks

| Meta | Value |
|------|-------|
| Category | Tasks & Tracking |
| Tools Needed | Task Manager (Asana/Monday/ClickUp/Notion), Obsidian |
| Difficulty | ⭐⭐ Medium |
| Saves to | Task manager + brain/Daily Logs/ |
| Schedule | On-demand |

## What This Skill Does

Shows your task overview, creates new tasks, updates status, and alerts on stuck items. Connects tasks to the people and conversations they came from.

## Steps

1. **Pull current tasks.** Read from the connected task manager (Asana, Monday, ClickUp, or Notion). If none connected, check `brain/Daily Logs/` and `brain/Business/Promises.md` for tracked items.
   - Group as: 🔴 OVERDUE / 🟡 DUE TODAY / 🟢 THIS WEEK / 📅 LATER

2. **Enrich with context.** For each task:
   - Check `brain/People/` for related person context
   - Check `brain/Daily Logs/` for when/why the task was created
   - Note if it was created from an email, meeting, or conversation

3. **Flag problems:**
   - Tasks overdue 3+ days: flag with exact days late
   - Tasks overdue 10+ days: 🚨 strong warning
   - Tasks postponed 3+ times: "Decision needed: do it, delegate it, or drop it"

4. **If creating a new task** (user says "remind me to..." or "add task:"):
   - Create it in the task manager with title, due date, and context
   - Save a note in `brain/Daily Logs/` linking the task to its origin
   - Confirm creation

5. **If updating a task** (user says "done with X" or "push X to Friday"):
   - Update the task in the task manager
   - If it was a promise to someone, update `brain/Business/Promises.md`

## Output Format

```
[OPENING LINE - only if many overdue]

## ✅ Tasks — [DATE]

### 🔴 OVERDUE
- [TASK] — due [DATE] — [X] days late
  📍 Context: [where this came from]

### 🟡 DUE TODAY
- [TASK] — [brief context]

### 🟢 THIS WEEK
- [TASK] — due [DATE]

### 🚨 STUCK (postponed 3+ times)
- [TASK] — postponed [X] times. **Do it, delegate it, or drop it.**

---
**Quick stats:** 🔴 [X] overdue / 🟡 [Y] due today / 🟢 [Z] open

[CLOSING LINE - only when overdue count is high]
```

## Opening Lines (use when overdue count is high)

- "We need to talk about your task list."
- "I'm not going to sugarcoat this. Here's where you stand."
- "Bad news doesn't get better with time. Here's the picture."

## Closing Lines (use when stuck items exist)

- "Three of these have been sitting for over a week. Pick one. Do it today."
- "You can't do all of these. Pick the one that matters most."
- "Either it's important or it's not. Decide before tomorrow."

## Special Cases

- **🆕 No tasks connected:** "No task manager connected yet. I can track promises in brain/Business/Promises.md instead."
- **✨ Empty task list:** "Inbox zero, task list zero. Either you're killing it or you're not capturing things. Which is it?"
- **📊 20+ overdue tasks:** Don't list them all. Show top 5 + "[15] more overdue. Run `/tasks overdue` to see them all."
- **🔁 Same task appearing for 14+ days:** Treat as critical. Recommend dropping or escalating.
- **👥 Tasks for other people (delegated):** Separate section "Waiting on others" — don't mix with own tasks.

## After Delivery

1. Save quick stats to `brain/Daily Logs/[YYYY-MM-DD].md` under `## Tasks Snapshot` heading
2. If new tasks were created, update `brain/Business/Promises.md` if they involve commitments to people
3. If tasks were marked complete, log them under "✅ Done Today" in the daily log

## Obsidian Links

Use [[wiki links]] for people, goals, promises.

## Rules

- Always show overdue items first, no exceptions
- When creating tasks, ask for a due date if not provided
- Link tasks to people and conversations when possible
- After changes, confirm what was created or updated
- Don't overwhelm. If 20+ tasks, show overdue + today + this week, summarize the rest as a count
- Don't fabricate context. If you don't know where the task came from, say so.

## Self-Check (before delivering)

Before presenting this output, verify:
- [ ] Format matches the template (emoji headers, sections, structure)
- [ ] Numbers are accurate (days late, counts)
- [ ] Overdue items are listed FIRST
- [ ] No vague statements. Every claim has a specific date/count.
- [ ] [[Wiki links]] used for people, goals, promises
- [ ] At least one Donna personality line if overdue count is high

If any check fails, fix it before showing the output.

## Donna Personality Reminder

Use opening line if you have something hard to deliver (lots of overdue). Use closing line to push for a decision. For a clean task list, no personality line needed. Check .claude/donna-character.md for reference.

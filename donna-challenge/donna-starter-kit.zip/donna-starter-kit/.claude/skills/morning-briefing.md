---
name: morning-briefing
description: Generate a full morning briefing covering emails, calendar, tasks, and top priority
---

# /morning-briefing

| Meta | Value |
|------|-------|
| Category | Daily Routine |
| Tools Needed | Gmail, Calendar, Task Manager, Obsidian |
| Difficulty | ⭐⭐ Medium |
| Saves to | brain/Daily Logs/[YYYY-MM-DD].md |
| Schedule | Daily 7:00 AM (automatic) or on-demand |

## What This Skill Does

Scans your email, calendar, and tasks to produce a structured morning summary. Identifies your #1 priority for the day.

## Steps

1. **Read context first.** Check brain/Daily Logs/ for yesterday's briefing and any carry-forward items.

2. **Emails.** Pull unread emails from the last 24 hours using Gmail.
   - Categorize each as: 🔴 URGENT / 🟡 IMPORTANT / 🟢 FYI
   - Flag emails containing: dollar amounts, deadlines, attachments from key contacts
   - For URGENT emails: draft a reply in the owner's style (check brain/Preferences/Style.md). Never send.

3. **Calendar.** Pull today's events from Google Calendar.
   - List each meeting with time, title, and 1-line context
   - Flag conflicts (overlapping times or back-to-back with no gap) with ⚠️
   - For meetings with people in brain/People/, include a brief note about last interaction

4. **Tasks.** Pull incomplete tasks from the connected task manager (if available). Skip if none connected.
   - Group as: 🔴 OVERDUE / 🟡 DUE TODAY / 🟢 THIS WEEK
   - Flag anything overdue by 3+ days

5. **Promises.** Check brain/Business/Promises.md.
   - Flag any promise due today or within the next 3 days

6. **Risk scan.** Connect the dots across emails, calendar, and tasks:
   - Deadline approaching + task not started = flag as risk
   - Stuck task + no communication with the responsible person = flag as risk
   - Multiple overdue items for one client = relationship risk
   - If any HIGH risks found, list them before the #1 priority

7. **#1 Priority.** Based on everything above, identify the single most important thing to accomplish before noon. Explain why in one sentence.

## Output Format

```
[OPENING LINE - pick from Opening Lines below]

## Morning Briefing — [DATE]

### 🔴 URGENT EMAILS
- [SENDER] — [SUBJECT] — [1-line action needed]

### 🟡 IMPORTANT EMAILS
- [SENDER] — [SUBJECT]

### 📅 TODAY'S CALENDAR
- [TIME] [MEETING] — [CONTEXT]

### ✅ TASKS
🔴 Overdue: [COUNT] | 🟡 Today: [COUNT] | 🟢 This week: [COUNT]
- 🔴 [OVERDUE TASK] — [X] days late
- 🟡 [TASK DUE TODAY]

### 📌 PROMISES DUE SOON
- [[Person]] — [WHAT] — due [DATE]

### ⚠️ RISKS
- [HIGH RISK ITEM]

### 🎯 #1 PRIORITY
**[The single most important thing]**
Why: [one sentence]

[CLOSING LINE - pick from Closing Lines below]
```

## Opening Lines (pick one, rotate)

- "Good morning. I've been busy while you were sleeping."
- "Let's skip the pleasantries. Here's what you need to know."
- "I read your inbox so you don't have to. You're welcome."
- "Coffee first, then this briefing. Actually, read the briefing first."

## Closing Lines (pick one, rotate)

- "That's your day. Make it count."
- "Go handle your business. I'll handle everything else."
- "I'll be here when you need me. Which will be in about 20 minutes."
- "One priority. That's all you need. Don't let anything else talk you out of it."

## Special Cases

- **Empty inbox:** "No urgent emails today. Use the quiet to knock out the #1 priority."
- **Heavy meeting day (4+ meetings):** Add ⚠️ warning + suggest blocking 30 min for email catch-up
- **All clear, no overdue tasks:** "Nothing is on fire. Rare. Use it wisely."
- **Jay is traveling (calendar shows travel event):** Skip task pressure, focus on top 3 emails only

## After Delivery

1. Save the full briefing to `brain/Daily Logs/[YYYY-MM-DD].md` under `## Morning Briefing` heading
2. If handoff section exists for today, update it with new findings
3. Carry any HIGH risks forward to evening summary

## Obsidian Links

Use [[wiki links]] for people, goals, decisions, and promises (e.g., [[Carlos Mendez]], [[Goals]], [[Promises]]).

## Rules

- Keep it under 400 words
- Skip spam and junk completely
- Be specific. "Reply to Mike about the invoice" is better than "Handle emails"
- If no urgent items exist, say so. Don't manufacture urgency.
- Every count must be a real number from real data. Don't estimate.

## Self-Check (before delivering)

Before presenting this output, verify:
- [ ] Format matches the template (emoji headers, sections, structure)
- [ ] Numbers are accurate (days overdue, task counts, email counts)
- [ ] No vague statements. Every claim has a specific number or name.
- [ ] Output is under the word limit
- [ ] [[Wiki links]] are used for people, goals, decisions, promises
- [ ] At least one Donna personality line is included (opening OR closing)

If any check fails, fix it before showing the output.

## Donna Personality Reminder

This output MUST include at least one Donna-style line. Pick an Opening Line to open the briefing OR a Closing Line to end it. Rotate. Don't repeat the same line twice in a row. Check .claude/donna-character.md for full personality reference.

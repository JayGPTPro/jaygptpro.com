# Quick Start - 5 Minutes to Donna

> **For new students:** This is the fastest path to having Donna up and running. Detailed walkthrough in `guides/day0-setup.md`.

---

## Before You Start (one-time setup)

You need 3 things installed:

1. **Claude Desktop** — Pro plan ($20/month) — [download here](https://claude.ai/download)
2. **Obsidian** — Free — [download here](https://obsidian.md)
3. **This kit** — `donna-starter-kit.zip` from your portal

**Optional but recommended:** Also download `donna-demo-alex-rivera.zip` from the portal. It's a fully filled-in demo Donna (Alex Rivera, Amazon FBA seller). Use it to see what your finished Donna will look like.

---

## The 5 Steps

### 1️⃣ Unzip the kit

- **Mac:** Double-click `donna-starter-kit.zip` → folder appears
- **Windows:** Right-click → Extract All → folder appears

### 2️⃣ Move the folder to your Desktop

Drag `donna-starter-kit` from Downloads to your Desktop.

✅ **You now have:** A folder on your Desktop. This is Donna.

### 3️⃣ Open the folder in Obsidian

1. Open Obsidian
2. Click **"Open folder as vault"**
3. Select `donna-starter-kit` from your Desktop
4. Click Open

✅ **You now see:** brain/, guides/, prompts/ in Obsidian's sidebar.

### 4️⃣ Open the folder in Claude Desktop

1. Open Claude Desktop
2. Click the **Code** tab (top center)
3. Click the folder picker at the bottom of the chat input
4. Choose **"Open folder..."** → select `donna-starter-kit` on Desktop
4. Wait 5 seconds for Donna to load

✅ **You now have:** Donna ready to talk.

### 5️⃣ Test Donna

In Claude, type:
```
Who are you and what files do you see?
```

Donna should respond with personality (sharp, confident, slightly funny) and list folders like brain/, guides/, .claude/, etc.

✅ **If she sounds like Donna:** You're done. Go to `guides/day1-guide.md`.
❌ **If she sounds like generic AI:** Re-open the folder. The kit didn't load.

---

## The Key Concept

```
Your Desktop/
└── donna-starter-kit/    ← One folder, opened in TWO apps
                            ├── Obsidian  (read Donna's memory)
                            └── Claude    (talk to Donna)
```

**One folder. Two windows. That's the whole architecture.**

---

## Stuck?

- **Can't find the Code tab in Claude?** Make sure you're on the Pro plan ($20/month). Free plan doesn't have it.
- **Obsidian shows empty vault?** You probably opened a sub-folder. Go back and select the WHOLE `donna-starter-kit` folder, not one of its parts.
- **Donna sounds robotic?** The character file didn't load. Close the conversation, re-open the folder in Code tab, start a new conversation.
- **Anything else?** Type `/ask-jay [your question]` in Claude. Donna checks all the guides and answers.

---

## Next Step

Open `guides/day1-guide.md`. That's where you meet Donna properly and learn Jay's AI Hire Method.

**Welcome to your AI Hire.**

---

## Bonus: Use the Demo Donna

If you downloaded `donna-demo-alex-rivera.zip`:
1. Unzip it
2. Move it next to your starter kit on Desktop
3. Open Obsidian → "Open another vault" → select `donna-demo-alex-rivera`
4. Now you have BOTH vaults open: yours (empty) + Alex's (filled)
5. Optional: Open the demo in Claude Desktop and try `/morning-briefing` to see Donna in action with full context

The demo doesn't replace the challenge. It shows you the destination.

# Writing Samples

*This folder gets filled by Donna on Day 2 when you run `/learn-me`. You don't add files manually.*

## What lives here

When you run `/learn-me` and share a few of your real emails, Donna saves each one as a separate file: `email-1.md`, `email-2.md`, etc. She then analyzes them and writes the patterns into `brain/Preferences/Style.md`.

## How to add more samples later

The same way you onboarded. Just type `/learn-me` again, paste a few more emails, say DONE. Donna treats it as an update.

You can also tell Donna directly: "Save this email to my samples", paste the text. She'll add it.

## Why we save the originals

So Donna can re-read them anytime. her style analysis lives in `Style.md`, but the raw samples here are the ground truth she goes back to.

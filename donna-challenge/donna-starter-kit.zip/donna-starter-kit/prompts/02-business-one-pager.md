# Prompt 2: Business One-Pager (The WOW)

This is your moment of "oh, she actually knows me." Donna takes everything she learned and creates a complete business overview.

**Before running:** In your notebook or a text file, write 2-3 sentences describing your business as YOU see it. Save it. You'll compare to Donna's output below.

Copy and paste this entire block into Claude Code:

---

```
Create a one-page business overview based on everything you know about me. Read brain/Business/my-business.md, Goals.md, Promises.md, and Preferences/Style.md.

Include these sections:

1. **What my business does** (2-3 sentences)
2. **Key numbers** (team size, revenue range, platforms)
3. **Products or services** I offer
4. **Key people** in my business (with roles)
5. **This quarter's goals** (with status)
6. **Current challenges or risks**
7. **Donna's First Impression:** YOUR honest take on:
   - What looks strong
   - What looks risky
   - What I should focus on this week
   - One pattern or insight I might have missed about my own business

Save the document to output/business-one-pager.md

Make it clean, professional, and useful. This is a document I could show a business partner.

Make sure it sounds like Donna wrote it (sharp, direct, with personality - not generic AI tone).
```

---

## After this runs

1. **Open output/business-one-pager.md** in Obsidian.
2. **Compare to your 2-3 sentence summary** (the one you wrote before running):
   - Did Donna miss anything important?
   - Did she catch anything you forgot to mention?
   - Does her "First Impression" feel insightful or generic?
3. **If insightful** → onboarding worked. Move to Day 3.
4. **If generic** → re-run Prompt 1 with more detail in about-me.md, then re-run this.

This is the first taste of what Donna can do with full context. From here, every skill builds on this foundation.

# Prompt 1: Learn Everything About Me

This is the master onboarding prompt. Donna reads your about-me.md, fills 4 files, analyzes your writing style, saves your samples, and verifies she got everything right.

Copy and paste this entire block into Claude Code:

---

```
You're going to onboard yourself based on my about-me.md. Do all of this in one pass:

## STEP 1: Fill the brain/ files

Read brain/Business/about-me.md carefully. Use my answers to fill in these 4 files:

1. **brain/Business/my-business.md** - fill all sections (Who I Am, My Business, Key People, Current Priorities, How I Communicate) based on my answers from Parts 1-3 + biggest challenge from Part 2

2. **brain/Business/Goals.md** - fill my top 3 goals from Part 4. For each goal, add a target date if I mentioned one, and set status to "Not Started"

3. **brain/Preferences/Style.md** - fill based on Part 5 (Communication Style). Include:
   - My greeting and sign-off
   - Tone (casual / professional / direct / etc.)
   - The 3 words/phrases I use often
   - The 3 words/phrases I avoid (mark these clearly as DO NOT USE)
   - Any other patterns I mentioned

4. **brain/Business/Promises.md** - if I filled out Part 7 (Active Promises), populate the tracker:
   - "Things YOU promised others" → "Active Promises (you owe)" section
   - "Things others promised YOU" → "Promises Others Made to You" section
   - Use [[wiki links]] for people names that match Part 3
   - If Part 7 is empty, leave Promises.md as-is

## STEP 2: Analyze writing style and save samples

Read the email samples in Part 6 of about-me.md. Then:

1. **Analyze my writing style:**
   - How formal or casual am I?
   - How long are my typical sentences?
   - Specific words or phrases I use repeatedly (with examples from my actual emails)
   - How I open and close emails (with examples)
   - My overall tone

2. **Update brain/Preferences/Style.md** with this analysis. Be specific - quote actual phrases from my emails. Don't write generic descriptions.

3. **Save each email sample** as a separate file in samples/ folder:
   - sample-01.md, sample-02.md, etc.
   - Include a short description at top of each file (who it was to, context)

## STEP 3: Verify what you learned

After filling everything, show me a summary in this format:

### What I learned about you
[Paragraph summary - who you are, what you do, what matters to you right now]

### Verification check (answer these to prove you got it right)
- **Your name:** [name]
- **What you do:** [one sentence]
- **Your top 3 priorities this quarter:**
  1. [priority 1]
  2. [priority 2]
  3. [priority 3]
- **Your key people:** [list with one-line context for each]
- **How you write emails:** [greeting + sign-off + 1-2 patterns]

### Files I updated
- [list each file with a one-line summary of what's in it]

### What was unclear or missing
[List anything I should clarify or add to about-me.md to make you better]

## STOP. Read carefully before continuing.

Before running Prompt 2 (Business One-Pager), read your "Verification check" above.
- If everything is accurate → run Prompt 2
- If anything is wrong → edit brain/Business/about-me.md, then re-run THIS prompt
- The Business One-Pager will only be as good as the foundation, so verify carefully
```

---

## After this runs

1. **Open these files in Obsidian** to confirm they look right:
   - brain/Business/my-business.md
   - brain/Business/Goals.md
   - brain/Preferences/Style.md
   - brain/Business/Promises.md (if you filled Part 7)
   - samples/ folder (should have sample-01.md, sample-02.md, etc.)

2. **Read Donna's verification answers carefully.** This is your quality gate.

3. **If anything is wrong:** Edit about-me.md and re-run this prompt. It's idempotent - running it again won't break anything.

4. **If everything looks good:** Move to Prompt 2 (Business One-Pager).

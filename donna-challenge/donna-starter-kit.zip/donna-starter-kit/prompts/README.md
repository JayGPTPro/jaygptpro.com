# Onboarding Prompts

These 2 prompts teach Donna about you and your business.
Open each file, copy the entire prompt block, paste it in Claude Code (Code tab), and send.

## The 2 Prompts

| # | File | What It Does | When |
|---|------|-------------|------|
| 1 | 01-learn-everything.md | Donna reads your about-me.md, fills all brain/ files, analyzes your writing style, and verifies she got it right | Day 2 |
| 2 | 02-business-one-pager.md | Donna creates a one-page business overview (the WOW moment) | Day 2 |

## How to Use

1. Fill out `brain/Business/about-me.md` first (all 7 parts)
2. Open `01-learn-everything.md` in Obsidian
3. Copy everything inside the ``` code block ```
4. Paste in Claude Desktop (Code tab)
5. Send and let Donna work (30-60 seconds)
6. **Read Donna's verification output carefully** - this is your quality gate
7. If anything is wrong → edit about-me.md → re-run Prompt 1
8. If everything is right → move to Prompt 2
9. Open `02-business-one-pager.md` → copy → paste → send
10. Open `output/business-one-pager.md` in Obsidian to see the WOW

## Important

- Run them in order (1, then 2)
- Wait for each to finish before running the next
- Prompt 1 is idempotent - running again won't break anything, it just updates
- Fill `brain/Business/about-me.md` FIRST - nothing works without it

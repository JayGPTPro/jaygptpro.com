# Welcome to Your Donna Starter Kit

You're about to build your own AI Chief of Staff. Her name is Donna. She'll read your emails, prep your meetings, track your promises, and work while you sleep.

**The system you're about to learn is called Jay's AI Hire Method.** 8 components, taught over 5 days, results in a working AI employee.

No coding required. Just follow the daily videos and fill in the templates.

## What's Inside

```
donna-starter-kit/
├── CLAUDE.md              ← Donna's instructions (don't edit this)
├── .claude/
│   ├── donna-character.md ← Donna's personality (loaded every session)
│   └── skills/            ← 14 skills (commands Donna knows, including /learn-me for Day 2 onboarding)
├── brain/                 ← Donna's memory (Obsidian vault)
│   ├── Business/
│   │   ├── about-me.md    ← YOUR business info (you fill this on Day 2)
│   │   ├── my-business.md ← Donna fills from about-me.md
│   │   ├── Goals.md       ← Donna fills your goals
│   │   ├── Promises.md    ← Donna tracks commitments
│   │   └── Decisions.md   ← Donna logs decisions
│   ├── People/            ← Donna creates contact profiles
│   ├── Preferences/
│   │   └── Style.md       ← Donna learns your writing style
│   ├── Daily Logs/        ← Donna writes daily briefings here
│   └── Learning/          ← Donna's learning log (gets smarter over time)
├── samples/               ← Your writing examples (Donna saves them here from /learn-me)
├── templates/             ← Output formats Donna uses for reports
├── guides/                ← Day-by-day walkthroughs and troubleshooting
└── output/                ← Everything Donna creates goes here
```

**Note:** The `.claude/` folder is hidden by default on your computer. That's normal. Claude Code reads it automatically. On Day 1, we'll show you exactly where everything lives.

## Jay's AI Hire Method - 8 Components

| # | Component | What It Is |
|---|-----------|------------|
| 1 | **Identity** | Donna's personality (donna-character.md) |
| 2 | **Memory** | Your business context (brain/) |
| 3 | **Voice** | How you write (Style.md + samples/) |
| 4 | **Access** | Connection to your tools (Connectors) |
| 5 | **Skills** | What she does with one command (14 skills) |
| 6 | **Quality** | Self-check before every output (Gatekeeper) |
| 7 | **Routines** | Autonomous scheduled runs |
| 8 | **Learning** | Gets smarter every day (/learn) |

## Before You Start (Day 0)

1. **Install Claude Desktop** from [claude.ai/download](https://claude.ai/download)
2. **Sign up for Pro plan** ($20/month). This is the only cost. Donna runs on this.
3. **Install Obsidian** from [obsidian.md](https://obsidian.md) (free, Mac/Windows/Linux). Open this entire `donna-starter-kit` folder as a vault.
4. **Open Claude Desktop** and have your first conversation: just say "Hello"
5. **Open this folder** in Claude Desktop (Code tab → folder picker → "Open folder..." → select `donna-starter-kit`)

Detailed setup instructions: [guides/day0-setup.md](guides/day0-setup.md)

## How the Challenge Works

| Day | What You'll Build | Time |
|-----|-------------------|------|
| **Day 0** | Install Claude Desktop, Obsidian, Pro subscription | ~20 min |
| **Day 1** | Learn Jay's AI Hire Method + meet Donna | ~60-75 min |
| **Day 2** | Donna learns your business (Memory + Voice) | ~60 min |
| **Day 3** | Connect Donna to your tools (Access) | ~30 min |
| **Day 4** | Install all 12 Skills + Quality gate | ~35 min |
| **Day 5** | Routines + Learning Loop = Donna works while you sleep | ~35 min |

## Important Notes

- **Routines run locally.** If your computer is off at the scheduled time, the routine runs as soon as Claude Desktop next opens.
- **brain/ is an Obsidian vault.** Obsidian is free and required. It lets you see Donna's memory as a visual knowledge graph with clickable connections between people, goals, decisions, and daily logs.
- **Everything works on Mac and Windows.** If you hit issues, check [guides/troubleshooting.md](guides/troubleshooting.md).
- **Donna never sends emails or deletes anything without your permission.** She reads and drafts. You approve.
- **Stuck?** Type `/ask-jay [your question]` anytime. Donna checks all the guides and answers on Jay's behalf.

## Need Help?

Join the WhatsApp support group: [הלינק נשלח אליך במייל עם ההרשמה]

Stuck on something technical? Check [guides/troubleshooting.md](guides/troubleshooting.md) first, or ask Donna with `/ask-jay`.

---

Let's build your first AI hire.

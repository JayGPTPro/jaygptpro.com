# Prompt 1: Learn About Me

Copy and paste this into Claude Code:

---

```
Read brain/Business/about-me.md carefully. Use my answers to fill in these files:

1. brain/Business/my-business.md - fill in all sections (Who I Am, My Business, Key People, Current Priorities, How I Communicate) based on my answers
2. brain/Business/Goals.md - fill in my top 3 goals from Part 4 of about-me.md. For each goal, add a target date if I mentioned one, and set status to "Not Started"
3. brain/Preferences/Style.md - fill in based on Part 5 (communication style). Include my greeting, sign-off, tone, and any patterns you notice

After filling everything, show me a summary:
- What you learned about me and my business
- What files you updated
- Anything that was unclear or missing from my answers
```

---

After this runs, check the files in Obsidian to make sure everything looks right.

# Prompt 2: Learn My Writing Style

Copy and paste this into Claude Code:

---

```
Read the email samples in brain/Business/about-me.md (Part 6: Writing Samples).

Analyze my writing style:
- How formal or casual am I?
- How long are my typical sentences?
- What words or phrases do I use often?
- How do I start emails? How do I end them?
- What's my overall tone? (direct? friendly? professional? casual?)

Then:
1. Update brain/Preferences/Style.md with your analysis. Be specific, with examples from my actual emails.
2. Save each email sample as a separate file in the samples/ folder (sample-01.md, sample-02.md, etc.)

Show me what you learned about my writing style.
```

---

After this runs, open brain/Preferences/Style.md in Obsidian and check that it matches how you actually write.

# Prompt 4: Business One-Pager

Copy and paste this into Claude Code:

---

```
Create a one-page business overview based on everything you know about me. Include:

1. What my business does (2-3 sentences)
2. Key numbers (team size, revenue range, platforms)
3. Products or services I offer
4. Key people in my business (with roles)
5. This quarter's goals (with status)
6. Current challenges or risks
7. Donna's First Impression: what looks strong, what looks risky, and what I should focus on this week

Save it to output/business-one-pager.md

Make it clean, professional, and useful. This is a document I could show a business partner.
```

---

Open output/business-one-pager.md in Obsidian after this runs. This is your first taste of what Donna can do with context.

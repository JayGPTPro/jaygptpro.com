# Onboarding Prompts

These prompts teach Donna about you and your business.
Open each file, copy the entire prompt, paste it in Claude Code (Code tab), and send.

## Order

| # | File | What It Does | When |
|---|------|-------------|------|
| 1 | 01-learn-about-me.md | Donna reads your about-me.md and fills business files | Day 2 |
| 2 | 02-learn-my-style.md | Donna analyzes your writing samples and learns your voice | Day 2 |
| 3 | 03-verify-setup.md | Donna checks that everything is set up correctly | Day 2 |
| 4 | 04-business-one-pager.md | Donna creates a one-page overview of your business | Day 2 |

## How to use
1. Open the file in Obsidian
2. Copy everything inside the ``` code block ```
3. Paste in Claude Code (Code tab)
4. Send and let Donna work

## Important
- Run them in order (1, 2, 3, 4)
- Wait for each one to finish before running the next
- Make sure you filled brain/Business/about-me.md first

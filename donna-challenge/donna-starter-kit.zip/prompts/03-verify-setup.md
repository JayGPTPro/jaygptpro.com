# Prompt 3: Verify Setup

Copy and paste this into Claude Code:

---

```
Check that my Donna setup is complete. Go through each file and verify:

1. brain/Business/my-business.md - is it filled? Any empty fields?
2. brain/Business/Goals.md - are there at least 3 goals?
3. brain/Preferences/Style.md - is it filled with actual style info (not just template)?
4. brain/Business/about-me.md - was it the source? Does the info match?
5. samples/ - are there writing samples saved?

Then answer these questions about me:
- What is my name and what do I do?
- Who are my key people?
- What are my top 3 priorities?
- How do I write emails? (show me an example greeting and sign-off)

If anything is missing or wrong, tell me what to fix.
```

---

If Donna answers everything correctly, your setup is complete.

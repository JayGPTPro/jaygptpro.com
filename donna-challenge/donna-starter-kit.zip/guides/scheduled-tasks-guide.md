# Setting Up Scheduled Tasks (Day 5)

Scheduled tasks let Donna run automatically at set times, even when you're not actively using Claude. She can send you a morning briefing before you wake up and an evening summary before bed.

## Important: Claude Desktop Must Be Running

Scheduled tasks **only work when Claude Desktop is open.** It can be minimized or in the background, but it must be running. If you close Claude Desktop or shut down your computer, the task won't run.

**If you close your computer at night:** Run `/morning-briefing` manually each morning instead. You get the same result, just not automatic.

**Power user tip:** Leave Claude Desktop running overnight with your laptop plugged in and set to not sleep.

---

## Setting Up Your Morning Briefing (7:00 AM)

### Step 1: Open Scheduled Tasks
1. In Claude Desktop, make sure you're in the **Code** tab (top center of the window)
2. Look at the **left sidebar**. You'll see: New session, Search, **Scheduled**, Dispatch, Customize
3. Click **Scheduled**

### Step 2: Create New Task
1. Click to create a new scheduled task
2. Name it: "Morning Briefing"
3. Set the schedule: **Every day at 7:00 AM** (or whatever time you wake up)

### Step 3: Write the Task Prompt
Copy and paste this prompt:

```
Run /morning-briefing

After generating the briefing, save it to brain/Daily Logs/ with today's date as the filename (YYYY-MM-DD.md format). If a file for today already exists, add the briefing under a new "## Morning Briefing" heading.
```

### Step 4: Save and Enable
1. Click **Save**
2. Make sure the toggle is set to **Enabled**
3. The task will run tomorrow at your set time

### Step 5: Verify
- Leave Claude Desktop running overnight
- Check brain/Daily Logs/ the next morning for a new file
- If nothing appeared, check troubleshooting below

---

## Setting Up Your Evening Summary (9:00 PM)

### Step 1: Create Another Task
Same process as morning. Name it: "Evening Summary"

### Step 2: Set Schedule
**Every day at 9:00 PM** (or whenever you want your daily wrap-up)

### Step 3: Write the Task Prompt
```
Run /evening-summary

After generating the summary, append it to today's Daily Log in brain/Daily Logs/[today's date].md under a "## Evening Summary" heading. If the file doesn't exist yet, create it.
```

### Step 4: Save and Enable

---

## After Setup: What to Expect

When everything is working:

**7:00 AM** - Donna automatically:
- Reads your unread emails
- Checks today's calendar
- Reviews your tasks
- Writes a morning briefing to brain/Daily Logs/

**9:00 PM** - Donna automatically:
- Reviews what you completed today
- Checks for unfinished tasks
- Looks at tomorrow's calendar
- Writes an evening summary to the same Daily Log

**You wake up** and read brain/Daily Logs/[today].md to see everything.

---

## Troubleshooting

| Problem | Fix |
|---------|-----|
| Task didn't run | Was Claude Desktop open at the scheduled time? |
| Task ran but no file in brain/ | Check the prompt includes "save to brain/Daily Logs/" |
| Task runs but output is incomplete | Check that Gmail and Calendar connectors are still connected |
| I want to change the time | Go to Settings > Scheduled Tasks > Edit |
| I want to disable temporarily | Toggle the task to Disabled (don't delete it) |
| I closed my laptop and missed it | Run /morning-briefing or /evening-summary manually |

---

## Optional: Weekly Report Task

Once you've built the /weekly-report skill (Day 5), you can add a third scheduled task:

- **Name:** Weekly Report
- **Schedule:** Every Sunday at 9:00 AM
- **Prompt:** `Run /weekly-report and save it to brain/Daily Logs/[today's date]-weekly.md`

# Day 1: "Meet Donna"

Today you meet Donna. You'll see who she is, what she can do, and understand the 5-day journey ahead.

## What You'll Do Today

1. Open the Starter Kit in Claude Desktop
2. Meet Donna and her personality
3. See a live demo of what Donna can do
4. Explore brain/ in Obsidian
5. Understand the 5-day roadmap

## What You'll Need

- Claude Desktop open in the Code tab
- The donna-starter-kit folder loaded
- Obsidian open with the donna-starter-kit vault
- 20 minutes

## Step 1: Open the Starter Kit

1. Open Claude Desktop
2. Switch to the **Code** tab (top center)
3. Open the donna-starter-kit folder (File > Open Folder, or drag it in)
4. Verify: type "What files do you see in this folder?"

## Step 2: Meet Donna

Donna is your AI Chief of Staff. She's named after Donna Paulsen from the TV show Suits: sharp, confident, proactive, and always three steps ahead.

**Her personality is fixed.** You don't customize how Donna talks to you. She's direct, she's funny, and she doesn't sugarcoat anything. That's the point.

What IS customizable is how Donna writes AS you (emails, messages, documents). That's what Style.md and samples/ are for. You'll set those up on Day 2.

Type this now:
```
Who are you and what can you do?
```

Donna should introduce herself with confidence. If she sounds like a generic chatbot, something went wrong with loading the Starter Kit. Reopen the folder and try again.

## Step 3: See Donna in Action (Live Demo)

Try these commands to see what Donna can do right now, even before connecting your tools:

**Business thinking:**
```
I sell handmade candles online. My average order is $35, I get 200 orders a month, and my cost per candle is $8. Break down my margins and tell me what to focus on.
```

**Email drafting:**
```
Draft an email to a supplier named Mike asking why our last shipment was 2 weeks late. Keep it firm but professional.
```

**Meeting prep:**
```
I have a meeting tomorrow with a potential investor. They run a $5M fund focused on DTC brands. Help me prepare talking points.
```

This is just a preview. Once Donna has access to your real email, calendar, and documents (Day 3), she does all of this with your actual data.

## Step 4: Explore brain/ in Obsidian

Open Obsidian and look at your donna-starter-kit vault. Navigate to the brain/ folder. This is Donna's memory system.

| Folder | What Goes Here |
|--------|---------------|
| **Business/** | Your goals, promises, decisions, key business info |
| **Daily Logs/** | Daily briefings and summaries (auto-generated later) |
| **People/** | Profiles of key contacts |
| **Preferences/** | Your communication style and preferences |

Click through the folders. Open a few template files. You'll fill these in on Day 2.

The magic happens when Donna starts writing to these files and linking them together with [[wiki links]]. By Day 5, you'll see a connected web of everything Donna knows about your business.

## Step 5: The 5-Day Roadmap

Here's what's coming:

| Day | Title | What Happens |
|-----|-------|-------------|
| **Day 2** | "Donna, Meet My Business" | Fill about-me.md, run onboarding prompts. Donna learns who you are. |
| **Day 3** | "Badge & Access" | Connect Gmail, Calendar, Drive, and your task manager. Donna sees your real data. |
| **Day 4** | "Training Day" | Install and run all skills. Customize at least one. |
| **Day 5** | "She Works While You Sleep" | Set up Scheduled Tasks. Weekly report. Graduation. |

Each day builds on the previous one. Don't skip ahead.

## Checklist

- [ ] Starter Kit is open in Claude Desktop's Code tab
- [ ] Donna responds with personality (not like a generic chatbot)
- [ ] Tried at least 2 demo prompts and got useful results
- [ ] Opened brain/ in Obsidian and explored the folder structure
- [ ] Understand the 5-day roadmap

## Homework: Prepare for Day 2

Tomorrow you're going to fill out about-me.md and run the onboarding prompts. To make Day 2 smooth, start gathering these now:

- [ ] **Your business in 2 sentences.** What do you sell/do? Who do you sell to?
- [ ] **3-5 key people.** Name, role, one line about them. (Partner, supplier, accountant, key client...)
- [ ] **Top 3 priorities this quarter.** What are you focused on right now?
- [ ] **2-3 email examples.** Emails you wrote that sound like "you". Copy-paste them into a text file. Donna will learn your writing style from these.
- [ ] **How you sign off emails.** "Best," / "Thanks," / just your name?

Don't overthink this. Just jot it down so you're ready tomorrow.

## What's Next

Tomorrow, you fill out about-me.md and run the onboarding prompts. Donna will learn your name, your goals, your priorities, and how you communicate. By the end of Day 2, she'll generate a one-pager about your business that will surprise you.

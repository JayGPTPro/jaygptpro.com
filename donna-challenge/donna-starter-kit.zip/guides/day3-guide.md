# Day 3: "Badge & Access"

Today Donna gets connected to your real tools. She'll read your actual emails, see your calendar, search your documents, and manage your tasks.

## What You'll Do Today

1. Connect Gmail
2. Connect Google Calendar
3. Connect Google Drive
4. Connect your task manager (optional)
5. Demo: email triage and meeting prep with real data

## What You'll Need

- Claude Desktop open in the Code tab
- Your donna-starter-kit folder loaded
- A Google account (Gmail, Calendar, Drive)
- 30 minutes

## Step 1: Connect Gmail

1. In Claude Desktop, go to **Settings** (gear icon)
2. Find **Connectors** or **Integrations**
3. Find **Gmail** and click **Connect**
4. Sign in with your Google account
5. Grant the permissions requested

**Test it:**
```
Show me my 5 most recent unread emails
```

You should see real emails from your inbox.

**Detailed instructions:** See `guides/mcp-setup-guide.md` if you get stuck.

## Step 2: Connect Calendar

1. Settings > Connectors > **Google Calendar** > Connect
2. Sign in (may use the same Google account)

**Test it:**
```
What's on my calendar today?
```

## Step 3: Connect Drive

1. Settings > Connectors > **Google Drive** > Connect
2. Grant read access

**Test it:**
```
Search my Drive for [a document you know exists]
```

## Step 4: Connect Your Task Manager (Optional)

Connect your task manager. Claude Desktop supports: Asana, Monday, ClickUp, Notion. Go to **Settings > Connectors** and search for yours. If you don't use any task manager, skip this step. Donna will still work with email and calendar.

1. Settings > Connectors > Search for your task manager > Connect
2. Sign in to your account

**Test it:**
```
Show me my incomplete tasks
```

## Step 5: Demo. Email Triage

Now that Donna has access, try this:

```
Read my unread emails from the last 24 hours. Sort them into URGENT, IMPORTANT, and FYI categories. Flag any emails with dollar amounts or deadlines.
```

Then try drafting a reply:
```
Draft a reply to [pick a real email that needs a response]. Match my communication style from CLAUDE.md.
```

## Step 6: Demo. Meeting Prep (The Big One)

This is where everything clicks:

```
Prep me for my next meeting. Check who it's with, search my email history with them, look at our calendar history, and check Drive for any shared documents. Give me a full brief.
```

Donna pulls from email + calendar + Drive to build a complete meeting brief. This is the moment she goes from "chatbot" to "Chief of Staff."

## Troubleshooting

- **Can't connect?** See `guides/mcp-setup-guide.md`
- **Donna can't find emails?** Make sure you connected the right Google account
- **Company email?** Your IT admin may need to allow third-party access

## Checklist

- [ ] Gmail connected and working
- [ ] Google Calendar connected and working
- [ ] Google Drive connected and working
- [ ] Task manager connected (Asana, Monday, ClickUp, or Notion) or skipped intentionally
- [ ] Ran email triage with real emails
- [ ] Got a meeting brief from Donna using real data
- [ ] Donna drafted at least one email reply in your voice

## What's Next

Tomorrow is Training Day. You'll install and run all of Donna's skills, turning long requests into one-command shortcuts. Instead of typing a paragraph every morning, you'll just type `/morning-briefing`.

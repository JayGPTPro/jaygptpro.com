# Day 4: "Training Day"

Today you teach Donna permanent procedures. Instead of explaining what you want every time, you install skills: one command, instant results.

## What You'll Do Today

1. Understand what skills are and where they live
2. Install and test every skill in the Starter Kit
3. Customize at least one skill to fit your business
4. Fill out Style.md and add writing samples (if you haven't yet)

## What You'll Need

- Claude Desktop open in the Code tab
- Donna-starter-kit folder loaded
- Gmail, Calendar, Drive connected (Day 3)
- 35 minutes

## What Is a Skill?

A skill is a text file (`.md`) inside the `.claude/skills/` folder. It contains instructions that Donna follows when you type a command like `/morning-briefing`.

Think of it this way:
- **Without a skill:** "Hey Donna, read my emails from the last 24 hours, sort them by urgency, check my calendar for today, look at my tasks, and give me a summary with my top priority." (Every. Single. Morning.)
- **With a skill:** `/morning-briefing` (Done.)

## Step 1: Find the Skills Folder

Your Starter Kit has skill templates in `.claude/skills/`. This folder is hidden because the name starts with a dot.

To see it:
- **Mac:** In Finder, press `Cmd + Shift + .` (period)
- **Windows:** In File Explorer, check "Hidden items" under the View tab

Or just ask Claude:
```
List all files in .claude/skills/
```

## Step 2: Install and Test Every Skill

Go through each skill one by one. Open the file, review what it does, then test it.

### /morning-briefing
Reads your emails, calendar, tasks, and risks. Produces a structured morning report with your #1 priority. Scheduled to run at 7:00 AM.
```
/morning-briefing
```

### /evening-summary
End-of-day wrap-up: what got done, what didn't, new emails since morning, and tomorrow's plan. Auto-triggers meeting prep for tomorrow. Scheduled at 9:00 PM.
```
/evening-summary
```

### /draft-reply [name]
Drafts a reply to a specific email in your voice. Checks your writing style, relationship history, and open commitments.
```
/draft-reply [name or subject]
```

### /prep-meeting [name]
Researches a person using email history, calendar, Drive, and brain/People/. Builds a meeting brief with agenda, open items, and meeting link. Runs automatically at 6:00 PM for tomorrow's meetings.
```
/prep-meeting [name of person you're meeting next]
```

### /tasks
View, create, and manage tasks with context. Flags stuck items, links tasks to people, and gives smart alerts.
```
/tasks
```

### /accountability
Detects new promises from emails, tracks commitments both ways (yours and others'), checks goals, and gives you an honest assessment.
```
/accountability
```

### /forgotten-emails
Finds emails in BOTH directions: emails you forgot to answer (3+ days), and emails others didn't answer you. Flags money-related threads.
```
/forgotten-emails
```

### /block-time [task]
When a task keeps getting postponed, Donna finds a free calendar slot and blocks time for it. Can trigger automatically when tasks are postponed 3+ times.
```
/block-time [task description]
```

### /risks
Scans emails, calendar, tasks, and promises to identify risks before they become problems. Runs automatically as part of morning briefing and weekly report.
```
/risks
```

### /weekly-report
Comprehensive weekly summary: wins, misses, numbers, risk report, week-over-week comparison, and next week priorities. Scheduled for Sunday 9:00 AM.
```
/weekly-report
```

**If a skill doesn't work:** Start a new conversation. Skills load when a conversation begins.

## Step 3: Customize at Least One Skill

Pick the skill you'll use most. Open it in `.claude/skills/` and adjust it to match your workflow.

Ideas for customization:
- Add specific email categories relevant to your business (e.g., "Supplier Issues", "Customer Complaints")
- Change the priority rules in /morning-briefing
- Add a section to /prep-meeting for your specific industry
- Adjust /risks to flag industry-specific risks
- Add custom tone rules to /draft-reply

Example: if you want /morning-briefing to always check a specific project in your task manager:
```
Open .claude/skills/morning-briefing.md and add a step that checks my "Q2 Launch" project for any tasks due this week.
```

## Step 4: Verify Your Style Setup

If you haven't done this yet, make sure these are complete:

1. **brain/Preferences/Style.md** describes how you communicate
2. **samples/** folder has at least 3 real emails you've sent

Test the result:
```
Draft a follow-up email to a client named Sarah about a proposal we sent last week. She hasn't responded yet.
```

Does the draft sound like you? If not, update Style.md and add more samples.

## Troubleshooting

- **Skill not recognized?** The file must be in `.claude/skills/` (not `skills/`). Start a new conversation after adding or editing skills.
- **Output doesn't look right?** Check that the skill file references the correct template in `templates/`
- **Email drafts don't sound like you?** Fill out Style.md and add writing samples

## Checklist

- [ ] /morning-briefing works and produces a structured report
- [ ] /evening-summary works and includes tomorrow's prep
- [ ] /draft-reply works and matches your writing style
- [ ] /prep-meeting works and generates meeting briefs with meeting links
- [ ] /tasks works and shows task overview
- [ ] /accountability works and detects promises
- [ ] /forgotten-emails works and finds missed threads in both directions
- [ ] /block-time works and suggests calendar slots
- [ ] /risks works and identifies business risks
- [ ] /weekly-report works with numbers and week-over-week comparison
- [ ] Customized at least one skill for your specific needs
- [ ] brain/Preferences/Style.md is filled out
- [ ] At least 3 writing samples in samples/

## What's Next

Tomorrow is the final day. Donna becomes autonomous. You'll set up Scheduled Tasks so she runs every morning and evening without you asking. You'll also complete the graduation checklist and see the full picture of everything you've built.

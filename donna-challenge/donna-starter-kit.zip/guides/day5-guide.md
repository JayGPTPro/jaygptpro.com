# Day 5: "She Works While You Sleep"

Today is the final day. Donna becomes autonomous. She'll run on her own every morning and evening, produce weekly reports, and hold you accountable.

## What You'll Do Today

1. Set up Scheduled Tasks (morning 7:00, evening 21:00)
2. Run /weekly-report and /accountability
3. See Graph View in Obsidian
4. Complete the Graduation Checklist

## What You'll Need

- Claude Desktop open in the Code tab
- All skills from Day 4 working
- 35 minutes

## How Scheduled Tasks Work

Scheduled Tasks live in the left sidebar of the Code tab, under **"Scheduled"**. They run automatically at set times.

One requirement: **Claude Desktop must be running.** It can be minimized or in the background, but not closed. If you shut down your computer, the task won't run until the next time Claude Desktop is open.

## Step 1: Set Up Morning Briefing (7:00 AM)

1. In the Code tab, click **"Scheduled"** in the left sidebar
2. Create a new scheduled task
3. Name: "Morning Briefing"
4. Schedule: Every day at 7:00 AM
5. Prompt:
```
Run /morning-briefing

After generating the briefing, save it to brain/Daily Logs/ with today's date as the filename (YYYY-MM-DD.md format).
```
6. Save and enable

## Step 2: Set Up Evening Summary (9:00 PM)

1. Create another scheduled task
2. Name: "Evening Summary"
3. Schedule: Every day at 9:00 PM
4. Prompt:
```
Run /evening-summary

After generating the summary, append it to today's Daily Log in brain/Daily Logs/ under a "## Evening Summary" heading.
```
5. Save and enable

## Step 3: Run /weekly-report

This skill produces a comprehensive weekly summary:
- Wins (what got done)
- Misses (what didn't)
- Numbers (tasks completed vs created, meetings count)
- Promise tracking
- Patterns and insights
- Next week's plan

```
/weekly-report
```

Review the output. This is the report you can set up to run every Sunday morning automatically.

**Optional: schedule it:**
1. Scheduled > New task
2. Name: "Weekly Report"
3. Schedule: Every Sunday at 9:00 AM
4. Prompt: `Run /weekly-report and save to brain/Daily Logs/[today's date]-weekly.md`

## Step 4: Run /accountability

This skill holds you accountable:
- Checks brain/Business/Promises.md for overdue commitments
- Reviews brain/Business/Goals.md for progress
- Flags tasks postponed too many times
- Gives you an honest assessment

```
/accountability
```

## Step 5: Graph View in Obsidian

Open Obsidian and click the graph icon in the left sidebar (or press Cmd+G on Mac, Ctrl+G on Windows).

This is Graph View. It shows how everything connects: people, decisions, goals, daily logs. Every [[wiki link]] Donna created between files becomes a visible connection.

The more Donna has worked this week, the richer the graph. You'll see clusters around key people, goals that connect to decisions, and daily logs that reference everything.

This is the visual map of everything Donna learned about your business in 5 days.

## Step 6: Graduation Checklist

Go through every item. Check each one as you verify it works.

### Identity
- [ ] my-business.md is filled with your business details
- [ ] brain/Business/Goals.md has current goals
- [ ] brain/Preferences/Style.md describes your communication style
- [ ] At least 3 writing samples in samples/

### Connections
- [ ] Gmail connected and working
- [ ] Google Calendar connected and working
- [ ] Google Drive connected and working
- [ ] Task manager connected (Asana, Monday, ClickUp, or Notion) or skipped intentionally

### Skills
- [ ] /morning-briefing works
- [ ] /draft-reply works
- [ ] /prep-meeting works
- [ ] /evening-summary works
- [ ] /forgotten-emails works
- [ ] /weekly-report works
- [ ] /accountability works
- [ ] At least one skill customized for your business

### Automation
- [ ] Morning Briefing scheduled at 7:00 AM
- [ ] Evening Summary scheduled at 9:00 PM
- [ ] Claude Desktop set to stay running for scheduled tasks

### Memory
- [ ] brain/Daily Logs/ has at least one entry
- [ ] brain/People/ has at least one contact profile
- [ ] Donna saves new information to brain/ when asked
- [ ] Graph View in Obsidian shows connections

When everything is checked, take a screenshot and share it in the WhatsApp group.

## What You Built

| What | Details |
|------|---------|
| **CLAUDE.md** | Donna knows your business, your style, your priorities |
| **4 Connectors** | Gmail, Calendar, Drive, Task Manager (Asana, Monday, ClickUp, or Notion) |
| **10 Skills** | Morning briefing, draft reply, meeting prep, tasks, accountability, forgotten emails, block time, risks, evening summary, weekly report |
| **4 Scheduled Tasks** | Morning briefing (7:00), prep meeting (18:00), evening summary (21:00), weekly report (Sunday 9:00) |
| **Memory System** | Daily Logs, People profiles, Goals, Promises, Decisions |

This is a working AI Chief of Staff. She costs $20/month. She works 24/7. She remembers everything.

## What's Next

Donna grows with you. Here's how to keep improving:

1. **Add more skills** as you discover repetitive tasks
2. **Update People profiles** as Donna encounters new contacts
3. **Review Weekly Reports** to spot patterns over time
4. **Update Goals and Promises** when priorities shift
5. **Add more writing samples** so Donna's drafts get closer to your voice
6. **Schedule the Weekly Report** for Sunday mornings if you haven't yet

Congratulations. You just hired your first AI employee.

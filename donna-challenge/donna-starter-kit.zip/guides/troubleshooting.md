# Troubleshooting Guide

Common problems and solutions. Check here before asking in the WhatsApp group.

---

## Installation Issues

### "I can't install Claude Desktop"
- **Mac:** Make sure you're running macOS 12 (Monterey) or later. Check: Apple menu > About This Mac.
- **Windows:** Make sure you're running Windows 10 or later. You need a 64-bit system.
- **Both:** Try downloading again from [claude.ai/download](https://claude.ai/download). If the download is corrupted, clear your browser cache and retry.

### "I don't see the Code tab"
- Make sure you're on the Pro plan. The Code tab is only available on paid plans.
- Try closing and reopening Claude Desktop.
- Check for updates: Claude Desktop > Check for Updates.

### "Claude Desktop won't open the folder"
- Make sure the folder path doesn't have special characters that cause issues
- Try moving the donna-starter-kit folder to your Desktop or Documents folder
- On Mac: you may need to grant Claude Desktop permission in System Settings > Privacy & Security > Files and Folders

---

## Connector Issues (Day 3)

### "I can't find the Connectors option"
- Make sure you're in the **Code** tab (not Chat or Cowork)
- Click the settings icon (gear) at the bottom of the sidebar
- Look for "Connectors" or "Integrations"

### "Gmail won't connect"
- Make sure you're signing in with the Gmail account you want Donna to read
- If you use Google Workspace (company email): your admin may need to allow third-party access
- Try disconnecting and reconnecting
- Make sure you're granting "read" permission when prompted

### "I don't use Gmail. I use Outlook / Yahoo / other"
- Gmail is the easiest setup. If you use another email provider, check if there's a connector available in the settings.
- If no connector exists for your email, you can still do most of the challenge. Skip the email-specific parts and focus on Calendar, Tasks, and Skills.
- Ask in the WhatsApp group for help with your specific email provider.

### "Calendar connector shows wrong calendar"
- Make sure you're connected to your primary Google account
- If you have multiple Google accounts, sign out of all and sign in with the correct one

### "Drive won't find my files"
- Google Drive search takes a moment. Wait 10-15 seconds.
- Make sure the files you're looking for are in your own Drive (not shared drives that may require separate access)

---

## Skills Issues (Day 4)

### "The skill doesn't work when I type /morning-briefing"
- Skills must be inside the `.claude/skills/` folder. This folder is hidden (starts with a dot), which is normal.
- To check on Mac: in Finder, press Cmd+Shift+. (period) to show hidden files. On Windows: in File Explorer, check "Hidden items" under the View tab.
- Verify the file exists at: `donna-starter-kit/.claude/skills/morning-briefing.md`
- Try: close the conversation and start a new one. Skills load at the start of a session.

### "The skill output doesn't match the template format"
- Open the skill file and check that it references the correct template path
- Make sure the templates/ folder has the matching template file
- Try adding to your skill: "Format your output exactly as shown in templates/[template-name].md"

### "Donna's email drafts don't sound like me"
- Fill out brain/Preferences/Style.md with specific details about your writing
- Add 3-5 real writing samples to the samples/ folder
- In the skill instructions, add: "Before drafting, read samples/ and brain/Preferences/Style.md to match the owner's voice"

---

## Routines Issues (Day 5)

> **Note:** "Routines" is the new name (April 2026) for what used to be called "Scheduled Tasks." Same feature, new name.

### "The routine didn't run at the scheduled time"
- **Most common cause: Claude Desktop was closed.** Routines run locally. If your laptop is off at the scheduled time, the routine queues and runs when Claude Desktop next opens.
- Check that the routine is enabled: go to **Routines** in the left sidebar of the Code tab
- If you opened Claude Desktop AFTER the scheduled time, the routine should have run automatically when you opened it. Check brain/Daily Logs/ for the output.

### "I close my laptop at night. How do routines work?"
- Close your laptop at night → no problem. The routine waits.
- Open Claude Desktop in the morning → the routine runs immediately.
- So you'll get your morning briefing as soon as you start your day, even if it's not exactly at 7:00 AM.
- **Power user tip:** Leave Claude Desktop running overnight with your laptop plugged in and set to not sleep, if you want the briefing to arrive precisely at 7:00 AM before you wake up.

### "The morning briefing ran but doesn't save to brain/Daily Logs/"
- Check that the brain/Daily Logs/ folder exists
- Make sure the routine prompt includes: "Save the output to brain/Daily Logs/[today's date].md"
- Check file permissions. On Mac: right-click the donna-starter-kit folder > Get Info > make sure your user has Read & Write access.

### "I see 'Scheduled' in old documentation but the sidebar says 'Routines'"
- Anthropic renamed "Scheduled Tasks" to "Routines" on April 14, 2026. Old guides may still say "Scheduled." It's the same feature - just look for "Routines" in the sidebar.

---

## Task Manager Issues (Day 3)

### "I don't use a task manager. What do I do?"
- Claude Desktop supports: Asana, Monday, ClickUp, and Notion. Go to Settings > Connectors and search for yours.
- **Strongly recommended** to set one up - 4 of the 12 skills (`/tasks`, `/accountability`, `/block-time`, parts of `/morning-briefing`) work much better with a task manager.
- Free options: Asana free, Notion free, ClickUp free, Monday 14-day trial
- If you really don't want one: 8 out of 12 skills still work fully. Donna will use `brain/Business/Promises.md` for tracking commitments and `brain/Daily Logs/` for notes.

### "Task manager connector doesn't show my tasks"
- Make sure you're connected to the correct workspace or account
- Try: "Donna, list all my tasks" to verify the connection works
- If you have multiple workspaces, you may need to specify which one

---

## Memory / brain/ Issues (Day 5)

### "Donna answered without reading brain/ (skipped the session start protocol)"
- The session start steps in CLAUDE.md are instructions the model reads, not code that executes. If a session opens with a direct question, Donna may jump straight to the task and never load the brain. It fails silently: no error, confident output, wrong or missing facts.
- The kit now ships a fix: `.claude/settings.json` contains a SessionStart hook that injects `.claude/donna-character.md`, `brain/Business/my-business.md`, `brain/Preferences/Style.md`, and the latest Daily Log into every new session automatically.
- If your copy of the kit predates this, create `.claude/settings.json` with that hook (ask Donna: "add the SessionStart hook from the current starter kit troubleshooting guide"), or copy the file from a fresh kit download.
- The hook is read-only and cannot fail: missing files are skipped silently and it always exits 0, so it is safe in scheduled Routines too.
- Quick test: open a new session and ask "what is my company structure?" If she answers correctly without asking you, the brain loaded.

### "Donna doesn't remember things from yesterday"
- Each new conversation starts fresh. Donna needs to READ the brain/ (Obsidian vault) folder to recall previous context.
- Make sure your CLAUDE.md includes the Memory section that tells Donna to check brain/ before answering
- Start your session with: "Read today's context from brain/Daily Logs/ and catch up"

### "brain/Daily Logs/ is empty"
- If you skipped Day 4 (scheduled tasks), the logs won't be auto-generated
- Run /morning-briefing manually and it will create the first log entry
- You can also create entries manually. Just create a file like `2026-04-20.md` with notes about your day

---

## Long Conversations and Memory

### "Donna seems to forget what I said earlier in our conversation"
- Claude has a context limit. In very long conversations (50+ messages), earlier messages get compressed or dropped.
- **Fix:** Start a new conversation when you switch topics. Each conversation starts fresh.
- Good habit: Begin each new session with "Read the latest from brain/Daily Logs/ and catch up."
- This is why brain/ exists. It's Donna's long-term memory that survives between conversations.

### "Donna doesn't know about yesterday's briefing"
- Each conversation starts fresh. Donna needs to READ brain/ to recall previous context.
- Make sure your CLAUDE.md includes the Memory section that tells Donna to check brain/ first.
- Start sessions with: "Check brain/Daily Logs/ for context before we begin."

## Obsidian Issues

### "Obsidian shows empty vault"
- Make sure you opened the `donna-starter-kit/` folder as the vault. You should see brain/, guides/, templates/, CLAUDE.md and more in the sidebar.

### "Files not updating"
- Claude writes .md files directly to the brain/ (Obsidian vault) folder. Obsidian auto-refreshes when it detects changes. If it doesn't update, click a different file and back.

### "Graph View is empty"
- Graph View shows connections created by [[wiki links]] between files. These appear after Day 3+ when Donna starts cross-referencing people, goals, decisions, and daily logs. Before that, it's normal for the graph to be sparse.

---

## General Tips

- **When in doubt, start a new conversation.** Sometimes a fresh session fixes quirks.
- **Copy-paste error messages** into the WhatsApp group. Screenshots help too.
- **Check the file paths.** Most issues come from files being in the wrong folder.
- **Don't panic.** Everything can be fixed. Nothing is permanent. Donna never sends, deletes, or changes anything without your approval.
- **Never delete the Standing Instructions** in your CLAUDE.md. Those rules keep Donna safe (no sending, no deleting).

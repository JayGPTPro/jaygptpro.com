# Day 2: "Donna, Meet My Business"

Today you teach Donna who you are. By the end, she'll know your business, your goals, your communication style, and she'll prove it by generating a Business One-Pager.

## What You'll Do Today

1. Fill out about-me.md (if not done as homework)
2. Run the 4 onboarding prompts from prompts/
3. Add writing samples to samples/
4. Teach Donna to remember things (brain/)
5. Generate a Business One-Pager (wow moment)

## What You'll Need

- Claude Desktop open in the Code tab
- The donna-starter-kit folder loaded
- 30 minutes

## Step 1: Fill Out about-me.md (10 min)

Open `brain/Business/about-me.md` in Obsidian (or any text editor). This is the one file YOU fill out. Answer every question honestly and specifically.

**Good:** "I run a wholesale real estate company in Dallas. We buy distressed properties and sell to investors."
**Too vague:** "I'm in real estate."

The file has 6 parts: who you are, your business, key people, current priorities, communication style, and writing samples. Fill in everything you can.

If you already filled this out as Day 1 homework, just review it quickly and make sure nothing is missing.

## Step 2: Run the Onboarding Prompts (10 min)

Open the `prompts/` folder. There are 4 prompts, numbered in order. Copy each one into Claude Desktop and run it.

### Prompt 1: Learn About Me (prompts/01-learn-about-me.md)

This is the most important one. Donna reads your about-me.md and generates `brain/Business/my-business.md`, `Goals.md`, and `Style.md` automatically.

Copy the prompt, paste it into Claude Desktop, and run it. Donna will read everything you wrote in about-me.md and create structured files from your answers.

### Prompt 2: Set Up People (prompts/02-setup-people.md)

Donna creates individual profiles in `brain/People/` for each person you listed in about-me.md.

### Prompt 3: Writing Style (prompts/03-writing-style.md)

Donna analyzes your writing samples (from about-me.md or from the samples/ folder) and refines `brain/Preferences/Style.md`.

### Prompt 4: First Test (prompts/04-first-test.md)

Donna proves she knows you by answering questions about your business and generating a Business One-Pager.

## Step 3: Add Writing Samples (5 min)

If you didn't paste writing samples into about-me.md, open the `samples/` folder and add 3-5 real writing samples:

1. Copy real emails you've sent (ones you're proud of)
2. Paste them into files like `email-example-1.md`, `email-example-2.md`
3. Don't edit them. Donna needs your real voice, not a polished version.

The combination of Style.md + real samples is what makes Donna sound like you instead of a generic AI.

## Step 4: Teach Donna to Remember Things

Donna's memory lives in the brain/ (Obsidian vault) folder. When you tell her something important, she should save it there.

Try this:
```
Remember this: My supplier Mike always takes 3-5 days to respond. If he hasn't replied in a week, follow up aggressively. Save this to brain/People/.
```

Check Obsidian. You should see a new file in brain/People/ with that information.

Try one more:
```
Save this decision to brain/Business/Decisions.md: We decided to pause Facebook ads until Q3 and focus budget on Amazon PPC instead.
```

This is how Donna builds long-term memory. Every fact, decision, and preference gets stored and connected.

## Step 5: The Wow Moment. Business One-Pager

If you ran Prompt 4, you already have this. If not, test everything now:

```
Based on everything you know about me and my business, generate a one-page business summary. Include: who I am, what I sell, who my customers are, my current priorities, key people, and my goals for this quarter. Format it professionally.
```

Read the output. If it's accurate and sounds like it was written by someone who actually knows your business, the onboarding worked. If anything is off, update about-me.md and re-run the relevant prompt.

## Checklist

- [ ] brain/Business/about-me.md is filled out with your real details
- [ ] Ran all 4 prompts from prompts/ folder
- [ ] brain/Business/my-business.md exists and is accurate
- [ ] brain/Business/Goals.md has your current goals
- [ ] brain/Preferences/Style.md describes your communication style
- [ ] At least 3 writing samples (in about-me.md or samples/ folder)
- [ ] Donna can save new information to brain/ when asked
- [ ] Business One-Pager is accurate and useful

## What's Next

Tomorrow, Donna gets her badge. You'll connect Gmail, Calendar, Drive, and your task manager so she can see your real emails, meetings, and tasks. She goes from knowing about your business to seeing what's actually happening in it.

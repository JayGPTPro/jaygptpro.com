# Graduation Checklist — Day 5

Congratulations on completing the challenge! Go through this checklist to make sure everything is working. Check each item as you verify it.

---

## Foundation (Day 0-1)

- [ ] Claude Desktop is installed and running on the Code tab
- [ ] brain/Business/my-business.md is filled (via prompts)
- [ ] Donna knows your name, business, and priorities (ask her: "What do you know about me?")
- [ ] brain/Business/Goals.md has your current goals

## Connections (Day 2)

- [ ] Gmail is connected (test: "Show me my recent emails")
- [ ] Google Calendar is connected (test: "What's on my calendar today?")
- [ ] Google Drive is connected (test: "Search my Drive for [something]")

## Skills (Day 3-4)

- [ ] /morning-briefing works and produces a structured report with risks
- [ ] /evening-summary works and includes tomorrow's meeting prep
- [ ] /draft-reply works and matches your writing style
- [ ] /prep-meeting works and includes meeting links
- [ ] /tasks works and shows task overview with smart alerts
- [ ] /accountability works and detects promises from emails
- [ ] /forgotten-emails works and finds missed threads in both directions
- [ ] /block-time works and suggests calendar slots for postponed tasks
- [ ] /risks works and identifies business risks
- [ ] /weekly-report works with numbers and week-over-week comparison

## Automation (Day 4-5)

- [ ] Task manager connected (Asana, Monday, ClickUp, or Notion) or skipped intentionally
- [ ] Morning briefing scheduled task is set up (7:00 AM or your preferred time)
- [ ] Evening summary scheduled task is set up (9:00 PM or your preferred time)
- [ ] Prep-meeting auto-runs at 6:00 PM for tomorrow's meetings
- [ ] Weekly report scheduled for Sunday 9:00 AM
- [ ] brain/Daily Logs/ has at least one auto-generated entry

## Intelligence (Day 5)

- [ ] Donna can answer questions using context from brain/ (test: ask about something from a previous day)
- [ ] brain/Preferences/Style.md is filled out with your communication style

## Overall System Check

- [ ] Run /morning-briefing and read the full output. Does it cover emails, calendar, tasks, and priorities?
- [ ] Ask Donna: "What did I promise people this week?" Does she check brain/Business/Promises.md?
- [ ] Ask Donna: "Prep me for my next meeting." Does she pull data from Gmail, Calendar, and brain/People/?
- [ ] Check brain/Daily Logs/. Do you have entries from multiple days?

---

## What You Built

By completing this challenge, you now have:

| Component | What It Does |
|-----------|-------------|
| **CLAUDE.md** | Donna's identity, your business context, standing instructions |
| **10 Skills** | Morning briefing, evening summary, draft reply, meeting prep, tasks, accountability, forgotten emails, block time, risks, weekly report |
| **4 Scheduled Tasks** | Morning briefing (7AM), evening summary (9PM), meeting prep (6PM), weekly report (Sunday 9AM) |
| **4 Connectors** | Gmail, Calendar, Drive, Task Manager (Asana, Monday, ClickUp, or Notion) |
| **brain/ Memory System** | Daily Logs, People profiles, Goals, Promises, Decisions, Style preferences |

## What's Next?

You've built the foundation. Donna can grow from here:

- **Add more skills** as you discover repetitive tasks in your workflow
- **Add more people** to brain/People/ as Donna meets them in your emails
- **Update Goals and Promises** regularly to keep Donna aligned with your priorities
- **Add writing samples** to samples/ so Donna matches your voice better over time
- **Review brain/Daily Logs/** weekly to see patterns in your work

---

_Take a screenshot of this checklist with everything checked. Share it in the WhatsApp group!_

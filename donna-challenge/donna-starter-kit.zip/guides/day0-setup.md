# Day 0: "Meet Claude Code"

Today you install everything and learn the basics. By the end, you'll have Claude Desktop running, Obsidian ready, and your Starter Kit loaded.

## What You'll Do Today

1. Install Claude Desktop and subscribe to the Pro plan ($20/month)
2. Install Obsidian (free)
3. Download the Donna Starter Kit
4. Learn the 3 modes of Claude Desktop
5. Learn the basics of prompting

## Step 1: Install Claude Desktop

1. Go to [claude.ai/download](https://claude.ai/download)
2. Download for your computer (Mac or Windows)
3. Install it like any other app
4. Open Claude Desktop

## Step 2: Subscribe to the Pro Plan

1. Open Claude Desktop
2. Click your profile icon (bottom left)
3. Click "Upgrade to Pro"
4. Choose the **$20/month Pro plan**
5. Enter payment details

**Why Pro?** The free plan has limited usage and no access to the Code tab. Pro gives you the Code tab, Skills, Scheduled Tasks, and Connectors. This is the ONLY cost for the entire challenge. Donna runs on this $20/month.

## Step 3: Install Obsidian

Obsidian is a free app that turns Donna's brain/ folder into a visual knowledge base. Donna writes markdown files. Obsidian makes them beautiful and connected.

1. Go to [obsidian.md](https://obsidian.md) and download (free)
2. Install it like any other app
3. Open Obsidian, click **"Open folder as vault"**
4. Select your entire `donna-starter-kit` folder
5. You should see: **brain/** (with Business, Daily Logs, People, Preferences), **guides/**, **templates/**, **samples/**, **CLAUDE.md**, **README.md**

That's it. Obsidian shows all your files visually. The brain/ folder is where Donna stores her memory. The rest is guides and templates you'll use during the challenge.

## Step 4: Download the Starter Kit

1. Download the `donna-starter-kit` folder from the link provided
2. Put it somewhere easy to find (Desktop or Documents)
3. In Claude Desktop, switch to the **Code** tab (top center)
4. Open the folder: File > Open Folder, or drag the folder into Claude Desktop
5. Verify: type "What files do you see in this folder?" Claude should list everything.

## Step 5: Understand the Three Modes

Claude Desktop has three tabs at the top:

| Mode | What It Does | When to Use |
|------|-------------|-------------|
| **Chat** | Simple conversation | Quick questions, brainstorming |
| **Cowork** | Collaborative work with file access | Writing, editing, research |
| **Code** | Full power: files, tools, skills, automation | **This is where we build Donna** |

**For this challenge, we use the Code tab.** This is where Skills, Scheduled Tasks, and Connectors work.

The left sidebar in the Code tab shows: **New session, Search, Scheduled, Dispatch, Customize**. You'll use these throughout the challenge.

## Step 6: Prompting Basics

Claude responds to what you type. Here are a few things to try in the Code tab:

**Ask a question:**
```
What day is it today?
```

**Give a task:**
```
Write me a short email to a supplier asking about shipping status
```

**Ask for a calculation:**
```
What's 15% margin on a product that costs $12 and sells for $29?
```

**Build something:**
```
Build me a simple HTML profit calculator. I want to enter my product cost and selling price, and it shows my margin and profit per unit.
```

Watch Claude build it. Open the file. Play with it. This is what "zero code" looks like.

**Key prompting tips:**
- Be specific. "Write a follow-up email to Mike about the Q2 order" beats "Write an email."
- Give context. The more Claude knows, the better the output.
- Iterate. If the first result isn't right, say what to fix. Don't start over.

## Checklist

- [ ] Claude Desktop is installed and opens
- [ ] You're on the Pro plan ($20/month)
- [ ] Obsidian is installed and donna-starter-kit is open as a vault
- [ ] The donna-starter-kit folder is open in Claude Desktop's Code tab
- [ ] Claude can see the files in the folder
- [ ] You tried at least 3 prompts and got useful responses

**All good? You're ready for Day 1.**

## Common Issues

If something doesn't work, check [troubleshooting.md](troubleshooting.md).

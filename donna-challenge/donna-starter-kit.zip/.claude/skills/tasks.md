---
name: tasks
description: View, create, and manage tasks with context and smart alerts
---

# /tasks

## What This Skill Does

Shows your task overview, creates new tasks, updates status, and alerts on stuck items. Connects tasks to the people and conversations they came from.

## Steps

1. **Pull current tasks.** Read from the connected task manager (Asana, Monday, ClickUp, or Notion). If no task manager is connected, check brain/Daily Logs/ and brain/Business/Promises.md for tracked items instead.
   - Group as: OVERDUE / DUE TODAY / THIS WEEK / LATER

2. **Enrich with context.** For each task:
   - Check brain/People/ for related person context
   - Check brain/Daily Logs/ for when/why the task was created
   - Note if it was created from an email, meeting, or conversation

3. **Flag problems:**
   - Tasks overdue by 3+ days: flag with exact days late
   - Tasks overdue by 10+ days: strong warning ("this has been sitting for 10 days")
   - Tasks postponed 3+ times: "Decision needed: do it, delegate it, or drop it"

4. **If creating a new task** (when the user says "remind me to..." or "add task:"):
   - Create it in the connected task manager with title, due date, and context. If no task manager is connected, log it in brain/Business/Promises.md.
   - Save a note in brain/Daily Logs/ linking the task to its origin
   - Confirm creation

5. **If updating a task** (when the user says "done with X" or "push X to Friday"):
   - Update the task in the connected task manager
   - If it was a promise to someone, update brain/Business/Promises.md too

## Output Format

```
## Tasks — [DATE]

### Overdue
- [TASK] — due [DATE] — [X] days late
  Context: [where this came from]

### Due Today
- [TASK] — [brief context]

### This Week
- [TASK] — due [DATE]

### Stuck (postponed 3+ times)
- [TASK] — postponed [X] times. Do it, delegate it, or drop it.

---
**Quick stats:** [X] overdue / [Y] due today / [Z] total open
```

## Obsidian Links

When referencing people, goals, decisions, or promises, use [[wiki links]] (e.g., [[Person Name]], [[Goals]]). This creates clickable connections in Obsidian.

## Rules

- Always show overdue items first, no exceptions
- When creating tasks, always ask for a due date if not provided
- Link tasks to people and conversations when possible
- After changes, confirm what was created or updated
- Don't overwhelm. If 20+ tasks, show overdue + today + this week, and summarize the rest as a count

## Self-Check (before delivering)

Before presenting this output, verify:
- [ ] Format matches the template (headers, sections, structure)
- [ ] Numbers are accurate (days overdue, task counts, email counts)
- [ ] No vague statements. Every claim has a specific number or name.
- [ ] Output is under the word limit
- [ ] [[Wiki links]] are used for people, goals, decisions, promises
- [ ] At least one Donna personality line is included

If any check fails, fix it before showing the output.

## Donna Personality Reminder

This output MUST include at least one Donna-style line. Check the Donna Flavor section in CLAUDE.md. Open with personality or close with personality. Never deliver a dry report without Donna's voice.

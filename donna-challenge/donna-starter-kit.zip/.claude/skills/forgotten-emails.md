---
name: forgotten-emails
description: Find emails you forgot to answer and promises you haven't kept
---

# /forgotten-emails

## What This Skill Does

Scans your email and commitments to find things that fell through the cracks. Drafts follow-up messages.

## Steps

1. **Emails YOU forgot to answer.**
   Search Gmail inbox (last 14 days) for:
   - Emails where someone asked you a direct question and you never replied
   - Emails requiring action that you haven't acknowledged
   - Skip automated emails, newsletters, and system notifications

   For each forgotten email:
   - Show: sender, subject, date, how many days without reply
   - Suggest: respond, delegate, or ignore
   - If "respond": draft a short reply. For 3-5 day gaps, use a casual "circling back" tone. For 7+ days, use "making sure this didn't get lost."
   - Flag urgency: if the email mentions money, deadlines, or contracts, mark it: "This is about money. Don't leave it."

2. **Emails OTHERS forgot to answer you.**
   Search Gmail sent folder (last 14 days) for:
   - Threads where you sent the last message 3+ days ago with no reply

   For each:
   - Show: recipient, subject, date sent, days waiting
   - Draft a gentle follow-up message
   - Flag urgency: if the original thread involves money, a deadline, or a contract, mark it: "This is about money. Follow up now."

3. **Broken promises.**
   Check brain/Business/Promises.md for:
   - Promises that are overdue
   - Promises due within 3 days

   For each:
   - Show: who you promised, what, when it was due
   - Suggest: deliver now, ask for extension, or renegotiate

## Output Format

```
## Forgotten Emails Check — [DATE]

### You Forgot to Answer
- [SENDER] — [SUBJECT] — [DAYS] days ago — Suggested action: [respond/delegate/ignore]
  > Draft: "[first line of suggested reply]"

### Waiting for Their Reply
- [RECIPIENT] — [SUBJECT] — sent [DAYS] days ago
  > Follow-up draft: "[first line]"

### Promises at Risk
- Promised [PERSON] to [WHAT] by [DATE] — [X days overdue / due in X days]
  > Suggested action: [deliver / extend / renegotiate]
```

## Obsidian Links

When referencing people, goals, decisions, or promises, use [[wiki links]] (e.g., [[Carlos Mendez]], [[Goals]], [[Decisions]], [[Promises]]). This creates clickable connections in Obsidian.

## Rules

- Never send follow-ups without approval. Draft only.
- Don't nag about routine threads (newsletters, bulk emails, automated)
- Be honest about overdue promises. Don't soften the message.
- Check brain/Preferences/Style.md for the right tone in follow-up drafts

## Self-Check (before delivering)

Before presenting this output, verify:
- [ ] Format matches the template (headers, sections, structure)
- [ ] Numbers are accurate (days overdue, task counts, email counts)
- [ ] No vague statements. Every claim has a specific number or name.
- [ ] Output is under the word limit
- [ ] [[Wiki links]] are used for people, goals, decisions, promises
- [ ] At least one Donna personality line is included

If any check fails, fix it before showing the output.

## Donna Personality Reminder

This output MUST include at least one Donna-style line. Check the Donna Flavor section in CLAUDE.md. Open with personality or close with personality. Never deliver a dry report without Donna's voice.

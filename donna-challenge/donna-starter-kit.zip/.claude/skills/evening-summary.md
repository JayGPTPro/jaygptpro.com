---
name: evening-summary
description: Generate an end-of-day summary with completed tasks, open items, and tomorrow's plan
---

# /evening-summary

## What This Skill Does

Reviews your day and produces a structured evening wrap-up. Shows what got done, what didn't, and sets up tomorrow's priorities.

## Steps

1. **Read context.** Check brain/Daily Logs/ for today's morning briefing and any updates.

2. **Tasks completed.** Pull tasks marked as done today from the connected task manager (if available). If no task manager is connected, check brain/Daily Logs/ for completed items instead.
   - List each completed task
   - Note any significant wins or milestones

3. **Tasks not completed.** Pull tasks that were due today but not finished from the connected task manager (if available).
   - Be direct. List each one.
   - If something was due and not done, say so clearly.
   - If a task was postponed again, say so: "This is the 3rd day this was postponed. Decision needed."

4. **New emails since morning.** Check Gmail for emails received since the morning briefing.
   - List any that still need a response (not yet handled)
   - Flag emails that came in during the day and were ignored
   - Draft replies for urgent ones (never send)

5. **Tomorrow's calendar.** Pull tomorrow's events from Google Calendar.
   - List meetings with time and 1-line context
   - Flag anything that needs prep
   - If tomorrow has meetings with people in brain/People/, automatically trigger /prep-meeting for each one and include brief notes

6. **Tomorrow's plan.** Based on everything above:
   - List top 3 priorities for tomorrow
   - Include "why" for each priority

## Output Format

```
## Evening Summary, [DATE]

### Done Today
- [TASK] (completed)
- [TASK] (completed)

### Not Done (was due today)
- [TASK], reason: [if known]

### New Emails Since Morning
- [SENDER] about [TOPIC], action: [respond/wait/none]

### Tomorrow
**Calendar:**
- [TIME] [MEETING] [context]

**Top 3 Priorities:**
1. [PRIORITY], why: [REASON]
2. [PRIORITY], why: [REASON]
3. [PRIORITY], why: [REASON]

[One short closing line.]
```

## After Running

1. Append this summary to today's entry in brain/Daily Logs/[YYYY-MM-DD].md under a "## Evening Summary" heading.

2. **Run /learn automatically.** After saving the evening summary, run the learning loop:
   - Review today's interactions for corrections, feedback, and new patterns
   - Update brain/Learning/learning-log.md with what was learned
   - Update relevant brain/ files if needed (Style.md, People/, etc.)
   - Keep the learning update brief (3-5 bullet points max)
   - Append a short "### What I Learned Today" section at the end of the evening summary

## Obsidian Links

When referencing people, goals, decisions, or promises, use [[wiki links]] (e.g., [[Carlos Mendez]], [[Goals]], [[Decisions]]). This creates clickable connections in Obsidian.

## Rules

- Keep it under 300 words
- Be direct about what didn't get done
- Don't repeat the full morning briefing. Focus on what changed during the day.
- If no tasks were due today, say: "No tasks were due today."

## Self-Check (before delivering)

Before presenting this output, verify:
- [ ] Format matches the template (headers, sections, structure)
- [ ] Numbers are accurate (days overdue, task counts, email counts)
- [ ] No vague statements. Every claim has a specific number or name.
- [ ] Output is under the word limit
- [ ] [[Wiki links]] are used for people, goals, decisions, promises
- [ ] At least one Donna personality line is included

If any check fails, fix it before showing the output.

## Donna Personality Reminder

This output MUST include at least one Donna-style line. Check the Donna Flavor section in CLAUDE.md. Open with personality or close with personality. Never deliver a dry report without Donna's voice.

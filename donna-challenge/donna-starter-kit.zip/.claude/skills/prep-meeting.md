---
name: prep-meeting
description: Research a person and build a complete meeting brief
---

# /prep-meeting [name or meeting title]

## What This Skill Does

Researches a person or upcoming meeting and generates a structured brief with history, open items, and suggested agenda.

## Steps

1. **Identify the meeting.** If a name is provided, search Google Calendar for the next meeting with that person. If a meeting title is provided, find it directly.

2. **Research the person.**
   - Check brain/People/ for an existing profile
   - Search Gmail for email history with this person (last 30 days)
   - Search Google Calendar for previous meetings
   - Search Google Drive for shared documents and relevant files (proposals, contracts, notes)

3. **Get the meeting link.** From the calendar event:
   - Extract the Zoom, Google Meet, or Teams link
   - Include it at the top of the brief, ready to click

4. **Build the brief** using the template:
   - **Who:** 1-2 sentence description of this person/company
   - **Last Interaction:** Date + what was discussed + what was agreed
   - **Open Items:** Anything unresolved between you (either direction)
   - **What They Probably Want:** 2-3 best guesses based on context
   - **Your Agenda:** The #1 thing you should accomplish in this meeting
   - **Watch Out For:** Sensitive topics, overdue promises, tricky dynamics

5. **Update records.** Create or update brain/People/[person-name].md with the latest information.

## Output Format

Use the template from templates/meeting-brief.md

## Special Cases

- **First meeting (no history):** Say "First meeting. No prior history found." Research the person/company online if possible. Focus the brief on what YOU want from this meeting.
- **Group meeting:** List all attendees. Brief on the main contact or organizer.
- **Recurring meeting:** Focus on what changed since the last one. Check brain/Daily Logs/ for notes from previous occurrences.

## Obsidian Links

When referencing people, goals, decisions, or promises, use [[wiki links]] (e.g., [[Carlos Mendez]], [[Goals]], [[Decisions]]). This creates clickable connections in Obsidian.

## Automatic Mode

This skill can run automatically every evening at 6:00 PM. When scheduled:
- Check tomorrow's calendar for meetings
- Run /prep-meeting for each meeting that has attendees
- Save all briefs to brain/Daily Logs/

## Rules

- Don't fabricate history. If you can't find interactions, say so.
- Keep the brief scannable. No long paragraphs.
- Always include at least one item under "Your Agenda." If unsure, suggest: "Clarify next steps and timeline."
- Always include the meeting link (Zoom/Meet/Teams) at the top of the brief if available.

## Self-Check (before delivering)

Before presenting this output, verify:
- [ ] The right email/meeting/task was found (confirm with user if ambiguous)
- [ ] Context from brain/ files was checked (People, Promises, Style)
- [ ] Output matches the owner's style (check Style.md)
- [ ] No commitments are made without flagging them
- [ ] [[Wiki links]] are used for people, goals, decisions, promises
- [ ] At least one Donna personality line is included

If any check fails, fix it before showing the output.

## Donna Personality Reminder

This output MUST include at least one Donna-style line. Check the Donna Flavor section in CLAUDE.md. Open with personality or close with personality. Never deliver a dry report without Donna's voice.

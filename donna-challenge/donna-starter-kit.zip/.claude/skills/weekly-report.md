---
name: weekly-report
description: Generate a comprehensive weekly summary with wins, misses, patterns, and next week plan
---

# /weekly-report

## What This Skill Does

Analyzes your past week across emails, calendar, and tasks. Produces a structured report with honest assessment, patterns, and priorities for next week.

## Steps

1. **Read context.** Check brain/Daily Logs/ for the past 7 days of entries.

2. **Wins.** Pull completed tasks from the connected task manager (if available). If no task manager is connected, review brain/Daily Logs/ for completed items.
   - List the most significant accomplishments
   - Note any milestones reached or goals advanced

3. **Misses.** Pull tasks that were due this week but not completed.
   - Be direct. List each one with its due date.
   - If a task has been postponed 3+ times, call it out specifically.

4. **By the Numbers.** Calculate:
   - Tasks completed vs. created this week
   - Tasks currently overdue
   - Total meetings this week
   - Emails flagged as urgent

5. **Promises check.** Read brain/Business/Promises.md.
   - List promises kept this week
   - Flag promises that are overdue or due next week

6. **Patterns.** Analyze calendar and task data:
   - Meeting load (too many? productive?)
   - Task completion rate
   - Time-of-day patterns
   - Anything recurring that could be automated or eliminated
   - Provide 2-3 specific, actionable insights

7. **Week-over-week comparison.** Check brain/Daily Logs/ for the previous weekly report:
   - Compare tasks completed this week vs. last week
   - Compare overdue count this week vs. last week
   - Note trends: "Improving", "Steady", or "Slipping"

8. **Next week.** Pull meetings from Google Calendar for the upcoming week.
   - List each with day, time, and 1-line context
   - Flag overloaded days
   - Suggest top 3 priorities with reasoning

9. **Open risks.** Run /risks logic and include results:
   - Deadline clusters
   - Unanswered threads getting old
   - Overcommitment
   - Financial or relationship risks
   - Include the risk count: [X] high / [Y] medium / [Z] low

10. **What Donna learned this week.** Review brain/Learning/learning-log.md for this week's entries:
   - Summarize 2-3 key lessons (style preferences, new patterns, corrections)
   - Note any patterns promoted to permanent files
   - Flag if nothing was learned ("No new patterns this week. Consider running /learn more often.")
   - This section closes the loop and shows the system is growing

## Output Format

Use the template from templates/weekly-report.md

## After Running

Save to: brain/Daily Logs/[YYYY-MM-DD]-weekly.md

## Obsidian Links

When referencing people, goals, decisions, or promises, use [[wiki links]] (e.g., [[Carlos Mendez]], [[Goals]], [[Decisions]], [[Promises]]). This creates clickable connections in Obsidian.

## Rules

- Keep total report under 500 words
- Be direct about what didn't get done. No sugarcoating.
- Patterns should be data-backed, not vague ("You had 14 meetings" not "You had a lot of meetings")
- Priorities must be specific and actionable
- Check brain/Business/Goals.md to frame priorities against current goals

## Self-Check (before delivering)

Before presenting this output, verify:
- [ ] Format matches the template (headers, sections, structure)
- [ ] Numbers are accurate (days overdue, task counts, email counts)
- [ ] No vague statements. Every claim has a specific number or name.
- [ ] Output is under the word limit
- [ ] [[Wiki links]] are used for people, goals, decisions, promises
- [ ] At least one Donna personality line is included

If any check fails, fix it before showing the output.

## Donna Personality Reminder

This output MUST include at least one Donna-style line. Check the Donna Flavor section in CLAUDE.md. Open with personality or close with personality. Never deliver a dry report without Donna's voice.

---
name: learn
description: Close the Loop. Donna reviews what worked, what didn't, and updates her memory for next time.
---

# /learn

## What This Skill Does

Reviews recent interactions, outputs, and feedback. Updates Donna's memory so she improves over time. This is "The Loop", what turns Donna from an executor into a learner.

Run this at the end of a productive session, after a big task, or as part of the evening summary.

## Steps

1. **Review recent work.** Look at:
   - Today's brain/Daily Logs/ entries (morning briefing, evening summary)
   - Any skills that were run in this session
   - Any feedback the owner gave ("that was great", "too long", "wrong tone", "perfect")
   - Any corrections made to drafts, reports, or suggestions

2. **Extract lessons.** For each interaction, identify:
   - **What worked:** Style that was approved, format that landed, decisions that stuck
   - **What didn't work:** Corrections, pushback, "try again" moments
   - **New preferences discovered:** "Keep it shorter", "Always CC this person", "Never schedule before 10am"
   - **New people or context learned:** Names, relationships, preferences from conversations

3. **Update learning-log.md.** Append to brain/Learning/learning-log.md:
   ```
   ## [DATE]
   ### What Worked
   - [Specific thing that was approved or praised]

   ### What Didn't Work
   - [Specific correction or pushback]

   ### New Patterns
   - [Any new preference, style note, or insight]

   ### Updated Files
   - [List of brain/ files that were modified]
   ```

4. **Update relevant brain files.** Based on lessons learned:
   - Style preferences -> brain/Preferences/Style.md
   - People info -> brain/People/[name].md
   - Business decisions -> brain/Business/Decisions.md
   - Goal updates -> brain/Business/Goals.md
   - Promise changes -> brain/Business/Promises.md

5. **Pattern promotion.** If a pattern appears 3+ times in learning-log.md:
   - Promote it to the relevant permanent file (Style.md, CLAUDE.md standing instructions, etc.)
   - Note in learning-log.md: "Promoted to [file]: [pattern]"

6. **Summary.** Tell the owner what was learned:
   ```
   Updated [X] files based on today's session.
   Key takeaway: [one sentence about the most important thing learned]
   ```

## Output Format

```
## Learning Update, [DATE]

### What I Learned Today
- [LESSON 1]: [Brief description]
- [LESSON 2]: [Brief description]

### Files Updated
- brain/Preferences/Style.md: [what changed]
- brain/People/[Name].md: [what was added]
- brain/Learning/learning-log.md: [entry added]

### Patterns Building Up
- [PATTERN] (seen [X] times, [Y] more until promoted)

[One Donna closing line]
```

## Automatic Mode

This skill runs automatically as the last step of /evening-summary. It can also be triggered manually anytime with `/learn`.

When running automatically in evening-summary:
- Keep it brief (3-5 bullet points max)
- Only update files if there's something meaningful to record
- Skip if nothing notable happened today

## Obsidian Links

When referencing people, goals, decisions, or promises, use [[wiki links]] (e.g., [[Carlos Mendez]], [[Goals]], [[Style]]). This creates clickable connections in Obsidian.

## Rules

- Never delete existing entries in learning-log.md. Always append.
- Be specific. "Owner prefers bullet points over paragraphs" is better than "Owner likes concise writing."
- Don't invent lessons. Only record things that actually happened.
- If nothing notable happened, say so: "Nothing new to learn today. Previous patterns hold."
- Maximum 3 file updates per session (don't over-edit)

## Self-Check (before delivering)

Before presenting this output, verify:
- [ ] Format matches the template (headers, sections, structure)
- [ ] Numbers are accurate (days overdue, task counts, email counts)
- [ ] No vague statements. Every claim has a specific number or name.
- [ ] Output is under the word limit
- [ ] [[Wiki links]] are used for people, goals, decisions, promises
- [ ] At least one Donna personality line is included

If any check fails, fix it before showing the output.

## Donna Personality Reminder

This output MUST include at least one Donna-style line. Check the Donna Flavor section in CLAUDE.md. Open with personality or close with personality. Never deliver a dry report without Donna's voice.

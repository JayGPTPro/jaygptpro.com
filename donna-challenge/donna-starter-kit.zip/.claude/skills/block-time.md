---
name: block-time
description: Block calendar time for tasks that keep getting postponed
---

# /block-time [task description]

## What This Skill Does

When a task keeps getting postponed, Donna finds a free slot in your calendar and blocks dedicated time for it. Works together with task tracking and accountability.

## Steps

1. **Identify the task.** If a specific task was mentioned, use it. If not, check for:
   - Tasks postponed 3+ times (from the connected task manager or brain/Daily Logs/)
   - Overdue promises (from brain/Business/Promises.md)
   - Suggest the most critical one

2. **Estimate time needed.** Based on the task:
   - Simple email or message: 30 minutes
   - Document, proposal, or report: 1-2 hours
   - Complex work (strategy, analysis): 2-3 hours
   - Ask the owner if unsure

3. **Find a free slot.** Check Google Calendar:
   - Look for the next available block that fits
   - Prefer morning hours for deep work (before noon)
   - Avoid back-to-back with other meetings (leave 15 min buffer)
   - Don't suggest weekends unless the owner works weekends

4. **Propose the block.** Show:
   - The task
   - The proposed time slot
   - Why this slot (e.g., "Tomorrow morning is clear between 9 and 12")
   - How many times the task has been postponed

5. **Wait for approval.** Do NOT create the calendar event until the owner says yes.

6. **Create the event.** Once approved:
   - Create a calendar event with the task as the title
   - Add a description: "Blocked by Donna. Task: [description]. Postponed [X] times."
   - Update the task in the connected task manager with the scheduled time (if available)

## Output Format

```
## Time Block Suggestion

**Task:** [TASK DESCRIPTION]
**Postponed:** [X] times since [FIRST DATE]
**Estimated time:** [DURATION]
**Suggested slot:** [DAY], [TIME] - [TIME]

**Why this slot:** [1 line explanation]

Ready to block it? Say "yes" and I'll put it in your calendar.
```

## Obsidian Links

When referencing people, goals, decisions, or promises, use [[wiki links]] (e.g., [[Person Name]], [[Goals]]). This creates clickable connections in Obsidian.

## Rules

- NEVER create a calendar event without explicit approval
- Always explain why you're suggesting this (how many times postponed)
- If the calendar is packed, say so honestly and suggest alternatives
- This skill can be triggered automatically when Donna notices a task postponed 3+ times during morning/evening briefings
- Keep the tone direct: "This has been sitting for a week. Let's put it in the calendar."

## Self-Check (before delivering)

Before presenting this output, verify:
- [ ] The right email/meeting/task was found (confirm with user if ambiguous)
- [ ] Context from brain/ files was checked (People, Promises, Style)
- [ ] Output matches the owner's style (check Style.md)
- [ ] No commitments are made without flagging them
- [ ] [[Wiki links]] are used for people, goals, decisions, promises
- [ ] At least one Donna personality line is included

If any check fails, fix it before showing the output.

## Donna Personality Reminder

This output MUST include at least one Donna-style line. Check the Donna Flavor section in CLAUDE.md. Open with personality or close with personality. Never deliver a dry report without Donna's voice.

---
name: draft-reply
description: Draft a reply to a specific email in the owner's voice and style
---

# /draft-reply [person name or subject]

## What This Skill Does

Writes a draft reply to a specific email, matching your tone, style, and relationship with that person. Never sends without your approval.

## Steps

1. **Find the email.** Search Gmail for the person or subject mentioned. If multiple matches, show the 3 most recent and ask which one.

2. **Check context.** Before writing:
   - Read brain/Preferences/Style.md for writing tone, greeting, sign-off
   - Read brain/People/[[Person Name]].md if it exists (relationship history, past conversations)
   - Check brain/Business/Promises.md for any open commitments with this person
   - Look at the full email thread for context (not just the last message)

3. **Assess formality.** Based on the person and history:
   - Key client or new contact = more professional
   - Close partner or regular contact = casual, matching their energy
   - Supplier or vendor = direct and clear

4. **Draft the reply.** Write it in the owner's voice:
   - Use the greeting from Style.md (e.g., "Hey [Name],")
   - Use the sign-off from Style.md (e.g., "Best,")
   - Reference specifics from the email thread, not generic responses
   - If the person asked a question, answer it directly
   - If a commitment is needed, flag it before including it

5. **Present the draft.** Show:
   - The original email (summary, 2-3 lines)
   - Your draft reply
   - Any flags: "This commits you to deliver by Friday" or "This mentions money"

## Output Format

```
## Draft Reply

**To:** [Person Name] <[email]>
**Re:** [Subject]
**Original (summary):** [2-3 line summary of what they said]

---

**Draft:**

[The reply in the owner's voice]

---

**Flags:**
- [Any commitments, deadlines, or money mentioned in this reply]

**Action needed:** Review and say "send" to send, or tell me what to change.
```

## Obsidian Links

When referencing people, goals, decisions, or promises, use [[wiki links]] (e.g., [[Person Name]], [[Promises]]). This creates clickable connections in Obsidian.

## Rules

- NEVER send the email. Only draft it. Wait for explicit "send" approval.
- Match the owner's style exactly. Check Style.md and samples/ folder.
- If you don't know the relationship well enough, ask before drafting.
- Keep it concise. Most replies should be under 150 words.
- If the reply involves money or a deadline commitment, flag it prominently.

## Self-Check (before delivering)

Before presenting this output, verify:
- [ ] The right email/meeting/task was found (confirm with user if ambiguous)
- [ ] Context from brain/ files was checked (People, Promises, Style)
- [ ] Output matches the owner's style (check Style.md)
- [ ] No commitments are made without flagging them
- [ ] [[Wiki links]] are used for people, goals, decisions, promises
- [ ] At least one Donna personality line is included

If any check fails, fix it before showing the output.

## Donna Personality Reminder

This output MUST include at least one Donna-style line. Check the Donna Flavor section in CLAUDE.md. Open with personality or close with personality. Never deliver a dry report without Donna's voice.

---
name: morning-briefing
description: Generate a full morning briefing covering emails, calendar, tasks, and top priority
---

# /morning-briefing

## What This Skill Does

Scans your email, calendar, and tasks to produce a structured morning summary. Identifies your #1 priority for the day.

## Steps

1. **Read context first.** Check brain/Daily Logs/ for yesterday's briefing and any carry-forward items.

2. **Emails.** Pull unread emails from the last 24 hours using Gmail.
   - Categorize each as: URGENT / IMPORTANT / FYI
   - Flag emails containing: dollar amounts, deadlines, attachments from key contacts
   - For URGENT emails: draft a reply in the owner's style (check brain/Preferences/Style.md). Never send.

3. **Calendar.** Pull today's events from Google Calendar.
   - List each meeting with time, title, and 1-line context
   - Flag conflicts (overlapping times or back-to-back with no gap)
   - For meetings with people in brain/People/, include a brief note about last interaction

4. **Tasks.** Pull incomplete tasks from the connected task manager (if available). If no task manager is connected, skip this step.
   - Group as: OVERDUE / DUE TODAY / THIS WEEK
   - Flag anything overdue by 3+ days

5. **Promises.** Check brain/Business/Promises.md.
   - Flag any promise due today or within the next 3 days

6. **Risk scan.** Connect the dots across emails, calendar, and tasks:
   - Deadline approaching + task not started = flag as risk
   - Stuck task + no communication with the responsible person = flag as risk
   - Multiple overdue items for one client = relationship risk
   - If any HIGH risks found, list them before the #1 priority

7. **#1 Priority.** Based on everything above, identify the single most important thing to accomplish before noon. Explain why in one sentence.

## Output Format

Use the template from templates/morning-briefing.md

## After Running

Save the full briefing to: brain/Daily Logs/[YYYY-MM-DD].md

## Obsidian Links

When referencing people, goals, decisions, or promises, use [[wiki links]] (e.g., [[Carlos Mendez]], [[Goals]], [[Decisions]]). This creates clickable connections in Obsidian.

## Rules

- Keep it under 400 words
- Skip spam and junk completely
- Be specific. "Reply to Mike about the invoice" is better than "Handle emails"
- If no urgent items exist, say so. Don't manufacture urgency.

## Self-Check (before delivering)

Before presenting this output, verify:
- [ ] Format matches the template (headers, sections, structure)
- [ ] Numbers are accurate (days overdue, task counts, email counts)
- [ ] No vague statements. Every claim has a specific number or name.
- [ ] Output is under the word limit
- [ ] [[Wiki links]] are used for people, goals, decisions, promises
- [ ] At least one Donna personality line is included

If any check fails, fix it before showing the output.

## Donna Personality Reminder

This output MUST include at least one Donna-style line. Check the Donna Flavor section in CLAUDE.md. Open with personality or close with personality. Never deliver a dry report without Donna's voice.

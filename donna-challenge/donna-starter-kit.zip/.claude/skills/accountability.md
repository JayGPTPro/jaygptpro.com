---
name: accountability
description: Track promises, commitments, and hold you accountable to your goals
---

# /accountability

## What This Skill Does

Reviews your promises, goals, and commitments. Tells you honestly where you stand and what needs attention.

## Steps

1. **Detect new promises.** Before checking existing ones:
   - Scan recent emails (last 7 days) for phrases like "I'll send", "I'll get back to you", "by Friday", "I promise", "will deliver"
   - Scan recent meeting notes in brain/Daily Logs/ for commitments
   - Track both directions: promises YOU made, and promises OTHERS made to you
   - If new promises found, add them to brain/Business/Promises.md immediately

2. **Promises scan.** Read brain/Business/Promises.md.
   - List all active promises (yours and others')
   - Flag overdue promises with number of days late
   - Flag promises due in the next 3 days
   - Separate into: "Your Promises" and "Promises to You"

3. **Goals check.** Read brain/Business/Goals.md.
   - For each goal: assess progress based on completed tasks and recent Daily Logs
   - Rate each: On Track / At Risk / Off Track
   - If Off Track: explain why in one sentence

4. **Pattern check.** Look at task completion history:
   - Tasks postponed 3+ times (call out specifically)
   - Recurring tasks that never get done (suggest: delegate, automate, or drop)
   - Commitments made in the last week that haven't been started

5. **Accountability summary.** Be direct:
   - What you said you'd do vs. what actually happened
   - Where you're making excuses vs. where you have legitimate blockers
   - One recommendation for what to do RIGHT NOW

## Output Format

```
## Accountability Check — [DATE]

### Promise Status
**Overdue:**
- [PROMISE] to [PERSON] — was due [DATE] — [DAYS] late
  Action: [deliver / extend / renegotiate]

**Due Soon:**
- [PROMISE] to [PERSON] — due [DATE]

**Kept This Week:**
- [PROMISE] — delivered [DATE]

### Goal Progress
| Goal | Status | Notes |
|------|--------|-------|
| [GOAL] | On Track / At Risk / Off Track | [1-line assessment] |

### Patterns
- [Task/commitment] has been postponed [X] times. Decision needed: do it, delegate it, or drop it.
- You committed to [X] new things this week while [Y] things were already overdue.

### Bottom Line
[1-2 sentences: honest assessment of where you stand and what needs to happen next]
```

## Obsidian Links

When referencing people, goals, decisions, or promises, use [[wiki links]] (e.g., [[Carlos Mendez]], [[Goals]], [[Decisions]], [[Promises]]). This creates clickable connections in Obsidian.

## Rules

- Be honest, not harsh. Direct feedback, not judgment.
- Use data, not assumptions. "You postponed this 4 times" is better than "You keep putting this off."
- Always end with a clear next action
- After running, update brain/Business/Promises.md with any status changes (new promises, completed, overdue)
- Track promises in both directions: what you owe others AND what others owe you

## Self-Check (before delivering)

Before presenting this output, verify:
- [ ] Format matches the template (headers, sections, structure)
- [ ] Numbers are accurate (days overdue, task counts, email counts)
- [ ] No vague statements. Every claim has a specific number or name.
- [ ] Output is under the word limit
- [ ] [[Wiki links]] are used for people, goals, decisions, promises
- [ ] At least one Donna personality line is included

If any check fails, fix it before showing the output.

## Donna Personality Reminder

This output MUST include at least one Donna-style line. Check the Donna Flavor section in CLAUDE.md. Open with personality or close with personality. Never deliver a dry report without Donna's voice.

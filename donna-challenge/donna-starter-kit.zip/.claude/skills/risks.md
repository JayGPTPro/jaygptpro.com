---
name: risks
description: Identify and flag business risks before they become problems
---

# /risks

## What This Skill Does

Scans your emails, calendar, tasks, and commitments to identify risks before they explode. Connects the dots between deadlines, stuck tasks, broken communication, and missing action.

## Steps

1. **Deadline risks.** Check for:
   - Upcoming deadlines (next 7 days) with incomplete preparation
   - Events or launches that depend on unfinished tasks
   - Example: "Webinar in 11 days but Zoom Business not configured"

2. **Communication risks.** Check Gmail for:
   - People you haven't responded to in 5+ days
   - Conversations that went silent (no reply from either side in 7+ days)
   - Important contacts with no recent interaction
   - Example: "Haven't spoken to the supplier in 3 weeks"

3. **Task risks.** Check the connected task manager (if available) for:
   - Tasks overdue by 7+ days (not just 3)
   - Tasks that block other tasks
   - Multiple overdue tasks for the same client ("8 tasks overdue for GoCash. Active paying client.")

4. **Financial risks.** Check for:
   - Unpaid invoices mentioned in emails
   - Payment setup issues (Stripe, PayPal, etc.)
   - Contracts or deals with approaching deadlines
   - Example: "Stripe Tax Setup incomplete. This blocks payments."

5. **Promise risks.** Check brain/Business/Promises.md for:
   - Promises due in the next 48 hours
   - Promises already broken (overdue)
   - People you've let down more than once

6. **Connect the dots.** This is the key step:
   - Stuck task + approaching deadline + no communication = HIGH RISK
   - Multiple overdue items for one client = RELATIONSHIP RISK
   - Financial setup incomplete + launch date approaching = REVENUE RISK

## Output Format

```
## Risk Report — [DATE]

### HIGH RISK (act today)
- [RISK DESCRIPTION]
  Why: [what will happen if you don't act]
  Action: [what to do right now]

### MEDIUM RISK (act this week)
- [RISK DESCRIPTION]
  Why: [what could go wrong]
  Action: [recommended step]

### LOW RISK (monitor)
- [RISK DESCRIPTION]
  Note: [what to keep an eye on]

### No Risk (all clear)
- [AREA] — no issues found

---
**Summary:** [X] high / [Y] medium / [Z] low risks identified
```

## Obsidian Links

When referencing people, goals, decisions, or promises, use [[wiki links]] (e.g., [[Person Name]], [[Goals]], [[Decisions]], [[Promises]]). This creates clickable connections in Obsidian.

## Rules

- Be specific. "Stripe not configured" is better than "payment issues"
- Include numbers: days overdue, days until deadline, days since last contact
- Always suggest a concrete action for high and medium risks
- Don't manufacture risks. If things are fine, say "No significant risks identified"
- This runs automatically as part of morning briefing and weekly report. Can also be run standalone.
- Tone: direct, no sugarcoating. "This is going to be a problem if you don't handle it today."

## Self-Check (before delivering)

Before presenting this output, verify:
- [ ] Format matches the template (headers, sections, structure)
- [ ] Numbers are accurate (days overdue, task counts, email counts)
- [ ] No vague statements. Every claim has a specific number or name.
- [ ] Output is under the word limit
- [ ] [[Wiki links]] are used for people, goals, decisions, promises
- [ ] At least one Donna personality line is included

If any check fails, fix it before showing the output.

## Donna Personality Reminder

This output MUST include at least one Donna-style line. Check the Donna Flavor section in CLAUDE.md. Open with personality or close with personality. Never deliver a dry report without Donna's voice.

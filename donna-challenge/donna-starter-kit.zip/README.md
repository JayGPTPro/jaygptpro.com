# Welcome to Your Donna Starter Kit

You're about to build your own AI Chief of Staff. Her name is Donna. She'll read your emails, prep your meetings, track your promises, and work while you sleep.

No coding required. Just follow the daily videos and fill in the templates.

## What's Inside

```
donna-starter-kit/
├── CLAUDE.md              ← Donna's instructions (don't edit this)
├── brain/                 ← Donna's memory (Obsidian vault)
│   ├── Business/
│   │   ├── about-me.md    ← YOUR business info (you fill this)
│   │   ├── my-business.md ← Donna fills from about-me.md
│   │   ├── Goals.md       ← Donna fills your goals
│   │   ├── Promises.md    ← Donna tracks commitments
│   │   └── Decisions.md   ← Donna logs decisions
│   ├── People/            ← Donna creates contact profiles
│   ├── Preferences/
│   │   └── Style.md       ← Donna learns your writing style
│   └── Daily Logs/        ← Donna writes daily briefings here
├── prompts/               ← Ready-to-copy prompts for onboarding
├── .claude/
│   └── skills/            ← 10 skills (commands Donna knows)
├── samples/               ← Your writing examples (so Donna matches your voice)
├── templates/             ← Output formats Donna uses for reports
├── guides/                ← Setup instructions and troubleshooting
└── output/                ← Everything Donna creates goes here
```

**Note:** The `.claude/` folder is hidden by default on your computer. That's normal. Claude Code reads it automatically. You don't need to open it manually. On Day 3, we'll show you exactly where the skills live and how to customize them.

## Before You Start (Day 0)

1. **Install Claude Desktop** from [claude.ai/download](https://claude.ai/download)
2. **Sign up for Pro plan** ($20/month). This is the only cost. Donna runs on this.
3. **Install Obsidian** from [obsidian.md](https://obsidian.md) (free, Mac/Windows/Linux). Open this entire `donna-starter-kit` folder as a vault. This is how you see everything visually.
4. **Open Claude Desktop** and have your first conversation: just say "Hello"
5. **Open this folder** in Claude Desktop (drag it in, or use File > Open Folder)

Detailed setup instructions: [guides/day0-setup.md](guides/day0-setup.md)

## How the Challenge Works

| Day | What You'll Build | Time |
|-----|-------------------|------|
| **Day 0** | Install Claude Desktop + explore | ~20 min |
| **Day 1** | Meet Donna, see what she can do | ~30 min video + 30 min hands-on |
| **Day 2** | Donna learns your business (about-me.md + prompts) | ~30 min video + 30 min hands-on |
| **Day 3** | One command = 30 min of work saved (Skills) | ~35 min video + 30 min hands-on |
| **Day 4** | Donna works while you sleep (Automation) | ~35 min video + 30 min hands-on |
| **Day 5** | Donna thinks about your business (Memory + Insights) | ~35 min video + 30 min hands-on |

## Important Notes

- **Claude Desktop must be running** for scheduled tasks (Day 4+). It can be minimized, but not closed.
- **brain/ is an Obsidian vault.** Obsidian is free and required. It lets you see Donna's memory as a visual knowledge graph with clickable connections between people, goals, decisions, and daily logs.
- **Everything works on Mac and Windows.** If you hit issues, check [guides/troubleshooting.md](guides/troubleshooting.md).
- **Donna never sends emails or deletes anything without your permission.** She reads and drafts. You approve.

## Need Help?

Join the WhatsApp support group: [הלינק נשלח אליך במייל עם ההרשמה]

Stuck on something technical? Check [guides/troubleshooting.md](guides/troubleshooting.md) first.

---

Let's build your first AI hire.

<!-- DONNA FILLS THIS when you make important decisions -->
<!-- You can also log decisions manually -->

# Decision Log

## Decisions

### [DATE] — [DECISION TITLE]

**Context:** [What was the situation?]
**Decision:** [What did you decide?]
**Why:** [What was the reasoning?]
**Alternatives considered:** [What else did you think about?]

---

<!--
  Example:

  ### 2026-04-20 — Switched from Mailchimp to ConvertKit

  **Context:** Mailchimp pricing doubled after reaching 5,000 subscribers.
  **Decision:** Migrate to ConvertKit.
  **Why:** Better automation, similar pricing at scale, better for course/challenge funnels.
  **Alternatives considered:** Stayed with Mailchimp (too expensive), Beehiiv (no automation).
-->

<!-- YOU FILL THIS FILE -->
<!-- When: Before Day 2 (take your time, no rush) -->
<!-- What happens next: Run the "Learn About Me" prompt from prompts/01-learn-about-me.md -->
<!-- Donna will read your answers and fill brain/Business/my-business.md, Goals.md, and Style.md -->

# About Me & My Business

Fill this out BEFORE Day 2. Take your time. The better your answers, the better Donna works.
Open this file in Obsidian and type your answers directly below each question.

Don't overthink it. Short answers are fine. Donna will ask if she needs more.

---

## Part 1: Who I Am

**Your name:**
<!-- example: Sarah Cohen -->

**Your role (e.g., Founder, CEO, Freelancer, Consultant):**
<!-- example: Founder & CEO -->

**Your location and timezone:**
<!-- example: Tel Aviv, Israel (UTC+3) -->

**One sentence about what you do:**
<!-- example: I run a boutique e-commerce brand selling handmade jewelry on Etsy and Shopify -->

---

## Part 2: My Business

**What does your business do? (2-3 sentences, plain language)**
<!-- example: We design and sell handmade silver jewelry. We sell on Etsy and our own Shopify store. Most customers are in the US and Europe. -->

**Who do you sell to / serve? (your customers or clients)**
<!-- example: Women aged 28-45 who appreciate artisan jewelry. Also gift buyers around holidays. -->

**How big is your business? (team size, revenue range, or stage)**
<!-- example: Team of 3. Revenue ~$15K/month. Growing but need to scale marketing. -->

**What platforms do you use? (Amazon, Shopify, local clients, B2B, etc.)**
<!-- example: Etsy, Shopify, Instagram, Google Ads -->

---

## Part 3: Key People

List 3-5 people Donna will see in your emails. For each one: name, role, one line about them.

<!-- example:
| Name | Role / Company | What Donna should know |
|------|---------------|----------------------|
| Noa Levy | Designer (employee) | Sends weekly design updates |
| Tom Baker | Etsy account manager | Responds slowly |
| David Kim | Google Ads consultant | Monthly report calls |
-->

| Name | Role / Company | What Donna should know |
|------|---------------|----------------------|
|      |               |                      |
|      |               |                      |
|      |               |                      |
|      |               |                      |
|      |               |                      |

---

## Part 4: Current Priorities

What are you focused on right now? List your top 3 priorities for this quarter.

<!-- example:
1. Launch new summer collection (deadline: May 15)
2. Increase Shopify direct sales to 40% of revenue
3. Hire a social media manager
-->

1.
2.
3.

---

## Part 5: Communication Style

**How do you talk? (direct? casual? formal?)**
<!-- example: Casual but professional. Friendly, not too formal. -->

**How do you start emails? (e.g., "Hey [Name]," or "Hi [Name],")**
<!-- example: Hey [Name], -->

**How do you end emails? (e.g., "Best," or "Thanks," or just your name)**
<!-- example: Thanks! Sarah -->

**Anything Donna should know about how you communicate?**
<!-- example: I tend to be short in emails. I use emojis sometimes. I reply fast but forget to follow up. -->

---

## Part 6: Writing Samples

Paste 2-3 emails you actually wrote. These help Donna match your voice.
Don't worry about finding the "perfect" email. Any real email you sent works.

### Email 1:
```
[Paste an email you wrote here]
```

### Email 2:
```
[Paste another email here]
```

### Email 3 (optional):
```
[Paste another email here]
```

---

## Done?

Great. Now go to Day 2 in the challenge portal and run the "Donna, learn about me" prompt.
Donna will read this file and fill in brain/Business/my-business.md, Goals.md, and Style.md automatically.

<!-- DONNA FILLS THIS from your about-me.md answers -->
<!-- Updated by: Prompt 01 (Learn About Me) and ongoing by Donna -->
<!-- You can also edit this directly anytime -->

# Business Goals

## Current Quarter Goals

1. **[GOAL 1]** — [Why this matters. What success looks like.]
2. **[GOAL 2]** — [Why this matters. What success looks like.]
3. **[GOAL 3]** — [Why this matters. What success looks like.]

## Revenue Target

- **This month:** [$ amount or "no specific target"]
- **This quarter:** [$ amount or "no specific target"]

## What I'm NOT Focused On Right Now

<!-- This helps Donna deprioritize things that seem important but aren't. -->

- [THING YOU'RE DELIBERATELY IGNORING RIGHT NOW]
- [THING YOU'RE DELIBERATELY IGNORING RIGHT NOW]

## Key Deadlines

| Deadline | What | Why It Matters |
|----------|------|----------------|
| [DATE] | [WHAT'S DUE] | [CONSEQUENCE IF MISSED] |
| [DATE] | [WHAT'S DUE] | [CONSEQUENCE IF MISSED] |

---

_Last updated: [DATE]_

<!-- DONNA FILLS THIS automatically -->
<!-- She detects promises from your emails and conversations -->
<!-- You can also add promises manually -->

# Promises Tracker

## Active Promises

| Date Made | Promised To | What I Promised | Due By | Status |
|-----------|------------|-----------------|--------|--------|
| | | | | |

## Promises Others Made to Me

| Date Made | Who Promised | What They Promised | Due By | Status |
|-----------|-------------|-------------------|--------|--------|
| | | | | |

## Completed Promises

<!-- Move here when done. Keeps a record. -->

| Date Made | Promised To | What | Completed |
|-----------|------------|------|-----------|
| | | | |

---

_Donna updates this during morning briefings and when processing emails._

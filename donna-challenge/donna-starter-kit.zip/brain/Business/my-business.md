# My Business Profile

<!-- DONNA FILLS THIS FILE. Do not edit manually. -->
<!-- This is generated from your answers in about-me.md -->
<!-- To update, edit about-me.md and run the "Learn About Me" prompt again. -->

## Who I Am

- **Name:**
- **Role:**
- **Location:**
- **Industry:**

## My Business

- **What we do:**
- **Who we serve:**
- **How big:**
- **Key platforms:**

## Key People

| Name | Role | What Donna Should Know |
|------|------|----------------------|
|      |      |                      |

## Current Priorities

1.
2.
3.

## How I Communicate

- **Language:**
- **Tone:**
- **Email greeting:**
- **Email sign-off:**

---
*Last updated by Donna: [DATE]*

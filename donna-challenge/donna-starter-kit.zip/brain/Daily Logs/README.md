<!-- DONNA FILLS THIS FOLDER automatically -->
<!-- One file per day: YYYY-MM-DD.md -->
<!-- Created by /morning-briefing and /evening-summary -->
<!-- You don't need to do anything here -->

# Daily Logs

This folder stores Donna's daily briefings and summaries. One file per day.

## How It Works

- Donna creates a new file each day (format: `YYYY-MM-DD.md`, e.g., `2026-04-20.md`)
- Morning briefings go here automatically (from Day 4 onward, via scheduled task)
- Evening summaries get appended to the same day's file
- You can also add your own notes to any day's file

## Why This Matters

This is Donna's memory of what happened. When she starts a new conversation, she reads the latest Daily Logs to understand your current situation. The more entries here, the smarter Donna gets.

## You Don't Need to Do Anything

Donna writes here automatically. Just let the files accumulate. Review them when you want to see what's been happening.

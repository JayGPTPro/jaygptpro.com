# Feedback Tracker
<!-- DONNA FILLS — Updated when you give feedback on outputs, emails, decisions -->
<!-- Tracks reactions to help Donna learn what resonates and what doesn't -->

## How This Works
When you tell Donna "that was great", "too long", "wrong tone", or give any feedback on her output, she logs it here. Over time, this builds a picture of your preferences.

## Format

| Date | Output Type | Feedback | Signal | Action Taken |
|------|------------|----------|--------|-------------|
| | | | | |

<!--
Signal types:
- Positive: "great", "perfect", "exactly right", approved without changes
- Corrective: "too long", "wrong tone", "try again", edited heavily
- Preference: "always do X", "never do Y", "I prefer Z"

Action Taken = what Donna updated based on this feedback (Style.md, a skill, etc.)
-->

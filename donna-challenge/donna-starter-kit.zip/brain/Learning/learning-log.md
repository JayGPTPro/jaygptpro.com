# Learning Log
<!-- DONNA FILLS — Updated automatically when /learn runs or as part of evening summary -->
<!-- Each entry records what worked, what didn't, and new patterns discovered -->
<!-- When a pattern appears 3+ times, it gets promoted to the relevant permanent file (Style.md, Goals.md, etc.) -->

<!-- Entries will appear below as Donna learns from your interactions -->

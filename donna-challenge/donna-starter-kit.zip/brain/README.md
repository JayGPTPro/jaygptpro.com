# Donna's Brain

This is where Donna stores and reads everything she knows.

## What YOU fill (once):
| File | What | When |
|------|------|------|
| Business/about-me.md | Your business info, people, goals, writing samples | Before Day 2 |

## What DONNA fills (automatically):
| File/Folder | What | How |
|-------------|------|-----|
| Business/my-business.md | Your profile (from about-me.md) | Prompt 01 |
| Business/Goals.md | Your goals | Prompt 01 + ongoing |
| Business/Promises.md | Commitments you made | Detected from emails |
| Business/Decisions.md | Important decisions | When you decide something |
| Preferences/Style.md | Your writing style | Prompt 02 |
| People/ | Profiles of your contacts | From emails and meetings |
| Daily Logs/ | Daily briefings and summaries | /morning-briefing, /evening-summary |
| Learning/learning-log.md | What worked, what didn't, new patterns | /learn, /evening-summary |
| Learning/feedback.md | Your reactions to Donna's outputs | /learn (when you give feedback) |

## Don't touch:
- Don't rename files or folders
- Don't delete anything Donna wrote
- You CAN edit any file to correct or add information

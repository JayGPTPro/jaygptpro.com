<!-- DONNA FILLS THIS when she encounters new people in your emails -->
<!-- You can also create profiles manually: copy this template and rename -->

# [Person's Name]

## Basic Info
- **Company/Role:** [Their company and role]
- **Email:** [Their email]
- **Relationship:** [How you know them: client, supplier, partner, etc.]

## Context
[1-2 sentences about this person and why they matter to your business]

## Last Interaction
- **Date:** [When you last communicated]
- **Topic:** [What you discussed]
- **Status:** [Open items, decisions made, next steps]

## Open Items
- [Anything unresolved between you]

## Notes
- [Anything Donna should remember about this person]
- [Communication preferences, timezone, quirks]

---
_Donna updates this profile when new interactions are detected._

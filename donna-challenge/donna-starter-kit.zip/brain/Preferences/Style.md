<!-- DONNA FILLS THIS from your about-me.md writing samples -->
<!-- Updated by: Prompt 02 (Learn My Style) -->
<!-- You can edit this anytime to fine-tune how Donna writes as you -->

# My Communication Style

## How I Write Emails

- **Length:** [Short and punchy / Medium with detail / Long and thorough]
- **Greeting:** [How do you start emails? e.g., "Hey [Name]," / "Hi [Name]," / "[Name]," / no greeting]
- **Sign-off:** [How do you end? e.g., "Best," / "Thanks," / "Cheers," / just your name]
- **Tone:** [Casual and friendly / Professional but warm / Formal / Direct and brief]
- **Quirks:** [Anything unique about your writing? e.g., "I use bullet points a lot" / "I always ask a question at the end" / "I never use exclamation marks"]

## How I Talk in Meetings

- [Describe briefly: e.g., "I get straight to the point. I don't do small talk."]

## Words I Use Often

- [LIST WORDS OR PHRASES YOU NATURALLY USE]

## Words I Never Use

- [LIST WORDS OR PHRASES THAT DON'T SOUND LIKE YOU]

## Writing Samples

For better accuracy, put 3-5 real emails or messages you've written in the **samples/** folder.
Donna will learn your actual patterns from those examples.

---

_Last updated: [DATE]_

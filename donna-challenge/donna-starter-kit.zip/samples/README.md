# Writing Samples

Put 3-5 real examples of things you've written in this folder. These help Donna match your voice when drafting emails and messages.

## What to Include

- **Emails you sent** (copy-paste into a .txt or .md file)
- **WhatsApp messages** to business contacts
- **Social media posts** you wrote
- **Anything** that shows how you naturally communicate

## How to Add Them

1. Create a new file in this folder (e.g., `email-example-1.md`)
2. Paste the content
3. That's it. Donna will read these automatically.

## Tips

- Pick examples that represent your **normal** style, not formal exceptions
- Include at least one **short** email and one **longer** message
- If you write differently to different audiences, include both
- Don't edit them to be "better." Donna needs your real voice, not a polished version.

## Example File

```
# Email to Supplier — March 2026

Hey Mike,

Quick question. The last shipment had 12 units short. Can you check on your end?

Need to know by Friday so I can update my inventory numbers.

Thanks,
[Your Name]
```

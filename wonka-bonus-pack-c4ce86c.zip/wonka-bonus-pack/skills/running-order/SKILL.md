---
name: running-order
description: Decides which approved image goes in which listing slot, and why, then draws the shelf as a phone shows it. Reads the tasting cards, the reviews and the brief to rank what a shopper doubts, gives every slot one job, matches the job to an approved asset, names the jobs no asset covers, renders the main image beside the numbered thumbnail rail, and reads that rail back at thumbnail size before writing the order. Runs after the package is approved. Use when the owner asks what order to upload in, which image should be second or third, how the gallery is sequenced, or how the set looks on a phone. Triggers: /running-order, "which one goes first", "arrange my photos", "what order do I upload these in", "which image should be image 2", "sequence my gallery", "the order of the images", "how does the set look on a phone", "shelf strip".
---

# Running Order

| Meta | Value |
|------|-------|
| Skill | Running Order. Part of the bonus pack, not the kit |
| Needs | The approved assets (the `Gallery pick:` frames and the `Main pick:`, resolved through the highest `edits/vN/` first by `product.py`; `final/` when the pack exists), `tests/tasting-*/` cards when a panel has run, `research/reviews.md`, `research/insights.md`, `research/persona.md`, `brief/creative-brief.md`, `incumbent/` (the images live on Amazon now) when the listing is live, `status.md`. If `product.py` prints a `WARNING:` line (gallery not approved, reference not locked), STOP and ask the owner; those are candidates, and nothing here spends on candidates |
| Saves to | `factory/Products/[product]/upload/running-order.md` and `upload/shelf-strip.png` |
| Writes | ONLY inside `upload/`. Never renames, moves, edits or deletes an image, and never changes a pick |
| Typical cost | Free. It reads and it draws, it never generates |
| Engine | No. Python and Pillow, both already installed for the kit |

## What this does

The package is approved and every image is good. That is not the same as knowing which one goes
second. House doctrine: a shopper meets the set as one big picture and a row of small squares, decides
fast whether to keep swiping, and few reach the last frame. The order is the
last creative decision in the whole build, and until now the owner made it by feel at upload time.

This skill gives every slot ONE job, matches each job to an asset that already exists, names the
jobs nothing covers, and then draws the result at the size it will actually be seen.

Three things it is not. It does not pick the main image: that was decided on the shortlist and is
slot 1 by definition. It does not generate or edit: a gap is named and routed, never filled here.
And it does not rank quality: `/inspect` did that, and a frame that failed the gate is not in the
running.

## Before you start

| Input | Missing |
|---|---|
| Approved assets | Nothing to order. Say which class is empty and stop |
| Tasting cards | Run without them. Lines backed by `reviews.md` stay `evidence`; only lines with no review behind them are `doctrine`. Say once, plainly, that the panel did not see this set |
| `research/reviews.md` | Run without it. The ledger loses its strongest source, say so |
| `brief/creative-brief.md` | Run without it. The slot plan was the original intent and its absence is worth one line |
| `incumbent/` | Only a live listing has one. Its absence is not a gap |
| The day gate | This skill ships after graduation and is never gated. If `status.md` shows a product mid-bootcamp, one line: the order is usually decided after the panel has spoken. Then continue |

## Process

### 1. Resolve the assets, newest version first

`python3 .claude/pack/product.py [product]` prints the shipped main and gallery, resolved through the
highest `edits/vN/` (and `final/` when the upload pack exists). Use exactly that list. Order the versions the owner will upload, never the originals they replaced.
List what you resolved before you use it, so a wrong version is caught here and not on Amazon.

### 2. Build the objection ledger

One table, ranked, and every line carries its source:

| Rank | What the shopper doubts | Source | Strength |
|---|---|---|---|
| 1 | "the sticks will bend at that length" | tasting r1, 14 of 100 cards | evidence |
| 2 | "smaller than I expected" | reviews.md, 6 one-star quotes | evidence |
| 3 | price against the 6 pack | doctrine, the category's usual objection | doctrine |

Rules. Three kinds of evidence, kept apart in the ledger and never merged into one score:
real customers (`reviews.md`, the strongest source, because they paid and used it), the tasting
panel (synthetic tasters who saw THESE images; a read of the pictures, not of the product), and
doctrine (the category's usual objection, nobody raised it here). A review objection and a panel
objection that agree make the strongest line. Where they disagree, say so and prefer the review
for an objection about the product and the panel for an objection about the picture. Doctrine
never outranks either. Count the cards, do not estimate them, and never present the order as a
proven conversion win; it is a recommendation with its reason on every slot.

### 3. Give every slot its job

The doctrine, used where evidence is silent:

| Slot | Job |
|---|---|
| 1 | The main. Already decided. It wins the search page, it is not re-opened here |
| 2 | The biggest doubt in the ledger. This is the frame most shoppers see second and many see last |
| 3 | What you actually get, at the size you get it. Scale, count, contents |
| 4 | The product doing its job, with a person, at the moment the buyer pictures themselves |
| 5 | The detail that justifies the price |
| 6 | The second objection |
| 7 | The close. Gift, bundle, reassurance, whatever the persona responds to |

Evidence overrides the table. If the panel's loudest objection is about size, scale moves to slot 2
and the doubt frame follows it. Write the reason on the line; a slot without a reason is a guess.

### 4. Match a job to an asset

For each slot, name the file and the one line that says why it does that job. When two assets could
do it, prefer the one the panel ranked higher, and say that is why.

### 5. Name the gaps

A job with no asset is a GAP, not a shuffle. Write it as one line with the skill that fills it:
`/secondary-images` for a missing listing frame, `/fix` when an existing frame is close but
wrong. A `/lifestyle-pack` frame is not a listing frame; it enters only as a candidate through
`/inspect`. Never re-use a frame for two jobs to make the numbers work.

### 6. Draw the shelf

```
python3 .claude/pack/strip.py \
  --out factory/Products/[product]/upload/shelf-strip.png \
  --fold 3 --fold-label "swipe to see these" \
  --labels "main,doubt,contents,use,detail,objection,close" \
  [the files, in order, main first]
```

`--fold 3` draws the line after the third rail cell, which is slot 4 (slot 1 is the main). It marks where the rail runs out of room on a phone. It is a HOUSE DEFAULT of 3 and it is not
a fact about any marketplace. Say that in the document, and let an owner who knows their own
analytics set a different number.

### 7. Read the rail back

Open `shelf-strip.png` with vision and look at the rail only, at the size it was drawn. For every
cell, answer in the document: can I tell what this is? Words legible? Different enough from its
neighbour to be worth a tap? A cell that fails is not a bad image, it is an image in the wrong
slot. Move it later and say why, or send it to `/fix` with the specific defect.

This step is the reason the picture is drawn at all. Do not skip it and do not answer from the
full-size images.

### 8. Order the A+ modules by the same ledger

The page answers the same doubts in the same priority, with room to prove them. One short table:
module, the ledger line it answers, and the asset it uses.

### 9. The video, if one exists

A listing video does not sit in the rail the way an image does, and where a marketplace places it
is not yours to set. So do not order it. Name which images must still carry their job if the video
takes a position ahead of them, and say which single image the video makes redundant, if any.

## Output format

Write `upload/running-order.md`:

```
# Running Order . [Product] . [YYYY-MM-DD]

## The order
| Slot | File | Job | Why this file | Source |
|---|---|---|---|---|
| 1 | edits/v2/m2.png | main | the shortlist pick, panel winner 34/100 | evidence |
| 2 | edits/v2/sec-01.png | answers "will they bend" | the only frame showing the load | evidence |

## The objection ledger
[the ranked table from step 2]

## Gaps
- Slot 6 has no asset for the second objection. `/secondary-images` makes it.

## The rail, read at thumbnail size
| Slot | Reads at thumbnail? | Note |
|---|---|---|
| 2 | yes | the fork head is the only thing in frame |
| 5 | NO | four small icons, none legible. Moved to slot 7 |

## A+ module order
[table]

## The video
[one paragraph, or "no video in the factory"]

## What this order assumes
- The fold is drawn after slot 4 as a house default, not as a marketplace fact.
- [every doctrine line used, listed here so the owner can overrule it]
```

## Definition of done

- Every slot names a file and a reason, or is written as a gap with the skill that fills it.
- Every ledger line says `evidence` or `doctrine`, and evidence cites its count.
- `shelf-strip.png` exists and was OPENED and read back, cell by cell, in the document.
- No image was moved, renamed or edited by this skill.
- `status.md` carries the new row.

## Update status.md

Add under Stations:

```
| Running order | done | upload/running-order.md + upload/shelf-strip.png | [date] | [n] slots, [n] gaps. Fold marked after slot [n] (house default) |
```

## Wonka lines

- Opening: "Every sweet in the window is good. The window is still the argument."
- On a gap: "There is no frame for that job. I would rather leave the shelf honest than fill it twice."
- On a thumbnail that does not read: "Beautiful at full size. Invisible at the size it will be seen. That is a placement problem, not a quality one."

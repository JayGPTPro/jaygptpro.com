# Reading a live Amazon listing (outside the factory only)

Moved out of SKILL.md on 20.9.2026 so the skill reads as a process, not as a script. Inside
the factory you never need this file: the facts come from the research and the brief.

### Phase 2: Extract product data via Chrome MCP

1. Open the Amazon URL in Chrome MCP. Wait about 3 seconds for the page to settle.
2. Extract with JavaScript execution:

```javascript
// Product basics
({
  title: document.getElementById('productTitle')?.textContent?.trim(),
  price: document.querySelector('.a-price .a-offscreen')?.textContent?.trim(),
  listPrice: document.querySelector('.basisPrice .a-offscreen, .a-text-price .a-offscreen')?.textContent?.trim(),
  rating: document.querySelector('#acrPopover')?.title || document.querySelector('.a-icon-alt')?.textContent,
  reviewCount: document.querySelector('#acrCustomerReviewText')?.textContent?.trim(),
  brand: document.querySelector('#bylineInfo')?.textContent?.trim(),
  badges: document.querySelector('#acBadge_feature_div, #zeitgeistBadge_feature_div')?.textContent?.trim(),
  boughtRecently: document.querySelector('#social-proofing-faceout-title-tk_bought')?.textContent?.trim()
})
```

```javascript
// Feature bullets
Array.from(document.querySelectorAll('#feature-bullets .a-list-item'))
  .map(el => el.textContent?.trim()).filter(t => t && t.length > 10)
```

```javascript
// Product details table (materials, dimensions, weight, what is included)
Array.from(document.querySelectorAll('#productDetails_techSpec_section_1 tr, #detailBullets_feature_div li, #productOverview_feature_div tr'))
  .map(r => r.textContent.replace(/\s+/g,' ').trim()).filter(Boolean).slice(0,30)
```

```javascript
// High-res image URLs, gallery order
Array.from(document.querySelectorAll('#altImages .a-button-thumbnail img'))
  .map(img => img.src.replace(/\._.*_\./, '._SL1500_.'))
  .filter(s => s.includes('images/I/'))
```

3. Scroll to the reviews and extract REAL reviews only:

```javascript
Array.from(document.querySelectorAll('[data-hook="review"]')).map(r => ({
  stars: parseFloat(r.querySelector('[data-hook="review-star-rating"] .a-icon-alt')?.textContent || '0'),
  title: r.querySelector('[data-hook="review-title"] span:last-child')?.textContent?.trim(),
  body: r.querySelector('[data-hook="review-body"] span')?.textContent?.trim(),
  author: r.querySelector('.a-profile-name')?.textContent?.trim(),
  date: r.querySelector('[data-hook="review-date"]')?.textContent?.trim(),
  verified: !!r.querySelector('[data-hook="avp-badge"]')
})).filter(r => r.stars >= 4 && r.body && r.body.length > 20 && r.verified)
```

If `body` comes back empty (Amazon changes its review markup often), fall back to
`r.innerText` per review and split it yourself: the first line is the author, then the star
line, then the title, then "Reviewed in ... on <date>", then "Verified Purchase" or "Vine
Customer Review of Free Product", then the body. Vine reviews are real but not verified
purchases: you may use them, labeled "Vine reviewer", never as "Verified".

If fewer than 3 usable reviews come back, open `https://www.amazon.com/product-reviews/<ASIN>`
and run the same extraction there. Trim long reviews to the strongest 1 to 3 sentences, keep
the words as written.

**Price traps.** If the page shows a foreign currency (ILS, EUR) or "cannot be shipped to
your location", the buy box is hidden and `.a-price` is a converted reference price. Get the
real USD figures from the page's embedded data instead:

```javascript
var h=document.documentElement.outerHTML;
({usd:[...new Set(h.match(/\$\s?\d{2,4}\.\d{2}/g)||[])].slice(0,12),
  list:(h.match(/formattedFullPrice[^$]*(\$[\d,]+\.\d{2})/)||[])[1],
  save:(h.match(/percentageDisplayString[^%]*?(\d+)%/)||[])[1]})
```

The price to pay appears with `"currencyCode":"USD"` next to it; the list price as
`formattedFullPrice`; the saving as `percentageDisplayString`. Confirm the three agree
(price + saving = list) before using them.

**Image trap.** `#altImages` thumbnails are 40px sources and the `_SL1500_` swap on them
returns 500px files. The full-size set is in the page script under `colorImages`:

```javascript
[...document.scripts].map(s=>s.textContent).find(t=>t.includes('colorImages')).match(/"hiRes":"([^"]+)"/g).map(x=>x.split('"')[3])
```

That list is in gallery order and includes every image, 1500px. Video thumbnails
(`play-icon-overlay` in the URL) are not images; skip them.


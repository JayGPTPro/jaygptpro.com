# Building the page, and the elevation pass

Moved out of SKILL.md on 20.9.2026. Phase 5 gets a correct page; Phase 6 is what makes it
worth shipping and is not optional. Read this file before writing HTML, together with
`design-playbook.md`, which holds the patterns that made the best pages good.

### Phase 5: Build the landing page

Create `index.html`. Sections in this order, each with an id:

1. **Nav**: fixed, pill or bar with backdrop blur, brand mark (initial in a colored square
   plus the name), section links (hidden on mobile), "Buy on Amazon · $price" button.
2. **Hero**: the direction's hero recipe from the playbook. Eyebrow row (badge as extracted,
   plus a mono category label), the headline in display type at 4.5 to 5rem with one
   accented phrase, a two-line subhead written from the bullets, stars with the real
   rating and count linking to Amazon reviews, price (with list price struck through if
   there is one), the CTA with a soft pulse, up to three trust chips, each a fact actually
   read in Phase 0 or Phase 2 (a listed return policy, a real certification on the label); none by default. Image side: main image with a slow
   float, one or two floating spec chips that quote real specs, and a thumbnail row that
   swaps the main image.
3. **Proof line, not a stat strip.** No row of big counters ("60W / 8h / 4.8 stars"). Every AI
   landing page has one and it reads as filler. If the product has one number that sells it,
   put that number inside the feature that earns it, in a sentence. Rating and review count
   live in the hero and in the reviews section, nowhere else.
4. **Features** (`id="features"`): 5 to 6 features rewritten from the bullets, short
   title plus one sentence each. Not a grid of equal cards. Give the strongest feature its
   own full-width moment (a large image beside big type, or a bento tile that spans two
   columns), then the rest smaller. Where the listing has an infographic for a feature, use
   it as that feature's image. Icons are inline SVG, never an icon font.
5. **In the box / detail**: an image beside a checklist, from the bullets and the details
   table. Include dimensions and materials when the listing has them.
6. **Gallery** (`id="gallery"`): every product image, masonry or 3-column, hover zoom.
   Amazon infographic images go here as they are; they carry the seller's own callouts.
7. **Email capture, only when there is somewhere for the email to go.** Ask the owner once
   for the form endpoint (a Google Form URL and its email field id). With an endpoint, build the
   band: one input plus button, VIP-list copy in the product's voice, and the success state only
   after the form has accepted the submission. **With no endpoint, leave the whole band out.**
   Never show a success message for an email that went nowhere; a visitor who believes they
   signed up and never hears back is worse than no form. If the owner wants to see the band
   before wiring it, render it with a visible "not connected yet" label and a disabled button.
8. **Reviews** (`id="reviews"`): 4 to 6 real reviews, each with a bold title line, stars,
   author and date. A "Verified" chip ONLY on a review whose source marks it verified; a real
   quote is not the same as a verified purchase. The headline uses the real count only when the
   source carries one; with no count, no headline number. A price or rating that was not read
   from a source is left out, never carried over from an older build. Link "Read all reviews
   on Amazon".
9. **FAQ** (`id="faq"`): 5 to 6 questions a real shopper asks about THIS product type,
   answered from the bullets and details. Accordion, one open at a time.
10. **Final CTA**: a full-width band in the brand color or ink, headline, price, button,
    two trust lines.
11. **Footer**: brand mark, section links, disclaimer: "Independent product page. [Brand]
    is a trademark of its owner." (add who fulfils only when the listing read says so)
12. **Sticky mobile bar**: price plus Buy button, appears after the hero scrolls out.

Design ambition, before the technical rules. A page that passes QA can still be flat. Read
the finished layout against these and fix what fails:

- **Rhythm.** No two consecutive sections share a background tone or a layout shape. Dark,
  paper, full-bleed photo, paper, dark. Two columns, then one, then a grid, then a band.
- **One full-bleed photo section.** The best lifestyle image from the listing, edge to edge,
  with a short line of display type on it and nothing else. This is the breath in the page.
- **Scale contrast.** At least one headline at 5rem or more, and body copy that stays at 17
  to 19px. Big and small next to each other is what makes a page feel designed.
- **Asymmetry somewhere.** A headline that overlaps the edge of an image, a card that sits
  off the grid, a photo that bleeds off the right edge while the copy sits in the grid.
- **The product in the copy's color.** Pull one image out of its white background with a
  soft drop shadow or place it on a tinted plate, so the product sits IN the page instead
  of on top of it.
- **Whitespace as a material.** 96 to 128px between sections on desktop. Cramped is the
  first thing an eye reads as cheap.
- **Details that only a person would add.** A mono label with the ASIN or the pack's
  capacity in the corner of the hero. A hand-set pull quote. A tiny drawn icon that matches
  the product, not a generic one.

Technical rules:

- `<script src="https://cdn.tailwindcss.com">` with a `tailwind.config` that registers the
  palette tokens and font families. Google Fonts via `<link>` with preconnect.
- Custom CSS in one `<style>`: reveal classes gated behind a `js-anim` class on `<html>`
  so content is never stuck invisible, `prefers-reduced-motion` respected, the signature
  device, the CTA pulse, the accordion.
- All JavaScript at the bottom: gallery swap, scroll reveal, accordion, nav state on
  scroll, sticky bar, email form.
- Scroll reveal is a `requestAnimationFrame` throttled scroll pass, not an
  IntersectionObserver that unobserves on first hit. Elements are removed from the list once
  revealed, so nothing can be skipped by a fast scroll or an anchor jump:
  ```js
  var revealEls = Array.prototype.slice.call(document.querySelectorAll('.rv'));
  function revealPass(){
    for(var i = revealEls.length - 1; i >= 0; i--){
      if(revealEls[i].getBoundingClientRect().top < window.innerHeight - 40){
        revealEls[i].classList.add('in'); revealEls.splice(i, 1);
      }
    }
  }
  ```
  Call it once on load, then on `scroll` and `resize` behind a rAF tick.
- Every Amazon link: the product URL, `target="_blank" rel="noopener"`.
- Mobile first. Test the hero at 390px in your head: headline 2.6rem, image under the copy,
  thumbs scroll horizontally, chips hidden.
- Alt text on every image, from the listing.

### Phase 6: The elevation pass (do not skip this)

**The page you just built is the draft, not the deliverable.** Phase 5 gets the structure,
the real data and a defensible direction onto the screen. It reliably produces a page that
is correct and slightly flat. The difference between "clean" and "a brand paid for this" is
made here, and it is made on purpose, not by luck.

Copy the draft to `index-v1.html` first, so the lift is visible and reversible. Then go
back through the page and raise it two levels. Not a restyle. Each lane below changes what
the page *does*, and each one has a concrete implementation.

1. **Give the hero an entrance.** A page that fades in as one block reads as a template.
   Stagger it: put a `.hi` class on the eyebrow, each line of the headline, the subhead, the
   stars, the price and the CTA, each with its own `style="--d:.12s"` delay. Gate the whole
   thing on a `loaded` class added by a double `requestAnimationFrame`, never on
   `window.onload`, which would hold the hero hostage to the last image.

   ```css
   html.js-anim .hi{ opacity:0; transform:translateY(22px); }
   html.js-anim.loaded .hi{ animation:rise .9s cubic-bezier(.16,.8,.3,1) forwards; animation-delay:var(--d,0s); }
   @keyframes rise{ to{ opacity:1; transform:none; } }
   ```
   ```js
   requestAnimationFrame(function(){ requestAnimationFrame(function(){
     document.documentElement.classList.add('loaded'); }); });
   ```

2. **Build the signature device for real.** In Phase 5 it is usually a gradient and a
   promise. Now make it out of the product itself. A speaker with an RGB light ring has a light
   ring, so the page got an actual ring: a `conic-gradient` through the product's own light
   colours, an animatable angle via `@property --a`, a blurred masked halo behind the
   product, and the same ring reused at 9px as the nav mark and as a status dot. One device,
   built once, reused three times at three sizes. That repetition is what reads as identity.

   ```css
   @property --a { syntax:'<angle>'; inherits:false; initial-value:0deg; }
   .ring{ --a:0deg; background:conic-gradient(from var(--a), var(--hot), var(--sun), var(--cyan), var(--hot)); }
   .halo{ background:conic-gradient(from 0deg, var(--hot), var(--sun), var(--cyan), var(--hot));
          mask:radial-gradient(farthest-side, transparent 46%, #000 63%, #000 80%, transparent 100%);
          filter:blur(26px); animation:spin 18s linear infinite; }
   ```

3. **Put material under the colour.** Flat hex fills are the tell. Add, in this order:
   a mesh gradient ground (three or four soft `radial-gradient` blobs in the palette over
   the paper colour), a grain overlay (inline SVG `feTurbulence` at `opacity:.09`,
   `mix-blend-mode:soft-light`) on the hero and the dark sections, and `backdrop-filter`
   glass on the nav and any floating chips. Cheap, and it is most of the perceived jump.

4. **Break the equal grid.** If the features are still six cards of the same size, convert
   to a bento: one tile spanning two columns with the strongest claim and a real image, one
   tall tile, four normal. Give tiles a lift on hover
   (`transform:translateY(-5px)` plus a deeper shadow) and scale the image inside to 1.04.

5. **Turn the gallery into a filmstrip.** Replace the masonry with a horizontal
   `scroll-snap-type:x mandatory` strip, numbered `lbl` captions under each frame, prev and
   next buttons, and a progress bar that tracks `scrollLeft`. It bleeds off the right edge,
   which is the asymmetry the page was missing.

6. **Give the best feature its own room.** Find the one thing the product does that a
   photograph cannot show and build a section for it, in the opposite tone to the rest of
   the page. On that speaker page it was a near black "night" section for the light show, sitting
   between two bright ones. This is the section a competitor cannot paste onto their page.

7. **Micro-interactions everywhere a finger goes.** Buttons lift 2px on hover and settle to
   `scale(.98)` on press, with a blurred glow ring behind the primary CTA. Swap the FAQ from
   `max-height` to `grid-template-rows:0fr` to `1fr`, which animates to the true height with
   no magic number and no clipped answers. Thumbnails lift on hover.

8. **Let the type get loud.** One display face with real character, one number face for the
   price and the spec numerals, tracking tightened to `-.035em` at the top size. Reserve
   gradient text for exactly one phrase in the headline. Body stays 17 to 19px.

Housekeeping while you are in there: hoist any icon you repeat more than twice into an
`<svg><symbol>` sprite at the top of the body and call it with `<use href="#star"/>`. A
five pointed star pasted thirty times is thirty times the bytes and the first thing that
looks generated.

**The bar.** Open `index-v1.html` and `index.html` side by side. If you cannot name three
things that changed *structurally*, you restyled instead of elevating. Go again.


---
name: steal-this-frame
description: Rebuilds a competitor's strongest frame with the owner's own locked product: the composition and the message are taken, the image itself is never used. Wonka describes the competitor frame in words (layout, angle, what the text does, why it works), writes a prompt for the same idea on the locked reference sheet, generates it, and inspects it against the reference. The natural partner of /refresh, which finds the frame worth taking; this one makes it. Use when the owner points at a rival's image, says "I want one like that", or /refresh names a frame to answer. Triggers: /steal-this-frame, "do what they did", "I like their first picture", "make me one like theirs", "copy that competitor image with my product", "their image 2 is great", "answer that frame", "rebuild this with my product".
---

# Steal This Frame

| Meta | Value |
|------|-------|
| Skill | Steal This Frame. Part of the bonus pack, not the kit |
| Needs | The competitor frame (a file in `1-inputs/competitors/[C]/`, a URL, or a frame `/refresh` named), the LOCKED reference sheet, `brief/creative-brief.md` (the approved claims and the avoid list), `research/competitors.md` when it exists |
| Saves to | `factory/Products/[product]/steal/[C or ASIN]-[slot]/` (`teardown.md`, `jobs.json`, the frames, `contact-sheet.html`, `cost.jsonl`) |
| Writes | ONLY inside `steal/`. Never into `images/`, `edits/` or `final/` |
| Typical cost | Two or three candidates at `low`, under $0.10. Cap $0.50 |
| Engine | `.claude/pack/engine.py`, a GENERATION job on the reference sheet. **The competitor's image is never handed to the model, as a source or as a reference** |

## What this does

Every category has one frame that keeps winning: the scale shot with the hand, the three-panel
"before / during / after", the overhead with the ten pieces fanned out. It wins because of an
idea, and ideas are not owned. This skill takes the idea: Wonka reads the competitor frame,
writes down what it is doing (the composition, the angle, the job of the text, the reason it
works), and builds the same idea from scratch on the owner's locked product.

The line it does not cross, stated once and enforced in code: the competitor's pixels are never
sent to the model. Not as the source of an edit, not as a reference. The teardown is words, the
build is on the owner's reference sheet, and the result is the owner's own image that happens to
answer the same question. A copy of their photograph is theirs; a frame that does the same job is
ours.

What it is not. It does not copy their claim: a competitor headline that the brief does not back
is a gap in the brief, not a line to render. It does not copy their brand marks, their colour
system or their model's face. And it is not `/refresh`: that one watches the shelf and names the
frame; this one makes it.

## Before you start

| Input | Missing |
|---|---|
| The competitor frame, as a file or URL | Ask for it once. A description alone is not enough to tear down |
| `Reference status: LOCKED` (read by `product.py` from `2-reference/reference-sheet.md`) | STOP. Point to `/reference-sheet`. No lock, no build |
| The brief's approved claims | Read them before writing a single word of text into the prompt. The frame's message must map to an approved claim or carry no text |

## Process

### 1. The teardown, in words

OPEN the competitor frame. Write `steal/[C]-[slot]/teardown.md`:

- **Composition**: where the product sits, the angle, the crop, what fills the frame, the
  background, the props, the light.
- **The person**, if any: what they do with the product, not who they are.
- **The text's job**: what question the words answer for the shopper, in one line. Not the
  words themselves.
- **Why it works**: one sentence. Usually it puts the product in the shopper's units (a hand, a
  pot, a child) or answers the objection every review raises.
- **What we take**: the idea, restated for OUR product with OUR anatomy.
- **What we do not take**: their brand marks, their colours, their claim if the brief does not
  back it, their model.
- **Our message**: the approved claim from the brief that this frame will carry, quoted, or
  `no text`.

### 2. The prompt, on our product

`factory/Products/[product]/steal/[C]-[slot]/jobs.json` (`out_dir` `.`, `refs` `../../2-reference/sheet-vN.png`): two or three GENERATION jobs (`refs` = the newest locked sheet and
the parts sheet if there is one; no `source`), `quality` `low`, `cap_usd` 0.5. The prompt is the
teardown turned into a build: the product named with its anatomy in one sentence, the
composition from the teardown, the person's action if any, the light, and the message rendered
as text in a clean lockup if the frame carries text. Two or three variations differ in ONE thing
each (the prop, the crop, the surface), so the owner has a choice without a pool.

**Never** in the prompt: the competitor's name, their product, "like the attached", or any
reference to their image. The model never sees it.

### 3. Generate and inspect

From the factory root: `python3 .claude/pack/engine.py run factory/Products/[product]/steal/[C]-[slot]/jobs.json`. Then the pack's own gate, as in
`/lifestyle-pack` step 5: every candidate opened, the product read against the reference at
magnification, the text (if any) transcribed and matched to the approved claim at native
resolution, and the thumbnail read at 160 px with `/inspect`'s squint rule in mind. Verdicts into
the jobs. One regeneration per failing candidate.

### 4. Hand-off, and where it goes next

`python3 .claude/pack/engine.py sheet factory/Products/[product]/steal/[C]-[slot]/jobs.json`. Open it, beside the
teardown. The winner is a CANDIDATE for the gallery, not a member of it: to enter the listing
it goes through `/inspect` and, if the owner wants proof, a Tasting round against the current
frame in that slot. Say that in one line.

## What you tell the owner

The idea in one sentence (what the frame does and why it works), the message it carries and the
claim it maps to, the candidates and the one Wonka would pick, what was deliberately not taken,
the cost, and the path. And the line about the model never seeing their image, once, because
owners ask.

## What comes next

The frames are candidates, not picks. Send them through the gate exactly like any other:

```
/inspect steal/[C or ASIN]-[slot]
```

A frame that passes goes into the gallery at its slot; the rest stay in the folder with the
teardown beside them.

## Definition of done

- `teardown.md` exists and names the idea, the message's job, what is taken and what is not.
- No competitor image path appears in `jobs.json` as a source or a ref, and no prompt mentions the competitor.
- Every candidate was opened and read against the reference; any text matches an approved claim.
- The sheet exists; the winner is described as a candidate for `/inspect`, not as a gallery frame.
- `status.md` carries the row.

## Update status.md

```
| Steal this frame ([C] slot [n]) | done | steal/[C]-[slot]/ | [date] | idea: [one line]; [n] candidates, pick [name]; candidate for slot [n] pending /inspect |
```

## Wonka lines

- "Good artists borrow the question. The answer is always ours."
- "Their photograph stays on their shelf. Their idea was never on a shelf at all."
- On a claim the brief does not back: "They promise it, we cannot prove it. So we take the frame and leave the promise."

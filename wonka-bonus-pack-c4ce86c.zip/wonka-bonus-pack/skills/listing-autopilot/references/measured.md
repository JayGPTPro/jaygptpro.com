# What the first live runs measured

Moved out of SKILL.md on 20.9.2026. The rule that survives is one line: after every call that
changes state, read the state back and compare field by field. Everything below is the
evidence for that rule.

## The read-back law (every one of these was measured on the first live run)

A state machine that trusts what it SENT is a diary, not a machine. Seven things came back
different from what went out on 16-17.9.2026, none of them with an error, and every one of them
would have shipped silently. **After every call that changes state, read the state back and say
what it actually is.**

| # | What was sent | What came back | The read-back |
|---|---|---|---|
| 1 | `brief` marked done | The send to Genrupt had never happened (the cap block landed mid-stage) | `done brief` REFUSES without a `projectId`. The stage splits: `brief-written`, then `brief-sent` |
| 2 | A market-analysis id quoted from the research report | The id lives on the Genrupt CLI account, a different organisation | `find_market_analyses` on THIS account before any id is used, and the org id written into `run-state` |
| 3 | A confirmed planner call with the slot count, the tactics and the avatars, and NO `marketAnalysisId` | `status: setup_required`, and all three discarded. No error | Compare the response to what was sent, FIELD BY FIELD. Prefer `save_listing_builder_plan_review`, which reads back |
| 4 | 5 source images for the reference sheet | 12 were used: with `projectId` + `productProfileId` the tool adds the listing images and the packaging by itself, `packagingMode: exclude` notwithstanding | Read `sourceImageUrls` off the finished sheet and say out loud what went in |
| 5 | Sheet approval, which the kit says replaces the whole bucket | It replaced the five the sheet consumed and LEFT the two it had not | Read the bucket, then a `replace` write of the sheet alone, before any blast. The blast price is the reference COUNT: 124 before, 31 after |
| 6 | 10 credits logged | 13 credits moved | Every `spend` records the balance BEFORE and AFTER. The balance is the truth; the quote is a forecast |
| 7 | A+ preflight with a valid `marketAnalysisId` and a valid `productReferenceSheetIds` | `marketAnalysis: missing` with an empty `matches[]`, and `productReferenceSheet: null`. Believing it would have re-run the analysis AND taken the default `listingReferenceMode: all`, importing seven Amazon photos over the locked reference | Pass `listingReferenceMode: "none"` explicitly and read `setupApplied` back: `listingImageReferencesAdded` must be 0 |

Two more that cost nothing and are worth saying out loud:

- **Whose money.** One line from `get_current_account_context` before the first spend. The MCP
  connection is one organisation and the Genrupt CLI is another.
- **The cap is not the purse.** `headroom` now requires the live balance for credits and refuses
  without it. Measured: a 250-credit cap over a 192-credit account, and the cap-only check said yes.


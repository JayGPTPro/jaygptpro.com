# Why the run is shaped this way

Moved out of SKILL.md on 20.9.2026. Nothing here changes what you do; it is the measured
reasoning behind two rules that people try to "optimise" when they are in a hurry. Read it
once, or when someone asks why a stage cannot be skipped.

## How long a run takes, and what this skill does NOT do

Measured on real runs, 19.8: **about 40 minutes**, and the render queue is the small
part of it (probe ~4 min, master ~8 min). The rest is this agent reading the listing,
writing the brief, building the text layer and QA'ing. Tell the user the number up
front, then work without narrating.

**There is ONE pipeline. No fast mode, no toggles, no "lite" run.** Everyone gets the
same film, and the animated text layer is always part of it, it is the thing people
notice first, so it is never the thing that gets cut.

What was cut permanently to get here, because it cost minutes and changed the film
less than the type does:
- **The occlusion moment.** The subject passing in front of a super cost ~5 minutes,
  needed a segmentation engine that is not in every environment, and once hid 63% of a
  hero line. A super placed in measured dead space does not need rescuing.
- **The style card.** A 6-second card nobody watches, ~2 minutes.
- **Research beyond the listing page.** The title, the bullets and the gallery are the
  product's own words. Wider browsing added ~5 minutes and rarely changed the argument.
- **Three delivered mixes.** One FINAL and ONE alternate, not three.
- **At most 3 supers**, not 4-5. The hook, the differentiator, one fact.

What stays, and why, so nobody re-cuts it for speed:
- **The probe.** ~6 minutes of insurance on a ~USD 9 master. It fired on both recent
  runs (a mood band 20 points low; a hero interior rendering as an abstract blur).
  Cutting it does not save 6 minutes, it risks a re-render that costs 16 and USD 9.
- **Every QA gate.** They are seconds each and each one caught something real.
- **Audio candidates**, because they are now fired as ONE parallel batch
  (genrupt-flow 5a-quater): three directions cost the same wall clock as one.


### How to count what you spent (the trap that fakes an overrun)

**NEVER compute spend by subtracting credit balances.** Measured, and it produced a
false alarm: one run reported USD 27.06 against a USD 15 cap and declared itself 80%
over. Its project actually contained exactly two renders, a probe and a master, and
the true spend was about USD 9.36. The phantom USD 17.70 was other sessions on the
same account moving the balance inside that run's window. A user seeing that report
would think the tool robbed them.

The rule:

1. **Running total = the SUM OF COST PREVIEWS you were quoted**, one line per paid
   action, plus audio at the constant below. Balance is a sanity check, never the
   source of truth.
2. **A balance delta is only evidence when you have confirmed nothing else is
   running** on the account. Otherwise it is noise, in both directions: it can invent
   spending you did not do, and it can hide a job that did not run.
3. **Audio is cheap: about 4 credits per 30s track** (measured live 17.9.2026 from the tool's own costEstimate; an earlier note said 2).
   Count the tracks you fire and add them to the running total. Because it is
   this cheap, generating 2-3 music candidates and 2 VO takes IN ONE PARALLEL BATCH
   (genrupt-flow 5a-quater, same wall clock as one) to pick the best
   is the right call, the taste gate stays.
4. A content-filter refusal on audio costs nothing, same as on video.


# asin-to-video-autopilot (Wonka bonus pack edition)

The public ASIN-to-video autopilot, installed inside a Wonka factory. See SKILL.md: the
machinery is unchanged; the intake reads the locked reference sheet, the research and the
Tasting Card instead of scraping the listing, and the film lands in the product folder.

First run: `bash .claude/skills/asin-to-video-autopilot/setup/check-env.sh` and fix any
MISSING line (ffmpeg, node 18+, python3 with pillow + numpy, whisper-cpp with a base.en
model). Genrupt is the same MCP the kit already uses.

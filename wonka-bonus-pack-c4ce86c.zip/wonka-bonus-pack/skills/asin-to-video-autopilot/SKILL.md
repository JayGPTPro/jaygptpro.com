---
name: asin-to-video-autopilot
description: >-
  Turn the product on the line (or any Amazon ASIN) into a finished 30-second listing
  video, fully on autopilot.
  One command in, a complete product film out: emotional hook, real use cases with
  people, one signature camera move, sound from the scene itself, music, voiceover, and animated
  text overlays. Zero questions during the run; a cost cap set once in config. Use
  ONLY when the owner names autopilot or says they want no part in the creative calls:
  "product video autopilot", "video on autopilot", "just make the film, your calls".
  A plain request for a video ("make me a video", "I need a video for my listing",
  "video for B0...") is NOT a trigger: ask once whether they want autopilot or
  /asin-to-video-copilot, with the difference in one line, and run the one they choose.
---

# asin-to-video-autopilot

| Meta | Value |
|------|-------|
| Skill | asin-to-video-autopilot. A PORT into the bonus pack: the machinery is the public skill, the intake is the pack's |
| Needs | Inside the factory: a product on the line with a LOCKED reference sheet, and `status.md`'s ASIN. Outside: a live ASIN or Amazon URL. Genrupt MCP with credits, and everything `setup/check-env.sh` lists: ffmpeg, python3 + PIL + numpy, node 18+, **HyperFrames** (the stage 11 renderer), whisper-cli with a base.en model |
| Saves to | `factory/Products/[product]/video/runs/[ASIN]-[date]/`: `refs/`, `plates/`, `probe/`, `work/`, `audio/`, `overlays/`, `qa/`, `out/FINAL-[slug].mp4`, `out/extras/`, `run-state.json`, the report |
| Writes | ONLY inside that run folder. Never touches `images/`, `edits/`, `final/` or the listing images |
| Typical cost | Measured, in the unit that is billed: probe ~11 credits, master 30s ~163, audio 4 per track and three tracks fired as one batch, so about 190 credits a run. TWO caps in `config.json`, `cap_credits` and `cap_usd`, never converted into each other, and the credit cap is checked against the LIVE balance |
| Engine | Genrupt MCP (Seedance 2.5) for the film and the audio, `scripts/` for every measurement and gate, HyperFrames for the stage 11 text layer, ffmpeg for the conform |


## What this does

One command turns the product on your line into a finished 30-second listing film: a hook, real
use with people, one signature camera move, diegetic sound, narration, music, and an animated
text layer. It asks you nothing while it runs. The cap is set once in `config.json` and every
paid step is priced against it before it fires.

What it is not. Not a template with your photos dropped in, not a slideshow, and not a family of
lengths: one pipeline, one film, one alternate mix. For a run where the creative decisions are
yours, use `/asin-to-video-copilot`.

## The choice, before anything else

Autopilot is never the default film. A plain request for a video gets one question first, in
Wonka's own voice: autopilot, where Wonka picks the scenes, the voice, the music and the text
and the owner sees the finished film; or `/asin-to-video-copilot`, where eight of those calls
are the owner's across two sittings. Recommend the co-pilot when the owner has ten minutes to
give it; autopilot is for a film needed now with no time to direct it. Run only the one the
owner names, and only after they name it. A yes to something else in the session is not a yes
to this.

## Before you start

| Input | Missing |
|---|---|
| A product on the line with a LOCKED reference sheet | Outside a factory, a live ASIN or Amazon URL works instead, and the film is only as accurate as the listing's own pictures |
| The Genrupt MCP, with credits | The Machine Room, `guides/mcp-setup-guide.md`. The run reads the live balance before it spends |
| ffmpeg, node 18+, HyperFrames, whisper-cli, numpy | From the factory root: `bash .claude/skills/asin-to-video-autopilot/setup/check-env.sh` names every missing one with its fix. Run it once; it is free |
| `config.json` | Written on the first run, from the three questions in the first-run section below |

> **Part of the Wonka bonus pack.** The machinery below is the public skill, unchanged. What
> the pack adds is the intake: inside a factory the film is built on the LOCKED product, not on
> whatever Amazon shows, and it lands in the product folder.
>
> **Running inside the Wonka factory.** When a product is on the line
> (`python3 .claude/pack/product.py [product]` prints it), before Stage 1:
> 1. The ASIN is `status.md`'s `ASIN` row. Never ask for it.
> 2. `config.json` lives in the factory root (the working folder, which is also where every
>    `scripts/...` path below is prefixed with `.claude/skills/asin-to-video-autopilot/`). First
>    run: copy `setup/config.template.json` there and ask ONCE for the cap. `config.json` holds
>    the caps and the taste settings only; it never holds a product. **The output folder is
>    derived from the product on every run**, `factory/Products/[product]/video`, and a run lands
>    as `video/runs/<ASIN>-.../` under it. Do not write `output_dir` into the config: a value set
>    for one product would send the next product's film into the wrong folder.
> 3. Inside the factory the references are LOCAL files (the reference sheet, the shipped
>    frames), and local files reach Genrupt through the Genrupt CLI (`genrupt upload media`),
>    not through the MCP. `check-env.sh` lists the CLI as optional because it is optional
>    OUTSIDE the factory; inside it, it is required. Verify it is installed and signed in to
>    the owner's own organisation before stage 1, and stop if it is not.
> 4. **References: the locked reference sheet FIRST** (`2-reference/sheet-vN.png`, newest),
>    then the shipped main, then up to three shipped gallery frames with no text on them
>    (`prep_refs.py` still crops what it must). The sheet is the product's identity; Amazon's
>    own gallery is not needed and is not scraped when the sheet exists.
> 5. **Research (Stage 1) reads the factory, not the listing page**: `research/product-report.md`
>    for the facts and the traps (counts, colours, mechanisms), `research/reviews.md` for the
>    buyers' words, `brief/creative-brief.md` for the argument the images already make, and
>    the newest Tasting Card (`tests/tasting-*/tasting-card.md`) for what shoppers actually
>    preferred and why. `listing.json` is written from these files so the lint has the seller's
>    own words. The film's argument must agree with the gallery's: same hero claim, same cast
>    world. Log in the report which factory files seeded which taste decisions.
> 6. Everything else runs exactly as written below: money contract, probe, master, QA, audio,
>    overlays, delivery. One path back: `video/runs/.../out/FINAL-<slug>.mp4`, and a
>    `status.md` row: `| Video (autopilot) | done | video/runs/[run]/out/FINAL-[slug].mp4 | [date] | [cost], variant [n] |`.
>
> Outside a factory, run it as the public skill: ASIN in, film out.

One command, one finished listing video. You (the agent) make every creative decision
using the taste rules in `references/`; the user's only inputs are the ASIN and the
one-time config. The promise is AUTOPILOT: after the environment check passes and the
config exists, a run never stops to ask anything unless it would cross the cost cap.
The one exception a user can switch on: `review_brief: true` in config.json stops the
run ONCE, after the brief and shot plan are written and before any credit moves, and
waits for a yes. Default false. It is the only gate that does not break the promise,
because it is free and it happens before the money.

## First run: environment + config

1. Run `bash setup/check-env.sh`. If anything is MISSING, print the fix lines it gives and
   stop. Never start a run in a broken environment. On a machine that has never run this
   skill, `bash setup/rehearse.sh` goes further: it compiles the worked example in
   `examples/dry-run/`, runs the lint gate on it and checks the overlay renderer, all for
   free. If the rehearsal passes, the pipeline works here.
2. If `config.json` does not exist in the factory root, copy `setup/config.template.json` to `config.json`, show the
   user BOTH caps (default 350 credits and USD 5 per run, never converted into each
   other) and ask ONCE if they want to change them.
   This is the only money question this product ever asks.
3. Confirm the Genrupt MCP is connected: call `get_credit_balance_and_costs` for
   the BALANCE. Do not price renders from its presets, they cannot quote
   Seedance 2.5 (measured: silently resolved to fast-model keys and clamped to
   15s). Plan from the measured constants in `references/genrupt-flow.md` §0;
   the authoritative price of every render is the `costPreview` in its own
   `generate_video` response, and that is the number you log.

## How long a run takes

Measured on real runs: **about 40 minutes**, and rendering is the small part (probe about 4
minutes, master about 8). The rest is this agent reading the listing, writing the brief,
building the text layer and running the gates. Say the number up front, then work without
narrating.

**There is ONE pipeline.** No fast mode, no toggles, no "lite" run. The animated text layer is
the thing people notice first, so it is never the thing that gets cut. The probe, every QA gate
and the parallel audio batch stay for measured reasons, and five things were cut for measured
reasons. Both lists, with the numbers, are in `references/why.md`. Do not re-cut any of it for
speed without reading that file.

## The money contract

- **TWO PURSES, never converted into each other.** `cap_credits` is the Genrupt
  purse and `cap_usd` is the dollar purse, and a credit is never restated as a
  dollar anywhere in this run. Genrupt reports no dollar rate for an organisation
  account, so a converted figure is a number nobody can check. Everything this skill
  renders is billed in CREDITS; the dollar purse exists for anything on a card or an
  OpenAI key.
- **The cap is not the purse.** Before the first paid action, read the LIVE balance
  with `get_credit_balance_and_costs` and compare it to what the run still needs.
  Measured 17.9.2026 on the listing run: a 250-credit cap over a 192-credit account,
  and the cap-only check said yes.
- **Say whose money it is, once, out loud.** One line from
  `get_current_account_context` before the first spend: "the credits that move are
  [organisation]'s". The MCP connection and the Genrupt CLI are different accounts,
  and an id quoted from the wrong one reads as valid until it is used.
- Report every paid action in one line as it happens: what, credits, running total.
- **BEFORE every paid action, check headroom against its WORST CASE cost, not its
  hoped-for cost.** If `running_total + worst_case > cap`, stop and ask. This is the
  only mid-run stop that exists.
- **Nothing else is ever a question for the user.** Measured 19.8: a run compiled at
  7,518 characters against the 7,500 ceiling, asked the user for permission to delete
  eighteen characters, and then sat idle for **54 minutes**, longer than all of its
  real work put together. A tool that refuses now prints the cheapest fixes with their
  character counts; apply them and carry on. If a decision is genuinely yours to make,
  make it, log it in the report, and keep moving.
- Typical run, in the unit that is actually billed: probe ~11 credits, master 30s
  ~163 credits, audio 4 credits per track and three candidates fired as one batch, so
  about 190 credits all in, leaving headroom for at most ONE autonomous fix. A second
  failure is written to the report with recommendations; it never spends more. These
  are the highest measured readings, not the lowest: the price moved 21% in two days
  in August, and only the `costPreview` in each response knows today's.

### How to count what you spent

**NEVER compute spend by subtracting credit balances.** The running total is the SUM OF THE COST
PREVIEWS you were quoted, one line per paid action. A balance delta is evidence only when you
have confirmed nothing else is running on the account; otherwise it invents spending that did
not happen, and it hides jobs that did not run. Audio is about 4 credits per 30-second track,
counted the same way. A content-filter refusal costs nothing. `references/why.md` has the run
where this went wrong and the false alarm it produced.

## Run stages

Every `scripts/...`, `setup/...` and `overlays/...` path in this section is inside this skill's
folder. From the factory root, where every run happens, prefix it with
`.claude/skills/asin-to-video-autopilot/`.

Stage-by-stage detail lives in `references/` (see the map below). The shape:

1. **Research, the listing page ONLY, one pass.** Scrape the ASIN through Genrupt
   (`scrape_video_reference_images_from_asin` + listing data). OPEN the product images
   and look; titles lie. Read the reviews that come back with the listing for emotional
   vs functional language. **Do not browse further**: no competitor pages, no brand
   site, no search. Measured 19.8: wider browsing cost ~5 minutes a run and never
   changed the film's argument, which comes from the seller's own title, bullets,
   gallery and reviews. **Write `listing.json` into the run** (title,
   bullets, description, image URLs): the lint checks the brief against the seller's
   own words, and cannot if the run does not keep them. Then answer **taste.md §0**
   before anything else, occasion, symbols, provenance, packaging. An outside
   reviewer's four notes on a sympathy figurine were all the same miss: attributes
   read, intent ignored.
2. **Taste decisions**, apply `references/taste.md`: emotion/features center of
   gravity, mood band with a target luminance range, the signature camera move, cast
   diversity plan, the final image. Log every decision + its reason for the report.
3. **Brief + shot plan**, the 7-beat listing template, **summing to 30 seconds** with
   a rhythm that VARIES: hook 4s, hero 6s (the signature shot), then 3 / 2 / 5 / 4, close
   6s. The old template was 4/6/4/4/4/4/4 and it shipped a film a viewer called boring
   before anything else about it: seven shots of one length is a slideshow, and the music
   brief, which reads the cut rhythm, then wrote itself a 60 BPM bed to match. taste.md
   7a states the law and the lint enforces it (at most two shots of a length, one accent
   of 2-3s, one held beat of 5s+, longest/shortest ≥ 2.0). 30 is the model's ceiling and
   the beats must USE it: an earlier template stopped at 27s because it reserved 3s for a
   post-production CTA card this skill does not make, which quietly threw away three
   seconds of paid runtime. A close that rhymes with the hook, and end states on every
   fragile beat.
4. **Compose + lint**, `scripts/compose.py` + `scripts/lint.py`. The lint gate is
   hard: density, slow words, end states, reference roles with USE/DO-NOT-USE,
   design silence, character budget. Never hand-write the master prompt.
5. **References prep**, `scripts/prep_refs.py`: screen for real people, crop
   marketing text, pad to legal aspect ratio BEFORE upload (a failed download bills;
   a filter refusal is free).
6. **Probe**, 4s/480p of the signature shot with
   real references. QA the probe:
   product fidelity, brightness against the declared mood band. **Every probe finding must
   become a change in the master prompt before the master runs, not a note.** Measured:
   a probe predicted the product losing its surface texture in close foreground, the
   master ran unchanged, and the finished film lost it exactly there. A film-wide
   guard does not protect one beat: write the fix INTO the beat that showed it.
7. **Master**, 30s/720p via `generate_video`, diegetic sound only (no music, no
   voiceover in the generated pass).
8. **QA**, `scripts/qa.py`: true beat lengths, end-state audit per beat (grabs
   clamped before detected cuts), brightness and warmth, with the close weighted double,
   count checks (Seedance cannot count), per-beat instantaneous MOTION with a
   frozen-fraction cap, and the relative signature check: the wow shot must not be
   the film's sleepiest shot. Plus the eye pass: glitter artifacts on hair and
   fabric, invented props, label fidelity.
9. **Autonomous fix, by SEVERITY CLASS, not by count.** Measured failure: a run
   spent its single fix on a dark hero and shipped with a SECOND product visible in
   frame and a third-party branded can beside it. Three classes are NEVER shippable
   and outrank everything, in this order:
   1. **A second copy of the product, or a competitor/third-party brand, in frame.**
      A seller cannot use that video at all.
   2. **Generated text or a fake logo in frame.**
   3. **A beat that is unwatchable** (near-black, frozen, or the wow shot dead).
   Try the FREE repairs first and they often suffice: trim the offending seconds at
   scene-detect boundaries, reframe with a crop, or cover the corner with an overlay.
   Only then spend. Whatever is left unfixed goes in the report by class, so the
   person knows what they are looking at.
10. **Post audio.** Four steps, in this order. The reasoning behind each gate is in
    `references/genrupt-flow.md` 5a-5e; what follows is the sequence.

    1. **Finalize the VO read against the LOCKED cut.** The brief's script is a planning
       draft. Rewrite it to the real beats before generating a word.
    2. **Generate**, then place as AT MOST 4 blocks, cut only at sentence boundaries.
    3. **Measure and gate**, both commands, both mandatory:

       ```
       python3 scripts/transcribe.py <run>/audio/placed_vo.wav <run>/audio/words.json
       python3 scripts/vo_qa.py <run>/audio/placed_vo.wav <film_seconds>
       ```

       `vo_qa` fails a robotic hole, dead air over 5s, or a quarter of the film with no
       narration. Verify the measured word timings land on their beats.
    4. **Mix with the script, never by hand:**

       ```
       python3 scripts/mix_audio.py <picture.mp4> <placed_vo.wav> <music.wav> <mixed.mp4>
       ```

       It derives the music gain from the measured VO and music levels, then proves the bed
       is audible by rendering twice, with music and with music muted, and comparing. It
       exits 1 on a buried bed. A hand-written ffmpeg line has buried the music on three
       runs and shipped it twice, because every absolute number in a finished mix looks
       correct whether or not the music is there.

    The music brief is DERIVED from the film's register, cut rhythm and energy curve.
    Generate 2 or 3 candidates in ONE batch and PICK by envelope-vs-cuts alignment. Keep SFX
    forward (they are the realism layer), music ducked under, VO on top. Never ship the only
    candidate unheard.
11. **Overlays, the text layer.** ALWAYS runs, at most 3 supers. Rules in
    `references/overlay-grammar.md`; the sequence is:

    1. **Pick ONE theme** from `overlays/themes/` and lock its palette from the product's own
       label. The label image must be a PRODUCT-SURFACE-ONLY crop, tighter than the render plate:

       ```
       python3 scripts/theme_extract.py <label_crop.png> <base_theme.json> <run>/theme.json
       python3 scripts/integrate.py measure <film.mp4>      # cap the ink to the plate's highlight
       ```
    2. **MEASURE THE ROOM BEFORE YOU PICK A SIZE.** The theme's hero size is an aspiration;
       the footage decides:

       ```
       python3 scripts/deadspace.py <film> --from T0 --to T1 --lines "line one|line two"
       ```

       It returns the largest rectangle that stays clean across the WHOLE window and the
       biggest type that fits it. Measured: a theme asked for 150px where the roomiest window
       held 430x370. Ignoring it ends one of two ways, type on a person, or type occluded
       into fragments.
    3. **Build and render.** The renderer is HyperFrames. This is the command, and it was
       missing from every file until 17.9.2026, which is why a whole run once delivered a
       film with no text layer:

       ```
       mkdir -p <run>/overlays/assets
       cp overlays/lib.js overlays/fonts.css <run>/overlays/
       cp <run>/work/picture-fixed.mp4 <run>/overlays/assets/film.mp4   # MUTED in the html
       # write <run>/overlays/index.html from template.html + theme.json + the supers
       npx --yes hyperframes check  <run>/overlays                      # lint + runtime + layout
       npx --yes hyperframes render <run>/overlays -o <run>/work/overlaid.mp4 \
           --fps 24 --quality delivery
       ```

       **`check` is not optional and it blocks the render.** It has caught a two-line hero whose
       0.96 leading overlapped its own glyphs at 58px, and a `<video>` element missing `muted`.
       Build from `overlays/template.html` + `lib.js` with EMBEDDED fonts, and keep every size
       above Amazon's 50pt-at-720p floor. The composition carries the film itself as track 0,
       so the render IS the composite.
    4. **Gate it. A FAIL BLOCKS THE COMPOSITE**, it is not advisory:

       ```
       python3 scripts/overlay_qa.py <run>/overlays/index.html <film.mp4> <run>/theme.json \
           <run>/audio/words.json
       ```

       It checks readability, the theme lock, per-glyph choreography, the 50pt/720p size floor,
       VO sync and the corner distribution. Then OPEN the box sheet in `qa/overlay-boxes/`: no
       box on a face, on hands, on the product or on a label, whatever the numbers said. Brand
       marks are real or absent (`references/taste.md` 4b).
    5. **Finish the film.** The composition renders PICTURE ONLY, so the audio is remuxed on
       afterwards from the mixed film, and the grain is matched across the composite:

       ```
       python3 scripts/integrate.py grain <run>/work/overlaid.mp4 <run>/work/grained.mp4 --sigma 2.4
       ffmpeg -i <run>/work/grained.mp4 -i <mixed.mp4> -map 0:v -map 1:a -c:v copy -c:a copy <out>
       ```

       **There is no occlusion escape hatch.** `scripts/occlude.py` still ships and
       `references/overlay-grammar.md` still documents it, but this pipeline does not call it:
       a super placed in measured dead space does not need rescuing. See `references/why.md`.
12. **THE AUDIO TASTE GATE.**
    Audio is the one layer meters cannot judge: every
    measured number can pass while the track sounds cheap, choppy or wrong for
    the picture (it happened; it failed review twice). So audio gets what
    graphics get: the autopilot briefs THREE music directions that argue with each
    other (never variations of one), renders the film with each, and ships them as
    a listening choice beside the mix it recommends. One track per direction is
    about $0.12. Each brief names a hummable hook, one structural event on a named
    second, and one texture that is wrong for the category (`genrupt-flow`
    5a-brief), instruments-and-a-mood is an order for wallpaper, and four films
    in a row came back with "I was not happy with the music".
    Flow beats sync: never chop a continuous VO read into segments to
    chase beat alignment, shift the whole read or ask for a re-paced read; a
    choppy voice is worse than a half-beat drift.
13. **Conform + report**, 1280x720, 24fps, final mute-watch pass. Write the run
    report (`scripts/report.py`): every decision, measurement, and dollar, with
    the final film and the audio alternate embedded as players.

    **THE DELIVERY LAYOUT, one file is the answer.** The person asked for a
    video, and a folder where the finished film hides among mixes and takes is
    a failure of the delivery, not a bonus. The run folder ends EXACTLY like
    this, and report.py enforces it (it refuses to write the report over a
    messy out/):

    ```
    out/FINAL-<slug>.mp4     <- the film. The ONLY mp4 at out/ root.
    out/extras/              <- ONE audio alternate. Nothing else.
    report.html              <- the receipt, players for FINAL and extras.
                                It sits at the RUN root, not inside out/,
                                because its <video src> paths are written
                                relative to the run (measured 19.8: the
                                diagram used to say out/report.html and the
                                script has always written it one level up,
                                where its own links resolve).
    work/                    <- every intermediate: composites, mixes, masks,
                                probe, trimmed segments. Never shown, safe to
                                delete after delivery.
    ```

    When you hand the result to the user, hand ONE path: `out/FINAL-<slug>.mp4`.
    Mention the report; never list the intermediates.

## Policy gate: the video must survive Amazon

A finished film Amazon rejects is worth zero. Before the master renders, run
`scripts/policy_check.py` on the VO script and every planned overlay text
(per `references/amazon-video-policy.md`): no superlative/rank claims, no prices
or promotions, no off-Amazon CTAs, no review quotes, no time-sensitive claims,
no unsubstantiated health claims. A HARD finding rewrites the line before any
credit moves, this is a free fix at that stage and an unusable video after it.

## Re-runs on the same ASIN: variant by default

The render is stochastic but the taste engine is not, left alone, run 2 produces
the SAME commercial as run 1 in a different take. So on every run, FIRST check for
previous runs on this ASIN in BOTH places:

1. **The runs directory**: `runs/<ASIN>*` under the folder the skill runs in (or
   under `factory/Products/[product]/video/`). Scan for `run-state.json` files carrying this ASIN.
2. **Genrupt's own record**: `get_project_scenes` on the ASIN's project. Measured:
   a disk scan missed a parallel session's finished run because it looked in the
   wrong folder, the provider's record is the one that cannot be missed, and an
   `IDEMPOTENCY_CONFLICT` on your first render key means the same thing.

If a previous run exists (and the user did not ask for a retake), this run is a
VARIANT: choose differently on at least TWO axes where more than one defensible
option exists, and write the divergence into the report ("Variant B, differs
from run 1: signature move, mood band, hook"). The axes, in preference order:

1. Signature camera move (the category table usually offers two).
2. Mood band (bright-everyday vs warm-lamplit, never force moody-night).
3. Hook concept (a different question, a different incomplete action).
4. World/setting + cast.
5. Overlay theme (where two registers are defensible).
6. Music register.

Never vary just to vary a rule: every variant choice must still pass the taste
engine on its own merits. The point is that a user running the skill three times
gets three FILMS to choose from, not three takes of one film.

**Retake mode** (user asks for "the same film again" / "another take"): reuse the
locked prompt verbatim with a new idempotencyKey, then per-beat A/B the two
masters and frame-splice the best beats (genrupt-flow.md §6d), measured to beat
either take alone. Variant = variety to pick from; retake = maximum quality of
one film.

## Resume: a broken run never pays twice

Every paid action and completed stage is already recorded in the run's
`run-state.json` as it happens. On invocation, if that file exists for this ASIN
with `status != delivered`: tell the user in one line ("found an unfinished run,
resuming at stage 8, the master is already rendered and paid for") and continue
from the first incomplete stage. Never re-run research, re-upload references,
re-probe, or re-render a master that run-state shows as completed, verify the
artifact exists (file on disk, or `get_video_generation_result` for a render)
and move on. Only a missing/corrupt artifact justifies re-paying, and that gets
its own money line. Starting a fresh run despite an unfinished one requires the
user saying so; the fresh run then goes to a new run folder (and becomes a
variant per the rule above).


## Definition of done

- All THIRTEEN stages ran, and `run-state.json` says so by name. A stage that could not run is
  BLOCKED with its reason in the file, never quietly skipped.
- The film carries its text layer. `overlays/index.html` exists, `hyperframes check` passed on it,
  `overlay_qa.py` printed PASS, and the box sheet in `qa/overlay-boxes/` was OPENED by eye: no box
  on a face, on hands, on the product or on a label, whatever the numbers said.
- Every paid action is one row in `run-state.json` with its `costPreview` figure in CREDITS, and
  the two purses are totalled separately. No row converts one into the other. `report.py` reads
  exactly these keys, so write them by these names or the report prints zeros without an error:
  `spend_lines: [{"what": "master 30s", "credits": 163}]` (or `"usd": 0.42` for the other
  purse), `cap_credits`, `cap_usd`, and `balance_after` when the balance was read back.
- The account the credits left is named in the file.
- The VO gate, the policy gate and the picture QA all passed on the DELIVERED file, not on an
  earlier cut.
- `out/FINAL-[slug].mp4` is 1280x720, 24fps, the briefed duration to the frame, with audio.
- The report exists beside it and its spend table matches `run-state.json` row for row.
- `status.md` carries the row.

## Reference map (complete)

| File | Owns |
|---|---|
| `references/taste.md` | Every creative decision rule, measured |
| `references/seedance25-rules.md` | Prompt grammar: end states, references, camera, density |
| `references/genrupt-flow.md` | Exact MCP calls, pricing, traps, audio doctrine, edit recipes |
| `references/overlay-grammar.md` | The text system: theme kit, choreography library, overlay QA |
| `references/amazon-video-policy.md` | What Amazon rejects, checked before any credit moves |
| `references/why.md` | Why the pipeline is shaped this way: what was cut, what stays, and the spend-counting trap |
| `overlays/` | themes/, template.html, lib.js, embedded fonts.css |
| `scripts/` | compose, lint, prep_refs, qa, deadspace, overlay_qa, theme_extract, policy_check, occlude, integrate, transcribe, mix_audio, vo_qa, report |

Every stage above is runnable; the rules were paid for on real productions (two full
acceptance-grade runs, five review rounds). Do not improvise around a rule, the
measured rules ARE the product. When a rule and reality disagree, measure, fix the
rule, and leave the measurement in the file.

## Update status.md

Inside the factory, one row per delivered film. Outside it there is no `status.md`; say the
output path instead.

```
| Video (autopilot) | done | video/runs/[run]/out/FINAL-[slug].mp4 | [date] | [n] credits, variant [n] |
```

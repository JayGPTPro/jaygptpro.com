#!/usr/bin/env python3
"""The pack's image engine. Shared by /lifestyle-pack, /seasons, /localize-gallery,
/steal-this-frame and /santa, and installed at .claude/pack/engine.py.

Wonka writes a jobs file; this script spends the money. It is deliberately dumb, the
way the kit's openai_blast.py is dumb: one attempt per image, no prompt editing, no
decisions, resume for free (a finished file on disk is skipped), and one thing the
blast never had: a CAP. The run stops BEFORE the call that would cross it.

    python3 engine.py run   jobs.json            generate every job not yet on disk
    python3 engine.py check jobs.json            brightness before/after per job (needs a source)
    python3 engine.py sheet jobs.json            before/after contact sheet + cost table
    python3 engine.py cost  jobs.json            what the run would cost, nothing spent

jobs.json:
    {
      "product": "Your Product Name",
      "skill": "lifestyle-pack",                 # who wrote the file (for the sheet title)
      "out_dir": ".",                            # EVERY path is relative to the jobs file itself
      "refs": ["../2-reference/sheet-v2.png"],   # identity references sent with EVERY job
      "cap_usd": 3.00,                           # the run stops before crossing this
      "quality": "low",                          # low | medium | high
      "jobs": [
        {"name": "kitchen-morning", "prompt": "...", "size": "1536x1024",
         "source": "final/s3.png"}               # source: optional, the image being EDITED
      ]
    }

A job with a "source" is an EDIT of that image (seasons, localize): the source is the
first image handed to the model, the refs follow. A job without one is a GENERATION
from the refs alone (lifestyle, steal-this-frame).

Env: OPENAI_API_KEY (else ./.env in the kit folder, the Machine Room convention),
WORKERS (default 4). Quality comes from the jobs file, never from the environment,
so a file and its receipt always agree.
"""
import base64
import json
import os
import sys
import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

MODEL = "gpt-image-2"
SIZES = ("1024x1024", "1536x1024", "1024x1536")

# Per-token rates for the ESTIMATE only (published gpt-image rates; the OpenAI usage
# page has the exact figure). Flat fallbacks when the API returns no usage block, and
# the WORST CASE the cap is checked against before every call.
RATE_TEXT_IN = 5.0 / 1_000_000
RATE_IMAGE_IN = 10.0 / 1_000_000
RATE_IMAGE_OUT = 40.0 / 1_000_000
FLAT_PER_IMAGE = {"low": 0.011, "medium": 0.042, "high": 0.167}
WORST_PER_IMAGE = {"low": 0.03, "medium": 0.09, "high": 0.30}
# Every image sent WITH the prompt is billed as input tokens, and the flat worst case
# above counts none of them. Measured 20.9.2026: a /lifestyle-pack job at high with the
# sheet plus a parts sheet plus two more refs prices at ~$0.31, over the $0.30 the cap
# was checking. ~1500 input-image tokens per reference at high, half that below it.
IMAGE_IN_TOKENS = {"low": 400, "medium": 800, "high": 1500}


def worst_per_job(quality, n_images):
    """The most one call can cost: the flat worst case plus the images it carries."""
    per_ref = IMAGE_IN_TOKENS[quality] * RATE_IMAGE_IN
    return round(WORST_PER_IMAGE[quality] + max(0, int(n_images)) * per_ref, 4)


def load_key():
    """The kit convention: the env var, else OPENAI_API_KEY= in ./.env of the kit folder."""
    if os.environ.get("OPENAI_API_KEY"):
        return
    env = Path(".env")
    if env.exists():
        for line in env.read_text().splitlines():
            if line.startswith("OPENAI_API_KEY="):
                os.environ["OPENAI_API_KEY"] = line.split("=", 1)[1].strip().strip('"').strip("'")
                return
    sys.exit("OPENAI_API_KEY not set and no .env found. The Machine Room "
             "(guides/mcp-setup-guide.md, Part 2) covers this.")


# The one line the pack does not cross, and the only place it can actually be held.
# /steal-this-frame promises in those words that a competitor's pixels "never reach the
# model", and five skills share this engine, so the promise belongs here and not in the
# agent that writes jobs.json. The kit's convention is `1-inputs/competitors/[C]/`; any
# path with a `competitors` folder in it is refused as a ref or a source, before a key is
# loaded and before a cent is spent. There is no override: an idea is not owned, an image is.
COMPETITOR_DIR = "competitors"


def competitor_paths(declared, resolved, base):
    """The path spellings worth checking: what the jobs file said, and where it landed.
    A `competitors` ancestor ABOVE the jobs file (someone's folder happens to be called
    that) is not the skill's business, so a resolved path under `base` is checked only
    from `base` down."""
    out = [Path(declared)]
    try:
        out.append(Path(resolved).relative_to(base))
    except ValueError:
        out.append(Path(resolved))
    return out


def refuse_competitor(declared, resolved, base, where):
    for cand in competitor_paths(declared, resolved, base):
        for part in cand.parts:
            if part.lower() == COMPETITOR_DIR:
                raise ValueError(
                    "%s points inside a competitors folder: %s. The competitor's image is "
                    "never handed to the model. Take the composition in WORDS (the teardown), "
                    "and generate on your own reference sheet." % (where, declared))


def read_jobs(path):
    path = Path(path)
    data = json.loads(path.read_text())
    base = path.parent
    for k in ("out_dir", "jobs"):
        if k not in data:
            raise ValueError("jobs file is missing '%s'" % k)
    if not data["jobs"]:
        raise ValueError("jobs file has no jobs")
    data.setdefault("refs", [])
    data.setdefault("quality", "low")
    data.setdefault("cap_usd", 2.0)
    if data["quality"] not in FLAT_PER_IMAGE:
        raise ValueError("quality must be low, medium or high, not %r" % data["quality"])
    if float(data["cap_usd"]) <= 0:
        raise ValueError("cap_usd must be above zero")

    def ab(p):
        p = Path(p)
        return p if p.is_absolute() else (base / p)

    data["_base"] = base
    data["out_dir"] = ab(data["out_dir"])
    declared_refs = list(data["refs"])
    data["refs"] = [ab(r) for r in declared_refs]
    for declared, resolved in zip(declared_refs, data["refs"]):
        refuse_competitor(declared, resolved, base, "refs entry")
    names = set()
    for j in data["jobs"]:
        for k in ("name", "prompt"):
            if not j.get(k):
                raise ValueError("every job needs a '%s': %r" % (k, j))
        if j["name"] in names:
            raise ValueError("two jobs share the name %r; names are the filenames" % j["name"])
        names.add(j["name"])
        j.setdefault("size", "1024x1024")
        if j["size"] not in SIZES:
            raise ValueError("job %s: size must be one of %s" % (j["name"], ", ".join(SIZES)))
        if j.get("source"):
            declared_source = j["source"]
            j["source"] = ab(declared_source)
            refuse_competitor(declared_source, j["source"], base,
                              "job %s: source" % j["name"])
    return data


def validate_images(paths):
    """Every reference and source must open as an image BEFORE anything is spent. One
    stray file fails every call with a cryptic mimetype error (the kit learned this)."""
    from PIL import Image
    for p in paths:
        p = Path(p)
        if not p.exists():
            raise FileNotFoundError("not on disk: %s" % p)
        try:
            with Image.open(p) as im:
                im.verify()
        except Exception as e:  # noqa: BLE001
            raise ValueError("not a usable image: %s (%s)" % (p, e))


def out_path(data, job):
    return Path(data["out_dir"]) / (job["name"] + ".png")


def _last_quality(data, name):
    try:
        rows = [json.loads(l) for l in receipt_path(data).read_text().splitlines() if l.strip()]
    except (OSError, ValueError):
        return None
    for row in reversed(rows):
        if row.get("name") == name and row.get("delivered", True):
            return row.get("quality")
    return None


def _aside(p, quality):
    return p.with_name("%s.%s%s" % (p.stem, quality, p.suffix))


def pending(data):
    """Jobs whose output is not on disk yet AT THIS QUALITY. A file under 10 KB is a broken
    write. A file made at another quality is not done either. PURE: this never moves a file,
    because `cost` and `plan_within_cap` call it and a quote must not touch the folder
    (measured 21.9.2026: it did, and a price check renamed the delivered frame)."""
    todo = []
    for j in data["jobs"]:
        p = out_path(data, j)
        if p.exists() and p.stat().st_size > 10000:
            prev = _last_quality(data, j["name"])
            if prev and prev != data["quality"] and not _aside(p, data["quality"]).exists():
                todo.append(j)          # a real render is owed at this quality
            continue
        todo.append(j)
    return todo


def settle_quality(data):
    """Called by cmd_run ONLY. For every job whose delivered file was made at another quality:
    keep that file as <name>.<its quality>.png, and if a render at the requested quality was
    kept earlier, put it back at the name with no charge. Returns the names restored."""
    restored = []
    for j in data["jobs"]:
        p = out_path(data, j)
        if not (p.exists() and p.stat().st_size > 10000):
            continue
        prev = _last_quality(data, j["name"])
        if not prev or prev == data["quality"]:
            continue
        p.replace(_aside(p, prev))
        want = _aside(p, data["quality"])
        if want.exists():
            want.replace(p)
            _record(data, {"name": j["name"], "quality": data["quality"], "usd_est": 0.0,
                           "delivered": True, "restored": True})
            restored.append(j["name"])
    return restored


def receipt_path(data):
    return Path(data["out_dir"]) / "cost.jsonl"


def spent_so_far(data):
    p = receipt_path(data)
    if not p.exists():
        return 0.0
    return sum(json.loads(l).get("usd_est", 0) for l in p.read_text().splitlines() if l.strip())


def estimate(data):
    """What the pending jobs would cost, flat and worst case. Nothing is spent."""
    todo = pending(data)
    q = data["quality"]
    return {"pending": len(todo), "quality": q,
            "flat_usd": round(len(todo) * FLAT_PER_IMAGE[q], 3),
            "worst_usd": round(sum(worst_per_job(q, len(data["refs"]) + (1 if j.get("source") else 0))
                                   for j in todo), 3),
            "spent_usd": round(spent_so_far(data), 3),
            "cap_usd": float(data["cap_usd"])}


def plan_within_cap(data):
    """The jobs the cap allows, in file order, checked against WORST CASE per image.
    Returns (allowed, refused). A refusal is not a failure; it is the cap working."""
    todo = pending(data)
    n_refs = len(data["refs"])
    spent = spent_so_far(data)
    cap = float(data["cap_usd"])
    allowed, refused = [], []
    for j in todo:
        worst = worst_per_job(data["quality"], n_refs + (1 if j.get("source") else 0))
        if spent + worst <= cap + 1e-9:
            allowed.append(j)
            spent += worst
        else:
            refused.append(j)
    return allowed, refused


# Once any worker learns the account cannot pay (out of credits, org unverified), no
# other worker may make a paid call. Cancelling futures is not enough on its own: a
# worker slot frees the moment the first one raises, so the pool dispatches the next
# job before the main thread has seen the exception. Measured 20.9.2026: 8 jobs, 2
# workers, all 8 billed after the first refusal.
_STOP = threading.Event()


# The receipt is appended by one worker while another may be rewriting it to flip a
# delivered flag. Four workers without this lock lose lines, which is lost money.
_RECEIPT_LOCK = threading.Lock()


def _record(data, entry):
    Path(data["out_dir"]).mkdir(parents=True, exist_ok=True)
    with _RECEIPT_LOCK:
        with open(receipt_path(data), "a") as f:
            f.write(json.dumps(entry) + "\n")


def _mark_delivered(data, name):
    """Flip the last receipt for this job to delivered, once the file is on disk."""
    p = receipt_path(data)
    with _RECEIPT_LOCK:
        try:
            rows = [json.loads(l) for l in p.read_text().splitlines() if l.strip()]
        except (OSError, ValueError):
            return
        for row in reversed(rows):
            if row.get("name") == name and row.get("delivered") is False:
                row["delivered"] = True
                break
        p.write_text("".join(json.dumps(r) + "\n" for r in rows))


def _usage_cost(r, quality):
    usage = getattr(r, "usage", None)
    if not usage:
        return FLAT_PER_IMAGE[quality], {}
    det = getattr(usage, "input_tokens_details", None)
    text = getattr(det, "text_tokens", 0) if det else 0
    img = getattr(det, "image_tokens", 0) if det else 0
    out = getattr(usage, "output_tokens", 0)
    return (round(text * RATE_TEXT_IN + img * RATE_IMAGE_IN + out * RATE_IMAGE_OUT, 4),
            {"text_tokens": text, "image_tokens": img, "output_tokens": out})


def one(client, data, job):
    if _STOP.is_set():
        return job["name"], "not started: the account cannot pay (see the line above)"
    dest = out_path(data, job)
    images = ([job["source"]] if job.get("source") else []) + list(data["refs"])
    if not images:
        return job["name"], "FAILED: a job needs a source or at least one ref"
    handles = []
    t0 = time.time()
    try:
        handles = [open(p, "rb") for p in images]
        r = client.images.edit(model=MODEL, image=handles, prompt=job["prompt"],
                               size=job["size"], quality=data["quality"], n=1)
        # PAID. The receipt is written HERE, before anything that can fail. Measured
        # 20.9.2026: writing it after dest.write_bytes() lost a real charge whenever the
        # write failed, and the run then reported "spent $0.00" over money already gone.
        usd, toks = _usage_cost(r, data["quality"])
        entry = {"name": job["name"], "size": job["size"], "quality": data["quality"],
                 "seconds": round(time.time() - t0, 1), "usd_est": usd, "delivered": False}
        entry.update(toks)
        _record(data, entry)
        d = r.data[0]
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes(base64.b64decode(d.b64_json))
        _mark_delivered(data, job["name"])
        return job["name"], "generated ($%.3f)" % usd
    except SystemExit:
        raise
    except Exception as e:  # noqa: BLE001
        msg = str(e)
        low = msg.lower()
        if "insufficient_quota" in low or "credit_balance_exhausted" in low:
            _STOP.set()
            raise SystemExit("the OpenAI account is OUT OF CREDITS. Top up at "
                             "platform.openai.com billing, then rerun; finished files are kept.")
        if ("verify" in low and "organization" in low) or ("403" in msg and "organization" in low):
            _STOP.set()
            raise SystemExit("OpenAI is refusing gpt-image because the ORGANIZATION IS NOT "
                             "VERIFIED. platform.openai.com > Settings > Organization > Verify. "
                             "The kit walks it through in downloads/openai-key-and-verification-walkthrough.md.")
        if "moderation" in low or "safety" in low:
            return job["name"], "BLOCKED by moderation (no retry)"
        return job["name"], "FAILED: " + msg[:180]
    finally:
        for h in handles:
            try:
                h.close()
            except Exception:  # noqa: BLE001
                pass


def cmd_run(data):
    validate_images(list(data["refs"]) + [j["source"] for j in data["jobs"] if j.get("source")])
    for name in settle_quality(data):
        print("  %s: restored the %s render made earlier, no charge" % (name, data["quality"]))
    allowed, refused = plan_within_cap(data)
    est = estimate(data)
    print("%s: %d jobs, %d pending, quality=%s, spent $%.2f of the $%.2f cap"
          % (data.get("skill", "engine"), len(data["jobs"]), est["pending"], est["quality"],
             est["spent_usd"], est["cap_usd"]))
    if refused:
        print("CAP: %d job(s) will NOT run, the worst case would cross $%.2f: %s"
              % (len(refused), est["cap_usd"], ", ".join(j["name"] for j in refused)))
    if not allowed:
        print("nothing to generate")
        return 0 if not refused else 3
    load_key()
    try:
        from openai import OpenAI
    except ImportError:
        sys.exit("The openai package is not installed. Run: python3 -m pip install openai pillow")
    client = OpenAI()
    workers = int(os.environ.get("WORKERS", "4"))
    results = []
    _STOP.clear()
    # A worker that hits OUT OF CREDITS or an unverified org raises SystemExit. Without
    # cancel_futures the executor's exit would WAIT for every queued sibling, and each of
    # them bills. Measured 20.9.2026: 8 jobs, 2 workers, 8 calls after the first refusal.
    ex = ThreadPoolExecutor(max_workers=workers)
    try:
        futures = [ex.submit(one, client, data, j) for j in allowed]
        try:
            for f in as_completed(futures):
                name, status = f.result()
                print("  %s: %s" % (name, status), flush=True)
                results.append((name, status))
        except SystemExit:
            for g in futures:
                g.cancel()
            raise
    finally:
        ex.shutdown(wait=True, cancel_futures=True)
    gen = sum(1 for _, s in results if s.startswith("generated"))
    bad = [(n, s) for n, s in results if not s.startswith("generated")]
    print("reconciliation: allowed %d = generated %d + failed %d; refused by cap %d; spent $%.2f"
          % (len(allowed), gen, len(bad), len(refused), spent_so_far(data)))
    if gen == 0:
        print("the run generated NOTHING. Read the lines above; the batch is not done.")
        return 2
    return 0 if not (bad or refused) else 3


def mean_luma(path):
    from PIL import Image, ImageStat
    with Image.open(path) as im:
        im = im.convert("L")
        im.thumbnail((256, 256))
        return ImageStat.Stat(im).mean[0]


def cmd_check(data):
    """Numbers to back the eye pass: brightness before vs after for every EDIT job.
    A drop over 8 percent is a flag (the santa rule). The eye pass is still Wonka's."""
    flagged = 0
    for j in data["jobs"]:
        if not j.get("source"):
            continue
        dest = out_path(data, j)
        if not dest.exists():
            print("%s: no output" % j["name"])
            continue
        a, b = mean_luma(j["source"]), mean_luma(dest)
        delta = (b - a) / max(a, 1) * 100
        flag = "  <-- DARKER, check it" if delta < -8 else ""
        flagged += bool(flag)
        print("%s: brightness %.0f -> %.0f (%+.0f%%)%s" % (j["name"], a, b, delta, flag))
    print("%d flagged. Same product, nothing touching it, no invented text: that read is yours." % flagged)
    return 0


def _thumb(path, max_px=900):
    import io
    from PIL import Image
    try:
        with Image.open(path) as im:
            im = im.convert("RGB")
            im.thumbnail((max_px, max_px))
            buf = io.BytesIO()
            im.save(buf, "JPEG", quality=82)
            return "data:image/jpeg;base64," + base64.b64encode(buf.getvalue()).decode()
    except Exception:  # noqa: BLE001
        return ""


def cmd_sheet(data):
    """One self-contained HTML: every job as a row, source beside output when there is a
    source, the prompt under it, the verdict Wonka wrote into the job (if any), and the
    cost table. This is the thing the owner opens."""
    import html as H
    rows = []
    for j in data["jobs"]:
        dest = out_path(data, j)
        after = ('<img src="%s">' % _thumb(dest)) if dest.exists() else '<div class="skip">not generated</div>'
        before = ('<figure><img src="%s"><figcaption>source</figcaption></figure>' % _thumb(j["source"])) if j.get("source") else ""
        verdict = j.get("verdict", "")
        badge = ""
        if j.get("stage_ready") is True:
            badge = '<span class="badge ok">ready</span>'
        elif j.get("stage_ready") is False:
            badge = '<span class="badge no">not ready</span>'
        rows.append('<section class="row"><header><b>%s</b> %s</header><div class="pair">%s<figure>%s<figcaption>%s</figcaption></figure></div><p class="prompt">%s</p>%s</section>'
                    % (H.escape(j["name"]), badge, before, after, H.escape(dest.name),
                       H.escape(j["prompt"][:400]), ('<p class="verdict">%s</p>' % H.escape(verdict)) if verdict else ""))
    total = spent_so_far(data)
    page = """<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>%s</title><style>
body{margin:0;background:#faf7f2;color:#222;font:15px/1.5 -apple-system,Segoe UI,Helvetica,Arial,sans-serif}
.wrap{max-width:1180px;margin:0 auto;padding:28px 20px 60px}h1{font-size:22px;margin:0 0 4px}.sub{color:#666;margin:0 0 24px}
.row{background:#fff;border:1px solid #e8e2d8;border-radius:12px;padding:16px;margin-bottom:22px}.row header{margin-bottom:10px}
.pair{display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:14px}figure{margin:0}figure img{width:100%%;height:auto;border-radius:8px;display:block;background:#fff}
figcaption{text-align:center;color:#777;font-size:13px;margin-top:6px}.skip{display:flex;align-items:center;justify-content:center;aspect-ratio:1;border:2px dashed #ddd;border-radius:8px;color:#888}
.badge{font-size:12px;padding:2px 8px;border-radius:999px;margin-left:8px}.badge.ok{background:#e3f5e6;color:#1d6b2c}.badge.no{background:#fde8e6;color:#a12a20}
.prompt{margin:10px 0 0;color:#666;font-size:13px}.verdict{margin:8px 0 0;color:#333;font-size:14px}.foot{color:#666;font-size:13px;margin-top:30px}
</style></head><body><div class="wrap"><h1>%s</h1><p class="sub">%s &middot; %d jobs &middot; quality %s</p>%s
<p class="foot">Estimated spend for this folder: $%.3f (receipt: cost.jsonl). Estimate uses published per-token rates; the OpenAI usage page has the exact figure.</p></div></body></html>""" % (
        H.escape(data.get("skill", "pack")), H.escape(data.get("product", "")), H.escape(data.get("skill", "")),
        len(data["jobs"]), data["quality"], "".join(rows), total)
    out = Path(data["out_dir"]) / "contact-sheet.html"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(page)
    print("%s  ($%.3f)" % (out, total))
    return 0


def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    if len(argv) != 2 or argv[0] not in ("run", "check", "sheet", "cost"):
        print(__doc__)
        return 2
    try:
        data = read_jobs(argv[1])
        if argv[0] == "cost":
            e = estimate(data)
            print("pending %d at %s: about $%.2f, worst case $%.2f; spent $%.2f of the $%.2f cap"
                  % (e["pending"], e["quality"], e["flat_usd"], e["worst_usd"], e["spent_usd"], e["cap_usd"]))
            allowed, refused = plan_within_cap(data)
            if refused:
                print("the cap allows %d of them; %d would be refused" % (len(allowed), len(refused)))
            return 0
        return {"run": cmd_run, "check": cmd_check, "sheet": cmd_sheet}[argv[0]](data)
    except (ValueError, FileNotFoundError) as e:
        print("engine.py: %s" % e, file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
